﻿(function () {
    'use strict';

    let app = angular
        .module('fcportal');

    let reqModule = ['ng-bootstrap-select', 'ui.mask'];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });

    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', function ($q) {
            return {
                'request': function (config) {
                    let accessToken = localStorage.getItem("AccessToken");
                    if (accessToken) {
                        config.headers['Authorization'] = 'Bearer ' + accessToken;
                    }
                    return config || $q.when(config);
                },
                'response': function (response) {
                    if (response.status === 401) {

                    }

                    return response || $q.when(response);
                },
                'responseError': function (rejection) {
                    if (rejection.status === 401) {

                    }

                    return $q.reject(rejection);
                }
            }
        }]);
    }]);

    app.directive('fileOnChange', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var onChangeHandler = scope.$eval(attrs.fileOnChange);
                element.on('change', function (evt) {
                    onChangeHandler(evt, scope, element, attrs);
                });
                element.on('$destroy', function () {
                    element.off();
                });

            }
        };
    });

    app.directive('inputcurrency', ['$filter', function ($filter) {
        return {
            restrict: 'E',
            require: 'ngModel',
            link: function (scope, $el, attrs, ngModel) {
                if ($el.get(0).type === 'number') {
                    ngModel.$parsers.push(function (value) {
                        //return $filter('currency')(value, '', 0);
                        return value.toString();
                    });

                    ngModel.$formatters.push(function (value) {
                        return $filter('currency')(value, '', 0);
                        //return parseFloat(value, 10);
                    });
                }
            }
        }
    }])

    app.controller('constructionServicesCtrl', constructionServicesCtrl);

    constructionServicesCtrl.$inject = ['$scope', '$http', '$timeout', '$filter', '$location'];

    function constructionServicesCtrl($scope, $http, $timeout, $filter, $location) {

        let accessToken = localStorage.getItem("AccessToken");
        if (!accessToken) {
            window.location = '/Login';
        }

        $scope.title = 'constructionServices';
        $scope.RequiredDocumentsList = [];
        let imageFileTypes = ['jpeg', "jpg", "png"];

        let webAPIPath = getWebAPIPath();
        $scope.lookupData = [];
        $scope.lookupOrgData = [];
        $scope.relationshipTypes = [
            { Title: 'Son of', ID: 1 },
            { Title: 'Daughter of', ID: 2 },
            { Title: 'Wife of', ID: 3 }
        ];

        $scope.DeliveryModeTypes = [{ ID: 1, Title: 'Pick up from e-Khidmat Markaz' }, { ID: 2, Title: 'Delivery by Post' }];
        $scope.serviceNotAvailable = false;
        $scope.Documents = [];
        $scope.challanAmountList = [];
        $scope.isShowApprovedFeeButton = false;
        $scope.challanFormStatictName = [
            'Challan Form-1 (AR-17)',
            'Challan Form-2 (AR-17)',
            'Challan Form-3 (AR-17)',
            'Challan Form-4 (AR-17)'
        ];

        $scope.currentDate = new Date();

        $scope.canAddChallanAmount = false;
        $scope.AccountHeadList = [];

        let PlotOwnerInfo = {
            ID: null,
            Name: null,
            RelationOfName: null,
            CNIC: null,
            Phone: null,
            RelationOf: null,
            Address: null,
            OwnerImage: null
        };

        let queryParams = [];
        function readQueryString(key) {
            let PageURL = decodeURI(window.location.search.substring(1));
            let sURLVariables = PageURL.split('&');

            for (let i = 0; i < sURLVariables.length; i++) {
                let sParameterName = sURLVariables[i].split('=');

                if ($.trim(sParameterName[0]).length > 0 && sParameterName[1]) {
                    queryParams[sParameterName[0]] = sParameterName[1];
                }
            }
        };

        readQueryString();

        function base64ToArrayBuffer(base64) {
            var binaryString = window.atob(base64);
            var binaryLen = binaryString.length;
            var bytes = new Uint8Array(binaryLen);
            for (var i = 0; i < binaryLen; i++) {
                var ascii = binaryString.charCodeAt(i);
                bytes[i] = ascii;
            }
            return bytes;
        }

        function saveByteArray(reportName, byte) {
            var blob = new Blob([byte], { type: "application/pdf" });
            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            var fileName = reportName;
            link.download = fileName;
            link.click();
        };

        $scope.editModel = {
            'TaskStatusID': 1,
            'ApplicantID': null,
            'StartTime': new Date(),
            'EndTime': null,
            'DivisionID': null,
            'DistrictID': null,
            'LocationID': null,
            'FCLocation': null,
            'UserName': null,
            'AuthorityID': null,
            'BPAServiceTypeID': 1,
            'ServiceID': null,
            'ServiceCode': null,
            'ServiceTypeID': null,
            'DeliveryTypeID': null,
            'ApplicationTypeID': null,
            'ApplicantCNIC': null,
            'ApplicantName': null,
            'GenderID': null,
            'ApplicantRelationOf': null,
            'FatherName': null,
            'FatherCNIC': null,
            'ApplicantContactNo': null,
            'RegisteredEmail': null,
            'CurrentAddress': null,
            'CurrentCityID': null,
            'CurrentDivisionID': null,
            'CurrentDistrictID': null,
            'IsSameAddr': false,
            'PermanentAddress': null,
            'PermanentCityID': null,
            'PermanentDivisionID': null,
            'PermanentDistrictID': null,
            'PostalAddress': null,
            'DeliveryModeID': 1,
            'CapturedImage': null,
            'SiteCoveredArea': null,
            'SitePlotArea': null,
            'SiteNatureID': null,
            'SiteAddress': null,
            'KhasraNo': null,
            'KhewatNo': null,
            'KhatoniNo': null,
            'Mouza': null,
            'Scheme': null,
            'Phase': null,
            'Sector': null,
            'Block': null,
            'StreetNo': null,
            'PlotTypeID': null,
            'ArchitectRegisNo': null,
            'Remarks': null,
            'OwnerInformationItems': [],
            'OnlineChallanCounter': [],
            'IsPSIDMandatory': false,
            'TypeID': null,
            'HeadID': null
        };

        $scope.editModel.OwnerInformationItems.push(angular.copy(PlotOwnerInfo));

        $scope.DisabledInputFields = false;
        $scope.DisabledServiceInputFields = false;
        $scope.DisableComments = true;

        $scope.dateOptions = {
            dateFormat: 'dd-mm-yy',
            showAnim: "slide",
            showOn: "both",
            buttonImage: "/images/calendar_25.gif",
            buttonImageOnly: true
        };

        $scope.UserProfile = userProfile;
        $scope.hidePlotType = false;

        let currentApplicantID = queryParams['ApplicantID'] ? queryParams['ApplicantID'] : '';

        $scope.savedSteps = [];
        for (var stepIndex = 0; stepIndex <= 5; stepIndex++) {
            $scope.savedSteps[stepIndex] = false;
        }
        /*start SufYan Panel */

        $scope.uploadReqDocFile = function (reqDocument, inputID) {

            if (reqDocument.file != null) {

                /************/
                var nameExistsObj = [];

                if ($scope.Documents != null && $scope.Documents.length > 0) {

                    nameExistsObj = $scope.Documents.filter(function (node) {
                        return node.name == reqDocument.file.name;
                    });

                    if (nameExistsObj.length > 0) {
                        toastr.info("Selected document with name '" + reqDocument.file.name + "' already attached.");
                        $scope.clearFile(inputID);
                        return;
                    }
                }
                /************/

                let jsonData = {
                    'ApplicantID': $scope.editModel.ApplicantID,
                    'UserName': $scope.editModel.UserName,
                };

                var frmData = new FormData();
                frmData.append("Data", JSON.stringify(jsonData));

                let index = 0;

                reqDocument.Size = getFileSizeKB(reqDocument.file);
                reqDocument.DocType = reqDocument.file.type;

                frmData.append("DocType" + index, reqDocument.DocType)
                frmData.append("Title" + index, reqDocument.Title | "");
                frmData.append("DocumentID" + index, reqDocument.ID);
                frmData.append("DocumentTypeID" + index, reqDocument.DocumentTypeID);
                frmData.append("DocumentTypeStaticName" + index, reqDocument.DocumentTypeStaticName);
                frmData.append("DocumentNatureID" + index, reqDocument.DocumentNatureID);
                frmData.append("Size" + index, reqDocument.Size);
                frmData.append("IssueDate" + index, reqDocument.IssueDate ? reqDocument.IssueDate.format("dd/M/yyyy") : null);
                frmData.append("ExpiryDate" + index, reqDocument.ExpiryDate ? reqDocument.ExpiryDate.format("dd/M/yyyy") : null);
                frmData.append("chosenFile", reqDocument.file);

                if ($scope.Documents == null) {
                    $scope.Documents = [];
                }

                let docServerModel = {
                    ID: null,
                    DocumentID: reqDocument.ID,
                    DocumentTypeID: reqDocument.DocumentTypeID,
                    name: reqDocument.file.name,
                    type: reqDocument.DocType,
                    size: reqDocument.Size,
                    title: reqDocument.Title,
                    IssueDate: reqDocument.IssueDate,
                    ExpiryDate: reqDocument.ExpiryDate
                }

                $scope.Documents.push(docServerModel);

                reqDocument.inUploading = true;

                $http.post(webAPIPath + 'api/Construction/SaveDocumentsInformation', frmData, {
                    withCredentials: false,
                    headers: { 'Content-Type': undefined },
                    uploadEventHandlers: {
                        progress: function (e) {
                            if (e.lengthComputable) {
                                reqDocument.uploadProgress = Math.round(e.loaded * 100 / e.total);
                            } else {
                                console.log('length false');
                            }
                        }
                    },
                    transformRequest: angular.identity
                }).then(function (successResp) {
                    reqDocument.inUploading = false;
                    if (successResp.status == HTTPStatusCode.OK) {

                        if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                            let respData = successResp.data.response_detail;

                            reqDocument.uploadProgress = null;
                            reqDocument.isUploaded = true;
                            docServerModel.ID = reqDocument.uploadedDocumentID = respData.Documents[0].ID;

                            toastr.success("Document has been uploaded Successfully.");
                            document.getElementById(inputID).value = "";

                            if ($scope.Documents != null && $scope.Documents.length > 0) {
                                $scope.DisabledServiceInputFields = true;
                            }
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {
                    reqDocument.inUploading = false;
                });

            } else {
                toastr.info("Please select the relevant document.");
            }
        }

        $scope.uploadChallanDocFile = function (reqDocument, inputID, inputScope) {

            if (reqDocument.file != null) {

                /************/
                var nameExistsObj = [];

                if ($scope.Documents != null && $scope.Documents.length > 0) {

                    nameExistsObj = $scope.Documents.filter(function (node) {
                        return node.name == reqDocument.file.name;
                    });

                    if (nameExistsObj.length > 0) {
                        toastr.info("Selected document with name '" + reqDocument.file.name + "' already attached.");
                        $scope.clearFile(inputID);
                        return;
                    }
                }
                /************/

                let jsonData = {
                    'ApplicantID': $scope.editModel.ApplicantID,
                    'UserName': $scope.editModel.UserName,
                    'IsChallanUpload': true
                };

                var frmData = new FormData();
                frmData.append("Data", JSON.stringify(jsonData));

                let index = 0;

                reqDocument.Size = getFileSizeKB(reqDocument.file);
                reqDocument.DocType = reqDocument.file.type;

                frmData.append("DocType" + index, reqDocument.DocType)
                frmData.append("Title" + index, reqDocument.Title | "");
                frmData.append("DocumentID" + index, reqDocument.ID);
                frmData.append("DocumentTypeID" + index, reqDocument.DocumentTypeID);
                frmData.append("DocumentTypeStaticName" + index, reqDocument.DocumentTypeStaticName);
                frmData.append("DocumentNatureID" + index, reqDocument.DocumentNatureID);
                frmData.append("Size" + index, reqDocument.Size);
                frmData.append("IssueDate" + index, reqDocument.IssueDate ? reqDocument.IssueDate.format("dd/M/yyyy") : null);
                frmData.append("ExpiryDate" + index, reqDocument.ExpiryDate ? reqDocument.ExpiryDate.format("dd/M/yyyy") : null);
                frmData.append("chosenFile", reqDocument.file);

                if ($scope.Documents == null) {
                    $scope.Documents = [];
                }

                let docServerModel = {
                    ID: null,
                    DocumentID: reqDocument.ID,
                    DocumentTypeID: reqDocument.DocumentTypeID,
                    name: reqDocument.file.name,
                    type: reqDocument.DocType,
                    size: reqDocument.Size,
                    title: reqDocument.Title,
                    IssueDate: reqDocument.IssueDate,
                    ExpiryDate: reqDocument.ExpiryDate
                }

                $scope.Documents.push(docServerModel);

                reqDocument.inUploading = true;

                $http.post(webAPIPath + 'api/Construction/SaveDocumentsInformation', frmData, {
                    withCredentials: false,
                    headers: { 'Content-Type': undefined },
                    uploadEventHandlers: {
                        progress: function (e) {
                            if (e.lengthComputable) {
                                reqDocument.uploadProgress = Math.round(e.loaded * 100 / e.total);
                            } else {
                                console.log('length false');
                            }
                        }
                    },
                    transformRequest: angular.identity
                }).then(function (successResp) {
                    reqDocument.inUploading = false;
                    if (successResp.status == HTTPStatusCode.OK) {

                        if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                            let respData = successResp.data.response_detail;

                            reqDocument.uploadProgress = null;
                            reqDocument.isUploaded = true;
                            docServerModel.ID = reqDocument.uploadedDocumentID = respData.Documents[0].ID;
                            inputScope.challanItem.IsPaid = true;

                            toastr.success("Document has been uploaded Successfully.");
                            document.getElementById(inputID).value = "";

                            if ($scope.Documents != null && $scope.Documents.length > 0) {
                                $scope.DisabledServiceInputFields = true;
                            }
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {
                    reqDocument.inUploading = false;
                });

            } else {
                toastr.info("Please select the relevant document.");
            }
        }

        $scope.clearFile = function (inputID) {
            document.getElementById(inputID).value = "";
        };

        $scope.downloadFile = function (ID) {
            if (ID > 0) {
                $http.get(webAPIPath + 'api/Construction/GetDocumentByRecordID', {
                    params: {
                        'applicantID': $scope.editModel.ApplicantID,
                        'recordID': ID
                    }
                }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {
                        let resp = successResp.data;

                        if (resp.response_header.status == APIResponseType.SUCCESS) {
                            let respData = resp.response_detail;

                            let fileByteArray = base64ToArrayBuffer(respData.FileBytes);
                            saveByteArray(respData.name, fileByteArray);
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {

                });
            }
        }

        $scope.markDocumentStatus = function (reqDoc) {
            if (reqDoc.uploadedDocumentID > 0) {
                var document = {
                    'RecordID': null,
                    'IsApproved': null
                }

                var model = {
                    'ApplicantID': null,
                    'ApprovalDisapproval': []
                }

                document.RecordID = reqDoc.uploadedDocumentID;
                document.IsApproved = reqDoc.IsApproved == 3 ? 1 : 3;

                model.ApplicantID = $scope.editModel.ApplicantID;
                model.ApprovalDisapproval.push(document);

                $http.post(webAPIPath + 'api/Construction/MarkDocumentStatus', JSON.stringify(model)).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {
                        let resp = successResp.data;

                        if (resp.response_header.status == APIResponseType.SUCCESS) {
                            reqDoc.IsApproved = document.IsApproved;

                            if (document.IsApproved == 3) {
                                toastr.success("Document mark with objection.");

                                let objectionDocList = $filter("filter")($scope.lookupData.RequiredDocuments, {
                                    IsApproved: 3
                                });

                                $scope.documentObjectionReason = (objectionDocList.length || 1) + '. ';
                                $('#objectionDocTxtModel').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });
                            } else {
                                toastr.success("Document objection removed.");
                            }


                        } else {
                            reqDoc.IsApproved = reqDoc.IsApproved;
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {

                });
            }
        }

        $scope.requiredDocumentSelected = function (evt, inputScope, element, attrs) {

            let elem = element[0];

            if (elem.files.length == 0) {
                toastr.info("Please attach file.");
                return;
            }

            let fileObj = elem.files[0];

            if (fileObj != "" && fileObj != undefined) {

                if (fileObj.type.indexOf('pdf') !== -1) {
                    /*file size limit */
                    let fileSize = getFileSizeKB(fileObj);

                    if (fileSize > 1024) { // 1 Mb file size

                        toastr.info("Document with name " + fileObj.name + " is exceeding the max file size limit (1 MB).");
                        $(evt.target).get(0).value = '';
                        return;
                    }

                    if (checkFileName(fileObj.name)) {

                        toastr.info(fileObj.name + " might have some special characters. Please rename the file name and upload again.");
                        $(evt.target).get(0).value = '';
                        return;
                    }

                    inputScope.document.fileName = fileObj.name;
                    inputScope.document.file = fileObj;
                    inputScope.document.IsApproved = 1;

                    $scope.uploadReqDocFile(inputScope.document, $(element[0]).attr('id'));
                } else {
                    toastr.info("Please upload pdf file only.");

                    $timeout(function () {
                        $(evt.target).get(0).value = '';
                    }, 100);

                }
            };
        }

        $scope.challanDocumentSelected = function (evt, inputScope, element, attrs) {

            let elem = element[0];

            if (elem.files.length == 0) {
                toastr.info("Please attach file.");
                return;
            }

            let fileObj = elem.files[0];

            if (fileObj != "" && fileObj != undefined) {

                if (fileObj.type.indexOf('pdf') !== -1) {
                    /*file size limit */
                    let fileSize = getFileSizeKB(fileObj);

                    if (fileSize > 1024) { // 1 Mb file size

                        toastr.info("Document with name " + fileObj.name + " is exceeding the max file size limit (1 MB).");
                        $(evt.target).get(0).value = '';
                        return;
                    }

                    if (checkFileName(fileObj.name)) {

                        toastr.info(fileObj.name + " might have some special characters. Please rename the file name and upload again.");
                        $(evt.target).get(0).value = '';
                        return;
                    }

                    inputScope.challanItem.document.fileName = fileObj.name;
                    inputScope.challanItem.document.file = fileObj;
                    inputScope.challanItem.document.IsApproved = 1;

                    $scope.uploadChallanDocFile(inputScope.challanItem.document, $(element[0]).attr('id'), inputScope);
                } else {
                    toastr.info("Please upload pdf file only.");

                    $timeout(function () {
                        $(evt.target).get(0).value = '';
                    }, 100);

                }
            };
        }

        $scope.uploadFile = function (evt, inputScope, element, attrs) {

            let fr = new FileReader();

            /*only file type images */
            let fileobj = element[0].files[0];

            if (fileobj != "" && fileobj != undefined) {
                let fileStatus = null;

                fileStatus = imageFileTypes.indexOf(fileobj.type.split("/")[1]);

                if (fileStatus == -1) {
                    inputScope.item.OwnerImage = null;
                    toastr.info("Please upload image file only");
                    $(evt.target).get(0).value = '';
                    return;
                }
                /*only file type images */

                /*file size limit */
                let fileCheckfailed = false;
                let fileSize = getFileSizeKB(fileobj);

                if (fileSize > 500) { // 500kb file size
                    fileCheckfailed = true;
                    toastr.info("Document with name " + fileobj.name + " is exceeding the max file size limit (500KB).");
                    inputScope.item.OwnerImage = null;
                    $(evt.target).get(0).value = '';
                    return;
                }

                if (checkFileName(fileobj.name)) {
                    fileCheckfailed = true;
                    toastr.info(fileobj.name + " might have some special characters. Please rename the file name and upload again.");
                    inputScope.item.OwnerImage = null;
                    $(evt.target).get(0).value = '';
                    return;
                }
                /*file size limit */

                fr.onload = function (e) {
                    let fileBase64 = this.result;
                    $scope.$apply(function () {
                        inputScope.item.OwnerImage = fileBase64;
                    });
                }

                if (element[0].files.length > 0)
                    fr.readAsDataURL(fileobj);
            }
        };

        $scope.profilePicture = function (evt, inputScope, element, attrs) {
            let fr = new FileReader

            /*only file type images */
            let fileobj = element[0].files[0];

            if (fileobj != "" && fileobj != undefined) {
                let fileStatus = null;
                fileStatus = imageFileTypes.indexOf(fileobj.type.split("/")[1]);

                if (fileStatus == -1) {
                    $scope.editModel.CapturedImage = null;
                    toastr.info("Please upload image file only");
                    $(evt.target).get(0).value = '';
                    return;
                }
                /*only file type images */


                /*file size limit */
                let fileCheckfailed = false;

                let fileSize = getFileSizeKB(fileobj);

                if (fileSize > 500) { // 500kb file size
                    fileCheckfailed = true;
                    toastr.info("Document with name " + fileobj.name + " is exceeding the max file size limit (500KB).");
                    $scope.editModel.CapturedImage = null;
                    $(evt.target).get(0).value = '';
                    return;
                }

                if (checkFileName(fileobj.name)) {
                    fileCheckfailed = true;
                    toastr.info(fileobj.name + " might have some special characters. Please rename the file name and upload again.");
                    $scope.editModel.CapturedImage = null;
                    $(evt.target).get(0).value = '';
                    return;
                }

                /*file size limit */

                fr.onload = function (e) {
                    let fileBase64 = this.result;
                    $scope.$apply(function () {
                        $scope.editModel.CapturedImage = fileBase64;
                    });
                }

                if (element[0].files.length > 0)
                    fr.readAsDataURL(fileobj);
            };

        }

        $scope.clickedBack = function () {
            let currStep = $scope.currentStep - 1;

            if (currStep < 1) {
                currStep = 1;
            }

            $scope.currentStep = currStep;

            if ($scope.currentStep == 1) {
                $timeout(function () {
                    $('[data-ng-model="editModel.BPAServiceTypeID"]').focus();
                    $('select[selectpicker]').selectpicker('refresh');
                }, 10);
            } if ($scope.currentStep == 2) {
                $timeout(function () {
                    $('[data-ng-model="currentReqDocModel.RequiredDocumentID"]').focus();
                }, 10);
            } if ($scope.currentStep == 3) {
                $timeout(function () {
                    $('#OwnerInformation table tbody > tr:first td:first input[data-ng-model="item.Name"]').focus();
                }, 10);

            } if ($scope.currentStep == 4) {
                $timeout(function () {
                    $('[data-ng-model="editModel.SiteCoveredArea"]').focus();
                    $('select[selectpicker]').selectpicker('refresh');
                }, 10);
            }

        };

        $scope.clickedNext = function () {
            let currStep = $scope.currentStep + 1;

            if (currStep > 5) {
                currStep = 5;
            }

            $scope.currentStep = currStep;

            if ($scope.currentStep == 2) {
                $timeout(function () {
                    $('[data-ng-model="currentReqDocModel.RequiredDocumentID"]').focus();
                }, 10);
            } if ($scope.currentStep == 3) {
                $timeout(function () {
                    $('#OwnerInformation table tbody > tr:first td:first input[data-ng-model="item.Name"]').focus();
                }, 10);

            } if ($scope.currentStep == 4) {
                $timeout(function () {
                    $('[data-ng-model="editModel.SiteCoveredArea"]').focus();
                }, 10);
            } if ($scope.currentStep == 5) {
                $timeout(function () {
                    $('[data-ng-model="editModel.Remarks"]').focus();
                }, 10);
            }

        };

        $scope.showStepOnClick = function (moveToStep) {
            if (moveToStep) {
                if ($scope.savedSteps[moveToStep] == true) {
                    $scope.currentStep = moveToStep;
                } else if (moveToStep == 5) {
                    let allsaved = true;
                    for (var allSavedCount = 1; allSavedCount < 4; allSavedCount++) {
                        if ($scope.savedSteps[allSavedCount] == false) {
                            allsaved = false;
                        }
                    }

                    if (allsaved) {
                        $scope.currentStep = moveToStep;
                    }
                }
            }
        }

        $scope.eKhidmatCenterAddress = '';

        $scope.OnlineChallanSum = 0;;
        $scope.feeTypes = [];
        function fixRequiredDocList() {
            if ($scope.lookupData.RequiredDocuments) {
                let reqDocsList = $filter("filter")($scope.lookupData.RequiredDocuments, {
                    ServiceTypeID: $scope.editModel.ServiceTypeID,
                    RequiredAppTypeID: $scope.editModel.ApplicationTypeID
                });

                if (reqDocsList && reqDocsList.length > 0) {
                    for (let reqDocCount = 0; reqDocCount < reqDocsList.length; reqDocCount++) {

                        let reqDocItem = reqDocsList[reqDocCount];

                        reqDocItem.isUploaded = false;
                        reqDocItem.uploadProgress = null;
                        reqDocItem.uploadedDocumentID = null;
                        reqDocItem.IsApproved = null;
                        reqDocItem.IsChallanForm = false;

                        //if ($scope.UserProfile.UserType == PortalUserTypes.CitizenPortal && $scope.editModel.TaskStatusID == 5) {
                        //    if (reqDocItem.DocumentTypeStaticName == $scope.challanFormStatictName) {
                        //        reqDocItem.IsMandatory = true;
                        //        reqDocItem.IsChallanForm = true;
                        //    } else {
                        //        reqDocItem.inUploading = true;
                        //    }
                        //}

                        if ($scope.challanFormStatictName.indexOf(reqDocItem.DocumentTypeStaticName) >= 0) {
                            reqDocItem.IsChallanForm = true;
                        }

                        if ($scope.Documents) {
                            for (let docCount = 0; docCount < $scope.Documents.length; docCount++) {

                                let docItem = $scope.Documents[docCount];

                                if (docItem.DocumentID == reqDocItem.ID) {
                                    reqDocItem.fileName = docItem.name;
                                    reqDocItem.uploadedDocumentID = docItem.ID;
                                    reqDocItem.isUploaded = true;
                                    reqDocItem.IsApproved = docItem.IsApproved;
                                    break;
                                }
                            }
                        }
                    }
                } else {
                    $scope.lookupData.RequiredDocuments.forEach(function (reqDocItem, docIndex) {
                        reqDocItem.isUploaded = false;
                        reqDocItem.uploadProgress = null;
                        reqDocItem.uploadedDocumentID = null;
                        reqDocItem.IsApproved = null;
                        reqDocItem.IsChallanForm = false;
                    });
                }

                $scope.OnlineChallanSum = 0;

                if ($scope.editModel.OnlineChallanCounter) {
                    let reqDocsList = $filter("filter")($scope.lookupData.RequiredDocuments, {
                        IsChallanForm: true
                    });

                    let challans = $scope.editModel.OnlineChallanCounter;

                    if (challans && challans.length > 0) {
                        let feeTypes = challans[0].ChallanFee;

                        $scope.feeTypes = [];
                        for (var feeTypeCount = 0; feeTypeCount < feeTypes.length; feeTypeCount++) {
                            $scope.feeTypes.push(feeTypes[feeTypeCount].FeeType);
                        }

                        for (var challanCounter = 0; challanCounter < challans.length; challanCounter++) {
                            let challanItem = challans[challanCounter];

                            for (var feeTypeCount = 0; feeTypeCount < challanItem.ChallanFee.length; feeTypeCount++) {
                                let feeItem = challanItem.ChallanFee[feeTypeCount];

                                $scope.OnlineChallanSum += feeItem.Amount;
                            }

                            if (challanItem.IsPaid) {
                                for (var reqDocCount = 0; reqDocCount < reqDocsList.length; reqDocCount++) {
                                    let reqDocItem = reqDocsList[reqDocCount];
                                    if (reqDocItem.ID == challanItem.DocumentID) {
                                        challanItem.document = reqDocItem;
                                        break;
                                    }
                                }
                            } else {
                                // TODO: need to fix, may be create lots of bugs
                                let reqDocsListNotUploaded = $filter("filter")(reqDocsList, {
                                    isUploaded: false
                                });

                                challanItem.document = reqDocsListNotUploaded[0];
                            }

                        }
                    }

                }
            }
        }

        $scope.showApprovedFeeButton = function () {
            if ($scope.lookupData.OnlineChallanList) {
                var object = $scope.lookupData.OnlineChallanList.filter(function (node) {
                    return node.Amount > 0;
                })

                if (object && object.length > 0 && $scope.UserProfile.UserType == 3) {
                    $scope.isShowApprovedFeeButton = true;
                }
                else {
                    $scope.isShowApprovedFeeButton = false;
                }
            }

        };

        $scope.paidChallanFee = function () {
            if (!isChallanPaid()) {
                toastr.info("Please Add Paid Challan in Document(s) List.");
                $scope.currentStep = 2;
                return;
            }

            if (!$("form").validationEngine('validate')) {
                //toastr.info("Please enter comments.");
                //$scope.currentStep = 5;
                //return;

                $scope.editModel.Remarks = 'Challan fee paid and uploaded.'.toUpperCase();
            }

            if ($scope.editModel.OnlineChallanCounter != null && $scope.editModel.OnlineChallanCounter.length > 0) {
                if ($scope.editModel.IsPSIDMandatory && ($scope.editModel.OnlineChallanCounter[0].PSID == undefined || $scope.editModel.OnlineChallanCounter[0].PSID == null || $scope.editModel.OnlineChallanCounter[0].PSID != '')
                      && ($scope.editModel.OnlineChallanCounter[0].PSIDStatus == undefined || $scope.editModel.OnlineChallanCounter[0].PSIDStatus == null || $scope.editModel.OnlineChallanCounter[0].PSIDStatus.toUpperCase() != 'PAID')) {
                    //toastr.info("PSID status has not been updated against your challan. Please Submit form again.");
                    //return;
                    if (!confirm("Challan Payment will be updated soon. Do you want to proceed application for further process?")) {
                        return;
                    }
                }
            }


            $scope.markApplicationStatus($scope.editModel.ApplicantID, "6", $scope.editModel.Remarks);
        };

        $scope.markApplicationStatus = function (applicantID, status, remarks) {


            let model = {
                'ApplicantID': applicantID,
                "TaskStatusID": status,
                "Remarks": remarks.toUpperCase(),
                "UserName": $scope.UserProfile.UserType == 3 ? $scope.UserProfile.UserName : $scope.editModel.UserName,
                'ApplicantName': $scope.editModel.ApplicantName,
                'ApplicantContactNo': $scope.editModel.ApplicantContactNo,
                'RegisteredEmail': $scope.editModel.RegisteredEmail
            }

            function successCallback(response) {

                if (response.status == HTTPStatusCode.OK) {
                    if (response.data.response_header.status == APIResponseType.SUCCESS) {
                        toastr.success(response.data.response_header.message);
                        gotoDashboard();
                    }
                    else {
                        handleResponseError(response.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            var path = webAPIPath + 'api/Construction/MarkApplicationStatus';

            return $http({
                method: 'post',
                url: path,
                data: model
            }).then(successCallback, errorCallback);
        };

        $scope.approvedChallanFee = function () {
            if (!$("form").validationEngine('validate')) {
                toastr.info("Please enter comments.");
                return;
            }

            $scope.markApplicationStatus($scope.editModel.ApplicantID, "5", $scope.editModel.Remarks);
        };

        $scope.disableScApprovedBtn = true;

        /*end SufYan Panel */
        function getList() {

            function successCallback(successResp) {
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                        let respData = successResp.data.response_detail;

                        $scope.lookupData = respData.LookupData;
                        $scope.lookupOrgData = $scope.lookupData;

                        //$scope.showApprovedFeeButton();

                        if (respData.Model) {
                            $timeout(function () {

                                for (let prop in respData.Model) {

                                    if ($scope.editModel.hasOwnProperty(prop)) {
                                        $scope.editModel[prop] = respData.Model[prop];
                                    }
                                }

                                $scope.editModel.Remarks = '';

                                $scope.Documents = respData.Model.Documents; //this is the list of saved documents.

                                //challanFormStatictName

                                fixRequiredDocList();

                                $scope.RemarksHistory = respData.Model.RemarksHistory;

                                let selectedServices = $filter("filter")($scope.lookupData.Services, { 'ID': $scope.editModel.ServiceID })

                                if (selectedServices && selectedServices.length > 0) {
                                    $scope.editModel.ServiceCode = selectedServices[0].Code;
                                }

                                let locations = $filter("filter")($scope.lookupData.Locations, { 'ID': $scope.editModel.LocationID })

                                if (locations && locations.length > 0) {
                                    $scope.editModel.FCLocation = locations[0].Code;
                                    $scope.editModel.UserName = locations[0].UserName;
                                    $scope.eKhidmatCenterAddress = locations[0].Name + " " + locations[0].Description;
                                }


                                let moveToStep = 1;

                                if ($scope.editModel.ApplicantID) {
                                    $scope.savedSteps[1] = true;
                                    moveToStep = 2;
                                }

                                if ($scope.Documents) {
                                    $scope.savedSteps[2] = true;
                                    moveToStep = 3;
                                }

                                if ($scope.editModel.OwnerInformationItems && $scope.editModel.OwnerInformationItems.length > 0) {
                                    $scope.savedSteps[3] = true;
                                }

                                if ($scope.editModel.SiteCoveredArea) {
                                    $scope.savedSteps[3] = true;
                                    $scope.savedSteps[4] = true;
                                    moveToStep = 5;
                                }
                                else {
                                    $scope.editModel.ArchitectRegisNo = $scope.UserProfile.ArchitectRegisNo;
                                }

                                let commentsDisableTaskStatus = [];

                                if ($scope.UserProfile.UserType == 2) {

                                    commentsDisableTaskStatus.push(0, 1, 4, 5);

                                    if ($scope.editModel.TaskStatusID == 4) {
                                        $scope.currentStep = 2;
                                    } else {

                                        if (moveToStep == 5 && $scope.editModel.TaskStatusID == 1) {
                                            $scope.editModel.Remarks = 'Application Submitted, Please.'.toUpperCase();
                                        }

                                        $scope.currentStep = moveToStep;
                                    }

                                } else if ($scope.UserProfile.UserType == 3) {

                                    let scMoveToStep = 5;
                                    $scope.canAddChallanAmount = true;
                                    if ($scope.editModel.TaskStatusID == 2) {
                                        scMoveToStep = 4;
                                    }

                                    $scope.currentStep = scMoveToStep;

                                    commentsDisableTaskStatus.push(2);
                                    commentsDisableTaskStatus.push(6);

                                    // Check IsChallanGeneratedBySc

                                    if ($scope.editModel.OnlineChallanCounter != null && $scope.editModel.OnlineChallanCounter.length > 0) {
                                        $scope.disableScApprovedBtn = false;
                                    }
                                }

                                if (!$scope.editModel.OwnerInformationItems) {
                                    $scope.editModel.OwnerInformationItems = [];
                                }

                                if ($scope.editModel.OwnerInformationItems.length == 0) {
                                    $scope.editModel.OwnerInformationItems.push(angular.copy(PlotOwnerInfo));
                                }

                                showHideEkhidmatCenter();
                                showHideServiceType();
                                showHideDeliveryTypes();

                                showHideApplicationTypes();

                                if ($scope.Documents != null && $scope.Documents.length > 0) {
                                    $scope.DisabledServiceInputFields = true;
                                }

                                if ($scope.UserProfile.UserType == PortalUserTypes.ScrutinizedPortal ||
                                    ($scope.editModel.TaskStatusID !== 1 && $scope.editModel.TaskStatusID !== 4)) {
                                    $scope.DisabledInputFields = true;
                                }


                                if (commentsDisableTaskStatus.indexOf($scope.editModel.TaskStatusID) >= 0) {
                                    $scope.DisableComments = false;
                                }

                                if ($scope.currentStep == 1) {
                                    $timeout(function () {
                                        $('[data-ng-model="editModel.BPAServiceTypeID"]').focus();
                                        $('select[selectpicker]').selectpicker('refresh');
                                    }, 100);
                                } else if ($scope.currentStep == 2) {
                                    $timeout(function () {
                                        $('[data-ng-model="currentReqDocModel.RequiredDocumentID"]').focus();
                                    }, 10);
                                } else if ($scope.currentStep == 3) {
                                    $timeout(function () {
                                        $('#OwnerInformation table tbody > tr:first td:first input[data-ng-model="item.Name"]').focus();
                                    }, 10);

                                } else if ($scope.currentStep == 4) {
                                    $timeout(function () {
                                        $('[data-ng-model="editModel.SiteCoveredArea"]').focus();
                                    }, 10);
                                } else if ($scope.currentStep == 5) {
                                    $timeout(function () {
                                        $('[data-ng-model="editModel.Remarks"]').focus();
                                    }, 10);
                                }

                                showHidePlotType();
                            }, 100);
                        } else {

                            if (!$scope.editModel.OwnerInformationItems) {
                                $scope.editModel.OwnerInformationItems = [];
                            }

                            if ($scope.editModel.OwnerInformationItems.length == 0) {
                                $scope.editModel.OwnerInformationItems.push(angular.copy(PlotOwnerInfo));
                            }

                            fixRequiredDocList();

                            showHideServiceType();
                            showHideDeliveryTypes();
                            showHideApplicationTypes();

                            if (currentApplicantID == "") {
                                $scope.editModel.ApplicantCNIC = $scope.UserProfile.CNIC;
                                $scope.editModel.ApplicantName = $scope.UserProfile.DisplayName;
                                $scope.editModel.ApplicantRelationOf = $scope.UserProfile.ApplicantRelationOf;
                                $scope.editModel.FatherName = $scope.UserProfile.FatherName;
                                $scope.editModel.FatherCNIC = $scope.UserProfile.FatherCNIC;
                                $scope.editModel.GenderID = $scope.UserProfile.GenderID;
                                $scope.editModel.ApplicantContactNo = $scope.UserProfile.CellNumber;
                                $scope.editModel.RegisteredEmail = $scope.UserProfile.EMail;
                                $scope.editModel.CurrentDivisionID = $scope.UserProfile.DivisionID;
                                $scope.editModel.CurrentDistrictID = $scope.UserProfile.DistrictID;
                                $scope.editModel.CurrentCityID = $scope.UserProfile.CityID;

                                $scope.editModel.DivisionID = $scope.UserProfile.DivisionID;
                                $scope.editModel.DistrictID = $scope.UserProfile.DistrictID;
                                $scope.editModel.ArchitectRegisNo = $scope.UserProfile.ArchitectRegisNo;
                                $scope.getCenterByDistrict();
                            }
                        }

                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                    if ($scope.lookupData.OnlineChallanList != null && $scope.lookupData.OnlineChallanList.length > 0) {
                        $scope.editModel.TypeID = $scope.lookupData.OnlineChallanList[0].TypeID;
                        $scope.editModel.HeadID = $scope.lookupData.OnlineChallanList[0].HeadID;
                    }
                    $scope.accountTypeChange();
                }
            }

            function errorCallback(response) {
                console.log(response);
            }


            let serviceCode = queryParams['ServiceCode'] ? queryParams['ServiceCode'] : '';

            $http.get(webAPIPath + 'api/Construction/GetRecordByID', { params: { 'ID': currentApplicantID, 'serviceCode': serviceCode } }).then(successCallback, errorCallback);
        }

        $scope.divisionChange = function () {
            if ($scope.editModel.DivisionID) {
                var obj = $scope.lookupData.Districts.filter(function (node) {
                    return node.DivisionID == $scope.editModel.DivisionID;
                });

                if (obj.length > 0) {
                    $scope.editModel.DistrictID = obj[0].ID;
                    $scope.getCenterByDistrict();
                }
            }

            if ($scope.editModel.DivisionID <= 0 || $scope.editModel.DivisionID == null) {
                $scope.lookupData.Authorities = null;
                $scope.editModel.BPAServiceTypeID = null;
                //$scope.lookupData.BPAServiceTypes = null;

            }
        }

        $scope.accountTypeChange = function () {
            $scope.AccountHeadList = [];
            if ($scope.editModel.TypeID) {
                $scope.AccountHeadList = $scope.lookupData.AccHead.filter(function (node) {
                    return node.TypeID == $scope.editModel.TypeID;
                });
            }
            if ($scope.AccountHeadList.length > 0) {
                $scope.editModel.HeadID = $scope.AccountHeadList[0].ID;
            }
            if ($scope.editModel.TypeID <= 0 || $scope.editModel.TypeID == null) {
                $scope.editModel.HeadID = null;
            }
        }

        $scope.getCenterByDistrict = function () {
            if ($scope.editModel.DistrictID) {

                var mapFCDistrictID = null;

                var obj = $scope.lookupData.Districts.filter(function (node) {
                    return node.ID == $scope.editModel.DistrictID;
                });

                if (obj.length > 0) {
                    mapFCDistrictID = obj[0].MapFCDistrictID;
                }

                $http.get(webAPIPath + 'api/Construction/GetCentersByDistrict', { params: { 'districtID': mapFCDistrictID } }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {
                        let resp = successResp.data;

                        if (resp.response_header.status == APIResponseType.SUCCESS) {
                            let respData = resp.response_detail;

                            $scope.lookupData.Locations = respData.LookupData.Locations;

                            if ($scope.lookupData.Locations && $scope.lookupData.Locations.length == 1) {
                                $scope.editModel.LocationID = $scope.lookupData.Locations[0].ID;

                                showHideEkhidmatCenter();

                                $timeout(function () {
                                    $scope.getAuthorities();
                                }, 10);
                            }
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {

                });
            }

            else if ($scope.editModel.DistrictID == null || $scope.editModel.DistrictID <= 0) {
                $scope.lookupData.Authorities = null;
                $scope.editModel.BPAServiceTypeID = null;
            }
        }

        $scope.getAuthorities = function () {
            if ($scope.editModel.DistrictID && $scope.editModel.LocationID != null && $scope.editModel.LocationID > 0) {

                let locations = $filter("filter")($scope.lookupData.Locations, { 'ID': $scope.editModel.LocationID })

                if (locations && locations.length > 0) {
                    $scope.editModel.FCLocation = locations[0].Code;
                    $scope.editModel.UserName = locations[0].UserName;
                    $scope.eKhidmatCenterAddress = locations[0].Name + " " + locations[0].Description;
                }

                $http.get(webAPIPath + 'api/Construction/GetAuthorities', {
                    params: {
                        'districtID': $scope.editModel.DistrictID,
                        'locationID': $scope.editModel.LocationID
                    }
                }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {
                        let resp = successResp.data;

                        if (resp.response_header.status == APIResponseType.SUCCESS) {
                            let respData = resp.response_detail;

                            $scope.lookupData.Authorities = respData.LookupData.Authorities;

                            if ($scope.lookupData.Authorities && $scope.lookupData.Locations.Authorities == 1) {
                                $scope.editModel.AuthorityID = $scope.lookupData.Authorities[0].ID;
                            }

                            $timeout(function () {
                                $('[data-ng-model="editModel.BPAServiceTypeID"]').focus();
                                $('select[selectpicker]').selectpicker('refresh');

                            }, 100);

                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {

                });
            }
        }

        $scope.getServicesByBPAService = function () {
            if ($scope.editModel.AuthorityID != null && $scope.editModel.AuthorityID > 0 && $scope.editModel.BPAServiceTypeID != null && $scope.editModel.BPAServiceTypeID > 0) {
                $http.get(webAPIPath + 'api/Construction/GetConstructionServices', {
                    params: {
                        'districtID': $scope.editModel.DistrictID,
                        'locationID': $scope.editModel.LocationID,
                        'bpaServiceTypeID': $scope.editModel.BPAServiceTypeID,
                        'authorityID': $scope.editModel.AuthorityID
                    }
                }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {

                        if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                            let respData = successResp.data.response_detail;

                            if (!respData.LookupData.Services) {
                                $scope.serviceNotAvailable = true;
                                $scope.lookupData.Services = [];
                                //toastr.info("On Selected location Services not provided.");
                            } else {
                                $scope.lookupData.Services = respData.LookupData.Services;
                                $scope.serviceNotAvailable = false;
                            }

                            $timeout(function () {
                                $('select[selectpicker]').selectpicker('refresh');
                            }, 100);

                            $scope.getAppAndServiceType();
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {

                });
            }
            else {
                $scope.lookupData.ServiceTypes = null;
                $scope.editModel.ServiceTypeID = null;
                $scope.lookupData.Services = null;
                $scope.editModel.ServiceID = null;
                $scope.lookupData.ApplicationTypes = null;
                $scope.editModel.ApplicationTypeID = null;

                $timeout(function () {
                    $('select[selectpicker]').selectpicker('refresh');
                }, 100);

                $scope.getAppAndServiceType();
            }
        }

        $scope.hideEkhidmatCenter = true;

        function showHideEkhidmatCenter() {
            $scope.hideEkhidmatCenter = true;

            if ($scope.lookupData.Locations && $scope.lookupData.Locations.length > 1) {
                $scope.hideEkhidmatCenter = false;
            }
        }

        $scope.hideServiceType = false;

        function showHideServiceType() {
            $scope.hideServiceType = false;

            if ($scope.lookupData.ServiceTypes && $scope.lookupData.ServiceTypes.length == 1) {
                if ($scope.lookupData.ServiceTypes[0].ID == 1) {
                    $scope.hideServiceType = true;
                }
            }
        }

        $scope.hideDeliveryTypes = false;

        function showHideDeliveryTypes() {
            $scope.hideDeliveryTypes = false;
            if ($scope.lookupData.DeliveryTypes && $scope.lookupData.DeliveryTypes.length == 1) {
                if ($scope.lookupData.DeliveryTypes[0].ID == 1) {
                    $scope.hideDeliveryTypes = true;
                }
            }
        }

        function getFilterApplicationTypes() {
            return $filter("filter")($scope.lookupData.ApplicationTypes,
                { DeliveryTypeID: $scope.editModel.DeliveryTypeID, ServiceTypeID: $scope.editModel.ServiceTypeID });
        }

        $scope.filterApplicationType = function () {
            showHideApplicationTypes();

            let currentApplicationTypes = getFilterApplicationTypes();
            if (currentApplicationTypes && currentApplicationTypes.length == 1) {
                $scope.editModel.ApplicationTypeID = currentApplicationTypes[0].ID;
            }
        }

        $scope.hideApplicationTypes = true;

        function showHideApplicationTypes() {
            $scope.hideApplicationTypes = true;

            let currentApplicationTypes = getFilterApplicationTypes();

            if (currentApplicationTypes) {
                if (currentApplicationTypes.length == 1) {
                    $scope.hideApplicationTypes = true;
                } else {
                    $scope.hideApplicationTypes = false;
                }
            }
        }

        function showHidePlotType() {
            if ($scope.editModel.ServiceID) {
                let listOfServiceIDForPlotType = [
                    74,
                    75,
                    76,
                    77,
                    84,
                    86,
                    94,
                    95,
                    96,
                    97,
                    98,
                    99,
                    100,
                    101,
                    102,
                    104,
                    105
                ];

                if (listOfServiceIDForPlotType.indexOf($scope.editModel.ServiceID) !== -1) {
                    $scope.hidePlotType = true;
                }
            }
        }

        $scope.getAppAndServiceType = function () {

            let selectedServices = $filter("filter")($scope.lookupData.Services, { 'ID': $scope.editModel.ServiceID })

            if (selectedServices && selectedServices.length > 0) {
                $scope.editModel.ServiceCode = selectedServices[0].Code;
            }
            else {
                $scope.lookupData.ServiceTypes = null;
                $scope.editModel.ServiceID = null;
                $scope.lookupData.ApplicationTypes = null;
                $scope.editModel.ApplicationTypeID = null;
                $scope.lookupData.DeliveryTypes = null;
                $scope.editModel.DeliveryTypeID = null;

                showHideServiceType();
                showHideDeliveryTypes();
                showHideApplicationTypes();

                $timeout(function () {
                    $('select[selectpicker]').selectpicker('refresh');
                }, 100);
            }

            if ($scope.editModel.ServiceID != null && $scope.editModel.ServiceID > 0 && $scope.editModel.LocationID != null && $scope.editModel.LocationID > 0) {
                $http.get(webAPIPath + 'api/Construction/GetServiceDeliveryTypesAndReqDocuments', {
                    params: {
                        'serviceID': $scope.editModel.ServiceID,
                        'locationID': $scope.editModel.LocationID
                    }
                }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {

                        if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                            let respData = successResp.data.response_detail;

                            $scope.lookupData.ServiceTypes = respData.LookupData.ServiceTypes;
                            showHideServiceType();

                            if ($scope.lookupData.ServiceTypes && $scope.lookupData.ServiceTypes.length == 1) {
                                $scope.editModel.ServiceTypeID = $scope.lookupData.ServiceTypes[0].ID;
                            }

                            $scope.lookupData.DeliveryTypes = respData.LookupData.DeliveryTypes;

                            showHideDeliveryTypes();
                            if ($scope.lookupData.DeliveryTypes && $scope.lookupData.DeliveryTypes.length == 1) {
                                $scope.editModel.DeliveryTypeID = $scope.lookupData.DeliveryTypes[0].ID;
                            }

                            $scope.lookupData.ApplicationTypes = respData.LookupData.ApplicationTypes;

                            let currentApplicationTypes = getFilterApplicationTypes();
                            if (currentApplicationTypes && currentApplicationTypes.length == 1) {
                                $scope.editModel.ApplicationTypeID = currentApplicationTypes[0].ID;
                            }

                            $scope.lookupData.RequiredDocuments = respData.LookupData.RequiredDocuments;

                            showHideApplicationTypes();

                            fixRequiredDocList();

                            $timeout(function () {
                                $('select[selectpicker]').selectpicker('refresh');
                            }, 100);
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {

                });
            }
        }

        function checkObjectionDocumentExists() {
            let result = false;
            if ($scope.Documents != null && $scope.Documents.length > 0) {
                let objectionDocs = $scope.Documents.filter(function (node) {
                    return node.IsApproved == 3;
                });

                if (objectionDocs && objectionDocs.length > 0) {
                    result = true;
                }
            }

            return result;
        }

        function checkRequiredDocumentListValid() {
            let valid = true;
            if ($scope.lookupData.RequiredDocuments != null && $scope.lookupData.RequiredDocuments.length > 0) {
                let mandatoryDocs = $scope.lookupData.RequiredDocuments.filter(function (node) {
                    return node.IsMandatory == true &&
                        node.ServiceTypeID == $scope.editModel.ServiceTypeID &&
                        node.RequiredAppTypeID == $scope.editModel.ApplicationTypeID;
                });

                if (mandatoryDocs) {
                    for (var reqDocCount = 0; reqDocCount < mandatoryDocs.length; reqDocCount++) {
                        let reqDocItem = mandatoryDocs[reqDocCount];

                        if (reqDocItem.isUploaded != true) {
                            toastr.info("Please attach mandatory document(s).");
                            valid = false;
                            break;
                        }
                    }
                }
            }

            return valid;
        }

        $scope.SaveInformation = function () {
            let saveRecordTxt = "Do you want to Save record?";

            if (!$("form").validationEngine('validate')) {
                return;
            }

            if ($scope.currentStep == 1) {

                if (!confirm(saveRecordTxt)) {
                    return;
                }

                // Step 1
                let jsonData = {
                    'ApplicantID': $scope.editModel.ApplicantID,
                    'StartTime': $scope.editModel.StartTime,
                    'EndTime': new Date(),
                    'DivisionID': $scope.editModel.DivisionID,
                    'DistrictID': $scope.editModel.DistrictID,
                    'LocationID': $scope.editModel.LocationID,
                    'FCLocation': $scope.editModel.FCLocation,
                    'UserName': $scope.editModel.UserName,
                    'AuthorityID': $scope.editModel.AuthorityID,
                    'BPAServiceTypeID': $scope.editModel.BPAServiceTypeID,
                    'ServiceID': $scope.editModel.ServiceID,
                    'ServiceCode': $scope.editModel.ServiceCode,
                    'ServiceTypeID': $scope.editModel.ServiceTypeID,
                    'DeliveryTypeID': $scope.editModel.DeliveryTypeID,
                    'ApplicationTypeID': $scope.editModel.ApplicationTypeID,
                    'ApplicantCNIC': $scope.editModel.ApplicantCNIC,
                    'ApplicantName': $scope.editModel.ApplicantName,
                    'GenderID': $scope.editModel.GenderID,
                    'ApplicantRelationOf': $scope.editModel.ApplicantRelationOf,
                    'FatherName': $scope.editModel.FatherName,
                    'FatherCNIC': $scope.editModel.FatherCNIC,
                    'ApplicantContactNo': $scope.editModel.ApplicantContactNo,
                    'RegisteredEmail': $scope.editModel.RegisteredEmail,
                    'CurrentAddress': $scope.editModel.CurrentAddress,
                    'CurrentCityID': $scope.editModel.CurrentCityID,
                    'CurrentDivisionID': $scope.editModel.CurrentDivisionID,
                    'CurrentDistrictID': $scope.editModel.CurrentDistrictID,
                    'PermanentAddress': $scope.editModel.PermanentAddress,
                    'PermanentCityID': $scope.editModel.PermanentCityID,
                    'PermanentDivisionID': $scope.editModel.PermanentDivisionID,
                    'PermanentDistrictID': $scope.editModel.PermanentDistrictID,
                    'PostalAddress': $scope.editModel.PostalAddress,
                    'DeliveryModeID': $scope.editModel.DeliveryModeID,
                    'CapturedImage': $scope.editModel.CapturedImage,
                    'OnlineApplicantCNIC': $scope.UserProfile.CNIC,
                };

                var frmData = new FormData();
                frmData.append("Data", JSON.stringify(jsonData));

                $http.post(webAPIPath + 'api/Construction/SaveGeneralInformation', frmData, {
                    headers: {
                        'Content-Type': undefined
                    }
                }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {

                        if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                            let respData = successResp.data.response_detail;

                            $scope.editModel.ApplicantID = respData.ApplicantID;
                            //$scope.editModel.TaskStatusID = respData.TaskStatusID;

                            if ($scope.editModel.ApplicantID) {
                                $scope.DisableComments = false;
                                toastr.success("General information has been saved Successfully. Your application id is '" + $scope.editModel.ApplicantID + "'");
                            } else {
                                toastr.success("General Information has been updated Successfully.");
                            }

                            $scope.currentStep = 2;
                            $scope.savedSteps[1] = true;
                            if ($scope.currentStep == 2) {
                                $timeout(function () {
                                    $('[data-ng-model="currentReqDocModel.RequiredDocumentID"]').focus();
                                }, 10);
                            }

                            showHidePlotType();

                            $timeout(function () {
                                $('select[selectpicker]').selectpicker('refresh');
                            }, 100);

                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {

                });
                //end Step 1
            }
            else if ($scope.currentStep == 2) {

                if (!checkRequiredDocumentListValid()) {
                    return;
                }


                if (checkObjectionDocumentExists() && $scope.UserProfile.UserType != 3) {
                    toastr.info("Please upload the objection documents again.");
                    return;
                }

                //let mandatoryDocs = [];
                //if ($scope.lookupData.RequiredDocuments != null && $scope.lookupData.RequiredDocuments.length > 0) {
                //    mandatoryDocs = $scope.lookupData.RequiredDocuments.filter(function (node) {
                //        return node.IsMandatory == true &&
                //            node.ServiceTypeID == $scope.editModel.ServiceTypeID &&
                //            node.RequiredAppTypeID == $scope.editModel.ApplicationTypeID;
                //    });
                //    if (mandatoryDocs.length > 0) {
                //        let userAddedMandatoryDocs = [];
                //        if ($scope.Documents) {
                //            angular.forEach(mandatoryDocs, function (mValue, mKey) {
                //                angular.forEach($scope.Documents, function (dvalue, dkey) {
                //                    if (mValue.ID == dvalue.DocumentID) {
                //                        userAddedMandatoryDocs.push(mValue.ID);
                //                        return;
                //                    }
                //                });
                //            });
                //        }
                //        if (userAddedMandatoryDocs.length !== mandatoryDocs.length) {
                //            $scope.currentStep = 2;
                //            toastr.info("Please attach mandatory document(s).");
                //            return;
                //        }
                //    }
                //}

                if ($scope.Documents != null && $scope.Documents.length > 0) {
                    toastr.success("Document(s) has been saved Successfully.");
                }

                $scope.currentStep = 3;
                if ($scope.currentStep == 3) {
                    $scope.savedSteps[2] = true;
                    $timeout(function () {
                        $('#OwnerInformation table tbody > tr:first td:first input[data-ng-model="item.Name"]').focus();
                    }, 10);

                }
            }
            else if ($scope.currentStep == 3) {

                if (!confirm(saveRecordTxt)) {
                    return;
                }

                if ($scope.editModel.OwnerInformationItems != null && $scope.editModel.OwnerInformationItems.length > 0) {

                    // Step 3
                    let jsonData = {
                        'ApplicantID': $scope.editModel.ApplicantID,
                        'UserName': $scope.editModel.UserName,
                        'OwnerInformationItems': $scope.editModel.OwnerInformationItems
                    };

                    var frmData = new FormData();
                    frmData.append("Data", JSON.stringify(jsonData));

                    $http.post(webAPIPath + 'api/Construction/SaveMultipleOwnerInformation', frmData, {
                        headers: {
                            'Content-Type': undefined
                        }
                    }).then(function (successResp) {
                        if (successResp.status == HTTPStatusCode.OK) {

                            if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                                let respData = successResp.data.response_detail;

                                $scope.editModel.OwnerInformationItems = respData.OwnerInformationItems;

                                $scope.editModel.ArchitectRegisNo = $scope.UserProfile.ArchitectRegisNo;

                                //if ($scope.editModel.OwnerInformationItems != null && $scope.editModel.OwnerInformationItems.length > 0) {
                                toastr.success("Owner(s) information has been updated Successfully.");
                                //}
                                $scope.currentStep = 4;
                                $scope.savedSteps[3] = true;
                                if ($scope.currentStep == 4) {
                                    $timeout(function () {
                                        $('[data-ng-model="editModel.SiteCoveredArea"]').focus();
                                    }, 10);
                                }

                            } else {
                                handleResponseError(successResp.data.response_header);
                            }
                        }
                    }, function (errorResp) {

                    });
                }
                //end Step 4
            }
            else if ($scope.currentStep == 4) {

                if (!confirm(saveRecordTxt)) {
                    return;
                }

                //if (parseFloat($scope.editModel.SiteCoveredArea).toFixed(2) > parseFloat($scope.editModel.SitePlotArea).toFixed(2)) {
                //    toastr.info("Site Covered Area must be less than Site Plot Area.");
                //    return;
                //}

                let jsonData = {
                    'ApplicantID': $scope.editModel.ApplicantID,
                    'UserName': $scope.editModel.UserName,
                    'SiteCoveredArea': $scope.editModel.SiteCoveredArea,
                    'SitePlotArea': $scope.editModel.SitePlotArea,
                    'SiteNatureID': $scope.editModel.SiteNatureID,
                    'SiteAddress': $scope.editModel.SiteAddress,
                    'KhasraNo': $scope.editModel.KhasraNo,
                    'KhewatNo': $scope.editModel.KhewatNo,
                    'KhatoniNo': $scope.editModel.KhatoniNo,
                    'Mouza': $scope.editModel.Mouza,
                    'Scheme': $scope.editModel.Scheme,
                    'Phase': $scope.editModel.Phase,
                    'Sector': $scope.editModel.Sector,
                    'Block': $scope.editModel.Block,
                    'StreetNo': $scope.editModel.StreetNo,
                    'PlotTypeID': $scope.editModel.PlotTypeID,
                    'ArchitectRegisNo': $scope.editModel.ArchitectRegisNo
                };

                var frmData = new FormData();
                frmData.append("Data", JSON.stringify(jsonData));

                $http.post(webAPIPath + 'api/Construction/SaveSiteInformation', frmData, {
                    headers: {
                        'Content-Type': undefined
                    }
                }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {

                        if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                            let respData = successResp.data.response_detail;

                            $scope.editModel.Remarks = 'Application Submitted, Please.'.toUpperCase();

                            toastr.success("Site information has been updated Successfully.");

                            $scope.currentStep = 5;
                            $scope.savedSteps[4] = true;
                            if ($scope.currentStep == 5) {
                                $timeout(function () {
                                    $('[data-ng-model="editModel.Remarks"]').focus();
                                }, 10);
                            }

                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {

                });
                //end Step 4
            }

        }

        let rejectedTxt = 'Rejected.'.toUpperCase();
        let approvedTxt = 'Approved.'.toUpperCase();

        $scope.ApprovedInformation = function () {
            let isFoundObjectionDocument = false;

            for (var reqDocCount = 0; reqDocCount < $scope.lookupData.RequiredDocuments.length; reqDocCount++) {
                let reqDocItem = $scope.lookupData.RequiredDocuments[reqDocCount];

                if (reqDocItem.IsApproved == 3) {
                    isFoundObjectionDocument = true;
                    break;
                }
            }

            if (isFoundObjectionDocument) {
                toastr.info("Application cannot be approved due to objection document.");
                return;
            }

            if ($scope.editModel.OnlineChallanCounter != null && $scope.editModel.OnlineChallanCounter.length > 0) {
                if ($scope.editModel.IsPSIDMandatory && ($scope.editModel.OnlineChallanCounter[0].PSID == undefined || $scope.editModel.OnlineChallanCounter[0].PSID == null || $scope.editModel.OnlineChallanCounter[0].PSID == '')) {
                    //toastr.info("Challan PSID not generated. Please save challan amount again to generate PSID");
                    //return;
                    if (!confirm("PSID is not generated due to system is not available right now. Do you want to proceed without PSID press “OK” Otherwise Cancel and generate challan again?")) {
                        return;
                    }
                }
            }

            let isFoundUnPaidChallan = false;

            for (var oncCount = 0; oncCount < $scope.editModel.OnlineChallanCounter.length; oncCount++) {
                let challan = $scope.editModel.OnlineChallanCounter[oncCount];

                if (challan.IsPaid == false) {
                    isFoundUnPaidChallan = true;
                    break;
                }
            }

            if (isFoundUnPaidChallan) {
                if ($.trim($scope.editModel.Remarks).length == 0) {
                    //toastr.info("Please enter comments.");
                    //return;
                    $scope.editModel.Remarks = 'Please pay challan fee, Thanks.'.toUpperCase();
                }

                $scope.markApplicationStatus($scope.editModel.ApplicantID, "5", $scope.editModel.Remarks);
                return;
            }

            if ($.trim($scope.editModel.Remarks).length == 0 || $scope.editModel.Remarks == rejectedTxt) {
                $scope.editModel.Remarks = approvedTxt;
                //toastr.info("Please Enter Comments / Remarks.");
            }

            $timeout(function () {
                //if (!$("form").validationEngine('validate')) {
                //    //toastr.info("Please Enter Reason for Acceptance.");
                //    return;
                //}

                if ($.trim($scope.editModel.Remarks).length == 0) {
                    toastr.info("Please Enter Comments / Remarks.");

                    if ($scope.currentStep != 5) {
                        $scope.currentStep = 5;
                    }
                    return;
                }

                if (!confirm("Do you want to Approve current application?")) {
                    return;
                }

                let locations = $filter("filter")($scope.lookupData.Locations, { 'ID': $scope.editModel.LocationID });

                if (!(locations && locations.length > 0)) {
                    return toastr("e-Khidmat Markaz not found, Please contact administrator.")
                }

                let jsonData = {
                    'applicantID': $scope.editModel.ApplicantID,
                    'taskStatusID': locations[0].TaskStatusID,
                    'UserName': $scope.editModel.UserName,
                    'Remarks': $scope.editModel.Remarks.toUpperCase()
                };

                var frmData = new FormData();
                frmData.append("Data", JSON.stringify(jsonData));

                $http.post(webAPIPath + 'api/Construction/ApproveApplication', frmData, {
                    headers: {
                        'Content-Type': undefined
                    }
                }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {

                        if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                            let respData = successResp.data.response_detail;
                            toastr.success("Record has been Approved Successfully.");

                            window.location.href = '/Layouts/ScrutinizerDashboard.aspx';
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }, function (errorResp) {

                });
            }, 100);

        }

        $scope.RejectDataByScrutinizer = function () {

            if ($.trim($scope.editModel.Remarks).length == 0 || $scope.editModel.Remarks == approvedTxt) {
                $scope.editModel.Remarks = rejectedTxt;
                //toastr.info("Please Enter Reason for Rejection.");
            }

            if ($scope.editModel.OnlineChallanCounter != null && $scope.editModel.OnlineChallanCounter.length > 0) {
                if ($scope.editModel.IsPSIDMandatory && ($scope.editModel.OnlineChallanCounter[0].PSID == undefined || $scope.editModel.OnlineChallanCounter[0].PSID == null || $scope.editModel.OnlineChallanCounter[0].PSID == '')) {
                    //toastr.info("Challan PSID not generated. Please save challan amount again to generate PSID");
                    //return;
                    if (!confirm("PSID is not generated due to system is not available right now. Do you want to proceed without PSID press “OK” Otherwise Cancel and generate challan again?")) {
                        return;
                    }
                }
            }

            $timeout(function () {
                //if (!$("form").validationEngine('validate')) {
                //    //toastr.info("Please Enter Reason for Acceptance.");
                //    return;
                //}

                if (!confirm("Do you want to Reject current application?")) {
                    return;
                }

                if ($.trim($scope.editModel.Remarks).length == 0) {
                    toastr.info("Please enter rejection reason.");

                    if ($scope.currentStep != 5) {
                        $scope.currentStep = 5;
                    }
                    return;
                }

                let jsonData = {
                    'ApplicantID': $scope.editModel.ApplicantID,
                    'UserName': $scope.editModel.UserName,
                    'Remarks': $scope.editModel.Remarks.toUpperCase(),
                    'ApplicantName': $scope.editModel.ApplicantName,
                    'ApplicantContactNo': $scope.editModel.ApplicantContactNo,
                    'RegisteredEmail': $scope.editModel.RegisteredEmail
                };

                var frmData = new FormData();
                frmData.append("Data", JSON.stringify(jsonData));

                $http.post(webAPIPath + 'api/Construction/RejectDataByScrutinizer', frmData, {
                    headers: {
                        'Content-Type': undefined
                    }
                })
                    .then(function (successResp) {
                        if (successResp.status == HTTPStatusCode.OK) {

                            if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                                let respData = successResp.data.response_detail;
                                toastr.success("Record has been Rejected Successfully.");
                                window.location.href = '/Layouts/ScrutinizerDashboard.aspx';
                            } else {
                                handleResponseError(successResp.data.response_header);
                            }
                        }
                    }, function (errorResp) {

                    });
            }, 100);
        }

        $scope.submitApplication = function () {

            let jsonData = {
                'ApplicantID': $scope.editModel.ApplicantID,
                'UserName': $scope.editModel.UserName,
                'Remarks': $scope.editModel.Remarks.toUpperCase(),
                'ApplicantName': $scope.editModel.ApplicantName,
                'ApplicantContactNo': $scope.editModel.ApplicantContactNo,
                'RegisteredEmail': $scope.editModel.RegisteredEmail
            };

            var frmData = new FormData();
            frmData.append("Data", JSON.stringify(jsonData));

            $http.post(webAPIPath + 'api/Construction/SubmitDataByCitizen', frmData, {
                headers: {
                    'Content-Type': undefined
                }
            }).then(function (successResp) {
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                        let respData = successResp.data.response_detail;
                        toastr.success("Record has been Submitted Successfully.");
                        window.location = '/Layouts/CitizenDashboard.aspx';
                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }, function (errorResp) {

            });
        };

        function isChallanPaid() {
            let challanPaid = true;
            if ($scope.editModel.OnlineChallanCounter) {
                for (var challanCount = 0; challanCount < $scope.editModel.OnlineChallanCounter.length; challanCount++) {
                    let challanItem = $scope.editModel.OnlineChallanCounter[challanCount];

                    if (challanItem.IsPaid == false) {
                        challanPaid = false;
                        break;
                    }
                }
            }

            return challanPaid;
        }

        $scope.SubmitDataByCitizen = function () {

            if (!$("form").validationEngine('validate')) {
                toastr.info("Please enter comments.");
                return;
            }

            if (!checkRequiredDocumentListValid()) {
                return;
            }

            if (checkObjectionDocumentExists() && $scope.UserProfile.UserType != 3) {
                toastr.info("Please upload the objection documents again.");
                return;
            }

            if (isChallanPaid() === false) {
                toastr.info("Please add paid challan in Document(s) list.");
                $scope.currentStep = 2;
                return;
            }

            if ($scope.editModel.OnlineChallanCounter != null && $scope.editModel.OnlineChallanCounter.length > 0) {
                if ($scope.editModel.IsPSIDMandatory && ($scope.editModel.OnlineChallanCounter[0].PSID == undefined || $scope.editModel.OnlineChallanCounter[0].PSID == null || $scope.editModel.OnlineChallanCounter[0].PSID != '')
                     && ($scope.editModel.OnlineChallanCounter[0].PSIDStatus == undefined || $scope.editModel.OnlineChallanCounter[0].PSIDStatus == null || $scope.editModel.OnlineChallanCounter[0].PSIDStatus.toUpperCase() != 'PAID')) {
                    //toastr.info("PSID status has not been updated against your challan. Please Submit form again.");
                    //return;
                    if (!confirm("Challan Payment will be updated soon. Do you want to proceed application for further process?")) {
                        return;
                    }
                }
            }

            if ($.trim($scope.editModel.Remarks).length == 0) {
                toastr.info("Please enter comments.");
                $scope.currentStep = 5;
                return;
            }

            if (!confirm("Do you want to Submit your record for Scrutinizing process?")) {
                return;
            }

            $('#discalmerModel').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });

        }

        $scope.SameAddr = function () {
            $scope.editModel.PermanentAddress = $scope.editModel.CurrentAddress;
            $scope.editModel.PermanentCityID = $scope.editModel.CurrentCityID;
            $scope.editModel.PermanentDivisionID = $scope.editModel.CurrentDivisionID;
            $scope.editModel.PermanentDistrictID = $scope.editModel.CurrentDistrictID;
        };

        $scope.addReqDoc = function (docObj) {
            if (docObj.Checked) {
                $scope.RequiredDocumentsList.push(docObj);
            } else {
                var index = $scope.RequiredDocumentsList.indexOf(docObj);
                $scope.RequiredDocumentsList.splice(index, 1);
            }
        };

        $scope.RemoveDocumentByRecordID = function (reqDocItem, index) {

            if (!confirm("Do you want to Remove this document?")) { return; }

            let jsonData = {
                'ApplicantID': $scope.editModel.ApplicantID,
                'UserName': $scope.editModel.UserName,
                'RecordID': reqDocItem.uploadedDocumentID
            };

            var model = JSON.stringify(jsonData);

            function successCallback(successResp) {
                if (successResp.status == HTTPStatusCode.OK) {
                    let resp = successResp.data;

                    if (resp.response_header.status == APIResponseType.SUCCESS) {
                        let respData = resp.response_detail;

                        if ($scope.Documents) {
                            for (var docItemCount = 0; docItemCount < $scope.Documents.length; docItemCount++) {
                                let docItem = $scope.Documents[docItemCount];
                                if (docItem.DocumentID == reqDocItem.ID) {

                                    $timeout(function () {
                                        $scope.Documents.splice(docItemCount, 1);

                                        if ($scope.Documents != null && $scope.Documents.length == 0) {
                                            $scope.DisabledServiceInputFields = false;
                                        }
                                    }, 1000);

                                    break;
                                }
                            }
                        }

                        if (reqDocItem.uploadedDocumentID > 0) {
                            reqDocItem.isUploaded = false;
                            reqDocItem.uploadedDocumentID = null;
                        }
                    } else {
                        handleResponseError(successResp.data.response_header);
                    }

                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.post(webAPIPath + 'api/Construction/DeleteDocumentByRecordID', model)
                .then(successCallback, errorCallback);
        }

        $scope.RemoveChallanByRecordID = function (challanItem, index) {

            if (!confirm("Do you want to Remove this document?")) { return; }

            let reqDocItem = challanItem.document;

            let jsonData = {
                'ApplicantID': $scope.editModel.ApplicantID,
                'UserName': $scope.editModel.UserName,
                'RecordID': reqDocItem.uploadedDocumentID,
                'IsChallanUpload': true
            };

            var model = JSON.stringify(jsonData);

            function successCallback(successResp) {
                if (successResp.status == HTTPStatusCode.OK) {
                    let resp = successResp.data;

                    if (resp.response_header.status == APIResponseType.SUCCESS) {
                        let respData = resp.response_detail;

                        if ($scope.Documents) {
                            for (var docItemCount = 0; docItemCount < $scope.Documents.length; docItemCount++) {
                                let docItem = $scope.Documents[docItemCount];
                                if (docItem.DocumentID == reqDocItem.ID) {

                                    $timeout(function () {
                                        $scope.Documents.splice(docItemCount, 1);

                                        if ($scope.Documents != null && $scope.Documents.length == 0) {
                                            $scope.DisabledServiceInputFields = false;
                                        }
                                    }, 1000);

                                    break;
                                }
                            }
                        }

                        if (reqDocItem.uploadedDocumentID > 0) {
                            reqDocItem.isUploaded = false;
                            reqDocItem.uploadedDocumentID = null;
                            challanItem.IsPaid = false;
                        }
                    } else {
                        handleResponseError(successResp.data.response_header);
                    }

                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.post(webAPIPath + 'api/Construction/DeleteDocumentByRecordID', model)
                .then(successCallback, errorCallback);
        }

        function activate() {
            getList();

            $(document).ready(function () {
                $("form").validationEngine({ promptPosition: "topRight:-95", scroll: false });

                if ($scope.currentStep == 1) {
                    $timeout(function () {
                        $('[data-ng-model="editModel.BPAServiceTypeID"]').focus();
                        $('select[selectpicker]').selectpicker('refresh');
                    }, 10);
                }

            });
        }

        /*start SufYan Panel */

        $scope.plotOwnerInfoAdd = function () {

            if (!$("form").validationEngine('validate')) {
                return;
            }

            if ($scope.editModel.OwnerInformationItems == null) {
                $scope.editModel.OwnerInformationItems = [];
            }
            var itemLength = $scope.editModel.OwnerInformationItems.length;

            if ($scope.editModel.OwnerInformationItems[itemLength - 1].Name == null) {
                toastr.info("Please enter Name.");
                return;
            }

            $scope.editModel.OwnerInformationItems.push(angular.copy(PlotOwnerInfo));

            if ($scope.currentStep == 3) {
                $timeout(function () {
                    $('#OwnerInformation table tbody > tr:first td:first input[data-ng-model="item.Name"]').focus();
                }, 10);
            }
        }

        $scope.plotOwnerInfoRemove = function (index) {

            let item = $scope.editModel.OwnerInformationItems[index];

            if (item != null && (item.ID != null && item.ID > 0)) {
                if (confirm("Do you want to Remove this Plot Owner Info record?")) {
                    let jsonData = {
                        'ApplicantID': $scope.editModel.ApplicantID,
                        'UserName': $scope.editModel.UserName,
                        'RecordID': item.ID
                    };

                    var model = JSON.stringify(jsonData);

                    function successCallback(successResp) {
                        if (successResp.status == HTTPStatusCode.OK) {
                            let resp = successResp.data;

                            if (resp.response_header.status == APIResponseType.SUCCESS) {
                                let respData = resp.response_detail;
                                //if ($scope.editModel.OwnerInformationItems.length > 0) {
                                //    $scope.editModel.OwnerInformationItems.splice(index, 1);
                                //}
                            } else {
                                handleResponseError(successResp.data.response_header);
                            }
                        }
                    }

                    function errorCallback(response) {
                        console.log(response);
                    }

                    $http.post(webAPIPath + 'api/Construction/DeleteOwnerByRecordID', model)
                        .then(successCallback, errorCallback);
                }
            }

            $scope.editModel.OwnerInformationItems.splice(index, 1);
            if ($scope.editModel.OwnerInformationItems.length == 0) {
                $scope.editModel.OwnerInformationItems.push(angular.copy(PlotOwnerInfo));
            }
        }
        /*end SufYan Panel */

        $scope.currentStep = 1;

        $scope.cancelClick = function () {

            if ($scope.UserProfile.UserType == 3) {
                if (confirm('Do you want to Redirect to Dashboard?')) {
                    window.location.href = '/Layouts/ScrutinizerDashboard';
                }
            } else {
                if (confirm('Are you sure, you want to Cancel?')) {
                    window.location.href = '/Layouts/CitizenDashboard';
                }
            }
        }

        $scope.openChallanModal = function () {
            if ($scope.lookupData.OnlineChallanList.length > 0) {
                $('#ChallanAmount').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });
            }
            else {
                toastr.success("Challan generation configuration is not defined.");
            }
        }

        $scope.clearChallan = function () {
            if (confirm('Are you sure you want to clear amount(s)?')) {
                if ($scope.lookupData.OnlineChallanList) {
                    let challans = $scope.lookupData.OnlineChallanList;
                    for (var cCount = 0; cCount < challans.length; cCount++) {
                        let challan = challans[cCount];
                        challan.Amount = 0;
                    }
                }
            }
        }

        $scope.saveChallan = function () {
            if (!$("form").validationEngine('validate')) {
                toastr.info("Please enter valid value.");
                return;
            }
            let status = false;
            angular.forEach($scope.lookupData.OnlineChallanList, function (value, key) {
                if (value.Amount > 0) {
                    status = true;
                }
            });
            if (!status) {
                toastr.info("Please enter valid amount.");
                return;
            }
            // get account number against selected head ID
            let accountHead = $scope.AccountHeadList.filter(obj => {
                return obj.ID == $scope.editModel.HeadID
            });
            angular.forEach($scope.lookupData.OnlineChallanList, function (value, key) {
                value.TypeID = $scope.editModel.TypeID;
                value.HeadID = $scope.editModel.HeadID;
                value.AccountNumber = accountHead[0].AccountNumber;
            });

            $scope.saveModel = {
                'ApplicantID': $scope.editModel.ApplicantID,
                'OnlineChallanList': $scope.lookupData.OnlineChallanList
            }

            function successCallback(response) {

                if (response.status == HTTPStatusCode.OK) {
                    if (response.data.response_header.status == APIResponseType.SUCCESS) {
                        toastr.success("Challan amount configured successfully.");

                        $scope.editModel.OnlineChallanCounter = response.data.response_detail.OnlineChallanCounter;
                        $scope.lookupData.OnlineChallanList = response.data.response_detail.OnlineChallanList;
                        //$scope.showApprovedFeeButton();

                        fixRequiredDocList();

                        $('#ChallanAmount').modal('hide');

                        $scope.disableScApprovedBtn = false;

                        if ($scope.editModel.IsPSIDMandatory) {
                            $scope.GenerateEPayPSID();

                        }
                    }
                    else {
                        handleResponseError(response.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            var path = webAPIPath + 'api/Construction/SaveConstructionChallan';

            return $http({
                method: 'post',
                url: path,
                data: $scope.saveModel
            }).then(successCallback, errorCallback);
        }

        $scope.GenerateEPayPSID = function () {
            //toastr.success("PSID Configured.");
            $http.get(webAPIPath + 'api/CFSCEPayment/CFSCGenerateEPayPSID',
                {
                    params: {
                        'ApplicantID': $scope.editModel.ApplicantID,
                    }
                })
                .then(function (resp) {
                    if (resp.status == HTTPStatusCode.OK) {
                        if (resp.data.response_header.status == APIResponseType.SUCCESS) {
                            if (resp.data.response_detail.content[0].consumerNumber != null) {
                                $scope.editModel.OnlineChallanCounter[0].PSID = resp.data.response_detail.content[0].consumerNumber;
                                toastr.success("PSID has been generated successfully. Now, you can further proceed. Your PSID = " + $scope.editModel.OnlineChallanCounter[0].PSID);
                            }
                            else {
                                toastr.error("PSID has not been generated. Kindly Save Challan Form again.");
                            }
                        }
                        else {
                            toastr.error("PSID has not been generated. Kindly Save Challan Form again.");
                            //handleResponseError(resp.data.response_header);
                        }
                    }
                }, function (errResp) {

                });
        }

        $scope.cancelChallan = function () {
            $('#ChallanAmount').modal('hide');
        }

        $scope.citizenChallanDetail = {
            "BankName": null,
            "BranchTitle": null,
            "BranchCode": null,
            "HeadOfAccount": null,
            "AccountNumber": null,
            "AccountTitle": null,
            "OnlineChallanList": []
        };


        $scope.showChallanForm = function () {
            $http.get(webAPIPath + 'api/Construction/GetChallanDataByApplicantID',
                {
                    params: {
                        'ApplicantID': $scope.editModel.ApplicantID,
                    }
                })
                .then(function (resp) {
                    if (resp.status == HTTPStatusCode.OK) {
                        if (resp.data.response_header.status == APIResponseType.SUCCESS) {
                            $scope.citizenChallanDetail = resp.data.response_detail;

                            let sumAmount = 0;
                            if ($scope.citizenChallanDetail && $scope.citizenChallanDetail.OnlineChallanList) {

                                let challanAmountList = $scope.citizenChallanDetail.OnlineChallanList;
                                for (let challanAmountCount = 0; challanAmountCount < challanAmountList.length; challanAmountCount++) {
                                    let amoItem = challanAmountList[challanAmountCount];

                                    sumAmount += amoItem.Amount;
                                }
                            }

                            $scope.citizenChallanDetail.SumAmount = sumAmount;

                            let translator = new T2W("EN_US");
                            // one thousand two hundred thirty-four
                            $scope.citizenChallanDetail.SumAmountEng = translator.toWords($scope.citizenChallanDetail.SumAmount);

                            let scrutinizerNames = $scope.citizenChallanDetail.OnlineChallanList[0];
                            $scope.citizenChallanDetail.SEmployeeName = scrutinizerNames.EmployeeName;
                            $scope.citizenChallanDetail.SDesignation = scrutinizerNames.Designation;

                            $('#challangenrate').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });
                        }
                        else {
                            handleResponseError(resp.data.response_header);
                        }
                    }
                }, function (errResp) {

                });
        }

        $scope.documentObjectionReason = '';

        $scope.showObjectionComments = function (reqDocItem) {
            $('#previousRemarksModel').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });
        }

        $scope.addDocumentObjectionReason = function () {
            if ($.trim($scope.documentObjectionReason).length == 0) {
                toastr.info('Please add reason.');
                return;
            }
            if ($.trim($scope.editModel.Remarks).length > 0) {
                $scope.editModel.Remarks += "\n" + $scope.documentObjectionReason.toUpperCase();
            } else {
                $scope.editModel.Remarks = $scope.documentObjectionReason.toUpperCase();
            }

            $('#objectionDocTxtModel').modal('hide');
        }

        activate();
    }
})();
