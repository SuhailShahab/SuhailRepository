﻿(function () {
    'use strict';

    let app = angular
        .module('fcportal');

    let reqModule = ['ng-bootstrap-select', 'angularUtils.directives.dirPagination'];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });

    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', function ($q) {
            return {
                'request': function (config) {
                    let accessToken = localStorage.getItem("AccessToken");
                    if (accessToken) {
                        config.headers['Authorization'] = 'Bearer ' + accessToken;
                    }
                    return config || $q.when(config);
                },
                'response': function (response) {
                    if (response.status === 401) {

                    }

                    return response || $q.when(response);
                },
                'responseError': function (rejection) {
                    if (rejection.status === 401) {

                    }

                    return $q.reject(rejection);
                }
            }
        }]);
    }]);

    app.controller('citizenDashboardCtrl', citizenDashboard);

    citizenDashboard.$inject = ['$scope', '$http'];


    function citizenDashboard($scope, $http) {

        let accessToken = localStorage.getItem("AccessToken");
        if (!accessToken) {
            window.location = '/Login';
        }

        let webAPIPath = getWebAPIPath();

        let countModel = {
            TotalInProgress: null,
            TotalApplied: null,
            TotalUnderScrutiny: null,
            TotalApproved: null,
            TotalRejected: null
        };

        let applicantModel = {
            SrNo: null,
            ServiceName: '',
            ApplicantID: '',
            ApplicantName: '',
            ApplicantContactNo: '',
            ApplicantCNIC: '',
            RegistrationDate: '',
            SiteInformation: '',
            Status: '',
            TaskStatusID: null
        };

        let searchCriteriaModel = {
            TaskStatusID: 1,
            ServiceTypeID: null,
            ServiceID: null,
            StartDate: null,
            EndDate: null,
            PageNo: 1,
            PageSize: 10,
        };

        $scope.dateOptions = {
            dateFormat: 'dd-mm-yy',
            showAnim: "slide",
            showOn: "both",
            buttonImage: "/images/calendar_25.gif",
            buttonImageOnly: true
        };

        $scope.StartDate = null; //new Date();
        $scope.EndDate = null; //new Date();

        $scope.dashboardCounts = angular.copy(countModel);
        $scope.applicantList = [];
        $scope.servicesList = [];
        $scope.servicesTypeList = [];
        $scope.totalRecords = 0;
        $scope.searchModel = angular.copy(searchCriteriaModel);
        $scope.UserProfile = userProfile;

        $scope.pageChanged = function (newPage) {
            //$scope.searchModel.PageNo = newPage;
            $scope.getRecord($scope.searchModel.TaskStatusID, null);
        };


        function GetFormattedDate(date) {
            var todayTime = date;
            var month = format(todayTime.getMonth() + 1);
            var day = format(todayTime.getDate());
            var year = format(todayTime.getFullYear());
            return month + "/" + day + "/" + year;
        }

        //$scope.TaskStatusID = 2;
        $scope.getRecord = function (taskStatusID, evt) {

            if ($scope.searchModel.TaskStatusID != taskStatusID) {
                $scope.searchModel.ServiceTypeID = null;
                $scope.searchModel.ServiceID = null;
                $scope.StartDate = null;
                $scope.EndDate = null;
                $scope.searchModel.TaskStatusID = taskStatusID;

                if ($scope.searchModel.PageNo > 1) {
                    $scope.searchModel.PageNo = 1;
                    return;
                }
            }

            $scope.searchModel.StartDate = null;
            $scope.searchModel.EndDate = null;

            if ($scope.StartDate != null) {
                $scope.searchModel.StartDate = toCurrentDate($scope.StartDate);
            }

            if ($scope.EndDate != null) {
                $scope.searchModel.EndDate = toCurrentDate($scope.EndDate);
            }

            function successCallback(response) {

                if (response.status == HTTPStatusCode.OK) {
                    if (response.data.response_header.status == APIResponseType.SUCCESS) {
                        $scope.dashboardCounts = response.data.response_detail.Counts;
                        $scope.applicantList = response.data.response_detail.colApplications;
                        $scope.servicesTypeList = response.data.response_detail.ServiceTypes;
                        $scope.totalRecords = response.data.response_detail.TotalRecords;
                    }
                    else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }


            var path = webAPIPath + 'api/CitizenDashboard/GetRecords';

            return $http({
                method: 'post',
                url: path,
                data: $scope.searchModel
            }).then(function (success) {
                if (success) {
                    successCallback(success);
                }
            }, function (error) {
                errorCallback(error);

            });
        }



        $scope.resetFilter = function () {
            $scope.searchModel.ServiceTypeID = null;
            $scope.searchModel.ServiceID = null;
            $scope.StartDate = null;
            $scope.EndDate = null;
            $scope.searchModel.PageNo = 1;
            $scope.servicesList = [];
            $scope.getRecord($scope.searchModel.TaskStatusID);
        }

        $scope.edit = function (record) {
            window.location.href = record.URL;
        }

        $scope.previewRecord = function (record) {
            let url = "";
            if (record.URL.split('?').length > 1)
                url = "ConstructionServicesPreview.aspx?" + record.URL.split('?')[1];

            if (url != "")
                window.location.href = url;
            else {
                //Show Error Message Here...
            }
        }
        //CR:005
        $scope.updateApplicationStatus = function () {
          
                function successCallback(response) {

                    if (response.status == HTTPStatusCode.OK) {
                        if (response.data.response_header.status == APIResponseType.SUCCESS) {
                            //$scope.getRecord($scope.searchModel.TaskStatusID);
                            //toastr.success("Record Deleted Successfully.");
                        }
                        else {
                            //handleResponseError(successResp.data.response_header);
                        }
                    }
                }

                function errorCallback(response) {
                    console.log(response);
                }

                $http.get(webAPIPath + 'api/CitizenDashboard/UpdateApplicationStatus').then(successCallback, errorCallback);
           
        }

        $scope.delete = function (record) {
            if (confirm('Are you sure you want to delete this record?')) {
                function successCallback(response) {

                    if (response.status == HTTPStatusCode.OK) {
                        if (response.data.response_header.status == APIResponseType.SUCCESS) {
                            $scope.getRecord($scope.searchModel.TaskStatusID);
                            toastr.success("Record Deleted Successfully.");
                        }
                        else {
                            handleResponseError(successResp.data.response_header);
                        }
                    }
                }

                function errorCallback(response) {
                    console.log(response);
                }

                $http.post(webAPIPath + 'api/CitizenDashboard/DeleteApplication?ApplicationID=' + record.ApplicantID, {
                }, {
                    withCredentials: true,
                    headers: {
                        'Content-Type': undefined,
                        'Authorization': 'Bearer ' + window.getAccessToken()
                    },
                }).then(successCallback, errorCallback);
            }
        }

        $scope.printBarcode = function (record) {
            var url = "PrintQRCode.aspx";
            //var windowWidthOption = $(window).width()  / 2;
            //var windowHeightOption = ($(window).height() / 4) + $(window).height();
            //var leftOption = (($(window).width() - windowWidthOption) / 2);
            //var topOption = ($(window).height() - windowHeightOption) / 2);

            var windowWidthOption = $(window).width() / 2.5;
            var windowHeightOption = $(window).height() * (1 / 1);
            var leftOption = (($(window).width() - windowWidthOption) / 2);
            var topOption = (($(window).height() - windowHeightOption) / 2);

            var barCodeData = JSON.stringify({
                'ApplicantID': record.ApplicantID,
                'ApplicantCNIC': record.ApplicantCNIC = null ? '' : record.ApplicantCNIC,
                //'RegistrationDate': new moment(record.RegistrationDate).format('DD/MM/YYYY hh:mm A'),
                //'Division':record.DivisionTitle,
                //'District':record.DistrictTitle,
                'Address': record.CurrentAddress
            });

            var winOption = window.open(url + '?serviceName=' + record.ServiceName + '&ServiceCode=' + record.ServiceCode + '&ApplicantID=' + record.ApplicantID, '_blank', 'fullscreen=no,toolbar=no,location=no,addressbar=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=' + windowWidthOption + ',height=' + windowHeightOption + ',left=' + leftOption + ',top=' + topOption);
            //var winOption = window.open(url, '_blank', 'fullscreen=no,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,width=' + windowWidthOption + ',height=' + windowHeightOption + ',left=' + leftOption + ',top=' + topOption);

            if (winOption) {
                winOption.focus();
            }

            return;
        }

        $scope.getServicesByBPAService = function () {
            $scope.servicesList = [];
            $http.get(webAPIPath + 'api/Construction/GetServicesByServiceType', {
                params: {
                    'districtID': '',
                    'locationID': '',
                    'bpaServiceTypeID': $scope.searchModel.ServiceTypeID,
                    'authorityID': ''
                }
            }).then(function (successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                        let respData = successResp.data.response_detail;

                        $scope.servicesList = respData.LookupData.Services;

                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }, function (errorResp) {

            });
        }

        $scope.currentDate = new Date();

        $scope.citizenChallanDetail = {
            "BankName": null,
            "BranchTitle": null,
            "BranchCode": null,
            "HeadOfAccount": null,
            "AccountNumber": null,
            "AccountTitle": null,
            "OnlineChallanList": []
        };

        $scope.showChallanForm = function (rowItem) {
            $http.get(webAPIPath + 'api/Construction/GetChallanDataByApplicantID',
                {
                    params: {
                        'ApplicantID': rowItem.ApplicantID,
                    }
                })
                .then(function (resp) {
                    if (resp.status == HTTPStatusCode.OK) {
                        if (resp.data.response_header.status == APIResponseType.SUCCESS) {
                            $scope.citizenChallanDetail = resp.data.response_detail;

                            let sumAmount = 0;
                            if ($scope.citizenChallanDetail && $scope.citizenChallanDetail.OnlineChallanList) {

                                let challanAmountList = $scope.citizenChallanDetail.OnlineChallanList;
                                for (let challanAmountCount = 0; challanAmountCount < challanAmountList.length; challanAmountCount++) {
                                    let amoItem = challanAmountList[challanAmountCount];

                                    sumAmount += amoItem.Amount;
                                }
                            }

                            $scope.citizenChallanDetail.SumAmount = sumAmount;

                            let translator = new T2W("EN_US");
                            // one thousand two hundred thirty-four
                            $scope.citizenChallanDetail.SumAmountEng = translator.toWords($scope.citizenChallanDetail.SumAmount);

                            let scrutinizerNames = $scope.citizenChallanDetail.OnlineChallanList[0];
                            $scope.citizenChallanDetail.SEmployeeName = scrutinizerNames.EmployeeName;
                            $scope.citizenChallanDetail.SDesignation = scrutinizerNames.Designation;

                            $('#challangenrate').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });
                        }
                        else {
                            handleResponseError(resp.data.response_header);
                        }
                    }
                }, function (errResp) {

                });
        }

        $scope.getRecord(1);    //get applied 

        $scope.getUserRemarks = function (appItem) {
            let txtRemarks = '-';
            if ([3, 4].indexOf(appItem.TaskStatusID) != -1) {
                txtRemarks = '<b>' + appItem.Status + '</b><br/><br/>' + appItem.Remarks
            } else {
                txtRemarks = appItem.Remarks || '-';
            }

            return txtRemarks;
        }
    }
})();
