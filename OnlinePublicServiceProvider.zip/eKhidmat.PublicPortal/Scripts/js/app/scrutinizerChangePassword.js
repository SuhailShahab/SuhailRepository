﻿(function () {
    'use strict';

    let app = angular
        .module('fcportal');

    let reqModule = ['ng-bootstrap-select', 'ui.mask', ];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });

    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', function ($q) {
            return {
                'request': function (config) {
                    let accessToken = localStorage.getItem("AccessToken");
                    if (accessToken) {
                        config.headers['Authorization'] = 'Bearer ' + accessToken;
                    }
                    return config || $q.when(config);
                },
                'response': function (response) {
                    if (response.status === 401) {

                    }

                    return response || $q.when(response);
                },
                'responseError': function (rejection) {
                    if (rejection.status === 401) {

                    }

                    return $q.reject(rejection);
                }
            }
        }]);
    }]);

    app.controller('changePasswordCtrl', changePassword);

    changePassword.$inject = ['$scope', '$http'];

    function changePassword($scope, $http) {
        $scope.title = 'changePassword';
        let webAPIPath = getWebAPIPath();
        let changePasswordModel = {
            UserName: userProfile.UserName,
            Password: null,
            NewPassword: null,
            ConfirmPassword:null
        };       

        $scope.editModel = angular.copy(changePasswordModel);
 
        $scope.updatePassword = function () {
            if (!$("form").validationEngine('validate')) {
                return false;
            }

            if ($scope.editModel.Password == null || $scope.editModel.Password.length == 0)
            {
                toastr.info('Please enter new password.');
                return false;
            }

            if ($scope.editModel.Password == null || $scope.editModel.Password.length == 0) {
                toastr.info('Please enter old password.');
                return false;
            }

            if ($scope.editModel.ConfirmPassword == null || $scope.editModel.ConfirmPassword.length == 0) {
                toastr.info('Please enter confirmed password.');
                return false;
            }

            if ($scope.editModel.NewPassword != null || $scope.editModel.NewPassword.length > 0) {
                if ($scope.editModel.NewPassword.length < 6 || $scope.editModel.NewPassword.length > 30) {
                    toastr.info('Password length is between 6 and 30');
                    return false;
                }
            }

            if ($scope.editModel.ConfirmPassword != null || $scope.editModel.ConfirmPassword.length > 0) {
                if ($scope.editModel.ConfirmPassword.length < 6 || $scope.editModel.ConfirmPassword.length > 30) {
                    toastr.info('Confirm Password length is between 6 and 30');
                    return false;
                }
            }

            if ($scope.editModel.NewPassword !== $scope.editModel.ConfirmPassword) {
                toastr.info('Password not match.');
                return false;
            }

            function successCallback(successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                        let respData = successResp.data.response_detail;

                        //$('input[name$="WebAPIPath"]').val(respData.AccessToken);
                        //__doPostBack('lnkRegister', '');

                        $scope.editModel.NewPassword = null;
                        $scope.editModel.ConfirmPassword = null;
                        $scope.editModel.Password = null;
                        $scope.editModel.UserName = null;

                        toastr.info(successResp.data.response_header.message);
                        setTimeout(function () { gotoDefaultpage(); }, 3000);
                        

                    } else {
                        if (successResp.data.response_header.code == 446) {
                            toastr.info(successResp.data.response_header.message);
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }


                    }
                } else {
                    toastr.info(successResp.data.response_header.message);
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.post(webAPIPath + 'api/Portal/GenericChangePassword', $scope.editModel).then(successCallback, errorCallback);

            return false;
        }

        

        activate();

        function activate() {
            //getList();

            $(document).ready(function () {
                $("form").validationEngine();

                $(document).on('click', '.toggle-password', function () {
                    $(this).find('span').toggleClass("fa-eye fa-eye-slash");
                    var input = $($(this).attr("toggle"));
                    if (input.attr("type") == "password") {
                        input.attr("type", "text");
                    } else {
                        input.attr("type", "password");
                    }
                });
                
            });

        }
    }
})();
