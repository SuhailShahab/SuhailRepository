﻿(function () {
    'use strict';

    let app = angular
        .module('fcportal');

    let reqModule = ['monospaced.qrcode'];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });
    
    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', function ($q) {
            return {
                'request': function (config) {
                    let accessToken = localStorage.getItem("AccessToken");
                    if (accessToken) {
                        config.headers['Authorization'] = 'Bearer ' + accessToken;
                    }
                    return config || $q.when(config);
                },
                'response': function (response) {
                    if (response.status === 401) {

                    }

                    return response || $q.when(response);
                },
                'responseError': function (rejection) {
                    if (rejection.status === 401) {

                    }

                    return $q.reject(rejection);
                }
            }
        }]);
    }]);

    app.controller('printQRCodeCtrl', printQRCodeCtrl);

    printQRCodeCtrl.$inject = ['$scope', '$http', '$timeout', '$filter', '$location'];

    function printQRCodeCtrl($scope, $http, $timeout, $filter, $location) {

        let accessToken = localStorage.getItem("AccessToken");
        if (!accessToken) {
            window.location = '/Login';
        }


        let webAPIPath = getWebAPIPath();

        $scope.title = 'Print QR Code';
        
        $scope.options = {
            timepicker: false,
            angularFormat: "dd/MM/yyyy",
        };

        $scope.date = new Date();
        $scope.endDate = new Date();

       
        //let queryParams = $location.search();

        let queryParams = [];
        function readQueryString(key) {
            let PageURL = decodeURI(window.location.search.substring(1));
            let sURLVariables = PageURL.split('&');

            for (let i = 0; i < sURLVariables.length; i++) {
                let sParameterName = sURLVariables[i].split('=');

                if ($.trim(sParameterName[0]).length > 0 && sParameterName[1]) {
                    queryParams[sParameterName[0]] = sParameterName[1];
                }
            }
        };

        readQueryString();

        function getList() {

            function successCallback(successResp) {
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                        let respData = successResp.data.response_detail;

                        let record = respData.Model;

                        var barCodeData = JSON.stringify({
                            'ApplicantID': record.ApplicantID,
                            'ApplicantCNIC': record.ApplicantCNIC = null ? '' : record.ApplicantCNIC,
                            //'RegistrationDate': new moment(record.RegistrationDate).format('DD/MM/YYYY hh:mm A'),
                            //'Division':record.DivisionTitle,
                            //'District':record.DistrictTitle,
                            'Address': record.CurrentAddress
                        });

                        $scope.barCodeJsonData = angular.fromJson(barCodeData);
                        $scope.barCodeData = barCodeData;
                        $scope.serviceName = record.ServiceName;
                        $scope.recordDate = (new moment(record.RegistrationDate).format('DD/MM/YYYY hh:mm a'));

                        //$scope.callPrintQR();

                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }


            let serviceCode = queryParams['ServiceCode'] ? queryParams['ServiceCode'] : null;

            $http.get(webAPIPath + 'api/Construction/GetRecordByID', { params: { 'ID': currentApplicantID, 'serviceCode': serviceCode } }).then(successCallback, errorCallback);
        }


        let currentApplicantID = queryParams['ApplicantID'] ? queryParams['ApplicantID'] : '';

        function activate() {
            getList();
        }

        $scope.callPrintQR = function (data) {
            setTimeout(function () { window.print(); }, 1000);
        }

        $scope.generateQRData = function (data) {
            return $scope.barCodeData;
        }

        activate();
    }
})();
