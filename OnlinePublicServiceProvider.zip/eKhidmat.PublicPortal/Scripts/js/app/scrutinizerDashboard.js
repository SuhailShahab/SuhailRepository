﻿(function () {
    'use strict';

    let app = angular
        .module('fcportal');

    let reqModule = ['angularUtils.directives.dirPagination'];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });

    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', function ($q) {
            return {
                'request': function (config) {
                    let accessToken = localStorage.getItem("AccessToken");
                    if (accessToken) {
                        config.headers['Authorization'] = 'Bearer ' + accessToken;
                    }
                    return config || $q.when(config);
                },
                'response': function (response) {
                    if (response.status === 401) {

                    }

                    return response || $q.when(response);
                },
                'responseError': function (rejection) {
                    if (rejection.status === 401) {

                    }

                    return $q.reject(rejection);
                }
            }
        }]);
    }]);

    app.controller('scrutinizerDashboardCtrl', dasboard);

    dasboard.$inject = ['$scope', '$http'];

    function dasboard($scope, $http) {

        let webAPIPath = getWebAPIPath();
        let countModel = {
            TotalInbox: 0,
            TotalApproved: 0,
            TotalRejected: 0
        };

        let applicantModel = {
            SrNo: null,
            ServiceName: '',
            ApplicantID: '',
            ApplicantName: '',
            ApplicantContactNo: '',
            ApplicantCNIC: '',
            AppliedBy: '',
            RegistrationDate: '',
            SiteInformation: '',
            Status: ''
        };

        let searchCritariaModel = {
            LocationID: null,
            TaskStatusID: null,
            ServiceID: null,
            StartDate: null,
            EndDate: null,
            PageNo: null,
            PageSize: null,
            ServiceTypeID: null,
            SearchTerm: null
        };


        $scope.dashboardCounts = angular.copy(countModel);
        $scope.applicantList = [];
        $scope.servicesList = [];
        $scope.servicesTypeList = [];
        $scope.searchModel = angular.copy(searchCritariaModel);
        $scope.searchModel.PageNo = 1;
        $scope.searchModel.PageSize = 10;
        $scope.totalRecords = 0;
        $scope.UserProfile = userProfile;
        $scope.userLocations = [];
        

        $scope.dateOptions = {
            dateFormat: 'dd-mm-yy',
            showAnim: "slide",
            showOn: "both",
            buttonImage: "/images/calendar_25.gif",
            buttonImageOnly: true
        };

        $scope.StartDate = null;
        $scope.EndDate = null;
        $scope.currentDate = new Date();

        $scope.getList = function (taskStatusID, item) {

            if (item != null) {
                $('.scrutinizer-dashboard-box').removeClass('active');
                item.currentTarget.attributes['class'].value = item.currentTarget.attributes['class'].value + ' active';
            }

            if (taskStatusID != null)
                $scope.searchModel.TaskStatusID = taskStatusID;

            if ($scope.StartDate != null) {
                $scope.searchModel.StartDate = toCurrentDate($scope.StartDate);
            }

            if ($scope.EndDate != null) {
                $scope.searchModel.EndDate = toCurrentDate($scope.EndDate);
            }         

            function successCallback(response) {

                if (response.status == HTTPStatusCode.OK) {
                    if (response.data.response_header.status == APIResponseType.SUCCESS) {
                        $scope.dashboardCounts = response.data.response_detail.Counts;
                        $scope.applicantList = response.data.response_detail.colApplications;
                        $scope.servicesTypeList = response.data.response_detail.ServiceTypes;
                        $scope.totalRecords = response.data.response_detail.TotalRecords;
                        $scope.userLocations = response.data.response_detail.colUserLocations;
                    }
                    else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            var path = webAPIPath + 'api/ScrutinizerDashboard/GetRecords';

            return $http({
                method: 'post',
                url: path,
                data: $scope.searchModel
            }).then(function (success) {
                if (success) {
                    successCallback(success);
                }

            }, function (error) {
                errorCallback(error);

            });

        }

        $scope.getCards = function (taskStatusID, item) {
            
            $scope.pagination.current = 1;
            $scope.searchModel.PageNo = 1;

            $scope.getList(taskStatusID, item);
        }

        $scope.resetFilter = function () {
            $scope.searchModel.ServiceTypeID = null;
            $scope.searchModel.ServiceID = null;
            $scope.StartDate = null;
            $scope.EndDate = null;
            $scope.searchModel.PageNo = 1;
            $scope.servicesList = [];
            $scope.getList();
        }

        $scope.getServicesByBPAService = function () {
            $scope.servicesList = [];
            $http.get(webAPIPath + 'api/Construction/GetConstructionServicesBySVCandUserID', {
                params: {
                    'districtID': '',
                    'locationID': '',
                    'bpaServiceTypeID': $scope.searchModel.ServiceTypeID,
                    'authorityID': '',
                    'UserID': $scope.UserProfile.UserID
                }
            }).then(function (successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                        let respData = successResp.data.response_detail;

                        $scope.servicesList = respData.LookupData.Services;

                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }, function (errorResp) {

            });
        }

        $scope.getApplicantDetail = function (applicantID, serviceCode) {

            window.location = "ConstructionServicesApplication.aspx?ApplicantID=" + applicantID + "&ServiceCode=" + serviceCode;
        }

        $scope.pagination = {
            current: 1
        };

        $scope.pageChanged = function (newPage) {
            $scope.searchModel.PageNo = newPage;
            $scope.getList($scope.searchModel.TaskStatusID, null);
        };

        $scope.getList(2);//Get Inbox Items       

    }
})();
