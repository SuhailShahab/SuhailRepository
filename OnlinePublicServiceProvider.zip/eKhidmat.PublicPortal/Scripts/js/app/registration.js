﻿(function () {
    'use strict';

    let app = angular
        .module('fcportal');

    let reqModule = ['ng-bootstrap-select', 'ui.mask'];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });

    app.controller('registrationCtrl', registration);

    registration.$inject = ['$scope', '$http', '$timeout', '$interval'];

    function registration($scope, $http, $timeout, $interval) {
        $scope.title = 'Registration';
        $scope.regenerateOPTTitleShow = false;
        $scope.regenerateOPTTitleShow = "";
        let webAPIPath = getWebAPIPath();
        let registerModel = {
            ApplicantID: null,
            ApplicantName: null,
            FatherName: null,
            ApplicantRelationOf: 'Son of',
            ApplicantCNIC: null,
            ProfessionID: null,
            TelcoID: '030',
            ContactNo: null,
            CityID: null,
            DistrictID: null,
            DivisionID: null,
            TehsilID: null,
            Password: null,
            RegisteredEmail: null,
            OTPCode: null,
            CitizenTypeID: 5,
            OtherCitizenTypeName: null,
            GenderID: 7,
            ArchitectRegisNo: null,
            ArchitectRegNoStatus: null

        };

        $scope.relationshipTypes = [
            { Title: 'Son of', ID: 1 },
            { Title: 'Daughter of', ID: 2 },
            { Title: 'Wife of', ID: 3 }
        ];

        $scope.telcoService = [
            { Title: 'Mobilink', ID: '030' },
            { Title: 'Telenor', ID: '034' },
            { Title: 'Ufone', ID: '033' },
            { Title: 'Warid', ID: '032' },
            { Title: 'Zong', ID: '031' },
        ]

        $scope.editModel = angular.copy(registerModel);
        $scope.disableInfoEdit = false;
        $scope.OTPVerified = false;
        $scope.IsAllowOTP = false
        $scope.registerLists = {
            DistrictsList: [],
            DivisionsList: [],
            ProfessionsList: [],
            TehsilsList: [],
            CityList: [],
            CitizenTypeList: [],
            GenderList: [],
        };

        function getList() {

            function successCallback(successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {
                    let resp = successResp.data;

                    if (resp.response_header.status == APIResponseType.SUCCESS) {
                        let respData = resp.response_detail;

                        $scope.registerLists = respData;

                        $scope.CitizenTypeChange();
                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.get(webAPIPath + '/api/PortalAccount/GetCitizenRegisterLists', {}).then(successCallback, errorCallback);
        }

        let OTPCode = null;

        $scope.getRegistrationOTP = function () {

            if (!$("form").validationEngine('validate')) {
                return;
            }

            $scope.editModel.OTPCode = null;
            clearInterval(downloadTimer);

            function successCallback(successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {
                    let resp = successResp.data;

                    if (resp.response_header.status == APIResponseType.SUCCESS) {
                        let respData = resp.response_detail;

                        OTPCode = respData.OTPCode

                        $('#OTPVerificationModal').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });

                        $timeout(function () {
                            $('#OTPVerificationModal [data-ng-model="editModel.OTPCode"]').focus();
                        }, 10);

                        clearInterval(downloadTimer);
                        TimerCountdown();

                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.post(webAPIPath + 'api/PortalAccount/GetRegisterOTP', $scope.editModel).then(successCallback, errorCallback);
        }

        $scope.ResendOTPitle = '(30s) Resend OTP';
        $scope.ResendOPTDisable = false;
        let downloadTimer = null;


        function TimerCountdown() {
            let timeleft = 30;
            $scope.ResendOPTDisable = true;
            clearInterval(downloadTimer);
            downloadTimer = setInterval(function () {
                if (timeleft <= 0) {
                    clearInterval(downloadTimer);
                    $scope.ResendOPTDisable = false;
                    $scope.disableInfoEdit = false;
                    $scope.ResendOTPitle = 'Resend OTP';
                } else {
                    $scope.ResendOTPitle = '(' + timeleft + 's) Resend OTP';
                }
                $scope.$apply();
                timeleft -= 1;
            }, 1000);
        }

        $scope.closeOTP = function () {
            $scope.editModel.OTP = null;
            //toastr.info('Are you the 6 fingered man?')
        }

        $scope.verifyOTP = function () {

            if (OTPCode == $scope.editModel.OTPCode) {
                $scope.disableInfoEdit = true;
                $scope.OTPVerified = true;
                $('#OTPVerificationModal').modal('hide');
            } else {
                if ($.trim($scope.editModel.OTPCode).length == 0) {
                    toastr.info('Please enter OTP Code.');
                } else {
                    toastr.info('OTP Code is not valid.');
                }
            }
        }

        $scope.resetForm = function () {
            if (!$scope.OTPVerified) {
                $scope.editModel = {
                    ApplicantID: null,
                    ApplicantName: null,
                    FatherName: null,
                    ApplicantRelationOf: 'Son of',
                    ApplicantCNIC: null,
                    ProfessionID: null,
                    TelcoID: null,
                    ContactNo: null,
                    CityID: null,
                    DistrictID: null,
                    DivisionID: null,
                    TehsilID: null,
                    Password: null,
                    RegisteredEmail: null,
                    OTPCode: null,
                    CitizenTypeID: null,
                    OtherCitizenTypeName: null,
                    GenderID: null,
                    ArchitectRegisNo: null,
                    ArchitectRegNoStatus: null,
                    ArchitectStatusTitle: null
                };
            }
        }

        $scope.saveRegister = function () {
            if (!$("form").validationEngine('validate')) {
                return false;
            }

            if ($scope.editModel.Password !== $scope.editModel.ConfirmPassword) {
                toastr.info('Password not match.');
                return false;
            }

            function successCallback(successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                        let respData = successResp.data.response_detail;

                        toastr.info("You have been registered successfully");

                        $timeout(function () {
                            $('input[name$="WebAPIPath"]').val(respData.AccessToken);
                            __doPostBack('lnkRegister', '');
                        }, 1000);

                    } else {

                        if (successResp.data.response_header.code == 437) {
                            $scope.OTPVerified = false;
                            $scope.disableInfoEdit = false;
                            $scope.editModel.OTPCode = null;
                            toastr.info(successResp.data.response_header.message);
                            $scope.getRegistrationOTP();
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }


                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.post(webAPIPath + 'api/PortalAccount/CitizenRegister', $scope.editModel).then(successCallback, errorCallback);

            return false;
        }

        $scope.isShowCitizenType = false;
        $scope.CitizenTypeChange = function () {
            if ($scope.editModel.CitizenTypeID == 5) {
                $scope.isShowCitizenType = true;
            } else {
                $scope.isShowCitizenType = false;
            }

            //var citizenTypeName = $scope.registerLists.CitizenTypeList.filter(function (item) { return item.ID == $scope.editModel.CitizenTypeID; })[0];
            //if (citizenTypeName != "" && citizenTypeName.Title == "Other") {
            //    $scope.isShowCitizenType = true;
            //} else {
            //    $scope.isShowCitizenType = false;
            //}
        };

        $scope.citizenVerify = function ($event) {
            if ($scope.editModel.ApplicantCNIC) {
                function successCallback(successResp) {
                    console.log(successResp);
                    if (successResp.status == HTTPStatusCode.OK) {
                        let resp = successResp.data;

                        if (resp.response_header.status != APIResponseType.SUCCESS) {
                            if (successResp.data.response_header.code == 446) {
                                toastr.info(successResp.data.response_header.message);
                            } else {
                                handleResponseError(successResp.data.response_header);
                            }

                            $scope.editModel.ApplicantCNIC = null;
                        }
                    }
                }

                function errorCallback(response) {
                    console.log(response);
                }

                $http.get(webAPIPath + 'api/PortalAccount/CitizenVerify?cnic=' + $scope.editModel.ApplicantCNIC, $scope.editModel).then(successCallback, errorCallback);
            }
        }
        activate();

        function activate() {
            getList();

            $scope.IsAllowOTP = Boolean.parse(localStorage.getItem("IsAllowOTP"));

            $(document).ready(function () {
                $("form").validationEngine();

                $(document).on('click', '.toggle-password', function () {
                    $(this).find('span').toggleClass("fa-eye fa-eye-slash");
                    var input = $($(this).attr("toggle"));
                    if (input.attr("type") == "password") {
                        input.attr("type", "text");
                    } else {
                        input.attr("type", "password");
                    }
                });

            });

            $timeout(function () {
                $('[data-ng-model="editModel.CitizenTypeID"]').focus();
            }, 10);

        }
        $scope.isShowStatusIcons = false;
        $scope.ArchitectVerificaitonRegNo = function ($event) {
            $scope.editModel.ArchitectRegNoStatus = null;
            if ($scope.editModel.ArchitectRegisNo && $scope.editModel.ArchitectRegisNo.indexOf('A') == -1) {
                $scope.editModel.ArchitectRegisNo = 'A' + $scope.editModel.ArchitectRegisNo
            }
            if ($scope.editModel.ArchitectRegisNo && $scope.editModel.ArchitectRegisNo.length == 6) {
                function successCallback(successResp) {
                    console.log(successResp);
                    if (successResp.status == HTTPStatusCode.OK) {
                        $scope.isShowStatusIcons = true;
                        let resp = successResp.data;

                        if (resp.response_header.status != APIResponseType.SUCCESS) {
                            if (successResp.data.response_header.code == 200) {
                                $scope.editModel.ArchitectStatusTitle = successResp.data.response_header.message;
                               // toastr.info(successResp.data.response_header.message);
                            }
                            //else {
                            //    handleResponseError(successResp.data.response_header);
                            //}

                            //$scope.editModel.ApplicantCNIC = null;
                        }
                        else {
                            $scope.editModel.ArchitectRegNoStatus = successResp.data.response_detail.data[0].status;
                            let regNoStatus = "";
                            if ($scope.editModel.ArchitectRegNoStatus == 0)
                                regNoStatus = "Architect Removed";
                            if ($scope.editModel.ArchitectRegNoStatus == 1)
                                regNoStatus = "Architect Registered";
                            if ($scope.editModel.ArchitectRegNoStatus == 2)
                                regNoStatus = "Architect Deceased";
                            if ($scope.editModel.ArchitectRegNoStatus == 3)
                                regNoStatus = "Architect Pending";

                            $scope.editModel.ArchitectStatusTitle = regNoStatus;
                        }
                    }
                }

                function errorCallback(response) {
                    console.log(response);
                }

                $http.get(webAPIPath + 'api/ArchitectVerification/ArchitectVerificaitonRegNo?registrationNo=' + $scope.editModel.ArchitectRegisNo, $scope.editModel).then(successCallback, errorCallback);
            }
        }

    }
})();
