﻿(function () {
    'use strict';

    let app = angular
        .module('fcportal');

    let reqModule = ['ng-bootstrap-select', 'ui.mask', ];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });

    app.controller('changePasswordCtrl', changePassword);

    changePassword.$inject = ['$scope', '$http'];

    function changePassword($scope, $http) {
        $scope.title = 'changePassword';
        let webAPIPath = getWebAPIPath();
        let changePasswordModel = {
            ApplicantCNIC: null,
            Password: null,
            OTPCode: null

        };

        

        $scope.editModel = angular.copy(changePasswordModel);
        $scope.disableInfoEdit = false;
        $scope.OTPVerified = false;
        $scope.ResendOPTDisable = false;
        $scope.ResendOTPitle = '(30s) Resend OTP';
        let downloadTimer = null;
        //Code for Timer Start
        
        $scope.TimerCountdown = function () {
            let timeleft = 30;
            $scope.ResendOPTDisable = true;
            ///  $scope.disableInfoEdit = true;
            clearInterval(downloadTimer);
            downloadTimer = setInterval(function () {
                if (timeleft <= 0) {
                    clearInterval(downloadTimer);
                    $scope.ResendOPTDisable = false;
                    $scope.disableInfoEdit = false;
                    $scope.ResendOTPitle = 'Resend OTP';
                } else {
                    $scope.ResendOTPitle = '(' + timeleft + 's) Resend OTP';
                }
                $scope.$apply();
                timeleft -= 1;
            }, 1000);
        }

        //Code for Timer End

        let OTPCode = null;

        $scope.getChangePasswordOTP = function (OTPflag) {

            //if (!$("form").validationEngine('validate')) {
            //    return;
            //}
           
            //$('#OTPVerificationModal').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });
            //console.log("In getChangePasswordOTP " + $scope.editModel)

            if ($scope.editModel.ApplicantCNIC == null) {
                toastr.info('Please enter CNIC.');
                return false;
            }

            clearInterval(downloadTimer);

            $scope.editModel.OTPCode = null;

            function successCallback(successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {
                    let resp = successResp.data;

                    if (resp.response_header.status == APIResponseType.SUCCESS) {
                        let respData = resp.response_detail;

                        OTPCode = respData.OTPCode;
                        //console.log("OTPCode = " + OTPCode)

                        
                        if (OTPflag == true) {
                            toastr.info('One Time Pin (OTP) has been sent to you through email & SMS. Please enter OTP to submit your request.');
                        }
                      //  document.getElementById("countdown").style.display = "none";
                        
                        $('#OTPVerificationModal').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });
                        document.getElementById("inputOTP").focus();
                        clearInterval(downloadTimer);
                        $scope.TimerCountdown();
                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.post(webAPIPath + 'api/PortalAccount/GetChangePasswordOTP', $scope.editModel).then(successCallback, errorCallback);
        }

        $scope.closeOTP = function () {
            $scope.editModel.OTP = null;
            //toastr.info('Are you the 6 fingered man?')
        }

        $scope.verifyOTP = function () {
            if (!$("form").validationEngine('validate')) {
                return;
            }

            if (OTPCode == $scope.editModel.OTPCode) {
                $scope.disableInfoEdit = true;
                $scope.OTPVerified = true;
                $('#OTPVerificationModal').modal('hide');
            } else {
                if ($.trim($scope.editModel.OTPCode).length == 0) {
                    toastr.info('Please enter OTP Code.');
                } else {
                    toastr.info('OTP Code is not valid.');
                }
            }
        }

        $scope.updatePassword = function () {
            if (!$("form").validationEngine('validate')) {
                return false;
            }

            if ($scope.editModel.Password == null || $scope.editModel.ConfirmPassword == null || $scope.editModel.Password.length == 0 || $scope.editModel.ConfirmPassword.length == 0) {
                toastr.info('Please enter new & confirmed password.');
                return false;
            }

            if ($scope.editModel.Password != null || $scope.editModel.Password.length > 0) {
                if ($scope.editModel.Password.length < 6 || $scope.editModel.Password.length > 30) {
                    toastr.info('Password length is between 6 and 30');
                    return false;
                }
            }

            

            if ($scope.editModel.ConfirmPassword != null || $scope.editModel.ConfirmPassword.length > 0) {
                if ($scope.editModel.ConfirmPassword.length < 6 || $scope.editModel.ConfirmPassword.length > 30) {
                    toastr.info('Confirm Password length is between 6 and 30');
                    return false;
                }
            }

            if ($scope.editModel.Password !== $scope.editModel.ConfirmPassword) {
                toastr.info('Password not match.');
                return false;
            }

            function successCallback(successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                        let respData = successResp.data.response_detail;

                        //$('input[name$="WebAPIPath"]').val(respData.AccessToken);
                        //__doPostBack('lnkRegister', '');

                        $scope.OTPVerified = false;
                        $scope.disableInfoEdit = false;
                        $scope.editModel.OTPCode = null;
                        $scope.editModel.ConfirmPassword = null;
                        $scope.editModel.Password = null;
                        $scope.editModel.ApplicantCNIC = null;

                        toastr.info(successResp.data.response_header.message);
                        setTimeout(function () { window.location.href = '/Login'; }, 3000);
                        

                    } else {

                        if (successResp.data.response_header.code == 446) {
                            $scope.OTPVerified = false;
                            $scope.disableInfoEdit = false;
                            $scope.editModel.OTPCode = null;
                            toastr.info(successResp.data.response_header.message);
                        } else {
                            handleResponseError(successResp.data.response_header);
                        }


                    }
                } else {
                   
                    $scope.OTPVerified = false;
                    $scope.disableInfoEdit = false;
                    $scope.editModel.OTPCode = null;
                    toastr.info(successResp.data.response_header.message);
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.post(webAPIPath + 'api/PortalAccount/ChangePassword', $scope.editModel).then(successCallback, errorCallback);

            return false;
        }

        

        activate();

        function activate() {
            //getList();

            $(document).ready(function () {
                $("form").validationEngine();

                $(document).on('click', '.toggle-password', function () {
                    $(this).find('span').toggleClass("fa-eye fa-eye-slash");
                    var input = $($(this).attr("toggle"));
                    if (input.attr("type") == "password") {
                        input.attr("type", "text");
                    } else {
                        input.attr("type", "password");
                    }
                });
                document.getElementById("CNICtxt").focus();
                $('#OTPVerificationModal').on('shown.bs.modal', function () {
                    $('#inputOTP').focus();
                })
            });

        }
    }
})();
