﻿(function () {
    'use strict';

    let app = angular
        .module('fcportal');

    let reqModule = ['ng-bootstrap-select', 'ui.mask'];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });
    
    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', function ($q) {
            return {
                'request': function (config) {
                    let accessToken = localStorage.getItem("AccessToken");
                    if (accessToken) {
                        config.headers['Authorization'] = 'Bearer ' + accessToken;
                    }
                    return config || $q.when(config);
                },
                'response': function (response) {
                    if (response.status === 401) {

                    }

                    return response || $q.when(response);
                },
                'responseError': function (rejection) {
                    if (rejection.status === 401) {

                    }

                    return $q.reject(rejection);
                }
            }
        }]);
    }]);

    app.directive('fileOnChange', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var onChangeHandler = scope.$eval(attrs.fileOnChange);
                element.on('change', function (evt) {
                    onChangeHandler(evt, scope, element, attrs);
                });
                element.on('$destroy', function () {
                    element.off();
                });

            }
        };
    });

    app.controller('constructionServicesPreviewCtrl', constructionServicesPreviewCtrl);

    constructionServicesPreviewCtrl.$inject = ['$scope', '$http', '$timeout', '$filter', '$location'];

    function constructionServicesPreviewCtrl($scope, $http, $timeout, $filter, $location) {

        let accessToken = localStorage.getItem("AccessToken");
        //if (!accessToken) {
        //    window.location = '/Login';
        //}

        $scope.title = 'constructionServicesPreview';

        let webAPIPath = getWebAPIPath();

        let queryParams = [];
        function readQueryString(key) {
            let PageURL = decodeURI(window.location.search.substring(1));
            let sURLVariables = PageURL.split('&');

            for (let i = 0; i < sURLVariables.length; i++) {
                let sParameterName = sURLVariables[i].split('=');

                if ($.trim(sParameterName[0]).length > 0 && sParameterName[1]) {
                    queryParams[sParameterName[0]] = sParameterName[1];
                }
            }
        };

        readQueryString();

        $scope.previewModel = {
            'TaskStatusID': 1,
            'ApplicantID': null,
            'StartTime': new Date(),
            'EndTime': null,
            'DivisionID': null,
            'DistrictID': null,
            'LocationID': null,
            'FCLocation': null,
            'UserName': null,
            'AuthorityID': null,
            'BPAServiceTypeID': null,
            'ServiceID': null,
            'ServiceCode': null,
            'ServiceTypeID': null,
            'DeliveryTypeID': null,
            'ApplicationTypeID': null,
            'ApplicantCNIC': null,
            'ApplicantName': null,
            'GenderID': null,
            'ApplicantRelationOf': null,
            'FatherName': null,
            'FatherCNIC': null,
            'ApplicantContactNo': null,
            'RegisteredEmail': null,
            'CurrentAddress': null,
            'CurrentCityID': null,
            'CurrentDivisionID': null,
            'CurrentDistrictID': null,
            'IsSameAddr': false,
            'PermanentAddress': null,
            'PermanentCityID': null,
            'PermanentDivisionID': null,
            'PermanentDistrictID': null,
            'PostalAddress': null,
            'DeliveryModeID': 1,
            'CapturedImage': null,
            'SiteCoveredArea': null,
            'SitePlotArea': null,
            'SiteNatureType': null,
            'SiteAddress': null,
            'KhasraNo': null,
            'KhewatNo': null,
            'KhatoniNo': null,
            'Mouza': null,
            'Scheme': null,
            'Phase': null,
            'Sector': null,
            'Block': null,
            'StreetNo': null,
            'PlotTypeTitle': null,
            'Remarks': null,
            'Division': null,
            'District': null,
            'Location': null,
            'Authority': null,
            'BPAServiceType': null,
            'Service': null,
            'ServiceType': null,
            'DeliveryType': null,
            'ApplicationType': null,
            'OwnerInformationItems': [],
        };

        $scope.UserProfile = userProfile;

        function getPreviewData() {

            function successCallback(successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.response_header.status == APIResponseType.SUCCESS) {
                        let respData = successResp.data.response_detail;
                        $scope.previewModel = respData.Model;
                        $scope.RemarksHistory = respData.Model.RemarksHistory;
                        $scope.Documents = respData.Model.Documents;

                        $timeout(function () {
                            window.print();
                        }, 100);

                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            let currentApplicantID = queryParams['ApplicantID'] ? queryParams['ApplicantID'] : '';
            let serviceCode = queryParams['ServiceCode'] ? queryParams['ServiceCode'] : '';

            $http.get(webAPIPath + 'api/Construction/GetPreviewDataByApplicantID', { params: { 'ID': currentApplicantID, 'serviceCode': serviceCode } }).then(successCallback, errorCallback);
        }

        function activate() {

            $(document).ready(function () {
                getPreviewData();
            });
        }

        activate();


        //let PlotOwnerInfo = {
        //    ID: null,
        //    Name: null,
        //    RelationOfName: null,
        //    CNIC: null,
        //    Phone: null,
        //    RelationOf: null,
        //    Address: null,
        //    OwnerImage: null
        //};


    }
})();