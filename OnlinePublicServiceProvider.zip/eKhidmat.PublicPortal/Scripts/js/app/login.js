﻿(function () {
    'use strict';

    let app = angular
       .module('fcportal');

    let reqModule = ['ng-bootstrap-select', 'ui.mask'];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });

    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', function ($q) {
            return {
                'request': function (config) {
                    var accessToken = localStorage.getItem("AccessToken");
                    if (accessToken) {
                        config.headers['Authorization'] = 'Bearer ' + accessToken;
                    }
                    return config || $q.when(config);
                },
                'response': function (response) {
                    if (response.status === 401) {

                    }

                    return response || $q.when(response);
                },
                'responseError': function (rejection) {
                    if (rejection.status === 401) {

                    }

                    return $q.reject(rejection);
                }
            }
        }]);
    }]);

    app.controller('loginCtrl', login);

    login.$inject = ['$scope', '$http', '$timeout', '$interval'];

    function login($scope, $http, $timeout, $interval) {
        $scope.title = 'login';
        let webAPIPath = getWebAPIPath();

        let loginModel = {
            ApplicantCNIC: null,
            Password: null
        };

        $scope.editModel = angular.copy(loginModel);
        let IsAllowOTP = false;
        let OTPCode = null;

        $scope.LoginClick = function () {

            if (!$("form").validationEngine('validate')) {
                return;
            }

            if ($scope.editModel.ApplicantCNIC == null) {
                toastr.info('Please enter your CNIC No.');
                return false;
            } else if ($scope.editModel.Password == null) {
                toastr.info('Please enter your password');
                return false;
            }

            if (IsAllowOTP != true) {
                getTokenfromAPI();
            }
            else {
                getLoginOTP();

                $('#OTPVerificationModal').modal({ 'backdrop': 'static', 'keyboard': false, 'show': true });

                $scope.editModel.OTPCode = null;

                $timeout(function () {
                    $('[data-ng-model="editModel.OTPCode"]').focus();
                }, 10);

                $scope.ResendOTPitle = '(30s) Resend OTP';               
                clearInterval(downloadTimer);
                TimerCountdown();
            }
        }

        $scope.ResendOTP = function () {
            if (!$("form").validationEngine('validate')) {
                return;
            }

            getLoginOTP();
        }

        $scope.SubmitOTP = function () {

            if (!$("form").validationEngine('validate')) {
                return;
            }

            if (OTPCode != null && OTPCode == $scope.editModel.OTPCode) {
                $('#OTPVerificationModal').modal('hide');
                getTokenfromAPI();

            } else {
                if ($.trim($scope.editModel.OTPCode).length == 0) {
                    toastr.info('Please enter OTP Code.');
                    return;
                } else {
                    toastr.info('OTP Code is not valid.');
                    return;
                }
            }
        }

        function getLoginOTP() {

            function successCallback(successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {
                    let resp = successResp.data;

                    if (resp.response_header.status == APIResponseType.SUCCESS) {
                        let respData = resp.response_detail;

                        OTPCode = respData.OTPCode;
                        toastr.info('One Time Pin (OTP) has been sent to you through email & SMS. Please enter OTP to submit your request.');

                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.post(webAPIPath + 'api/PortalAccount/GetLoginOTP', $scope.editModel).then(successCallback, errorCallback);
        }

        function getTokenfromAPI() {

            function successCallback(successResp) {
                console.log(successResp);
                if (successResp.status == HTTPStatusCode.OK) {
                    let resp = successResp.data;

                    if (resp.response_header.status == APIResponseType.SUCCESS) {
                        let respData = resp.response_detail;

                        $timeout(function () {
                            $('input[name$="WebAPIPath"]').val(respData.AccessToken);
                            __doPostBack('lnkLogin', '');
                        }, 1000);
                    } else {
                        handleResponseError(successResp.data.response_header);
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            $http.post(webAPIPath + 'api/PortalAccount/CitizenLogin', $scope.editModel).then(successCallback, errorCallback);
        }

        $scope.ResendOTPitle = '(30s) Resend OTP';
        $scope.ResendOPTDisable = false;
        let downloadTimer = null;

        function TimerCountdown() {
            let timeleft = 30;
            $scope.ResendOPTDisable = true;

            clearInterval(downloadTimer);
            downloadTimer = setInterval(function () {
                if (timeleft <= 0) {
                    clearInterval(downloadTimer);
                    $scope.ResendOPTDisable = false;
                    $scope.ResendOTPitle = 'Resend OTP';

                } else {
                    $scope.ResendOTPitle = '(' + timeleft + 's) Resend OTP';
                }
                $scope.$apply();
                timeleft -= 1;
            }, 1000);
        }

        activate();

        function activate() {

            IsAllowOTP = Boolean.parse(localStorage.getItem("IsAllowOTP"));

            $(document).ready(function () {
                $("form").validationEngine();

                $(document).on('click', '.toggle-password', function () {
                    $(this).find('span').toggleClass("fa-eye fa-eye-slash");
                    var input = $(this).parent().find("input");
                    if (input.attr("type") == "password") {
                        input.attr("type", "text");
                    } else {
                        input.attr("type", "password");
                    }
                });

                $timeout(function () {
                    $('[data-ng-model="editModel.ApplicantCNIC"]').focus();
                }, 10);


            });
        }

    }
})();
