﻿(function () {
    'use strict';

    let app = angular
        .module('fcportal');

    app.directive('datetimepicker', ['$timeout', '$parse', function ($timeout, $parse) {
        return {
            require: 'ngModel',
            scope: {
                options: "="
            },
            link: function (scope, el, attrs, ngModel) {

                $timeout(function () {
                    if (!scope.options) {
                        scope.options = [];
                    }

                    if (ngModel.$modelValue) {
                        scope.options.value = ngModel.$modelValue;
                    }

                    let changeListener = function () {
                        console.log('Date Updated: ' + ngModel.$modelValue);
                        $(el).val(ngModel.$modelValue);
                    }

                    scope.options.onChangeDateTime = function (dateText) {
                        scope.$apply(function () {

                            ngModel.$viewChangeListeners.splice(changeListener, 1);
                            ngModel.$setViewValue(dateText);
                            $timeout(function () {
                                ngModel.$viewChangeListeners.push(changeListener);
                            });
                        });
                    };

                    $(el).datetimepicker(scope.options);

                    if (scope.options.value) {
                        delete scope.options.value;
                    }
                    
                    ngModel.$viewChangeListeners.push(changeListener);

                    //ngModel.$overrideModelOptions({
                    //    getterSetter: true
                    //});

                    //let getter = $parse(attrs.ngModel);
                    //getter = function () {
                    //    return $(el).datetimepicker('getValue');
                    //}

                    //ngModel.$render = function model2view() {
                    //    clock.set(ngModel.$viewValue);
                    //}


                    //scope.$watch(function () {
                    //    return ngModel.$modelValue;
                    //}, function (newValue) {
                    //    console.log(newValue);
                    //});

                    //$(el).datetimepicker({
                    //    minDate: 0,
                    //    //onChangeDateTime: logic,
                    //    //onShow: logic,
                    //    onSelect: function (dateText) {
                    //        scope.$apply(function () {
                    //            ngModel.$setViewValue(dateText);
                    //        });
                    //    }
                    //});
                }, 100);

            }
        };
    }]);

    //app.directive('datetimepicker', xdasoftdatetimepicker);

    //xdasoftdatetimepicker.$inject = ['$window', '$filter'];

    //function xdasoftdatetimepicker($window, $filter) {
    //    return {
    //        restrict: "EA",
    //        replace: true,
    //        scope: {
    //            date: "=",
    //            options: "="
    //        },
    //        template: "<input ng-model=\"str\" type=\"text\" class=\"input input-block\"></input>",
    //        link: function (scope, elem, attr) {
    //            scope.options.onChangeDateTime = function (dp, i) {
    //                scope.date = dp;
    //                //console.log(scope.date);
    //            }
    //            $(elem).datetimepicker(scope.options);
    //            scope.$watch("date", function () {
    //                scope.str = $filter("date")(scope.date, scope.options.angularFormat);
    //                //console.log(scope.str);
    //            });
    //        }
    //    }
    //}


})();