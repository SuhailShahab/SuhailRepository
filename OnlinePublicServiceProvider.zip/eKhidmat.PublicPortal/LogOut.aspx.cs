﻿using eKhidmat.PublicPortal.ApplicationClasses;
using PITB.eKhidmat.ApplicationClasses;
using PITB.FC.BE.Common;
using PITB.FC.BE.RightsManager;
using System;
using System.Web;
using System.Web.UI;

namespace eKhidmat.PublicPortal
{
    public partial class LogOut : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserProfileModel profileModel = CommonFunction.GetCurrentUserSession();

                if (profileModel != null)
                {
                    HttpContext.Current.Session.Abandon();

                    SessionStateManager sessionStateManager = new SessionStateManager();
                    int? result = sessionStateManager.DeleteSessionByID(HttpContext.Current.Session.SessionID);

                    //HttpContext.Current.Response.Cookies["AccessToken"].Expires = DateTime.Now.AddDays(-1);
                    HttpContext.Current.Response.Cookies["AccessToken"].Expires = DateTime.Now.AddHours(-8);
                    HttpContext.Current.Request.Cookies.Clear();

                    if (profileModel.UserType == GlobalDeclarations.UserTypes.ScrutinizedPortal.GetHashCode())
                    {
                        Response.Redirect("~/Layouts/ScrutinizerLogin.aspx");
                    }
                    else
                    {
                        Response.Redirect("~/Login.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                if (AppConfigManager.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(ex.Message) + "');", true);
                }
            }

        }
    }
}