﻿using PITB.eKhidmat.ApplicationClasses;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace eKhidmat.PublicPortal.ApplicationClasses
{
    public static class AppConfigManager
    {
        public static string EkhidmatAPIUrl
        {
            get
            {
                return Convert.ToString(ConfigurationManager.AppSettings["EkhidmatAPIUrl"]);
            }
        }

        public static bool IsShowGeneralMsg
        {
            get
            {
                return Convert.ToBoolean(ConfigurationManager.AppSettings["IsShowGeneralMsg"]);
            }
        }

        public static string GeneralErrorMessage
        {
            get
            {
                return ConfigurationManager.AppSettings["GeneralMsg"].ToString();
            }
        }
        public static bool IsAllowMobileOTP_CP
        {
            get
            {
                string result = string.Empty;
                
                result = CommonFunction.GetConfiguration("IsAllowMobileOTP_CP");
                if (string.IsNullOrEmpty(result) || result == "false")
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public static bool IsAllowEmailOTP_CP
        {
            get
            {
                string result = string.Empty;

                result = CommonFunction.GetConfiguration("IsAllowEmailOTP_CP");
                if (string.IsNullOrEmpty(result) || result == "false")
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        public static bool IsAllowOTP_CP
        {
            get
            {
                string result = string.Empty;

                result = CommonFunction.GetConfiguration("IsAllowOTP_CP");
                if (string.IsNullOrEmpty(result) || result == "false")
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }

        public static string JsCSSName
        {
            get
            {
                bool reslut = false;
                reslut =  Convert.ToBoolean(ConfigurationManager.AppSettings["EnabledMinifiedJSCSSFiles"]);

                if (reslut == true)
                {
                    return ".min";
                }

                return "";
            }
        }

    }
}