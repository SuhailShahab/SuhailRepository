﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eKhidmat.PublicPortal.ApplicationClasses
{
  public  static   class RptConfig
    {
       

        public static string UserNameCredientail
        {
            get { return Convert.ToString(ConfigurationManager.AppSettings["UserNameCredientail"]); }//"administrator"; }//System.Configuration.ConfigurationManager.ConnectionStrings["UserNameCred"].ConnectionString.ToString();  }
           // set { this.m_UserName = value; }
        }

        public static string PasswordCredientail
        {
            get { return Convert.ToString(ConfigurationManager.AppSettings["PasswordCredientail"]); }//get { return "pitb@123"; }//System.Configuration.ConfigurationManager.ConnectionStrings["PasswordCred"].ConnectionString.ToString(); }
           // set { this.m_Password = value; }
        }

        //public static string ReportDominName
        //{
        //    get { return Convert.ToString(ConfigurationManager.AppSettings["ReportDominName"]); }// get { return "sp2013:44410"; }//System.Configuration.ConfigurationManager.ConnectionStrings["DomainNameCred"].ConnectionString.ToString(); }
           
        //}

        public static string ExtSPSiteName
        {
            get { return Convert.ToString(ConfigurationManager.AppSettings["ExtSPSiteName"]); }// get { return "sp2013:44410"; }//System.Configuration.ConfigurationManager.ConnectionStrings["DomainNameCred"].ConnectionString.ToString(); }

        }

        //public static string EnableReportCredential
        //{
        //    get { return System.Configuration.ConfigurationManager.ConnectionStrings["EnableReportCred"].ConnectionString.ToString(); }
        //    //set { this.m_EnableReportCredential = value; }
        //}

        //public static string ResetReportViewer
        //{
        //    get { return "1"; }//System.Configuration.ConfigurationManager.ConnectionStrings["ReportViewerReset"].ConnectionString.ToString(); }
        //   // set { this.m_ReportViewerReset = value; }
        //}

        public static string ReportServer
        {
            get { return Convert.ToString(ConfigurationManager.AppSettings["ReportServer"]); }//get { return @"http://sp2013:44410/_vti_bin/ReportServer"; }  //System.Configuration.ConfigurationManager.ConnectionStrings["ReportServer"].ConnectionString.ToString(); }
           // set { this.m_ReportServer = value; }
        }
        public static string ReportPath
        {
            get { return Convert.ToString(ConfigurationManager.AppSettings["ReportPath"]); }//get { return @"http://sp2013:44410/FCReports/Reports/"; }  //System.Configuration.ConfigurationManager.ConnectionStrings["ReportServer"].ConnectionString.ToString(); }
            // set { this.m_ReportServer = value; }
        }
        //public static string ReportProjectNameHRMS
        //{
        //    get { return System.Configuration.ConfigurationManager.ConnectionStrings["ReportProjectNameHRMS"].ConnectionString.ToString(); }
        //   // set { this.m_ReportProjectNameHRMS = value; }
        //}
        //public static string ReportProjectNameFMS
        //{
        //    get { return "sp2013:44410/FCReports/"; }//System.Configuration.ConfigurationManager.ConnectionStrings["ReportProjectNameFMS"].ConnectionString.ToString(); }
        //   // set { this.m_ReportProjectNameFMS = value; }
        //}
        //public static string ReportProjectNameCTMS
        //{
        //    get { return System.Configuration.ConfigurationManager.ConnectionStrings["ReportProjectNameCTMS"].ConnectionString.ToString(); }
        //   // set { this.m_ReportProjectNameCTMS = value; }
        //}
    }
}
