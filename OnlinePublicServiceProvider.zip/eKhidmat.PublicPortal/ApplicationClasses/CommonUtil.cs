﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eKhidmat.PublicPortal.ApplicationClasses
{
    public class CommonUtil
    {
        //public  void SaveSessionState(UserModel user)
        //{
        //    try
        //    {
        //        SerializeDeserialize<UserModel> xmlObj = new SerializeDeserialize<UserModel>();
        //        string strUser = xmlObj.SerializeData(user);
        //        LazyBaseSingletonBLL<SessionStateBLL>.Instance.SaveSessionState(Session.SessionID, strUser, user.UserID, ConfigurationHelper.TimeOute);
        //    }
        //    catch (Exception ex)
        //    {
        //        LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveSessionState", 1, PageNames.Login, new UserModel()));
        //    }
        //}
    }
}