﻿// =================================================================================================================================
// Create by:	<sufyan ali>
// Create date: <11-08-2020 10:13AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
using eKhidmat.API.Common;
using eKhidmat.PublicPortal.ApplicationClasses;
using Newtonsoft.Json;
using PITB.FC.BE;
using PITB.FC.BE.Common;
using PITB.FC.BE.Configuration;
using PITB.FC.BE.RightsManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Net;
using System.Reflection;
using System.Text;
using System.Web;

namespace PITB.eKhidmat.ApplicationClasses
{
    public static class CommonFunction
    {
        //#region "Error Log Method Method"

        ///// <summary>
        ///// Save Error Log Info
        ///// </summary>
        ///// <param name="erroLog"></param>
        ///// <returns></returns>
        //public static int AddErrorLog(ErrorLogModel erroLog)
        //{
        //    FillErrorLogData(erroLog);
        //    return LazyBaseSingletonUI<CommonBLL>.Instance.SaveErrorLog(erroLog);
        //}
        //public static string AddErrorLogs(ErrorLogModel erroLog)
        //{
        //    FillErrorLogData(erroLog);
        //    int id = LazyBaseSingletonUI<CommonBLL>.Instance.SaveErrorLogs(erroLog);
        //    return "(" + id.ToString() + "-" + DateTime.Now.Day + DateTime.Now.Month + DateTime.Now.Year + ")";

        //}

        //private static void FillErrorLogData(ErrorLogModel ErrorLog)
        //{
        //    if (ErrorLog != null && !string.IsNullOrEmpty(ErrorLog.PageName) && ErrorLog.PageName != "SignIn")         // CR: 052
        //    {
        //        DataTable dtUser = GetSessionUserTable();
        //        if (dtUser != null)
        //        {
        //            if (dtUser.Columns.Contains("FCLocationCode") && !Convert.IsDBNull(dtUser.Rows[0]["FCLocationCode"]))
        //            {
        //                ErrorLog.LocationCode = Convert.ToString(dtUser.Rows[0]["FCLocationCode"]);
        //            }
        //            if (ErrorLog.Service.GetHashCode() > 0)
        //            {
        //                ErrorLog.ServiceCode = StringEnum.GetCode(ErrorLog.Service);
        //            }
        //            if (dtUser.Columns.Contains("DivisionID") && !Convert.IsDBNull(dtUser.Rows[0]["DivisionID"]))
        //            {
        //                ErrorLog.DivisionID = Convert.ToInt32(dtUser.Rows[0]["DivisionID"]);
        //            }

        //            if (dtUser.Columns.Contains("MainDistrictID") && !Convert.IsDBNull(dtUser.Rows[0]["MainDistrictID"]))
        //            {
        //                ErrorLog.DistrictID = Convert.ToInt32(dtUser.Rows[0]["MainDistrictID"]);
        //            }
        //        }
        //    }

        //    if (ErrorLog.CustomException != null)
        //    {
        //        if (ErrorLog.CustomException.Message != "") ErrorLog.Message = ErrorLog.GetaAllMessages();//ErrorLog.g //ErrorLog.CustomException.Message;
        //        if (ErrorLog.CustomException.StackTrace != "") ErrorLog.StackTrace = ErrorLog.CustomException.StackTrace;
        //        if (ErrorLog.CustomException.Source != "") ErrorLog.Source = ErrorLog.CustomException.Source;

        //    }
        //}

        //#endregion

        /// <summary>
        /// Fix single quotes issue in toaster error messages.
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static string FixQuotesFortoastr(string msg)
        {
            return HttpUtility.JavaScriptStringEncode(msg);
        }

        /// <summary>
        /// Save Error Log Info
        /// </summary>
        /// <param name="erroLog"></param>
        /// <returns></returns>
        public static string GetConfiguration(string key)
        {
            try
            {
                if (!string.IsNullOrEmpty(AppConfigManager.EkhidmatAPIUrl))
                {
                    string serviceURL = AppConfigManager.EkhidmatAPIUrl + "api/Common/GetConfiguration";

                    WebClient webClient = new WebClient();
                    webClient.Encoding = Encoding.UTF8;
                    webClient.QueryString.Add("key", key);

                    Uri address = new Uri(serviceURL);
                    var response = webClient.DownloadString(address);

                    ResponseModel<List<ConfigurationModel>> responseModel = JsonConvert.DeserializeObject<ResponseModel<List<ConfigurationModel>>>(response);

                    if (responseModel.response_detail.Count > 0)
                    {
                        foreach (ConfigurationModel localModel in responseModel.response_detail)
                        {
                            return localModel.KeyValue;
                        }
                    }
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }

            return string.Empty;
        }

        /// <summary>
        /// Get Description of Enum
        /// </summary>
        public static string GetEnumDescription(Enum p_Enum)
        {
            try
            {
                FieldInfo l_FieldInfo = p_Enum.GetType().GetField(p_Enum.ToString());
                DescriptionAttribute[] attributes = (DescriptionAttribute[])l_FieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);
                if (attributes.Length > 0)
                {
                    return attributes[0].Description;
                }
                else
                {
                    return p_Enum.ToString();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// Check the Session value. If valude is null get session value from session database and set the session value
        /// IF Session not found form datbase then check the cookee and get the profile value form database by access token
        /// </summary>
        /// <returns></returns>
        public static UserProfileModel GetCurrentUserSession()
        {
            UserProfileModel userProfileModel = null;

            if (HttpContext.Current.Session["UserProfile"] == null)
            {
                //  HttpCookie accessToken = HttpContext.Current.Request.Cookies.Get("AccessToken");

                SessionStateManager sessionStateManager = new SessionStateManager();
                SessionStateModel sesstionModel = sessionStateManager.GetSessiontStateByID(HttpContext.Current.Session.SessionID);
                if (sesstionModel != null && !string.IsNullOrEmpty(sesstionModel.JsonString))
                {
                    //Get Session State form Database
                    if (sesstionModel != null)
                    {
                        userProfileModel = JsonConvert.DeserializeObject<UserProfileModel>(sesstionModel.JsonString);
                        HttpContext.Current.Session["UserProfile"] = userProfileModel;

                    }

                }
                else
                {

                    HttpCookie accessToken = HttpContext.Current.Request.Cookies.Get("AccessToken");

                    if (accessToken != null && accessToken.Value != "")
                    {
                        // Get Profiler info form token
                        ResponseModel<UserProfileModel> userProfile = GetUserProfile(accessToken.Value);

                        if (userProfile != null && userProfile.response_header.status == CommonAPI.GetEnumDescription(GlobalDeclarations.ResponseType.Success))
                        {
                            HttpContext.Current.Session["UserProfile"] = userProfile.response_detail;
                            userProfileModel = (UserProfileModel)HttpContext.Current.Session["UserProfile"];
                        }
                        else
                        {
                            return null;
                        }

                    }
                    else
                    {
                        return null;
                    }
                }
            }
            else
            {
                userProfileModel = (UserProfileModel)HttpContext.Current.Session["UserProfile"];
            }

            return userProfileModel;
        }

        public static ResponseModel<UserProfileModel> GetUserProfile(string accessToken)
        {
            try
            {
                if (!string.IsNullOrEmpty(AppConfigManager.EkhidmatAPIUrl))
                {
                    // process the request and get response as string
                    string serviceURL = AppConfigManager.EkhidmatAPIUrl + "api/Portal/GetUserProfile";

                    WebClient webClient = new WebClient();
                    //webClient.Headers["Content-type"] = "application/json";
                    webClient.Encoding = Encoding.UTF8;
                    webClient.Headers.Add("Authorization", "Bearer" + accessToken);

                    Uri address = new Uri(serviceURL);
                    var profile = webClient.DownloadString(address);

                    ResponseModel<UserProfileModel> profileResponse = JsonConvert.DeserializeObject<ResponseModel<UserProfileModel>>(profile);
                    if (profileResponse != null && profileResponse.response_header != null)
                    {
                        return profileResponse;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return null;
        }

    }
}
