﻿using PITB.FC.BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eKhidmat.PublicPortal.ApplicationClasses
{
    [ClassMapping(TableName = "tblSessionState", Identifier = "SessionID")]
    [Serializable]
    public class SessionStateModel
    {
        [MappingInfo(ColumnName = "SessionID", IdentitySpecification = true)]
        public string SessionID { get; set; }

        [MappingInfo(ColumnName = "UserName")]
        public string UserName { get; set; }

        [MappingInfo(ColumnName = "JsonString")]
        public string JsonString { get; set; }

        [MappingInfo(ColumnName = "TimeOut")]
        public int? TimeOut { get; set; }
    }
}