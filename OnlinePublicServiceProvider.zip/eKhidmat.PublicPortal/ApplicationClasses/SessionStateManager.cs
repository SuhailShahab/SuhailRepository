﻿using eKhidmat.PublicPortal.Common;
using Newtonsoft.Json;
using PITB.FC.BE;
using PITB.FC.BE.RightsManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Configuration;

namespace eKhidmat.PublicPortal.ApplicationClasses
{
    public class SessionStateManager
    {
        public SessionStateManager()
        {
            this.m_spConnectionString = WebConfigurationManager.ConnectionStrings["DBConnectionStringSessionState"].ConnectionString.ToString();
        }

        #region "DB-State Methods"

        private string m_spConnectionString = "DBConnectionString";

        protected string ConnectionString
        {
            get { return m_spConnectionString; }
        }

        public int SaveSessionState(string sessionID, string jsonString, string userName, int? timeOute)
        {
            object result = 0;
            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    using (SqlCommand sqlCmd = new SqlCommand())
                    {

                        try
                        {
                            if (con.State == ConnectionState.Closed)
                                con.Open();

                            sqlCmd.Connection = con;
                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.CommandText = "spAddSessionState";

                            sqlCmd.Parameters.Add(new SqlParameter("@SessionID", SqlDbType.NVarChar));
                            sqlCmd.Parameters["@SessionID"].Value = sessionID;

                            sqlCmd.Parameters.Add(new SqlParameter("@JsonString", SqlDbType.NVarChar));
                            sqlCmd.Parameters["@JsonString"].Value = jsonString;

                            if (timeOute.HasValue && timeOute.Value > 0)
                            {
                                sqlCmd.Parameters.Add(new SqlParameter("@SessionTimeOute", SqlDbType.Int));
                                sqlCmd.Parameters["@SessionTimeOute"].Value = timeOute;
                            }

                            sqlCmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
                            sqlCmd.Parameters["@UserName"].Value = userName;

                            result = sqlCmd.ExecuteScalar();
                            con.Close();
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                        finally
                        {
                            if (con.State == ConnectionState.Open)
                                con.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }

        public SessionStateModel GetSessiontStateByID(string sessionId)
        {
            SessionStateModel sessionStateModel = null;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {

                    using (SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSessionStateByID", con))
                    {
                        DataTable dt = new DataTable();
                        sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SessionID", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@SessionID"].Value = sessionId;

                        sqlDadp.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {

                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();

                }
            }

            return sessionStateModel;
        }

        public int? DeleteSessionByID(string sessionID)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spDeleteSessionByID";

                        if (!string.IsNullOrEmpty(sessionID))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@SessionID", SqlDbType.VarChar));
                            sqlCmd.Parameters["@SessionID"].Value = sessionID;
                        }

                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return result;
        }

        #endregion

        private static void SetUserSessionValue(UserProfileModel userProfileModel)
        {
            if (userProfileModel != null)
            {
                HttpContext.Current.Session["UserName"] = userProfileModel.UserName;
            }
            
            HttpContext.Current.Session["UserTable"] = userProfileModel;
        }

        /// <summary>
        /// Reload session user information
        /// </summary>
        public static SessionStateModel GetSessionUserTable()
        {
            UserProfileModel userProfileModel = null;
            SessionStateModel sessionStateModel = null;
            HttpCookie accessToken = null;
            if (HttpContext.Current.Session["UserTable"] == null)
            {
                accessToken = HttpContext.Current.Request.Cookies.Get("AccessToken");

                if (accessToken != null && accessToken.Value != "")
                {
                    try
                    {
                        string webAPIPath = AppConfigManager.EkhidmatAPIUrl;

                        if (webAPIPath != null && webAPIPath != "")
                        {

                            string requestData = string.Empty;

                            // process the request and get response as string
                            string serviceURL = webAPIPath.TrimEnd('/') + "/api/Portal/GetUserProfile";

                            WebClient webClient = new WebClient();
                            webClient.Headers["Content-type"] = "application/json";
                            webClient.Headers["Authorization"] = accessToken.ToString();
                            webClient.Encoding = Encoding.UTF8;

                            Uri address = new Uri(serviceURL);
                            var responseaData = webClient.UploadString(address, "POST", requestData);

                            ResponseModel<UserProfileModel> responseResult = JsonConvert.DeserializeObject<ResponseModel<UserProfileModel>>(responseaData);
                            userProfileModel = responseResult.response_detail;
                        }
                    }
                    catch (Exception ex)
                    {
                       
                    }

                    SetUserSessionValue(userProfileModel);

                    userProfileModel = (UserProfileModel)HttpContext.Current.Session["UserTable"];
                }
                else
                {
                    //Get Session State form Database
                    sessionStateModel = new SessionStateManager().GetSessiontStateByID(HttpContext.Current.Session.SessionID);

                    if (sessionStateModel != null)
                    {
                        userProfileModel = JsonConvert.DeserializeObject<UserProfileModel>(sessionStateModel.JsonString);

                        DateTime cookieTime = DateTime.Now.AddHours(CookeeExpiryTime.ExpiryTime);//.AddDays(1);
                        HttpContext.Current.Response.Cookies["UserName"].Value = userProfileModel.UserName.ToString();
                        HttpContext.Current.Response.Cookies["UserName"].Expires = cookieTime;

                        SetUserSessionValue(userProfileModel);

                        userProfileModel = (UserProfileModel)HttpContext.Current.Session["UserTable"];
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            else
            {
                userProfileModel = (UserProfileModel)HttpContext.Current.Session["UserTable"];
            }

            return sessionStateModel;
        }

    }
}