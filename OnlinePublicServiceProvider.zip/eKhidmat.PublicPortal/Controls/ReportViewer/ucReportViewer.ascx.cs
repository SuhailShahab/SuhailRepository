﻿using Microsoft.Reporting.WebForms;
using Microsoft.SharePoint.Utilities;
using eKhidmat.PublicPortal.ApplicationClasses;

using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eKhidmat.PublicPortal.Controls.ReportViewer
{
    public partial class ucReportViewer : System.Web.UI.UserControl
    {
        #region Custom Properties

        public string ReportName { get; set; }

        public List<Microsoft.Reporting.WebForms.ReportParameter> ParamList { get; set; }

        public List<Microsoft.Reporting.WebForms.ReportDataSource> DataSourceList { get; set; }

        private string testProperty;

        public string TestProperty
        {
            get { return testProperty; }
            set { testProperty = value; }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        #region Custom Methods

        public void LoadLocalReport()
        {


            try
            {
                cRptViewer.Width = Unit.Pixel(950);
                cRptViewer.Height = Unit.Pixel(700);

                // Update report and refresh
                cRptViewer.LocalReport.ReportPath = SPUtility.GetGenericSetupPath("template") + "/LAYOUTS/Reports/" + this.GetReportPath() + ".rdlc";

                cRptViewer.LocalReport.EnableExternalImages = true; 
                if (this.ParamList != null && this.ParamList.Count > 0)
                {
                    cRptViewer.LocalReport.SetParameters(this.ParamList);
                }
                cRptViewer.LocalReport.DataSources.Clear();
                if (this.DataSourceList != null && this.DataSourceList.Count > 0)
                {
                    for (int i = 0; i < this.DataSourceList.Count; i++)
                    {
                        cRptViewer.LocalReport.DataSources.Add(this.DataSourceList[i]);
                    }
                }

                cRptViewer.LocalReport.Refresh();

                //   ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "AddPrintButtonScript", "AddPrintButton();", true);

            }
            catch (Exception ex)
            {

                //string errorCode = string.Empty;
                ////errorCode = AddErrorLogs(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));
                //if (ConfigurationReader.IsShowGeneralMsg)
                //{
                //    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationReader.GeneralMsg + "<br/>" + errorCode + "');", true);
                //}
                //else
                //{
                //    throw;

                //}
                //Common.AddErrorLog(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));

            }
        }

        public void LoadReport()
        {


            try
            {
                //if (string.IsNullOrEmpty(this.ReportName) && string.IsNullOrEmpty(this.ServiceCode))
                //{
                //   // lblErrorMessage.Text = CustomMsg.MissingReportName;
                //    return;
                // }
                ReportServerCredentials objReportServerCredentials = null;
                //Credentail Settting
                objReportServerCredentials = new ReportServerCredentials(RptConfig.UserNameCredientail, RptConfig.PasswordCredientail, RptConfig.ExtSPSiteName);

                cRptViewer.Visible = true;
                //if (RptConfig.ResetReportViewer.ToString() == "1")
                //    cRptViewer.Reset();

                //cRptViewer.Width = Unit.Percentage(100);
                //cRptViewer.Height = Unit.Percentage(100);
                cRptViewer.ProcessingMode = ProcessingMode.Remote;
                cRptViewer.ServerReport.ReportServerUrl = new Uri(RptConfig.ReportServer);

                //Assign Credential
                cRptViewer.ServerReport.ReportServerCredentials = objReportServerCredentials;
                cRptViewer.ServerReport.ReportPath = this.GetReportPath();


                if (this.ParamList != null && this.ParamList.Count > 0)
                {
                    cRptViewer.ServerReport.SetParameters(this.ParamList);
                }
                cRptViewer.ServerReport.Refresh();


            }
            catch (Exception ex)
            {
               // string errorCode = string.Empty;
               //// errorCode = Common.AddErrorLogs(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));
               // if (ConfigurationReader.IsShowGeneralMsg)
               // {
               //     ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationReader.GeneralMsg + "<br/>" + errorCode + "');", true);
               // }
               // else
               // {
               //     throw;

               // }
                // Common.AddErrorLog(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));

            }
        }
        
        public string GetReportPath()
        {
            StringBuilder sbReprotPath = new StringBuilder();
            // sbReprotPath.Append(RptConfig.ReportPath);

            sbReprotPath.Append(this.ReportName);
            // sbReprotPath.Append(".rdl");
            return sbReprotPath.ToString();
        }
        
        #endregion 
    }
}