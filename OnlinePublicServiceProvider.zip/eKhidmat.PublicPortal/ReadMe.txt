OTB Url
http://sms.punjab.gov.pk/api/cmpservice.svc/sendsmsdata/MTU=/Mw==
