﻿using eKhidmat.PublicPortal.ApplicationClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eKhidmat.PublicPortal.Layouts
{
    public partial class PrintQRCode : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            WebAPIPath.Value = AppConfigManager.EkhidmatAPIUrl;
        }
    }
}