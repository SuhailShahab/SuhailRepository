﻿using eKhidmat.PublicPortal.ApplicationClasses;
using PITB.FC.BE.RightsManager;
using PITB.FC.DAL.Reports;
using System;
using System.Data;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using PITB.FC.BE.Lookups;
using Microsoft.Reporting.WebForms;


namespace eKhidmat.PublicPortal.Layouts
{
    public partial class OnlineServiceAppStatusDetailReport : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
            pnlError.Visible = false;
            if (!IsPostBack)
            {
                UserProfileModel profileModel = null;
                if (HttpContext.Current.Session["UserProfile"] != null)
                {
                    profileModel = (UserProfileModel)HttpContext.Current.Session["UserProfile"];
                    lblName.Text = profileModel.DisplayName;


                    if (profileModel != null)
                    {
                        GetDivision(profileModel.UserID);
                        GetOnlineStatus(null);
                    }

                    //ddlTaskStatus.Items.Insert(0, new ListItem("Choose..", "0"));
                    ddlDivision.Items.Insert(0, new ListItem("ALL", "0"));
                    ddlDistrict.Items.Insert(0, new ListItem("ALL", "0"));

                    this.ddlFCCenter.Items.Insert(0, new ListItem("ALL", "0"));
                    this.ddlServices.Items.Insert(0, new ListItem("ALL", "0"));



                    // Date Criteria
                    dtpTo.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    //dtpFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToString("dd/") + "07/" + new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToString("yyyy");
                    dtpFrom.Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToString("dd/") + "07/2020";

                    DropDownRestriction(profileModel);
                    GetUserDefaultValues(profileModel);

                    ShowReport();
                }
            }
        }


        #region "Bind Dropdowns"


        /// <summary>
        ///  Bind Divison data in Drop down
        /// </summary>
        private void GetDivision(int? userID)
        {
            //ddlDivision.DataSource = GetDivisionInfo(4);
            ddlDivision.DataSource = GetDivisionInfo(userID.Value);
            ddlDivision.DataValueField = "DivisionID";
            ddlDivision.DataTextField = "Title";
            ddlDivision.DataBind();
            //ddlDivision.Items.Insert(0, new ListItem("Choose..", "0"));
        }


        /// <summary>
        ///  Bind District data in Drop down
        /// </summary>
        /// <param name="divisionID"></param>
        private void GetDistrict(int divisionID, int userID)
        {
            ddlDistrict.Items.Clear();
            // ddlDistrict.DataSource = GetDistrictInfo(divisionID, 4);
            ddlDistrict.DataSource = GetDistrictInfo(divisionID, userID);
            ddlDistrict.DataValueField = "DistrictID";
            ddlDistrict.DataTextField = "Title";
            ddlDistrict.DataBind();
            ddlDistrict.Items.Insert(0, new ListItem("ALL", "0"));
            ddlDistrict.SelectedIndex = 0;


        }

        /// <summary>
        /// Bind The Center Drop down list
        /// </summary>
        /// <param name="districtID"></param>
        /// <param name="userID"></param>
        public void GetFCCenter(int districtID, int userID)
        {
            ddlFCCenter.Items.Clear();
            //dlFCCenter.DataSource = GetFCLocationInfo(districtID, 4);
            ddlFCCenter.DataSource = GetFCLocationInfo(districtID, userID);
            ddlFCCenter.DataTextField = "Name";
            ddlFCCenter.DataValueField = "LocationID";
            ddlFCCenter.DataBind();
            ddlFCCenter.Items.Insert(0, new ListItem("ALL", "0"));
            ddlFCCenter.SelectedIndex = 0;

        }

        /// <summary>
        /// Get Online Status
        /// </summary>
        /// <param name="statusID"></param>
        public void GetOnlineStatus(int? statusID)
        {
            this.ddlTaskStatus.Items.Clear();
            this.ddlTaskStatus.DataSource = GetOnlineStatusInfo(statusID);
            this.ddlTaskStatus.DataTextField = "Title";
            this.ddlTaskStatus.DataValueField = "StatusID";
            this.ddlTaskStatus.DataBind();
            this.ddlTaskStatus.Items.Insert(0, new ListItem("ALL", ""));
            this.ddlTaskStatus.SelectedIndex = 0;

        }

        /// <summary>
        /// Bind Service data in Drop down
        /// </summary>
        public void BindServices(int divisionID, int districtID, int locationID, int userID)
        {
            this.ddlServices.Items.Clear();
            //this.ddlServices.DataSource = GetServiceInfo(divisionID, districtID, locationID, 4);
            this.ddlServices.DataSource = GetServiceInfo(divisionID, districtID, locationID, userID);
            this.ddlServices.DataTextField = "Title";
            this.ddlServices.DataValueField = "ServiceID";
            this.ddlServices.DataBind();
            this.ddlServices.Items.Insert(0, new ListItem("ALL", "0"));
            this.ddlServices.SelectedIndex = 0;
        }
        #endregion


        #region "Methods"

        /// <summary>
        /// Set the Default  user seeting
        /// </summary>
        /// <param name="profileModel"></param>
        private void GetUserDefaultValues(UserProfileModel profileModel)
        {

            if (profileModel.DivisionID > 0)
            {
                ddlDivision.SelectedValue = profileModel.DivisionID.ToString();
                GetDistrict(Convert.ToInt32(ddlDivision.SelectedValue), profileModel.UserID);
                SetDivisionDistrict(Convert.ToInt32(ddlDivision.SelectedValue));
            }

            if (profileModel.DistrictID > 0)
            {
                ddlDistrict.SelectedValue = profileModel.DistrictID.ToString();
                ddlDistrict_SelectedIndexChanged("", null);
            }

            if (profileModel.FCLocationID > 0)
            {
                ddlFCCenter.SelectedValue = profileModel.FCLocationCode;
            }
            BindServices(profileModel.DivisionID, profileModel.DistrictID, profileModel.FCLocationID, profileModel.UserID);

            if (!Convert.IsDBNull(profileModel.ServiceCode))
            {
                ddlServices.SelectedValue = profileModel.ServiceCode.ToString();
            }
            else
            {
                ddlServices.SelectedValue = "0";
            }



        }

        /// <summary>
        ///  Ristrict the User on the basid of list
        /// </summary>
        /// <param name="profileModel"></param>
        private void DropDownRestriction(UserProfileModel profileModel)
        {
            int? divisionID = profileModel.DivisionID;
            int fcLocationID = profileModel.FCLocationID;
            int? districtID = profileModel.DistrictID;

            if (divisionID.HasValue && divisionID.Value > 0)
            {
                ddlDivision.SelectedValue = divisionID.ToString();
                ddlDivision.Enabled = false;
                ddlDivision_SelectedIndexChanged("", null);

                if (districtID.HasValue && districtID.Value > 0)
                {
                    this.ddlDistrict.SelectedValue = districtID.Value.ToString();
                    ddlDistrict_SelectedIndexChanged("", null);
                    this.ddlDistrict.Enabled = false;
                }
                else
                    this.ddlDistrict.Enabled = true;

                if (fcLocationID > 0)
                {
                    this.ddlFCCenter.SelectedValue = Convert.ToString(fcLocationID);
                    ddlFCCenter.Enabled = false;
                }
                else
                    this.ddlFCCenter.Enabled = true;
            }
            else
            {

                ddlDivision.Enabled = true;
                ddlDivision.SelectedIndex = 0;
                this.ddlDistrict.Enabled = true;
                this.ddlDistrict.SelectedIndex = 0;

            }

        }


        // This method used to set the District based upon Division
        /// </summary>
        /// <param name="DivisionID"></param>
        private void SetDivisionDistrict(int DivisionID)
        {
            foreach (ListItem item in ddlDivision.Items)
            {
                if (Convert.ToInt32(item.Value) == DivisionID)
                {
                    foreach (ListItem districtItem in ddlDistrict.Items)
                    {
                        if (item.Text == districtItem.Text)
                        {
                            ddlDistrict.SelectedValue = districtItem.Value;
                            return;
                        }
                    }
                }

            }
        }

        /// <summary>
        /// Show the  report on the basis of filter Criteria
        /// </summary>
        private void ShowReport()
        {

            try
            {

                UserProfileModel profileModel = null;
                if (HttpContext.Current.Session["UserProfile"] != null)
                {
                    profileModel = (UserProfileModel)HttpContext.Current.Session["UserProfile"];



                    eKhidmat.PublicPortal.Layouts.Reports.ucReportViewer viewer = (eKhidmat.PublicPortal.Layouts.Reports.ucReportViewer)this.ucReportViewer1;


                    viewer.ReportName = "OnlineServiceAppStatusDetail";

                    // add the parameters
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();
                    //if (ddlDivision.SelectedValue != null && ddlDivision.SelectedValue != "0")
                    parameters.Add(new ReportParameter("Division", this.ddlDivision.SelectedItem.Text));
                    //if (ddlDistrict.SelectedValue != null && ddlDistrict.SelectedValue != "0")
                    parameters.Add(new ReportParameter("District", this.ddlDistrict.SelectedItem.Text));

                    if (ddlFCCenter.SelectedValue != null && ddlFCCenter.SelectedValue != "0")
                        parameters.Add(new ReportParameter("FCLocation", this.ddlFCCenter.SelectedItem.Text));

                    if (ddlTaskStatus.SelectedValue != null && ddlTaskStatus.SelectedValue != "0")
                        parameters.Add(new ReportParameter("TaskStatus", this.ddlTaskStatus.SelectedItem.Text));


                    //if (ddl TaskStatus.SelectedValue != null && ddlTaskStatus.SelectedValue != "")
                    //    parameters.Add(new ReportParameter("TaskStatus", this.ddlTaskStatus.SelectedItem.Text));

                    //if (ParamDtFrom != null && ParamDtTo != null)
                    //{
                    //    parameters.Add(new ReportParameter("FromDate",  ParamDtFrom.ToString()));
                    //    parameters.Add(new ReportParameter("ToDate", ParamDtTo.ToString()));
                    //}
                    //else
                    //{
                    parameters.Add(new ReportParameter("FromDate", ConvertDateFormat(dtpFrom.Value).ToString()));
                    parameters.Add(new ReportParameter("ToDate", ConvertDateFormat(dtpTo.Value).ToString()));
                    //}

                    parameters.Add(new ReportParameter("UserName", profileModel.UserName));


                    if (ddlDivision.SelectedValue != null && ddlDivision.SelectedValue != "0")
                        profileModel.DivisionID = Convert.ToInt32(ddlDivision.SelectedValue);
                    else
                        profileModel.DivisionID = 0;


                    if (ddlDistrict.SelectedValue != null && ddlDistrict.SelectedValue != "0")
                        profileModel.DistrictID = Convert.ToInt32(ddlDistrict.SelectedValue);
                    else
                        profileModel.DistrictID = 0;

                    if (ddlFCCenter.SelectedValue != null && ddlFCCenter.SelectedValue != "0")
                        profileModel.FCLocationID = Convert.ToInt32(ddlFCCenter.SelectedValue);
                    else
                        profileModel.FCLocationID = 0;

                    if (ddlServices.SelectedValue != null && ddlServices.SelectedValue != "0")
                        profileModel.ServiceID = Convert.ToInt32(ddlServices.SelectedValue);
                    else
                        profileModel.ServiceID = 0;

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    int? SelectTaskStatusID = 0;
                    if (ddlTaskStatus.SelectedIndex > 0) SelectTaskStatusID = Convert.ToInt32(ddlTaskStatus.SelectedValue);
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("ds", GetServiceDataTableDB(parameters, profileModel, dtpFrom.Value, dtpTo.Value, SelectTaskStatusID)));
                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                if (AppConfigManager.IsShowGeneralMsg)
                {
                    lblError.Text = AppConfigManager.GeneralErrorMessage + " " + errorCode;
                    pnlError.Visible = true;

                }
                else
                {
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
            }




        }


        #endregion

        #region "Dropdown Events"

        /// <summary>
        ///  Division drop down selected Index change event call when any change in dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlDivision_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlDivision.SelectedIndex > 0)
                {
                    UserProfileModel profileModel = null;
                    if (HttpContext.Current.Session["UserProfile"] != null)
                    {
                        profileModel = (UserProfileModel)HttpContext.Current.Session["UserProfile"];
                    }
                    if (profileModel != null)
                    {
                        GetDistrict(Convert.ToInt32(ddlDivision.SelectedValue), profileModel.UserID);
                        SetDivisionDistrict(Convert.ToInt32(ddlDivision.SelectedValue));

                    }

                    ddlDistrict_SelectedIndexChanged(sender, e);
                }
                else
                {
                    ddlDistrict.Items.Clear();
                    // ddlDistrict.ClearSelection();
                    ddlDistrict.Items.Insert(0, new ListItem("ALL", "0"));
                    ddlDistrict.SelectedIndex = 0;

                    ddlFCCenter.Items.Clear();
                    ddlFCCenter.Items.Insert(0, new ListItem("ALL", "0"));
                    ddlFCCenter.SelectedIndex = 0;

                }
                ddlDivision.Focus();

            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        ///  District drop down selected Index change event call when any change in dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlDistrict.SelectedIndex > 0)
                {
                    UserProfileModel profileModel = null;
                    if (HttpContext.Current.Session["UserProfile"] != null)
                    {
                        profileModel = (UserProfileModel)HttpContext.Current.Session["UserProfile"];
                    }

                    if (profileModel != null)
                        GetFCCenter(Convert.ToInt32(ddlDistrict.SelectedValue), profileModel.UserID);

                    ddlFCCenter_SelectedIndexChanged(sender, e);
                }
            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        ///  District drop down selected Index change event call when any change in dropdown
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlFCCenter_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //if (ddlFCCenter.SelectedIndex > 0)
                //{
                UserProfileModel profileModel = null;
                if (HttpContext.Current.Session["UserProfile"] != null)
                {
                    profileModel = (UserProfileModel)HttpContext.Current.Session["UserProfile"];
                }

                if (profileModel != null)
                    BindServices(Convert.ToInt32(ddlDivision.SelectedValue), Convert.ToInt32(ddlDistrict.SelectedValue), Convert.ToInt32(ddlFCCenter.SelectedValue), profileModel.UserID);
                // }
            }
            catch (Exception ex)
            {

            }
        }
        #endregion

        #region "Button Click Events"

        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            ShowReport();

        }

        #endregion


        #region Private Methods

        /// 
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetServiceDataTableDB(List<ReportParameter> parameters, UserProfileModel profileModel, string dtpFrom, string dtpTo, int? statusID)
        {
            DataTable dt = null;

            dt = GetRptOnlineServiceAppStatusDetail(profileModel, dtpFrom, dtpTo, statusID);

            //dt = GetRptGeneralServiceInfo(4);

            if (dt.Rows.Count > 0)
                parameters.Add(new ReportParameter("CheckRecord", ""));
            else
                parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

            return dt;
        }


        /// <summary>
        /// Set the Data info
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public DateTime ConvertDateFormat(string value)
        {
            DateTime Date = new DateTime();

            string[] arrValue = value.Split('/');
            if (arrValue.Length == 3)
            {
                Date = new DateTime(Convert.ToInt32(arrValue[2]), Convert.ToInt32(arrValue[1]), Convert.ToInt32(arrValue[0]));
            }

            return Date;
        }

        /// <summary>
        /// Get te Reports list
        /// </summary>
        /// <param name="divisionID"></param>
        /// <param name="districtID"></param>
        /// <param name="locationID"></param>
        /// <param name="userID"></param>
        /// <param name="dtpFrom"></param>
        /// <param name="dtpTo"></param>
        /// <returns></returns>
        private DataTable GetRptOnlineServiceAppStatusDetail(UserProfileModel profileModel, string dtpFrom, string dtpTo, int? taskStatusID)
        {
            ReportParameters rpParam = new ReportParameters();
            rpParam.DivisionID = profileModel.DivisionID;
            rpParam.DistrictID = profileModel.DistrictID;
            rpParam.LocationID = profileModel.FCLocationID;
            rpParam.ServiceID = profileModel.ServiceID;
            rpParam.TaskStatusID = taskStatusID;
            rpParam.UserID = profileModel.UserID;
            rpParam.DtpFrom = dtpFrom;
            rpParam.DtpTo = dtpTo;

            return PostAPIData(rpParam, "GetRptOnlineServiceAppStatusDetail");
        }


        /// <summary>
        /// Get the Division info
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        private DataTable GetDivisionInfo(int userID)
        {
            ReportParameters rpParam = new ReportParameters();
            rpParam.UserID = userID;

            return PostAPIData(rpParam, "GetDivision");
        }

        /// <summary>
        /// Get the DIstrict info
        /// </summary>
        /// <param name="divisionID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        private DataTable GetDistrictInfo(int divisionID, int userID)
        {
            ReportParameters rpParam = new ReportParameters();
            rpParam.DivisionID = divisionID;
            rpParam.UserID = userID;

            return PostAPIData(rpParam, "GetDistirctByID");
        }

        private DataTable GetOnlineStatusInfo(int? statusID)
        {
            ReportParameters rpParam = new ReportParameters();
            rpParam.TaskStatusID = statusID;
            return PostAPIData(rpParam, "GetOnlineStatus");
        }
        /// <summary>
        /// Get the Center info
        /// </summary>
        /// <param name="districtID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        private DataTable GetFCLocationInfo(int districtID, int userID)
        {
            ReportParameters rpParam = new ReportParameters();
            rpParam.DistrictID = districtID;
            rpParam.UserID = userID;

            return PostAPIData(rpParam, "GetLocationByDistrictandUserID");
        }

        /// <summary>
        /// Get the Service Info
        /// </summary>
        /// <param name="divisionID"></param>
        /// <param name="districtID"></param>
        /// <param name="locationID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        private DataTable GetServiceInfo(int divisionID, int districtID, int locationID, int userID)
        {
            ReportParameters rpParam = new ReportParameters();
            rpParam.DivisionID = divisionID;
            rpParam.DistrictID = districtID;
            rpParam.LocationID = locationID;
            rpParam.UserID = userID;

            return PostAPIData(rpParam, "GetAvailServicesByUserID");
        }


        /// <summary>
        /// Get the API List data
        /// </summary>
        /// <param name="rpParams"></param>
        /// <param name="methodName"></param>
        /// <returns></returns>
        private DataTable PostAPIData(ReportParameters rpParams, string methodName)
        {

            try
            {
                if (!string.IsNullOrEmpty(AppConfigManager.EkhidmatAPIUrl))
                {

                    // serailze model object to json string
                    DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(ReportParameters));
                    MemoryStream mem = new MemoryStream();
                    ser.WriteObject(mem, rpParams);
                    string Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                    string serviceURL = AppConfigManager.EkhidmatAPIUrl + "api/Report/" + methodName;

                    using (WebClient wc = new WebClient())
                    {
                        wc.Headers["Content-type"] = "application/json";
                        wc.Encoding = Encoding.UTF8;
                        wc.Headers.Add("Authorization", "Bearer" + HttpContext.Current.Session["AccessToken"]);
                        Uri address = new Uri(serviceURL);
                        var AccessToken = wc.UploadString(address, "POST", Data);
                        DataTable AccessView = JsonConvert.DeserializeObject<DataTable>(AccessToken);
                        return AccessView;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }
        #endregion

    }
}