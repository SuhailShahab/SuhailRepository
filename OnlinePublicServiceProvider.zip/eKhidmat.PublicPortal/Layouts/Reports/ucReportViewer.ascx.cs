﻿using eKhidmat.PublicPortal.ApplicationClasses;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eKhidmat.PublicPortal.Layouts.Reports
{
    public partial class ucReportViewer : System.Web.UI.UserControl
    {
        #region Custom Properties

        public string ReportName { get; set; }

        public List<Microsoft.Reporting.WebForms.ReportParameter> ParamList { get; set; }

        public List<Microsoft.Reporting.WebForms.ReportDataSource> DataSourceList { get; set; }

        private string testProperty;

        public string TestProperty
        {
            get { return testProperty; }
            set { testProperty = value; }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        #region Custom Methods

        public void LoadLocalReport()
        {


            try
            {
                cRptViewer1.Width = Unit.Pixel(1096);
                cRptViewer1.Height = Unit.Pixel(700);

                // Update report and refresh
                cRptViewer1.LocalReport.ReportPath = this.MapPath("/Layouts/Reports/Reports/"+ this.GetReportPath() + ".rdlc");
                
                //Server.MapPath("~/LAYOUTS/PITBFC/Reports/Reports/" + this.GetReportPath() + ".rdlc");  
                //Server.MapPath("~") + "/LAYOUTS/PITBFC/Reports/Reports/" + this.GetReportPath() + ".rdlc";

                cRptViewer1.LocalReport.EnableExternalImages = true; // Sajjad Aslam 22-Aug-2017 (for making dynamic report logo)
                if (this.ParamList != null && this.ParamList.Count > 0)
                {
                    cRptViewer1.LocalReport.SetParameters(this.ParamList);
                }
                cRptViewer1.LocalReport.DataSources.Clear();
                if (this.DataSourceList != null && this.DataSourceList.Count > 0)
                {
                    for (int i = 0; i < this.DataSourceList.Count; i++)
                    {
                        cRptViewer1.LocalReport.DataSources.Add(this.DataSourceList[i]);
                    }
                }

                cRptViewer1.LocalReport.Refresh();

                //   ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "AddPrintButtonScript", "AddPrintButton();", true);

            }
            catch (Exception ex)
            {
                throw ex;

                //string errorCode = string.Empty;
                //errorCode = Common.AddErrorLogs(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));
                //if (ConfigurationReader.IsShowGeneralMsg)
                //{
                //    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationReader.GeneralMsg + "<br/>" + errorCode + "');", true);
                //}
                //else
                //{
                //    throw;

                //}
                //Common.AddErrorLog(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));

            }
        }

        public void LoadReport()
        {


            try
            {
                //if (string.IsNullOrEmpty(this.ReportName) && string.IsNullOrEmpty(this.ServiceCode))
                //{
                //   // lblErrorMessage.Text = CustomMsg.MissingReportName;
                //    return;
                // }
                ReportServerCredentials objReportServerCredentials = null;
                //Credentail Settting
                objReportServerCredentials = new ReportServerCredentials(RptConfig.UserNameCredientail, RptConfig.PasswordCredientail, RptConfig.ExtSPSiteName);

                cRptViewer1.Visible = true;
                //if (RptConfig.ResetReportViewer.ToString() == "1")
                //    cRptViewer1.Reset();

                //cRptViewer1.Width = Unit.Percentage(100);
                //cRptViewer1.Height = Unit.Percentage(100);
                cRptViewer1.ProcessingMode = ProcessingMode.Remote;
                cRptViewer1.ServerReport.ReportServerUrl = new Uri(RptConfig.ReportServer);

                //Assign Credential
                cRptViewer1.ServerReport.ReportServerCredentials = objReportServerCredentials;
                cRptViewer1.ServerReport.ReportPath = this.GetReportPath();


                if (this.ParamList != null && this.ParamList.Count > 0)
                {
                    cRptViewer1.ServerReport.SetParameters(this.ParamList);
                }
                cRptViewer1.ServerReport.Refresh();


            }
            catch (Exception ex)
            {
                //string errorCode = string.Empty;
                //errorCode = Common.AddErrorLogs(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));
                //if (ConfigurationReader.IsShowGeneralMsg)
                //{
                //    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationReader.GeneralMsg + "<br/>" + errorCode + "');", true);
                //}
                //else
                //{
                //    throw;

                //}
                // Common.AddErrorLog(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));

            }
        }
        public string GetReportPath()
        {
            StringBuilder sbReprotPath = new StringBuilder();
            // sbReprotPath.Append(RptConfig.ReportPath);

            sbReprotPath.Append(this.ReportName);
            // sbReprotPath.Append(".rdl");
            return sbReprotPath.ToString();
        }
        #endregion
    }
}
