﻿using eKhidmat.API.Common;
using eKhidmat.PublicPortal.ApplicationClasses;
using Newtonsoft.Json;
using PITB.FC.BE;
using PITB.FC.BE.Common;
using PITB.FC.BE.Construction;
using PITB.FC.BE.RightsManager;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eKhidmat.PublicPortal.Layouts
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

    }
}