﻿using eKhidmat.PublicPortal.ApplicationClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eKhidmat.PublicPortal.Layouts
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                HiddenField hiddenWebAPIPath = (HiddenField)Page.Master.FindControl("WebAPIPath");

                if(hiddenWebAPIPath != null)
                {
                    string token = hiddenWebAPIPath.Value;
                    HttpContext.Current.Session["AccessToken"] = token;

                    string navigateUrl = "/Layouts/CitizenDashboard";
                    ScriptManager.RegisterStartupScript(this, GetType(), "Msg", "toastr.info('You have been registered successfully.');", true);
                    ScriptManager.RegisterStartupScript(this, GetType(), "AccessToken", "localStorage.setItem('AccessToken', '" + token + "');", true);
                    ScriptManager.RegisterStartupScript(this, GetType(), "Redirect", "window.location='" + navigateUrl + "';", true);
                }
            }
            ScriptManager.RegisterStartupScript(this, GetType(), "AccessToken", "localStorage.setItem('IsAllowOTP', '" + AppConfigManager.IsAllowOTP_CP + "');", true);
        }
    }
}