﻿using eKhidmat.PublicPortal.Common;
using PITB.eKhidmat.ApplicationClasses;
using PITB.FC.BE.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eKhidmat.PublicPortal.Layouts
{
    public partial class ScrutinizerDashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    // check the current user have rights to access to the page
                    UserProfileModel userProfileModel = CommonFunction.GetCurrentUserSession();

                    if (userProfileModel != null && userProfileModel.UserPageAccessRightsList != null && userProfileModel.UserPageAccessRightsList.Count > 0)
                    {
                        if (!userProfileModel.UserPageAccessRightsList.Contains(PageNames.ScrutinizerDashboard))
                        {
                            Response.Redirect("/Layouts/Error.aspx?Code=404=Access Page Denied", true);
                        }

                    }
                    else
                    {
                        Response.Redirect("/Layouts/Error.aspx?Code=404=Access Page Denied", true);
                    }
                }
            }
            catch
            {

            }
            
        }
    }
}