﻿using eKhidmat.API.Common;
using eKhidmat.PublicPortal.ApplicationClasses;
using eKhidmat.PublicPortal.Common;
using Newtonsoft.Json;
using PITB.eKhidmat.ApplicationClasses;
using PITB.FC.BE;
using PITB.FC.BE.Common;
using PITB.FC.BE.Construction;
using PITB.FC.BE.RightsManager;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace eKhidmat.PublicPortal.Layouts
{
    public partial class ScrutinizerLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lnkbtnLogin_Click(object sender, EventArgs e)
        {
            string loginName = string.Empty;
            string password = string.Empty;
            ResponseModel<TokenResponseModel> responseResult = new ResponseModel<TokenResponseModel>();
            try
            {
                loginName = txtLoginName.Text;
                password = txtPassword.Text;
               
               if (string.IsNullOrEmpty(loginName))
               {
                   //((Label)this.Master.FindControl("PlaceHolderMain").FindControl("lblFailureText")).Text = "Please enter your user name";
                   ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info('Please enter your username');", true);
                   return;
               }
               else if (string.IsNullOrEmpty(password))
               {
                   //((Label)this.Master.FindControl("PlaceHolderMain").FindControl("lblFailureText")).Text = "Please enter your password";
                   ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info('Please enter your password');", true);
                   return;
               }


                ResponseModel<TokenResponseModel> response = this.ScrutinizedLogin(new LoginViewModel(loginName, password,null));
               
                if (response.response_header.status != GlobalDeclarations.ResponseType.Success.ToString())
                {
                    if (response.response_header.status == GlobalDeclarations.ResponseType.Warning.ToString())
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info('" + response.response_header.message + "');", true);
                        return;
                    }

                    if (AppConfigManager.IsShowGeneralMsg)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                        return;
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(response.response_header.message) + "');", true);
                        return;
                    }
                }
                
               if (!string.IsNullOrEmpty(response.response_detail.AccessToken))
               {
                   ResponseModel<UserProfileModel> profileResponse = this.GetUserProfile(response.response_detail.AccessToken);
                    if(profileResponse != null && profileResponse.response_header != null)
                    {
                        if(profileResponse.response_header.status == CommonAPI.GetEnumDescription(GlobalDeclarations.ResponseType.Success))
                        {
                            HttpContext.Current.Session["UserProfile"] = profileResponse.response_detail;
                            HttpContext.Current.Session["AccessToken"] = response.response_detail.AccessToken;
                            DateTime cookieTime = DateTime.Now.AddDays(CookeeExpiryTime.ExpiryTime);
                            HttpContext.Current.Response.Cookies["AccessToken"].Value = response.response_detail.AccessToken;
                            HttpContext.Current.Response.Cookies["AccessToken"].Expires = cookieTime;

                            string navigateUrl = "/Layouts/ScrutinizerDashboard.aspx";
                            ScriptManager.RegisterStartupScript(this, GetType(), "AccessToken", "localStorage.setItem('AccessToken', '" + response.response_detail.AccessToken + "');", true);
                            ScriptManager.RegisterStartupScript(this, GetType(), "Redirect", "window.location='" + navigateUrl + "';", true);
                            //  Response.Redirect("/Layouts/ScrutinizerDashboard.aspx", true);
                            ///Save session in databse
                            this.SaveSessionState(profileResponse.response_detail);
                        }
                        else
                        {
                           if(AppConfigManager.IsShowGeneralMsg)
                            {                                
                               ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('"+ AppConfigManager.GeneralErrorMessage + "');", true);
                                return;
                            }
                           else
                            {
                                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('"+ CommonFunction.FixQuotesFortoastr(profileResponse.response_header.message)+ "');", true);
                                return;
                            }
                           
                        }
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info('Login name or password is invalid.Please try again.');", true);
                        return;
                    }
                    if (profileResponse != null && profileResponse.response_header != null && profileResponse.response_header.status == CommonAPI.GetEnumDescription(GlobalDeclarations.ResponseType.Success))
                    {
                        HttpContext.Current.Session["UserProfile"] = profileResponse.response_detail;
                        HttpContext.Current.Session["AccessToken"] = response.response_detail.AccessToken;

                        string navigateUrl = "/Layouts/ScrutinizerDashboard.aspx";
                        ScriptManager.RegisterStartupScript(this, GetType(), "AccessToken", "localStorage.setItem('AccessToken', '" + response.response_detail.AccessToken + "');", true);
                        ScriptManager.RegisterStartupScript(this, GetType(), "Redirect", "window.location='" + navigateUrl + "';", true);
                        //  Response.Redirect("/Layouts/ScrutinizerDashboard.aspx", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info('Login name or password is invalid.Please try again.');", true);
                        return;
                    }

               }
               else
               {
                   ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info('Username or password is invalid.Please try again.');", true);
                   return;
               }
                    //Navigate to Scrutinzer Dashbaord
               
            }
            catch(Exception ex)
            {
                if (AppConfigManager.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                    return;
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(ex.Message) + "');", true);
                    return;
                }
            }
        }

        #region Custom Methods
        internal void SaveSessionState(UserProfileModel userProfileModel)
        {

            string jsonUser = JsonConvert.SerializeObject(userProfileModel);
            LazyBaseSingletonUI<SessionStateManager>.Instance.SaveSessionState(Session.SessionID, jsonUser, userProfileModel.UserName, null);

        }
        private ResponseModel<TokenResponseModel> ScrutinizedLogin(LoginViewModel loginViewModel)
        {
           
            try
            {
                ResponseModel<TokenResponseModel> response = new ResponseModel<TokenResponseModel>();
                response.response_detail = new TokenResponseModel();

                string webAPIPath = AppConfigManager.EkhidmatAPIUrl; 

                if (webAPIPath != null && webAPIPath != "")
                {
                    
                    string Data = JsonConvert.SerializeObject(loginViewModel);

                    // process the request and get response as string
                    string serviceURL = webAPIPath.TrimEnd('/') + "/api/PortalAccount/ScrutinizedLogin";

                    WebClient webClient = new WebClient();
                    webClient.Headers["Content-type"] = "application/json";
                    webClient.Encoding = Encoding.UTF8;

                    Uri address = new Uri(serviceURL);
                    var accessToken = webClient.UploadString(address, "POST", Data);

                    response = JsonConvert.DeserializeObject<ResponseModel<TokenResponseModel>>(accessToken);
                    return response;
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
               // errorCode = Common.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), 0, ServiceCodes.none, PageNames.SignIn));
            }

            return null;
        }


        private ResponseModel<UserProfileModel> GetUserProfile(string accessToken)
        {
            try
            {
                if (!string.IsNullOrEmpty(AppConfigManager.EkhidmatAPIUrl))
                {
                    // process the request and get response as string
                    string serviceURL = AppConfigManager.EkhidmatAPIUrl + "api/Portal/GetUserProfile";

                    WebClient webClient = new WebClient();
                    //webClient.Headers["Content-type"] = "application/json";
                    webClient.Encoding = Encoding.UTF8;
                    webClient.Headers.Add("Authorization", "Bearer" + accessToken);

                    Uri address = new Uri(serviceURL);
                    var profile = webClient.DownloadString(address);

                    ResponseModel<UserProfileModel> response = JsonConvert.DeserializeObject<ResponseModel<UserProfileModel>>(profile);
                    return response;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        public class LoginViewModel
        {
            public string AccessToken { get; set; }
            public string UserName { get; set; }
            public string Password { get; set; }
            public string ClientIP { get; set; }
            public string LocationMappedIPAddress { get; set; }

            public LoginViewModel()
            {

            }
            public LoginViewModel(string userName, string password,string clienIP)
            {
                this.UserName = userName;
                this.Password = password;
                this.ClientIP = clienIP;


            }
        }

        public class LoginAccessViewModel
        {
            public string accessToken { get; set; }
        }

        #endregion 


    }
}