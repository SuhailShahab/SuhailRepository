﻿using eKhidmat.PublicPortal.Common;

// =================================================================================================================================
// Create by:	<sufyan ali>
// Create date: <27-08-2020 01:54:49PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
namespace eKhidmat.PublicPortal.ViewModels
{
    public class LoginViewModel
    {
        public string AccessToken { get; set; }
        public string ApplicantCNIC { get; set; }
        public string Password { get; set; }
        public string ClientIP { get; set; }
        public string LocationMappedIPAddress { get; set; }
    }

    public class LoginAccessViewModel
    {
        [MappingInfo(ColumnName = "code")]
        public string Code { get; set; }

        [MappingInfo(ColumnName = "OTP")]
        public int OTP { get; set; }

        [MappingInfo(ColumnName = "AccessToken")]
        public string AccessToken { get; set; }

        [MappingInfo(ColumnName = "message")]
        public string Message { get; set; }
    }
}