﻿using eKhidmat.API.Common;
using eKhidmat.PublicPortal.ApplicationClasses;
using eKhidmat.PublicPortal.Common;
using Newtonsoft.Json;
using PITB.eKhidmat.ApplicationClasses;
using PITB.FC.BE.Common;
using PITB.FC.BE.RightsManager;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eKhidmat.PublicPortal
{
    public partial class LoginNew : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (IsPostBack)
                {
                    HiddenField hiddenWebAPIPath = (HiddenField)Page.Master.FindControl("WebAPIPath");

                    if (hiddenWebAPIPath != null)
                    {
                        string token = hiddenWebAPIPath.Value;
                        HttpContext.Current.Session["AccessToken"] = token;

                        ScriptManager.RegisterStartupScript(this, GetType(), "AccessToken", "localStorage.setItem('AccessToken', '" + token + "');", true);

                        DateTime cookieTime = DateTime.Now.AddHours(CookeeExpiryTime.ExpiryTime);
                        HttpContext.Current.Response.Cookies["AccessToken"].Value = token;
                        HttpContext.Current.Response.Cookies["AccessToken"].Expires = cookieTime;

                        string navigateUrl = string.Empty;
                        UserProfileModel profileModel = CommonFunction.GetCurrentUserSession();

                        if (profileModel != null)
                        {
                            if (profileModel.UserType == (int)GlobalDeclarations.UserTypes.ScrutinizedPortal)
                            {
                                navigateUrl = "/Layouts/ScrutinizerDashboard";
                            }
                            else
                            {
                                navigateUrl = "/Layouts/CitizenDashboard";
                               
                            }

                            //Save session in database
                            this.SaveSessionState(profileModel);

                            ScriptManager.RegisterStartupScript(this, GetType(), "Redirect", "window.location='" + navigateUrl + "';", true);
                        }
                        else
                        {
                            Response.Redirect("~/Login.aspx");
                        }
                    }
                }

                ScriptManager.RegisterStartupScript(this, GetType(), "IsAllowOTP", "localStorage.setItem('IsAllowOTP', '" + AppConfigManager.IsAllowOTP_CP + "');", true);
            }
            catch (Exception ex)
            {
                if (AppConfigManager.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(ex.Message) + "');", true);
                }
            }

        }

        internal void SaveSessionState(UserProfileModel userProfileModel)
        {
            string jsonUser = JsonConvert.SerializeObject(userProfileModel);
            LazyBaseSingletonUI<SessionStateManager>.Instance.SaveSessionState(Session.SessionID, jsonUser, userProfileModel.UserName, null);
        }
    }
}