﻿//using eKhidmat.PublicPortal.ApplicationClasses;
//using Newtonsoft.Json;
//using PITB.eKhidmat.ApplicationClasses;
//using PITB.FC.BE.Common;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using System.Web.UI;
//using System.Web.UI.WebControls;
using eKhidmat.PublicPortal.ApplicationClasses;
using Newtonsoft.Json;
using PITB.eKhidmat.ApplicationClasses;
using PITB.FC.BE.Common;
using PITB.FC.BE.RightsManager;
using System;
using System.Web;
using System.Web.UI;

namespace eKhidmat.PublicPortal
{
    public partial class Site2 : System.Web.UI.MasterPage
    {
        public UserProfileModel profileModel { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            WebAPIPath.Value = AppConfigManager.EkhidmatAPIUrl;

            if (!IsPostBack)
            {
                this.profileModel = CommonFunction.GetCurrentUserSession();

                if (profileModel != null)
                {
                    string profileJson = string.Format("const userProfile= {0}", JsonConvert.SerializeObject(profileModel));
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", profileJson, true);

                    if (this.Page.GetType().Name == "default_aspx")
                    {
                        if (profileModel.UserType == (int)GlobalDeclarations.UserTypes.ScrutinizedPortal)
                        {
                            Response.Redirect("~/Layouts/ScrutinizerDashboard.aspx");
                        }
                        else
                        {
                            Response.Redirect("~/Layouts/CitizenDashboard.aspx");
                        }
                    }
                }
                else
                {
                    string currentPageName = this.Page.GetType().Name;
                    if (Request.Url.Host.StartsWith("sct.fc.punjab") && currentPageName != "layouts_scrutinizerlogin_aspx")
                    {
                        Response.Redirect("~/Layouts/ScrutinizerLogin.aspx");
                        return;
                    }

                    if (currentPageName != "login_aspx"
                        && currentPageName != "loginnew_aspx"
                        && currentPageName != "layouts_registration_aspx"
                        && currentPageName != "layouts_scrutinizerlogin_aspx"
                        && currentPageName != "layouts_changepassword_aspx"
                        && currentPageName != "layouts_error_aspx")
                    {
                        if (currentPageName.Contains("scrutinizer"))
                        {
                            Response.Redirect("~/Layouts/ScrutinizerLogin.aspx");
                        }
                        else
                        {
                            Response.Redirect("~/Login.aspx");
                        }
                    }
                }
            }
        }

    }
}