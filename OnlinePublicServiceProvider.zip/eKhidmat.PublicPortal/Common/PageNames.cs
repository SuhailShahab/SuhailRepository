﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace eKhidmat.PublicPortal.Common
{
    /// <summary>
    /// Value is MenuName for Table Feature table
    /// Value is StaticName for Table AppObjects
    /// Note Very Important
    ///Use values of MenuName for Feature table 
    ///Use values are StaticName for AppObjects
    /// </summary>
    /// 
    public class PageNames
    {
        public const string None = "None";
        public const string ScrutinizerDashboard = "ScrutinizerDashboard";
    }

    public class CookeeExpiryTime
    {
        public const int ExpiryTime = 8;
    }
}