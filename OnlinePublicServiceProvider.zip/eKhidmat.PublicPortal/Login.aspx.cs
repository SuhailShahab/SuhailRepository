﻿using eKhidmat.API.Common;
using eKhidmat.PublicPortal.ApplicationClasses;
using eKhidmat.PublicPortal.Common;
using eKhidmat.PublicPortal.ViewModels;
using Newtonsoft.Json;
using PITB.eKhidmat.ApplicationClasses;
using PITB.FC.BE;
using PITB.FC.BE.Common;
using PITB.FC.BE.RightsManager;
using System;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;

namespace eKhidmat.PublicPortal
{
    public partial class Login : System.Web.UI.Page
    {
        public int CitizenCount = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //ResponseModel<CitizenCountCountModel> count = GetUserCountFromAPI();
                //if (count != null)
                //    this.CitizenCount = count.response_detail.CitizenCount;
            }
            catch (Exception ex)
            {
                if (AppConfigManager.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(ex.Message), true);
                }
            }
        }

        protected void SubmitOTP_Click(object sender, EventArgs e)
        {
            try
            {
                string url = string.Empty;
                UserModel currentUser = new UserModel();

                if (!string.IsNullOrEmpty(txtOTP.Value) && Session["OTPCode"].ToString() == txtOTP.Value)
                {
                    txtCNICNo.Value = txtCNICNo.Value.Replace("-", "");
                    this.GetTokenFromAPI();
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info('Please enter valid OTP');", true);
                }
            }
            catch (Exception ex)
            {
                if (AppConfigManager.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(ex.Message) + "');", true);
                }
            }
        }

        protected void Login_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtCNICNo.Value))
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info('Please enter your CNIC No.');", true);
                    return;
                }
                else if (string.IsNullOrEmpty(txtpassword.Value))
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info('Please enter your password');", true);
                    return;
                }

                txtCNICNo.Value = txtCNICNo.Value.Replace("-", "");
                txtOTP.Value = string.Empty;

                if (!AppConfigManager.IsAllowOTP_CP)
                {
                    this.GetTokenFromAPI();
                }
                else
                {
                    HttpContext.Current.Session["Password"] = txtpassword.Value;
                    ResponseModel<TokenResponseOTPModel> otpResponse = this.GetLoginOTP(txtCNICNo.Value, txtpassword.Value);
                    if (otpResponse != null && otpResponse.response_header != null && otpResponse.response_header.status == CommonAPI.GetEnumDescription(GlobalDeclarations.ResponseType.Success))
                    {
                        HttpContext.Current.Session["OTPCode"] = otpResponse.response_detail.OTPCode;
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "timeout", "showModal()", true);
                    }
                    else
                    {
                        if (otpResponse != null)
                        {
                            txtOTP.Value = "";
                            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(otpResponse.response_header.message) + "');", true);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                if (AppConfigManager.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(ex.Message) + "');", true);
                }
            }
        }

        protected void RegenerateOTP_Click(object sender, EventArgs e)
        {
            try
            {
                if (Session["Password"] != null)
                {
                    txtCNICNo.Value = txtCNICNo.Value.Replace("-", "");
                    txtOTP.Value = string.Empty;

                    ResponseModel<TokenResponseOTPModel> otpResponse = this.GetLoginOTP(txtCNICNo.Value, Session["Password"].ToString());
                    if (otpResponse != null && otpResponse.response_header != null && otpResponse.response_header.status == CommonAPI.GetEnumDescription(GlobalDeclarations.ResponseType.Success))
                    {
                        HttpContext.Current.Session["OTPCode"] = otpResponse.response_detail.OTPCode;
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "timeout", "showModal()", true);
                    }
                    else
                    {
                        if (otpResponse != null)
                        {
                            txtOTP.Value = "";
                            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(otpResponse.response_header.message) + "');", true);
                        }
                        else
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (AppConfigManager.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(ex.Message) + "');", true);
                }
            }
        }

        #region Private Methods

        //internal void SaveSessionState(DataSet dtUser, string userName)
        //{

        //    string jsonUser = JsonConvert.SerializeObject(dtUser);

        //    LazyBaseSingletonBLL<SessionStateBLL>.Instance.SaveSessionState(Session.SessionID, jsonUser, userName, null);

        //}

        private ResponseModel<TokenResponseModel> GetAccessToken(string cnicno, string password)
        {
            try
            {
                if (!string.IsNullOrEmpty(AppConfigManager.EkhidmatAPIUrl))
                {
                    LoginViewModel login = new LoginViewModel();
                    login.ApplicantCNIC = cnicno.Replace("-", "");
                    login.Password = password;

                    // serailze model object to json string
                    DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(LoginViewModel));
                    MemoryStream mem = new MemoryStream();
                    ser.WriteObject(mem, login);
                    string Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                    string serviceURL = AppConfigManager.EkhidmatAPIUrl + "api/PortalAccount/CitizenLogin";

                    using (WebClient wc = new WebClient())
                    {
                        WebClient webClient = new WebClient();
                        webClient.Headers["Content-type"] = "application/json";
                        webClient.Encoding = Encoding.UTF8;

                        Uri address = new Uri(serviceURL);
                        var AccessToken = webClient.UploadString(address, "POST", Data);

                        ResponseModel<TokenResponseModel> AccessView = new JavaScriptSerializer().Deserialize<ResponseModel<TokenResponseModel>>(AccessToken);

                        return AccessView;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        private ResponseModel<TokenResponseOTPModel> GetLoginOTP(string cnicno, string password)
        {
            try
            {
                if (!string.IsNullOrEmpty(AppConfigManager.EkhidmatAPIUrl))
                {
                    LoginViewModel login = new LoginViewModel();
                    login.ApplicantCNIC = cnicno;
                    login.Password = password;

                    // serailze model object to json string
                    DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(LoginViewModel));
                    MemoryStream mem = new MemoryStream();
                    ser.WriteObject(mem, login);
                    string Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                    string serviceURL = AppConfigManager.EkhidmatAPIUrl + "api/PortalAccount/GetLoginOTP";

                    using (WebClient wc = new WebClient())
                    {
                        WebClient webClient = new WebClient();
                        webClient.Headers["Content-type"] = "application/json";
                        webClient.Encoding = Encoding.UTF8;

                        Uri address = new Uri(serviceURL);
                        string otp = webClient.UploadString(address, "POST", Data);

                        ResponseModel<TokenResponseOTPModel> AccessView = new JavaScriptSerializer().Deserialize<ResponseModel<TokenResponseOTPModel>>(otp);

                        return AccessView;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        private ResponseModel<UserProfileModel> GetUserProfile(string accessToken)
        {
            try
            {
                if (!string.IsNullOrEmpty(AppConfigManager.EkhidmatAPIUrl))
                {
                    // process the request and get response as string
                    string serviceURL = AppConfigManager.EkhidmatAPIUrl + "api/Portal/GetUserProfile";

                    WebClient webClient = new WebClient();
                    //webClient.Headers["Content-type"] = "application/json";
                    webClient.Encoding = Encoding.UTF8;
                    webClient.Headers.Add("Authorization", "Bearer" + accessToken);

                    Uri address = new Uri(serviceURL);
                    var profile = webClient.DownloadString(address);

                    ResponseModel<UserProfileModel> response = JsonConvert.DeserializeObject<ResponseModel<UserProfileModel>>(profile);
                    return response;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        private void GetTokenFromAPI()
        {
            string password = string.Empty;

            if (AppConfigManager.IsAllowOTP_CP)
            {
                password = Session["Password"].ToString();
            }
            else
            {
                if (!string.IsNullOrEmpty(txtpassword.Value))
                {
                    password = txtpassword.Value.ToString();
                }
                else if (Session["Password"] != null)
                {
                    password = Session["Password"].ToString();
                }

            }

            ResponseModel<TokenResponseModel> tokenResponse = this.GetAccessToken(txtCNICNo.Value, password);
            if (tokenResponse != null && tokenResponse.response_header != null && tokenResponse.response_header.status == CommonAPI.GetEnumDescription(GlobalDeclarations.ResponseType.Success))
            {
                //ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "timeoutkyc", "showkyc()", true);

                ResponseModel<UserProfileModel> profileResponse = this.GetUserProfile(tokenResponse.response_detail.AccessToken);
                if (profileResponse != null && profileResponse.response_header != null && profileResponse.response_header.status == CommonAPI.GetEnumDescription(GlobalDeclarations.ResponseType.Success))
                {
                    if (profileResponse.response_detail.IsUserVerified == true)
                    {
                        HttpContext.Current.Session["UserProfile"] = profileResponse.response_detail;

                        HttpContext.Current.Session["AccessToken"] = tokenResponse.response_detail.AccessToken;

                        DateTime cookieTime = DateTime.Now.AddHours(CookeeExpiryTime.ExpiryTime);//AddDays(1);
                        HttpContext.Current.Response.Cookies["AccessToken"].Value = tokenResponse.response_detail.AccessToken;
                        HttpContext.Current.Response.Cookies["AccessToken"].Expires = cookieTime;

                        ScriptManager.RegisterStartupScript(this, GetType(), "AccessToken", "localStorage.setItem('AccessToken', '" + tokenResponse.response_detail.AccessToken + "');", true);
                        string navigateUrl = string.Empty;

                        if (profileResponse.response_detail.UserType == (int)GlobalDeclarations.UserTypes.CitizenPortal)
                        {
                            navigateUrl = "/Layouts/CitizenDashboard";
                        }
                        else if (profileResponse.response_detail.UserType == (int)GlobalDeclarations.UserTypes.ScrutinizedPortal)
                        {
                            navigateUrl = "/Layouts/ScrutinizerDashboard";
                        }

                        //Save session in database
                        this.SaveSessionState(profileResponse.response_detail);

                        ScriptManager.RegisterStartupScript(this, GetType(), "LoginBoxHide", "$(\'.login-card-box\').hide();", true);
                        ScriptManager.RegisterStartupScript(this, GetType(), "Redirect", "window.location='" + navigateUrl + "';", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "timeoutkyc", "showkyc()", true);
                    }
                }
                else
                {
                    if (profileResponse != null)
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(profileResponse.response_header.message) + "');", true);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                    }
                }
            }
            else
            {
                if (tokenResponse != null)
                {
                    txtCNICNo.Value = "";
                    txtpassword.Value = "";
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + CommonFunction.FixQuotesFortoastr(tokenResponse.response_header.message) + "');", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('" + AppConfigManager.GeneralErrorMessage + "');", true);
                }
            }
        }
        internal void SaveSessionState(UserProfileModel userProfileModel)
        {

            string jsonUser = JsonConvert.SerializeObject(userProfileModel);
            LazyBaseSingletonUI<SessionStateManager>.Instance.SaveSessionState(Session.SessionID, jsonUser, userProfileModel.UserName, null);

        }
        private ResponseModel<CitizenCountCountModel> GetUserCountFromAPI()
        {
            if (!string.IsNullOrEmpty(AppConfigManager.EkhidmatAPIUrl))
            {
                // process the request and get response as string
                string serviceURL = AppConfigManager.EkhidmatAPIUrl + "api/PortalAccount/GetCitizenCount";

                WebClient webClient = new WebClient();
                //webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;

                Uri address = new Uri(serviceURL);
                var count = webClient.DownloadString(address);

                ResponseModel<CitizenCountCountModel> response = JsonConvert.DeserializeObject<ResponseModel<CitizenCountCountModel>>(count);
                return response;
            }
            return null;
        }
        #endregion
    }
}