﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Identity
{
    using Microsoft.AspNet.Identity.Owin;
    using Microsoft.Owin.Security;
    using System.Threading.Tasks;

    public class SignInService : SignInManager<ApplicationUser, int>
    {
        public SignInService(UserManager userManager, IAuthenticationManager authenticationManager) : base(userManager, authenticationManager)
        {

        }

        public override Task SignInAsync(ApplicationUser user, bool isPersistent, bool rememberBrowser)
        {
            return base.SignInAsync(user, isPersistent, rememberBrowser);
        }
    }
}