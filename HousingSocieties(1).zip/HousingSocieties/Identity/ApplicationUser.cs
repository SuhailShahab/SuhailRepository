﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Identity
{
    using Microsoft.AspNet.Identity;
    using Models;
    using Newtonsoft.Json;

    public class ApplicationUser : IUser<int>
    {
        public ApplicationUser()
        {
            this.Claims = new List<UserClaim>();
        }

        public ApplicationUser(string userName) : this()
        {
            this.UserName = userName;
        }

        public ApplicationUser(int id, string userName) : this()
        {
            this.Id = id;
            this.UserName = userName;
        }

        [MappingInfo(ColumnName = "UserID")]
        public int Id { get; set; }

        [MappingInfo(ColumnName = "UserName")]
        public string UserName { get; set; }

        [JsonIgnore]
        [MappingInfo(ColumnName = "Password")]
        public string PasswordHash { get; set; }

        [MappingInfo(ColumnName = "DisplayName")]
        public string DisplayName { get; set; }

        [MappingInfo(ColumnName = "UserTypeID")]
        public int? UserTypeID { get; set; }

        public int AccessFailedCount { get; set; }
        public IList<UserClaim> Claims { get; private set; }

    }
}