﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Identity
{
    using System.Security.Claims;
    using System.Threading.Tasks;
    using Microsoft.AspNet.Identity;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;
    using BLL.Lookup;
    using CommonUtility;

    public class UserStore :
        IUserStore<ApplicationUser, int>,
        IUserLockoutStore<ApplicationUser, int>,
        IUserPasswordStore<ApplicationUser, int>,
        IUserClaimStore<ApplicationUser, int>,
        IUserTwoFactorStore<ApplicationUser, int>
    {
        private string spConnectionString { get; set; }

        public UserStore()
        {
            //this.spConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString.ToString() + ";";
        }

        #region "UserStore"
        public Task CreateAsync(ApplicationUser user)
        {
            LazyBaseSingleton<UserBLL>.Instance.Create(user);
            return Task.FromResult(0);
        }

        public Task DeleteAsync(ApplicationUser user)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            //Dispose(true);
            GC.SuppressFinalize(this);
        }

        public Task<ApplicationUser> FindByIdAsync(int userId)
        {
            ApplicationUser user = LazyBaseSingleton<UserBLL>.Instance.GetByUserID(userId);

            return Task.FromResult(user);
        }

        public Task<ApplicationUser> FindByNameAsync(string userName)
        {
            ApplicationUser user = LazyBaseSingleton<UserBLL>.Instance.GetByUserName(userName);

            return Task.FromResult(user);
        }

        public Task UpdateAsync(ApplicationUser user)
        {
            LazyBaseSingleton<UserBLL>.Instance.Update(user);
            return Task.FromResult(0);
        }

        #endregion

        #region "PasswordStore"

        public Task<string> GetPasswordHashAsync(ApplicationUser user)
        {
            return Task.FromResult(user.PasswordHash);
        }

        public Task<bool> HasPasswordAsync(ApplicationUser user)
        {
            return Task.FromResult(user.PasswordHash != null);
        }

        public Task SetPasswordHashAsync(ApplicationUser user, string passwordHash)
        {
            user.PasswordHash = passwordHash;
            return Task.FromResult(0);
        }


        #endregion


        #region USERS - CLAIM STORE

        public Task AddClaimAsync(ApplicationUser user, System.Security.Claims.Claim claim)
        {
            if (user == null)
            {
                throw new ArgumentNullException("user");
            }

            if (claim == null)
            {
                throw new ArgumentNullException("claim");
            }

            if (user.Claims != null && user.Claims.Any(f => f.Value == claim.Value))
            {
                user.Claims.Add(new UserClaim(claim));
            }

            return Task.FromResult(0);
        }

        public Task<IList<System.Security.Claims.Claim>> GetClaimsAsync(ApplicationUser user)
        {
            if (user == null)
            {
                throw new ArgumentNullException("user");
            }

            return Task.FromResult<IList<System.Security.Claims.Claim>>(user.Claims.Select(clm => new System.Security.Claims.Claim(clm.Type, clm.Value)).ToList());
        }

        public Task RemoveClaimAsync(ApplicationUser user, System.Security.Claims.Claim claim)
        {
            if (user == null)
            {
                throw new ArgumentNullException("user");
            }

            if (claim == null)
            {
                throw new ArgumentNullException("user");
            }

            user.Claims.Remove(new UserClaim(claim));

            return Task.FromResult(0);
        }

        #endregion

        #region LockoutStore

        public Task<DateTimeOffset> GetLockoutEndDateAsync(ApplicationUser user)
        {
            throw new NotImplementedException();
        }

        public Task SetLockoutEndDateAsync(ApplicationUser user, DateTimeOffset lockoutEnd)
        {
            throw new NotImplementedException();
        }

        public Task<int> IncrementAccessFailedCountAsync(ApplicationUser user)
        {
            return Task.Factory.StartNew<int>(() => user.AccessFailedCount++);
        }

        public Task ResetAccessFailedCountAsync(ApplicationUser user)
        {
            user.AccessFailedCount = 0;
            return Task.FromResult(0);
        }

        public Task<int> GetAccessFailedCountAsync(ApplicationUser user)
        {
            return Task.Factory.StartNew<int>(() => user.AccessFailedCount);
        }

        public Task<bool> GetLockoutEnabledAsync(ApplicationUser user)
        {
            return Task.Factory.StartNew<bool>(() => false);
        }


        #endregion

        #region TwoFactor

        public Task SetLockoutEnabledAsync(ApplicationUser user, bool enabled)
        {
            throw new NotImplementedException();
        }

        public Task SetTwoFactorEnabledAsync(ApplicationUser user, bool enabled)
        {
            throw new NotImplementedException();
        }

        public Task<bool> GetTwoFactorEnabledAsync(ApplicationUser user)
        {
            return Task.Factory.StartNew<bool>(() => false);
        }

        #endregion
    }
}