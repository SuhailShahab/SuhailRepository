﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PITB.FC.HousingSocieties.Startup))]
namespace PITB.FC.HousingSocieties
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
