﻿using System;
using System.Linq;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using PITB.FC.HousingSocieties.Models;
using PITB.FC.HousingSocieties.BLL.Lookup;
using PITB.FC.HousingSocieties.CommonUtility;

namespace PITB.FC.HousingSocieties.Account
{
    public partial class Register : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            bool redirect = false;
            if (User.Identity.IsAuthenticated)
            {
                Identity.ApplicationUser loggedUser = LazyBaseSingleton<UserBLL>.Instance.GetByUserID(User.Identity.GetUserId<int>());
                if (!loggedUser.UserTypeID.HasValue || (loggedUser.UserTypeID.HasValue && loggedUser.UserTypeID.Value != 1))
                {
                    redirect = true;
                }

            }
            else
            {
                redirect = true;
            }

            if (redirect)
            {
                Response.Redirect("~/Layouts/HousingSocietyDashboard.aspx");
            }
        }

        protected void CreateUser_Click(object sender, EventArgs e)
        {
            var manager = Context.GetOwinContext().GetUserManager<Identity.UserManager>();
            var signInManager = Context.GetOwinContext().Get<Identity.SignInService>();
            var user = new Identity.ApplicationUser() { UserName = UserName.Text };
            IdentityResult result = manager.Create(user, Password.Text);
            if (result.Succeeded)
            {
                // For more information on how to enable account confirmation and password reset please visit http://go.microsoft.com/fwlink/?LinkID=320771
                //string code = manager.GenerateEmailConfirmationToken(user.Id);
                //string callbackUrl = IdentityHelper.GetUserConfirmationRedirectUrl(code, user.Id, Request);
                //manager.SendEmail(user.Id, "Confirm your account", "Please confirm your account by clicking <a href=\"" + callbackUrl + "\">here</a>.");

                //signInManager.SignIn(user, isPersistent: false, rememberBrowser: false);

                //IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
            }
            else
            {
                ErrorMessage.Text = result.Errors.FirstOrDefault();
            }
        }
    }
}