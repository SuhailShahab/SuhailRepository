﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using PITB.FC.HousingSocieties.BLL.Lookup;
using PITB.FC.HousingSocieties.CommonUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.FC.HousingSocieties.Account
{
    public partial class AdminUpdatePassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            bool redirect = false;
            if (User.Identity.IsAuthenticated)
            {
                Identity.ApplicationUser loggedUser = LazyBaseSingleton<UserBLL>.Instance.GetByUserID(User.Identity.GetUserId<int>());
                if (!loggedUser.UserTypeID.HasValue || (loggedUser.UserTypeID.HasValue && loggedUser.UserTypeID.Value != 1))
                {
                    redirect = true;
                }

            }
            else
            {
                redirect = true;
            }

            if (redirect)
            {
                Response.Redirect("~/Layouts/HousingSocietyDashboard.aspx");
            }
        }

        protected void SetPassword_Click(object sender, EventArgs e)
        {
            if (IsValid)
            {
                // Create the local login info and link the local account to the user
                var manager = Context.GetOwinContext().GetUserManager<Identity.UserManager>();
                IdentityResult result = manager.AddPassword(Convert.ToInt32(UserID.Text), password.Text);
                if (result.Succeeded)
                {

                }
                else
                {
                    AddErrors(result);
                }
            }
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }
    }
}