﻿using System;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using PITB.FC.HousingSocieties.Models;
using System.Text;
using System.Collections.Generic;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;

namespace PITB.FC.HousingSocieties.Account
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //RegisterHyperLink.NavigateUrl = "Register";
            //// Enable this once you have account confirmation enabled for password reset functionality
            ////ForgotPasswordHyperLink.NavigateUrl = "Forgot";
            //OpenAuthLogin.ReturnUrl = Request.QueryString["ReturnUrl"];
            //var returnUrl = HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
            //if (!String.IsNullOrEmpty(returnUrl))
            //{
            //    RegisterHyperLink.NavigateUrl += "?ReturnUrl=" + returnUrl;
            //}

            if (!Page.IsPostBack)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "AccessToken", "localStorage.removeItem('AccessToken');", true);
            }

        }

        protected void LogIn(object sender, EventArgs e)
        {
            if (IsValid)
            {
                // Validate the user password
                var manager = Context.GetOwinContext().GetUserManager<Identity.UserManager>();
                var signinManager = Context.GetOwinContext().GetUserManager<Identity.SignInService>();

                // This doen't count login failures towards account lockout
                // To enable password failures to trigger lockout, change to shouldLockout: true
                var result = signinManager.PasswordSignIn(Username.Text, Password.Text, RememberMe.Checked, shouldLockout: false);

                if (result == SignInStatus.Success) {
                    
                    var securityKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(Encoding.UTF8.GetBytes(Startup.JWTSecret));
                    var credentials = new Microsoft.IdentityModel.Tokens.SigningCredentials(securityKey, Microsoft.IdentityModel.Tokens.SecurityAlgorithms.HmacSha256);

                    //Create a List of Claims, Keep claims name short    
                    var permClaims = new List<Claim>();
                    permClaims.Add(new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()));
                    permClaims.Add(new Claim(JwtRegisteredClaimNames.UniqueName, Username.Text));
                    
                    //Create Security Token object by giving required parameters    
                    var token = new System.IdentityModel.Tokens.Jwt.JwtSecurityToken(Startup.JWTValidIssuer, //Issure    
                                    Startup.JWTValidIssuer,  //Audience    
                                    permClaims,
                                    expires: DateTime.Now.AddDays(1),
                                    signingCredentials: credentials);
                    string jwt_token = new System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler().WriteToken(token);
                    ScriptManager.RegisterStartupScript(this, GetType(), "AccessToken", "setAccessToken('" + jwt_token + "');", true);
                }

                string navigateUrl = "/Layouts/HousingSocietyDashboard.aspx";
                switch (result)
                {
                    case SignInStatus.Success:
                        ScriptManager.RegisterStartupScript(this, GetType(), "Redirect", "window.location='" + navigateUrl + "';", true);
                        //Response.Redirect("/Layouts/HousingSocietyDashboard.aspx");
                        //IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
                        break;
                    //case SignInStatus.LockedOut:
                    //    Response.Redirect("/Account/Lockout");
                    //    break;
                    //case SignInStatus.RequiresVerification:
                    //    Response.Redirect(String.Format("/Account/TwoFactorAuthenticationSignIn?ReturnUrl={0}&RememberMe={1}",
                    //                                    Request.QueryString["ReturnUrl"],
                    //                                    RememberMe.Checked),
                    //                      true);
                    //    break;
                    case SignInStatus.Failure:
                    default:
                        FailureText.Text = "Invalid login attempt";
                        ErrorMessage.Visible = true;
                        break;
                }
            }
        }

    }
}