﻿using System.Web.UI;

namespace PITB.FC.HousingSocieties.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}