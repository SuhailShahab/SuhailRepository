﻿using System;
using System.Data.SqlClient;
using System.Reflection;

namespace PITB.FC.HousingSocieties.CommonUtility
{
    public class SqlUtility
    {
        public void GetAddParameterExtented(object obj, SqlCommand sqlCommand)
        {
            PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (var f in fields)
            {
                foreach (Object objColumName in f.GetCustomAttributes(true))
                {

                    Models.MappingInfoAttribute mappingInfoAttribute = objColumName as Models.MappingInfoAttribute;

                    if (mappingInfoAttribute != null)
                    {
                        try
                        {
                            var p = f.GetValue(obj, null);
                            if (p != null && p != "" && p != "null" && !mappingInfoAttribute.Transient)
                            {
                                sqlCommand.Parameters.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                                break;
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
            }

        }
    }
}