﻿using PITB.FC.HousingSocieties.BLL;
using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.CommonUtility
{
    public class CommonAPI
    {
        public string AddErrorLogs(ErrorLogModel erroLog)
        {
            FillErrorLogData(erroLog);
            int id = new CommonBLL().SaveErrorLogs(erroLog);
            return "(" + id.ToString() + "-" + DateTime.Now.Day + DateTime.Now.Month + DateTime.Now.Year + ")";
        }

        private void FillErrorLogData(ErrorLogModel ErrorLog)
        {
            if (ErrorLog != null && !string.IsNullOrEmpty(ErrorLog.PageName) && ErrorLog.PageName != "SignIn")         // CR: 052
            {

            }

            //ErrorLog.WebMethod = WebMethod;
            if (ErrorLog.CustomException != null)
            {
                if (ErrorLog.CustomException.Message != "") ErrorLog.Message = ErrorLog.GetaAllMessages();//ErrorLog.g //ErrorLog.CustomException.Message;
                if (ErrorLog.CustomException.StackTrace != "") ErrorLog.StackTrace = ErrorLog.CustomException.StackTrace;
                if (ErrorLog.CustomException.Source != "") ErrorLog.Source = ErrorLog.CustomException.Source;
            }

        }

        public static string GetUserIP()
        {
            string VisitorsIPAddr = String.Empty;

            if (HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null)
            {
                VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
            }
            else if (HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"] != null)
            {
                VisitorsIPAddr = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
            else if ((HttpContext.Current.Request.UserHostAddress.Length != 0))
            {
                VisitorsIPAddr = HttpContext.Current.Request.UserHostAddress;
            }

            if (VisitorsIPAddr == "::1")
            {
                VisitorsIPAddr = "127.0.0.1";
            }


            return VisitorsIPAddr;
        }
    }
}