﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.CommonUtility
{
    public static class ConfigurationReader
    {
        public static bool IsShowGeneralMsg
        {
            get
            {
                return Convert.ToBoolean(ConfigurationManager.AppSettings["IsShowGeneralMsg"]);
            }
        }

        public static string GeneralMsg
        {
            get
            {
                return ConfigurationManager.AppSettings["GeneralMsg"];

            }
        }
        public static string KMLFolderPath
        {
            get
            {
                return ConfigurationManager.AppSettings["KMLFolderPath"];

            }
        }
        public static string EncryptionKey
        {
            get
            {
                if (ConfigurationManager.AppSettings.AllKeys.Contains("EncryptionKey"))
                {
                    return Convert.ToString(ConfigurationManager.AppSettings["EncryptionKey"]);
                }
                else
                {
                    return "b14ca5898a4e4133bbce2ea2315a1916";
                }
            }


        }
    }
}