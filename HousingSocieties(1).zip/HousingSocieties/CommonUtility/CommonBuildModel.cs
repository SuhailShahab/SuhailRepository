﻿using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;

namespace PITB.FC.HousingSocieties.CommonUtility
{
    public class CommonBuildModel
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dt"></param>
        /// <param name="objectType"></param>
        /// <returns></returns>
        //public T BuildModel<T>(DataTable dt, T objectType)
        //{
        //    Type handlerType = objectType.GetType();
        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        IList<T> genList = new List<T>();
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            T item = (T)Activator.CreateInstance(handlerType);
        //            foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
        //            {
        //                foreach (Object obj in propertyInfo.GetCustomAttributes(true))
        //                {
        //                    MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
        //                    if (mappingInfoAttribute != null)
        //                    {
        //                        if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
        //                        {
        //                            propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
        //                            break;
        //                        }
        //                    }
        //                }

        //            }
        //            genList.Add(item);
        //        }
        //        return genList[0];
        //    }

        //    return null;

        //}

        public List<T> BuildModelList<T>(DataTable dt)
        {

            if (dt != null && dt.Rows.Count > 0)
            {
                List<T> genList = new List<T>();
                foreach (DataRow dr in dt.Rows)
                {
                    T item = Activator.CreateInstance<T>();
                    foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                    {
                        foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                        {
                            Models.MappingInfoAttribute mappingInfoAttribute = obj as Models.MappingInfoAttribute;
                            if (mappingInfoAttribute != null)
                            {
                                if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                                {
                                    try
                                    {
                                        propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                                    }
                                    catch (ArgumentException)
                                    {
                                        Console.WriteLine("Unable to convert colume : " + mappingInfoAttribute.ColumnName);
                                        throw;
                                    }

                                    break;
                                }
                            }
                        }

                    }
                    genList.Add(item);
                }
                return genList;
            }

            return null;

        }


        //public IList<T> BuildModelExtend<T>(DataTable dt, T objectType)
        //{
        //    Type handlerType = objectType.GetType();
        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        IList<T> genList = new List<T>();
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            T item = (T)Activator.CreateInstance(handlerType);
        //            foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
        //            {
        //                foreach (Object obj in propertyInfo.GetCustomAttributes(true))
        //                {
        //                    MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
        //                    if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
        //                    {
        //                        if (!string.IsNullOrEmpty(mappingInfoAttribute.DataType) && mappingInfoAttribute.DataType.Equals("bool"))
        //                        {
        //                            propertyInfo.SetValue(item, Convert.ToBoolean(dr[mappingInfoAttribute.ColumnName]));
        //                            break;
        //                        }
        //                        else
        //                        {
        //                            propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
        //                            break;
        //                        }

        //                    }
        //                }

        //            }
        //            genList.Add(item);
        //        }
        //        return genList;
        //    }

        //    return null;

        //}

        public IList<T> BuildModel<T>(DataTable dt)
        {
            try
            {
                if (dt != null && dt.Rows.Count > 0)
                {
                    IList<T> genList = new List<T>();
                    foreach (DataRow dr in dt.Rows)
                    {
                        T item = Activator.CreateInstance<T>();
                        foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                        {
                            foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                            {
                                Models.MappingInfoAttribute mappingInfoAttribute = obj as Models.MappingInfoAttribute;
                                if (mappingInfoAttribute != null)
                                {
                                    if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                                    {
                                        try
                                        {
                                            propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                                            break;
                                        }
                                        catch (Exception)
                                        {
                                            throw;
                                        }

                                    }
                                }
                            }

                        }
                        genList.Add(item);
                    }
                    return genList;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return null;

        }
        public List<T> BuildModellst<T>(DataTable dt)
        {

            if (dt != null && dt.Rows.Count > 0)
            {
                List<T> genList = new List<T>();
                foreach (DataRow dr in dt.Rows)
                {
                    T item = Activator.CreateInstance<T>();
                    foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                    {
                        foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                        {
                            Models.MappingInfoAttribute mappingInfoAttribute = obj as Models.MappingInfoAttribute; if (mappingInfoAttribute != null)
                            {
                                if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                                {
                                    propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                                    break;
                                }
                            }
                        }

                    }
                    genList.Add(item);
                }
                return genList;
            }

            return null;

        }
        public DataTable ToDataTable<T>(IList<T> list)
        {
            PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            for (int i = 0; i < props.Count; i++)
            {
                PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }
            object[] values = new object[props.Count];
            foreach (T item in list)
            {
                for (int i = 0; i < values.Length; i++)
                    values[i] = props[i].GetValue(item) ?? DBNull.Value;
                table.Rows.Add(values);
            }
            return table;
        }
    }

}