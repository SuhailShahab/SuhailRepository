﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class DevelopmentAuthorityModel : LookupBase
    {
        [MappingInfo(ColumnName = "AuthorityID")]
        public int ID { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int DistrictID { get; set; }

        //[MappingInfo(ColumnName = "VersionNO")]
        //public int? VersionNO { get; set; }

        public DevelopmentAuthorityModel()
        {
        }
        public DevelopmentAuthorityModel(string notification)
        {
            this.Notification = notification;
        }
    }
}