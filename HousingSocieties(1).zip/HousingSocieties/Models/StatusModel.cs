﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class StatusModel
    {
        public string Status { get; set; }
        public string Message { get; set; }
        public string NextUrl { get; set; }

        #region "Constructors"

        public StatusModel(StatusType s, string Message)
        {
            this.Status = GetEnumDescription(s);
            this.Message = Message;
        }

        #endregion

        protected string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes =
                (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

            if (attributes != null && attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }
    }

    public enum StatusType
    {
        [Description("Info")]
        Info,
        [Description("error")]
        error,
        [Description("warning")]
        warning,
        [Description("success")]
        success,
        [Description("fail")]
        fail,
    }
}