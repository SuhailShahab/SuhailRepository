﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class DocumentModel : BaseModel
    {
        [MappingInfo(ColumnName = "DocumentID")]
        public int? DocumentID { get; set; }

        [MappingInfo(ColumnName = "SocietyID")]
        public int? SocietyID { get; set; }

        [MappingInfo(ColumnName = "FileName")]
        public string FileName { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "MediaType")]
        public string MediaType { get; set; }

        [MappingInfo(ColumnName = "FileSize")]
        public int? FileSize { get; set; }

        [MappingInfo(ColumnName = "Attachment")]
        public byte[] Attachment { get; set; }

        [MappingInfo(ColumnName = "DocumentTypeID")]
        public int? DocumentTypeID { get; set; }


    }
    public class DocumentModelView : StatusModel
    {
        public DocumentModelView(StatusType s, string Message) : base(s, Message)
        {
        }
    }

}