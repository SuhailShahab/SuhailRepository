﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class ErrorLogModel
    {
        public int logID { get; set; }
        //public int LocationID { get; set; }
        public string LocationCode { get; set; }

        //public int ServiceID { get; set; }
        public string ServiceCode { get; set; }

        public int DivisionID { get; set; }
        //public string DivisionCode { get; set; }
        //public string DivisionTitle { get; set; }

        public int DistrictID { get; set; }
        //public string DistrictCode { get; set; }

        public string Method { get; set; }
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public string Source { get; set; }
        public int IsWebMethod { get; set; }

        public DateTime Created { get; set; }

        public string PageName { get; set; }
        public string PageStaticName { get; set; }

        public Exception CustomException { get; set; }
        //public string MethodName{ get; set; }

        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        ////public ServiceCodes Service { get; set; }
        public DataTable DataUser { get; set; }
        // public string PageName{ get; set; }


        public ErrorLogModel()
        {

        }

        //public ErrorLogModel(string message, string methodName, int webMethod, ServiceCodes service, string PageName)
        //{
        //    this.CustomException = null;
        //    this.Method = methodName;
        //    this.IsWebMethod = webMethod;
        //    this.Service = service;
        //    this.PageName = PageName;
        //    this.Message = message;
        //}
        //public ErrorLogModel(Exception ex, string methodName, int webMethod, ServiceCodes service, string PageName)
        //{
        //    this.CustomException = ex;
        //    this.Method = methodName;
        //    this.IsWebMethod = webMethod;
        //    this.Service = service;
        //    this.PageName = PageName;
        //}

        public ErrorLogModel(Exception ex, string methodName, int webMethod, string PageName)
        {
            this.CustomException = ex;
            this.Method = methodName;
            this.IsWebMethod = webMethod;
            this.PageName = PageName;
        }

        public ErrorLogModel(string message, string methodName, int webMethod, string PageName)
        {
            this.CustomException = null;
            this.Method = methodName;
            this.IsWebMethod = webMethod;
            this.PageName = PageName;
            this.Message = message;
        }

        public string GetaAllMessages()
        {
            string message = string.Empty;
            Exception innerException = this.CustomException;

            do
            {
                message = message + (string.IsNullOrEmpty(innerException.Message) ? string.Empty : innerException.Message);
                innerException = innerException.InnerException;
            }
            while (innerException != null);

            return message;
        }
      
    }
}