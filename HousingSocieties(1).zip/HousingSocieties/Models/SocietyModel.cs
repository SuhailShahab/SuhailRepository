﻿using PITB.FC.HousingSocieties.Models.Lookup;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class SocietyModel : BaseModel
    {
        [MappingInfo(ColumnName = "SocietyID")]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Name")]
        public string Name { get; set; }

        [MappingInfo(ColumnName = "PhaseSector")]
        public string PhaseSector { get; set; }

        [MappingInfo(ColumnName = "Block")]
        public string Block { get; set; }

        [MappingInfo(ColumnName = "TotalArea")]
        public decimal? TotalArea { get; set; }

        [MappingInfo(ColumnName = "AuthorityID")]
        public int? AuthorityID { get; set; }

        [MappingInfo(ColumnName = "Authority")]
        public string Authority { get; set; }

        [MappingInfo(ColumnName = "NOCAppliedDate")]
        public DateTime? NOCAppliedDate { get; set; }

        [MappingInfo(ColumnName = "DivisonID")]
        public int? DivisionID { get; set; }

        [MappingInfo(ColumnName = "Division")]
        public string Division { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int? DistrictID { get; set; }

        [MappingInfo(ColumnName = "District")]
        public string District { get; set; }

        [MappingInfo(ColumnName = "CityID")]
        public int? CityID { get; set; }

        [MappingInfo(ColumnName = "City")]
        public string City { get; set; }

        [MappingInfo(ColumnName = "UnionCouncilID")]
        public int? UnionCouncilID { get; set; }

        [MappingInfo(ColumnName = "LocationCordinates")]
        public string LocationCordinates { get; set; }

        [MappingInfo(ColumnName = "Address")]
        public string Address { get; set; }

        [MappingInfo(ColumnName = "Mouza")]
        public string Mouza { get; set; }

        [MappingInfo(ColumnName = "DeveloperName")]
        public string DeveloperName { get; set; }

        [MappingInfo(ColumnName = "SocietyStatusID")]
        public int? SocietyStatusID { get; set; }

        [MappingInfo(ColumnName = "SocietyStatus")]
        public string SocietyStatus { get; set; }

        [MappingInfo(ColumnName = "TotalPlots")]
        public int? TotalPlots { get; set; }

        [MappingInfo(ColumnName = "TotalPlotSold")]
        public int? TotalPlotSold { get; set; }

        [MappingInfo(ColumnName = "TotalConstructedHouse")]
        public int? TotalConstructedHouse { get; set; }

        [MappingInfo(ColumnName = "OwnershipLandID")]
        public int? OwnershipLandID { get; set; }

        [MappingInfo(ColumnName = "OwnershipLand")]
        public string OwnershipLand { get; set; }

        [MappingInfo(ColumnName = "OwnershipLandDesc")]
        public string OwnershipLandDesc { get; set; }

        [MappingInfo(ColumnName = "AvailabilitySiteOffice")]
        public bool? AvailabilitySiteOffice { get; set; }

        [MappingInfo(ColumnName = "UnApprovedReasonDesc")]
        public string UnApprovedReasonDesc { get; set; }

        [MappingInfo(ColumnName = "SocietyNotGrantedNOCDesc")]
        public string SocietyNotGrantedNOCDesc { get; set; }

        [MappingInfo(ColumnName = "SocietyActionTakenDesc")]
        public string SocietyActionTakenDesc { get; set; }

        [MappingInfo(ColumnName = "SocietyAvailableFacilityDesc")]
        public string SocietyAvailableFacilityDesc { get; set; }

        [MappingInfo(ColumnName = "Remarks")]
        public string Remarks { get; set; }

        [MappingInfo(ColumnName = "IsActive")]
        public bool? IsActive { get; set; }

        public List<DocumentModel> lstSocietyDocument { get; set; }

        public List<DocumentModel> lstSocietyKML { get; set; }

        [MappingInfo(ColumnName = "DocumentID", Transient = true)]
        public int DocumentID { get; set; }


        [MappingInfo(ColumnName = "IsKMLAvailable")]
        public bool IsKMLAvailable { get; set; }

        //public List<SchemeUnApprovedReasonModel> lstSocietyUnApprovedReason { get; set; }
        //public List<NOCDepartmentModel> lstNotGrantedNOCDepartment { get; set; }

        //public List<ActionTakenModel> lstSocietyActionTaken { get; set; }
        //public List<AvailableFacilityModel> lstSocietyAvailableFacility { get; set; }

        [MappingInfo(ColumnName = "HousesDetailDocumentID", Transient = true)]
        public int HousesDetailDocumentID { get; set; }

        [MappingInfo(ColumnName = "PlotDetailDocumentID", Transient = true)]
        public int PlotDetailDocumentID { get; set; }

        [MappingInfo(ColumnName = "DeveloperOtherDocumentID", Transient = true)]
        public int DeveloperOtherDocumentID { get; set; }

        // New Fields
        [MappingInfo(ColumnName = "ApprovedBlocks")]
        public string ApprovedBlocks { get; set; }

        [MappingInfo(ColumnName = "ResidentialPlots")]
        public int? ResidentialPlots { get; set; }

        [MappingInfo(ColumnName = "CommercialPlots")]
        public int? CommercialPlots { get; set; }

        [MappingInfo(ColumnName = "MortgagedPlots")]
        public string MortgagedPlots { get; set; }

        [MappingInfo(ColumnName = "ApprovalStage")]
        public string ApprovalStage { get; set; }

        public string QRCode { get; set; }

        [MappingInfo(ColumnName = "SellableArea")]
        public decimal? SellableArea { get; set; }

        [MappingInfo(ColumnName = "UnSellableArea")]
        public decimal? UnSellableArea { get; set; }

        [MappingInfo(ColumnName = "TotalAreaDetails")]
        public string TotalAreaDetails { get; set; }

        [MappingInfo(ColumnName = "CatgryWiseResPlots")]
        public string CatgryWiseResPlots { get; set; }

        [MappingInfo(ColumnName = "CatgryWiseComPlots")]
        public string CatgryWiseComPlots { get; set; }

        [MappingInfo(ColumnName = "LowIncomeScheme")]
        public string LowIncomeScheme { get; set; }
    }

    public class SocietyModelView : StatusModel
    {
        public SocietyModelView(StatusType s, string Message) : base(s, Message)
        {
        }

        public SocietyModelView() : base(StatusType.success, string.Empty)
        {
        }

        public int? VisitorHitCounts { get; set; }

        public string UserDisplayName { get; set; }
        public SocietyModel Model { get; set; }
        public List<SocietyModel> colSocities { get; set; }
        public List<SocietyViewModel> colViewSocities { get; set; }

        public int? TotalRecords { get; set; }
        public int SearchCounter { get; set; }

        public List<DevelopmentAuthorityModel> colDevelopmentAuthorities { get; set; }
        public List<DivisionModel> colDivision { get; set; }
        public List<DistrictModel> colDistrict { get; set; }
        public List<CityModel> colCity { get; set; }

        public List<UnionCouncilModel> colUnionCouncil { get; set; }

        public List<OwnershipLandModel> colOwnershipLands { get; set; }

        public List<SocietyStatusModel> colSocietyStatus { get; set; }

        public List<DocumentTypeModel> colDocumentTypes { get; set; }

        public List<SchemeUnApprovedReasonModel> colSchemeUnApprovedReason { get; set; }

        public List<NOCDepartmentModel> colNOCDepartment { get; set; }
        public List<ActionTakenModel> colActionTaken { get; set; }
        public List<AvailableFacilityModel> colAvailableFacility { get; set; }
        public List<SchemeStatusCountModel> SchemeStatusCounts { get; set; }
    }


    public class SocietyViewModel
    {
        [MappingInfo(ColumnName = "SocietyID")]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Name")]
        public string Name { get; set; }

        //[MappingInfo(ColumnName = "PhaseSector")]
        //public string PhaseSector { get; set; }

        //[MappingInfo(ColumnName = "Block")]
        //public string Block { get; set; }

        [MappingInfo(ColumnName = "TotalArea")]
        public decimal? TotalArea { get; set; }

        [MappingInfo(ColumnName = "AuthorityID")]
        public int? AuthorityID { get; set; }

        [MappingInfo(ColumnName = "Authority")]
        public string Authority { get; set; }

        //[MappingInfo(ColumnName = "NOCAppliedDate")]
        //public DateTime? NOCAppliedDate { get; set; }

        [MappingInfo(ColumnName = "DivisonID")]
        public int? DivisionID { get; set; }

        //[MappingInfo(ColumnName = "Division")]
        //public string Division { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int? DistrictID { get; set; }

        //[MappingInfo(ColumnName = "District")]
        //public string District { get; set; }

        [MappingInfo(ColumnName = "CityID")]
        public int? CityID { get; set; }

        [MappingInfo(ColumnName = "City")]
        public string City { get; set; }

        //[MappingInfo(ColumnName = "UnionCouncilID")]
        //public int? UnionCouncilID { get; set; }

        //[MappingInfo(ColumnName = "LocationCordinates")]
        //public string LocationCordinates { get; set; }

        //[MappingInfo(ColumnName = "Address")]
        //public string Address { get; set; }

        //[MappingInfo(ColumnName = "Mouza")]
        //public string Mouza { get; set; }

        //[MappingInfo(ColumnName = "DeveloperName")]
        //public string DeveloperName { get; set; }

        [MappingInfo(ColumnName = "SocietyStatusID")]
        public int? SocietyStatusID { get; set; }

        [MappingInfo(ColumnName = "SocietyStatus")]
        public string SocietyStatus { get; set; }

        //[MappingInfo(ColumnName = "TotalPlots")]
        //public int? TotalPlots { get; set; }

        //[MappingInfo(ColumnName = "TotalPlotSold")]
        //public int? TotalPlotSold { get; set; }

        //[MappingInfo(ColumnName = "TotalConstructedHouse")]
        //public int? TotalConstructedHouse { get; set; }

        //[MappingInfo(ColumnName = "OwnershipLandID")]
        //public int? OwnershipLandID { get; set; }

        [MappingInfo(ColumnName = "OwnershipLand")]
        public string OwnershipLand { get; set; }

        //[MappingInfo(ColumnName = "OwnershipLandDesc")]
        //public string OwnershipLandDesc { get; set; }

        //[MappingInfo(ColumnName = "AvailabilitySiteOffice")]
        //public bool? AvailabilitySiteOffice { get; set; }

        //[MappingInfo(ColumnName = "UnApprovedReasonDesc")]
        //public string UnApprovedReasonDesc { get; set; }

        //[MappingInfo(ColumnName = "SocietyNotGrantedNOCDesc")]
        //public string SocietyNotGrantedNOCDesc { get; set; }

        //[MappingInfo(ColumnName = "SocietyActionTakenDesc")]
        //public string SocietyActionTakenDesc { get; set; }

        //[MappingInfo(ColumnName = "SocietyAvailableFacilityDesc")]
        //public string SocietyAvailableFacilityDesc { get; set; }

        //[MappingInfo(ColumnName = "Remarks")]
        //public string Remarks { get; set; }

        [MappingInfo(ColumnName = "IsActive")]
        public bool? IsActive { get; set; }


        [MappingInfo(ColumnName = "DocumentID", Transient = true)]
        public int DocumentID { get; set; }
        [MappingInfo(ColumnName = "IsKMLAvailable", Transient = true)]
        public bool IsKMLAvailable { get; set; }
        //public List<DocumentModel> lstSocietyDocument { get; set; }

        //public List<SchemeUnApprovedReasonModel> lstSocietyUnApprovedReason { get; set; }
        //public List<NOCDepartmentModel> lstNotGrantedNOCDepartment { get; set; }

        //public List<ActionTakenModel> lstSocietyActionTaken { get; set; }
        //public List<AvailableFacilityModel> lstSocietyAvailableFacility { get; set; }

        [MappingInfo(ColumnName = "HousesDetailDocumentID", Transient = true)]
        public int HousesDetailDocumentID { get; set; }

        [MappingInfo(ColumnName = "PlotDetailDocumentID", Transient = true)]
        public int PlotDetailDocumentID { get; set; }

        [MappingInfo(ColumnName = "DeveloperOtherDocumentID", Transient = true)]
        public int DeveloperOtherDocumentID { get; set; }

        [MappingInfo(ColumnName = "EncURL", Transient = true)]
        public string EncURL { get; set; }

    }
    public class SocietySearchModel
    {
        public int? DevelopmentAuthoritieID { get; set; }
        public int? DivisionID { get; set; }
        public int? DistrictID { get; set; }
        public int? CityID { get; set; }

        public string SearchTerm { get; set; }

        public int? SocietyStatusID { get; set; }
        public int? UserID { get; set; }
    }

    public class SchemeStatusCountModel
    {
        [MappingInfo(ColumnName = "ID")]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Approved")]
        public int Approved { get; set; }

        [MappingInfo(ColumnName = "UnApproved")]
        public int UnApproved { get; set; }

        [MappingInfo(ColumnName = "Illegal")]
        public int Illegal { get; set; }

        [MappingInfo(ColumnName = "Total")]
        public int Total { get; set; }

    }

    public class SocietyInactiveModel : StatusModel
    {
        public SocietyInactiveModel(StatusType s, string Message) : base(s, Message)
        {
        }

        public int? SocietyID { get; set; }

        public int? UserID { get; set; }

        public bool IsActive { get; set; }

    }

    public class DeleteSocietyDocumentModel : StatusModel
    {
        public DeleteSocietyDocumentModel(StatusType s, string Message) : base(s, Message)
        {
        }

        public int? SocietyID { get; set; }

        public int? DocumentID { get; set; }

        public int? UserID { get; set; }


    }
}