﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class KMLModel
    {
        [MappingInfo(ColumnName = "KMLID")]
        public int? KMLID { get; set; }

        [MappingInfo(ColumnName = "SocietyID")]
        public int? SocietyID { get; set; }

        [MappingInfo(ColumnName = "FileName")]
        public string FileName { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "MediaType")]
        public string MediaType { get; set; }

        [MappingInfo(ColumnName = "FileSize")]
        public int? FileSize { get; set; }

        [MappingInfo(ColumnName = "Attachment")]
        public byte[] Attachment { get; set; }
    }

    public class KMLModelView : StatusModel
    {
        public KMLModelView(StatusType s, string Message) : base(s, Message)
        {
        }
    }
}