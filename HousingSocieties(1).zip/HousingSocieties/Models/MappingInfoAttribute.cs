﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property, AllowMultiple = true)]
    public class MappingInfoAttribute : System.Attribute
    {
        public MappingInfoAttribute()
        {

        }

        //public MappingInfoAttribute(string colunmname ,string ex)
        //{
        //    this.ColumnName = columnName;
        //    this.IsExclude = ex;
        //}

        private bool transient = false;
        private bool convertBool = false;
        private string selfJoin = String.Empty;
        private string columnName = String.Empty;
        private string datatype = String.Empty;
        private bool identitySpecification = false;
        // private string isExclude = string.Empty;


        public bool Transient
        {
            get { return transient; }
            set { transient = value; }
        }

        public bool IsConvertBool
        {
            get { return convertBool; }
            set { convertBool = value; }
        }

        public string SelfJoin
        {
            get { return selfJoin; }
            set { selfJoin = value; }
        }

        //public string IsExclude
        //{
        //    get
        //    {
        //        return isExclude;
        //    }
        //    set
        //    {
        //        isExclude = value;
        //    }
        //}


        public string ColumnName
        {
            get
            {
                return columnName;
            }
            set
            {
                columnName = value;
            }
        }


        public string DataType
        {
            get { return datatype; }
            set { datatype = value; }
        }

        public bool IdentitySpecification
        {
            get { return identitySpecification; }
            set { identitySpecification = value; }
        }


    }
}