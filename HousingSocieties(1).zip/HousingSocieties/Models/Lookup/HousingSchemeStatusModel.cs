﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models.Lookup
{
    public class HousingSchemeStatusModel : LookupBase
    {
        [MappingInfo(ColumnName = "HousingSchemStatusID")]
        public int ID { get; set; }

       
        public HousingSchemeStatusModel()
        {
        }
        public HousingSchemeStatusModel(string notification)
        {
            this.Notification = notification;
        }
    }
}