﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public abstract class LookupBase : BaseModel
    {
        public int ID { get; set; }

        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }

        //[MappingInfo(ColumnName = "StaticName")]
        //public string StaticName { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        //[MappingInfo(ColumnName = "TitleUrdu")]
        //public string TitleUrdu { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "IsActive")]
        public bool IsActive { get; set; }
      
    }
}