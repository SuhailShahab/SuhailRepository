﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class DivisionModel : LookupBase
    {
        [MappingInfo(ColumnName = "DivisionID")]
        public int? ID { get; set; }

        public List<int> AuthorityIDs { get; set; }

        public DivisionModel()
        {
        }
        public DivisionModel(string notification)
        {
            this.Notification = notification;
        }

    }
}