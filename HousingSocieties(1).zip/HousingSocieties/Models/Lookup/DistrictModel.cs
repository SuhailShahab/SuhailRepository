﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class DistrictModel : LookupBase
    {
        [MappingInfo(ColumnName = "DistrictID")]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "DivisionID")]
        public int? DivisionID { get; set; }

        [MappingInfo(ColumnName = "IsDevelopmentAuthority")]
        public bool IsDevelopmentAuthority { get; set; }

        public DistrictModel()
        {
        }
        public DistrictModel(string notification)
        {
            this.Notification = notification;
        }

    }
}