﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models.Lookup
{
    public class AvailableFacilityModel : LookupBase
    {
        [MappingInfo(ColumnName = "AvailableFacilityID")]
        public int ID { get; set; }


        public AvailableFacilityModel()
        {
        }
        public AvailableFacilityModel(string notification)
        {
            this.Notification = notification;
        }
    }
}