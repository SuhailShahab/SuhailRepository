﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models.Lookup
{
    public class NOCReasonModel : LookupBase
    {
        [MappingInfo(ColumnName = "NOCReasonID")]
        public int ID { get; set; }


        public NOCReasonModel()
        {
        }
        public NOCReasonModel(string notification)
        {
            this.Notification = notification;
        }
    }
}