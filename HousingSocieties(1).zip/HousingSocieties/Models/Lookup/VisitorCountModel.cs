﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models.Lookup
{
    public class VisitorCountModel
    {
        [MappingInfo(ColumnName = "RecordID")]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "SessionID")]
        public string SessionID { get; set; }

        [MappingInfo(ColumnName = "UserIP")]
        public string UserIP { get; set; }

        [MappingInfo(ColumnName = "CreatedDate")]
        public DateTime? CreatedDate { get; set; }

        [MappingInfo(ColumnName = "UserID")]
        public int? UserID { get; set; }

        [MappingInfo(ColumnName = "PageReferral")]
        public string PageReferral { get; set; }

        [MappingInfo(ColumnName = "TypeID")]
        public int? TypeID { get; set; }
    }
}