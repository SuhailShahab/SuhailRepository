﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models.Lookup
{
    public class SocietyStatusModel : LookupBase
    {
        [MappingInfo(ColumnName = "SocietyStatusID")]
        public int ID { get; set; }

        public SocietyStatusModel()
        {
        }
        public SocietyStatusModel(string notification)
        {
            this.Notification = notification;
        }
    }
}