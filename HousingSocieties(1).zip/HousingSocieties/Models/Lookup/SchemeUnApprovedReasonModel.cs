﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models.Lookup
{
    public class SchemeUnApprovedReasonModel : LookupBase
    {
        [MappingInfo(ColumnName = "UnApprovedReasonID")]
        public int ID { get; set; }

        [MappingInfo(ColumnName = "Checked")]
        public bool? IsChecked { get; set; }


        public SchemeUnApprovedReasonModel()
        {
        }
        public SchemeUnApprovedReasonModel(string notification)
        {
            this.Notification = notification;
        }
    }
}