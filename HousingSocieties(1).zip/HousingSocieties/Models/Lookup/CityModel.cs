﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class CityModel : LookupBase
    {
        [MappingInfo(ColumnName = "CityID")]
        public int ID { get; set; }

        public CityModel()
        {
        }
        public CityModel(string notification)
        {
            this.Notification = notification;
        }
    }
}