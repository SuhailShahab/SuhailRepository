﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public class UnionCouncilModel : LookupBase
    {
        [MappingInfo(ColumnName = "UnionCouncilID")]
        public int ID { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int DistrictID { get; set; }

        [MappingInfo(ColumnName = "TehsilID")]
        public int TehsilID { get; set; }
        public UnionCouncilModel()
        {
        }
        public UnionCouncilModel(string notification)
        {
            this.Notification = notification;
        }
    }
}