﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models.Lookup
{
    public class OwnershipLandModel : LookupBase
    {
        [MappingInfo(ColumnName = "OwnershipLandID")]
        public int ID { get; set; }


        public OwnershipLandModel()
        {
        }
        public OwnershipLandModel(string notification)
        {
            this.Notification = notification;
        }
    }
}