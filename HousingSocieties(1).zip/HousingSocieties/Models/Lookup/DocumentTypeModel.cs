﻿namespace PITB.FC.HousingSocieties.Models
{
    public class DocumentTypeModel : LookupBase
    {
        [MappingInfo(ColumnName = "DocumentTypeID")]
        public int? ID { get; set; }

        public DocumentTypeModel()
        {
        }
        public DocumentTypeModel(string notification)
        {
            this.Notification = notification;
        }
    }
}