﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models.Lookup
{
    public class NOCDepartmentModel : LookupBase
    {
        [MappingInfo(ColumnName = "NOCDepartmentID")]
        public int ID { get; set; }


        public NOCDepartmentModel()
        {
        }
        public NOCDepartmentModel(string notification)
        {
            this.Notification = notification;
        }
    }
}