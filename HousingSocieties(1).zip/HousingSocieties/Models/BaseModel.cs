﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.Models
{
    public abstract class BaseModel
    { 
        public string Notification { get; set; }

        [MappingInfo(ColumnName = "Created")]
        public DateTime? CreatedDate { get; set; }

        [MappingInfo(ColumnName = "Author")]
        public int? CreatedBy { get; set; }

        [MappingInfo(ColumnName = "Modified")]
        public DateTime? ModifiedDate { get; set; }

        [MappingInfo(ColumnName = "Editor")]
        public int? ModifiedBy { get; set; }
    }
}