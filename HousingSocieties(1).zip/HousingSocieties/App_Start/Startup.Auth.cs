﻿using System;
using System.Web.Http;

namespace PITB.FC.HousingSocieties
{
    using Microsoft.Owin.Security.Jwt;
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.Owin;
    using Microsoft.Owin;
    using Microsoft.Owin.Security.Cookies;
    using Owin;
    using Microsoft.Owin.Security;
    using Microsoft.IdentityModel.Tokens;
    using System.Text;

    public partial class Startup
    {


        public static string JWTValidIssuer
        {
            get
            {
                return "HousingSocieties";
            }
        }

        public static string JWTSecret
        {
            get
            {
                return "HousingSocietiesSecret";
            }
        }
        
        public void ConfigureAuth(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration();
            WebApiConfig.Register(config);

            app.CreatePerOwinContext<Identity.UserManager>(() => new Identity.UserManager(new Identity.UserStore()));
            app.CreatePerOwinContext<Identity.SignInService>((options, context) => new Identity.SignInService(context.GetUserManager<Identity.UserManager>(), context.Authentication));

            app.UseCookieAuthentication(new CookieAuthenticationOptions
            {
                CookieName = "HosuingSocieties",
                AuthenticationMode = AuthenticationMode.Active,
                AuthenticationType = DefaultAuthenticationTypes.ApplicationCookie,
                LoginPath = new PathString("/Account/Login.aspx"),
                //Provider = new CookieAuthenticationProvider
                //{
                //    OnValidateIdentity = SecurityStampValidator.OnValidateIdentity<ApplicationUserManager, ApplicationUser>(
                //        validateInterval: TimeSpan.FromMinutes(30),
                //        regenerateIdentity: (manager, user) => user.GenerateUserIdentityAsync(manager))
                //}
                Provider = new CookieAuthenticationProvider
                {
                    OnValidateIdentity = SecurityStampValidator.OnValidateIdentity<Identity.UserManager, Identity.ApplicationUser, int>(
                    validateInterval: TimeSpan.FromMinutes(30),
                    regenerateIdentityCallback: (manager, user) =>
                    {
                        var userIdentity = manager.CreateIdentityAsync(user, DefaultAuthenticationTypes.ApplicationCookie);
                        return (userIdentity);
                    },
                    getUserIdCallback: (id) => (Int32.Parse(id.GetUserId()))
                    )
                }
            });

            app.UseJwtBearerAuthentication(
                new JwtBearerAuthenticationOptions
                {
                    AuthenticationMode = AuthenticationMode.Active,
                    TokenValidationParameters = new TokenValidationParameters()
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = JWTValidIssuer,
                        ValidAudience = JWTValidIssuer,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(JWTSecret))
                    }
                });

            app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);

            app.UseWebApi(config);
        }
    }
}
