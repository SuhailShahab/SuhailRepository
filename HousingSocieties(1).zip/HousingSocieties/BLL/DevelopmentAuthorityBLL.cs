﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL;
using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.BLL
{
    public class DevelopmentAuthorityBLL:BaseBLL
    {
        public List<DevelopmentAuthorityModel> GetAllAuthorities()
        {
            try
            {
                DataTable dt = null;
                dt = new DevelopmentAuthorityDAL().GetAllAuthorities();
                return CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DevelopmentAuthorityModel>(dt);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}