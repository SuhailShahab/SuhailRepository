﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL;
using PITB.FC.HousingSocieties.Models;
using PITB.FC.HousingSocieties.Models.Lookup;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.BLL
{
    public class SocityBLL : BaseBLL
    {
        public List<SocietyModel> GetAllSocities(SocietySearchModel searchModel = null)
        {

            List<SocietyModel> viewModel = new List<SocietyModel>();

            try
            {
                DataTable dt = null;
                dt = new SocityDAL().GetAllSocities(searchModel);

                viewModel = LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SocietyModel>(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return viewModel;
        }

        public List<SocietyViewModel> GetAllSocitiesViewData(SocietySearchModel searchModel = null)
        {

            List<SocietyViewModel> viewModel = new List<SocietyViewModel>();

            try
            {
                DataTable dt = null;
                dt = new SocityDAL().GetAllSocities(searchModel);

                viewModel = LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SocietyViewModel>(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return viewModel;
        }

        public List<SchemeStatusCountModel> GetSchemeStatusCount()
        {
            List<SchemeStatusCountModel> model = new List<SchemeStatusCountModel>();

            try
            {
                DataTable dt = null;
                dt = new SocityDAL().GetSchemeStatusCount();

                if(dt != null && dt.Rows.Count > 0)
                {
                    model = LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SchemeStatusCountModel>(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return model;
        }

        public SocietyModelView GetSocitiesPagedViewData(SocietySearchModel searchModel, int? pageNumber, int? pageSize)
        {
            SocietyModelView viewModel = new SocietyModelView();

            try
            {
                DataSet ds = null;
                ds = new SocityDAL().GetPagedSocities(searchModel, pageNumber, pageSize);

                if (ds.Tables.Count > 0)
                {
                    viewModel.colViewSocities = LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SocietyViewModel>(ds.Tables[0]);
                }

                if (ds.Tables.Count > 1)
                {
                    viewModel.TotalRecords = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRows"]);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return viewModel;
        }

        public List<SocietyModel> GetSocietiesData(SocietySearchModel searchModel = null)
        {

            List<SocietyModel> viewModel = new List<SocietyModel>();

            try
            {
                DataTable dt = null;
                dt = new SocityDAL().GetSocietiesData(searchModel);

                viewModel = LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SocietyModel>(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return viewModel;
        }

        public void GetSocietiesFillLists(SocietyModelView model, int? userID)
        {
            try
            {
                DataSet ds = null;
                ds = new SocityDAL().GetSocietiesFillLists(userID);

                if (ds != null)
                {
                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        model.colDevelopmentAuthorities = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DevelopmentAuthorityModel>(ds.Tables[0]);

                    if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                        model.colDistrict = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DistrictModel>(ds.Tables[1]);

                    if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                    {
                        List<DivisionModel> Divisions = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DivisionModel>(ds.Tables[2]);

                        if (Divisions != null)
                        {
                            foreach (DivisionModel item in Divisions)
                            {
                                item.AuthorityIDs = (from x in ds.Tables[3].AsEnumerable()
                                                     where x.Field<int>("DivisionID") == item.ID
                                                     select x.Field<int>("AuthorityID")).ToList();
                            }
                        }
                        model.colDivision = Divisions;
                    }

                    if (ds.Tables[4] != null && ds.Tables[4].Rows.Count > 0)
                        model.colSocietyStatus = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SocietyStatusModel>(ds.Tables[4]);

                }

                //return CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DevelopmentAuthorityModel>(ds);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void GetSocietyFillLookups(SocietyModelView model)
        {
            try
            {
                DataSet ds = null;
                ds = new SocityDAL().GetSocietyFillLookups();

                if (ds != null)
                {
                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        model.colNOCDepartment = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<NOCDepartmentModel>(ds.Tables[0]);

                    if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                        model.colActionTaken = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<ActionTakenModel>(ds.Tables[1]);

                    if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                        model.colAvailableFacility = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<AvailableFacilityModel>(ds.Tables[2]);

                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public SocietyModel GetSocietyByID(int? societyID, int? userID)
        {
            SocietyModel objModel = new SocietyModel();
            try
            {
                DataSet ds = null;
                ds = new SocityDAL().GetSocietyByID(societyID, userID);

                if (ds != null)
                {
                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        objModel = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SocietyModel>(ds.Tables[0]).ToList()[0];

                    if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                        objModel.lstSocietyDocument = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DocumentModel>(ds.Tables[1]);

                    if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                        objModel.lstSocietyKML = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DocumentModel>(ds.Tables[2]);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return objModel;
        }

        public SocietyModel GetSocietyDetailByID(int? societyID)
        {
            SocietyModel objModel = new SocietyModel();
            try
            {
                DataSet ds = null;
                ds = new SocityDAL().GetSocietyDetailByID(societyID);

                if (ds != null)
                {
                    if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        objModel = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SocietyModel>(ds.Tables[0]).ToList()[0];

                    if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                        objModel.lstSocietyDocument = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DocumentModel>(ds.Tables[1]);
                    
                    if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                        objModel.lstSocietyKML = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DocumentModel>(ds.Tables[2]);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return objModel;
        }

        public int SaveData(SocietyModel model)
        {
            int? result = 0;
            try
            {
                DataTable dtDocument = new DataTable();
                DataTable dtKML = new DataTable();
                dtDocument = this.BuildDocumentDataTable(model.lstSocietyDocument);
                dtKML = this.BuildDocumentDataTable(model.lstSocietyKML);

                result = new SocityDAL().SaveData(model, dtDocument, dtKML);
            }
            catch (Exception)
            {
                throw;
            }
            return result.Value;
        }

        public int UpdateData(SocietyModel model)
        {
            int? result = 0;
            try
            {
                DataTable dtDocument = new DataTable();
                DataTable dtKML = new DataTable();
                dtDocument = this.BuildDocumentDataTable(model.lstSocietyDocument);
                dtKML = this.BuildDocumentDataTable(model.lstSocietyKML);
                result = new SocityDAL().UpdateData(model, dtDocument, dtKML);
            }
            catch (Exception)
            {
                throw;
            }
            return result.Value;
        }

        public int UpdateSocietyInactive(SocietyInactiveModel model)
        {
            int? result = 0;
            try
            {
                result = new SocityDAL().UpdateSocietyInactive(model);
            }
            catch (Exception)
            {
                throw;
            }

            return result.Value;
        }
        public int DeleteSocietyDocument(DeleteSocietyDocumentModel model)
        {
            int? result = 0;
            try
            {
                result = new SocityDAL().DeleteSocietyDocument(model);
            }
            catch (Exception)
            {
                throw;
            }

            return result.Value;
        }

        public int DeleteSocietyKML(DeleteSocietyDocumentModel model)
        {
            int? result = 0;
            try
            {
                result = new SocityDAL().DeleteSocietyKML(model);
            }
            catch (Exception)
            {
                throw;
            }

            return result.Value;
        }

        internal DataTable BuildDocumentDataTable(List<DocumentModel> model)
        {
            DataTable dt = new DataTable();

            if (model != null && model.Count > 0)
            {
                model = model.Where(w => w.DocumentID == null || w.DocumentID == 0).ToList();

                // add columns in the table
                dt.Columns.Add("DocumentID", typeof(System.Int32));
                dt.Columns.Add("FileName", typeof(System.String));
                dt.Columns.Add("Title", typeof(System.String));
                dt.Columns.Add("MediaType", typeof(System.String));
                dt.Columns.Add("Attachment", typeof(SqlBinary));
                dt.Columns.Add("IsActive", typeof(System.Boolean));
                dt.Columns.Add("DocumentTypeID", typeof(System.Int32));

                DataRow dr = null;

                foreach (DocumentModel item in model)
                {
                    dr = dt.NewRow();
                    dr["DocumentID"] = item.DocumentID == null ? (object)DBNull.Value : item.DocumentID;
                    dr["FileName"] = item.FileName;
                    dr["Title"] = item.Title;
                    dr["MediaType"] = item.MediaType;
                    dr["Attachment"] = item.Attachment;
                    dr["DocumentTypeID"] = item.DocumentTypeID;
                    dt.Rows.Add(dr);
                }
            }
            return dt;
        }

        public DocumentModel DownloadFile(int? documentID)
        {
            DocumentModel objModel = null;
            try
            {
                DataTable dt = null;
                dt = new SocityDAL().DownloadFile(documentID);
                if (dt != null && dt.Rows.Count > 0)
                    objModel = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DocumentModel>(dt).ToList()[0];


            }
            catch (Exception)
            {
                throw;
            }
            return objModel;
        }

        public DocumentModel DownloadKMLFile(int? documentID, int? SocietyID)
        {
            DocumentModel objModel = null;
            try
            {
                DataTable dt = null;
                dt = new SocityDAL().DownloadKMLFile(documentID, SocietyID);
                if (dt != null && dt.Rows.Count > 0)
                    objModel = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DocumentModel>(dt).ToList()[0];

            }
            catch (Exception)
            {
                throw;
            }
            return objModel;
        }

        public int UpdateSearchCounter()
        {
            int counter = 0;
            try
            {

                counter = new SocityDAL().UpdateSearchCounter();

            }
            catch (Exception)
            {
                throw;
            }
            return counter;
        }

        public int GetSearchCounter()
        {
            int counter = 0;
            try
            {

                counter = new SocityDAL().GetSearchCounter();

            }
            catch (Exception)
            {
                throw;
            }
            return counter;
        }
    }
}