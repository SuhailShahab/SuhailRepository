﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL.Lookup;
using PITB.FC.HousingSocieties.Models.Lookup;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.BLL.Lookup
{
    public class SocietyStatusBLL :BaseBLL
    {
        public List<SocietyStatusModel> GetAllSocietyStatus()
        {
            try
            {
                DataTable dt = null;
                dt = new SocietyStatusDAL().GetAllSocietyStatus();
                return CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SocietyStatusModel>(dt);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}