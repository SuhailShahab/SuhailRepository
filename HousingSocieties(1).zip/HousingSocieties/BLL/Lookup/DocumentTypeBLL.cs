﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL.Lookup;
using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace PITB.FC.HousingSocieties.BLL.Lookup
{
    public class DocumentTypeBLL : BaseBLL
    {
        public List<DocumentTypeModel> GetAllDocumentTypes()
        {
            List<DocumentTypeModel> documentTypes = null;
            try
            {
                DataSet ds = null;
                ds = new DocumentTypeDAL().GetAllDocumentTypes();
                documentTypes = LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DocumentTypeModel>(ds.Tables[0]);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return documentTypes;
        }
    }
}