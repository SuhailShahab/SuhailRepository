﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL.Lookup;
using PITB.FC.HousingSocieties.Models.Lookup;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.BLL.Lookup
{
    public class SchemeUnApprovedReasonBLL : BaseBLL
    {
        public List<SchemeUnApprovedReasonModel> GetAllSchemeUnApprovedReason()
        {
            try
            {
                DataTable dt = null;
                dt = new SchemeUnApprovedReasonDAL().GetAllSchemeUnApprovedReason();
                return CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<SchemeUnApprovedReasonModel>(dt);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}