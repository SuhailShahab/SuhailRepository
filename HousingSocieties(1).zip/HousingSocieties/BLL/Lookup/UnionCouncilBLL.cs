﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL.Lookup;
using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.BLL.Lookup
{
    public class UnionCouncilBLL : BaseBLL
    {
        public List<UnionCouncilModel> GetAllUnionCouncil()
        {
            try
            {
                DataTable dt = null;
                dt = new UnionCouncilDAL().GetAllUnionCouncil();
                return CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<UnionCouncilModel>(dt);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}