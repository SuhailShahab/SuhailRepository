﻿using PITB.FC.HousingSocieties.DAL.Lookup;
using PITB.FC.HousingSocieties.Models.Lookup;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.BLL.Lookup
{
    public class VisitorCountBLL : BaseBLL
    {
        public int? Add(VisitorCountModel visitorCount)
        {
            try
            {
                return new VisitorCountDAL().SaveData(visitorCount);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}