﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL.Lookup;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.BLL.Lookup
{
    public class UserBLL : BaseBLL
    {
        public Identity.ApplicationUser GetByUserName(string userName)
        {
            try
            {
                DataTable dt = null;
                dt = new UserDAL().GetByUserName(userName);
                if (dt != null && dt.Rows.Count > 0)
                {
                    return CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel<Identity.ApplicationUser>(dt).FirstOrDefault();
                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }
        public Identity.ApplicationUser GetByUserID(int userId)
        {
            try
            {
                DataTable dt = null;
                dt = new UserDAL().GetByUserID(userId);
                if (dt != null && dt.Rows.Count > 0)
                {
                    return CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel<Identity.ApplicationUser>(dt).FirstOrDefault();
                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }
        public Identity.ApplicationUser Create(Identity.ApplicationUser user)
        {
            try
            {
                return new UserDAL().Create(user);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Identity.ApplicationUser Update(Identity.ApplicationUser user)
        {
            try
            {
                return new UserDAL().Update(user);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}