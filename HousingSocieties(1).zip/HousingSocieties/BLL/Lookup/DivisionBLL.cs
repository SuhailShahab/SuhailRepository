﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL.Lookup;
using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace PITB.FC.HousingSocieties.BLL.Lookup
{
    public class DivisionBLL : BaseBLL
    {
        public List<DivisionModel> GetAllDivisions()
        {
            try
            {
                DataSet ds = null;
                ds = new DivisionDAL().GetAllDivisions();
                List<DivisionModel> Divisions = CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DivisionModel>(ds.Tables[0]);

                if(Divisions != null)
                {
                    foreach (DivisionModel item in Divisions)
                    {
                        item.AuthorityIDs = (from x in ds.Tables[1].AsEnumerable()
                                             where x.Field<int>("DivisionID") == item.ID
                                             select x.Field<int>("AuthorityID")).ToList();
                    }
                }

                return Divisions;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}