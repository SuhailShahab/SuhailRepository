﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL.Lookup;
using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.Data;

namespace PITB.FC.HousingSocieties.BLL.Lookup
{
    public class CityBLL:BaseBLL
    {
        public List<CityModel> GetAllCities()
        {
            try
            {
                DataTable dt = null;
                dt = new CityDAL().GetAllCities();
                return CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<CityModel>(dt);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}