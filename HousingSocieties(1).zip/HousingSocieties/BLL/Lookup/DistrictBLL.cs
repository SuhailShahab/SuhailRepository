﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.DAL.Lookup;
using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.Data;

namespace PITB.FC.HousingSocieties.BLL.Lookup
{
    public class DistrictBLL:BaseBLL
    {
        public List<DistrictModel> GetAllDistricts()
        {
            try
            {
                DataTable dt = null;
                dt = new DistrictDAL().GetAllDistricts();
                return CommonUtility.LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<DistrictModel>(dt);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}