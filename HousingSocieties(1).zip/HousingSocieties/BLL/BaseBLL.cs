﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.BLL
{
    public abstract class BaseBLL
    {
    }
}