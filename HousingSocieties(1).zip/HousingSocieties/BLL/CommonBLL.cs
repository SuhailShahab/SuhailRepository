﻿using PITB.FC.HousingSocieties.DAL;
using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.BLL
{
    public class CommonBLL
    {
        public int SaveErrorLogs(ErrorLogModel ErrorLog)
        {
            return new CommonDAL().SaveErrorLogs(ErrorLog);
        }
    }
}