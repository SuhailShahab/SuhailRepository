﻿using PITB.FC.HousingSocieties.BLL.Lookup;
using PITB.FC.HousingSocieties.CommonUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PITB.FC.HousingSocieties.Controllers
{
    public class BaseController : ApiController
    {
        public Identity.ApplicationUser LoggedUser
        {
            get
            {
                if (User.Identity.IsAuthenticated)
                {
                    return LazyBaseSingleton<UserBLL>.Instance.GetByUserName(User.Identity.Name);
                }

                return null;
            }
        }
    }
}