﻿using PITB.FC.HousingSocieties.BLL;
using PITB.FC.HousingSocieties.BLL.Lookup;
using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.Models;
using PITB.FC.HousingSocieties.Models.Lookup;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Script.Serialization;

namespace PITB.FC.HousingSocieties.Controllers
{
    public class DownloadFileResult : IHttpActionResult
    {
        MemoryStream bookStuff;
        string PdfFileName;
        string MediaType;
        HttpRequestMessage httpRequestMessage;
        HttpResponseMessage httpResponseMessage;

        public DownloadFileResult(MemoryStream data, HttpRequestMessage request, string filename, string mediaType = "application/octet-stream")
        {
            bookStuff = data;
            httpRequestMessage = request;
            PdfFileName = filename;
            MediaType = mediaType;
        }

        public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
        {
            httpResponseMessage = httpRequestMessage.CreateResponse(HttpStatusCode.OK);
            httpResponseMessage.Content = new StreamContent(bookStuff);

            httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
            httpResponseMessage.Content.Headers.ContentDisposition.FileName = PdfFileName;
            httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(MediaType);

            return Task.FromResult(httpResponseMessage);
        }
    }

    [RoutePrefix("api/Societies")]
    public class SocietiesController : BaseController
    {
        [HttpGet, Route("GetRecords")]
        public SocietyModelView GetRecords(int? reqTypeID = null)
        {
            VisitorCountModel visitorModel = new VisitorCountModel();
            visitorModel.UserIP = CommonAPI.GetUserIP();
            visitorModel.TypeID = reqTypeID;

            if (this.Request.Headers.Referrer != null)
            {
                visitorModel.PageReferral = this.Request.Headers.Referrer.ToString();
            }

            if (this.LoggedUser != null)
            {
                visitorModel.UserID = this.LoggedUser.Id;
            }

            if (HttpContext.Current.Session != null)
            {
                visitorModel.SessionID = HttpContext.Current.Session.SessionID;
            }

            SocietyModelView viewModel = new SocietyModelView();
            viewModel.colViewSocities = LazyBaseSingleton<SocityBLL>.Instance.GetAllSocitiesViewData();
            viewModel.SearchCounter = LazyBaseSingleton<SocityBLL>.Instance.GetSearchCounter();
            viewModel.VisitorHitCounts = LazyBaseSingleton<VisitorCountBLL>.Instance.Add(visitorModel);
            viewModel.colDevelopmentAuthorities = LazyBaseSingleton<DevelopmentAuthorityBLL>.Instance.GetAllAuthorities();
            viewModel.colCity = LazyBaseSingleton<CityBLL>.Instance.GetAllCities();
            viewModel.colDistrict = LazyBaseSingleton<DistrictBLL>.Instance.GetAllDistricts();
            viewModel.colDivision = LazyBaseSingleton<DivisionBLL>.Instance.GetAllDivisions();
            viewModel.colSocietyStatus = LazyBaseSingleton<SocietyStatusBLL>.Instance.GetAllSocietyStatus();

            string input = "SchemeID=";
            if (viewModel.colViewSocities != null && viewModel.colViewSocities.Count > 0)
            {
                foreach (var item in viewModel.colViewSocities)
                {
                    item.EncURL = Encryption.EncryptString(ConfigurationReader.EncryptionKey, input + Convert.ToString(item.ID));
                }
            }
            return viewModel;
        }

        [HttpGet, Route("GetRecordsByFilters")]
        public SocietyModelView GetRecordsByFilters(int? DevelopmentAuthoritieID = null,
            int? DivisionID = null, int? DistrictID = null, int? SocietyStatusID = null,
            int? ReqTypeID = null, int PageNumber = 1, int PageSize = 50, string SearchTerm = null)
        {
            VisitorCountModel visitorModel = new VisitorCountModel();
            visitorModel.UserIP = CommonAPI.GetUserIP();
            visitorModel.TypeID = ReqTypeID;

            if (this.Request.Headers.Referrer != null)
            {
                visitorModel.PageReferral = this.Request.Headers.Referrer.ToString();
            }

            if (this.LoggedUser != null)
            {
                visitorModel.UserID = this.LoggedUser.Id;
            }

            if (HttpContext.Current.Session != null)
            {
                visitorModel.SessionID = HttpContext.Current.Session.SessionID;
            }

            SocietySearchModel searchModel = new SocietySearchModel();
            searchModel.DevelopmentAuthoritieID = DevelopmentAuthoritieID;
            searchModel.DivisionID = DivisionID;
            searchModel.DistrictID = DistrictID;
            searchModel.SocietyStatusID = SocietyStatusID;
            searchModel.SearchTerm = SearchTerm;

            SocietyModelView viewModel = null;
            viewModel = LazyBaseSingleton<SocityBLL>.Instance.GetSocitiesPagedViewData(searchModel, PageNumber, PageSize);

            if (PageNumber == 1)
            {
                viewModel.SearchCounter = LazyBaseSingleton<SocityBLL>.Instance.GetSearchCounter();
                viewModel.VisitorHitCounts = LazyBaseSingleton<VisitorCountBLL>.Instance.Add(visitorModel);

                viewModel.colDevelopmentAuthorities = LazyBaseSingleton<DevelopmentAuthorityBLL>.Instance.GetAllAuthorities();
                viewModel.colCity = LazyBaseSingleton<CityBLL>.Instance.GetAllCities();
                viewModel.colDistrict = LazyBaseSingleton<DistrictBLL>.Instance.GetAllDistricts();
                viewModel.colDivision = LazyBaseSingleton<DivisionBLL>.Instance.GetAllDivisions();
                viewModel.colSocietyStatus = LazyBaseSingleton<SocietyStatusBLL>.Instance.GetAllSocietyStatus();

                viewModel.SchemeStatusCounts = LazyBaseSingleton<SocityBLL>.Instance.GetSchemeStatusCount();
            }

            return viewModel;
        }

        [HttpGet, Route("GetRecordsByFiltersPaged")]
        public SocietyModelView GetRecordsByFiltersPaged(int? DevelopmentAuthoritieID = null,
            int? DivisionID = null, int? DistrictID = null, int? SocietyStatusID = null,
            int? ReqTypeID = null, int PageNumber = 1, int PageSize = 50, string SearchTerm = null)
        {
            SocietySearchModel searchModel = new SocietySearchModel();
            searchModel.DevelopmentAuthoritieID = DevelopmentAuthoritieID;
            searchModel.DivisionID = DivisionID;
            searchModel.DistrictID = DistrictID;
            searchModel.SocietyStatusID = SocietyStatusID;
            searchModel.SearchTerm = SearchTerm;

            SocietyModelView viewModel = null;
            viewModel = LazyBaseSingleton<SocityBLL>.Instance.GetSocitiesPagedViewData(searchModel, PageNumber, PageSize);

            return viewModel;
        }

        [Authorize, HttpGet, Route("GetRecordByID")]
        public SocietyModelView GetRecordByID(int? ID = null)
        {
            SocietyModelView viewModel = new SocietyModelView();
            try
            {
                viewModel.UserDisplayName = string.IsNullOrEmpty(this.LoggedUser.DisplayName) ? this.LoggedUser.UserName : this.LoggedUser.DisplayName;
                //viewModel.colDevelopmentAuthorities = LazyBaseSingleton<DevelopmentAuthorityBLL>.Instance.GetAllAuthorities();
                //viewModel.colDistrict = LazyBaseSingleton<DistrictBLL>.Instance.GetAllDistricts();
                //viewModel.colDivision = LazyBaseSingleton<DivisionBLL>.Instance.GetAllDivisions();
                //viewModel.colSocietyStatus = LazyBaseSingleton<SocietyStatusBLL>.Instance.GetAllSocietyStatus();
                if (ID != null)
                {
                    viewModel.Model = LazyBaseSingleton<SocityBLL>.Instance.GetSocietyByID(ID, this.LoggedUser.Id);
                }

                LazyBaseSingleton<SocityBLL>.Instance.GetSocietiesFillLists(viewModel, this.LoggedUser.Id); // get Authorities, District, Division and Society Status

                viewModel.colCity = LazyBaseSingleton<CityBLL>.Instance.GetAllCities();
                viewModel.colUnionCouncil = LazyBaseSingleton<UnionCouncilBLL>.Instance.GetAllUnionCouncil();
                viewModel.colOwnershipLands = LazyBaseSingleton<OwnershipLandBLL>.Instance.GetAllOwnershipLand();
                viewModel.colSchemeUnApprovedReason = LazyBaseSingleton<SchemeUnApprovedReasonBLL>.Instance.GetAllSchemeUnApprovedReason();
                viewModel.colDocumentTypes = LazyBaseSingleton<DocumentTypeBLL>.Instance.GetAllDocumentTypes();

                LazyBaseSingleton<SocityBLL>.Instance.GetSocietyFillLookups(viewModel); // get NOCDepartment, ActionTaken, AvailableFacility
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    viewModel = new SocietyModelView(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    viewModel = new SocietyModelView(StatusType.error, ex.Message);
                }
            }
            return viewModel;
        }

        [Authorize, HttpGet, Route("GetSocietiesData")]
        public SocietyModelView GetSocietiesData(int? AuthorityID, int? DivisionID, int? DistrictID, int? SocietyStatusID)
        {
            SocietyModelView viewModel = new SocietyModelView();
            try
            {

                viewModel.UserDisplayName = string.IsNullOrEmpty(this.LoggedUser.DisplayName) ? this.LoggedUser.UserName : this.LoggedUser.DisplayName;

                SocietySearchModel searchModel = new SocietySearchModel();
                searchModel.UserID = this.LoggedUser.Id;
                searchModel.DevelopmentAuthoritieID = AuthorityID;
                searchModel.DivisionID = DivisionID;
                searchModel.DistrictID = DistrictID;
                searchModel.SocietyStatusID = SocietyStatusID;

                viewModel.colSocities = LazyBaseSingleton<SocityBLL>.Instance.GetSocietiesData(searchModel);
                LazyBaseSingleton<SocityBLL>.Instance.GetSocietiesFillLists(viewModel, searchModel.UserID); // get Authorities, District, Division and Society Status

                //viewModel.colDevelopmentAuthorities = LazyBaseSingleton<DevelopmentAuthorityBLL>.Instance.GetAllAuthorities();
                //viewModel.colDistrict = LazyBaseSingleton<DistrictBLL>.Instance.GetAllDistricts();
                //viewModel.colDivision = LazyBaseSingleton<DivisionBLL>.Instance.GetAllDivisions();
                //viewModel.colSocietyStatus = LazyBaseSingleton<SocietyStatusBLL>.Instance.GetAllSocietyStatus();
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    viewModel = new SocietyModelView(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    viewModel = new SocietyModelView(StatusType.error, ex.Message);
                }
            }
            return viewModel;
        }

        /// <summary>
        /// Save Society Information
        /// </summary>
        /// <returns></returns>
        [Authorize, HttpPost, Route("SaveSocietyInformation")]
        public SocietyModelView SaveSocietyInformation()
        {
            #region Declaration Variable

            SocietyModelView modelView = new SocietyModelView(StatusType.success, string.Empty);
            #endregion
            try
            {
                if (HttpContext.Current.Request.Form["Data"] == null || HttpContext.Current.Request.Form["Data"].ToString() == "")
                {
                    return new SocietyModelView(StatusType.error, "Invalid Data");
                }
                else
                {
                    SocietyModel model = new JavaScriptSerializer().Deserialize<SocietyModel>(HttpContext.Current.Request.Form["Data"].ToString());

                    string validationResult = IsValidateData(model);
                    int? result = 0;
                    if (!string.IsNullOrEmpty(validationResult))
                    {
                        return new SocietyModelView(StatusType.Info, validationResult);
                    }

                    List<DocumentModel> docListModel = new List<DocumentModel>();

                    HttpRequest request = HttpContext.Current.Request;
                    if (request.Files.Count > 0)
                    {
                        docListModel = AttachDocuments(request);
                    }
                    model.lstSocietyKML = docListModel.Where(x => x.DocumentTypeID == 2).ToList(); // 2 document type id for KML
                    model.lstSocietyDocument = docListModel.Where(x => x.DocumentTypeID != 2).ToList();


                    // vals.Where(x => x > 0).ToList();
                    /*
                    DocumentModel KMLDocumentFile = null;
                    if (docListModel != null && docListModel.Count > 0)
                    {
                        if (HttpContext.Current.Request.Form["IsMAPFile"] == "1")
                        {
                            if (docListModel.Count == 1)
                            {
                                model.lstSocietyDocument = docListModel;
                            }
                            else
                            {
                                List<DocumentModel> docMapListModel = new List<DocumentModel>();
                                docMapListModel.Add(docListModel.FirstOrDefault());
                                model.lstSocietyDocument = docMapListModel;
                            }
                        }

                        if (HttpContext.Current.Request.Form["IsKMLFile"] == "1")
                        {
                            if (docListModel.Count == 1)
                            {
                                KMLDocumentFile = docListModel.FirstOrDefault();
                                model.lstSocietyKML = docListModel;
                            }
                            else
                            {
                                KMLDocumentFile = docListModel[1];
                                model.lstSocietyKML = docListModel.Skip(1).Take(1).ToList();
                            }
                        }
                    }
                    */
                    if (model.lstSocietyKML != null && model.lstSocietyKML.Count > 0)
                    {
                        model.IsKMLAvailable = true;
                    }

                    model.CreatedBy = this.LoggedUser.Id;

                    if (model.ID.HasValue && model.ID.Value > 0)
                        result = LazyBaseSingleton<SocityBLL>.Instance.UpdateData(model);
                    else
                        result = LazyBaseSingleton<SocityBLL>.Instance.SaveData(model);

                    if (result.HasValue && result.Value > 0)
                    {
                        /* 
                         * // KML file saving in folder code
                        if (KMLDocumentFile != null)
                        {
                            string _FileName = Path.GetFileName(KMLDocumentFile.FileName);
                            string[] arrFileName;
                            arrFileName = _FileName.Split('.');  // 0 = FileName, 1 = {FileExtension},

                            // making file name from society id
                            if (model.ID.HasValue && model.ID.Value > 0)
                                _FileName = Convert.ToString(model.ID.Value) + "." + Convert.ToString(arrFileName[1]);
                            else
                                _FileName = Convert.ToString(result.Value) + "." + Convert.ToString(arrFileName[1]);
                            //string _path = Path.Combine(System.Web.HttpContext.Current.Server.MapPath("~/SocietiesKMLFiles"), _FileName);
                            string KMLFolderPath = ConfigurationReader.KMLFolderPath;
                            string _path = Path.Combine(KMLFolderPath, _FileName);

                            using (System.IO.FileStream file = new System.IO.FileStream(_path, FileMode.OpenOrCreate, FileAccess.ReadWrite))
                            {
                                using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream(KMLDocumentFile.Attachment))
                                {
                                    memoryStream.CopyTo(file);
                                }
                            }
                        }
                        */
                        modelView = new SocietyModelView(StatusType.success, "Data saved Successfully!");
                    }
                    else
                    {
                        modelView = new SocietyModelView(StatusType.error, "No data saved!");
                    }
                }
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    modelView = new SocietyModelView(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    modelView = new SocietyModelView(StatusType.error, ex.Message);
                }
            }

            return modelView;
        }

        private List<DocumentModel> AttachDocuments(HttpRequest request)
        {
            List<DocumentModel> files = new List<DocumentModel>();

            for (int i = 0; i < request.Files.Count; i++)
            {
                DocumentModel fileModel = new DocumentModel();
                HttpPostedFile postFile = request.Files[i];

                using (System.IO.MemoryStream memoryStream = new System.IO.MemoryStream())
                {
                    postFile.InputStream.CopyTo(memoryStream);
                    fileModel.Attachment = memoryStream.ToArray();
                }

                fileModel.Title = request.Files[i].FileName;
                fileModel.MediaType = request.Files[i].ContentType;
                fileModel.FileName = Convert.ToString(request.Form["FileName" + i]);
                fileModel.DocumentTypeID = Convert.ToInt32(request.Form["DocumentTypeID" + i]);

                // fileModel.Title = request.Form["DocumentTypeStaticName" + i].ToString();

                files.Add(fileModel);
            }
            return files;
        }
        private string IsValidateData(SocietyModel model)
        {
            if (string.IsNullOrEmpty(model.Name))
                return "Society name is required";
            else
                return string.Empty;
        }

        [Authorize, HttpPost, Route("UpdateSocietyInactive")]
        public SocietyInactiveModel UpdateSocietyInactive(SocietyInactiveModel inactiveModel)
        {
            try
            {
                inactiveModel.UserID = this.LoggedUser.Id;
                if (inactiveModel.SocietyID.HasValue == false)
                {
                    return new SocietyInactiveModel(StatusType.error, "Society ID not provided");
                }

                int? result = 0;
                result = LazyBaseSingleton<SocityBLL>.Instance.UpdateSocietyInactive(inactiveModel);

                if (result.HasValue && result.Value > 0)
                {
                    return new SocietyInactiveModel(StatusType.success, "Data saved Successfully!");
                }
                else
                {
                    return new SocietyInactiveModel(StatusType.error, "No data saved!");
                }
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    inactiveModel = new SocietyInactiveModel(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    inactiveModel = new SocietyInactiveModel(StatusType.error, ex.Message);
                }

            }

            return inactiveModel;
        }

        [Authorize, HttpPost, Route("DeleteSocietyDocument")]
        public DeleteSocietyDocumentModel DeleteSocietyDocument(DeleteSocietyDocumentModel deleteModel)
        {

            try
            {
                deleteModel.UserID = this.LoggedUser.Id;
                if (deleteModel.SocietyID.HasValue == false)
                {
                    return new DeleteSocietyDocumentModel(StatusType.error, "Society ID not provided");
                }
                if (deleteModel.DocumentID.HasValue == false)
                {
                    return new DeleteSocietyDocumentModel(StatusType.error, "Document not provided");
                }

                int? result = 0;
                result = LazyBaseSingleton<SocityBLL>.Instance.DeleteSocietyDocument(deleteModel);

                if (result.HasValue && result.Value > 0)
                {
                    deleteModel = new DeleteSocietyDocumentModel(StatusType.success, "Data saved Successfully!");
                }
                else
                {
                    deleteModel = new DeleteSocietyDocumentModel(StatusType.error, "No data saved!");
                }
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    deleteModel = new DeleteSocietyDocumentModel(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    deleteModel = new DeleteSocietyDocumentModel(StatusType.error, ex.Message);
                }
            }

            return deleteModel;
        }

        [Authorize, HttpPost, Route("DeleteSocietyKML")]
        public DeleteSocietyDocumentModel DeleteSocietyKML(DeleteSocietyDocumentModel deleteModel)
        {

            try
            {
                deleteModel.UserID = this.LoggedUser.Id;
                if (deleteModel.SocietyID.HasValue == false)
                {
                    return new DeleteSocietyDocumentModel(StatusType.error, "Society ID not provided");
                }
                if (deleteModel.DocumentID.HasValue == false)
                {
                    return new DeleteSocietyDocumentModel(StatusType.error, "KML not provided");
                }

                int? result = 0;
                result = LazyBaseSingleton<SocityBLL>.Instance.DeleteSocietyKML(deleteModel);

                if (result.HasValue && result.Value > 0)
                {
                    deleteModel = new DeleteSocietyDocumentModel(StatusType.success, "Data saved Successfully!");
                }
                else
                {
                    deleteModel = new DeleteSocietyDocumentModel(StatusType.error, "No data saved!");
                }
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    deleteModel = new DeleteSocietyDocumentModel(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    deleteModel = new DeleteSocietyDocumentModel(StatusType.error, ex.Message);
                }
            }

            return deleteModel;
        }

        [HttpGet, Route("GetMapFile/{DocumentID:int}")]
        public IHttpActionResult DownloadFile(int DocumentID)
        {
            DocumentModelView docModelView = null;
            try
            {
                DocumentModel docModel = LazyBaseSingleton<SocityBLL>.Instance.DownloadFile(DocumentID);
                if (docModel != null)
                {
                    MemoryStream dataStream = new MemoryStream(docModel.Attachment);
                    DownloadFileResult resp = new DownloadFileResult(dataStream, Request, docModel.Title);
                    return resp;
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    docModelView = new DocumentModelView(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    docModelView = new DocumentModelView(StatusType.error, ex.Message);
                }
            }

            return Ok(docModelView);
        }

        [HttpGet, Route("GetKMLMapFile/{DocumentID:int}")]
        public IHttpActionResult DownloadKMLFile(int DocumentID)
        {
            DocumentModelView docModelView = null;
            try
            {
                DocumentModel docModel = LazyBaseSingleton<SocityBLL>.Instance.DownloadKMLFile(DocumentID, null);
                if (docModel != null)
                {
                    MemoryStream dataStream = new MemoryStream(docModel.Attachment);
                    DownloadFileResult resp = new DownloadFileResult(dataStream, Request, docModel.Title, "application/vnd.google-earth.kml+xml");
                    return resp;
                }
                else
                {
                    return NotFound();
                }
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    docModelView = new DocumentModelView(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    docModelView = new DocumentModelView(StatusType.error, ex.Message);
                }
            }

            return Ok(docModelView);
        }

        [HttpPost, Route("UpdateSearchCounter")]
        public int UpdateSearchCounter()
        {
            #region Declaration Variable
            int SearchCounter = 0;
            #endregion
            try
            {
                SearchCounter = LazyBaseSingleton<SocityBLL>.Instance.UpdateSearchCounter();
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));
            }

            return SearchCounter;
        }

        [HttpGet, Route("GetSearchCounter")]
        public int GetSearchCounter()
        {
            #region Declaration Variable
            int SearchCounter = 0;
            #endregion
            try
            {
                SearchCounter = LazyBaseSingleton<SocityBLL>.Instance.GetSearchCounter();
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));
            }

            return SearchCounter;
        }

        [HttpGet, Route("GetSocietyDetailByID")]
        public SocietyModelView GetSocietyDetailByID(int? ID = null, string URL = "")
        {
            SocietyModelView viewModel = new SocietyModelView();
            try
            {
                //viewModel.UserDisplayName = string.IsNullOrEmpty(this.LoggedUser.DisplayName) ? this.LoggedUser.UserName : this.LoggedUser.DisplayName;

                if (ID != null)
                {
                    viewModel.Model = LazyBaseSingleton<SocityBLL>.Instance.GetSocietyDetailByID(ID);
                    //viewModel.Model.QRCode = GetSocietyQRCode(-1, URL);
                }

                //LazyBaseSingleton<SocityBLL>.Instance.GetSocietiesFillLists(viewModel, this.LoggedUser.Id); // get Authorities, District, Division and Society Status

                //viewModel.colCity = LazyBaseSingleton<CityBLL>.Instance.GetAllCities();
                //viewModel.colUnionCouncil = LazyBaseSingleton<UnionCouncilBLL>.Instance.GetAllUnionCouncil();
                //viewModel.colOwnershipLands = LazyBaseSingleton<OwnershipLandBLL>.Instance.GetAllOwnershipLand();
                //viewModel.colSchemeUnApprovedReason = LazyBaseSingleton<SchemeUnApprovedReasonBLL>.Instance.GetAllSchemeUnApprovedReason();

                //LazyBaseSingleton<SocityBLL>.Instance.GetSocietyFillLookups(viewModel); // get NOCDepartment, ActionTaken, AvailableFacility
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    viewModel = new SocietyModelView(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    viewModel = new SocietyModelView(StatusType.error, ex.Message);
                }
            }
            return viewModel;
        }

        [HttpGet, Route("GetSocietyDetailByEncURL")]
        public SocietyModelView GetSocietyDetailByEncURL(string URL = "")
        {
            SocietyModelView viewModel = new SocietyModelView();
            try
            {

                if (!string.IsNullOrEmpty(URL) && URL.Length > 0)
                {
                    string[] urls = URL.Split('?');
                    string decryptURL = Encryption.DecryptString(ConfigurationReader.EncryptionKey, urls[1]);
                    string[] parms = decryptURL.Split('=');
                    viewModel.Model = LazyBaseSingleton<SocityBLL>.Instance.GetSocietyDetailByID(Convert.ToInt32(parms[1]));
                    viewModel.Model.QRCode = GetSocietyQRCode(-1, URL);
                }
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));

                if (ConfigurationReader.IsShowGeneralMsg)
                {
                    viewModel = new SocietyModelView(StatusType.error, ConfigurationReader.GeneralMsg + errorCode);
                }
                else
                {
                    viewModel = new SocietyModelView(StatusType.error, ex.Message);
                }
            }
            return viewModel;
        }


        [HttpGet, Route("GetSocietyQRCode")]
        public string GetSocietyQRCode(int SchemeID, string URL)
        {

            try
            {
                QRCoder.QRCodeGenerator qrGenerator = new QRCoder.QRCodeGenerator();

                string qrToken = null;
                if (SchemeID != -1)
                {
                    string input = "SchemeID=";
                    URL = URL.TrimEnd('/');
                    qrToken = URL.Substring(0, URL.LastIndexOf('/'));
                    qrToken += "/HousingSocietiesDetail?" + Encryption.EncryptString(ConfigurationReader.EncryptionKey, input + Convert.ToString(SchemeID));
                }
                else
                {
                    qrToken = URL;
                }


                QRCoder.QRCodeData qrCodeData = qrGenerator.CreateQrCode(
                   qrToken,
                   QRCoder.QRCodeGenerator.ECCLevel.M
                );

                QRCoder.PngByteQRCode qrCode = new QRCoder.PngByteQRCode(qrCodeData);
                byte[] qrCodeAsPngByteArr = qrCode.GetGraphic(114 / qrCodeData.ModuleMatrix.Count());
                return Convert.ToBase64String(qrCodeAsPngByteArr.ToArray());
            }
            catch (Exception ex)
            {
                string errorCode = "";
                errorCode = LazyBaseSingleton<CommonAPI>.Instance.AddErrorLogs(new ErrorLogModel(ex, MethodBase.GetCurrentMethod().Name, 1, this.GetType().Name));
            }

            return "";
        }
    }
}