﻿$(document).ready(function () {

    var originalXhr = $.ajaxSettings.xhr;

    window.defaultOnUploadProgress = function (event, position, total, percent) {

        var $modal = $('.js-loading-bar'),
            $bar = $modal.find('.progress-bar'),
            $textbar = $modal.find('.progress-text');

        if ($modal.length > 0) {

            if ($modal.is(":visible") == false) {
                console.log('Showing loader');
                $bar.css('width', 0);
                $textbar.html('0% uploaded');
                $modal.modal('show');
                $('#overlay').hide();
            }

            var showpercent = parseFloat(percent).toFixed(2);

            $bar.css('width', percent + '%');
            $textbar.html('Submitting data to server: ' + showpercent + '% uploaded');
            var position = event.loaded || event.position;
            console.log((position / total) + '-> ' + showpercent + ' % done');

            if (percent >= 100) {
                console.log('Hiding loader');
                $textbar.html('Started processing data.....');

                setTimeout(function () {
                    $modal.modal('hide');
                    $bar.css('width', 0);
                    $textbar.html('0% uploaded');
                }, 100);

                $('#overlay').show();
            }
        }
    }

    window.defaultOnProgress = function (event, position, total, percent) {

        var $modal = $('.js-loading-bar'),
            $bar = $modal.find('.progress-bar'),
            $textbar = $modal.find('.progress-text');

        if ($modal.length > 0) {

            if ($modal.is(":visible") == false) {
                console.log('Showing loader');
                $bar.css('width', 0);
                $textbar.html('0% downloaded');
                $modal.modal('show');
                $('#overlay').hide();
            }

            var showpercent = parseFloat(percent).toFixed(2);

            $bar.css('width', percent + '%');
            $textbar.html('Downloading data to server: ' + showpercent + '% downloaded');
            var position = event.loaded || event.position;
            console.log((position / total) + '-> ' + showpercent + ' % done');

            if (percent >= 100) {
                console.log('Hiding loader');
                $textbar.html('Started processing data.....');

                setTimeout(function () {
                    $modal.modal('hide');
                    $bar.css('width', 0);
                    $textbar.html('0% Downloaded');
                }, 100);

                $('#overlay').show();
            }
        }
    }

    $.ajaxPrefilter(function (options, originalOptions, jqXHR) {
        options.xhr = function () {
            var xhr = originalXhr();

            if (options.processData == false && options.contentType == false && $.trim(options.type).toLowerCase() == "post") {
                xhr.upload.addEventListener("progress", function (evt) {
                    if (evt.lengthComputable) {
                        var pct = evt.loaded / evt.total;
                        var position = evt.loaded || evt.position;

                        window.defaultOnUploadProgress(evt, position, evt.total, pct * 100);
                    }
                }, false);

                if (typeof options.error == 'function') {
                    options.prevErrorHandler = options.error;
                }

                options.error = function (jqXHR, textStatus, errorThrown) {
                    var $modal = $('.js-loading-bar');

                    if ($modal.length > 0) {
                        if ($modal.is(":visible")) {
                            $modal.modal('hide');
                            $('#overlay').hide();
                        }
                    }

                    if (typeof options.prevErrorHandler == 'function') {
                        prevErrorHandler(jqXHR, textStatus, errorThrown);
                    }
                }
            }

            if (typeof options.downloadProgress !== 'undefined' && options.downloadProgress) {
                xhr.addEventListener("progress", function (evt) {
                    if (evt.lengthComputable) {
                        var pct = evt.loaded / evt.total;
                        var position = evt.loaded || evt.position;

                        window.defaultOnProgress(evt, position, evt.total, pct * 100);
                    }
                }, false);

                if (typeof options.error == 'function') {
                    options.prevErrorHandler = options.error;
                }

                options.error = function (jqXHR, textStatus, errorThrown) {
                    var $modal = $('.js-loading-bar');

                    if ($modal.length > 0) {
                        if ($modal.is(":visible")) {
                            $modal.modal('hide');
                            $('#overlay').hide();
                        }
                    }

                    if (typeof options.prevErrorHandler == 'function') {
                        prevErrorHandler(jqXHR, textStatus, errorThrown);
                    }
                }
            }

            return xhr;
        }
    });

    $('.js-loading-bar').modal({
        backdrop: 'static',
        show: false
    });

});