const APIResponseType = {
    SUCCESS: "Success",//100
    WARNING: "Warning",//200
    EXCEPTION: "Exception",//900
    ERROR: "Error"//400
}

const PortalUserTypes = {
    None: 0,
    CitizenMobile: 1,
    CitizenPortal: 2,
    ScrutinizedPortal: 3
}

const HTTPStatusCode = {
    CONTINUE: 100,
    SWITCHING_PROTOCOLS: 101,
    PROCESSING: 102,
    EARLY_HINTS: 103,
    OK: 200,
    CREATED: 201,
    ACCEPTED: 202,
    NON_AUTHORITATIVE_INFORMATION: 203,
    NO_CONTENT: 204,
    RESET_CONTENT: 205,
    PARTIAL_CONTENT: 206,
    MULTI_STATUS: 207,
    ALREADY_REPORTED: 208,
    IM_USED: 226,
    MULTIPLE_CHOICES: 300,
    MOVED_PERMANENTLY: 301,
    FOUND: 302,
    SEE_OTHER: 303,
    NOT_MODIFIED: 304,
    USE_PROXY: 305,
    TEMPORARY_REDIRECT: 307,
    PERMANENT_REDIRECT: 308,
    BAD_REQUEST: 400,
    UNAUTHORIZED: 401,
    PAYMENT_REQUIRED: 402,
    FORBIDDEN: 403,
    NOT_FOUND: 404,
    METHOD_NOT_ALLOWED: 405,
    NOT_ACCEPTABLE: 406,
    PROXY_AUTHENTICATION_REQUIRED: 407,
    REQUEST_TIMEOUT: 408,
    CONFLICT: 409,
    GONE: 410,
    LENGTH_REQUIRED: 411,
    PRECONDITION_FAILED: 412,
    PAYLOAD_TOO_LARGE: 413,
    URI_TOO_LONG: 414,
    UNSUPPORTED_MEDIA_TYPE: 415,
    RANGE_NOT_SATISFIABLE: 416,
    EXPECTATION_FAILED: 417,
    IM_A_TEAPOT: 418,
    MISDIRECTED_REQUEST: 421,
    UNPROCESSABLE_ENTITY: 422,
    LOCKED: 423,
    FAILED_DEPENDENCY: 424,
    TOO_EARLY: 425,
    UPGRADE_REQUIRED: 426,
    PRECONDITION_REQUIRED: 428,
    TOO_MANY_REQUESTS: 429,
    REQUEST_HEADER_FIELDS_TOO_LARGE: 431,
    UNAVAILABLE_FOR_LEGAL_REASONS: 451,
    INTERNAL_SERVER_ERROR: 500,
    NOT_IMPLEMENTED: 501,
    BAD_GATEWAY: 502,
    SERVICE_UNAVAILABLE: 503,
    GATEWAY_TIMEOUT: 504,
    HTTP_VERSION_NOT_SUPPORTED: 505,
    VARIANT_ALSO_NEGOTIATES: 506,
    INSUFFICIENT_STORAGE: 507,
    LOOP_DETECTED: 508,
    BANDWIDTH_LIMIT_EXCEEDED: 509,
    NOT_EXTENDED: 510,
    NETWORK_AUTHENTICATION_REQUIRED: 511
};

function handleResponseError(respHeaderAJAX) {
    if (respHeaderAJAX.status == APIResponseType.EXCEPTION) {
        toastr.error(respHeaderAJAX.message);
    } else if (respHeaderAJAX.status == APIResponseType.ERROR || respHeaderAJAX.status == APIResponseType.WARNING) {
        toastr.info(respHeaderAJAX.message);
    }
}

$(document).ready(function () {
    $('ul.nav li.dropdown').hover(function () {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
    }, function () {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });

    $('#myCarousel .carousel-indicators li:last-child').remove();
    $('#myCarousel .carousel-inner .item:last-child').remove();
});

function getWebAPIPath() {
    let WebAPIPath = $('input[name$="WebAPIPath"]').val();

    if ($.trim(WebAPIPath).length > 0) {
        return WebAPIPath;
    }

    return "";
}

function getAccessToken() {
    return localStorage.getItem("AccessToken");
}


function browserIsIE() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");

    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
        // If Internet Explorer, return version number
        return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));
    }

    return false;
}

function getFileSizeMB(fileObj) {
    try {
        var fileSize = 0;
        //for IE
        if (browserIsIE()) {//we could use this $.browser.msie but since it's depracted we'll use this function
            //before making an object of ActiveXObject, 
            //please make sure ActiveX is enabled in your IE browser
            var objFSO = new ActiveXObject("Scripting.FileSystemObject"); var filePath = fileObj.value;
            var objFile = objFSO.getFile(filePath);
            var fileSize = objFile.size; //size in kb
            fileSize = fileSize / 1048576; //size in mb 
        }
            //for FF, Safari, Opeara and Others
        else {
            fileSize = fileObj.size //size in kb
            fileSize = fileSize / 1048576; //size in mb 
        }

        return fileSize;
    }
    catch (e) {
        throw e;
    }
}

function getFileSizeKB(fileObj) {
    try {
        var fileSize = 0;
        //for IE
        if (browserIsIE()) {//we could use this $.browser.msie but since it's depracted we'll use this function
            //before making an object of ActiveXObject, 
            //please make sure ActiveX is enabled in your IE browser
            var objFSO = new ActiveXObject("Scripting.FileSystemObject"); var filePath = fileObj.value;
            var objFile = objFSO.getFile(filePath);
            fileSize = objFile.size; //size in kb
            fileSize = fileSize / 1024; //size in mb 
        }
            //for FF, Safari, Opeara and Others
        else {
            fileSize = fileObj.size //size in kb
            fileSize = fileSize / 1024; //size in mb 
        }

        return fileSize;
    }
    catch (e) {
        throw e;
    }
}

function checkFileName(name) {
    var re = new RegExp(/[\,\~\#\%\&\*\{\}\\\:\<\>\?\/\+\|\[\]\^\]\[]/gi);
    return re.test(name);
}

function gotoDashboard() {
    if (userProfile) {
        if (userProfile.UserType == PortalUserTypes.ScrutinizedPortal) {
            window.location = '/Layouts/ScrutinizerDashboard';
        } else {
            window.location = '/Layouts/CitizenDashboard';
        }
    }
}

function gotoLogin() {
    if (userProfile) {
        if (userProfile.UserType == PortalUserTypes.ScrutinizedPortal) {
            window.location = '/Layouts/ScrutinizerLogin';
        } else {
            window.location = '/Login';
        }
    }
}

function gotoChangePassword() {
    if (userProfile) {
        window.location = '/Layouts/GenericChangePassword';
    }

}

var toUTCDate = function (date) {
    var _utc = new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());
    return _utc;
};

function clearLocalStorage() {
    userProfile = null;
    localStorage.setItem("AccessToken", null);
}

function gotoDefaultpage() {
    if (userProfile) {
        if (userProfile.UserType == PortalUserTypes.CitizenPortal) {
            window.location = '/Login';
        }
        else if (userProfile.UserType == PortalUserTypes.ScrutinizedPortal) {
            window.location = '/Layouts/ScrutinizerLogin';
        }
    }
    clearLocalStorage();
}
function toCurrentDate(date) {
    let timePart = new Date();
    var _date = new Date(date.getFullYear(), date.getMonth(), date.getDate(), timePart.getHours(), timePart.getMinutes(), timePart.getSeconds());
    return _date;
};
function titleCase(str) {
    return str.toLowerCase().split(' ').map(function (word) {
        return (word.charAt(0).toUpperCase() + word.slice(1));
    }).join(' ');
}
