﻿(function () {
    'use strict';

    let app = angular
        .module('housingSocieties');

    let reqModule = ['angularUtils.directives.dirPagination'];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });

    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', function ($q) {
            return {
                'request': function (config) {
                    //let accessToken = localStorage.getItem("AccessToken");
                    //if (accessToken) {
                    //    config.headers['Authorization'] = 'Bearer ' + accessToken;
                    //}
                    return config || $q.when(config);
                },
                'response': function (response) {
                    if (response.status === 401) {

                    }

                    return response || $q.when(response);
                },
                'responseError': function (rejection) {
                    if (rejection.status === 401) {

                    }

                    return $q.reject(rejection);
                }
            }
        }]);
    }]);

    app.controller('defaultPageCtrl', defaultPageCtrl);

    defaultPageCtrl.$inject = ['$scope', '$http', '$timeout', '$filter', '$location'];

    function defaultPageCtrl($scope, $http, $timeout, $filter, $location) {

        $scope.viewModel = {
            colSocities: [],
            colDevelopmentAuthorities: [],
            colDistrict: [],
            colDivision: [],
            colCity: []
        };

        let _searchModel = {
            DevelopmentAuthoritieID: null,
            DivisionID: null,
            DistrictID: null,
            CityID: null,
        };

        $scope.searchModel = angular.copy(_searchModel);

        function clearSearch() {
            filterEnabled = false;
            $scope.searchModel = angular.copy(_searchModel);
            doFilterRecords();
        }

        $scope.clearSearch = clearSearch;

        let filterEnabled = false;
        $scope.filterRecords = function () {
            filterEnabled = true;
            doFilterRecords();
        }

        let allRecords = [];
        function doFilterRecords() {
            if (filterEnabled) {

                let tempRecords = [];

                $scope.viewModel.colSocities = allRecords.filter(function (item) {
                    return (
                        ($scope.searchModel.DevelopmentAuthoritieID && (item.AuthorityID == $scope.searchModel.DevelopmentAuthoritieID) || !$scope.searchModel.DevelopmentAuthoritieID) &&
                        ($scope.searchModel.DivisionID && (item.DivisionID == $scope.searchModel.DivisionID) || !$scope.searchModel.DivisionID) &&
                        ($scope.searchModel.DistrictID && (item.DistrictID == $scope.searchModel.DistrictID) || !$scope.searchModel.DistrictID ) &&
                        ($scope.searchModel.CityID && (item.CityID == $scope.searchModel.CityID) || !$scope.searchModel.CityID)
                        )
                });

                //$scope.viewModel.colSocities = $filter('filter')(allRecords,
                //    { DevelopmentAuthoritieID: $scope.searchModel.DevelopmentAuthoritieID || undefined } &&
                //    { DivisionID: $scope.searchModel.DivisionID || undefined } &&
                //    { DistrictID: $scope.searchModel.DistrictID || undefined } &&
                //    { CityID: $scope.searchModel.CityID || undefined }
                //);
            } else {
                $scope.viewModel.colSocities = allRecords;
            }
        }

        function getList() {
            function successCallback(successResp) {
                if (successResp.status == HTTPStatusCode.OK) {
                    $scope.viewModel.colSocities = allRecords = successResp.data.colSocities || [];
                    $scope.viewModel.colDevelopmentAuthorities = successResp.data.colDevelopmentAuthorities || [];
                    $scope.viewModel.colDistrict = successResp.data.colDistrict || [];
                    $scope.viewModel.colDivision = successResp.data.colDivision || [];
                    $scope.viewModel.colCity = successResp.data.colCity || [];
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            const searchParams = new URLSearchParams();
            Object.keys($scope.searchModel).forEach(key => searchParams.append(key, $scope.searchModel[key]));

            $http.get('/api/Societies/GetRecords', {
                params: $scope.searchModel
            }).then(successCallback, errorCallback);
        }

        function activate() {
            getList();

            $(document).ready(function () {
                $("form").validationEngine({
                    //promptPosition: "topRight:-95",
                    //scroll: false
                });

                $('#slider1').s3Slider({
                    timeOut: 4000
                });
                $('#news-container').vTicker({
                    speed: 800,
                    pause: 3000,
                    animation: 'fade',
                    mousePause: false,
                    showItems: 4
                });
            });
        }

        activate();
    }
})();
