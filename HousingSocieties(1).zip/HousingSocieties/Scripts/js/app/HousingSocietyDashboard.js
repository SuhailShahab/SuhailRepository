﻿(function () {
    'use strict';


    let app = angular.module('housingSocieties');

    let reqModule = ['angularUtils.directives.dirPagination'];
    reqModule.forEach(function (module) {
        app.requires.push(module);
    });

    app.config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', function ($q) {
            return {
                'request': function (config) {
                    let accessToken = localStorage.getItem("AccessToken");
                    if (accessToken) {
                        config.headers['Authorization'] = 'Bearer ' + accessToken;
                    }
                    return config || $q.when(config);
                },
                'response': function (response) {
                    if (response.status === 401) {

                    }

                    return response || $q.when(response);
                },
                'responseError': function (rejection) {
                    if (rejection.status === 401) {

                    }

                    return $q.reject(rejection);
                }
            }
        }]);
    }]);

    app.controller('housingSocietyDashboardCtrl', housingSocietyDashboardCtrl);

    housingSocietyDashboardCtrl.$inject = ['$scope', '$http', '$timeout', '$filter', '$location'];

    function housingSocietyDashboardCtrl($scope, $http, $timeout, $filter, $location) {
        $scope.title = 'housingSocietyDashboard';

        $scope.settings = {
            perPage: 10,
            currentPage: 1,
            startSerial: 1
        }

        let _SocietyModel = {
            ID: null,
            Name: '',
            PhaseSector: '',
            Block: '',
            TotalArea: 0,
            AuthorityID: null,
            NOCAppliedDate: null, //needs
            DivisionID: null,
            DistrictID: null,
            CityID: null,
            UnionCouncilID: null, // needs
            LocationCordinates: null,
            Mouza: null,
            DeveloperName: null,
            SocietyStatusID: null,
            TotalPlots: null,
            TotalPlotSold: null,
            TotalConstructedHouse: null,
            OwnershipLandID: null,
            AvailabilitySiteOffice: true,
            UnApprovedReasonDesc: null,
            Remarks: '',
            IsActive: true
        }

        $scope.editModel = angular.copy(_SocietyModel);

        $scope.viewModel = {
            colDevelopmentAuthorities: [],
            colDistrict: [],
            colDivision: [],
            colCity: [],
            colUnionCouncil: [],
            colSocietyStatus: [],
            colOwnershipLands: [],
            siteOfficeAvailableOptions: [
                { Value: true, Title: 'Available' },
                { Value: false, Title: 'Not Available' }
            ],
            colSchemeUnApprovedReason: [],
            colSocities: []
        };

        $scope.getCallData = {
            colDevelopmentAuthorities: [],
            colDistrict: [],
            colDivision: [],
        };

        $scope.DisableDivision = false;
        $scope.DisableDistrict = false;
        //$scope.DisableAuthority = false;

        let _searchModel = {
            UserID: null,
            //AuthorityID: 1,
            //DivisionID: 6,
            //DistrictID: 18,
            AuthorityID: null,
            DivisionID: null,
            DistrictID: null,
            SocietyStatusID: null,
            SearchTerm: ''
        };

        $scope.searchModel = angular.copy(_searchModel);

        function clearSearch() {

            filterEnabled = false;
            $scope.searchModel = angular.copy(_searchModel);
            getList();
        }

        let filterAuthorityIDs = [2];//[2, 39]

        $scope.changedAuthority = function () {

            $timeout(function () {


                if ($scope.searchModel.AuthorityID && $scope.searchModel.AuthorityID !== 39) {
                    // Filter Division

                    $scope.viewModel.colDivision = [];
                    let tempcolDivision = [], tempColDivisionIDs = [];
                    for (let divIndex = 0; divIndex < $scope.getCallData.colDivision.length; divIndex++) {
                        let item = $scope.getCallData.colDivision[divIndex];
                        if ($scope.filterDivision(item)) {
                            tempColDivisionIDs.push(item.ID);
                            tempcolDivision.push(item);
                        }
                    }

                    $scope.viewModel.colDivision = tempcolDivision;
                    // Filter District
                    $scope.viewModel.colDistrict = [];
                    let tempcolDistrict = [];
                    let IsDevelopmentAuthority = filterAuthorityIDs.indexOf($scope.searchModel.AuthorityID) > -1 ? false : true;

                    for (let divIndex = 0; divIndex < $scope.getCallData.colDistrict.length; divIndex++) {

                        let item = $scope.getCallData.colDistrict[divIndex];
                        if (item.IsDevelopmentAuthority == IsDevelopmentAuthority &&
                            tempColDivisionIDs.indexOf(item.DivisionID) > -1) {
                            tempcolDistrict.push(item);
                        }
                    }

                    $scope.viewModel.colDistrict = tempcolDistrict;
                } else {
                    $scope.viewModel.colDivision = $scope.getCallData.colDivision;
                    $scope.viewModel.colDistrict = $scope.getCallData.colDistrict;
                }
            }, 10);

        }


        $scope.filterDivision = function (item) {

            if ($scope.searchModel.AuthorityID) {
                if ($scope.searchModel.AuthorityID == 2 || $scope.searchModel.AuthorityID == 39) {
                    return true;
                } else {
                    return item.AuthorityIDs.indexOf($scope.searchModel.AuthorityID) > -1
                }
            }

            return true;
        }

        $scope.filterDistrict = function (item) {
            if ($scope.searchModel.DivisionID) {

                if ($scope.searchModel.AuthorityID == 2) {
                    return item.IsDevelopmentAuthority == false &&
                        item.DivisionID == $scope.searchModel.DivisionID;
                } else if ($scope.searchModel.AuthorityID == 39) {
                    return item.DivisionID == $scope.searchModel.DivisionID;
                } else {
                    if ($scope.searchModel.AuthorityID) {
                        return item.DivisionID == $scope.searchModel.DivisionID && (item.IsDevelopmentAuthority == true);
                    } else {
                        return item.DivisionID == $scope.searchModel.DivisionID;
                    }

                }
            } else {
                if ($scope.searchModel.AuthorityID == 2) {
                    return item.IsDevelopmentAuthority == false;
                } else if ($scope.searchModel.AuthorityID == 39) {
                    return true;
                } else {
                    return item.IsDevelopmentAuthority == true;
                }
            }
        }

        $scope.clearSearch = clearSearch;

        let filterEnabled = false;
        $scope.filterRecords = function () {
            filterEnabled = true;
            getList();
        }

        let allRecords = [];
        function doFilterRecords() {
            if (filterEnabled) {

                let tempRecords = [];

                $scope.viewModel.colSocities = allRecords.filter(function (item) {
                    return (
                        ($scope.searchModel.AuthorityID && (item.AuthorityID == $scope.searchModel.AuthorityID) || !$scope.searchModel.AuthorityID) &&
                        ($scope.searchModel.DivisionID && (item.DivisionID == $scope.searchModel.DivisionID) || !$scope.searchModel.DivisionID) &&
                        ($scope.searchModel.DistrictID && (item.DistrictID == $scope.searchModel.DistrictID) || !$scope.searchModel.DistrictID) &&
                        ($scope.searchModel.SocietyStatusID && (item.SocietyStatusID == $scope.searchModel.SocietyStatusID) || !$scope.searchModel.SocietyStatusID)
                    )
                });

            } else {
                $scope.viewModel.colSocities = allRecords.filter(function (item) {
                    return ($scope.searchModel.SocietyStatusID && (item.SocietyStatusID == $scope.searchModel.SocietyStatusID) || !$scope.searchModel.SocietyStatusID);
                });;
            }
        }
        $scope.doFilterRecords = doFilterRecords;

        $scope.searchTerm = function () {
            doFilterRecords();
            $scope.viewModel.colSocities = $filter('filter')($scope.viewModel.colSocities, $scope.searchModel.SearchTerm);
            $scope.settings.currentPage = 1;
            $scope.settings.startSerial = 1;
        }

        $scope.searchFilter = function (item) {
            var searchString = $scope.searchModel.SearchTerm;
            if (searchString == null || searchString == "" || searchString == undefined) {
                return true;
            }

            searchString = searchString.toLowerCase();
            if (
                    (item.Name.toLowerCase().indexOf(searchString) != -1) ||
                    (item.Authority.toLowerCase().indexOf(searchString) != -1) ||
                    (item.City.toLowerCase().indexOf(searchString) != -1) ||
                    (item.SocietyStatus.toLowerCase().indexOf(searchString) != -1) ||
                    ((item.TotalArea + "").toLowerCase().indexOf(searchString) != -1)
                ) {
                return true;
            }
            return false;
        }

        $scope.UserDisplayName = '';

        function getList() {
            function successCallback(successResp) {
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.Status != "success") {
                        switch (successResp.data.Status) {
                            case "error":
                                toastr.error(successResp.data.Message);
                                break;
                            case "Info":
                                toastr.info(successResp.data.Message);
                                break;
                        }

                        return;
                    }

                    $scope.UserDisplayName = successResp.data.UserDisplayName;

                    $scope.viewModel.colDevelopmentAuthorities = successResp.data.colDevelopmentAuthorities || [];
                    $scope.viewModel.colDistrict = successResp.data.colDistrict || [];
                    $scope.viewModel.colDivision = successResp.data.colDivision || [];
                    $scope.viewModel.colCity = successResp.data.colCity || [];
                    $scope.viewModel.colUnionCouncil = successResp.data.colUnionCouncil || [];
                    $scope.viewModel.colSocietyStatus = successResp.data.colSocietyStatus || [];
                    $scope.viewModel.colOwnershipLands = successResp.data.colOwnershipLands || [];
                    $scope.viewModel.colSchemeUnApprovedReason = successResp.data.colSchemeUnApprovedReason || [];

                    if ($scope.viewModel.colOwnershipLands.length > 0) {
                        $scope.editModel.OwnershipLandID = $scope.viewModel.colOwnershipLands[0].ID;
                    }

                    $scope.viewModel.colSocities = successResp.data.colSocities || [];

                    $scope.getCallData.colDevelopmentAuthorities = $scope.viewModel.colDevelopmentAuthorities = successResp.data.colDevelopmentAuthorities || [];
                    $scope.getCallData.colDistrict = $scope.viewModel.colDistrict = successResp.data.colDistrict || [];
                    $scope.getCallData.colDivision = $scope.viewModel.colDivision = successResp.data.colDivision || [];

                    if ($scope.getCallData.colDevelopmentAuthorities.length == 1) {
                        $scope.searchModel.AuthorityID = $scope.getCallData.colDevelopmentAuthorities[0].ID;
                        //$scope.DisableAuthority = true;
                    }

                    if ($scope.getCallData.colDistrict.length == 1) {
                        $scope.searchModel.DistrictID = $scope.getCallData.colDistrict[0].ID;
                        $scope.DisableDistrict = true;
                    }

                    if ($scope.getCallData.colDivision.length == 1) {
                        $scope.searchModel.DivisionID = $scope.getCallData.colDivision[0].ID;
                        $scope.DisableDivision = true;
                    }

                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            var requestParams = {
                //UserID: $scope.searchModel.UserID,
                AuthorityID: $scope.searchModel.AuthorityID,
                DivisionID: $scope.searchModel.DivisionID,
                DistrictID: $scope.searchModel.DistrictID,
                SocietyStatusID: $scope.searchModel.SocietyStatusID
            }

            Object.keys(requestParams).forEach(function (key, index) {
                if (this[key] == null) this[key] = "";
            }, requestParams);

            $http.get('/api/Societies/GetSocietiesData', {
                params: requestParams
            }).then(successCallback, errorCallback);
        }

        $scope.RedirectToDeclaration = function (ID) {
            var targetUrl = '/Layouts/HousingSocietyDeclaration.aspx';
            if (ID != undefined) {
                targetUrl = targetUrl + '?ID=' + ID
            }
            //window.open(targetUrl, "_blank");
            window.open(targetUrl, "_self");
        }

        $scope.ActivateDeactivate = function (ID, isActive) {
            var confirmationMsg = "Do you want to " + (isActive ? "activate" : "deactivate") + " the scheme?"
            if (!confirm(confirmationMsg)) {
                return;
            }
            var self = $scope;
            $http.post('/api/Societies/UpdateSocietyInactive', {
                SocietyID: ID,
                IsActive: isActive
            }).then(function (successResp) {
                if (successResp.status == HTTPStatusCode.OK) {
                    if (successResp.data) {

                        if (successResp.data.Status == 'success') {
                            var successMsg = 'Society has been disabled successfully!'
                            //if (successResp.data.IsActive == true) {isActive
                            if (isActive == true) {
                                var successMsg = 'Society has been enabled successfully!'
                            }

                            toastr.success(successMsg);
                            self.viewModel.colSocities.forEach(function (society) {
                                if (society.ID == ID) {
                                    society.IsActive = isActive;
                                }
                            })
                        }
                        else {

                            switch (successResp.data.Status) {
                                case "error":
                                    toastr.error(successResp.data.Message);
                                    break;
                                case "Info":
                                    toastr.info(successResp.data.Message);
                                    break;
                            }



                        }
                    }

                }
                else {
                    toastr.error('There is something wrong. Please contact with administrator.');
                }

            }, function (errorResp) {

            });
        }

        activate();

        function activate() {
            getList();
        }
    }
})();
