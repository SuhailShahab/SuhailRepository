﻿function initMap() {
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 3,
        center: { lat: 41.876, lng: -87.624 },
    });
    // const ctaLayer = new google.maps.KmlLayer({
    //   url: "https://googlearchive.github.io/js-v2-samples/ggeoxml/cta.kml",
    //   map: map,
    // });
}

// initialize Leaflet
//31.1704° N, 72.7097° E
var map = L.map('map').setView({ lon: 74.329376, lat: 31.582045 }, 11);

// add the OpenStreetMap tiles
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://openstreetmap.org/copyright">OpenStreetMap contributors</a>'
}).addTo(map);

// show the scale bar on the lower left corner
L.control.scale().addTo(map);

let webAPIBase = 'http://10.52.98.30:8094';
//let webAPIBase = 'http://localhost:4140';
//let webAPIBase = 'https://housingsocieties.punjab.gov.pk';

let params = (new URL(document.location)).searchParams;
let kmlPath = webAPIBase + '/SocietiesKMLFiles/' + params.get('DocumentID') + '.kml';

fetch(kmlPath)
    .then(res => res.text())
    .then(kmltext => {
        // Create new kml overlay
        const track = new omnivore.kml.parse(kmltext);
        map.addLayer(track);

        // Adjust map to show the kml
        const bounds = track.getBounds();
        map.fitBounds(bounds);
    }).catch((e) => {
        console.log(e);
    })