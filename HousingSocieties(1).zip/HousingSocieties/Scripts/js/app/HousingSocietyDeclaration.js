﻿(function () {
    'use strict';

    angular
        .module('housingSocieties')
        .controller('housingSocietyDeclarationCtrl', housingSocietyDeclarationCtrl)
        .directive('fileOnChange', function () {
            return {
                restrict: 'A',
                link: function (scope, element, attrs) {
                    var onChangeHandler = scope.$eval(attrs.fileOnChange);
                    element.on('change', function (evt) {
                        onChangeHandler(evt, scope, element, attrs);
                    });
                    element.on('$destroy', function () {
                        element.off();
                    });

                }
            };
        });

    housingSocietyDeclarationCtrl.$inject = ['$scope', '$http', '$timeout', '$filter', '$location'];

    function housingSocietyDeclarationCtrl($scope, $http, $timeout, $filter, $location) {
        $scope.title = 'housingSocietyDeclaration';

        let _SocietyModel = {
            ID: null,
            Name: '',
            PhaseSector: '',
            Block: '',
            TotalArea: 0,
            AuthorityID: null,
            NOCAppliedDate: null, //needs
            DivisionID: null,
            DistrictID: null,
            CityID: null,
            UnionCouncilID: null, // needs
            LocationCordinates: null,
            Mouza: null,
            DeveloperName: null,
            SocietyStatusID: null,
            TotalPlots: null,
            TotalPlotSold: null,
            TotalConstructedHouse: null,
            OwnershipLandID: 2,
            AvailabilitySiteOffice: true,
            UnApprovedReasonDesc: null,
            Remarks: '',
            IsActive: true,
            NOCDepartment: [],
            ActionTaken: [],
            AvailableFacility: [],
            lstSocietyDocument: [],
            lstSocietyKML: [],
            ApprovedBlocks: null,
            ResidentialPlots: 0,
            CommercialPlots: 0,
            MortgagedPlots: null,
            ApprovalStage: null,
            SellableArea: 0,
            UnSellableArea: 0,
            TotalAreaDetails: "Park: \nOpen Space: \nGraveyard: \nPublic Building: ",
            CatgryWiseResPlots: "No. of 3 Marla Plots: \nNo. of 5 Marla Plots: \nNo. of 7 Marla plots: \nNo. of 10 Marla Plots: \nNo. of 1 Kanal Plots: ",
            CatgryWiseComPlots: "No. of 3 Marla Plots: \nNo. of 5 Marla Plots: \nNo. of 7 Marla plots: \nNo. of 10 Marla Plots: \nNo. of 1 Kanal Plots: ",
            LowIncomeScheme: null
        }

        $scope.editModel = angular.copy(_SocietyModel);

        $scope.viewModel = {
            colDevelopmentAuthorities: [],
            colDistrict: [],
            colDivision: [],
            colCity: [],
            colUnionCouncil: [],
            colSocietyStatus: [],
            colDocumentTypes: [],
            colOwnershipLands: [],
            siteOfficeAvailableOptions: [
                { Value: true, Title: 'Available' },
                { Value: false, Title: 'Not Available' }
            ],
            colSchemeUnApprovedReason: [],

            colNOCDepartment: [],
            colActionTaken: [],
            colAvailableFacility: []
        };
        $scope.DisableButtons = false;
        $scope.Documents = [];
        $scope.ViewDocuments = [];
        $scope.DocumentFormData = null;
        // toggle selection for a given checkbox
        $scope.toggleSelectionCheckbox = function toggleSelectionCheckbox(ID, NameOfArrayProp) {
            var idx = $scope.editModel[NameOfArrayProp].indexOf(ID);

            if (idx > -1) { // is currently selected
                $scope.editModel[NameOfArrayProp].splice(idx, 1);
            }
            else { // is newly selected
                $scope.editModel[NameOfArrayProp].push(ID);
            }

            console.log(NameOfArrayProp + ': ', $scope.editModel[NameOfArrayProp]);
        };

        var today = new Date();
        $scope.todayDate = new Date(today.getFullYear(), today.getMonth(), today.getDate());

        $scope.dateOptions = {
            dateFormat: 'dd-mm-yy',
            showAnim: "slide",
            showOn: "both",
            buttonImage: "/images/calendar_25.gif",
            buttonImageOnly: true
        };

        $scope.tempModel = {
            UnApprovedReasonOther: false,

        }

        let DocumentInfo = {
            DocumentID: null,
            SocietyID: null,
            DocumentTypeID: null,
            Document: [],
            FileName: null,
            Title: null,
            MediaType: null
        };
        $scope.ViewDocuments.push(angular.copy(DocumentInfo));

        $scope.addDocumentRow = function () {

            if ($scope.ViewDocuments == null) {
                $scope.ViewDocuments = [];
            }
            var itemLength = $scope.ViewDocuments.length;
            var docIndex = $scope.Documents.length;
            if (docIndex > 0)
                docIndex = docIndex - 1;

            if ($scope.ViewDocuments[itemLength - 1].DocumentTypeID == null || $scope.ViewDocuments[itemLength - 1].DocumentTypeID < 1) {
                toastr.info("Please select document type.");
                return;
            }
                //else if ($scope.ViewDocuments[itemLength - 1].FileName == null) {
                //    toastr.info("Please enter Name.");
                //    return;
                //}
            else if ($scope.ViewDocuments[itemLength - 1].DocumentID == null && ($scope.Documents[docIndex] !== undefined && $scope.Documents[docIndex].Size) == 0) {
                toastr.info("Please attach document.");
                return;
            }

            $scope.ViewDocuments.push(angular.copy(DocumentInfo));

        }
        $scope.UserDisplayName = '';
        function getList() {
            function successCallback(successResp) {
                if (successResp.status == HTTPStatusCode.OK) {

                    if (successResp.data.Status != "success") {
                        switch (successResp.data.Status) {
                            case "error":
                                toastr.error(successResp.data.Message);
                                break;
                            case "Info":
                                toastr.info(successResp.data.Message);
                                break;
                        }

                        return;
                    }

                    $scope.UserDisplayName = successResp.data.UserDisplayName;

                    //if (successResp.data.Model) // Model is not present in case of new scheme ,so apply this check
                    //{
                    //    if (successResp.data.Model.ID == null) {
                    //        toastr.error('You do not have rights to view this housing scheme');
                    //        window.setTimeout(function () {
                    //            $scope.redirectToDashboard();
                    //        }, 3000);
                    //    }
                    //}

                    $scope.viewModel.colDevelopmentAuthorities = successResp.data.colDevelopmentAuthorities || [];
                    $scope.viewModel.colDistrict = successResp.data.colDistrict || [];
                    $scope.viewModel.colDivision = successResp.data.colDivision || [];
                    $scope.viewModel.colCity = successResp.data.colCity || [];
                    $scope.viewModel.colUnionCouncil = successResp.data.colUnionCouncil || [];
                    $scope.viewModel.colSocietyStatus = successResp.data.colSocietyStatus || [];
                    $scope.viewModel.colDocumentTypes = successResp.data.colDocumentTypes || [];
                    $scope.viewModel.colOwnershipLands = successResp.data.colOwnershipLands || [];
                    $scope.viewModel.colSchemeUnApprovedReason = successResp.data.colSchemeUnApprovedReason || [];
                    $scope.viewModel.colNOCDepartment = successResp.data.colNOCDepartment || [];
                    $scope.viewModel.colActionTaken = successResp.data.colActionTaken || [];
                    $scope.viewModel.colAvailableFacility = successResp.data.colAvailableFacility || [];

                    //if ($scope.viewModel.colOwnershipLands.length > 0) {
                    //    $scope.editModel.OwnershipLandID = $scope.viewModel.colOwnershipLands[0].ID;
                    //}
                    //if (successResp.data.Model == null || successResp.data.Model.ID == null) {
                    //    toastr.error('You do not have rights to view this housing scheme.');
                    //    window.setTimeout(function () {
                    //        $scope.redirectToDashboard();
                    //    }, 3000);
                    //}

                    if (successResp.data.Model) {
                        $scope.editModel = successResp.data.Model;

                        $scope.ViewDocuments = [];

                        if ($scope.editModel.lstSocietyDocument != null && $scope.editModel.lstSocietyDocument.length > 0) {

                            angular.forEach($scope.editModel.lstSocietyDocument, function (item) {
                                $scope.ViewDocuments.push(item);
                            });
                        }

                        if ($scope.editModel.lstSocietyKML != null && $scope.editModel.lstSocietyKML.length > 0) {
                            angular.forEach($scope.editModel.lstSocietyKML, function (item) {
                                $scope.ViewDocuments.push(item);
                            });
                        }

                        if ($scope.ViewDocuments.length == 0) {
                            $scope.ViewDocuments.push(angular.copy(DocumentInfo));
                        }

                        if ($scope.editModel.OwnershipLandID == 0 || $scope.editModel.OwnershipLandID == null || $scope.editModel.OwnershipLandID == undefined) {
                            $scope.editModel.OwnershipLandID = "";
                        }
                    }

                    if ($scope.viewModel.colDevelopmentAuthorities.length == 1) {
                        $scope.editModel.AuthorityID = $scope.viewModel.colDevelopmentAuthorities[0].ID;
                    }

                    if ($scope.viewModel.colDivision.length == 1) {
                        $scope.editModel.DivisionID = $scope.viewModel.colDivision[0].ID;
                    }

                    if ($scope.viewModel.colDistrict.length == 1) {
                        $scope.editModel.DistrictID = $scope.viewModel.colDistrict[0].ID;
                    }

                    if ($scope.viewModel.colCity.length == 1) {
                        $scope.editModel.CityID = $scope.viewModel.colCity[0].ID;
                    }
                }
            }

            function errorCallback(response) {
                console.log(response);
            }

            //const searchParams = new URLSearchParams();
            //Object.keys($scope.searchModel).forEach(key => searchParams.append(key, $scope.searchModel[key]));

            $http.get('/api/Societies/GetRecordByID', {
                params: {
                    ID: getParameterByName('ID')
                }
            }).then(successCallback, errorCallback);

        }


        let MAPFile = null;
        $scope.documentSelected = function (evt, inputScope, element, attrs) {

            if (inputScope.item.DocumentTypeID == null || inputScope.item.DocumentTypeID < 1) {
                toastr.info("Please select document type.");
                return;
            }

            if (inputScope.item.DocumentTypeID == 2) {

                let elem = element[0];

                if (elem.files.length == 0) {
                    toastr.info("Please attach file.");
                    return;
                }

                let fileObj = elem.files[0];

                if (fileObj != "" && fileObj != undefined) {
                    if (fileObj.name.indexOf('.kml') !== -1) {
                        /*file size limit */
                        let fileSize = getFileSizeKB(fileObj);

                        if (fileSize > 25600) { // 25 Mb file size

                            toastr.info("Document with name " + fileObj.name + " is exceeding the max file size limit (25 MB).");
                            $(evt.target).get(0).value = '';
                            return;
                        }

                        if (checkFileName(fileObj.name)) {

                            toastr.info(fileObj.name + " might have some special characters. Please rename the file name and upload again.");
                            $(evt.target).get(0).value = '';
                            return;
                        }

                        //KMLFile = fileObj;

                        inputScope.document = {
                            "DocType": fileObj.type,
                            "Title": fileObj.name,
                            "FileName": inputScope.item.FileName,
                            "DocumentTypeID": inputScope.item.DocumentTypeID,
                            "Size": fileObj.size,
                            "file": fileObj
                        }
                        $scope.processSocietyDocument(inputScope.document, $(element[0]).attr('id'));
                    } else {
                        toastr.info("Please upload kml file only.");

                        $timeout(function () {
                            $(evt.target).get(0).value = '';
                        }, 100);

                    }
                };
            }
            else if (inputScope.item.DocumentTypeID != 2) {
                // $scope.DocumentFormData = null;
                let elem = element[0];

                if (elem.files.length == 0) {
                    toastr.info("Please attach file.");
                    return;
                }

                let fileObj = elem.files[0];

                if (fileObj != "" && fileObj != undefined) {
                    if (fileObj.type.indexOf('pdf') !== -1) {
                        /*file size limit */
                        let fileSize = getFileSizeKB(fileObj);
                        if (inputScope.item.DocumentTypeID == 1) {
                            if (fileSize > 25600) { // 25 Mb file size

                                toastr.info("Document with name " + fileObj.name + " is exceeding the max file size limit (25 MB).");
                                $(evt.target).get(0).value = '';
                                return;
                            }
                        }
                        else {
                            if (fileSize > 1024) { // 1 Mb file size

                                toastr.info("Document with name " + fileObj.name + " is exceeding the max file size limit (1 MB).");
                                $(evt.target).get(0).value = '';
                                return;
                            }
                        }
                        if (checkFileName(fileObj.name)) {

                            toastr.info(fileObj.name + " might have some special characters. Please rename the file name and upload again.");
                            $(evt.target).get(0).value = '';
                            return;
                        }

                        /// MAPFile = fileObj;
                        inputScope.document = {
                            "DocType": fileObj.type,
                            "Title": fileObj.name,
                            "FileName": inputScope.item.FileName,
                            "DocumentTypeID": inputScope.item.DocumentTypeID,
                            "Size": fileObj.size,
                            "file": fileObj
                        }
                        $scope.processSocietyDocument(inputScope.document, $(element[0]).attr('id'));
                    } else {
                        toastr.info("Please upload pdf file only.");

                        $timeout(function () {
                            $(evt.target).get(0).value = '';
                        }, 100);

                    }
                };
            }
        }


        //let MAPFile = null;
        //$scope.societyDocumentSelected = function (evt, inputScope, element, attrs) {

        //    // $scope.DocumentFormData = null;
        //    let elem = element[0];

        //    if (elem.files.length == 0) {
        //        toastr.info("Please attach file.");
        //        return;
        //    }

        //    let fileObj = elem.files[0];

        //    if (fileObj != "" && fileObj != undefined) {
        //        if (fileObj.type.indexOf('pdf') !== -1) {
        //            /*file size limit */
        //            let fileSize = getFileSizeKB(fileObj);
        //            if (attrs.typeid == 1) {
        //                if (fileSize > 25600) { // 25 Mb file size

        //                    toastr.info("Document with name " + fileObj.name + " is exceeding the max file size limit (25 MB).");
        //                    $(evt.target).get(0).value = '';
        //                    return;
        //                }
        //            }
        //            else {
        //                if (fileSize > 1024) { // 1 Mb file size

        //                    toastr.info("Document with name " + fileObj.name + " is exceeding the max file size limit (1 MB).");
        //                    $(evt.target).get(0).value = '';
        //                    return;
        //                }
        //            }
        //            if (checkFileName(fileObj.name)) {

        //                toastr.info(fileObj.name + " might have some special characters. Please rename the file name and upload again.");
        //                $(evt.target).get(0).value = '';
        //                return;
        //            }

        //            /// MAPFile = fileObj;
        //            inputScope.document = {
        //                "DocType": fileObj.type,
        //                "Title": fileObj.name,
        //                //"ID": null,
        //                "DocumentTypeID": attrs.typeid,
        //                "Size": fileObj.size,
        //                "file": fileObj
        //            }


        //            $scope.processSocietyDocument(inputScope.document, $(element[0]).attr('id'));
        //        } else {
        //            toastr.info("Please upload pdf file only.");

        //            $timeout(function () {
        //                $(evt.target).get(0).value = '';
        //            }, 100);

        //        }
        //    };
        //}


        //let KMLFile = null;
        //$scope.societyKMLSelected = function (evt, inputScope, element, attrs) {

        //    // $scope.DocumentFormData = null;

        //    let elem = element[0];

        //    if (elem.files.length == 0) {
        //        toastr.info("Please attach file.");
        //        return;
        //    }

        //    let fileObj = elem.files[0];

        //    if (fileObj != "" && fileObj != undefined) {
        //        if (fileObj.name.indexOf('.kml') !== -1) {
        //            /*file size limit */
        //            let fileSize = getFileSizeKB(fileObj);

        //            if (fileSize > 25600) { // 25 Mb file size

        //                toastr.info("Document with name " + fileObj.name + " is exceeding the max file size limit (25 MB).");
        //                $(evt.target).get(0).value = '';
        //                return;
        //            }

        //            if (checkFileName(fileObj.name)) {

        //                toastr.info(fileObj.name + " might have some special characters. Please rename the file name and upload again.");
        //                $(evt.target).get(0).value = '';
        //                return;
        //            }

        //            //KMLFile = fileObj;

        //            inputScope.document = {
        //                "DocType": fileObj.type,
        //                "Title": fileObj.name,
        //                //"ID": null,
        //                "DocumentTypeID": attrs.typeid,
        //                "Size": fileObj.size,
        //                "file": fileObj
        //            }


        //            $scope.processSocietyDocument(inputScope.document, $(element[0]).attr('id'));
        //        } else {
        //            toastr.info("Please upload kml file only.");

        //            $timeout(function () {
        //                $(evt.target).get(0).value = '';
        //            }, 100);

        //        }
        //    };
        //}

        $scope.processSocietyDocument = function (reqDocument, inputID) {
            if (reqDocument.file != null) {

                /************/
                var nameExistsObj = [];


                //if ($scope.Documents != null && $scope.Documents.length > 0) {

                //    for (var i = $scope.Documents.length - 1; i >= 0; --i) {
                //        if ($scope.Documents[i].DocumentTypeID == reqDocument.DocumentTypeID) {
                //            $scope.Documents.splice(i, 1);
                //        }
                //    }
                //    // array filer
                //    //nameExistsObj = $scope.Documents.filter(function (node) {
                //    //    return node.DocumentTypeID == reqDocument.DocumentTypeID;
                //    //});
                //    // another array filter
                //    //const found = $scope.Documents.some(el => el.DocumentTypeID === reqDocument.DocumentTypeID);

                //    //if (nameExistsObj.length > 0) {
                //    //    toastr.info("Selected document with name '" + reqDocument.file.name + "' already attached.");
                //    //    $scope.clearFile(inputID);
                //    //    return;
                //    //}
                //}


                /************/

                let jsonData = {
                    'SocietyID': $scope.editModel.ID
                };
                reqDocument.Size = getFileSizeKB(reqDocument.file);
                reqDocument.DocType = reqDocument.file.type;
                if ($scope.Documents == null) {
                    $scope.Documents = [];
                }

                let docServerModel = {
                    //ID: null,
                    //DocumentID: reqDocument.ID,
                    DocumentTypeID: reqDocument.DocumentTypeID,
                    Name: reqDocument.FileName,
                    DocType: reqDocument.DocType,
                    Size: reqDocument.Size,
                    Title: reqDocument.Title,
                    File: reqDocument.file
                }

                $scope.Documents.push(docServerModel);

            } else {
                toastr.info("Please select the relevant document.");
            }
        }

        $scope.clearFile = function (inputID) {
            document.getElementById(inputID).value = "";
        };

        $scope.enableUploadOnDocType = function (docTypeID) {
            var docTypeObj = [];
            docTypeObj = $scope.editModel.lstSocietyDocument.filter(function (node) {
                return node.DocumentTypeID == docTypeID;
            });
            if (docTypeObj.length > 0)
                return true;
        };
        $scope.SaveRecord = function () {

            if (!$("form").validationEngine('validate')) {
                return;
            }

            if ($scope.editModel.OwnershipLandID) {
                $scope.editModel.OwnershipLandDesc = null;
            }
            else {
                $scope.editModel.OwnershipLandID = null;
            }

            delete $scope.editModel.CreatedDate;
            delete $scope.editModel.ModifiedDate;
            delete $scope.editModel.lstSocietyDocument;
            delete $scope.editModel.lstSocietyKML;


            $scope.editModel.NOCAppliedDate = ($scope.editModel.NOCAppliedDate ? new moment($scope.editModel.NOCAppliedDate).format("M/D/YYYY") : null)
            ////var frmData = null;//$scope.DocumentFormData;
            // var frmData = $scope.DocumentFormData;
            var frmData = new FormData();
            if (frmData == null || frmData == undefined) {
                frmData = new FormData();
            }
            frmData.delete("Data");
            frmData.append("Data", JSON.stringify($scope.editModel));
            var index = 0;
            for (var i = 0; i < $scope.Documents.length; i++) {
                frmData.append("DocType" + index, $scope.Documents[i].DocType)
                frmData.append("FileName" + index, $scope.Documents[i].Name || "");
                frmData.append("Title" + index, $scope.Documents[i].Name || "");
                frmData.append("DocumentTypeID" + index, $scope.Documents[i].DocumentTypeID);
                frmData.append("Size" + index, $scope.Documents[i].Size);

                var Item = $scope.Documents[i].File;
                frmData.append("chosenFile", Item);
                index++;
            }

            ////if (MAPFile != null) {
            ////    frmData.append("IsMAPFile", 1);
            ////    frmData.append("chosenFile", MAPFile);
            ////} else {
            ////    frmData.append("IsMAPFile", 0);
            ////}

            ////if (KMLFile != null) {
            ////    frmData.append("IsKMLFile", 1);
            ////    frmData.append("chosenFile", KMLFile);
            ////} else {
            ////    frmData.append("IsKMLFile", 0);
            ////}

            $scope.DisableButtons = true;
            var self = $scope;
            $http.post('/api/Societies/SaveSocietyInformation', frmData, {
                headers: {
                    'Content-Type': undefined
                }
            }).then(function (successResp) {
                if (successResp.status == HTTPStatusCode.OK) {
                    if (successResp.data) {
                        if (successResp.data.Status == 'success') {
                            var successMsg = "Society Information has been saved Successfully."
                            if ($scope.editModel.ID) {
                                successMsg = "Society Information has been updated Successfully."
                            }
                            toastr.success(successMsg);

                            //location.reload();
                            window.setTimeout(function () {
                                $scope.redirectToDashboard();
                            }, 3000);

                        }
                        else {
                            self.DisableButtons = false;
                            //toastr.error('There is something wrong, please contact administrator');

                            switch (successResp.data.Status) {
                                case "error":
                                    toastr.error(successResp.data.Message);
                                    break;
                                case "Info":
                                    toastr.info(successResp.data.Message);
                                    break;
                            }



                        }
                    }
                }
                else {
                    self.DisableButtons = false;
                    toastr.error('There is something wrong. Please contact with administrator.');
                }

            }, function (errorResp) {
                toastr.error('There is something wrong, please contact administrator');
                self.DisableButtons = false;
            });
        }


        $scope.deleteDocument = function (item) {

            var docTypeID = item.DocumentTypeID;
            var docID = item.DocumentID;

            if (docID == null) {
                var index = $scope.ViewDocuments.indexOf(item);
                $scope.ViewDocuments.splice(index, 1);
                return;
            }


            if (docTypeID == 2) {
                var confirmationMsg = "Do you want to delete the attached society map (KML)"
                if (!confirm(confirmationMsg)) {
                    return;
                }
                var self = $scope;

                $http.post('/api/Societies/DeleteSocietyKML', {
                    SocietyID: self.editModel.ID,
                    DocumentID: docID,
                    UserID: null
                }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {
                        if (successResp.data) {
                            if (successResp.data.Status == 'success') {
                                toastr.success("Society map (KML) has been deleted successfully!");

                                // remove document from list
                                for (var i = self.editModel.lstSocietyKML.length - 1; i >= 0; --i) {
                                    if (self.editModel.lstSocietyKML[i].DocumentID == docID) {
                                        self.editModel.lstSocietyKML.splice(i, 1);
                                    }
                                }

                                for (var i = self.ViewDocuments.length - 1; i >= 0; --i) {
                                    if (self.ViewDocuments[i].DocumentID == docID) {
                                        self.ViewDocuments.splice(i, 1);
                                    }
                                }
                            }
                            else {
                                switch (successResp.data.Status) {
                                    case "error":
                                        toastr.error(successResp.data.Message);
                                        break;
                                    case "Info":
                                        toastr.info(successResp.data.Message);
                                        break;
                                }
                            }
                        }
                    }
                    else {
                        toastr.error('There is something wrong. Please contact with administrator.');
                    }

                }, function (errorResp) {

                });
            }
            else {

                if (docTypeID == 1) {
                    var confirmationMsg = "Do you want to delete the attached society map (PDF)?"
                }
                else if (docTypeID == 3) {
                    var confirmationMsg = "Do you want to delete the attached society houses detail (PDF)?"
                }
                else if (docTypeID == 4) {
                    var confirmationMsg = "Do you want to delete the attached society plots detail (PDF)?"
                }
                else if (docTypeID == 5) {
                    var confirmationMsg = "Do you want to delete the attached society developer and other info (PDF)?"
                }
                else {
                    var confirmationMsg = "Do you want to delete the attached document (PDF)?"
                }
                if (!confirm(confirmationMsg)) {
                    return;
                }
                var self = $scope;

                $http.post('/api/Societies/DeleteSocietyDocument', {
                    SocietyID: self.editModel.ID,
                    DocumentID: docID,
                    UserID: null
                }).then(function (successResp) {
                    if (successResp.status == HTTPStatusCode.OK) {
                        if (successResp.data) {
                            if (successResp.data.Status == 'success') {
                                if (docTypeID == 1) {
                                    toastr.success("Society map (PDF) has been deleted successfully!");
                                }
                                else if (docTypeID == 3) {
                                    toastr.success("Society houses Detail (PDF) has been deleted successfully!");
                                }
                                else if (docTypeID == 4) {
                                    toastr.success("Society plots Detail (PDF) has been deleted successfully!");
                                }
                                else if (docTypeID == 5) {
                                    toastr.success("Society developer and other info (PDF) has been deleted successfully!");
                                }
                                else {
                                    var confirmationMsg = "Do you want to delete the attached document (PDF)?"
                                }
                                // remove document from list
                                for (var i = self.editModel.lstSocietyDocument.length - 1; i >= 0; --i) {
                                    if (self.editModel.lstSocietyDocument[i].DocumentID == docID) {
                                        self.editModel.lstSocietyDocument.splice(i, 1);
                                    }
                                }

                                for (var i = self.ViewDocuments.length - 1; i >= 0; --i) {
                                    if (self.ViewDocuments[i].DocumentID == docID) {
                                        self.ViewDocuments.splice(i, 1);
                                    }
                                }
                            }
                            else {
                                switch (successResp.data.Status) {
                                    case "error":
                                        toastr.error(successResp.data.Message);
                                        break;
                                    case "Info":
                                        toastr.info(successResp.data.Message);
                                        break;
                                }
                            }
                        }
                    }
                    else {
                        toastr.error('There is something wrong. Please contact with administrator.');
                    }

                }, function (errorResp) {

                });
            }
        }

        //$scope.deleteDocument = function (docID, docTypeID) {
        //    if (docTypeID == 1) {
        //        var confirmationMsg = "Do you want to delete the attached society map (PDF)?"
        //    }
        //    else if (docTypeID == 3) {
        //        var confirmationMsg = "Do you want to delete the attached society houses detail (PDF)?"
        //    }
        //    else if (docTypeID == 4) {
        //        var confirmationMsg = "Do you want to delete the attached society plots detail (PDF)?"
        //    }
        //    else if (docTypeID == 5) {
        //        var confirmationMsg = "Do you want to delete the attached society developer and other info (PDF)?"
        //    }
        //    else {
        //        var confirmationMsg = "Do you want to delete the attached document (PDF)?"
        //    }
        //    if (!confirm(confirmationMsg)) {
        //        return;
        //    }
        //    var self = $scope;

        //    $http.post('/api/Societies/DeleteSocietyDocument', {
        //        SocietyID: self.editModel.ID,
        //        DocumentID: docID,
        //        UserID: null
        //    }).then(function (successResp) {
        //        if (successResp.status == HTTPStatusCode.OK) {
        //            if (successResp.data) {
        //                if (successResp.data.Status == 'success') {
        //                    if (docTypeID == 1) {
        //                        toastr.success("Society map (PDF) has been deleted successfully!");
        //                    }
        //                    else if (docTypeID == 3) {
        //                        toastr.success("Society houses Detail (PDF) has been deleted successfully!");
        //                    }
        //                    else if (docTypeID == 4) {
        //                        toastr.success("Society plots Detail (PDF) has been deleted successfully!");
        //                    }
        //                    else if (docTypeID == 5) {
        //                        toastr.success("Society developer and other info (PDF) has been deleted successfully!");
        //                    }
        //                    else {
        //                        var confirmationMsg = "Do you want to delete the attached document (PDF)?"
        //                    }


        //                    // remove document from list
        //                    for (var i = self.editModel.lstSocietyDocument.length - 1; i >= 0; --i) {
        //                        if (self.editModel.lstSocietyDocument[i].DocumentID == docID) {
        //                            self.editModel.lstSocietyDocument.splice(i, 1);
        //                        }
        //                    }

        //                }
        //                else {
        //                    switch (successResp.data.Status) {
        //                        case "error":
        //                            toastr.error(successResp.data.Message);
        //                            break;
        //                        case "Info":
        //                            toastr.info(successResp.data.Message);
        //                            break;
        //                    }
        //                }
        //            }
        //        }
        //        else {
        //            toastr.error('There is something wrong. Please contact with administrator.');
        //        }

        //    }, function (errorResp) {

        //    });
        //}

        //$scope.deleteKML = function (docID) {
        //    var confirmationMsg = "Do you want to delete the attached society map (KML)"
        //    if (!confirm(confirmationMsg)) {
        //        return;
        //    }
        //    var self = $scope;

        //    $http.post('/api/Societies/DeleteSocietyKML', {
        //        SocietyID: self.editModel.ID,
        //        DocumentID: docID,
        //        UserID: null
        //    }).then(function (successResp) {
        //        if (successResp.status == HTTPStatusCode.OK) {
        //            if (successResp.data) {
        //                if (successResp.data.Status == 'success') {
        //                    toastr.success("Society map (KML) has been deleted successfully!");

        //                    // remove document from list
        //                    for (var i = self.editModel.lstSocietyKML.length - 1; i >= 0; --i) {
        //                        if (self.editModel.lstSocietyKML[i].DocumentID == docID) {
        //                            self.editModel.lstSocietyKML.splice(i, 1);
        //                        }
        //                    }

        //                }
        //                else {
        //                    switch (successResp.data.Status) {
        //                        case "error":
        //                            toastr.error(successResp.data.Message);
        //                            break;
        //                        case "Info":
        //                            toastr.info(successResp.data.Message);
        //                            break;
        //                    }
        //                }
        //            }
        //        }
        //        else {
        //            toastr.error('There is something wrong. Please contact with administrator.');
        //        }

        //    }, function (errorResp) {

        //    });
        //}

        $scope.redirectToDashboard = function () {
            window.open('/Layouts/HousingSocietyDashboard.aspx', "_self");
        }

        $scope.cancelRecord = function () {
            if (!confirm('All changes will be discarded, you want to continue?')) {
                return;
            }

            location.reload();
        }

        function getParameterByName(name) {
            var url = window.location.href;
            name = name.replace(/[\[\]]/g, '\\$&');
            var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, ' '));
        }

        activate();

        function activate() {
            getList();
        }
    }
})();
