﻿try {
    //moment.locale('ur');
    let portalAPP = angular.module('housingSocieties', ['ngSanitize', 'angularMoment', 'ui.date']);
    portalAPP.config(['$compileProvider', function ($compileProvider) {
        //$compileProvider.debugInfoEnabled(false);
        //$compileProvider.commentDirectivesEnabled(false);
        //$compileProvider.cssClassDirectivesEnabled(false);
    }]);
    portalAPP.filter('titleCase', function () {
        return function (input) {
            input = input || '';

            return input.toLowerCase().split(' ').map(function (word) {
                return (word.charAt(0).toUpperCase() + word.slice(1));
            }).join(' ');
            //return input.replace(/\w\S*/g, function (txt) { return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase(); });
        };
    });
    portalAPP.directive('loadingSpinner', ['$http', '$timeout', function ($http, $timeout) {
        return {
            restrict: 'E',
            replace: true,
            controller: ['$scope', function ($scope) {

                $http.defaults.transformRequest.push(function (data) {
                    //console.log("$broadcast httpCallStarted " + $http.pendingRequests.length);
                    $scope.$broadcast('httpCallStarted');
                    //console.log(data);
                    return data;
                });

                $http.defaults.transformResponse.push(function (data) {
                    //console.log("$broadcast httpCallStopped " + $http.pendingRequests.length);
                    $scope.$broadcast('httpCallStopped');
                    //console.log(data);
                    return data;
                });

                $scope.$on('httpCallStarted', function (e) {
                    $timeout(function () {
                        //console.log("enter httpCallStarted " + $http.pendingRequests.length);

                        var callConfig = $http.pendingRequests[$http.pendingRequests.length - 1];

                        if (angular.isDefined(callConfig)) {
                            if (!angular.isDefined(callConfig.showLoader) || (angular.isDefined(callConfig.showLoader) && callConfig.showLoader)) {
                                $('.preloader').show();
                            }
                        } else {
                            $('.preloader').show();
                        }
                    }, 1);
                });

                $scope.$on('httpCallStopped', function (e) {
                    $timeout(function () {
                        //console.log("enter httpCallStopped " + $http.pendingRequests.length);

                        let pendingReuests = 0;

                        for (let i = 0; i < $http.pendingRequests.length; i++) {
                            let callConfig = $http.pendingRequests[i];

                            if (callConfig && !angular.isDefined(callConfig.showLoader) || (angular.isDefined(callConfig.showLoader) && callConfig.showLoader)) {
                                pendingReuests++;
                            }
                        }

                        if (pendingReuests == 0) {
                            $('.preloader').hide();
                        }
                    }, 1);
                });

                try {
                    $(function () {

                        "use strict";

                        if (typeof Sys.WebForms.PageRequestManager.getInstance() !== 'undefined') {
                            Sys.WebForms.PageRequestManager.getInstance().add_initializeRequest(ShowLoader);
                            Sys.WebForms.PageRequestManager.getInstance().add_endRequest(HideLoader);

                            function ShowLoader() {
                                $('.preloader').show();
                            }

                            function HideLoader() {
                                $('.preloader').hide();
                            }
                        }
                    });
                } catch (e) {
                    console.error(e);
                }
            }]
        }
    }]);
} catch (e) {
    console.error(e);
}