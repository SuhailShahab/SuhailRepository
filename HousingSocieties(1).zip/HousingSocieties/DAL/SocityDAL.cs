﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.DAL
{
    public class SocityDAL: BaseDAL
    {
        public DataTable GetAllSocities(SocietySearchModel searchModel)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spSocityGetAll", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if(searchModel != null)
                    {
                        if(searchModel.DevelopmentAuthoritieID.HasValue && searchModel.DevelopmentAuthoritieID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DevelopmentAuthoritieID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DevelopmentAuthoritieID"].Value = searchModel.DevelopmentAuthoritieID;
                        }

                        if (searchModel.DivisionID.HasValue && searchModel.DivisionID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = searchModel.DivisionID;
                        }

                        if (searchModel.DistrictID.HasValue && searchModel.DistrictID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = searchModel.DistrictID;
                        }

                        if (searchModel.CityID.HasValue && searchModel.CityID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CityID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@CityID"].Value = searchModel.CityID;
                        }
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        public DataTable GetSchemeStatusCount()
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDASchemeStatusCount", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    
                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        public DataTable GetSocietiesData(SocietySearchModel searchModel)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSocietiesDataDashboard", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (searchModel != null)
                    {
                        if (searchModel.DevelopmentAuthoritieID.HasValue && searchModel.DevelopmentAuthoritieID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AuthorityID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@AuthorityID"].Value = searchModel.DevelopmentAuthoritieID;
                        }

                        if (searchModel.DivisionID.HasValue && searchModel.DivisionID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = searchModel.DivisionID;
                        }

                        if (searchModel.DistrictID.HasValue && searchModel.DistrictID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = searchModel.DistrictID;
                        }

                        if (searchModel.SocietyStatusID.HasValue && searchModel.SocietyStatusID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SocietyStatusID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@SocietyStatusID"].Value = searchModel.SocietyStatusID;
                        }

                        if (searchModel.UserID.HasValue && searchModel.UserID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@UserID"].Value = searchModel.UserID;
                        }
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        public DataSet GetPagedSocities(SocietySearchModel searchModel, int? PageNumber, int? PageSize)
        {
            DataSet dt = new DataSet();
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetPagedSociety", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (PageNumber.HasValue && PageNumber.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNumber", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@PageNumber"].Value = PageNumber;
                    }

                    if (PageSize.HasValue && PageSize.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@PageSize"].Value = PageSize;
                    }

                    if (searchModel != null)
                    {
                        if (searchModel.DevelopmentAuthoritieID.HasValue && searchModel.DevelopmentAuthoritieID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DevelopmentAuthoritieID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DevelopmentAuthoritieID"].Value = searchModel.DevelopmentAuthoritieID;
                        }

                        if (searchModel.DivisionID.HasValue && searchModel.DivisionID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = searchModel.DivisionID;
                        }

                        if (searchModel.DistrictID.HasValue && searchModel.DistrictID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = searchModel.DistrictID;
                        }

                        if (searchModel.CityID.HasValue && searchModel.CityID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CityID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@CityID"].Value = searchModel.CityID;
                        }

                        if (searchModel.SocietyStatusID.HasValue && searchModel.SocietyStatusID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SocietyStatusID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@SocietyStatusID"].Value = searchModel.SocietyStatusID;
                        }

                        if(!string.IsNullOrEmpty(searchModel.SearchTerm))
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchTerm", SqlDbType.NVarChar));
                            sqlDadp.SelectCommand.Parameters["@SearchTerm"].Value = searchModel.SearchTerm;
                        }
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        public DataSet GetSocietiesFillLists(int? userID)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSocietiesFillLists", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
            return ds;
        }

        public DataSet GetSocietyFillLookups()
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSocietyFillLookups", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(ds);
                    //return ds;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
                return ds;
            }
        }

        public DataSet GetSocietyByID(int? societyID, int? userID)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSocietyDataBySocietyID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SocietyID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@SocietyID"].Value = societyID;

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }

                    sqlDadp.Fill(ds);
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
                return ds;
            }
        }

        public DataSet GetSocietyDetailByID(int? societyID)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSocietyDataDetailBySocietyID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SocietyID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@SocietyID"].Value = societyID;

                    

                    sqlDadp.Fill(ds);
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
                return ds;
            }
        }

        public int? SaveData(SocietyModel model, DataTable dtDocument, DataTable dtKML)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {
                        string spName = "spAddSocietyData";
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = spName;
                        sqlCmd.Transaction = transaction;

                        CommonUtility.LazyBaseSingleton<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                        if (dtDocument != null && dtDocument.Rows.Count > 0)
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@SocietyDocument", SqlDbType.Structured));
                            sqlCmd.Parameters["@SocietyDocument"].Value = dtDocument;
                        }

                        if (dtKML != null && dtKML.Rows.Count > 0)
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@SocietyKML", SqlDbType.Structured));
                            sqlCmd.Parameters["@SocietyKML"].Value = dtKML;
                        }

                        try
                        {
                            //result = sqlCmd.ExecuteNonQuery();
                            result = sqlCmd.ExecuteScalar();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }

        public int? UpdateData(SocietyModel model, DataTable dtDocument, DataTable dtKML)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {
                        string spName = "spEditSocietyData";
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = spName;
                        sqlCmd.Transaction = transaction;

                        CommonUtility.LazyBaseSingleton<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                        if (dtDocument != null && dtDocument.Rows.Count > 0)
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@SocietyDocument", SqlDbType.Structured));
                            sqlCmd.Parameters["@SocietyDocument"].Value = dtDocument;
                        }
                        if (dtKML != null && dtKML.Rows.Count > 0)
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@SocietyKML", SqlDbType.Structured));
                            sqlCmd.Parameters["@SocietyKML"].Value = dtKML;
                        }
                        try
                        {
                            result = sqlCmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }

        public int? UpdateSocietyInactive(SocietyInactiveModel model)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {
                        string spName = "spUpdateSocietyInactive";
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = spName;
                        sqlCmd.Transaction = transaction;

                        sqlCmd.Parameters.Add(new SqlParameter("@SocietyID", SqlDbType.Int));
                        sqlCmd.Parameters["@SocietyID"].Value = model.SocietyID;

                        sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                        sqlCmd.Parameters["@IsActive"].Value = model.IsActive;

                        sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlCmd.Parameters["@UserID"].Value = model.UserID;


                        try
                        {
                            result = sqlCmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }

    public int? DeleteSocietyDocument(DeleteSocietyDocumentModel model)
    {
        object result = 0;
        using (SqlConnection con = new SqlConnection(this.spConnectionString))
        {
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();

                using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                {
                    string spName = "spDeleteSocietyDocument";
                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = spName;
                    sqlCmd.Transaction = transaction;

                    sqlCmd.Parameters.Add(new SqlParameter("@SocietyID", SqlDbType.Int));
                    sqlCmd.Parameters["@SocietyID"].Value = model.SocietyID;

                    sqlCmd.Parameters.Add(new SqlParameter("@DocumentID", SqlDbType.Int));
                    sqlCmd.Parameters["@DocumentID"].Value = model.DocumentID;

                    sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlCmd.Parameters["@UserID"].Value = model.UserID;


                    try
                    {
                        result = sqlCmd.ExecuteNonQuery();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        return Convert.ToInt32(result);
    }

        public int? DeleteSocietyKML(DeleteSocietyDocumentModel model)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {
                        string spName = "spDeleteSocietyKML";
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = spName;
                        sqlCmd.Transaction = transaction;

                        sqlCmd.Parameters.Add(new SqlParameter("@SocietyID", SqlDbType.Int));
                        sqlCmd.Parameters["@SocietyID"].Value = model.SocietyID;

                        sqlCmd.Parameters.Add(new SqlParameter("@KMLID", SqlDbType.Int));
                        sqlCmd.Parameters["@KMLID"].Value = model.DocumentID;

                        sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlCmd.Parameters["@UserID"].Value = model.UserID;


                        try
                        {
                            result = sqlCmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }

        public DataTable DownloadFile(int? documentID)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDocumentByDocID ", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DocumentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DocumentID"].Value = documentID;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
            return dt;
        }

        public DataTable DownloadKMLFile(int? documentID, int?  SocietyID)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDocumentByKMLID ", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (documentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@KMLID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@KMLID"].Value = documentID;
                    }

                    if (SocietyID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SocietyID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SocietyID"].Value = SocietyID;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
            return dt;
        }

        public int UpdateSearchCounter()
        {
            DataTable dt = new DataTable();
            int counter=0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spUpdateSearchCounter ", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                   
                    sqlDadp.Fill(dt);

                    if (dt.Rows.Count>0)
                    {
                        counter = Convert.ToInt32(dt.Rows[0][0]);
                    }
                    
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
            return counter;
        }

        public int GetSearchCounter()
        {
            DataTable dt = new DataTable();
            int counter = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSearchCounter ", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        counter = Convert.ToInt32(dt.Rows[0][0]);
                    }

                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
            return counter;
        }
    }
}