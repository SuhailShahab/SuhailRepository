﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.DAL.Lookup
{
    public class CityDAL:BaseDAL
    {
        public DataTable GetAllCities()
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCities", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}