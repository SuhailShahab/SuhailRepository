﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.DAL.Lookup
{
    public class UserDAL : BaseDAL
    {
        public DataTable GetByUserName(string userName)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spUserByUserName", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@UserName"].Value = userName;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();

                }
            }
            
        }

        public DataTable GetByUserID(int userId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spUserByUserID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userId;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

        }

        public Identity.ApplicationUser Create(Identity.ApplicationUser user)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spAddUser", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@UserName"].Value = user.UserName;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PasswordHash", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@PasswordHash"].Value = user.PasswordHash;

                    sqlDadp.Fill(dt);

                    return user;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }

        public Identity.ApplicationUser Update(Identity.ApplicationUser user)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spUpdateUser", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserId"].Value = user.Id;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PasswordHash", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@PasswordHash"].Value = user.PasswordHash;

                    sqlDadp.Fill(dt);

                    return user;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }
    }
}