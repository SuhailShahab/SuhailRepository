﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.DAL.Lookup
{
    public class DocumentTypeDAL : BaseDAL
    {
        public DataSet GetAllDocumentTypes()
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDocumentTypes", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}