﻿using PITB.FC.HousingSocieties.CommonUtility;
using PITB.FC.HousingSocieties.Models.Lookup;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.DAL.Lookup
{
    public class VisitorCountDAL : BaseDAL
    {
        public int? SaveData(VisitorCountModel model)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {
                        string spName = "spAddVisitorCount";
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = spName;
                        sqlCmd.Transaction = transaction;

                        CommonUtility.LazyBaseSingleton<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);
                        
                        try
                        {
                            result = sqlCmd.ExecuteScalar();
                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }
    }
}