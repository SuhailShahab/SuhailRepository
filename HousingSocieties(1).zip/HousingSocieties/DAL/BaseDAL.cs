﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace PITB.FC.HousingSocieties.DAL
{
    public abstract class BaseDAL
    {
        private string m_spConnectionString = "DBConnectionString";

        public BaseDAL(bool isWrite = false)
        {
            // this.IsSavedMetaData = true;

           // string IsNewArchitecture = ConfigurationManager.AppSettings["IsNewArchitecture"];
          //  if (string.IsNullOrEmpty(IsNewArchitecture) || !Convert.ToBoolean(IsNewArchitecture))
          //  {
                //==========================Old Architecture===========================================================
                this.m_spConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString.ToString() + ";";
                // this.IsCenterlizedSaved = Convert.ToBoolean(ConfigurationManager.AppSettings["IsCenterlizedSaved"]);
          //  }
            //else
            //{

            //    //===========================Get the Application Level Setting form webconfig===========================
            //    string commonDB = ConfigurationManager.AppSettings["DefaultCommonDBName"];
            //    string serverName = ConfigurationManager.AppSettings["DefaultServerName"];
            //    string agl = isWrite ? ConfigurationManager.AppSettings["WriteAGL"] : ConfigurationManager.AppSettings["ReadAGL"];
            //    string connectionstring = ConfigurationManager.ConnectionStrings["DBConnectionStringNew"].ConnectionString.ToString();

            //    //===========================END=======================================================================
            //    //Set DB Name
            //    connectionstring = connectionstring.Replace("DBName", commonDB);
            //    //Set Server with readAGL
            //    this.m_spConnectionString = connectionstring.Replace("ServerName", serverName + agl);
            //    this.spDefaultWriteConnectionString = connectionstring.Replace("ServerName", serverName + ConfigurationManager.AppSettings["WriteAGL"]);
            //}
        }
        protected string spConnectionString
        {
            get { return m_spConnectionString; }
        }
    }
}