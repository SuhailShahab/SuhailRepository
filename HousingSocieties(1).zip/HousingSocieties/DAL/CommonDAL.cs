﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using PITB.FC.HousingSocieties.Models;

namespace PITB.FC.HousingSocieties.DAL
{
    public class CommonDAL : BaseDAL
    {
        public int SaveErrorLogs(ErrorLogModel ErrorLog)
        {
            object result = "";
            SqlConnection con = new SqlConnection(this.spConnectionString);
            //SqlConnection con = new SqlConnection(this.spDefaultWriteConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddErrorLog";

                if (!string.IsNullOrEmpty(ErrorLog.Method))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Method", SqlDbType.VarChar));
                    sqlCmd.Parameters["@Method"].Value = ErrorLog.Method;
                }

                if (!string.IsNullOrEmpty(ErrorLog.Message))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Message", SqlDbType.VarChar));
                    sqlCmd.Parameters["@Message"].Value = ErrorLog.Message;
                }
                if (!string.IsNullOrEmpty(ErrorLog.StackTrace))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar));
                    sqlCmd.Parameters["@StackTrace"].Value = ErrorLog.StackTrace;
                }
                if (!string.IsNullOrEmpty(ErrorLog.Source))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Source", SqlDbType.VarChar));
                    sqlCmd.Parameters["@Source"].Value = ErrorLog.Source;
                }

                sqlCmd.Parameters.Add(new SqlParameter("@IsWebMethod", SqlDbType.Bit));
                sqlCmd.Parameters["@IsWebMethod"].Value = ErrorLog.IsWebMethod;

                sqlCmd.Parameters.Add(new SqlParameter("@Created", SqlDbType.DateTime));
                sqlCmd.Parameters["@Created"].Value = DateTime.Now;

                if (!string.IsNullOrEmpty(ErrorLog.LocationCode))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@LocationCode", SqlDbType.VarChar));
                    sqlCmd.Parameters["@LocationCode"].Value = ErrorLog.LocationCode;
                }


                if (!string.IsNullOrEmpty(ErrorLog.ServiceCode))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@ServiceCode", SqlDbType.VarChar));
                    sqlCmd.Parameters["@ServiceCode"].Value = ErrorLog.ServiceCode;
                }

                if (!string.IsNullOrEmpty(ErrorLog.PageName))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@PageName", SqlDbType.VarChar));
                    sqlCmd.Parameters["@PageName"].Value = ErrorLog.PageName;
                }
                result = sqlCmd.ExecuteScalar();

            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open) con.Close();
            }

            return Convert.ToInt32(result);
        }
    }
}