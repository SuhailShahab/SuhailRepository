﻿using PITBFC.FP.ApplicationClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PITBFC.FP.BOP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           string abc =  CustomSecurity.Decode("RGF0YSBTb3VyY2U9MTAuMS4xMTUuNTtJbml0aWFsIENhdGFsb2c9UElUQkZDO1BlcnNpc3QgU2VjdXJpdHkgSW5mbz1UcnVlO1VzZXIgSUQ9c2E7UGFzc3dvcmQ9RGl0Y0BwaXRiO0Nvbm5lY3QgVGltZW91dD0yMDs=");
        }
    }
}
