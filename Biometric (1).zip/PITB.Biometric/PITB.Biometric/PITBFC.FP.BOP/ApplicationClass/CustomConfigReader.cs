﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITBFC.FP.ApplicationClass
{
    public class CustomConfigReader
    {
        //internal static string Location
        //{
        //    get { return CustomSecurity.Decode(ConfigurationManager.AppSettings["Location"]); }
        //}
        internal static string LocationCode
        {
            get { return CustomSecurity.Decode(ConfigurationManager.AppSettings["LocationCode"]); }
        }
        internal static string LocationName
        {
            get { return CustomSecurity.Decode(ConfigurationManager.AppSettings["LocationName"]); }
        }
        //internal static string District
        //{
        //    get { return CustomSecurity.Decode(ConfigurationManager.AppSettings["District"]); }
        //}
        internal static string DistrictCode
        {
            get { return CustomSecurity.Decode(ConfigurationManager.AppSettings["DistrictCode"]); }
        }
        internal static int? LocationID
        {
            get { return Convert.ToInt32(CustomSecurity.Decode(ConfigurationManager.AppSettings["LocationID"])); }
        }
        internal static string AreaName
        {
            get { return CustomSecurity.Decode(ConfigurationManager.AppSettings["AreaName"]); }
        }

        internal static string DBConnectionString
        {
            get { return CustomSecurity.Decode(ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString); }
        }

        #region Common AppSetting
        internal static bool? IsShowGeneralMsg
        {
            get { return Convert.ToBoolean(ConfigurationManager.AppSettings["IsShowGeneralMsg"]); }
        }
        internal static string GeneralMsg
        {
            get
            {
                return Convert.ToString(ConfigurationManager.AppSettings["GeneralMsg"]) + GetDateTimeStamp();
            }
        }
        internal static bool ShowLog
        {
            get { return Convert.ToBoolean(ConfigurationManager.AppSettings["ShowLog"]); }
        }
        internal static string LogFilePath
        {
            get { return Convert.ToString(ConfigurationManager.AppSettings["LogFilePath"]); }
        }


        #endregion

        #region Custom Method
        internal static string GetDateTimeStamp()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("[");
            sb.Append(DateTime.Now.ToString("ddMMMyyyy"));
            sb.Append("-");
            sb.Append(DateTime.Now.ToString("HH:mm:ss"));
            sb.Append("]");
            return sb.ToString();

        }
        #endregion
    }
}
