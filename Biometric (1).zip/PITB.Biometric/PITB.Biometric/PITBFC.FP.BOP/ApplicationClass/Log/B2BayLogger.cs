﻿using PITBFC.FP.ApplicationClass;
using System;
using System.IO;
using System.Text;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <21-10-2015 07:47:38PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPScheduler.ApplicationClassess.Log
{
    public static class B2BayLogger
    {
        public static void Log(String strLog)
        {
            if (CustomConfigReader.ShowLog)
                Log(strLog, LogMode.INFO);
        }

        public static void LogErr(String strLog, Exception e)
        {
            if (CustomConfigReader.ShowLog)
            {
                Log(strLog, LogMode.ERROR);
                Log("Summary: " + e.Message, LogMode.ERROR);
                Log("Detail: " + e.StackTrace, LogMode.ERROR);
            }
        }
        public static void LogErr(Exception e)
        {
            if (CustomConfigReader.ShowLog)
            {                
                Log("Summary: " + e.Message, LogMode.ERROR);
                Log("Detail: " + e.StackTrace, LogMode.ERROR);
            }
        }
        public static void WriteLogsToFile()
        {
            if (CustomConfigReader.ShowLog)
            {
                if (logDate == null)
                {
                    logDate = DateTime.Now;
                    Utility.createLogFile();
                    Utility.writeLogsToFile(logDate);
                }
                else if (Utility.getDay(logDate) < Utility.getDay(DateTime.Now))
                {
                    Utility.writeLogsToFile(logDate);
                    logDate = null;
                }
                else
                {
                    Utility.writeLogsToFile(logDate);
                }
            }
        }
        
        #region "Private Members, Methods and Enums"

        private static void Log(String strLog, LogMode enumLogMode)
        {
            if (CustomConfigReader.ShowLog)
            {
                if (stringBuffer == null)
                    stringBuffer = new StringBuilder();
                stringBuffer.Append(Utility.ParseDateToString(DateTime.Now) + " [" + enumLogMode + "] " + strLog + "\r\n");
            }
        }

        private enum LogMode
        {
            INFO,
            ERROR
        }

        private static StringBuilder stringBuffer = null;
        private static DateTime? logDate = null;

        #endregion

        #region Utilty Classs

        public static class Utility
        {
            private static readonly object Locker = new object();

            static bool isEmpty(String str)
            {
                if (str == null || str.Trim().Length == 0)
                {
                    return true;
                }

                return false;
            }

            public static string ParseDateToString(DateTime? date)
            {
                if (!date.HasValue)
                    return "";

                string simpleDateFormat = date.Value.ToString("HH:mm:ss");
                return simpleDateFormat;
            }

            public static string GetFilename(DateTime? date)
            {
                if (!date.HasValue)
                    return "";

                return date.Value.ToString("ddMMMyyyy");
            }

            static string GetTab(int level)
            {
                StringBuilder sbLevel = new StringBuilder();

                for (int tab = 0; tab < level; tab++)
                {
                    sbLevel.Append(" ");
                }

                return sbLevel.ToString();
            }

            static string StackTraceToString(Exception e)
            {
                return e.StackTrace;
            }

            //static bool showLog()
            //{
            //    if (!Utility.isEmpty(ConfigurationHelper.ShowLog) && (ConfigurationHelper.ShowLog.ToUpper().Equals("TRUE") || ConfigurationReader.ShowLog.ToUpper().Equals("FALSE")))
            //        return Convert.ToBoolean(ConfigurationHelper.ShowLog);
            //    return false;
            //}

            public static void writeLogsToFile(DateTime? date)
            {
                string logFilename = Path.Combine(CustomConfigReader.LogFilePath, GetFilename(date) + ".log");

                try
                {
                    makeDir(CustomConfigReader.LogFilePath);

                    // logFile =n new File(logFilename);
                    //if (!File.Exists(logFilename))
                    //{
                    //    logFile = new File(logFilename);
                    //}

                    /*fileWritter = new FileWriter(logFile, true);
                    BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
                    bufferWritter.write(stringBuffer.toString());
                    bufferWritter.close();
                    stringBuffer.delete(0, stringBuffer.length());*/

                    lock (Locker)
                    {
                        using (var fileStream = new FileStream(logFilename, FileMode.Append, FileAccess.Write))
                        {
                            using (var streamWriter = new StreamWriter(fileStream))
                            {
                                streamWriter.WriteLine(stringBuffer.ToString());
                                streamWriter.Flush();

                                if (stringBuffer != null && stringBuffer.Length > 0)
                                {
                                    stringBuffer.Clear();
                                    stringBuffer = null;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    // ex.printStackTrace();
                    //  B2BayLogger.logErr("Exception occurred while creating the log file", ex);
                }
            }
           

            public static void createLogFile()
            {
                string logFilename = Path.Combine(CustomConfigReader.LogFilePath, GetFilename(logDate) + ".log");
                makeDir(CustomConfigReader.LogFilePath);

                if (!File.Exists(logFilename))
                {
                    try
                    {
                        using (var myFile = File.Create(logFilename))
                        {
                            // interact with myFile here, it will be disposed automatically
                        }
                    }
                    catch (IOException e)
                    {
                        //e.printStackTrace();
                        B2BayLogger.LogErr("IO Exception", e);
                    }
                }
            }
            
            static void makeDir(String logDirectory)
            {
                var directoryInfo = new DirectoryInfo(logDirectory);

                if (!directoryInfo.Exists)
                    directoryInfo.Create();
            }

            public static int getDay(DateTime? date)
            {
                /* Calendar calendar = new GregorianCalendar();
                 calendar.setTimeInMillis(date.getTime());
                 return calendar.get(Calendar.MINUTE);*/
                return date.Value.Day;
            }
        }

        #endregion
    }
}
