﻿//using PITBFC.FP.BOP.PITBFacilitationCentreService;
using PITBFC.FP.BOP.PITBFCSecurityEnrollment;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PITBFC.FP.ApplicationClass
{
   public static class CustomConfigWriter
    {
       public static void WriteAppSetting(UserModel value)
       {
           if (value != null)
           {
               Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

               config.AppSettings.Settings["LocationID"].Value = CustomSecurity.Encode(value.FCLocationID.ToString());
               config.AppSettings.Settings["LocationCode"].Value = CustomSecurity.Encode(value.LocationCode);
               config.AppSettings.Settings["LocationName"].Value = CustomSecurity.Encode(value.LocationName);
               //config.AppSettings.Settings["District"].Value = CustomSecurity.Encode(value.DistrictCode);
               config.AppSettings.Settings["DistrictCode"].Value = CustomSecurity.Encode(value.DistrictCode);
               config.AppSettings.Settings["AreaName"].Value = CustomSecurity.Encode(value.LocationName + "(" + value.LocationCode + ")"); ;


               config.Save(ConfigurationSaveMode.Modified);

               ConfigurationManager.RefreshSection("appSettings");
           }
           
       }

       public static void SetConnectionSetting(UserModel value)
       {
           if (value!=null && !string.IsNullOrEmpty(value.LocationConnectionString))
           {
               Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);

               ConnectionStringSettings st = new ConnectionStringSettings("DBConnectionString", "", "System.Data.SqlClient");
               config.ConnectionStrings.ConnectionStrings.Remove(st);

               ConnectionStringSettings st2 = new ConnectionStringSettings("DBConnectionString", CustomSecurity.Encode(value.LocationConnectionString), "System.Data.SqlClient");
               config.ConnectionStrings.ConnectionStrings.Add(st2);

               //Save the configuration file.
               config.Save(ConfigurationSaveMode.Modified);

               // Force a reload of a changed section.
               ConfigurationManager.RefreshSection("connectionString");
              
           }
            
       }
    }
}
