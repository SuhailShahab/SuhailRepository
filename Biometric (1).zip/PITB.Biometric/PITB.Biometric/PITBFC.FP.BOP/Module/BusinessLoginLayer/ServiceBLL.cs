﻿using PITBFC.FP.Module.DataAccessLayer;
using PITBFC.FP.Module.DataModelLayer;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <04-03-2015 06:30:55PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Module.BusinessLoginLayer
{
    public class ServiceBLL
    {
        public List<ServiceModel> GetServices()
        {
            DataTable dt = null;
            dt = new ServiceDAL().GetAll();
            return BuildModelCollection(dt);
        }

        #region "Private Methods"

        internal List<ServiceModel> BuildModelCollection(DataTable dt)
        {
            List<ServiceModel> collection = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                collection = new List<ServiceModel>();

                foreach (DataRow dr in dt.Rows)
                {
                    ServiceModel sm = new ServiceModel();

                    if (dt.Columns.Contains("ServiceID") && !Convert.IsDBNull(dr["ServiceID"]))
                        sm.ID = Convert.ToInt32(dr["ServiceID"]);
                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        sm.Code = Convert.ToString(dr["Code"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        sm.Title = Convert.ToString(dr["Title"]).ToUpper();

                    collection.Add(sm);
                }

                collection.TrimExcess();
            }

            return collection;
        }

        #endregion
    }
}
