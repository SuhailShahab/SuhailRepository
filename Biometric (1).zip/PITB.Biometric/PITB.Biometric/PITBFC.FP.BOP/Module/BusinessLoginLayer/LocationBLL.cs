﻿using PITBFC.FP.Module.DataAccessLayer;
using PITBFC.FP.Module.DataModelLayer;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <04-03-2015 06:30:55PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Module.BusinessLoginLayer
{
    public class LocationBLL
    {
        public List<LocationModel> GetLocations()
        {
            DataTable dt = null;
            dt = new LocationDAL().GetAll();
            return BuildModelCollection(dt);
        }

        public LocationModel GetLocationByCode(string Code)
        {
            DataTable dt = new LocationDAL().GetLocationByCode(Code);
            return BuildModel(dt);
        }

        #region "Private Methods"

        private LocationModel BuildModel(DataTable dt)
        {
            LocationModel lm = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                lm = new LocationModel();

                if (dt.Columns.Contains("LocationID") && !Convert.IsDBNull(dr["LocationID"]))
                    lm.ID = Convert.ToInt32(dr["LocationID"]);
                if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                    lm.Code = Convert.ToString(dr["Code"]);
                if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                    lm.Title = Convert.ToString(dr["Name"]);
                if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                    lm.DistrictID = Convert.ToInt32(dr["DistrictID"]);
                if (dt.Columns.Contains("DistrictCode") && !Convert.IsDBNull(dr["DistrictCode"]))
                    lm.DistrictCode = Convert.ToString(dr["DistrictCode"]);
            }

            return lm;
        }

        private List<LocationModel> BuildModelCollection(DataTable dt)
        {
            List<LocationModel> collection = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                collection = new List<LocationModel>();

                foreach (DataRow dr in dt.Rows)
                {
                    LocationModel lm = new LocationModel();

                    if (dt.Columns.Contains("LocationID") && !Convert.IsDBNull(dr["LocationID"]))
                        lm.ID = Convert.ToInt32(dr["LocationID"]);
                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        lm.Code = Convert.ToString(dr["Code"]);
                    if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                        lm.Title = Convert.ToString(dr["Name"]);

                    collection.Add(lm);
                }

                collection.TrimExcess();
            }

            return collection;
        }

        #endregion
    }
}
