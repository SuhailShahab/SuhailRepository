﻿using PITBFC.FP.Module.DataAccessLayer;
using PITBFC.FP.Module.DataModelLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <05-03-2015 11:16:31AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Module.BusinessLoginLayer
{
    public class NICRecordBLL
    {
        /// <summary>
        /// Enroll a biometric agaist CNIC
        /// </summary>
        /// <param name="Model"></param>
        /// <returns></returns>
        public int Save(NICRecordModel Model)
        {
            return new NICRecordDAL().Add(Model);
        }

        /// <summary>
        /// Get cnic record against cnic number
        /// </summary>
        /// <param name="CNICNumber"></param>
        /// <param name="DistrictCode"></param>
        /// <returns></returns>
        public NICRecordModel GetNadraCNICRecord(string CNICNumber, string DistrictCode)
        {
            DataTable dt = new DataTable();
            dt = new NICRecordDAL().GetNICNadraRecord(CNICNumber, DistrictCode);
            return BuildModel(dt);
        }

        /// <summary>
        /// Get all records
        /// </summary>
        /// <returns></returns>
        public List<NICRecordModel> GetNadraCNICRecord()
        {
            DataTable dt = new DataTable();
            dt = new NICRecordDAL().GetNICNadraRecord();
            return BuildModelCollection(dt);
        }

        /// <summary>
        /// Get cnic record agaist cnic
        /// </summary>
        /// <param name="cnic"></param>
        /// <returns></returns>
        public List<NICRecordModel> GetNadraCNICRecord(string cnic)
        {
            DataTable dt = new DataTable();
            dt = new NICRecordDAL().GetNICNadraRecord(cnic);
            return BuildModelCollection(dt);
        }

        #region "Private Methods"

        private NICRecordModel BuildModel(DataTable dt)
        {
            NICRecordModel model = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                model = new NICRecordModel();

                if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                    model.Name = dr["Name"].ToString();

                //if (dt.Columns.Contains("NameUrdu") && !Convert.IsDBNull(dr["NameUrdu"]))
                //    model.NameUrdu = dr["NameUrdu"].ToString();

                if (dt.Columns.Contains("FatherName") && !Convert.IsDBNull(dr["FatherName"]))
                    model.FatherName = dr["FatherName"].ToString();

                //if (dt.Columns.Contains("FatherNameUrdu") && !Convert.IsDBNull(dr["FatherNameUrdu"]))
                //    model.FatherNameUrdu = dr["FatherNameUrdu"].ToString();

                //if (dt.Columns.Contains("GenderID") && !Convert.IsDBNull(dr["GenderID"]))
                //    model.GenderID = Convert.ToInt16(dr["GenderID"].ToString());

                //if (dt.Columns.Contains("DOB") && !Convert.IsDBNull(dr["DOB"]))
                //    model.DOB = Convert.ToDateTime(dr["DOB"].ToString()).ToString("dd/MM/yyyy");

                //if (dt.Columns.Contains("IssueDate") && !Convert.IsDBNull(dr["IssueDate"]))
                //    model.IssueDate = Convert.ToDateTime(dr["IssueDate"].ToString()).Date;

                //if (dt.Columns.Contains("ExpiryDate") && !Convert.IsDBNull(dr["ExpiryDate"]))
                //    model.ExpiryDate = Convert.ToDateTime(dr["ExpiryDate"].ToString()).Date;

                //if (dt.Columns.Contains("HouseNo") && !Convert.IsDBNull(dr["HouseNo"]))
                //    model.HouseNo = dr["HouseNo"].ToString();

                //if (dt.Columns.Contains("StreetNo") && !Convert.IsDBNull(dr["StreetNo"]))
                //    model.StreetNo = dr["StreetNo"].ToString();

                //if (dt.Columns.Contains("BlockNo") && !Convert.IsDBNull(dr["BlockNo"]))
                //    model.BlockNo = dr["BlockNo"].ToString();

                //if (dt.Columns.Contains("Neighbourhood") && !Convert.IsDBNull(dr["Neighbourhood"]))
                //    model.Neighbourhood = dr["Neighbourhood"].ToString();

                //if (dt.Columns.Contains("NeighbourhoodUrdu") && !Convert.IsDBNull(dr["NeighbourhoodUrdu"]))
                //    model.NeighbourhoodUrdu = dr["NeighbourhoodUrdu"].ToString();

                //if (dt.Columns.Contains("AdditionalInformation") && !Convert.IsDBNull(dr["AdditionalInformation"]))
                //    model.AdditionalInformation = dr["AdditionalInformation"].ToString();

                //if (dt.Columns.Contains("AdditionalInformationUrdu") && !Convert.IsDBNull(dr["AdditionalInformationUrdu"]))
                //    model.AdditionalInformationUrdu = dr["AdditionalInformationUrdu"].ToString();

                //if (dt.Columns.Contains("PermanentAddress") && !Convert.IsDBNull(dr["PermanentAddress"]))
                //    model.PermanentAddress = dr["PermanentAddress"].ToString();

                //if (dt.Columns.Contains("PermanentAddressUrdu") && !Convert.IsDBNull(dr["PermanentAddressUrdu"]))
                //    model.PermanentAddressUrdu = dr["PermanentAddressUrdu"].ToString();

                //if (dt.Columns.Contains("CurrentAddress") && !Convert.IsDBNull(dr["CurrentAddress"]))
                //    model.CurrentAddress = dr["CurrentAddress"].ToString();

                //if (dt.Columns.Contains("ContactNo") && !Convert.IsDBNull(dr["ContactNo"]))
                //    model.ContactNo = dr["ContactNo"].ToString();

                //if (dt.Columns.Contains("CurrentAddressUrdu") && !Convert.IsDBNull(dr["CurrentAddressUrdu"]))
                //    model.CurrentAddressUrdu = dr["CurrentAddressUrdu"].ToString();

                //if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                //    model.DivisionID = Convert.ToInt16(dr["DivisionID"].ToString());

                //if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                //    model.DistrictID = Convert.ToInt16(dr["DistrictID"].ToString());

                //if (dt.Columns.Contains("TehsilID") && !Convert.IsDBNull(dr["TehsilID"]))
                //    model.TehsilID = Convert.ToInt16(dr["TehsilID"].ToString());

                //if (dt.Columns.Contains("CityID") && !Convert.IsDBNull(dr["CityID"]))
                //    model.CityID = Convert.ToInt16(dr["CityID"].ToString());

                //if (dt.Columns.Contains("UnionCouncilID") && !Convert.IsDBNull(dr["UnionCouncilID"]))
                //    model.UnionCouncilID = Convert.ToInt16(dr["UnionCouncilID"].ToString());

                //if (dt.Columns.Contains("CNICImageFront") && !Convert.IsDBNull(dr["CNICImageFront"]))
                //    model.CNICImageFront = dr["CNICImageFront"].ToString();

                //if (dt.Columns.Contains("CNICImageBack") && !Convert.IsDBNull(dr["CNICImageBack"]))
                //    model.CNICImageBack = dr["CNICImageBack"].ToString();

                //if (dt.Columns.Contains("Signature") && !Convert.IsDBNull(dr["Signature"]))
                //    model.Signature = dr["Signature"].ToString();

            }

            return model;
        }

        private List<NICRecordModel> BuildModelCollection(DataTable dt)
        {
            List<NICRecordModel> collection = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                collection = new List<NICRecordModel>();

                foreach (DataRow dr in dt.Rows)
                {
                    NICRecordModel model = new NICRecordModel();

                    if (dt.Columns.Contains("CNIC") && !Convert.IsDBNull(dr["CNIC"]))
                        model.CNIC = dr["CNIC"].ToString();

                    if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                        model.Name = dr["Name"].ToString();

                    //if (dt.Columns.Contains("NameUrdu") && !Convert.IsDBNull(dr["NameUrdu"]))
                    //    model.NameUrdu = dr["NameUrdu"].ToString();

                    if (dt.Columns.Contains("FatherName") && !Convert.IsDBNull(dr["FatherName"]))
                        model.FatherName = dr["FatherName"].ToString();

                    //if (dt.Columns.Contains("FatherNameUrdu") && !Convert.IsDBNull(dr["FatherNameUrdu"]))
                    //    model.FatherNameUrdu = dr["FatherNameUrdu"].ToString();

                    //if (dt.Columns.Contains("GenderID") && !Convert.IsDBNull(dr["GenderID"]))
                    //    model.GenderID = Convert.ToInt16(dr["GenderID"].ToString());

                    //if (dt.Columns.Contains("DOB") && !Convert.IsDBNull(dr["DOB"]))
                    //    model.DOB = Convert.ToDateTime(dr["DOB"].ToString()).ToString("dd/MM/yyyy");

                    //if (dt.Columns.Contains("IssueDate") && !Convert.IsDBNull(dr["IssueDate"]))
                    //    model.IssueDate = Convert.ToDateTime(dr["IssueDate"].ToString()).Date;

                    //if (dt.Columns.Contains("ExpiryDate") && !Convert.IsDBNull(dr["ExpiryDate"]))
                    //    model.ExpiryDate = Convert.ToDateTime(dr["ExpiryDate"].ToString()).Date;

                    //if (dt.Columns.Contains("HouseNo") && !Convert.IsDBNull(dr["HouseNo"]))
                    //    model.HouseNo = dr["HouseNo"].ToString();

                    //if (dt.Columns.Contains("StreetNo") && !Convert.IsDBNull(dr["StreetNo"]))
                    //    model.StreetNo = dr["StreetNo"].ToString();

                    //if (dt.Columns.Contains("BlockNo") && !Convert.IsDBNull(dr["BlockNo"]))
                    //    model.BlockNo = dr["BlockNo"].ToString();

                    //if (dt.Columns.Contains("Neighbourhood") && !Convert.IsDBNull(dr["Neighbourhood"]))
                    //    model.Neighbourhood = dr["Neighbourhood"].ToString();

                    //if (dt.Columns.Contains("NeighbourhoodUrdu") && !Convert.IsDBNull(dr["NeighbourhoodUrdu"]))
                    //    model.NeighbourhoodUrdu = dr["NeighbourhoodUrdu"].ToString();

                    //if (dt.Columns.Contains("AdditionalInformation") && !Convert.IsDBNull(dr["AdditionalInformation"]))
                    //    model.AdditionalInformation = dr["AdditionalInformation"].ToString();

                    //if (dt.Columns.Contains("AdditionalInformationUrdu") && !Convert.IsDBNull(dr["AdditionalInformationUrdu"]))
                    //    model.AdditionalInformationUrdu = dr["AdditionalInformationUrdu"].ToString();

                    //if (dt.Columns.Contains("PermanentAddress") && !Convert.IsDBNull(dr["PermanentAddress"]))
                    //    model.PermanentAddress = dr["PermanentAddress"].ToString();

                    //if (dt.Columns.Contains("PermanentAddressUrdu") && !Convert.IsDBNull(dr["PermanentAddressUrdu"]))
                    //    model.PermanentAddressUrdu = dr["PermanentAddressUrdu"].ToString();

                    //if (dt.Columns.Contains("CurrentAddress") && !Convert.IsDBNull(dr["CurrentAddress"]))
                    //    model.CurrentAddress = dr["CurrentAddress"].ToString();

                    //if (dt.Columns.Contains("ContactNo") && !Convert.IsDBNull(dr["ContactNo"]))
                    //    model.ContactNo = dr["ContactNo"].ToString();

                    //if (dt.Columns.Contains("CurrentAddressUrdu") && !Convert.IsDBNull(dr["CurrentAddressUrdu"]))
                    //    model.CurrentAddressUrdu = dr["CurrentAddressUrdu"].ToString();

                    //if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                    //    model.DivisionID = Convert.ToInt16(dr["DivisionID"].ToString());

                    //if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                    //    model.DistrictID = Convert.ToInt16(dr["DistrictID"].ToString());

                    //if (dt.Columns.Contains("TehsilID") && !Convert.IsDBNull(dr["TehsilID"]))
                    //    model.TehsilID = Convert.ToInt16(dr["TehsilID"].ToString());

                    //if (dt.Columns.Contains("CityID") && !Convert.IsDBNull(dr["CityID"]))
                    //    model.CityID = Convert.ToInt16(dr["CityID"].ToString());

                    //if (dt.Columns.Contains("UnionCouncilID") && !Convert.IsDBNull(dr["UnionCouncilID"]))
                    //    model.UnionCouncilID = Convert.ToInt16(dr["UnionCouncilID"].ToString());

                    //if (dt.Columns.Contains("CNICImageFront") && !Convert.IsDBNull(dr["CNICImageFront"]))
                    //    model.CNICImageFront = dr["CNICImageFront"].ToString();

                    //if (dt.Columns.Contains("CNICImageBack") && !Convert.IsDBNull(dr["CNICImageBack"]))
                    //    model.CNICImageBack = dr["CNICImageBack"].ToString();

                    //if (dt.Columns.Contains("Signature") && !Convert.IsDBNull(dr["Signature"]))
                    //    model.Signature = dr["Signature"].ToString();

                    if (dt.Columns.Contains("FingerImpression") && !Convert.IsDBNull(dr["FingerImpression"]))
                    {
                        model.FingerImpression = (byte[])dr["FingerImpression"];
                        
                    }

                    if (dt.Columns.Contains("FingerPrint") && !Convert.IsDBNull(dr["FingerPrint"]))
                        model.FignerPrint = dr["FingerPrint"].ToString();

                    collection.Add(model);
                }

                collection.TrimExcess();
            }

            return collection;
        }

        #endregion
    }
}
