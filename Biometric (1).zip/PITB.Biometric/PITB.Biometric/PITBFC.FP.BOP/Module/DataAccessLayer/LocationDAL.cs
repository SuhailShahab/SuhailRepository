﻿using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <04-03-2015 06:06:55PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Module.DataAccessLayer
{
    public class LocationDAL : BaseDAL
    {
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                using(SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetLocations", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetLocationByCode(string code)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetLocationByCode", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@Code"].Value = code != null ? code : "";

                    sqlDadp.Fill(dt);
                    return dt;
                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
