﻿using PITBFC.FP.Module.DataModelLayer;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <05-03-2015 11:16:31AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Module.DataAccessLayer
{
    public class NICRecordDAL : BaseDAL
    {
        /// <summary>
        /// Enroll a biometric agaist CNIC
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(NICRecordModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddNICNadraRecord";

                sqlCmd.Parameters.Add(new SqlParameter("@CNIC", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CNIC"].Value = model.CNIC;

                sqlCmd.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Name"].Value = model.Name;

                sqlCmd.Parameters.Add(new SqlParameter("@NameUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@NameUrdu"].Value = model.NameUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@FatherName", SqlDbType.NVarChar));
                sqlCmd.Parameters["@FatherName"].Value = model.FatherName;

                sqlCmd.Parameters.Add(new SqlParameter("@FatherNameUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@FatherNameUrdu"].Value = model.FatherNameUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@ContactNo", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ContactNo"].Value = model.ContactNo;

                sqlCmd.Parameters.Add(new SqlParameter("@GenderID", SqlDbType.Int));
                sqlCmd.Parameters["@GenderID"].Value = model.GenderID;

                if (model.DOB == null)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@DOB", SqlDbType.DateTime));
                    sqlCmd.Parameters["@DOB"].Value = model.DOB;
                }

                if (model.IssueDate == null)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@IssueDate", SqlDbType.DateTime));
                    sqlCmd.Parameters["@IssueDate"].Value = model.IssueDate;
                }

                if (model.ExpiryDate == null)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@ExpiryDate", SqlDbType.DateTime));
                    sqlCmd.Parameters["@ExpiryDate"].Value = model.ExpiryDate;
                }

                sqlCmd.Parameters.Add(new SqlParameter("@HouseNo", SqlDbType.NVarChar));
                sqlCmd.Parameters["@HouseNo"].Value = model.HouseNo;

                sqlCmd.Parameters.Add(new SqlParameter("@StreetNo", SqlDbType.NVarChar));
                sqlCmd.Parameters["@StreetNo"].Value = model.StreetNo;

                sqlCmd.Parameters.Add(new SqlParameter("@BlockNo", SqlDbType.NVarChar));
                sqlCmd.Parameters["@BlockNo"].Value = model.BlockNo;

                sqlCmd.Parameters.Add(new SqlParameter("@Neighbourhood", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Neighbourhood"].Value = model.Neighbourhood;

                sqlCmd.Parameters.Add(new SqlParameter("@NeighbourhoodUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@NeighbourhoodUrdu"].Value = model.NeighbourhoodUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@AdditionalInformation", SqlDbType.NVarChar));
                sqlCmd.Parameters["@AdditionalInformation"].Value = model.AdditionalInformation;

                sqlCmd.Parameters.Add(new SqlParameter("@AdditionalInformationUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@AdditionalInformationUrdu"].Value = model.AdditionalInformationUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@PermanentAddress", SqlDbType.NVarChar));
                sqlCmd.Parameters["@PermanentAddress"].Value = model.PermanentAddress;

                sqlCmd.Parameters.Add(new SqlParameter("@PermanentAddressUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@PermanentAddressUrdu"].Value = model.PermanentAddressUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@CurrentAddress", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CurrentAddress"].Value = model.CurrentAddress;

                sqlCmd.Parameters.Add(new SqlParameter("@CurrentAddressUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CurrentAddressUrdu"].Value = model.CurrentAddressUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@DivisionID"].Value = model.DivisionID;

                sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@DistrictID"].Value = model.DistrictID;

                sqlCmd.Parameters.Add(new SqlParameter("@TehsilID", SqlDbType.Int));
                sqlCmd.Parameters["@TehsilID"].Value = model.TehsilID;

                sqlCmd.Parameters.Add(new SqlParameter("@UnionCouncilID", SqlDbType.Int));
                sqlCmd.Parameters["@UnionCouncilID"].Value = model.UnionCouncilID;

                sqlCmd.Parameters.Add(new SqlParameter("@CityID", SqlDbType.Int));
                sqlCmd.Parameters["@CityID"].Value = model.CityID;

                sqlCmd.Parameters.Add(new SqlParameter("@FingerImpression", SqlDbType.VarBinary));
                sqlCmd.Parameters["@FingerImpression"].Value = model.FingerImpression;

                sqlCmd.Parameters.Add(new SqlParameter("@FingerPrint", SqlDbType.VarChar));
                sqlCmd.Parameters["@FingerPrint"].Value = model.FignerPrint;

                sqlCmd.Parameters.Add(new SqlParameter("@LocationCode", SqlDbType.VarChar));
                sqlCmd.Parameters["@LocationCode"].Value = model.LocationCode;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Get nic record against cnic
        /// </summary>
        /// <param name="cnic"></param>
        /// <param name="districtCode"></param>
        /// <returns></returns>
        public DataTable GetNICNadraRecord(string cnic, string districtCode)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;

            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetNadraCNICRecord", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CNIC", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@CNIC"].Value = cnic;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictCode", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@DistrictCode"].Value = districtCode;

                    sqlDadp.Fill(dt);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

            return dt;
        }

        /// <summary>
        /// Get all nic records
        /// </summary>
        /// <returns></returns>
        public DataTable GetNICNadraRecord()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;

            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllNadraCNICRecord", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open) 
                    con.Close();
            }

            return dt;
        }

        /// <summary>
        /// Get nic record against provided cnic
        /// </summary>
        /// <param name="CNIC"></param>
        /// <returns></returns>
        public DataTable GetNICNadraRecord(string CNIC)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;

            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCNICRecordByCNIC", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CNIC", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@CNIC"].Value = CNIC;

                    sqlDadp.Fill(dt);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                    con.Close();
            }

            return dt;
        }
    }
}
