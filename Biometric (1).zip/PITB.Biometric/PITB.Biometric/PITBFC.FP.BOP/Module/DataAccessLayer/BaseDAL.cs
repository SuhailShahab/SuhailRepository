﻿using PITBFC.FP.ApplicationClass;
using System.Configuration;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <04-03-2015 06:14:55PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Module.DataAccessLayer
{
    public class BaseDAL
    {
        private string _ConnectionString;

        protected string spConnectionString
        {
            get { return _ConnectionString; }
        }

        public BaseDAL()
        {

            this._ConnectionString = string.IsNullOrEmpty(CustomConfigReader.DBConnectionString) ? GlobalInfo.LocationConnectionString : CustomConfigReader.DBConnectionString;//ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString.ToString();
            //this._ConnectionString = @"Data Source=10.52.99.96\DEVSQL;Initial Catalog=PITBFC;Persist Security Info=True;User ID=sa;Password=allah@15;Connect Timeout=20;";
           // this._ConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString.ToString();
        }
    }
}
