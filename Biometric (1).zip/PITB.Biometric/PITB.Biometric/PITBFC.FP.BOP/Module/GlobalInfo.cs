﻿using PITBFC.FP.Module.DataModelLayer;
using System.Collections.Generic;
using System;
//using PITBFC.FP.BOP.PITBFacilitationCentreService;
using PITBFC.FP.BOP.PITBFCSecurityEnrollment;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <16-03-2015 04:18:24PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Module
{
    public static class GlobalInfo
    {
        
        public static void SetAppSetting(UserModel value)
        {
            if (value != null)
           {
               LocationID = value.FCLocationID;
               LocationCode = value.LocationCode;
               LocationName=  value.LocationName;
               DistrictCode = value.DistrictCode;
               AreaName = value.LocationName + "(" + value.LocationCode + ")";
               UserID = value.UserID;
               LocationConnectionString = value.LocationConnectionString;
               EmployeeName = value.EmployeeName;
               IsBOPVerification = value.IsBOPVerification;
            }
        }
        public static List<NICRecordModel> records {get; set;}
        public static int? UserID { get; set; }
        public static int? DepartmentID { get; set; }
        public static int? DistrictID { get; set; }
        public static string UserName { get; set; }
        public static string EmployeeName { get; set; }
        public static string DistrictCode { get; set; }
        public static string AreaName { get; set; }
        public static string LocationCode { get; set; }
        public static string LocationName { get; set; }
        public static int? LocationID { get; set; }
        public static string LocationConnectionString { get; set; }
        public static bool? IsBOPVerification { get; set; }



    }
}
