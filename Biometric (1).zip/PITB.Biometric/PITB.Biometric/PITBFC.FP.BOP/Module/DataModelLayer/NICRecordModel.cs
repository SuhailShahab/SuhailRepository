﻿using System;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <05-03-2015 11:05:31AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Module.DataModelLayer
{
    public class NICRecordModel
    {
        public string ApplicantID { get; set; }
        public string CNIC { get; set; }
        public string Name { get; set; }
        public string NameUrdu { get; set; }
        public string FatherName { get; set; }
        public string FatherNameUrdu { get; set; }
        public string ContactNo { get; set; }
        public int GenderID { get; set; }
        public DateTime? DOB { get; set; }
        public DateTime? IssueDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public string HouseNo { get; set; }
        public string StreetNo { get; set; }
        public string BlockNo { get; set; }
        public string Neighbourhood { get; set; }
        public string NeighbourhoodUrdu { get; set; }
        public string AdditionalInformation { get; set; }
        public string AdditionalInformationUrdu { get; set; }
        public string PermanentAddress { get; set; }
        public string PermanentAddressUrdu { get; set; }
        public string CurrentAddress { get; set; }
        public string CurrentAddressUrdu { get; set; }
        public int CityID { get; set; }
        public int DivisionID { get; set; }
        public int DistrictID { get; set; }
        public int TehsilID { get; set; }
        public int UnionCouncilID { get; set; }
        public string LocationCode { get; set; }
        public byte[] FingerImpression { get; set; }
        public string FignerPrint { get; set; }
    }

    //public class CitizenEnrollment()
    //{
    //    public string CNIC {get; set;}
    //    public byte[] FingerImpression {get; set;}
    //    public string DistrictCode {get; set;}
    //    public string Notification {get; set;}
    //}
}
