﻿using PITBFC.FP.Module.DataModelLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <05-03-2015 11:05:31AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.BOP.Module.DataModelLayer
{
    public class NICFmdModel : NICRecordModel
    {

    }
}
