﻿using System;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <04-03-2015 05:59:55PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Module.DataModelLayer
{
    public class LocationModel
    {
        public int ID { get; set; }
        public string Code { get; set; }
        public string Title { get; set; }
        public int DistrictID { get; set; }
        public string DistrictCode { get; set; }

        public LocationModel()
        { 
        }

        public LocationModel(string Code, string Title)
        {
            this.Code = Code;
            this.Title = Title;
        }
    }
}
