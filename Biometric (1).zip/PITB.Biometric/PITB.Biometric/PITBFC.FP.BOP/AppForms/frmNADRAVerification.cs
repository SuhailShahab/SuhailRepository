﻿using PITBFC.FP.ApplicationClass;
using PITBFC.FP.Module;
using PITBFC.FP.Module.BusinessLoginLayer;
using PITBFC.FP.Module.DataModelLayer;
using PITBFC.FP.BOP.PITBFacilitationCentreService;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using DPUruNet;
using System.Drawing.Imaging;
using PITBFC.FP.BOP.Properties;
using System.Linq;
using System.ComponentModel;
using SMS.CMPScheduler.ApplicationClassess.Log;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <27-02-2018 03:27:04PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Forms
{
    public partial class frmNADRAVerification : Form//, DPFP.Capture.EventHandler
    {
        #region "Variable"

      //  private DPFP.Capture.Capture Capturer;
     //   private DPFP.Verification.Verification verifier;

        /// <summary>
        /// Contain session information against new cnic request
        /// </summary>
        private string SessionID { get; set; }
        private string TransactionID {get; set;}

        /// <summary>
        /// Holds the main form with many functions common to all of SDK actions.
        /// </summary>
        public frmMain _sender;

        #endregion

        #region "Constructor"

        public frmNADRAVerification()
        {
            InitializeComponent();
           
           
            //string area = CustomConfigReader.AreaName;//ConfigurationManager.AppSettings["AreaName"].ToString();

            //int? locationID = CustomConfigReader.LocationID; 
        }

        #endregion

        #region "SDK event"

        /// <summary>
        /// Handler for when a fingerprint is captured.
        /// </summary>
        /// <param name="captureResult">contains info and data on the fingerprint capture</param>
        public void OnCaptured(CaptureResult captureResult)
        {
            try
            {
                bool isValidate = true;
                this.Invoke(new Function(delegate()
                {
                    isValidate = ValidatControl();
                
                if (isValidate)
                {
                    //Make text Field disabled until clear pressed
                    txtCNIC.Enabled = false;
                    // Check capture quality and throw an error if bad.
                    if (!_sender.CheckCaptureResult(captureResult)) return;

                    // Create bitmap
                    foreach (Fid.Fiv fiv in captureResult.Data.Views)
                    {
                       // SendMessage(Action.SendBitmap, _sender.CreateBitmap(fiv.RawImage, fiv.Width, fiv.Height));
                        SendMessage(Action.SendBitmap, this.CreateBitmap(fiv.RawImage, fiv.Width, fiv.Height));
                    }

                    DataResult<Fmd> fmdResult = FeatureExtraction.CreateFmdFromFid(captureResult.Data, Constants.Formats.Fmd.ANSI);
                    Fmd fmdData = fmdResult.Data;
                    string Base64FingerResult = Convert.ToBase64String(fmdData.Bytes);
                
                
                    Cursor.Current = Cursors.WaitCursor;
                    this.Enabled = false;

                    #region "Send Verification Request"

                    PITBFC.FP.BOP.PITBFacilitationCentreService.CitizenVerificationRequestModel cvr =
                    new PITBFC.FP.BOP.PITBFacilitationCentreService.CitizenVerificationRequestModel();

                    //Create request object for BOP Service

                    CreateRequestObject(Base64FingerResult, cvr);

                    //Create request object for BOP Service

                    if (SessionID != null && SessionID != "0")
                        cvr.TransactionID = this.TransactionID;
                    else
                    {
                        // generate Random Transaction ID 
                        GetTransactionID();
                        cvr.TransactionID = this.TransactionID;
                        // generate Random Transaction ID 
                    }


                    using (PITBFacilitationCentreServiceClient proxy = new PITBFacilitationCentreServiceClient())
                    {
                        PITBFC.FP.BOP.PITBFacilitationCentreService.CitizenVerificationResponseModel response = proxy.VerificationBVS(cvr);
                        if (response != null)
                        {
                            //Set Value of control with response object of BOP
                            lblName.Text = response.Name;
                            lblPresentAddress.Text = response.PresentAddress;
                            lblBirthPlace.Text = response.BirthPlace;
                            lblDOB.Text = response.DateOfBirth.HasValue ? response.DateOfBirth.Value.ToString("dd-MMM-yyyy") : "";
                            lblCardExpiry.Text = response.ExpiryDate.HasValue ? response.ExpiryDate.Value.ToString("dd-MMM-yyyy") : "";


                            if (response.SessionID != null && response.SessionID != "0")
                            this.SessionID = response.SessionID;

                            if (response.Code == BOPErrors.SessionExpired.GetHashCode().ToString()) // 201: Session has been expired 
                            {
                                this.SessionID = null;
                            }
                            else if (response.Code == BOPErrors.Successfull.GetHashCode().ToString()) // 100: successfull
                            {
                                pnlFingerIndexs.Visible = false;
                                grpAvailableIndexes.Visible = false;
                                pnlCitizenInformation.Visible = true;
                            }
                            else if (response.Code == BOPErrors.InvalidFingerIndex.GetHashCode().ToString()) // 121: invalid finger index
                            {
                                
                                DisableFingers(response.AvailableFinderIndex);
                                cmbFingerIndex.SelectedIndex = 0;
                                this.pnlFingerIndexs.BackgroundImage = Resources.FullHand;
                                SetStatus(response.Message);

                            }
                            else if (response.Code == BOPErrors.LimitExhausted.GetHashCode().ToString()) // 119: Verification Limit has been exhausted
                            {
                               
                                this.cmbServices.Focus();
                                this.pnlFingerIndexs.BackgroundImage = Resources.FullHand;
                                SetStatus(response.Message);
                            }
                            else
                            {
                                
                                this.cmbServices.Focus();
                                this.pnlFingerIndexs.BackgroundImage = Resources.FullHand;
                                SetStatus(response.Message);
                            }
                            
                        }
                    }

                    #endregion

                    Cursor.Current = Cursors.Default;
                    this.Enabled = true;
                }
                }));

            }
            catch (Exception ex)
            {
                // Send error message, then close form
                SendMessage(Action.SendMessage, "Error:  " + ex.Message);
            }
        }

        private void CreateRequestObject(string Base64FingerResult, PITBFC.FP.BOP.PITBFacilitationCentreService.CitizenVerificationRequestModel cvr)
        {
            cvr.CitizenNumber = txtCNIC.Text;
            cvr.ContactNumber = txtMobileNo.Text;
            cvr.FingerIndex = Convert.ToInt32(cmbFingerIndex.SelectedValue);
            cvr.TemplateType = "ANSI";
            cvr.FingerTemplate = Base64FingerResult;
            cvr.AreaName = CustomConfigReader.AreaName;//ConfigurationManager.AppSettings["AreaName"].ToString();
            cvr.ServiceID = Convert.ToInt32(cmbServices.SelectedValue);
            cvr.LocationID = CustomConfigReader.LocationID; //Convert.ToInt32(ConfigurationManager.AppSettings["LocationID"].ToString());
            cvr.SessionID = this.SessionID;
            cvr.CreatedUserID = GlobalInfo.UserID;
        }

        private void GetTransactionID()
        {
            string dateformat = DateTime.Now.ToString("ddMMyyyyhhmmss");
            Random r = new Random();
            int n = r.Next(0, 9); // generate 1 digit 
            this.TransactionID = Convert.ToString(n) + dateformat;
        }

        private void DisableFingers(string availableFingers)
        {
            if (availableFingers != null)
            {
                //show panel group for available fingers
                grpAvailableIndexes.Visible = true;
                
                string[] fingerindex = new string[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
                string[] availableIndexes = availableFingers.Split(',');

                string[] disableIndexes = fingerindex.Except(availableIndexes).ToArray();

                for (int t = 0; t < disableIndexes.Length; t++)
                {
                    switch (Convert.ToInt32(disableIndexes[t]))
                    {
                        case 1:
                            pnlRightThumb.Enabled = false;
                            lblIndex1.BackColor = Color.Gray;
                            break;
                        case 2:
                            pnlRightIndex.Enabled = false;
                            lblIndex2.BackColor = Color.Gray;
                            break;
                        case 3:
                            pnlRightMiddle.Enabled =false;
                            lblIndex3.BackColor = Color.Gray;
                            break;
                        case 4:
                            pnlRightRing.Enabled = false;
                            lblIndex4.BackColor = Color.Gray;
                            break;
                        case 5:
                            pnlRightLittle.Enabled = false;
                            lblIndex5.BackColor = Color.Gray;
                            break;
                        case 6:
                            pnlLeftThumb.Enabled = false;
                            lblIndex6.BackColor = Color.Gray;
                            break;
                        case 7:
                            pnlLeftIndex.Enabled = false;
                            lblIndex7.BackColor = Color.Gray;
                            break;
                        case 8:
                            pnlLeftMiddle.Enabled = false;
                            lblIndex8.BackColor = Color.Gray;
                            break;
                        case 9:
                            pnlLeftRing.Enabled = false;
                            lblIndex9.BackColor = Color.Gray;
                            break;
                        case 10:
                            pnlLeftLittle.Enabled = false;
                            lblIndex10.BackColor = Color.Gray;
                            break;
                        
                    }
                } 
            }

           
            
        }

        private delegate void SendMessageCallback(Action action, object payload);
        private void SendMessage(Action action, object payload)
        {
            try
            {
                if (this.pbFingerprint.InvokeRequired)
                {
                    SendMessageCallback d = new SendMessageCallback(SendMessage);
                    this.Invoke(d, new object[] { action, payload });
                }
                else
                {
                    switch (action)
                    {
                        case Action.SendMessage:
                            MessageBox.Show((string)payload);
                            break;
                        case Action.SendBitmap:
                            pbFingerprint.Image = (Bitmap)payload;
                            pbFingerprint.Refresh();
                            break;
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        public Bitmap CreateBitmap(byte[] bytes, int width, int height)
        {
            byte[] rgbBytes = new byte[bytes.Length * 3];

            for (int i = 0; i <= bytes.Length - 1; i++)
            {
                rgbBytes[(i * 3)] = bytes[i];
                rgbBytes[(i * 3) + 1] = bytes[i];
                rgbBytes[(i * 3) + 2] = bytes[i];
            }
            Bitmap bmp = new Bitmap(width, height, PixelFormat.Format24bppRgb);

            BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);

            for (int i = 0; i <= bmp.Height - 1; i++)
            {
                IntPtr p = new IntPtr(data.Scan0.ToInt64() + data.Stride * i);
                System.Runtime.InteropServices.Marshal.Copy(rgbBytes, i * bmp.Width * 3, p, bmp.Width * 3);
            }

            bmp.UnlockBits(data);

            return bmp;
        }
        private enum Action
        {
            SendBitmap,
            SendMessage
        }


        private enum BOPErrors 
        {
            SessionExpired = 201,
            Successfull = 100,
            InvalidFingerIndex = 121,
            LimitExhausted = 119
        }
        #endregion 

        /*
        #region "DPFP Interface Methods"

        public void OnComplete(object Capture, string ReaderSerialNumber, DPFP.Sample Sample)
        {
            Process(Sample);
        }

        public void OnFingerGone(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnFingerTouch(object Capture, string ReaderSerialNumber)
        {
            SetControlValue(null);
        }

        public void OnReaderConnect(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnReaderDisconnect(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnSampleQuality(object Capture, string ReaderSerialNumber, DPFP.Capture.CaptureFeedback CaptureFeedback)
        {
            //throw new NotImplementedException();
        }

        #endregion
        */
        /*
        #region "DPFP Related Methods"

        protected void Init()
        {
            try
            {
                Capturer = new DPFP.Capture.Capture();				// Create a capture operation.


                if (null != Capturer)
                {
                    Capturer.EventHandler = this;					    // Subscribe for capturing events.
                    verifier = new DPFP.Verification.Verification();	// Create a verifier.
                }
                else
                    SetPrompt("Can't initiate capture operation!");
            }
            catch
            {
                MessageBox.Show("Can't initiate capture operation!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected void Start()
        {
            if (null != Capturer)
            {
                try
                {
                    Capturer.StartCapture();
                    //SetPrompt("Using the fingerprint reader, scan your fingerprint.");
                }
                catch
                {
                    SetPrompt("Can't initiate capture!");
                }
            }
        }

        protected void Stop()
        {
            if (null != Capturer)
            {
                try
                {
                    Capturer.StopCapture();
                    
                }
                catch
                {
                    SetPrompt("Can't terminate capture!");
                }
                //finally
                //{
                //    Environment.Exit(0);
                //}
            }
        }

        protected void Process(DPFP.Sample Sample)
        {
            try
            {
                // Draw fingerprint sample image.
                DrawPicture(ConvertFPImageToBitmap(Sample));

                // Process the sample and create a feature set for the enrollment purpose.
                DPFP.FeatureSet features = ExtractFeatures(Sample, DPFP.Processing.DataPurpose.Verification);

                // if sample quality is not good then feature is null
                if (features == null)
                {
                    MessageBox.Show("Figure templete quality is not good. Kindly clean your finger and try again.", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SetPrompt("Figure templete quality is not good. Kindly clean your finger and try again.");
                }
                else
                {
                    bool isValidate = true;
                    //byte[] template = Sample.Bytes;

                    byte[] template = null;

                    DPFP.Capture.SampleConversion conversion = new DPFP.Capture.SampleConversion();
                    conversion.ConvertToANSI381(Sample, ref template);

                    this.Invoke(new Function(delegate()
                    {
                        isValidate = ValidatControl();
                        if (isValidate)
                        {
                            Cursor.Current = Cursors.WaitCursor;
                            this.Enabled = false;

                            #region "Send Verification Request"

                            PITBFC.FP.PITBFacilitationCentreService.CitizenVerificationRequestModel cvr =
                            new PITBFC.FP.PITBFacilitationCentreService.CitizenVerificationRequestModel();

                            cvr.CitizenNumber = txtCNIC.Text;
                            cvr.ContactNumber = txtMobileNo.Text;
                            cvr.FingerIndex = Convert.ToInt32(cmbFingerIndex.SelectedValue);
                            cvr.TemplateType = "ANSI";
                            cvr.FingerTemplate = Convert.ToBase64String(template);
                            cvr.AreaName = CustomConfigReader.AreaName;//ConfigurationManager.AppSettings["AreaName"].ToString();
                            cvr.ServiceID = Convert.ToInt32(cmbServices.SelectedValue);
                            cvr.LocationID = CustomConfigReader.LocationID; //Convert.ToInt32(ConfigurationManager.AppSettings["LocationID"].ToString());
                            cvr.SessionID = SessionID;

                            using (PITBFacilitationCentreServiceClient proxy = new PITBFacilitationCentreServiceClient())
                            {
                                PITBFC.FP.PITBFacilitationCentreService.CitizenVerificationResponseModel response = proxy.VerificationBVS(cvr);
                                if (response != null)
                                {
                                    lblName.Text = response.Name;
                                    lblPresentAddress.Text = response.PresentAddress;
                                    lblBirthPlace.Text = response.BirthPlace;
                                    lblDOB.Text = response.DateOfBirth.HasValue ? response.DateOfBirth.Value.ToString("dd-MMM-yyyy") : "";
                                    lblCardExpiry.Text = response.ExpiryDate.HasValue ? response.ExpiryDate.Value.ToString("dd-MMM-yyyy") : "";
                                    SessionID = response.SessionID;

                                    pnlFingerIndexs.Visible = false;
                                    pnlCitizenInformation.Visible = true;
                                }
                            }

                            #endregion

                            Cursor.Current = Cursors.Default;
                            this.Enabled = true;
                        }
                    }));
                }
            }
            catch (DPFP.Error.SDKException e)
            {
                MessageBox.Show(e.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
                this.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
                this.Enabled = true;
            }
        }

        #endregion
        */

        #region "Method"
        /*
        protected Bitmap ConvertFPImageToBitmap(DPFP.Sample Sample)
        {
            DPFP.Capture.SampleConversion Convertor = new DPFP.Capture.SampleConversion();	// Create a sample convertor.
            Bitmap bitmap = null;												            // TODO: the size doesn't matter
            Convertor.ConvertToPicture(Sample, ref bitmap);									// TODO: return bitmap as a result
            return bitmap;
        }
        */
        protected void SetStatus(string status)
        {
            this.Invoke(new Function(delegate()
            {
                lblStatus.ForeColor = Color.Red;
                lblStatus.Text = status;
            }));
        }

        //protected void SetPrompt(string prompt)
        //{
        //    this.Invoke(new Function(delegate()
        //    {
        //        txtPrompt.Text = prompt;
        //    }));
        //}

        //private void DrawPicture(Bitmap bitmap)
        //{
        //    this.Invoke(new Function(delegate()
        //    {
        //        pbFingerprint.Image = new Bitmap(bitmap, pbFingerprint.Size);	// fit the image into the picture box
        //    }));
        //}
        /*
        protected DPFP.FeatureSet ExtractFeatures(DPFP.Sample Sample, DPFP.Processing.DataPurpose Purpose)
        {
            DPFP.Processing.FeatureExtraction Extractor = new DPFP.Processing.FeatureExtraction();	// Create a feature extractor
            DPFP.Capture.CaptureFeedback feedback = DPFP.Capture.CaptureFeedback.None;
            DPFP.FeatureSet features = new DPFP.FeatureSet();
            Extractor.CreateFeatureSet(Sample, Purpose, ref feedback, ref features);			// TODO: return features as a result?
            if (feedback == DPFP.Capture.CaptureFeedback.Good)
                return features;
            else
                return null;
        }
        */
        
        //protected void SetControlValue(NICRecordModel vrm)
        //{
        //    this.Invoke(new Function(delegate()
        //    {
        //        if (vrm != null)
        //        {
        //            /*txtCNIC.Text = vrm.CNIC;
        //            txtMobileNo.Text = 
        //            lblName.Text = vrm.Name;
                    
        //            lblNameFather.Text = vrm.FatherName;
        //            lblContactNo.Text = vrm.ContactNo;
        //            lblPresentAddress.Text = vrm.PermanentAddress;
        //            lblCurrentAddress.Text = vrm.CurrentAddressUrdu;*/
        //        }
        //        else
        //        {
        //            //txtCNIC.Text = "";
        //            //txtMobileNo.Text = "";
        //            lblName.Text = "";
        //            lblPresentAddress.Text = "";
        //            lblBirthPlace.Text = "";
        //            lblDOB.Text = "";
        //            lblCardExpiry.Text = "";
        //        }
        //    }));
        //}

        private void ResetControls()
        {
            txtCNIC.ResetText();
            txtCNIC.Enabled = true;
            txtMobileNo.ResetText();
            lblName.ResetText();
            lblPresentAddress.ResetText();
            lblBirthPlace.ResetText();
            lblDOB.ResetText();
            lblCardExpiry.ResetText();
            cmbFingerIndex.SelectedIndex = (cmbFingerIndex.Items != null && cmbFingerIndex.Items.Count>0)?0:-1;
            cmbServices.SelectedIndex = 0;
            SessionID = null;
            TransactionID = null;
            pbFingerprint.Image = null;
            pbFingerprint.Refresh();

            pnlCitizenInformation.Visible = false;
            pnlFingerIndexs.Visible = true;
            pnlFingerIndexs.BackgroundImage = Resources.FullHand;

            lblStatus.ResetText();

            //Enable all Finger panels
            pnlRightThumb.Enabled = true;
            pnlRightIndex.Enabled = true;
            pnlRightMiddle.Enabled = true;
            pnlRightRing.Enabled = true;
            pnlRightLittle.Enabled = true;
            pnlLeftThumb.Enabled = true;
            pnlLeftIndex.Enabled = true;
            pnlLeftMiddle.Enabled = true;
            pnlLeftRing.Enabled = true;
            pnlLeftLittle.Enabled = true;
            
            // re-set available indexes colour to green & hide panel
            grpAvailableIndexes.Visible = false;
            lblIndex1.BackColor = Color.Green;
            lblIndex2.BackColor = Color.Green;
            lblIndex3.BackColor = Color.Green;
            lblIndex4.BackColor = Color.Green;
            lblIndex5.BackColor = Color.Green;
            lblIndex6.BackColor = Color.Green;
            lblIndex7.BackColor = Color.Green;
            lblIndex8.BackColor = Color.Green;
            lblIndex9.BackColor = Color.Green;
            lblIndex10.BackColor = Color.Green;
            
            txtPrompt.Text = "Fingerprint reader is ready, scan your finger";
        }
        
        private void GetFingerIndexs()
        {
            using (PITBFacilitationCentreServiceClient proxy = new PITBFacilitationCentreServiceClient())
            {
                PITBFC.FP.BOP.PITBFacilitationCentreService.FingerIndexModel[] fingerIndex = proxy.GetFingerTypes();
                if (fingerIndex.Length != 0)
                {
                    PITBFC.FP.BOP.PITBFacilitationCentreService.FingerIndexModel zeroIndex = new PITBFC.FP.BOP.PITBFacilitationCentreService.FingerIndexModel();
                    zeroIndex.FingerIndex = 0;
                    zeroIndex.Description = "-- Select --";

                    // convert array collection to list collection
                    List<PITBFC.FP.BOP.PITBFacilitationCentreService.FingerIndexModel> lstfingerIndexs = new List<PITBFC.FP.BOP.PITBFacilitationCentreService.FingerIndexModel>(fingerIndex);
                    lstfingerIndexs.Insert(0, zeroIndex);

                    cmbFingerIndex.DataSource = lstfingerIndexs;
                    cmbFingerIndex.ValueMember = "FingerIndex";
                    cmbFingerIndex.DisplayMember = "Description";
                }
                else
                {
                    PITBFC.FP.BOP.PITBFacilitationCentreService.FingerIndexModel zeroIndex = new PITBFC.FP.BOP.PITBFacilitationCentreService.FingerIndexModel();
                    zeroIndex.FingerIndex = 0;
                    zeroIndex.Description = "-- Select --";

                    List<PITBFC.FP.BOP.PITBFacilitationCentreService.FingerIndexModel> lstfingerIndexs = new List<PITBFC.FP.BOP.PITBFacilitationCentreService.FingerIndexModel>(fingerIndex);
                    lstfingerIndexs.Add(zeroIndex);

                    cmbFingerIndex.DataSource = lstfingerIndexs;
                    cmbFingerIndex.ValueMember = "FingerIndex";
                    cmbFingerIndex.DisplayMember = "Description";
                }
            }
        }
        
        private void GetServices()
        {
            using (PITBFacilitationCentreServiceClient proxy = new PITBFacilitationCentreServiceClient())
            {
                PITBFC.FP.BOP.PITBFacilitationCentreService.Services[] Servics = proxy.GetPSPAServices(Convert.ToString(GlobalInfo.UserID));
                if (Servics.Length != 0)
                {
                    PITBFC.FP.BOP.PITBFacilitationCentreService.Services zeroIndex = new PITBFC.FP.BOP.PITBFacilitationCentreService.Services();
                    zeroIndex.ServiceID = 0;
                    zeroIndex.Title = "-- Select --";

                    // convert array collection to list collection
                    List<PITBFC.FP.BOP.PITBFacilitationCentreService.Services> lstServies = new List<PITBFC.FP.BOP.PITBFacilitationCentreService.Services>(Servics);
                    lstServies.Insert(0, zeroIndex);

                    cmbServices.DataSource = lstServies;
                    cmbServices.ValueMember = "ServiceID";
                    cmbServices.DisplayMember = "Title";
                }
                else
                {
                    PITBFC.FP.BOP.PITBFacilitationCentreService.Services zeroIndex = new PITBFC.FP.BOP.PITBFacilitationCentreService.Services();
                    zeroIndex.ServiceID = 0;
                    zeroIndex.Title = "-- Select --";

                    // convert array collection to list collection
                    List<PITBFC.FP.BOP.PITBFacilitationCentreService.Services> lstServies = new List<PITBFC.FP.BOP.PITBFacilitationCentreService.Services>(Servics);
                    lstServies.Add(zeroIndex);

                    cmbServices.DataSource = lstServies;
                    cmbServices.ValueMember = "ServiceID";
                    cmbServices.DisplayMember = "Title";
                }
            }
        }
       
        protected bool ValidatControl()
        {
            try
            {

                if (cmbServices.SelectedIndex == 0)
                {
                    MessageBox.Show("Please select service.", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SetStatus("Please select service.");
                    cmbServices.Focus();
                    return false;
                }
                else if (txtCNIC.TextLength == 0)
                {
                    MessageBox.Show("Please enter citizen CNIC #.", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SetStatus("Please enter citizen CNIC #");
                    txtCNIC.Focus();
                    return false;
                }
                else if (txtCNIC.TextLength < 13)
                {
                    MessageBox.Show("Invalid CNIC #. Please enter a 13 digit CNIC #.", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SetStatus("Invalid CNIC #. Please enter a 13 digit CNIC #.");
                    txtCNIC.Focus();
                    return false;
                }
                else if (txtMobileNo.TextLength == 0)
                {
                    MessageBox.Show("Please enter citizen contact number.", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SetStatus("Please enter citizen contact number.");
                    txtMobileNo.Focus();
                    return false;
                }
                else if (txtMobileNo.TextLength < txtMobileNo.MaxLength)
                {
                    MessageBox.Show("Please enter a valid contact number.", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SetStatus("Please enter a valid contact number.");
                    txtMobileNo.Focus();
                    return false;
                }
                else if (cmbFingerIndex.SelectedIndex == 0)
                {
                    MessageBox.Show("Please select finger before scan.", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    SetStatus("Please select finger before scan.");
                    return false;
                }
            }
            catch(Exception)
            {
                throw;
            }

            return true;
        }
        
        #endregion

        #region "Form Events"

        private void frmNADRAVerification_Load(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                this.Enabled = false;

               // Init();
              //  Start();

                GetFingerIndexs();
                GetServices();
                ResetControls();

                pnlFingerIndexs.BackgroundImage = Resources.FullHand;

                Cursor.Current = Cursors.Default;
                this.Enabled = true;

                //=============SDK=====================
                // Reset variables
                pbFingerprint.Image = null;

                if (!_sender.OpenReader())
                {
                    
                    this.Close();
                }

                if (!_sender.StartCaptureAsync(this.OnCaptured))
                {
                    this.Close();
                }
                //=====================================
                
            }
            catch (Exception ex)
            {
                Cursor.Current = Cursors.Default;
                this.Enabled = true;
                MessageBox.Show("There is something wrong with device. Please contact with administrator", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                B2BayLogger.LogErr(ex);
            }
        }

        private void frmNADRAVerification_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //_sender.RefreshDevice();
                _sender.CancelCaptureAndCloseReader(this.OnCaptured);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region "TextBox Events"

        private void txtCNIC_KeyDown(object sender, KeyEventArgs e)
        {
            if (!(e.KeyCode == Keys.Back || (e.KeyValue >= 48 && e.KeyValue <= 57) || (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)))
            {
                e.SuppressKeyPress = true;
            }
        }

        private void txtCNIC_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (txtCNIC.TextLength == 0)
            {
                e.Cancel = true;
                SetStatus("Please enter citizen CNIC #");
                lblStatus.ForeColor = Color.Red;
            }
            else if (txtCNIC.TextLength < 13)
            {
                e.Cancel = true;
                SetStatus("Invalid CNIC #.");
                lblStatus.ForeColor = Color.Red;
            }
        }

        private void txtCNIC_Validated(object sender, EventArgs e)
        {
            SetStatus("");
            lblStatus.ForeColor = Color.Black;
        }

        private void txtMobileNo_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (txtMobileNo.TextLength == 0)
            {
                //e.Cancel = true;
                SetStatus("Please enter citizen contact number");
                lblStatus.ForeColor = Color.Red;
            }
            else if (txtMobileNo.TextLength < txtMobileNo.MaxLength)
            {
                //e.Cancel = true;
                SetStatus("Invalid contact number");
                lblStatus.ForeColor = Color.Red;
            }
        }

        #endregion

        #region "Button Click Events"

        private void btnRightThumb_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 1;
        }

        private void btnRightIndex_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 2;
        }

        private void btnRightMiddle_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 3;
        }

        private void btnRightRing_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 4;
        }

        private void btnRightLittle_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 5;
        }

        private void btnLeftThumb_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 6;
        }

        private void btnLeftIndex_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 7;
        }

        private void btnLeftMiddle_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 8;
        }

        private void btnLeftRing_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 9;
        }

        private void btnLeftLittle_Click(object sender, EventArgs e)
        {
            cmbFingerIndex.SelectedValue = 10;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ResetControls();
        }

        #endregion

        #region "ComboBox Events"

        private void cmbFingerIndex_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (cmbFingerIndex.SelectedIndex != 0)
            {
                SetStatus("You have selected " + cmbFingerIndex.Text);
                lblStatus.ForeColor = Color.Green;

                switch (Convert.ToInt32(cmbFingerIndex.SelectedValue))
                {
                    case 1:
                        pnlFingerIndexs.BackgroundImage = Resources.RightThumbGreen;
                        break;
                    case 2:
                        pnlFingerIndexs.BackgroundImage = Resources.RightIndexGreen;
                        break;
                    case 3:
                        pnlFingerIndexs.BackgroundImage = Resources.RightMiddleGreen;
                        break;
                    case 4:
                        pnlFingerIndexs.BackgroundImage = Resources.RightRingGreen;
                        break;
                    case 5:
                        pnlFingerIndexs.BackgroundImage = Resources.RightSmallGreen;
                        break;
                    case 6:
                        pnlFingerIndexs.BackgroundImage = Resources.Left_ThumbGreen;
                        break;
                    case 7:
                        pnlFingerIndexs.BackgroundImage = Resources.Left_IndexGreen;
                        break;
                    case 8:
                        pnlFingerIndexs.BackgroundImage = Resources.Left_MiddleGreen;
                        break;
                    case 9:
                        pnlFingerIndexs.BackgroundImage = Resources.LeftRingGreen;
                        break;
                    case 10:
                        pnlFingerIndexs.BackgroundImage = Resources.Left_SmallGreen;
                        break;
                    default:
                        pnlFingerIndexs.BackgroundImage = Resources.FullHand;
                        break;
                }
            }
            else
            {
                SetStatus("");
                lblStatus.ForeColor = Color.Black;
            }
             
        }

        #endregion

        #region "Panel Mouse Hover & Leave Events"

        private void pnlLeftThumb_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.Left_ThumbGreen;
        }

        private void pnlLeftThumb_MouseLeave(object sender, EventArgs e)
        {
            
            if (cmbFingerIndex.SelectedIndex == 0)
                pnlFingerIndexs.BackgroundImage = Resources.FullHand;
            else
            {
                switch (Convert.ToInt32(cmbFingerIndex.SelectedValue))
                {
                    case 1:
                        pnlFingerIndexs.BackgroundImage = Resources.RightThumbGreen;
                        break;
                    case 2:
                        pnlFingerIndexs.BackgroundImage = Resources.RightIndexGreen;
                        break;
                    case 3:
                        pnlFingerIndexs.BackgroundImage = Resources.RightMiddleGreen;
                        break;
                    case 4:
                        pnlFingerIndexs.BackgroundImage = Resources.RightRingGreen;
                        break;
                    case 5:
                        pnlFingerIndexs.BackgroundImage = Resources.RightSmallGreen;
                        break;
                    case 6:
                        pnlFingerIndexs.BackgroundImage = Resources.Left_ThumbGreen;
                        break;
                    case 7:
                        pnlFingerIndexs.BackgroundImage = Resources.Left_IndexGreen;
                        break;
                    case 8:
                        pnlFingerIndexs.BackgroundImage = Resources.Left_MiddleGreen;
                        break;
                    case 9:
                        pnlFingerIndexs.BackgroundImage = Resources.LeftRingGreen;
                        break;
                    case 10:
                        pnlFingerIndexs.BackgroundImage = Resources.Left_SmallGreen;
                        break;
                    default:
                        pnlFingerIndexs.BackgroundImage = Resources.FullHand;
                        break;
                }
            
            } 
        }

        private void pnlLeftIndex_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.Left_IndexGreen;
        }

        private void pnlLeftMiddle_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.Left_MiddleGreen;
        }

        private void pnlLeftRing_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.LeftRingGreen;
        }

        private void pnlLeftLittle_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.Left_SmallGreen;
        }

        private void pnlRightThumb_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.RightThumbGreen;
        }

        private void pnlRightIndex_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.RightIndexGreen;
        }

        private void pnlRightMiddle_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.RightMiddleGreen;
        }

        private void pnlRightRing_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.RightRingGreen;
        }

        private void pnlRightLittle_MouseHover(object sender, EventArgs e)
        {
            pnlFingerIndexs.BackgroundImage = Resources.RightSmallGreen;
        }

        #endregion

        private void pnlLeftThumb_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
