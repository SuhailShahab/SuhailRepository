﻿using PITBFC.FP.ApplicationClass;
//using PITBFC.FP.BOP.PITBFacilitationCentreService;
using PITBFC.FP.Module;
using SMS.CMPScheduler.ApplicationClassess.Log;
using System;
using System.Configuration;
//using System.DirectoryServices.AccountManagement;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using PITBFC.FP.BOP.PITBFCSecurityEnrollment;
// =================================================================================================================================
// Create by:	<Mudassir Iqbal>
// Create date: <07-03-2018 01:17:23PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Forms
{
    public partial class frmLogin : Form
    {
        public frmMain main = null;

        #region "Constructors"

        public frmLogin()
        {
            InitializeComponent();
            InitializeForm();
        }

        public frmLogin(frmMain frmMain)
        {
            Thread t = new Thread( new ThreadStart(StartupSplash));
            t.Start();
            Thread.Sleep(5000);
            InitializeComponent();
            InitializeForm();
            this.main = frmMain;
            this.Text = "e-Khidmat Maraakaz - Login (Version 0018)";
            t.Abort();
        }

        #endregion

        #region "Button Click Events"

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnVerification_Click(object sender, EventArgs e)
        {
            if (txtLoginName.Text != "" && txtPassword.Text != "")
            {
                #region "Send Verification Request"

                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    this.Enabled = false;

                    PITBFC.FP.BOP.PITBFCSecurityEnrollment.UserLoginModel userLogin =
                    new PITBFC.FP.BOP.PITBFCSecurityEnrollment.UserLoginModel();

                    userLogin.UserName = txtLoginName.Text;
                    userLogin.Password = txtPassword.Text;

                    B2BayLogger.Log(" ============Start-Calling WCF Service for verfication========================");
                    using (PITBFacilitationCentreServiceClient proxy = new PITBFacilitationCentreServiceClient())
                    {
                        PITBFC.FP.BOP.PITBFCSecurityEnrollment.UserModel responseUser = proxy.GetUserInfoByVerfication(userLogin);
                        if (responseUser != null)
                        {
                            //Globel Setting
                            //====================================================================
                            B2BayLogger.Log(" ============Globel Setting========================");
                            GlobalInfo.SetAppSetting(responseUser);
                            //====================================================================
                            //Application level Setting
                            //====================================================================
                            B2BayLogger.Log(" ============Application level Setting=============");
                            CustomConfigWriter.WriteAppSetting(responseUser);
                            //====================================================================
                            B2BayLogger.Log(" ============Set Database connection setting=======");
                            //Set Database connection setting
                            CustomConfigWriter.SetConnectionSetting(responseUser);                           
                            //===================================================================                  
                            //Calling of Main Form
                            //===================================================================
                            B2BayLogger.Log(" ============Show Main Form========================");
                            this.main.Show();
                            this.Close();
                            B2BayLogger.Log(" ============Login successfully====================");
                            //===================================================================
                        }
                        else
                        {
                            lblMessage.Text = "Not a valid Login Name or Password. Please try again.";
                        }
                        B2BayLogger.Log(" ============End-Calling WCF Service for verfication========================");
                    }
                }
                catch (Exception ex)
                {

                    if (CustomConfigReader.IsShowGeneralMsg.Value)
                    {
                        lblMessage.Text = CustomConfigReader.GeneralMsg + CustomConfigReader.GetDateTimeStamp();
                        B2BayLogger.LogErr("Method Name:btnVerification_Click_1 " + CustomConfigReader.GetDateTimeStamp(), ex);
                    }
                    else
                    {
                        lblMessage.Text = "There is some connection problem with server. Please try again.";
                    }

                }
                finally
                {
                    B2BayLogger.WriteLogsToFile();
                }
                
                #endregion
            }
            else
            {
                lblMessage.Text = "Login Name or Password can not be empty.";
            }

            Cursor.Current = Cursors.Default;
            this.Enabled = true;
        }

        #endregion

        #region "Form Events"

        private void frmLogin_Load(object sender, EventArgs e)
        {
            this.Activate();
            this.Focus();
            this.btnClose.Focus();
            this.txtPassword.Focus();
            this.txtLoginName.Focus();
            this.ActiveControl = this.txtLoginName;
            this.txtLoginName.Select();
            

           
        }

        private void frmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
               
                if (!GlobalInfo.UserID.HasValue)
                {
                    
                    Environment.Exit(0);
                }

            }
            catch (Exception ex)
            {

            }

        }

        #endregion

        #region Custom Methods
        public void StartupSplash()
        {
            Application.Run(new SplashScreen());
        }
        public void InitializeForm()
        {
            this.lblMessage.Text = string.Empty;

            //-----------Make Panel in Center of the form------
            pnlLogin.Location = new Point(
            this.ClientSize.Width / 2 - pnlLogin.Size.Width / 2,
            this.ClientSize.Height / 2 - pnlLogin.Size.Height / 2);
            pnlLogin.Anchor = AnchorStyles.None;
            //-------------------------------------------------
            
        }
        #endregion 

    }
}
