﻿using System;
using System.Windows.Forms;
using PITBFC.FP.Module;
using PITBFC.FP.Module.BusinessLoginLayer;
using System.Configuration;
using PITBFC.FP.ApplicationClass;
using DPUruNet;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections.Generic;
using System.Threading;
using SMS.CMPScheduler.ApplicationClassess.Log;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <04-03-2015 03:17:23PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Forms
{
    delegate void Function();
    public partial class frmMain : Form
    {
        
        #region "Variables"

        private frmNADRAVerification bvs;
        private frmVerification verify;
        frmEnrollment enrollment;

        private Reader currentReader;
        private bool reset;

        #endregion

        #region "Properities"

        //// When set by child forms, shows s/n and enables buttons.
        public Reader CurrentReader
        {
            get { return currentReader; }
            set
            {
                currentReader = value;
                SendMessage(Action.UpdateReaderState, value);
            }
        }

        /// <summary>
        /// Reset the UI causing the user to reselect a reader.
        /// </summary>
        public bool Reset
        {
            get { return reset; }
            set { reset = value; }
        }

        #endregion

        #region "Constructors"

        public frmMain()
        {
            InitializeComponent();

            if (!GlobalInfo.UserID.HasValue)// && GlobalInfo.UserID.Value > 0
            {
               
                frmLogin login = new frmLogin(this);
                login.ShowDialog();//.ShowDialog();
                this.Hide();
            }
            
        }

        public frmMain(frmLogin loignfrm)
        {
            InitializeComponent();
            this.Show();
            loignfrm.Close();
        }

        #endregion

        #region custom methods

        private void ResetControl()
        {
            this.btnEnrollment.Enabled = this.btnVerification.Enabled = this.cboReaders.Items != null && this.cboReaders.Items.Count > 0 ? true : false;
            this.btnRefreshDevcie.Visible = !this.btnEnrollment.Enabled;
            //Check if user has rights to view BOP service
            this.btnNadraVerification.Enabled = (GlobalInfo.IsBOPVerification.Value && this.btnEnrollment.Enabled);
            
        }

        public void StartupSplash()
        {
            Application.Run(new SplashScreen("Finding device...."));
        }

        #endregion

        #region "Button Click Events"


        private void btnEnrollment_Click(object sender, EventArgs e)
        {
            try
            {
                B2BayLogger.Log("===================Enrolment Start====================");
                this.CurrentReader = _readers[this.cboReaders.SelectedIndex];
                if (enrollment == null && this.cboReaders.Items.Count > 0)
                {
                    enrollment = new frmEnrollment();
                    enrollment._sender = this;
                }

                if (enrollment != null)
                {
                    enrollment.ShowDialog();
                    enrollment.Dispose();
                    enrollment = null;
                }
                else
                {
                    MessageBox.Show("There is something wrong with device. Please contact with administrator", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.RefreshDevice();
                }

                B2BayLogger.Log("=================END Enrolment Start====================");
            }
            catch (Exception ex)
            {
                if (CustomConfigReader.IsShowGeneralMsg.Value)
                {
                    MessageBox.Show(CustomConfigReader.GeneralMsg + CustomConfigReader.GetDateTimeStamp(), "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    B2BayLogger.LogErr("Event Name:btnEnrollment_Click", ex);
                }
                else
                {
                    MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            finally
            {
                B2BayLogger.WriteLogsToFile();
            }


        }


        private void btnVerification_Click(object sender, EventArgs e)
        {
            B2BayLogger.Log("===================Verification Start====================");
            try
            {
                this.CurrentReader = _readers[this.cboReaders.SelectedIndex];
                if (verify == null && this.cboReaders.Items.Count > 0)
                {
                    verify = new frmVerification();
                    verify._sender = this;
                }

                if (verify != null)
                {
                    verify.ShowDialog();
                    verify.Dispose();
                    verify = null;
                }
                else
                {
                    MessageBox.Show("There is something wrong with device. Please contact with administrator", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.RefreshDevice();
                }

                B2BayLogger.Log("===================Verification END====================");
            }
            catch (Exception ex)
            {
                if (CustomConfigReader.IsShowGeneralMsg.Value)
                {
                    MessageBox.Show(CustomConfigReader.GeneralMsg + CustomConfigReader.GetDateTimeStamp(), "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    B2BayLogger.LogErr("Event Name:btnEnrollment_Click", ex);
                }
                else
                {
                    MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            finally
            {
                B2BayLogger.WriteLogsToFile();
            }
        }

        private void btnNadraVerification_Click(object sender, EventArgs e)
        {
            B2BayLogger.Log("===================BOP Verification Start====================");
            try
            {
                this.CurrentReader = _readers[this.cboReaders.SelectedIndex];
                if (bvs == null && this.cboReaders.Items.Count > 0)
                {
                    bvs = new frmNADRAVerification();
                    bvs._sender = this;

                }
                if (bvs != null)
                {
                    bvs.ShowDialog();
                    bvs.Dispose();
                    bvs = null;
                }
                else
                {
                    MessageBox.Show("There is something wrong with device. Please contact with administrator", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.RefreshDevice();
                }

                B2BayLogger.Log("===================BOP Verification END====================");
            }
            catch (Exception ex)
            {
                if (CustomConfigReader.IsShowGeneralMsg.Value)
                {
                    MessageBox.Show(CustomConfigReader.GeneralMsg + CustomConfigReader.GetDateTimeStamp(), "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    B2BayLogger.LogErr("Event Name:btnEnrollment_Click", ex);
                }
                else
                {
                    MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            finally
            {
                B2BayLogger.WriteLogsToFile();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRefreshDevcie_Click(object sender, EventArgs e)
        {
            B2BayLogger.Log("===================Refresh finding Devcie Start====================");
            Thread t = new Thread(new ThreadStart(StartupSplash));
            t.Start();
            RefreshDevice();
            Thread.Sleep(5000);

            this.ResetControl();
            t.Abort();
            B2BayLogger.Log("===================Refresh finding Devcie END====================");
        }

        #endregion

        #region "Form Event"

        private void frmMain_Load(object sender, EventArgs e)
        {
            try
            {
                //Global.records = new NICRecordBLL().GetNadraCNICRecord();
                RefreshDevice();
                ResetControl();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Environment.Exit(0);
        }

        #endregion

        #region "Get Reader"

        private ReaderCollection _readers;

        public void RefreshDevice()
        {
            _readers = ReaderCollection.GetReaders();

            try
            {
                this.cboReaders.Items.Clear();
                this.cboReaders.Text = string.Empty;
                foreach (Reader Reader in _readers)
                {
                    this.cboReaders.Items.Add(Reader.Description.SerialNumber);
                }
                if (this.cboReaders.Items.Count > 0)
                {
                    this.cboReaders.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                //message box:
                String text = ex.Message;
                text += "\r\n\r\nPlease check if DigitalPersona service has been started";
                //String caption = "Cannot access readers";

                MessageBox.Show(text, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        #endregion

        #region "Send Message"

        /// <summary>
        /// 
        /// </summary>
        private enum Action
        {
            UpdateReaderState
        }

        private delegate void SendMessageCallback(Action state, object payload);

        private void SendMessage(Action state, object payload)
        {
            using (Tracer tracer = new Tracer("Form_Main::SendMessage"))
            {

                //if (this.txtReaderSelected.InvokeRequired)
                if (this.cboReaders.InvokeRequired)
                {
                    SendMessageCallback d = new SendMessageCallback(SendMessage);
                    this.Invoke(d, new object[] { state, payload });
                }
                else
                {
                    switch (state)
                    {
                        case Action.UpdateReaderState:
                            if ((Reader)payload != null)
                            {
                                btnVerification.Enabled = true;
                                btnNadraVerification.Enabled = true;
                                ResetControl();
                            }
                            else
                            {
                                btnVerification.Enabled = false;
                                btnNadraVerification.Enabled = false;
                                ResetControl();
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        #endregion

        #region "SDK Methods"

        ///// <summary>
        ///// Open a device and check result for errors.
        ///// </summary>
        ///// <returns>Returns true if successful; false if unsuccessful</returns>
        public bool OpenReader()
        {
            using (Tracer tracer = new Tracer("Form_Main::OpenReader"))
            {
                reset = false;
                Constants.ResultCode result = Constants.ResultCode.DP_DEVICE_FAILURE;

                // Open reader
                if (currentReader != null)
                    result = currentReader.Open(Constants.CapturePriority.DP_PRIORITY_COOPERATIVE);

                if (result != Constants.ResultCode.DP_SUCCESS)
                {

                    this.cboReaders.Items.Clear();

                    this.cboReaders.SelectedIndex = -1;
                    this.cboReaders.Text = string.Empty;

                    MessageBox.Show("Error:  " + result);
                    reset = true;
                    return false;
                }

                return true;
            }
        }

        /// <summary>
        /// Create a bitmap from raw data in row/column format.
        /// </summary>
        /// <param name="bytes"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <returns></returns>
        public Bitmap CreateBitmap(byte[] bytes, int width, int height)
        {
            byte[] rgbBytes = new byte[bytes.Length * 3];

            for (int i = 0; i <= bytes.Length - 1; i++)
            {
                rgbBytes[(i * 3)] = bytes[i];
                rgbBytes[(i * 3) + 1] = bytes[i];
                rgbBytes[(i * 3) + 2] = bytes[i];
            }
            Bitmap bmp = new Bitmap(width, height, PixelFormat.Format24bppRgb);

            BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);

            for (int i = 0; i <= bmp.Height - 1; i++)
            {
                IntPtr p = new IntPtr(data.Scan0.ToInt64() + data.Stride * i);
                System.Runtime.InteropServices.Marshal.Copy(rgbBytes, i * bmp.Width * 3, p, bmp.Width * 3);
            }

            bmp.UnlockBits(data);

            return bmp;
        }

        public bool StartCaptureAsync(Reader.CaptureCallback OnCaptured)
        {
            using (Tracer tracer = new Tracer("Form_Main::StartCaptureAsync"))
            {
                // Activate capture handler
                currentReader.On_Captured += new Reader.CaptureCallback(OnCaptured);

                // Call capture
                if (!CaptureFingerAsync())
                {
                    return false;
                }

                return true;
            }
        }

        /// <summary>
        /// Function to capture a finger. Always get status first and calibrate or wait if necessary.  Always check status and capture errors.
        /// </summary>
        /// <param name="fid"></param>
        /// <returns></returns>
        public bool CaptureFingerAsync()
        {
            using (Tracer tracer = new Tracer("Form_Main::CaptureFingerAsync"))
            {
                try
                {
                    GetStatus();

                    Constants.ResultCode captureResult = currentReader.CaptureAsync(Constants.Formats.Fid.ANSI, Constants.CaptureProcessing.DP_IMG_PROC_DEFAULT, currentReader.Capabilities.Resolutions[0]);
                    if (captureResult != Constants.ResultCode.DP_SUCCESS)
                    {
                        reset = true;
                        throw new Exception("" + captureResult);
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error:  " + ex.Message);
                    return false;
                }
            }
        }

        /// <summary>
        /// Cancel the capture and then close the reader.
        /// </summary>
        /// <param name="OnCaptured">Delegate to unhook as handler of the On_Captured event </param>
        public void CancelCaptureAndCloseReader(Reader.CaptureCallback OnCaptured)
        {
            using (Tracer tracer = new Tracer("Form_Main::CancelCaptureAndCloseReader"))
            {
                if (currentReader != null)
                {
                    currentReader.CancelCapture();

                    // Dispose of reader handle and unhook reader events.
                    currentReader.Dispose();

                    if (reset)
                    {
                        CurrentReader = null;
                    }
                }
            }
        }

        /// <summary>
        /// Check quality of the resulting capture.
        /// </summary>
        public bool CheckCaptureResult(CaptureResult captureResult)
        {
            using (Tracer tracer = new Tracer("Form_Main::CheckCaptureResult"))
            {
                if (captureResult.Data == null || captureResult.ResultCode != Constants.ResultCode.DP_SUCCESS)
                {
                    if (captureResult.ResultCode != Constants.ResultCode.DP_SUCCESS)
                    {
                        reset = true;
                        throw new Exception(captureResult.ResultCode.ToString());
                    }

                    // Send message if quality shows fake finger
                    if ((captureResult.Quality != Constants.CaptureQuality.DP_QUALITY_CANCELED))
                    {
                        throw new Exception("Quality - " + captureResult.Quality);
                    }
                    return false;
                }

                return true;
            }
        }

        /// <summary>
        /// Check the device status before starting capture.
        /// </summary>
        /// <returns></returns>
        public void GetStatus()
        {
            using (Tracer tracer = new Tracer("Form_Main::GetStatus"))
            {
                Constants.ResultCode result = currentReader.GetStatus();

                if ((result != Constants.ResultCode.DP_SUCCESS))
                {
                    reset = true;
                    throw new Exception("" + result);
                }

                if ((currentReader.Status.Status == Constants.ReaderStatuses.DP_STATUS_BUSY))
                {
                    Thread.Sleep(50);
                }
                else if ((currentReader.Status.Status == Constants.ReaderStatuses.DP_STATUS_NEED_CALIBRATION))
                {
                    currentReader.Calibrate();
                }
                else if ((currentReader.Status.Status != Constants.ReaderStatuses.DP_STATUS_READY))
                {
                    throw new Exception("Reader Status - " + currentReader.Status.Status);
                }
            }
        }

        #endregion
    }
}
