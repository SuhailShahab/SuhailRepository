﻿using DPUruNet;
using PITBFC.FP.ApplicationClass;
//using PITBFC.FP.BOP.PITBFacilitationCentreService;
using PITBFC.FP.BOP.PITBFCSecurityEnrollment;
using PITBFC.FP.Module.BusinessLoginLayer;
using PITBFC.FP.Module.DataModelLayer;
using SMS.CMPScheduler.ApplicationClassess.Log;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Windows.Forms;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <04-03-2015 03:20:33PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR001        Sajjad Aslam                05-Apr-2018                 modified entrolment tempelate check condition on save
// =================================================================================================================================
namespace PITBFC.FP.Forms
{
    public partial class frmEnrollment : Form
    {
        #region "Variable"

        //private DPFP.Capture.Capture Capturer;
        //private DPFP.Processing.Enrollment Enroller;

        private byte[] arrTemplate = null;
        private Image img;
        private string districtCode = CustomConfigReader.DistrictCode; //ConfigurationManager.AppSettings["District"].ToString();
        private PITBFC.FP.BOP.PITBFCSecurityEnrollment.NICRecord nic;

        public frmMain _sender;
        int sampleNeeded = 4;
        List<Fmd> preenrollmentFmds;
        DataResult<Fmd> enrollmentResult = null;

        string template = string.Empty;

        #endregion

        #region "Constructor"

        public frmEnrollment()
        {
            InitializeComponent();
        }

        #endregion

        #region "DPFP Interface Methods"

        /*
        public void OnComplete(object Capture, string ReaderSerialNumber, DPFP.Sample Sample)
        {
            SetPrompt("Scan the same fingerprint again.");
            Process(Sample);
        }

        public void OnFingerGone(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnFingerTouch(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnReaderConnect(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnReaderDisconnect(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnSampleQuality(object Capture, string ReaderSerialNumber, DPFP.Capture.CaptureFeedback CaptureFeedback)
        {
            //throw new NotImplementedException();
        }
        */
        #endregion

        #region "DPFP Related Methods"

        /*
        protected void Init()
        {
            try
            {
                Capturer = new DPFP.Capture.Capture();				// Create a capture operation.

                if (null != Capturer)
                {
                    Capturer.EventHandler = this;					// Subscribe for capturing events.
                    Enroller = new DPFP.Processing.Enrollment();	// Create an enrollment.
                }
                else
                    SetPrompt("Can't initiate capture operation!");
            }
            catch
            {
                MessageBox.Show("Can't initiate capture operation!", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected void Process(DPFP.Sample Sample)
        {
            try
            {
                // Draw fingerprint sample image.
                DrawPicture(ConvertFPImageToBitmap(Sample));

                // Process the sample and create a feature set for the enrollment purpose.
                DPFP.FeatureSet features = ExtractFeatures(Sample, DPFP.Processing.DataPurpose.Enrollment);

                // Check quality of the sample and add to enroller if it's good
                if (features != null) try
                    {
                        //MakeReport("The fingerprint feature set was created.");
                        Enroller.AddFeatures(features);		// Add feature set to template.
                    }
                    finally
                    {
                        UpdateStatus();

                        // Check if template has been created.
                        switch (Enroller.TemplateStatus)
                        {
                            case DPFP.Processing.Enrollment.Status.Ready:	// report success and stop capturing
                                //OnTemplate(Enroller.Template);
                                //byte[] arrTemplate = null;

                                DPFP.Template fpTemplate = new DPFP.Template();
                                fpTemplate = Enroller.Template;
                                fpTemplate.Serialize(ref arrTemplate);

                                SetPrompt("Scanning complete...");
                                Stop();
                                break;

                            case DPFP.Processing.Enrollment.Status.Failed:	// report failure and restart capturing
                                Enroller.Clear();
                                Stop();
                                UpdateStatus();
                                //OnTemplate(null);
                                Start();
                                break;
                        }
                    }
            }
            catch (DPFP.Error.SDKException e)
            {
                MessageBox.Show("Citizen has not been registered properly. Please enrollment again!", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ResetFingurePrintCapture();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ResetFingurePrintCapture();
            }
        }

        protected void Start()
        {
            if (null != Capturer)
            {
                try
                {
                    Capturer.StartCapture();
                    SetPrompt("Fingerprint reader is ready, scan your finger");
                }
                catch
                {
                    SetPrompt("Can't initiate capture!");
                }
            }
        }

        protected void Stop()
        {
            if (null != Capturer)
            {
                try
                {
                    Capturer.StopCapture();
                }
                catch
                {
                    SetPrompt("Can't terminate capture!");
                }
            }
        }

         */
        #endregion

        #region "Form Events"

        private void frmEnrollment_Load(object sender, EventArgs e)
        {
            try
            {
                //Init();
                //Start();
                B2BayLogger.Log("===================Form Initialize the reader device Start====================");
                img = Picture.Image;
                ResetControls();

                if (!_sender.OpenReader())
                {
                    this.Close();
                }

                if (!_sender.StartCaptureAsync(this.OnCaptured))
                {
                    this.Close();
                }
                //=====================================
                B2BayLogger.Log("===================Form Initialize the reader device END====================");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                B2BayLogger.LogErr(ex);
                B2BayLogger.Log("===================Form Initialize the reader device END====================");
            }
        }

        private void frmEnrollment_KeyDown(object sender, KeyEventArgs e)
        {
            B2BayLogger.Log("===================frmEnrollment_KeyDown Start====================");
            if (e.Control && e.KeyCode == Keys.S)
            {
                Save();
            }
            B2BayLogger.Log("===================frmEnrollment_KeyDown END====================");
        }

        private void frmEnrollment_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //Stop();
                B2BayLogger.Log("===================Form Closing the reader device Start====================");
                _sender.CancelCaptureAndCloseReader(this.OnCaptured);
                B2BayLogger.Log("===================Form Closing the reader device END====================");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                B2BayLogger.LogErr(ex);
                B2BayLogger.Log("===================Form Closing the reader device END====================");
            }
            finally
            {
                B2BayLogger.WriteLogsToFile();
            }
        }

        #endregion

        #region "Methods"

        /*
        protected void SetStatus(string status)
        {
            this.Invoke(new Function(delegate()
            {
                lblStatus.Text = status;
            }));
        }

        protected void SetPrompt(string prompt)
        {
            this.Invoke(new Function(delegate()
            {
                txtPrompt.Text = prompt;
            }));
        }

        private void DrawPicture(Bitmap bitmap)
        {
            this.Invoke(new Function(delegate()
            {
                Picture.Image = new Bitmap(bitmap, Picture.Size);	// fit the image into the picture box
            }));
        }

        
        protected Bitmap ConvertFPImageToBitmap(DPFP.Sample Sample)
        {
            DPFP.Capture.SampleConversion Convertor = new DPFP.Capture.SampleConversion();	// Create a sample convertor.
            Bitmap bitmap = null;												            // TODO: the size doesn't matter
            Convertor.ConvertToPicture(Sample, ref bitmap);									// TODO: return bitmap as a result
            return bitmap;
        }

        protected DPFP.FeatureSet ExtractFeatures(DPFP.Sample Sample, DPFP.Processing.DataPurpose Purpose)
        {
            DPFP.Processing.FeatureExtraction Extractor = new DPFP.Processing.FeatureExtraction();	// Create a feature extractor
            DPFP.Capture.CaptureFeedback feedback = DPFP.Capture.CaptureFeedback.None;
            DPFP.FeatureSet features = new DPFP.FeatureSet();
            Extractor.CreateFeatureSet(Sample, Purpose, ref feedback, ref features);			// TODO: return features as a result?
            if (feedback == DPFP.Capture.CaptureFeedback.Good)
                return features;
            else
                return null;
        }

        
        */
        
        private void Save()
        {
            try
            {
                if (string.IsNullOrEmpty(txtApplicant.Text))
                {
                    MessageBox.Show("Please enter applicant id or CNIC", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtApplicant.Focus();
                    return;
                }
                if (string.IsNullOrEmpty(lblCNICNumber.Text))
                {
                    MessageBox.Show("Invalid CNIC number", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);                    
                    return;
                }
                
                if (enrollmentResult != null && enrollmentResult.ResultCode == Constants.ResultCode.DP_ENROLLMENT_NOT_READY) // CR001
                {
                    MessageBox.Show("No enrollment fingerprint image created. Please try again.", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                //if (arrTemplate == null)
                //{
                //    MessageBox.Show("Please scan citzen finger print imperssion", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //    return;
                //}

                Cursor.Current = Cursors.WaitCursor;
                this.Enabled = false;

                // save record to center maintained database
                if (Convert.ToBoolean(ConfigurationManager.AppSettings["MaintainCenterData"].ToString()))
                {
                    NICRecordModel nr = new NICRecordModel();
                    nr.CNIC = nic.CNIC;
                    nr.Name = nic.Name;
                    nr.FatherName = nic.FatherName;
                    nr.PermanentAddress = nic.ParmanentAddress;
                    nr.CurrentAddress = nic.CurrentAddress;
                    nr.ContactNo = nic.ContactNo;
                    nr.GenderID = nic.GenderID;
                    nr.DOB = nic.DOB;
                    nr.HouseNo = nic.HouseNo;
                    nr.StreetNo = nic.StreetNo;
                    nr.BlockNo = nic.BlockNo;
                    nr.Neighbourhood = nic.Neighbourhood;
                    nr.NeighbourhoodUrdu = nic.NeighbourhoodUrdu;
                    nr.AdditionalInformation = nic.AdditionalInformation;
                    nr.AdditionalInformationUrdu = nic.AdditionalInformationUrdu;
                    nr.PermanentAddress = nic.ParmanentAddress;
                    nr.PermanentAddressUrdu = nic.PermanentAddressUrdu;
                    nr.CurrentAddress = nic.CurrentAddress;
                    nr.CurrentAddressUrdu = nic.CurrentAddressUrdu;
                    nr.DivisionID = nic.DivisionID;
                    nr.DistrictID = nic.DistrictID;
                    nr.TehsilID = nic.TehsilID;
                    nr.CityID = nic.CityID;
                    nr.UnionCouncilID = nic.UnionCouncilID;
                    //nr.FingerImpression = arrTemplate;
                    nr.FingerImpression = enrollmentResult.Data.Bytes;
                    nr.FignerPrint = template;
                    nr.LocationCode = CustomConfigReader.LocationCode; //ConfigurationManager.AppSettings["Location"].ToString();
                    new NICRecordBLL().Save(nr);
                }


                PITBFC.FP.BOP.PITBFCSecurityEnrollment.CitizenEnrollment ce = new PITBFC.FP.BOP.PITBFCSecurityEnrollment.CitizenEnrollment();
                ce.CNIC = lblCNICNumber.Text;
                ce.DistrictCode = districtCode;
                //ce.FingerImpression = arrTemplate;
                //ce.DistrictCode = DistrictCode;
                ce.FingerImpression = enrollmentResult.Data.Bytes;
                ce.FingerPrint = template;

                using (PITBFacilitationCentreServiceClient proxy = new PITBFacilitationCentreServiceClient())
                {
                    string result = proxy.CitizenEnrollment(ce);
                    if (result != "")
                    {
                        string[] arrResult = result.Split('|');
                        if (arrResult[0] == "true")
                        {
                            //SetPrompt("Record saved successfully.");
                            txtPrompt.Text = "Record saved successfully.";
                            ResetControls();
                            ResetFingurePrintCapture();
                            MessageBox.Show("Record saved successfully. Click close, and then click Fingerprint Verification", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                
                Cursor.Current = Cursors.Default;
                this.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
                this.Enabled = true;
            }
        }

         
         
        private void ResetFingurePrintCapture()
        {
            //Enroller.Clear();
            //Stop();
            UpdateStatus();
            //Start();
            Picture.Image = img;
            arrTemplate = null;
            enrollmentResult = null;
        }
        
        

        private void UpdateStatus()
        {
            // Show number of samples needed.
            SendMessage(Action.SendMessage, (String.Format("Fingerprint samples needed: {0}", sampleNeeded)));
        }


        private void ResetControls()
        {
            txtApplicant.ResetText();
            lblCNICNumber.ResetText();
            lblName.ResetText();
            lblNameofFather.ResetText();
            lblParmanentAddress.ResetText();
            lblCurrentAddress.ResetText();
            lblContactNo.ResetText();
            nic = null;

            lblStatus.ResetText();
            txtPrompt.Text = "Fingerprint reader is ready, scan your finger";
        }
        
        #endregion

        #region "Button Click Events"

        private void btnSave_Click(object sender, EventArgs e)
        {
            B2BayLogger.Log("===================Save record Start====================");
            Save();
            B2BayLogger.Log("===================Save record END======================");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #endregion

        #region "RadioButton Events"

        private void rbtnApplicantID_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton)sender;

            lblApplicantID.Text = rb.Text;
            txtApplicant.ResetText();
        }

        #endregion

        #region "TextBox Events"

        private void txtApplicant_KeyDown(object sender, KeyEventArgs e)
        {
            B2BayLogger.Log("===================KeyDown process of getting data from WCF Start====================");

            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    this.Enabled = false;
                    B2BayLogger.Log("=========Calling  WCF PITBFacilitationCentreServiceClient Start===============");
                    using (PITBFacilitationCentreServiceClient proxy = new PITBFacilitationCentreServiceClient())
                    {

                       
                        nic = proxy.GetNICRecordByApplicantID(txtApplicant.Text);
                        if (nic != null)
                        {
                            if (string.IsNullOrEmpty(nic.Notification))
                            {
                                B2BayLogger.Log("=========Record Found from WCF PITBFacilitationCentreServiceClient========");
                                lblCNICNumber.Text = nic.CNIC;
                                lblName.Text = nic.Name;
                                lblNameofFather.Text = nic.FatherName;
                                lblParmanentAddress.Text = nic.ParmanentAddress;
                                lblCurrentAddress.Text = nic.CurrentAddress;
                                lblContactNo.Text = nic.ContactNo;
                                B2BayLogger.Log("=========Setting the value of control with reponse object==================");
                            }
                            else
                            {
                                MessageBox.Show(nic.Notification, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                B2BayLogger.Log("=========InfoMessage:" + nic.Notification + "==================");
                            }
                                
                        }
                        else
                        {
                            MessageBox.Show("No record found", "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            B2BayLogger.Log("No record found");
                        }
                           
                    }

                    Cursor.Current = Cursors.Default;
                    this.Enabled = true;

                    B2BayLogger.Log("===================KeyDown process of getting data from WCF End====================");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Cursor.Current = Cursors.Default;
                    this.Enabled = true;
                    B2BayLogger.LogErr(ex);
                    B2BayLogger.Log("===========KeyDown process of getting data from WCF End with exception=============");
                }
                finally
                {
                    B2BayLogger.WriteLogsToFile();
                }
            }
        }

        #endregion

        #region "UrU SDK Methods"

        /// <summary>
        /// Handler for when a fingerprint is captured.
        /// </summary>
        /// <param name="captureResult">contains info and data on the fingerprint capture</param>
        public void OnCaptured(CaptureResult captureResult)
        {
            try
            {
                // Check capture quality and throw an error if bad.
                if (!_sender.CheckCaptureResult(captureResult)) return;

                sampleNeeded--;

                DataResult<Fmd> resultConversion = FeatureExtraction.CreateFmdFromFid(captureResult.Data, Constants.Formats.Fmd.DP_PRE_REGISTRATION);

                SendMessage(Action.SendMessage, (String.Format("Fingerprint samples needed: {0}", sampleNeeded)));

                if (resultConversion.ResultCode != Constants.ResultCode.DP_SUCCESS)
                {
                    _sender.Reset = true;
                    throw new Exception(resultConversion.ResultCode.ToString());
                }

                // Create bitmap
                foreach (Fid.Fiv fiv in captureResult.Data.Views)
                {
                    SendMessage(Action.SendBitmap, this._sender.CreateBitmap(fiv.RawImage, fiv.Width, fiv.Height));
                }

                if (preenrollmentFmds == null) preenrollmentFmds = new List<Fmd>();

                preenrollmentFmds.Add(resultConversion.Data);

                if (sampleNeeded == 0)
                {
                    enrollmentResult = DPUruNet.Enrollment.CreateEnrollmentFmd(Constants.Formats.Fmd.DP_REGISTRATION, preenrollmentFmds);
                    if (enrollmentResult.ResultCode == Constants.ResultCode.DP_SUCCESS)
                    {
                        template = Fmd.SerializeXml(enrollmentResult.Data);
                        SendMessage(Action.SendInformation, "Enrollment template created successfully.");
                        SendMessage(Action.SendMessage, "");
                        preenrollmentFmds.Clear();
                        sampleNeeded = 4;
                        return;
                    }
                    else //if (enrollmentResult.ResultCode == Constants.ResultCode.DP_ENROLLMENT_INVALID_SET)
                    {
                        sampleNeeded = 4;
                        SendMessage(Action.SendInformation, "Enrollment was unsuccessful.  Please try again.");
                        SendMessage(Action.SendMessage, (String.Format("Fingerprint samples needed: {0}", sampleNeeded)));
                        preenrollmentFmds.Clear();
                        return;
                    }
                }
                }
            catch (SDKException se)
            {
                MessageBox.Show(se.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                // Send error message, then close form
                //SendMessage(Action.SendMessage, "Error:  " + ex.Message);
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Custom Event/Delegate of SDK

        private delegate void SendMessageCallback(Action action, object payload);
        private void SendMessage(Action action, object payload)
        {
            try
            {
                if (this.Picture.InvokeRequired)
                {
                    SendMessageCallback d = new SendMessageCallback(SendMessage);
                    this.Invoke(d, new object[] { action, payload });
                }
                else
                {
                    switch (action)
                    {
                        case Action.SendMessage:
                            //MessageBox.Show((string)payload);
                            lblStatus.Text = (string)payload;
                            break;
                        case Action.SendPrompt:
                            //MessageBox.Show((string)payload);
                            txtPrompt.Text = (string)payload;
                            break;
                        case Action.SendInformation:
                            MessageBox.Show((string)payload, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        case Action.SendBitmap:
                            Picture.Image = (Bitmap)payload;
                            Picture.Refresh();
                            break;
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        #endregion

        #region Custom Emum of SDK

        private enum Action
        {
            SendBitmap,
            SendMessage,
            SendPrompt,
            SendInformation
        }

        #endregion
    }
}
