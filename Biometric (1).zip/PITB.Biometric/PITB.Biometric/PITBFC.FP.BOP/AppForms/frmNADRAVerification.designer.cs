﻿namespace PITBFC.FP.Forms
{
    partial class frmNADRAVerification
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNADRAVerification));
            this.pbFingerprint = new System.Windows.Forms.PictureBox();
            this.txtPrompt = new System.Windows.Forms.TextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCNIC = new System.Windows.Forms.TextBox();
            this.pnlCitizenInformation = new System.Windows.Forms.Panel();
            this.lblCardExpiry = new System.Windows.Forms.Label();
            this.lblDOB = new System.Windows.Forms.Label();
            this.lblBirthPlace = new System.Windows.Forms.Label();
            this.lblAddressCurrent = new System.Windows.Forms.Label();
            this.lblContact = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPresentAddress = new System.Windows.Forms.Label();
            this.txtMobileNo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbFingerIndex = new System.Windows.Forms.ComboBox();
            this.pnlFingerIndexs = new System.Windows.Forms.Panel();
            this.pnlRightLittle = new System.Windows.Forms.Panel();
            this.pnlRightRing = new System.Windows.Forms.Panel();
            this.pnlRightMiddle = new System.Windows.Forms.Panel();
            this.pnlRightIndex = new System.Windows.Forms.Panel();
            this.pnlRightThumb = new System.Windows.Forms.Panel();
            this.pnlLeftLittle = new System.Windows.Forms.Panel();
            this.pnlLeftRing = new System.Windows.Forms.Panel();
            this.pnlLeftMiddle = new System.Windows.Forms.Panel();
            this.pnlLeftIndex = new System.Windows.Forms.Panel();
            this.pnlLeftThumb = new System.Windows.Forms.Panel();
            this.btnLeftLittle = new System.Windows.Forms.Button();
            this.btnLeftRing = new System.Windows.Forms.Button();
            this.btnLeftMiddle = new System.Windows.Forms.Button();
            this.btnLeftIndex = new System.Windows.Forms.Button();
            this.btnLeftThumb = new System.Windows.Forms.Button();
            this.btnRightLittle = new System.Windows.Forms.Button();
            this.btnRightRing = new System.Windows.Forms.Button();
            this.btnRightMiddle = new System.Windows.Forms.Button();
            this.btnRightIndex = new System.Windows.Forms.Button();
            this.btnRightThumb = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.cmbServices = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.grpAvailableIndexes = new System.Windows.Forms.GroupBox();
            this.lblIndex5 = new System.Windows.Forms.Label();
            this.lblIndex4 = new System.Windows.Forms.Label();
            this.lblIndex3 = new System.Windows.Forms.Label();
            this.lblIndex2 = new System.Windows.Forms.Label();
            this.lblIndex1 = new System.Windows.Forms.Label();
            this.lblIndex6 = new System.Windows.Forms.Label();
            this.lblIndex7 = new System.Windows.Forms.Label();
            this.lblIndex8 = new System.Windows.Forms.Label();
            this.lblIndex9 = new System.Windows.Forms.Label();
            this.lblIndex10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbFingerprint)).BeginInit();
            this.pnlCitizenInformation.SuspendLayout();
            this.pnlFingerIndexs.SuspendLayout();
            this.grpAvailableIndexes.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbFingerprint
            // 
            this.pbFingerprint.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbFingerprint.BackColor = System.Drawing.Color.Transparent;
            this.pbFingerprint.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbFingerprint.ErrorImage = null;
            this.pbFingerprint.InitialImage = null;
            this.pbFingerprint.Location = new System.Drawing.Point(705, 196);
            this.pbFingerprint.Name = "pbFingerprint";
            this.pbFingerprint.Size = new System.Drawing.Size(408, 371);
            this.pbFingerprint.TabIndex = 17;
            this.pbFingerprint.TabStop = false;
            // 
            // txtPrompt
            // 
            this.txtPrompt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPrompt.BackColor = System.Drawing.Color.White;
            this.txtPrompt.Enabled = false;
            this.txtPrompt.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrompt.Location = new System.Drawing.Point(705, 155);
            this.txtPrompt.Name = "txtPrompt";
            this.txtPrompt.ReadOnly = true;
            this.txtPrompt.Size = new System.Drawing.Size(408, 31);
            this.txtPrompt.TabIndex = 22;
            // 
            // lblStatus
            // 
            this.lblStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.Font = new System.Drawing.Font("Calibri", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.Black;
            this.lblStatus.Location = new System.Drawing.Point(705, 570);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(408, 45);
            this.lblStatus.TabIndex = 23;
            this.lblStatus.Text = "status";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(90)))), ((int)(((byte)(93)))));
            this.label1.Location = new System.Drawing.Point(69, 202);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 21);
            this.label1.TabIndex = 31;
            this.label1.Text = "CNIC *";
            // 
            // txtCNIC
            // 
            this.txtCNIC.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCNIC.BackColor = System.Drawing.Color.White;
            this.txtCNIC.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCNIC.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCNIC.Location = new System.Drawing.Point(233, 196);
            this.txtCNIC.MaxLength = 13;
            this.txtCNIC.Name = "txtCNIC";
            this.txtCNIC.Size = new System.Drawing.Size(452, 31);
            this.txtCNIC.TabIndex = 1;
            this.txtCNIC.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCNIC_KeyDown);
            this.txtCNIC.Validating += new System.ComponentModel.CancelEventHandler(this.txtCNIC_Validating);
            this.txtCNIC.Validated += new System.EventHandler(this.txtCNIC_Validated);
            // 
            // pnlCitizenInformation
            // 
            this.pnlCitizenInformation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlCitizenInformation.BackColor = System.Drawing.Color.Transparent;
            this.pnlCitizenInformation.Controls.Add(this.lblCardExpiry);
            this.pnlCitizenInformation.Controls.Add(this.lblDOB);
            this.pnlCitizenInformation.Controls.Add(this.lblBirthPlace);
            this.pnlCitizenInformation.Controls.Add(this.lblAddressCurrent);
            this.pnlCitizenInformation.Controls.Add(this.lblContact);
            this.pnlCitizenInformation.Controls.Add(this.lblAddress);
            this.pnlCitizenInformation.Controls.Add(this.lblName);
            this.pnlCitizenInformation.Controls.Add(this.label3);
            this.pnlCitizenInformation.Controls.Add(this.label2);
            this.pnlCitizenInformation.Controls.Add(this.lblPresentAddress);
            this.pnlCitizenInformation.Location = new System.Drawing.Point(66, 278);
            this.pnlCitizenInformation.Name = "pnlCitizenInformation";
            this.pnlCitizenInformation.Size = new System.Drawing.Size(633, 249);
            this.pnlCitizenInformation.TabIndex = 47;
            this.pnlCitizenInformation.Visible = false;
            // 
            // lblCardExpiry
            // 
            this.lblCardExpiry.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCardExpiry.BackColor = System.Drawing.Color.Transparent;
            this.lblCardExpiry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCardExpiry.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCardExpiry.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.lblCardExpiry.Location = new System.Drawing.Point(167, 204);
            this.lblCardExpiry.Name = "lblCardExpiry";
            this.lblCardExpiry.Size = new System.Drawing.Size(452, 33);
            this.lblCardExpiry.TabIndex = 57;
            this.lblCardExpiry.Text = "CNIC";
            this.lblCardExpiry.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDOB
            // 
            this.lblDOB.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDOB.BackColor = System.Drawing.Color.Transparent;
            this.lblDOB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDOB.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDOB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.lblDOB.Location = new System.Drawing.Point(167, 159);
            this.lblDOB.Name = "lblDOB";
            this.lblDOB.Size = new System.Drawing.Size(452, 33);
            this.lblDOB.TabIndex = 56;
            this.lblDOB.Text = "CNIC";
            this.lblDOB.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblBirthPlace
            // 
            this.lblBirthPlace.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblBirthPlace.BackColor = System.Drawing.Color.Transparent;
            this.lblBirthPlace.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBirthPlace.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBirthPlace.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.lblBirthPlace.Location = new System.Drawing.Point(167, 114);
            this.lblBirthPlace.Name = "lblBirthPlace";
            this.lblBirthPlace.Size = new System.Drawing.Size(452, 33);
            this.lblBirthPlace.TabIndex = 55;
            this.lblBirthPlace.Text = "CNIC";
            this.lblBirthPlace.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblAddressCurrent
            // 
            this.lblAddressCurrent.AutoSize = true;
            this.lblAddressCurrent.BackColor = System.Drawing.Color.Transparent;
            this.lblAddressCurrent.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddressCurrent.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(90)))), ((int)(((byte)(93)))));
            this.lblAddressCurrent.Location = new System.Drawing.Point(3, 210);
            this.lblAddressCurrent.Name = "lblAddressCurrent";
            this.lblAddressCurrent.Size = new System.Drawing.Size(88, 21);
            this.lblAddressCurrent.TabIndex = 52;
            this.lblAddressCurrent.Text = "Card Expiry";
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.BackColor = System.Drawing.Color.Transparent;
            this.lblContact.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContact.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(90)))), ((int)(((byte)(93)))));
            this.lblContact.Location = new System.Drawing.Point(3, 120);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(84, 21);
            this.lblContact.TabIndex = 51;
            this.lblContact.Text = "Birth Place";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblAddress.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(90)))), ((int)(((byte)(93)))));
            this.lblAddress.Location = new System.Drawing.Point(3, 165);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(98, 21);
            this.lblAddress.TabIndex = 50;
            this.lblAddress.Text = "Date of Birth";
            // 
            // lblName
            // 
            this.lblName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblName.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.lblName.Location = new System.Drawing.Point(167, 2);
            this.lblName.Name = "lblName";
            this.lblName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblName.Size = new System.Drawing.Size(452, 33);
            this.lblName.TabIndex = 48;
            this.lblName.Text = "CNIC";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(90)))), ((int)(((byte)(93)))));
            this.label3.Location = new System.Drawing.Point(3, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 21);
            this.label3.TabIndex = 47;
            this.label3.Text = "Present Address";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(90)))), ((int)(((byte)(93)))));
            this.label2.Location = new System.Drawing.Point(3, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 21);
            this.label2.TabIndex = 46;
            this.label2.Text = "Name";
            // 
            // lblPresentAddress
            // 
            this.lblPresentAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPresentAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblPresentAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPresentAddress.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPresentAddress.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(55)))), ((int)(((byte)(55)))));
            this.lblPresentAddress.Location = new System.Drawing.Point(167, 47);
            this.lblPresentAddress.Name = "lblPresentAddress";
            this.lblPresentAddress.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblPresentAddress.Size = new System.Drawing.Size(452, 55);
            this.lblPresentAddress.TabIndex = 53;
            this.lblPresentAddress.Text = "CNIC";
            this.lblPresentAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMobileNo
            // 
            this.txtMobileNo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMobileNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtMobileNo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobileNo.Location = new System.Drawing.Point(233, 237);
            this.txtMobileNo.MaxLength = 11;
            this.txtMobileNo.Name = "txtMobileNo";
            this.txtMobileNo.Size = new System.Drawing.Size(452, 31);
            this.txtMobileNo.TabIndex = 2;
            this.txtMobileNo.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCNIC_KeyDown);
            this.txtMobileNo.Validating += new System.ComponentModel.CancelEventHandler(this.txtMobileNo_Validating);
            this.txtMobileNo.Validated += new System.EventHandler(this.txtCNIC_Validated);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(90)))), ((int)(((byte)(93)))));
            this.label4.Location = new System.Drawing.Point(69, 244);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 21);
            this.label4.TabIndex = 48;
            this.label4.Text = "Contact Number *";
            // 
            // cmbFingerIndex
            // 
            this.cmbFingerIndex.FormattingEnabled = true;
            this.cmbFingerIndex.Location = new System.Drawing.Point(116, 545);
            this.cmbFingerIndex.Name = "cmbFingerIndex";
            this.cmbFingerIndex.Size = new System.Drawing.Size(121, 23);
            this.cmbFingerIndex.TabIndex = 50;
            this.cmbFingerIndex.Visible = false;
            this.cmbFingerIndex.SelectedIndexChanged += new System.EventHandler(this.cmbFingerIndex_SelectedIndexChanged);
            // 
            // pnlFingerIndexs
            // 
            this.pnlFingerIndexs.BackColor = System.Drawing.Color.Transparent;
            this.pnlFingerIndexs.BackgroundImage = global::PITBFC.FP.BOP.Properties.Resources.FullHand;
            this.pnlFingerIndexs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlFingerIndexs.Controls.Add(this.pnlRightLittle);
            this.pnlFingerIndexs.Controls.Add(this.pnlRightRing);
            this.pnlFingerIndexs.Controls.Add(this.pnlRightMiddle);
            this.pnlFingerIndexs.Controls.Add(this.pnlRightIndex);
            this.pnlFingerIndexs.Controls.Add(this.pnlRightThumb);
            this.pnlFingerIndexs.Controls.Add(this.pnlLeftLittle);
            this.pnlFingerIndexs.Controls.Add(this.pnlLeftRing);
            this.pnlFingerIndexs.Controls.Add(this.pnlLeftMiddle);
            this.pnlFingerIndexs.Controls.Add(this.pnlLeftIndex);
            this.pnlFingerIndexs.Controls.Add(this.pnlLeftThumb);
            this.pnlFingerIndexs.Controls.Add(this.btnLeftLittle);
            this.pnlFingerIndexs.Controls.Add(this.btnLeftRing);
            this.pnlFingerIndexs.Controls.Add(this.btnLeftMiddle);
            this.pnlFingerIndexs.Controls.Add(this.btnLeftIndex);
            this.pnlFingerIndexs.Controls.Add(this.btnLeftThumb);
            this.pnlFingerIndexs.Controls.Add(this.btnRightLittle);
            this.pnlFingerIndexs.Controls.Add(this.btnRightRing);
            this.pnlFingerIndexs.Controls.Add(this.btnRightMiddle);
            this.pnlFingerIndexs.Controls.Add(this.btnRightIndex);
            this.pnlFingerIndexs.Controls.Add(this.btnRightThumb);
            this.pnlFingerIndexs.Location = new System.Drawing.Point(66, 278);
            this.pnlFingerIndexs.Name = "pnlFingerIndexs";
            this.pnlFingerIndexs.Size = new System.Drawing.Size(791, 254);
            this.pnlFingerIndexs.TabIndex = 51;
            // 
            // pnlRightLittle
            // 
            this.pnlRightLittle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlRightLittle.BackColor = System.Drawing.Color.Transparent;
            this.pnlRightLittle.Location = new System.Drawing.Point(614, 32);
            this.pnlRightLittle.Name = "pnlRightLittle";
            this.pnlRightLittle.Size = new System.Drawing.Size(31, 90);
            this.pnlRightLittle.TabIndex = 64;
            this.pnlRightLittle.Click += new System.EventHandler(this.btnRightLittle_Click);
            this.pnlRightLittle.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlRightLittle.MouseHover += new System.EventHandler(this.pnlRightLittle_MouseHover);
            // 
            // pnlRightRing
            // 
            this.pnlRightRing.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlRightRing.BackColor = System.Drawing.Color.Transparent;
            this.pnlRightRing.Location = new System.Drawing.Point(569, 14);
            this.pnlRightRing.Name = "pnlRightRing";
            this.pnlRightRing.Size = new System.Drawing.Size(36, 107);
            this.pnlRightRing.TabIndex = 63;
            this.pnlRightRing.Click += new System.EventHandler(this.btnRightRing_Click);
            this.pnlRightRing.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlRightRing.MouseHover += new System.EventHandler(this.pnlRightRing_MouseHover);
            // 
            // pnlRightMiddle
            // 
            this.pnlRightMiddle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlRightMiddle.BackColor = System.Drawing.Color.Transparent;
            this.pnlRightMiddle.Location = new System.Drawing.Point(526, 6);
            this.pnlRightMiddle.Name = "pnlRightMiddle";
            this.pnlRightMiddle.Size = new System.Drawing.Size(34, 112);
            this.pnlRightMiddle.TabIndex = 62;
            this.pnlRightMiddle.Click += new System.EventHandler(this.btnRightMiddle_Click);
            this.pnlRightMiddle.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlRightMiddle.MouseHover += new System.EventHandler(this.pnlRightMiddle_MouseHover);
            // 
            // pnlRightIndex
            // 
            this.pnlRightIndex.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlRightIndex.BackColor = System.Drawing.Color.Transparent;
            this.pnlRightIndex.Location = new System.Drawing.Point(477, 19);
            this.pnlRightIndex.Name = "pnlRightIndex";
            this.pnlRightIndex.Size = new System.Drawing.Size(35, 103);
            this.pnlRightIndex.TabIndex = 61;
            this.pnlRightIndex.Click += new System.EventHandler(this.btnRightIndex_Click);
            this.pnlRightIndex.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlRightIndex.MouseHover += new System.EventHandler(this.pnlRightIndex_MouseHover);
            // 
            // pnlRightThumb
            // 
            this.pnlRightThumb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlRightThumb.BackColor = System.Drawing.Color.Transparent;
            this.pnlRightThumb.Location = new System.Drawing.Point(408, 134);
            this.pnlRightThumb.Name = "pnlRightThumb";
            this.pnlRightThumb.Size = new System.Drawing.Size(74, 72);
            this.pnlRightThumb.TabIndex = 60;
            this.pnlRightThumb.Click += new System.EventHandler(this.btnRightThumb_Click);
            this.pnlRightThumb.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlRightThumb.MouseHover += new System.EventHandler(this.pnlRightThumb_MouseHover);
            // 
            // pnlLeftLittle
            // 
            this.pnlLeftLittle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeftLittle.BackColor = System.Drawing.Color.Transparent;
            this.pnlLeftLittle.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlLeftLittle.BackgroundImage")));
            this.pnlLeftLittle.Location = new System.Drawing.Point(145, 31);
            this.pnlLeftLittle.Name = "pnlLeftLittle";
            this.pnlLeftLittle.Size = new System.Drawing.Size(31, 90);
            this.pnlLeftLittle.TabIndex = 59;
            this.pnlLeftLittle.Click += new System.EventHandler(this.btnLeftLittle_Click);
            this.pnlLeftLittle.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlLeftLittle.MouseHover += new System.EventHandler(this.pnlLeftLittle_MouseHover);
            // 
            // pnlLeftRing
            // 
            this.pnlLeftRing.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeftRing.BackColor = System.Drawing.Color.Transparent;
            this.pnlLeftRing.Location = new System.Drawing.Point(187, 14);
            this.pnlLeftRing.Name = "pnlLeftRing";
            this.pnlLeftRing.Size = new System.Drawing.Size(31, 107);
            this.pnlLeftRing.TabIndex = 58;
            this.pnlLeftRing.Click += new System.EventHandler(this.btnLeftRing_Click);
            this.pnlLeftRing.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlLeftRing.MouseHover += new System.EventHandler(this.pnlLeftRing_MouseHover);
            // 
            // pnlLeftMiddle
            // 
            this.pnlLeftMiddle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeftMiddle.BackColor = System.Drawing.Color.Transparent;
            this.pnlLeftMiddle.Location = new System.Drawing.Point(234, 3);
            this.pnlLeftMiddle.Name = "pnlLeftMiddle";
            this.pnlLeftMiddle.Size = new System.Drawing.Size(31, 116);
            this.pnlLeftMiddle.TabIndex = 57;
            this.pnlLeftMiddle.Click += new System.EventHandler(this.btnLeftMiddle_Click);
            this.pnlLeftMiddle.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlLeftMiddle.MouseHover += new System.EventHandler(this.pnlLeftMiddle_MouseHover);
            // 
            // pnlLeftIndex
            // 
            this.pnlLeftIndex.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeftIndex.BackColor = System.Drawing.Color.Transparent;
            this.pnlLeftIndex.Location = new System.Drawing.Point(279, 19);
            this.pnlLeftIndex.Name = "pnlLeftIndex";
            this.pnlLeftIndex.Size = new System.Drawing.Size(35, 103);
            this.pnlLeftIndex.TabIndex = 56;
            this.pnlLeftIndex.Click += new System.EventHandler(this.btnLeftIndex_Click);
            this.pnlLeftIndex.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlLeftIndex.MouseHover += new System.EventHandler(this.pnlLeftIndex_MouseHover);
            // 
            // pnlLeftThumb
            // 
            this.pnlLeftThumb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlLeftThumb.BackColor = System.Drawing.Color.Transparent;
            this.pnlLeftThumb.Location = new System.Drawing.Point(309, 134);
            this.pnlLeftThumb.Name = "pnlLeftThumb";
            this.pnlLeftThumb.Size = new System.Drawing.Size(74, 72);
            this.pnlLeftThumb.TabIndex = 55;
            this.pnlLeftThumb.Click += new System.EventHandler(this.btnLeftThumb_Click);
            this.pnlLeftThumb.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlLeftThumb_Paint);
            this.pnlLeftThumb.MouseLeave += new System.EventHandler(this.pnlLeftThumb_MouseLeave);
            this.pnlLeftThumb.MouseHover += new System.EventHandler(this.pnlLeftThumb_MouseHover);
            // 
            // btnLeftLittle
            // 
            this.btnLeftLittle.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeftLittle.Location = new System.Drawing.Point(7, 203);
            this.btnLeftLittle.Name = "btnLeftLittle";
            this.btnLeftLittle.Size = new System.Drawing.Size(55, 28);
            this.btnLeftLittle.TabIndex = 12;
            this.btnLeftLittle.Text = "Left Little";
            this.btnLeftLittle.UseVisualStyleBackColor = true;
            this.btnLeftLittle.Visible = false;
            this.btnLeftLittle.Click += new System.EventHandler(this.btnLeftLittle_Click);
            // 
            // btnLeftRing
            // 
            this.btnLeftRing.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeftRing.Location = new System.Drawing.Point(7, 91);
            this.btnLeftRing.Name = "btnLeftRing";
            this.btnLeftRing.Size = new System.Drawing.Size(55, 28);
            this.btnLeftRing.TabIndex = 11;
            this.btnLeftRing.Text = "Left Ring";
            this.btnLeftRing.UseVisualStyleBackColor = true;
            this.btnLeftRing.Visible = false;
            this.btnLeftRing.Click += new System.EventHandler(this.btnLeftRing_Click);
            // 
            // btnLeftMiddle
            // 
            this.btnLeftMiddle.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeftMiddle.Location = new System.Drawing.Point(7, 119);
            this.btnLeftMiddle.Name = "btnLeftMiddle";
            this.btnLeftMiddle.Size = new System.Drawing.Size(55, 28);
            this.btnLeftMiddle.TabIndex = 10;
            this.btnLeftMiddle.Text = "Left Middle";
            this.btnLeftMiddle.UseVisualStyleBackColor = true;
            this.btnLeftMiddle.Visible = false;
            this.btnLeftMiddle.Click += new System.EventHandler(this.btnLeftMiddle_Click);
            // 
            // btnLeftIndex
            // 
            this.btnLeftIndex.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeftIndex.Location = new System.Drawing.Point(7, 147);
            this.btnLeftIndex.Name = "btnLeftIndex";
            this.btnLeftIndex.Size = new System.Drawing.Size(55, 28);
            this.btnLeftIndex.TabIndex = 9;
            this.btnLeftIndex.Text = "Left Index";
            this.btnLeftIndex.UseVisualStyleBackColor = true;
            this.btnLeftIndex.Visible = false;
            this.btnLeftIndex.Click += new System.EventHandler(this.btnLeftIndex_Click);
            // 
            // btnLeftThumb
            // 
            this.btnLeftThumb.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLeftThumb.Location = new System.Drawing.Point(7, 231);
            this.btnLeftThumb.Name = "btnLeftThumb";
            this.btnLeftThumb.Size = new System.Drawing.Size(55, 28);
            this.btnLeftThumb.TabIndex = 8;
            this.btnLeftThumb.Text = "Left Thumb";
            this.btnLeftThumb.UseVisualStyleBackColor = true;
            this.btnLeftThumb.Visible = false;
            this.btnLeftThumb.Click += new System.EventHandler(this.btnLeftThumb_Click);
            // 
            // btnRightLittle
            // 
            this.btnRightLittle.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRightLittle.Location = new System.Drawing.Point(7, 63);
            this.btnRightLittle.Name = "btnRightLittle";
            this.btnRightLittle.Size = new System.Drawing.Size(55, 28);
            this.btnRightLittle.TabIndex = 7;
            this.btnRightLittle.Text = "Right Little";
            this.btnRightLittle.UseVisualStyleBackColor = true;
            this.btnRightLittle.Visible = false;
            this.btnRightLittle.Click += new System.EventHandler(this.btnRightLittle_Click);
            // 
            // btnRightRing
            // 
            this.btnRightRing.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRightRing.Location = new System.Drawing.Point(7, 35);
            this.btnRightRing.Name = "btnRightRing";
            this.btnRightRing.Size = new System.Drawing.Size(55, 28);
            this.btnRightRing.TabIndex = 6;
            this.btnRightRing.Text = "Right Ring";
            this.btnRightRing.UseVisualStyleBackColor = true;
            this.btnRightRing.Visible = false;
            this.btnRightRing.Click += new System.EventHandler(this.btnRightRing_Click);
            // 
            // btnRightMiddle
            // 
            this.btnRightMiddle.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRightMiddle.Location = new System.Drawing.Point(7, 7);
            this.btnRightMiddle.Name = "btnRightMiddle";
            this.btnRightMiddle.Size = new System.Drawing.Size(55, 28);
            this.btnRightMiddle.TabIndex = 5;
            this.btnRightMiddle.Text = "Right Middle";
            this.btnRightMiddle.UseVisualStyleBackColor = true;
            this.btnRightMiddle.Visible = false;
            this.btnRightMiddle.Click += new System.EventHandler(this.btnRightMiddle_Click);
            // 
            // btnRightIndex
            // 
            this.btnRightIndex.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRightIndex.Location = new System.Drawing.Point(7, 175);
            this.btnRightIndex.Name = "btnRightIndex";
            this.btnRightIndex.Size = new System.Drawing.Size(55, 28);
            this.btnRightIndex.TabIndex = 4;
            this.btnRightIndex.Text = "Right Index";
            this.btnRightIndex.UseVisualStyleBackColor = true;
            this.btnRightIndex.Visible = false;
            this.btnRightIndex.Click += new System.EventHandler(this.btnRightIndex_Click);
            // 
            // btnRightThumb
            // 
            this.btnRightThumb.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRightThumb.Location = new System.Drawing.Point(7, 259);
            this.btnRightThumb.Name = "btnRightThumb";
            this.btnRightThumb.Size = new System.Drawing.Size(86, 28);
            this.btnRightThumb.TabIndex = 3;
            this.btnRightThumb.Text = "Right Thumb";
            this.btnRightThumb.UseVisualStyleBackColor = true;
            this.btnRightThumb.Click += new System.EventHandler(this.btnRightThumb_Click);
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(183)))), ((int)(((byte)(91)))));
            this.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(183)))), ((int)(((byte)(91)))));
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(570, 596);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(115, 37);
            this.btnClear.TabIndex = 13;
            this.btnClear.Text = "&Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // cmbServices
            // 
            this.cmbServices.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbServices.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbServices.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbServices.FormattingEnabled = true;
            this.cmbServices.Location = new System.Drawing.Point(233, 155);
            this.cmbServices.Name = "cmbServices";
            this.cmbServices.Size = new System.Drawing.Size(452, 31);
            this.cmbServices.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(82)))), ((int)(((byte)(90)))), ((int)(((byte)(93)))));
            this.label5.Location = new System.Drawing.Point(69, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 21);
            this.label5.TabIndex = 54;
            this.label5.Text = "Service *";
            // 
            // grpAvailableIndexes
            // 
            this.grpAvailableIndexes.BackColor = System.Drawing.Color.Transparent;
            this.grpAvailableIndexes.Controls.Add(this.lblIndex5);
            this.grpAvailableIndexes.Controls.Add(this.lblIndex4);
            this.grpAvailableIndexes.Controls.Add(this.lblIndex3);
            this.grpAvailableIndexes.Controls.Add(this.lblIndex2);
            this.grpAvailableIndexes.Controls.Add(this.lblIndex1);
            this.grpAvailableIndexes.Controls.Add(this.lblIndex6);
            this.grpAvailableIndexes.Controls.Add(this.lblIndex7);
            this.grpAvailableIndexes.Controls.Add(this.lblIndex8);
            this.grpAvailableIndexes.Controls.Add(this.lblIndex9);
            this.grpAvailableIndexes.Controls.Add(this.lblIndex10);
            this.grpAvailableIndexes.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAvailableIndexes.Location = new System.Drawing.Point(211, 533);
            this.grpAvailableIndexes.Name = "grpAvailableIndexes";
            this.grpAvailableIndexes.Size = new System.Drawing.Size(494, 69);
            this.grpAvailableIndexes.TabIndex = 55;
            this.grpAvailableIndexes.TabStop = false;
            this.grpAvailableIndexes.Text = "Registered Finger Indexes";
            // 
            // lblIndex5
            // 
            this.lblIndex5.BackColor = System.Drawing.Color.Green;
            this.lblIndex5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex5.ForeColor = System.Drawing.Color.White;
            this.lblIndex5.Location = new System.Drawing.Point(448, 18);
            this.lblIndex5.Name = "lblIndex5";
            this.lblIndex5.Size = new System.Drawing.Size(42, 34);
            this.lblIndex5.TabIndex = 15;
            this.lblIndex5.Text = "Right Little";
            this.lblIndex5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndex4
            // 
            this.lblIndex4.BackColor = System.Drawing.Color.Green;
            this.lblIndex4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex4.ForeColor = System.Drawing.Color.White;
            this.lblIndex4.Location = new System.Drawing.Point(403, 18);
            this.lblIndex4.Name = "lblIndex4";
            this.lblIndex4.Size = new System.Drawing.Size(42, 34);
            this.lblIndex4.TabIndex = 14;
            this.lblIndex4.Text = "Right Ring";
            this.lblIndex4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndex3
            // 
            this.lblIndex3.BackColor = System.Drawing.Color.Green;
            this.lblIndex3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex3.ForeColor = System.Drawing.Color.White;
            this.lblIndex3.Location = new System.Drawing.Point(356, 18);
            this.lblIndex3.Name = "lblIndex3";
            this.lblIndex3.Size = new System.Drawing.Size(44, 34);
            this.lblIndex3.TabIndex = 13;
            this.lblIndex3.Text = "Right Middle";
            this.lblIndex3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndex2
            // 
            this.lblIndex2.BackColor = System.Drawing.Color.Green;
            this.lblIndex2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex2.ForeColor = System.Drawing.Color.White;
            this.lblIndex2.Location = new System.Drawing.Point(311, 18);
            this.lblIndex2.Name = "lblIndex2";
            this.lblIndex2.Size = new System.Drawing.Size(42, 34);
            this.lblIndex2.TabIndex = 12;
            this.lblIndex2.Text = "Right Index";
            this.lblIndex2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndex1
            // 
            this.lblIndex1.BackColor = System.Drawing.Color.Green;
            this.lblIndex1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex1.ForeColor = System.Drawing.Color.White;
            this.lblIndex1.Location = new System.Drawing.Point(262, 17);
            this.lblIndex1.Name = "lblIndex1";
            this.lblIndex1.Size = new System.Drawing.Size(46, 34);
            this.lblIndex1.TabIndex = 11;
            this.lblIndex1.Text = "Right Thumb";
            this.lblIndex1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndex6
            // 
            this.lblIndex6.BackColor = System.Drawing.Color.Green;
            this.lblIndex6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex6.ForeColor = System.Drawing.Color.White;
            this.lblIndex6.Location = new System.Drawing.Point(201, 18);
            this.lblIndex6.Name = "lblIndex6";
            this.lblIndex6.Size = new System.Drawing.Size(46, 34);
            this.lblIndex6.TabIndex = 10;
            this.lblIndex6.Text = "Left Thumb";
            this.lblIndex6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndex7
            // 
            this.lblIndex7.BackColor = System.Drawing.Color.Green;
            this.lblIndex7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex7.ForeColor = System.Drawing.Color.White;
            this.lblIndex7.Location = new System.Drawing.Point(155, 18);
            this.lblIndex7.Name = "lblIndex7";
            this.lblIndex7.Size = new System.Drawing.Size(42, 34);
            this.lblIndex7.TabIndex = 9;
            this.lblIndex7.Text = "Left Index";
            this.lblIndex7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndex8
            // 
            this.lblIndex8.BackColor = System.Drawing.Color.Green;
            this.lblIndex8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex8.ForeColor = System.Drawing.Color.White;
            this.lblIndex8.Location = new System.Drawing.Point(108, 18);
            this.lblIndex8.Name = "lblIndex8";
            this.lblIndex8.Size = new System.Drawing.Size(44, 34);
            this.lblIndex8.TabIndex = 8;
            this.lblIndex8.Text = "Left Middle";
            this.lblIndex8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndex9
            // 
            this.lblIndex9.BackColor = System.Drawing.Color.Green;
            this.lblIndex9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex9.ForeColor = System.Drawing.Color.White;
            this.lblIndex9.Location = new System.Drawing.Point(64, 18);
            this.lblIndex9.Name = "lblIndex9";
            this.lblIndex9.Size = new System.Drawing.Size(42, 34);
            this.lblIndex9.TabIndex = 7;
            this.lblIndex9.Text = "Left Ring";
            this.lblIndex9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIndex10
            // 
            this.lblIndex10.BackColor = System.Drawing.Color.Green;
            this.lblIndex10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndex10.ForeColor = System.Drawing.Color.White;
            this.lblIndex10.Location = new System.Drawing.Point(19, 17);
            this.lblIndex10.Name = "lblIndex10";
            this.lblIndex10.Size = new System.Drawing.Size(42, 34);
            this.lblIndex10.TabIndex = 6;
            this.lblIndex10.Text = "Left Little";
            this.lblIndex10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmNADRAVerification
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1177, 656);
            this.Controls.Add(this.grpAvailableIndexes);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.pbFingerprint);
            this.Controls.Add(this.pnlFingerIndexs);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmbServices);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.cmbFingerIndex);
            this.Controls.Add(this.txtMobileNo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtCNIC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPrompt);
            this.Controls.Add(this.pnlCitizenInformation);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmNADRAVerification";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "e-Khidmat Maraakaz - Biomatric Verfication (BVS)";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmNADRAVerification_FormClosing);
            this.Load += new System.EventHandler(this.frmNADRAVerification_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbFingerprint)).EndInit();
            this.pnlCitizenInformation.ResumeLayout(false);
            this.pnlCitizenInformation.PerformLayout();
            this.pnlFingerIndexs.ResumeLayout(false);
            this.grpAvailableIndexes.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbFingerprint;
        private System.Windows.Forms.TextBox txtPrompt;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCNIC;
        private System.Windows.Forms.Panel pnlCitizenInformation;
        private System.Windows.Forms.Label lblPresentAddress;
        private System.Windows.Forms.Label lblAddressCurrent;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMobileNo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCardExpiry;
        private System.Windows.Forms.Label lblDOB;
        private System.Windows.Forms.Label lblBirthPlace;
        private System.Windows.Forms.ComboBox cmbFingerIndex;
        private System.Windows.Forms.Panel pnlFingerIndexs;
        private System.Windows.Forms.Button btnLeftLittle;
        private System.Windows.Forms.Button btnLeftRing;
        private System.Windows.Forms.Button btnLeftMiddle;
        private System.Windows.Forms.Button btnLeftIndex;
        private System.Windows.Forms.Button btnLeftThumb;
        private System.Windows.Forms.Button btnRightLittle;
        private System.Windows.Forms.Button btnRightRing;
        private System.Windows.Forms.Button btnRightMiddle;
        private System.Windows.Forms.Button btnRightIndex;
        private System.Windows.Forms.Button btnRightThumb;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ComboBox cmbServices;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel pnlLeftThumb;
        private System.Windows.Forms.Panel pnlLeftIndex;
        private System.Windows.Forms.Panel pnlRightLittle;
        private System.Windows.Forms.Panel pnlRightRing;
        private System.Windows.Forms.Panel pnlRightMiddle;
        private System.Windows.Forms.Panel pnlRightIndex;
        private System.Windows.Forms.Panel pnlRightThumb;
        private System.Windows.Forms.Panel pnlLeftLittle;
        private System.Windows.Forms.Panel pnlLeftRing;
        private System.Windows.Forms.Panel pnlLeftMiddle;
        private System.Windows.Forms.GroupBox grpAvailableIndexes;
        private System.Windows.Forms.Label lblIndex5;
        private System.Windows.Forms.Label lblIndex4;
        private System.Windows.Forms.Label lblIndex3;
        private System.Windows.Forms.Label lblIndex2;
        private System.Windows.Forms.Label lblIndex1;
        private System.Windows.Forms.Label lblIndex6;
        private System.Windows.Forms.Label lblIndex7;
        private System.Windows.Forms.Label lblIndex8;
        private System.Windows.Forms.Label lblIndex9;
        private System.Windows.Forms.Label lblIndex10;
    }
}