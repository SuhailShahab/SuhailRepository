﻿namespace PITBFC.FP.Forms
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label Bevel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.btnEnrollment = new System.Windows.Forms.Button();
            this.btnVerification = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnNadraVerification = new System.Windows.Forms.Button();
            this.cboReaders = new System.Windows.Forms.ComboBox();
            this.btnRefreshDevcie = new System.Windows.Forms.Button();
            Bevel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Bevel
            // 
            Bevel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            Bevel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            Bevel.Location = new System.Drawing.Point(12, 167);
            Bevel.Name = "Bevel";
            Bevel.Size = new System.Drawing.Size(365, 3);
            Bevel.TabIndex = 3;
            // 
            // label1
            // 
            label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            label1.Location = new System.Drawing.Point(12, 255);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(365, 3);
            label1.TabIndex = 4;
            // 
            // label2
            // 
            label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            label2.Location = new System.Drawing.Point(12, 339);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(365, 3);
            label2.TabIndex = 7;
            // 
            // btnEnrollment
            // 
            this.btnEnrollment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(183)))), ((int)(((byte)(91)))));
            this.btnEnrollment.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(183)))), ((int)(((byte)(91)))));
            this.btnEnrollment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEnrollment.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnrollment.ForeColor = System.Drawing.Color.White;
            this.btnEnrollment.Location = new System.Drawing.Point(17, 101);
            this.btnEnrollment.Name = "btnEnrollment";
            this.btnEnrollment.Size = new System.Drawing.Size(353, 40);
            this.btnEnrollment.TabIndex = 0;
            this.btnEnrollment.Text = "Citizen Enrollment";
            this.btnEnrollment.UseVisualStyleBackColor = false;
            this.btnEnrollment.Click += new System.EventHandler(this.btnEnrollment_Click);
            // 
            // btnVerification
            // 
            this.btnVerification.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.btnVerification.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(183)))), ((int)(((byte)(91)))));
            this.btnVerification.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVerification.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerification.ForeColor = System.Drawing.Color.White;
            this.btnVerification.Location = new System.Drawing.Point(17, 193);
            this.btnVerification.Name = "btnVerification";
            this.btnVerification.Size = new System.Drawing.Size(353, 40);
            this.btnVerification.TabIndex = 1;
            this.btnVerification.Text = "Citizen Verification";
            this.btnVerification.UseVisualStyleBackColor = false;
            this.btnVerification.Click += new System.EventHandler(this.btnVerification_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(79)))), ((int)(((byte)(73)))));
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(79)))), ((int)(((byte)(73)))));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(244, 353);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(121, 35);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnNadraVerification
            // 
            this.btnNadraVerification.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(78)))), ((int)(((byte)(153)))), ((int)(((byte)(0)))));
            this.btnNadraVerification.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(91)))), ((int)(((byte)(183)))), ((int)(((byte)(91)))));
            this.btnNadraVerification.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNadraVerification.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNadraVerification.ForeColor = System.Drawing.Color.White;
            this.btnNadraVerification.Location = new System.Drawing.Point(17, 277);
            this.btnNadraVerification.Name = "btnNadraVerification";
            this.btnNadraVerification.Size = new System.Drawing.Size(353, 40);
            this.btnNadraVerification.TabIndex = 6;
            this.btnNadraVerification.Text = "Biometric Verification (BOP)";
            this.btnNadraVerification.UseVisualStyleBackColor = false;
            this.btnNadraVerification.Click += new System.EventHandler(this.btnNadraVerification_Click);
            // 
            // cboReaders
            // 
            this.cboReaders.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cboReaders.Location = new System.Drawing.Point(70, 48);
            this.cboReaders.Name = "cboReaders";
            this.cboReaders.Size = new System.Drawing.Size(256, 21);
            this.cboReaders.TabIndex = 15;
            this.cboReaders.Visible = false;
            // 
            // btnRefreshDevcie
            // 
            this.btnRefreshDevcie.BackColor = System.Drawing.Color.Green;
            this.btnRefreshDevcie.FlatAppearance.BorderColor = System.Drawing.Color.Green;
            this.btnRefreshDevcie.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefreshDevcie.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshDevcie.ForeColor = System.Drawing.Color.White;
            this.btnRefreshDevcie.Location = new System.Drawing.Point(117, 353);
            this.btnRefreshDevcie.Name = "btnRefreshDevcie";
            this.btnRefreshDevcie.Size = new System.Drawing.Size(121, 35);
            this.btnRefreshDevcie.TabIndex = 16;
            this.btnRefreshDevcie.Text = "Refresh";
            this.btnRefreshDevcie.UseVisualStyleBackColor = false;
            this.btnRefreshDevcie.Click += new System.EventHandler(this.btnRefreshDevcie_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(389, 406);
            this.Controls.Add(this.btnRefreshDevcie);
            this.Controls.Add(this.cboReaders);
            this.Controls.Add(label2);
            this.Controls.Add(this.btnNadraVerification);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(label1);
            this.Controls.Add(Bevel);
            this.Controls.Add(this.btnVerification);
            this.Controls.Add(this.btnEnrollment);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMain";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "e-Khidmat Maraakaz";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEnrollment;
        private System.Windows.Forms.Button btnVerification;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnNadraVerification;
        internal System.Windows.Forms.ComboBox cboReaders;
        private System.Windows.Forms.Button btnRefreshDevcie;
    }
}