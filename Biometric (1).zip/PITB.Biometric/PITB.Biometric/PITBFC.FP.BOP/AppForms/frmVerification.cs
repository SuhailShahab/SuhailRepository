﻿using DPUruNet;
using PITBFC.FP.ApplicationClass;
using PITBFC.FP.Module.BusinessLoginLayer;
using PITBFC.FP.Module.DataModelLayer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Windows.Forms;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <05-03-2015 03:20:33PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
// =================================================================================================================================
namespace PITBFC.FP.Forms
{
    public partial class frmVerification : Form
    {
        #region "Variable"

        public frmMain _sender;

        //private DPFP.Capture.Capture Capturer;
        //private DPFP.Verification.Verification Verifier;

        private const int DPFJ_PROBABILITY_ONE = 0x7fffffff;

        #endregion

        #region "Constructor"

        public frmVerification()
        {
            InitializeComponent();
        }

        #endregion

        #region "DPFP Interface Methods"

        /*
        public void OnComplete(object Capture, string ReaderSerialNumber, DPFP.Sample Sample)
        {
            Process(Sample);
        }

        public void OnFingerGone(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnFingerTouch(object Capture, string ReaderSerialNumber)
        {
            SetControlValue(null);
        }

        public void OnReaderConnect(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnReaderDisconnect(object Capture, string ReaderSerialNumber)
        {
            //throw new NotImplementedException();
        }

        public void OnSampleQuality(object Capture, string ReaderSerialNumber, DPFP.Capture.CaptureFeedback CaptureFeedback)
        {
            //throw new NotImplementedException();
        }
        */
        #endregion

        #region "DPFP Related Methods"

        /*
        protected void Init()
        {
            try
            {
                Capturer = new DPFP.Capture.Capture();				// Create a capture operation.


                if (null != Capturer)
                {
                    Capturer.EventHandler = this;					    // Subscribe for capturing events.
                    Verifier = new DPFP.Verification.Verification();	// Create a verifier.
                }
                else
                    SetPrompt("Can't initiate capture operation!");
            }
            catch
            {
                MessageBox.Show("Can't initiate capture operation!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        protected void Start()
        {
            if (null != Capturer)
            {
                try
                {
                    Capturer.StartCapture();
                    //SetPrompt("Using the fingerprint reader, scan your fingerprint.");
                }
                catch
                {
                    SetPrompt("Can't initiate capture!");
                }
            }
        }

        protected void Stop()
        {
            if (null != Capturer)
            {
                try
                {
                    Capturer.StopCapture();
                }
                catch
                {
                    SetPrompt("Can't terminate capture!");
                }
            }
        }

        protected void Process(DPFP.Sample Sample)
        {
            bool Verified = false;

            try
            {
                // Draw fingerprint sample image.
                DrawPicture(ConvertFPImageToBitmap(Sample));

                // Process the sample and create a feature set for the enrollment purpose.
                DPFP.FeatureSet features = ExtractFeatures(Sample, DPFP.Processing.DataPurpose.Verification);

                // Check quality of the sample and add to enroller if it's good
                if (features != null)
                {
                    //List<NICRecordModel> records = Global.records;
                    //if (records == null) 
                    List<NICRecordModel> records = new NICRecordBLL().GetNadraCNICRecord();

                    ImageConverter _imgCOn = new ImageConverter();
                    //Bitmap _bitMap = null;

                    foreach (NICRecordModel rm in records)
                    {
                        if (rm.FingerImpression != null)
                        {
                            DPFP.Template DeserializeTemplate = new DPFP.Template();
                            DeserializeTemplate.DeSerialize(rm.FingerImpression);
                            
                            DPFP.Verification.Verification.Result result = new DPFP.Verification.Verification.Result();
                            Verifier.Verify(features, DeserializeTemplate, ref result);
                            if (result.Verified)
                            {
                                // set information to controls
                                SetControlValue(rm);
                                Verified = true;
                                break;
                            }
                        }
                    }

                    if (Verified == false)
                        SetPrompt("No Record Found!");
                    else
                        SetPrompt("Verified");
                }
            }
            catch (DPFP.Error.SDKException e)
            {
                MessageBox.Show(e.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        */
        #endregion

        #region "Method"

        /*protected Bitmap ConvertFPImageToBitmap(DPFP.Sample Sample)
        {
            DPFP.Capture.SampleConversion Convertor = new DPFP.Capture.SampleConversion();	// Create a sample convertor.
            Bitmap bitmap = null;												            // TODO: the size doesn't matter
            Convertor.ConvertToPicture(Sample, ref bitmap);									// TODO: return bitmap as a result
            return bitmap;
        }

        protected void SetStatus(string status)
        {
            this.Invoke(new Function(delegate()
            {
                lblStatus.Text = status;
            }));
        }

        protected void SetPrompt(string prompt)
        {
            this.Invoke(new Function(delegate()
            {
                txtPrompt.Text = prompt;
            }));
        }

        private void DrawPicture(Bitmap bitmap)
        {
            this.Invoke(new Function(delegate()
            {
                Picture.Image = new Bitmap(bitmap, Picture.Size);	// fit the image into the picture box
            }));
        }

        protected DPFP.FeatureSet ExtractFeatures(DPFP.Sample Sample, DPFP.Processing.DataPurpose Purpose)
        {
            DPFP.Processing.FeatureExtraction Extractor = new DPFP.Processing.FeatureExtraction();	// Create a feature extractor
            DPFP.Capture.CaptureFeedback feedback = DPFP.Capture.CaptureFeedback.None;
            DPFP.FeatureSet features = new DPFP.FeatureSet();
            Extractor.CreateFeatureSet(Sample, Purpose, ref feedback, ref features);			// TODO: return features as a result?
            if (feedback == DPFP.Capture.CaptureFeedback.Good)
                return features;
            else
                return null;
        }

         * */

        protected void SetControlValue(NICRecordModel vrm)
        {
            this.Invoke(new Function(delegate()
            {
                if (vrm != null)
                {
                    lblCNIC.Text = vrm.CNIC;
                    txtCNIC.Text = vrm.CNIC;
                    lblName.Text = vrm.Name;
                    lblNameFather.Text = vrm.FatherName;
                    lblContactNo.Text = vrm.ContactNo;
                    lblParmanentAddress.Text = vrm.PermanentAddress;
                    lblCurrentAddress.Text = vrm.CurrentAddressUrdu;
                }
                else
                {
                    lblCNIC.Text = "";
                    txtCNIC.Text = "";
                    lblName.Text = "";
                    lblNameFather.Text = "";
                    lblContactNo.Text = "";
                    lblParmanentAddress.Text = "";
                    lblCurrentAddress.Text = "";
                }
            }));
        }

        private void ResetControls()
        {
            lblCNIC.ResetText();
            lblName.ResetText();
            lblNameFather.ResetText();
            lblParmanentAddress.ResetText();
            lblCurrentAddress.ResetText();
            lblContactNo.ResetText();

            lblStatus.ResetText();
            txtPrompt.Text = "Fingerprint reader is ready, scan your finger";
        }

        #endregion

        #region "Form Events"

        private void frmVerification_Load(object sender, EventArgs e)
        {
            try
            {
                //Init();
                //Start();

                //=============SDK=====================
                // Reset variables
                Picture.Image = null;

                if (!_sender.OpenReader())
                {

                    this.Close();
                }

                if (!_sender.StartCaptureAsync(this.OnCaptured))
                {
                    this.Close();
                }
                //=====================================

                ResetControls();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmVerification_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //Stop();
                _sender.CancelCaptureAndCloseReader(this.OnCaptured);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region "UrU SDK Methods"

        /// <summary>
        /// Handler for when a fingerprint is captured.
        /// </summary>
        /// <param name="captureResult">contains info and data on the fingerprint capture</param>
        public void OnCaptured(CaptureResult captureResult)
        {
            bool verified = false;

            try
            {
                // Check capture quality and throw an error if bad.
                if (!_sender.CheckCaptureResult(captureResult)) return;

                DataResult<Fmd> resultConversion = FeatureExtraction.CreateFmdFromFid(captureResult.Data, Constants.Formats.Fmd.DP_VERIFICATION);
                if (resultConversion.ResultCode != Constants.ResultCode.DP_SUCCESS)
                {
                    _sender.Reset = true;
                    throw new Exception(resultConversion.ResultCode.ToString());
                }

                // Create bitmap
                foreach (Fid.Fiv fiv in captureResult.Data.Views)
                {
                    SendMessage(Action.SendBitmap, this._sender.CreateBitmap(fiv.RawImage, fiv.Width, fiv.Height));
                }

                Fmd captureFigure = resultConversion.Data;
                List<NICRecordModel> records = null;

                if (string.IsNullOrEmpty(txtCNIC.Text))
                    records = new NICRecordBLL().GetNadraCNICRecord();
                else
                    records = new NICRecordBLL().GetNadraCNICRecord(txtCNIC.Text);

                if (records != null)
                {
                    Fmd[] fmds = new Fmd[1];
                    foreach (NICRecordModel rm in records)
                    {
                        /*if (string.IsNullOrEmpty(rm.FignerPrint) == false)
                        {
                            // regenerate FMD of against saved finger template
                            fmds[0] = Fmd.DeserializeXml(rm.FignerPrint);

                            DPUruNet.IdentifyResult ir = Comparison.Identify(captureFigure, 0, fmds, 21474, 5);
                            if (ir.ResultCode == Constants.ResultCode.DP_SUCCESS)
                            {
                                if (ir.Indexes.Length > 0)
                                {
                                    SendMessage(Action.SendPrompt, "Matched");
                                    SetControlValue(rm);
                                    _sender.Reset = true;
                                    verified = true;
                                }
                            }
                        }*/

                        if (rm.FingerImpression != null)
                        {
                            // generate FMD against saved template bytes
                            fmds[0] = new Fmd(rm.FingerImpression, 1, "1.0.0");

                            DPUruNet.IdentifyResult ir = Comparison.Identify(captureFigure, 0, fmds, 21474, 1);
                            if (ir.ResultCode == Constants.ResultCode.DP_SUCCESS)
                            {
                                if (ir.Indexes.Length > 0)
                                {
                                    SendMessage(Action.SendPrompt, "Matched");
                                    SetControlValue(rm);
                                    _sender.Reset = true;
                                    verified = true;
                                    break;
                                }
                            }
                        }
                    }

                    if (verified == false)
                    {
                        SendMessage(Action.SendPrompt, "No Record Found!");
                        SetControlValue(null);
                        _sender.Reset = true;
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(txtCNIC.Text))
                        SendMessage(Action.SendPrompt, "CNIC is register with e-Khidmat Maraakaz");
                    
                    SetControlValue(null);
                    _sender.Reset = true;
                }

                Cursor.Current = Cursors.Default;
                this.Enabled = true;
            }
            catch (DPUruNet.SDKException e)
            {
                MessageBox.Show(e.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "e-Khidmat Maraakaz", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Custom Event/Delegate of SDK

        private delegate void SendMessageCallback(Action action, object payload);
        private void SendMessage(Action action, object payload)
        {
            try
            {
                if (this.Picture.InvokeRequired)
                {
                    SendMessageCallback d = new SendMessageCallback(SendMessage);
                    this.Invoke(d, new object[] { action, payload });
                }
                else
                {
                    switch (action)
                    {
                        case Action.SendMessage:
                            lblStatus.Text = (string)payload;
                            break;
                        case Action.SendPrompt:
                            txtPrompt.Text = (string)payload;
                            break;
                        case Action.SendBitmap:
                            Picture.Image = (Bitmap)payload;
                            Picture.Refresh();
                            break;
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        #endregion

        #region Custom Emum of SDK

        private enum Action
        {
            SendBitmap,
            SendMessage,
            SendPrompt
        }

        #endregion

        #region "TextBox Events"

        private void txtCNIC_KeyDown(object sender, KeyEventArgs e)
        {
            if (!(e.KeyCode == Keys.Back || (e.KeyValue >= 48 && e.KeyValue <= 57) || (e.KeyCode >= Keys.NumPad0 && e.KeyCode <= Keys.NumPad9)))
            {
                e.SuppressKeyPress = true;
            }

        }

        #endregion
    }
}
