﻿using BLL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.SchedulerInfo;
using SMS.CMP.BLL.SMSQueue;
using SMS.Queue.ApplicationClassess;
using SMS.Queue.ApplicationClassess.Log;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;
using SMS.CMP.BE.CustomEnums;

// =================================================================================================================================
// Create by:	<Suhail Shahab>
// Create date: <21-10-2015 07:47:38>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
//CR:001            SUHAIL SHAHAB                   26-06-2015                  Add Email functionality
// =================================================================================================================================
namespace SMS.Queue.ApplicationClasses
{
    public class MainThread
    {
        int reTrytoSendSms = 0;
        /// <summary>
        ///// Create the Main Thread
        ///// </summary>
        public void StartThread()
        {
            Thread mT = new Thread(Main);
            mT.Start();
        }

        /// <summary>
        /// Main Tread Start the process
        /// </summary>
        public void Main()
        {
            string webForntEnd = ConfigurationHelper.IPSecondWebFornt; //"192.168.10.3";
            WebForntNames currentRunningWebFornt = CommonHelper.GetWebForntEnum(ConfigurationHelper.CurrentRuningWebFront);     // WebForntNames.WEB_FORNT1;
            WebForntNames secodWebFornt = CommonHelper.GetWebForntEnum(ConfigurationHelper.SecondWebFront);     // WebForntNames.WEB_FORNT2;
            
            bool isTransportError = false;
            try
            {
                B2BayLogger.Log("Execute Applciation with version no: 036....");
                B2BayLogger.Log("Only Telenor SMS");
               // B2BayLogger.Log("SMS of ZONG Ufone and Telenor to Jazz Off-Net API starting from 1st Oct 2021");
              //  B2BayLogger.WriteLogsToFile();
                while (true)
                {
                    Console.WriteLine("Applciation start version no: 036....");
                    B2BayLogger.Log("Only Telenor SMS");
                   // Console.WriteLine("SMS of ZONG Ufone and Telenor to Jazz Off-Net API starting from 1st Oct 2021");
                    B2BayLogger.Log("Applciation start version no: 036....");
                    Thread.Sleep(1000);
                    Console.WriteLine("HostingIP Address"+ConfigurationHelper.HostingIP);
                   // B2BayLogger.WriteLogsToFile();
                   // bool isPinged = CommonHelper.PingHost(webForntEnd);         // check primary server
                   // if (isPinged)
                    if (true)
                    {
                        Console.WriteLine("Check Active Web Fornt.");
                        bool isActiveServer = LazySingletonBLL<ServerInfoBLL>.Instance.IsActiveServer(secodWebFornt.GetHashCode());
                       // if (!isActiveServer)
                        //throw new  Exception("A transport-level error");
                        if (!isActiveServer)
                        {
                                               

                            if (LazySingletonBLL<SMSQueueBLL>.Instance.IsExistPendingSMSQueue())
                            {
                                Console.WriteLine("Send Request for Starting Que Based SMS Send Request ....");
                               
                                Console.WriteLine("Get Active Telcos..");
                                B2BayLogger.Log("Get Active Telcos...");
                                // Initiate Task Based Thread
                                List<SMSConfigurationModel> colTelcos = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetActiveTelcos();
                                
                                //Get only Telnor message 
                                //colTelcos = colTelcos.Where(t => t.TelcoID == TelcoNames.Telenor.GetHashCode()).ToList();
                                //Get All Telco except Telenor
                                colTelcos = colTelcos.Where(t => t.TelcoID != TelcoNames.Telenor.GetHashCode()).ToList();

                                if (colTelcos != null && colTelcos.Count > 0)
                                {
                                    int noOfThreads = colTelcos.Count; //ConfigurationHelper.NoOfThreads;

                                    Task[] taskArray = null;
                                    taskArray = new Task[noOfThreads];

                                    for (int j = 0; j < noOfThreads; j++)
                                    {
                                        SMSConfigurationModel configModel = colTelcos[j];                                        

                                        taskArray[j] = Task.Factory.StartNew((Object obj) =>
                                        {
                                            SMSQueue smsQueue = new SMSQueue(configModel.SMSThroughput);
                                            smsQueue.SendQuesueSMS(configModel.TelcoID, null);

                                        }, j);
                                        string threadInfo = "Thread TelcoID " + configModel.TelcoID + " SMSThroughput " + configModel.SMSThroughput;
                                        Console.WriteLine(threadInfo);
                                        B2BayLogger.Log(threadInfo);
                                    }

                                    try
                                    {
                                        B2BayLogger.Log("Wait for Completion of task---");
                                        Task.WaitAll(taskArray);
                                        Console.WriteLine("Start Flushing the Buffere..");
                                        B2BayLogger.Log("Start Flushing the Buffere..");
                                        //======================= Purge whole Buffer Data with IS Send is "3" =======================================
                                        LazySingleton<SMSQueueBLL>.Instance.PurgeBufferData();
                                        //=============================================================================================================
                                        reTrytoSendSms = 0;
                                        Console.WriteLine("End Flushing the Buffere..");
                                        B2BayLogger.Log("End Flushing the Buffere..");

                                    }
                                    catch
                                    { }

                                    B2BayLogger.Log("Request Send Successfully");
                                    Console.WriteLine("Request Send Successfully");

                                    B2BayLogger.WriteLogsToFile();
                                    Thread.Sleep(1000);
                                }
                                else
                                {
                                    Console.WriteLine("There is no active telcos exist.");
                                    B2BayLogger.Log("There is no active telcos exist.");
                                    Thread.Sleep(1000);
                                }
                            }
                            else
                            {                              

                                Console.WriteLine("No Pending SMS Queue Exist");
                                B2BayLogger.WriteLogsToFile();
                                Thread.Sleep(10000);
                            }

                        }
                        else
                        {
                            Console.WriteLine("Another Web Front End server is Active.");
                            B2BayLogger.Log("Another Web Front End server is Active.");
                            B2BayLogger.WriteLogsToFile();
                            int maxDelay = ConfigurationHelper.MaxRequestDelay * 2;
                            Thread.Sleep(maxDelay);
                        }
                    }
                    else //not runing
                    {
                        Console.WriteLine("Check Active Web Fornt.");
                        bool isActiveServer = LazySingletonBLL<ServerInfoBLL>.Instance.IsActiveServer(secodWebFornt.GetHashCode());
                        if (!isActiveServer)
                        {
                          //  Thread.Sleep(ConfigurationHelper.MaxRequestDelay);

                            if (LazySingletonBLL<SMSQueueBLL>.Instance.IsExistPendingSMSQueue())
                            {
                                Console.WriteLine("Send Request for Starting Que Based SMS Send Request ....");
                                B2BayLogger.Log("Send Request for Starting Que Based SMS Send Request ....");

                                Console.WriteLine("Get Active Telcos..");
                                B2BayLogger.Log("Get Active Telcos...");
                                // Initiate Task Based Thread
                                List<SMSConfigurationModel> colTelcos = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetActiveTelcos();
                                if (colTelcos != null && colTelcos.Count > 0)
                                {
                                    int noOfThreads = colTelcos.Count; //ConfigurationHelper.NoOfThreads;

                                    Task[] taskArray = null;
                                    taskArray = new Task[noOfThreads];

                                    for (int j = 0; j < noOfThreads; j++)
                                    {
                                        SMSConfigurationModel configModel = colTelcos[j];
                                       

                                        taskArray[j] = Task.Factory.StartNew((Object obj) =>
                                         {
                                             //SMSQueue.SendQuesueSMS();
                                             SMSQueue smsQueue = new SMSQueue(configModel.SMSThroughput);
                                             smsQueue.SendQuesueSMS(configModel.TelcoID, null);

                                         }, j);
                                    }

                                    try
                                    {
                                        Task.WaitAll(taskArray);
                                        //======================= Purge whole Buffer Data with IS Send is "3" =======================================
                                        LazySingleton<SMSQueueBLL>.Instance.PurgeBufferData();
                                        //=============================================================================================================
                                        B2BayLogger.Log("Wait after deletion");
                                        //Thread.Sleep(20000);
                                    }
                                    catch
                                    { }

                                    B2BayLogger.Log("Request Send Successfully");
                                    Console.WriteLine("Request Send Successfully");

                                    Thread.Sleep(1000);
                                }
                                else
                                {
                                    Console.WriteLine("There is no active telcos exist.");
                                    B2BayLogger.Log("There is no active telcos exist.");
                                    Thread.Sleep(1000);

                                   
                                }
                            }
                            else 
                            {
                                Console.WriteLine("No Pending SMS Queue Exist");
                                Thread.Sleep(2000);
                                
                            }
                        }
                        else if (isActiveServer)
                        {

                            Console.WriteLine("Update Active Server.");
                            B2BayLogger.Log("Update Active Server.");
                            LazySingletonBLL<ServerInfoBLL>.Instance.UpdateServerActive(currentRunningWebFornt.GetHashCode());
                            
                        }
                    }

                    B2BayLogger.WriteLogsToFile();
                }
                //End of While
                
            }
            catch (Exception e)
            {
                if (e.Message.Contains("A transport-level error") || e.Message.Contains("network-related or instance-specific error"))
                {
                    reTrytoSendSms++;
                    isTransportError = true;
                }
                else
                {
                    isTransportError = false;
                }
                B2BayLogger.LogErr("Error:", e);
                Console.WriteLine(e.Message);
                B2BayLogger.WriteLogsToFile();

                // ============================================ Send Email Notification ============================================ //
                if ( ConfigurationHelper.EnableEMailNotification)
                {
                    CommonHelper.SendNotificationEmail("SMS Queue Schulder have some issue" + e.Message);
                }
                    
            }
            finally
            {
                //==============Retry to send SMS==============

                if (isTransportError)
                {
                    if (reTrytoSendSms > 3)
                    {

                        if (ConfigurationHelper.EnableEMailNotification)
                            CommonHelper.SendNotificationEmail(" SMS Queue  Schulder have been Deleay 5 min due to Tranport Error");
                       // Environment.Exit(0);
                        this.LogAndMessage("Deleay 5 min due to Tranport Error");
                        B2BayLogger.WriteLogsToFile();
                        Thread.Sleep(300000);
                        this.Main();
                        
                    }
                    else
                    {
                        Console.WriteLine("Re Try to run (" + reTrytoSendSms.ToString() + ")");
                        B2BayLogger.Log("Re Try to run (" + reTrytoSendSms.ToString() + ")");
                        Thread.Sleep(2000);
                        B2BayLogger.WriteLogsToFile();
                        this.Main();
                       
                    }

                }
                else
                {
                    if (ConfigurationHelper.EnableEMailNotification)
                        CommonHelper.SendNotificationEmail(" SMS Queue  Schulder have been Stop due to some issue");
                   // Environment.Exit(0);
                    this.LogAndMessage("Deleay 5 min due to unknow Erorr Error");
                    B2BayLogger.WriteLogsToFile();
                    Thread.Sleep(300000);                    
                    this.Main();
                    
                }
                //==============END Retry to send SMS==============
            }


           
        }

      public  void LogAndMessage(string message)
      {
          Console.WriteLine(message);
          B2BayLogger.Log(message);
      }

   

      
    }
}
