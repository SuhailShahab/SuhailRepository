﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.CustomEnums;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.BLL.CMP;
//using SMS.CMP.BE.SMSQueue;
using SMS.CMP.BLL.SMSQueue;
using SMS.Queue.ApplicationClasses.SMSRequest;
using SMS.Queue.ApplicationClassess;
using SMS.Queue.ApplicationClassess.Log;
using SMS.Queue.CustomExceptions;
using System;
using System.Collections.Generic;
using System.Threading;
//==========================
/*
 * Implimention of vlaidation of phone number
*/
//==========================

namespace SMS.Queue.ApplicationClasses
{
    public class SMSQueue
    {
        //private int TelcoID { get; set; }
        private int? SMSThroughputRate { get; set; }
        //public static void SendQuesueSMS()
        //{
        //    B2BayLogger.Log("Starting Quesue SMS....");

        //    SMSQueueModel queueItem = null; 

        //    try
        //    {
        //        B2BayLogger.Log("Get Quesue SMS....");

        //        /// Set ISSend Status to "100" 
        //        /// Add Endtry to Transaction Table.
        //        List<SMSQueueModel> queuesList = LazySingleton<SMSQueueBLL>.Instance.GetNextSMSQueue();

        //        if (queuesList != null && queuesList.Count > 0)
        //        {
        //            foreach (SMSQueueModel item in queuesList)
        //            {
        //                //Add record in SMSTransaction and update the status 
        //                try
        //                {
        //                    queueItem = item;
        //                    //======================= Send SMS To Service =============================================================
        //                    LazySingleton<BulkSendSMSRequest>.Instance.SendSMS(item);
        //                    //=============================================================================================================
        //                    //======================= Mark IsSend Status to "101" =============================================================
        //                    LazySingletonBLL<SMSQueueBLL>.Instance.MarkSMSQueueSendStatus(new SMSQueueModel()
        //                    {
        //                        ID = item.ID	
        //                    });

        //                    //======================= Mark IsSend Status to "3" =============================================================
                            
        //                }
        //                catch (Exception ex)
        //                {
        //                    if(queueItem!=null && queueItem.SMSSendingID > 0 )
        //                    {
        //                        // Mark Failure record as "SendError" in Queue Buffered
        //                        LazySingletonBLL<SMSQueueBLL>.Instance.SetQueueDeliveryStatus(new SMSQueueModel()
        //                        {
        //                            OrganizationID = queueItem.OrganizationID,
        //                            CampaignID = queueItem.CampaignID,
        //                            DeliveryStatusID = SMSDeliveryStatuses.SendError.GetHashCode(),
        //                            ID= queueItem.ID,
        //                            TelcoID = queueItem.TelcoID,
        //                            IsOnNet = queueItem.IsOnNet
        //                        });


        //                    // string[] ids = queueItem.SMSSendingID.Split('-');

        //                    //======================= Fail Send SMS To Service =============================================================
        //                    LazySingletonBLL<SMSTransactionBLL>.Instance.UpdateSMSDeliveryStatus(new SMSTransactionModel()
        //                    {
        //                        OrganizationID = queueItem.OrganizationID,
        //                        CampaignID = queueItem.CampaignID,
        //                        SMSSendingID = queueItem.SMSSendingID,
        //                        DeliveryStatusID = SMSDeliveryStatuses.SendError.GetHashCode(),
        //                        ContactNo = queueItem.Phone,
        //                        Network = "",
        //                        TelcoID = queueItem.TelcoID,
        //                        IsOnNet = queueItem.IsOnNet
        //                    });
        //                    //======================= Send SMS To Service =============================================================
        //                    B2BayLogger.Log("Message Fail");
        //                    B2BayLogger.Log("Message " + item.SendMessage + "ShortCode " + item.ShortCode + "organizationID " + item.OrganizationID + "capaignID " + item.CampaignID + "SMSQueueID " + item.ID);
        //                    B2BayLogger.Log("Error " + ex.Message);
        //                    B2BayLogger.WriteLogsToFile();
        //                    }  
        //                    else
        //                    {
        //                        B2BayLogger.Log("Error " + ex.Message);
        //                        B2BayLogger.WriteLogsToFile();
        //                    }


        //                }
        //                //finally
        //                //{
        //                //    B2BayLogger.Log("Message " + item.SendMessage + "ShortCode " + item.ShortCode + "organizationID " + item.OrganizationID + "capaignID " + item.CampaignID + "SMSQueueID " + item.ID);
                           
        //                //}

        //                B2BayLogger.WriteLogsToFile();
        //            }//End of Loop

        //            if(queuesList!=null && queuesList.Count>0)
        //            {
        //                Console.WriteLine("Delay for SMs.");
        //                int Delay = queuesList.Count * 60;
        //                B2BayLogger.Log("*** Delay for sending sms***");
        //                Thread.Sleep(Delay);
        //            }

                   

        //        }
        //        else
        //        {
        //            B2BayLogger.Log("*** NO Record found ***");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SendQuesueSMS" + ex.Message, 1, PageNames.SMS_QueueScheduler, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.LogErr(ex.Message, ex);
        //        B2BayLogger.WriteLogsToFile();
        //    }

        //    B2BayLogger.WriteLogsToFile();
        //}

        public SMSQueue()
        {

        }
        public SMSQueue(int? smsThroughput)
        {
            this.SMSThroughputRate = smsThroughput;
        }
        public void SendQuesueSMS(int? telcoID, List<SMSQueueModel> queuesList)
        {
            B2BayLogger.Log("Starting Quesue SMS....");

            SMSQueueModel queueItem = null;

            try
            {
                B2BayLogger.Log("Get Quesue SMS....");

                /// Set ISSend Status to "100" 
                /// Add Endtry to Transaction Table.
                queuesList = queuesList != null ? queuesList : LazySingleton<SMSQueueBLL>.Instance.GetNextSMSQueueByIDs(telcoID, this.SMSThroughputRate);

                if (queuesList != null && queuesList.Count > 0)
                {
                    Thread.Sleep(1000);
                    Console.WriteLine("Telco ID " + telcoID);
                    Console.WriteLine("Total SMS Fetch " + queuesList.Count);

                    foreach (SMSQueueModel item in queuesList)
                    {
                        //Add record in SMSTransaction and update the status 
                        try
                        {
                            queueItem = item;
                            string phone = item.Phone;
                           //========================Phone Validation=============================================================
                            if (phone.Length == 11 && phone.Substring(0, 2) == "03")
                            {
                                //======================= Send SMS To Service ====================================================
                                LazySingleton<BulkSendSMSRequest>.Instance.SendSMS(item);
                            }
                            else if (phone.Length == 12 && phone.Substring(0, 3) == "923")
                            {
                                //======================= Send SMS To Service ====================================================
                                LazySingleton<BulkSendSMSRequest>.Instance.SendSMS(item);
                            }
                            else
                            {
                                Console.WriteLine("Invlaid Phone Number " + phone);
                                B2BayLogger.Log("Invlaid Phone Number " + phone);
                            }
                            
                            //=============================================================================================================
                            //======================= Mark IsSend Status to "101" =============================================================
                            LazySingletonBLL<SMSQueueBLL>.Instance.MarkSMSQueueSendStatus(new SMSQueueModel()
                            {
                                ID = item.ID
                            });

                            //======================= Mark IsSend Status to "3" =============================================================

                        }
                        catch (TelnorBuisnessException ex)
                        {
                            B2BayLogger.Log("Error " + ex.ErrorFullMessage);
                           /// B2BayLogger.WriteLogsToFile();

                            //==Update the Delivery Status
                            UpdateStatusAfterException(queueItem, item, ex);
                        }
                        catch (Exception ex)
                        {
                            if (queueItem != null && queueItem.SMSSendingID > 0)
                            {
                                // Mark Failure record as "SendError" in Queue Buffered
                                LazySingletonBLL<SMSQueueBLL>.Instance.SetQueueDeliveryStatus(new SMSQueueModel()
                                {
                                    OrganizationID = queueItem.OrganizationID,
                                    CampaignID = queueItem.CampaignID,
                                    DeliveryStatusID = SMSDeliveryStatuses.SendError.GetHashCode(),
                                    ID = queueItem.ID,
                                    TelcoID = queueItem.TelcoID,
                                    IsOnNet = queueItem.IsOnNet
                                });


                                // string[] ids = queueItem.SMSSendingID.Split('-');

                                //======================= Fail Send SMS To Service =============================================================
                                LazySingletonBLL<SMSTransactionBLL>.Instance.UpdateSMSDeliveryStatus(new SMSTransactionModel()
                                {
                                    OrganizationID = queueItem.OrganizationID,
                                    CampaignID = queueItem.CampaignID,
                                    SMSSendingID = queueItem.SMSSendingID,
                                    DeliveryStatusID = SMSDeliveryStatuses.SendError.GetHashCode(),
                                    ContactNo = queueItem.Phone,
                                    Network = "",
                                    TelcoID = queueItem.TelcoID,
                                    IsOnNet = queueItem.IsOnNet
                                });
                                //======================= Send SMS To Service =============================================================
                                B2BayLogger.Log("Message Fail");
                                B2BayLogger.Log("Message " + item.SendMessage + "ShortCode " + item.ShortCode + "organizationID " + item.OrganizationID + "capaignID " + item.CampaignID + "SMSQueueID " + item.ID);
                                B2BayLogger.Log("Error " + ex.Message);
                              //  B2BayLogger.WriteLogsToFile();
                            }
                            else
                            {
                                B2BayLogger.Log("Error " + ex.Message);
                               // B2BayLogger.WriteLogsToFile();
                            }


                        }
                        //finally
                        //{
                        //    B2BayLogger.Log("Message " + item.SendMessage + "ShortCode " + item.ShortCode + "organizationID " + item.OrganizationID + "capaignID " + item.CampaignID + "SMSQueueID " + item.ID);

                        //}

                      //  B2BayLogger.WriteLogsToFile();
                    }//End of Loop

                    if (queuesList != null && queuesList.Count>0)
                    {
                        queuesList = LazySingleton<SMSQueueBLL>.Instance.GetNextSMSQueueByIDs(telcoID,this.SMSThroughputRate);
                        if (queuesList != null && queuesList.Count > 0)
                        {
                            //Call again
                            this.SendQuesueSMS(telcoID, queuesList);
                        }
                    }
                   



                }
                else
                {
                    B2BayLogger.Log("*** NO Record found ***");
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SendQuesueSMS" + ex.Message, 1, PageNames.SMS_QueueScheduler, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.LogErr(ex.Message, ex);
               // B2BayLogger.WriteLogsToFile();
            }

           // B2BayLogger.WriteLogsToFile();
        }

        private static void UpdateStatusAfterException(SMSQueueModel queueItem, SMSQueueModel item, TelnorBuisnessException ex)
        {
            if (queueItem != null && queueItem.SMSSendingID > 0)
            {
                // Mark Failure record as "SendError" in Queue Buffered
                LazySingletonBLL<SMSQueueBLL>.Instance.SetQueueDeliveryStatus(new SMSQueueModel()
                {
                    OrganizationID = queueItem.OrganizationID,
                    CampaignID = queueItem.CampaignID,
                    DeliveryStatusID = SMSDeliveryStatuses.SendError.GetHashCode(),
                    ID = queueItem.ID,
                    TelcoID = queueItem.TelcoID,
                    IsOnNet = queueItem.IsOnNet
                });


                // string[] ids = queueItem.SMSSendingID.Split('-');

                //======================= Fail Send SMS To Service =============================================================
                LazySingletonBLL<SMSTransactionBLL>.Instance.UpdateSMSDeliveryStatus(new SMSTransactionModel()
                {
                    OrganizationID = queueItem.OrganizationID,
                    CampaignID = queueItem.CampaignID,
                    SMSSendingID = queueItem.SMSSendingID,
                    DeliveryStatusID = SMSDeliveryStatuses.SendError.GetHashCode(),
                    ContactNo = queueItem.Phone,
                    Network = "",
                    TelcoID = queueItem.TelcoID,
                    IsOnNet = queueItem.IsOnNet
                });
                //======================= Send SMS To Service =============================================================
                B2BayLogger.Log("Message Fail");
                B2BayLogger.Log("Message " + item.SendMessage + "ShortCode " + item.ShortCode + "organizationID " + item.OrganizationID + "capaignID " + item.CampaignID + "SMSQueueID " + item.ID);
                B2BayLogger.Log("Error " + ex.Message);
               // B2BayLogger.WriteLogsToFile();
            }
            else
            {
                B2BayLogger.Log("Error " + ex.Message);
               // B2BayLogger.WriteLogsToFile();
            }
        }
    }
}
