﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.CustomEnums;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.BLL.SMSQueue;
//using SMS.CMP.BE.SMSQueue;
using SMS.Queue.ApplicationClassess;
using SMS.Queue.ApplicationClassess.Log;
using SMS.Queue.CustomeEnum;
using SMS.Queue.CustomExceptions;
using SMS.Queue.DataModel;
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <21-10-2015 07:47:38PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.Queue.ApplicationClasses.SMSRequest
{
    public class SMSSendRequest
    {
        public int? CampaignID { get; set; }
        public int? OrganizationID { get; set; }
        public int? ShortCode { get; set; }

        public bool SendSMS()
        {
            return true;
        }
    }

    public class BulkSendSMSRequest
    {
        public int? ID { get; set; }
        public int? CampaignID { get; set; }
        public int? OrganizationID { get; set; }
        public string ShortCode { get; set; }
        public string Message { get; set; }
        public BulkSendSMSRequest()
        { }

        public BulkSendSMSRequest(int? campaignID, int? organizationID, string shortCode, int ? smsQueueID)
        {
            this.CampaignID = campaignID;
            this.OrganizationID = organizationID;
            this.ShortCode = shortCode;
            this.ID = smsQueueID;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="smsSingleModel"></param>
        /// <returns></returns>
        public bool SendSMS(SMSQueueModel smsSingleModel)
        {
            bool result = false;
            string serviceURL = string.Empty;
            try
            {
                string HostingIP = ConfigurationHelper.HostingIP;
                /*
                if (smsSingleModel.TelcoID == TelcoNames.Telenor.GetHashCode())
                {
                    //Call Telenaor API
                    SendSMSFormTeleNorAPI(smsSingleModel);
                }
                else
                {

                    serviceURL = GetUrl(smsSingleModel, HostingIP, ConfigurationHelper.WCFServiceName);
                    B2BayLogger.Log("Send Request To service");

                    B2BayLogger.Log("ServiceURL" + serviceURL);
                    B2BayLogger.WriteLogsToFile();

                    Console.WriteLine("Send Request to service....");
                    result = SendSmsToClient(serviceURL);
                }
                 */

               
               // if (true)
                //if (smsSingleModel.TelcoID == TelcoNames.Telenor.GetHashCode() || smsSingleModel.TelcoID == TelcoNames.Ufone.GetHashCode() || smsSingleModel.TelcoID == TelcoNames.Zong.GetHashCode())
                if (smsSingleModel.TelcoID == TelcoNames.Telenor.GetHashCode())
                {
                    serviceURL = this.GetUrl_ToSendTelnoSMS_FROM_Mobilink(smsSingleModel);
                }
                else
                {
                    serviceURL = GetUrl(smsSingleModel, HostingIP, ConfigurationHelper.WCFServiceName);
                }

               
                B2BayLogger.Log("Send Request To service");

                B2BayLogger.Log("ServiceURL" + serviceURL);
                B2BayLogger.WriteLogsToFile();

                Console.WriteLine(smsSingleModel.Phone);
                Console.WriteLine("Send Request to service....");
                result = SendSmsToClient(serviceURL);

                Console.WriteLine("Successfully send" + smsSingleModel.Phone);
                B2BayLogger.Log("Successfully send" + smsSingleModel.Phone );
                // write to log file
                
                B2BayLogger.WriteLogsToFile();
            }

            catch (Exception ex)
            {
                B2BayLogger.Log("There is Some Error:" + ex.Message);
                B2BayLogger.WriteLogsToFile();
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " Method Name: SendSMS " + serviceURL, 1, PageNames.SMS_CMPService, 0));
                throw ex;
            }

            return true;
        }

        private string GetUrl_ToSendTelnoSMS_FROM_Mobilink(SMSQueueModel smQueueModel)
        {
            //https://connect.jazzcmt.com/sendsms_url.html?Username=03070984927&Password=Jazz@1234&From=9100&To=03320754179&Message=صبح بخیر
            StringBuilder sbAuthenticateUrl = new StringBuilder();
            sbAuthenticateUrl.Append("https://connect.jazzcmt.com/sendsms_url.html?Username=");
            sbAuthenticateUrl.Append("03070984927&Password=Jazz@1234");
            sbAuthenticateUrl.Append("&From=");
            sbAuthenticateUrl.Append(smQueueModel.ShortCode);
            sbAuthenticateUrl.Append("&To=");
            sbAuthenticateUrl.Append(smQueueModel.Phone);
            sbAuthenticateUrl.Append("&Message=");
            sbAuthenticateUrl.Append(smQueueModel.SendMessage);
            return sbAuthenticateUrl.ToString();
        }

        private void SendSMSFormTeleNorAPI(SMSQueueModel smQueueModel)
        {
            //https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=xxxx&password=xxx
            //Build Url For Authentication and Session ID
            StringBuilder sbAuthenticateUrl = new StringBuilder();

            sbAuthenticateUrl.Append("https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=");
            sbAuthenticateUrl.Append(smQueueModel.UserName);
            sbAuthenticateUrl.Append("&password=");
            sbAuthenticateUrl.Append(smQueueModel.Password);

            string APIUrl = sbAuthenticateUrl.ToString();
            B2BayLogger.Log("API Url " + APIUrl);
            //Get Session ID
            B2BayLogger.Log("Get Session ID ");
            String resultXML = SendhttpWebRequest(APIUrl);
            B2BayLogger.Log("Response in getting Session " + resultXML);

            if (!string.IsNullOrEmpty(resultXML))
            {

                corpsms resposneModel = (corpsms)CommonHelper.XmlDeserializeFromString(resultXML, typeof(corpsms));
                if (resposneModel != null)
                {
                    if (resposneModel.response.ToUpper().Equals("ERROR"))
                    {
                        B2BayLogger.Log("Error Code " + resposneModel.data);
                        throw new TelnorBuisnessException(resposneModel.data);
                    }
                    else if (resposneModel.response.ToUpper().Equals("OK"))
                    {
                        B2BayLogger.Log("Session ID " + resposneModel.data);
                        sbAuthenticateUrl.Clear();
                        //Get Send Session ID in sms
                        //https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=xxxx&to=923xxxxxxxxx,923xxxxxxxxx,923xxxxxxxxx&text=xxxx&mask=xxxx

                        sbAuthenticateUrl.Append("https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=");
                        sbAuthenticateUrl.Append(resposneModel.data);//Session ID
                        sbAuthenticateUrl.Append("&to=");
                        sbAuthenticateUrl.Append(smQueueModel.Phone);
                        sbAuthenticateUrl.Append("&text=");
                        sbAuthenticateUrl.Append(smQueueModel.SendMessage);
                        //if (!string.IsNullOrEmpty(smQueueModel.ShortCode))
                        //{
                        //    sbAuthenticateUrl.Append("&mask=");
                        //    sbAuthenticateUrl.Append(smQueueModel.ShortCode);
                        //}                      

                        APIUrl = sbAuthenticateUrl.ToString();
                        // Send Request to Telinor API to send the message
                        B2BayLogger.Log("API Url " + APIUrl);
                        resultXML = SendhttpWebRequest(APIUrl);

                        //Deseriallize xml string to object
                        B2BayLogger.Log("Deseriallize xml string to object " + resposneModel.data);
                        resposneModel = (corpsms)CommonHelper.XmlDeserializeFromString(resultXML, typeof(corpsms));

                        if (resposneModel.response.ToUpper().Equals("ERROR"))
                        {
                            B2BayLogger.Log("Error " + resposneModel.data);


                            ThirdPartyAPIResponseModel thirdPartyAPIResponse = new ThirdPartyAPIResponseModel()
                            {
                                MessageID = resposneModel.data,
                                PhoneNo = smQueueModel.Phone,
                                SMSSendingID = resposneModel.data,
                                XMLResponse = resultXML,
                                StatusID = 4,
                                TelcoID = smQueueModel.TelcoID
                            };

                            //Get Message ID in separte table
                            B2BayLogger.Log("Add Third Party Response in Table in case or error ");
                            LazySingletonBLL<ThirdPartyAPIResponseBLL>.Instance.AddThirdPartyResponse(thirdPartyAPIResponse);

                            throw new TelnorBuisnessException(resposneModel.data);
                        }
                        else if (resposneModel.response.ToUpper().Equals("OK"))
                        {
                            string messageSendingID = GetMessageSendingID(smQueueModel);
                            B2BayLogger.Log("SMS Sending ID " + messageSendingID);

                            ThirdPartyAPIResponseModel thirdPartyAPIResponse = new ThirdPartyAPIResponseModel()
                            {
                                MessageID = resposneModel.data,
                                PhoneNo = smQueueModel.Phone,
                                SMSSendingID = messageSendingID,
                                XMLResponse = resultXML,
                                StatusID = 1,
                                TelcoID = smQueueModel.TelcoID
                            };
                            //Get Message ID in separte table
                            B2BayLogger.Log("Add Third Party Response in Table ");
                            LazySingletonBLL<ThirdPartyAPIResponseBLL>.Instance.AddThirdPartyResponse(thirdPartyAPIResponse);

                        }

                    }
                }


            }


        }

        private static string SendhttpWebRequest(string  requestUrl)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(requestUrl);
            request.Method = "GET";
            String resultXML = String.Empty;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                resultXML = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();

                // return true;
            }
            return resultXML;
        }


        #region Custom Methods
       
        /// <summary>
        /// 
        /// </summary>
        /// <param name="hostURI"></param>
        /// <returns></returns>
        private bool SendSmsToClient(string hostURI)
        {
            if (ConfigurationHelper.IsDownloadStringAsync)
            {
                return LoadDataAsync(hostURI);
            }
            else
            {
                return SendHttpWebRequest(hostURI);
            }
            
        }

        private static bool SendHttpWebRequest(string hostURI)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(hostURI);
            request.Method = "GET";
            String test = String.Empty;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                test = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();

                return true;
            }
        }
        public static bool LoadDataAsync(string hostURI)
        {
            using (var client = new WebClient())
            {
                // byte[] result = client.DownloadData(url);
                client.DownloadStringAsync(new Uri(hostURI));
            }
            return true;
        }

        private string  SendSmsToAPIClient(string hostURI)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(hostURI);
            request.Method = "GET";
            string  test = String.Empty;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                test = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();

                return test;
            }
           
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="smQueueModel"></param>
        /// <param name="hostingIP"></param>
        /// <param name="wcfServiceName"></param>
        /// <returns></returns>
        private string GetUrl(SMSQueueModel smQueueModel, string hostingIP, string wcfServiceName)
        {
            StringBuilder smsID = new StringBuilder();

            //Making SMS sending ID
            smsID.Append(smQueueModel.OrganizationID);
            smsID.Append("-");
            smsID.Append(smQueueModel.CampaignID);
            smsID.Append("-");
            smsID.Append(smQueueModel.SMSSendingID);
            smsID.Append("-");
            smsID.Append(smQueueModel.TelcoID);
            smsID.Append("-");
            smsID.Append(Convert.ToInt32(smQueueModel.IsOnNet));
            //Making Url for  sending SMS

            StringBuilder sbUrl = new StringBuilder();
         
                sbUrl.Append("http://");
                sbUrl.Append(smQueueModel.SMSGateway);
                sbUrl.Append("/cgi-bin/sendsms?&");
                sbUrl.Append("username=");
                sbUrl.Append(smQueueModel.UserName);
                sbUrl.Append("&password=");
                sbUrl.Append(smQueueModel.Password);
                sbUrl.Append("&to=");
                sbUrl.Append(smQueueModel.Phone);
                sbUrl.Append("&from=");
                sbUrl.Append(smQueueModel.ShortCode);
                if (!string.IsNullOrEmpty(smQueueModel.Lang) && smQueueModel.Lang.ToLower().Equals("en"))
                {

                }
                else
                {
                    sbUrl.Append("&charset=UTF-8&coding=2");
                }               
                // &charset = 
                sbUrl.Append("&text=");
                sbUrl.Append(smQueueModel.SendMessage);
                sbUrl.Append("&dlr-mask=31&dlr-url=http://");
                sbUrl.Append(hostingIP);
                sbUrl.Append("/");
                sbUrl.Append(wcfServiceName);
                sbUrl.Append("/SMSDeliveryResponse");               
                sbUrl.Append("/%p");
                sbUrl.Append("/");
                sbUrl.Append(smsID.ToString());               
                //Message
                sbUrl.Append("/%d");
                sbUrl.Append("/%i");
           // }

            return sbUrl.ToString();
        }

        private static string  GetMessageSendingID(SMSQueueModel smQueueModel)
        {
            StringBuilder smsID =new StringBuilder();
            smsID.Append(smQueueModel.OrganizationID);
            smsID.Append("-");
            smsID.Append(smQueueModel.CampaignID);
            smsID.Append("-");
            smsID.Append(smQueueModel.SMSSendingID);
            smsID.Append("-");
            smsID.Append(smQueueModel.TelcoID);
            smsID.Append("-");
            smsID.Append(Convert.ToInt32(smQueueModel.IsOnNet));
            return smsID.ToString();
        }

        #endregion
    }
}
