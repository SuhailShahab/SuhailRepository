﻿
using SMS.Queue.ApplicationClassess.Log;
using System;
using System.Diagnostics;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <21-10-2015 07:47:38PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.Queue.ApplicationClasses
{
    public class CommonHelper
    {
        //public void StartCampaint()
        //{

        //}

        public static bool PingHost(string nameOrAddress)
        {
            bool pingable = false;
            Ping pinger = new Ping();

            try
            {
                PingReply reply = pinger.Send(nameOrAddress);

                pingable = reply.Status == IPStatus.Success;
            }
            catch (PingException)
            {
                // Discard PingExceptions and return false;
            }

            return pingable;
        }

        public static WebForntNames GetWebForntEnum(string webForntName)
        {
            WebForntNames WebForntName = (WebForntNames)Enum.Parse(typeof(WebForntNames), webForntName);
            return WebForntName;
        }

        public static bool IsNewApplciationRunning(string appName)
        {
            // bool IsNewApplciationExecute = false;
            //System.Threading.Mutex mutex;

            //mutex = new System.Threading.Mutex(true, appName, out IsNewApplciationExecute);


            ////  mutex.ReleaseMutex();
            //GC.KeepAlive(mutex);
            //return IsNewApplciationExecute;

            Process currentProcess = Process.GetCurrentProcess();
            Process[] processlist = Process.GetProcesses();
            int cout = processlist.Where(a => a.ProcessName.Equals("SMS.Queue")).Count();
            if (cout > 1)
                return false;
            else
                return true;
        }

        public static void SendNotificationEmail(string errorMessage)
        {
            Console.WriteLine("Sending Email.");
            B2BayLogger.Log("Starting Send Email...");

            Thread.Sleep(1000);
            SendEmail email = new SendEmail();
            string emailBody = "Error Message: " + errorMessage; //SendEmailTemplate.GetEmailTemplate(colUnPostedData);
            email.MailSend("Notification of Stoppoing SMS Schduler", emailBody);
        }

        public static object XmlDeserializeFromString(string objectData, Type type)
        {
            var serializer = new System.Xml.Serialization.XmlSerializer(type);
            object result;

            using (System.IO.TextReader reader = new System.IO.StringReader(objectData))
            {
                result = serializer.Deserialize(reader);
            }

            return result;
        }

        

      
    }
}
