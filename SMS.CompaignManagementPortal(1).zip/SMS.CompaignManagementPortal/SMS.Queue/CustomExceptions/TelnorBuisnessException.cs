﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// =================================================================================================================================
// Create by:	<Atif Farroq>
// Create date: <10-DEC-2015 10:04AM>
// Create by Suhail Shahab: In case of error throw exception according to telnor API business rules,define in API Documents
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
namespace SMS.Queue.CustomExceptions
{
   public  class TelnorBuisnessException:Exception 
    {
        public string ErrorCode { get; set; }
        public string ErrorDescription { get; set; }
        public string ErrorFullMessage { get; set; }

       public  TelnorBuisnessException()
       {

       }

       public TelnorBuisnessException(string errorCode)
       {
           this.ErrorCode = errorCode;

           this.ErrorDescription = this.GetErrorCodeDescription(errorCode);
           this.ErrorFullMessage = "ErrorCode :" + this.ErrorCode + " Error Description:" + this.ErrorDescription;
          
       }

       public string GetErrorCodeDescription(string errorCode)
       {
           string description= string.Empty ;
           if (!string.IsNullOrEmpty(errorCode))
           {


               string[] arryErro = errorCode.Split(' ');
               if (arryErro.Length >1)
               switch (arryErro[1])
               {
                   case "200":
                       description = "Failed login. Username and password do not match.";
                       break;
                   case "201":
                       description = "Unknown MSISDN, Please Check Format i-e 92345xxxxxxx";
                       break;
                   case "100":
                       description = "Out of credit.";
                       break;
                   case "101":
                       description = "Field or input parameter missing";
                       break;
                   case "102":
                       description = "Invalid session ID or the session has expired. Login again.";
                       break;
                   case "103":
                       description = "Invalid Mask";
                       break;
                   case "211":
                       description = "Unknown Message ID.";
                       break;
                   case "300":
                       description = "Account has been blocked/suspended";
                       break;
                   case "400":
                       description = "Duplicate list name.";
                       break;
                   case "401":
                       description = "List name is missing.";
                       break;
                   case "411":
                       description = "Invalid MSISDN in the list.";
                       break;

               }
           }

           return description; 

       }
        
    }
}
