﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Queue.CustomeEnum
{
    public enum TelnoErrorCodeNames
    {
        None=0,
        SessionExpiredOrInvalid=102,
        InvalidMask=103,
        //103

    }
}
