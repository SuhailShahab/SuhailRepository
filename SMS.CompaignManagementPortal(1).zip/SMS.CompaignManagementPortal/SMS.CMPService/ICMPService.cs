﻿using SMS.CMP.BE.APIClasses;
using System.ServiceModel;
using System.ServiceModel.Web;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <19-10-2015 09:43:16AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ICMPService" in both code and config file together.
    [ServiceContract]
    public interface ICMPService
    {
        //[OperationContract]
        //[WebGet(UriTemplate = "SendSMS/{campaignID}/{organizationgID}/{toPhoneNo}/{message}")]
        //void SendSMS(string campaignID, string organizationgID, string toPhoneNo, string message);

        [OperationContract]
        [WebInvoke(
            ResponseFormat = WebMessageFormat.Json,
            RequestFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Bare,
            Method = "POST",
            UriTemplate = "SendSMS/{campaignID}/{organizationgID}/{toPhoneNo}/{message}")]
        void SendSMS(string campaignID, string organizationgID, string toPhoneNo, string message);

        [OperationContract]
        [WebInvoke(
            ResponseFormat = WebMessageFormat.Json,
            RequestFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Bare,
            Method = "POST",
            UriTemplate = "SendSMSData/{campaignID}/{organizationgID}")]
        void SendSMSData(string campaignID, string organizationgID, SMSMessageModel message);

        [OperationContract]
        [WebInvoke(
            ResponseFormat = WebMessageFormat.Json,
            RequestFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Bare,
            Method = "POST",
            UriTemplate = "SMSSend/{campaignID}/{organizationgID}/{lang}")]
        void SMSSend(string campaignID, string organizationgID,string lang, SMSMessageModel message);

        [OperationContract]
        [WebInvoke(
            ResponseFormat = WebMessageFormat.Json,
            RequestFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Bare,
            Method = "POST",
            UriTemplate = "SMSByTelcoCode/{campaignID}/{organizationgID}/{lang}/{telcoCode}")]
        void SMSByTelcoCode(string campaignID, string organizationgID, string lang,string telcoCode, SMSMessageModel message);

        [OperationContract]
        [WebGet(UriTemplate = "SMSDeliveryResponse/{to}/{smsid}/{type}/{from}")]
        void SMSDeliveryResponse(string to, string smsid, string type, string from);

        [OperationContract]
        [WebGet(UriTemplate = "Test/{smsid}/{type}")]
        void Test(string smsid, string type);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Xml,
            UriTemplate = "SMSSendByUrl/{lang}?campaignID={campaignID}&organizationgID={organizationgID}&phoneNumber={phoneNumber}&smsMessage={smsMessage}")]
        void SMSSendByUrl(string campaignID, string organizationgID,string lang,string phoneNumber,string smsMessage);
    }
}
