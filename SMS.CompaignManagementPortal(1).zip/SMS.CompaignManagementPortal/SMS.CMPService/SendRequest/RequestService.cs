﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Common;
using SMS.CMP.BLL.CMP;
using SMS.CMPService.ApplicationClassess;
using SMS.CMPService.ApplicationClassess.Log;
using System;
using System.IO;
using System.Net;
using System.Text;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <19-10-2015 09:43:16AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPService.SendRequest
{
    public class RequestService
    {
        public SMSConfigurationModel SendRequest(string sendToPhoneNo, string message, string smsSendingID, string shortCode)
        {
            bool? result = null;
            string ServiceURL = string.Empty;
            string networkTypeCode = string.Empty;

            try
            {

                if (sendToPhoneNo.Length == 11)
                {
                    networkTypeCode = sendToPhoneNo.Substring(0, 3);

                }
                else
                {
                    networkTypeCode = sendToPhoneNo.Substring(2, 2);
                    networkTypeCode = "0" + networkTypeCode;
                }

                SMSConfigurationModel smsCampaignModel = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetNetworkProvider(networkTypeCode);
                smsCampaignModel.SendPhoneNo = sendToPhoneNo;

                smsCampaignModel.IsOnNet = smsCampaignModel.SourceNetworksID.Equals(networkTypeCode) ? true : false;            //Verify the On Net and Off Net
                message = CommonMethod.ReplaceSpecilChar(message);          //Replace specila character 
                smsSendingID = smsSendingID + "-" + smsCampaignModel.TelcoID + "-" + Convert.ToInt32(smsCampaignModel.IsOnNet);
                ServiceURL = GetUrl(smsCampaignModel, message, smsSendingID, shortCode);

                result = SendSmsToClient(ServiceURL);

                // write to log file
                B2BayLogger.Log(ServiceURL);
                B2BayLogger.WriteLogsToFile();

                return smsCampaignModel;
            }
            catch (Exception ex)
            {
                B2BayLogger.Log("There is Some Error:" + ex.Message);
                B2BayLogger.WriteLogsToFile();
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ServiceURL, 1, PageNames.SMS_CMPService, 0));
                throw ex;
            }

            return null;
        }
        public SMSConfigurationModel SendRequest(string sendToPhoneNo, string message, string smsSendingID, string shortCode, string lang)
        {
            bool? result = null;
            string ServiceURL = string.Empty;
            string networkTypeCode = string.Empty;

            try
            {

                if (sendToPhoneNo.Length == 11)
                {
                    networkTypeCode = sendToPhoneNo.Substring(0, 3);

                }
                else
                {
                    networkTypeCode = sendToPhoneNo.Substring(2, 2);
                    networkTypeCode = "0" + networkTypeCode;
                }

                SMSConfigurationModel smsCampaignModel = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetNetworkProvider(networkTypeCode);
                smsCampaignModel.SendPhoneNo = sendToPhoneNo;

                smsCampaignModel.IsOnNet = smsCampaignModel.SourceNetworksID.Equals(networkTypeCode) ? true : false;            //Verify the On Net and Off Net
                message = CommonMethod.ReplaceSpecilChar(message);          //Replace specila character 
                smsSendingID = smsSendingID + "-" + smsCampaignModel.TelcoID + "-" + Convert.ToInt32(smsCampaignModel.IsOnNet);
                ServiceURL = GetUrl(smsCampaignModel, message, smsSendingID, shortCode, lang);

                result = SendSmsToClient(ServiceURL);

                // write to log file
                B2BayLogger.Log(ServiceURL);
                B2BayLogger.WriteLogsToFile();

                return smsCampaignModel;
            }
            catch (Exception ex)
            {
                B2BayLogger.Log("There is Some Error:" + ex.Message);
                B2BayLogger.WriteLogsToFile();
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ServiceURL, 1, PageNames.SMS_CMPService, 0));
                throw ex;
            }

            return null;
        }

        /// <summary>
        /// Get SMS Configuration Model Fill
        /// </summary>
        /// <param name="sendToPhoneNo"></param>
        /// <param name="message"></param>
        /// <param name="smsSendingID"></param>
        /// <param name="shortCode"></param>
        /// <returns></returns>
        public SMSConfigurationModel GetSMSConfigurationModel(string sendToPhoneNo)
        {
            //string ServiceURL = string.Empty;
            string networkTypeCode = string.Empty;
            string originalContactNo = string.Empty;
            try
            {
                originalContactNo = sendToPhoneNo;
                sendToPhoneNo = LazySingleton<CommonBLL>.Instance.ConvertContactNo92(sendToPhoneNo);

                if (sendToPhoneNo.Length == 11)
                {
                    networkTypeCode = sendToPhoneNo.Substring(0, 3);

                }
                else
                {
                    networkTypeCode = sendToPhoneNo.Substring(2, 2);
                    networkTypeCode = "0" + networkTypeCode;
                }

                // Fill SMSConfigurationModel Mode
                SMSConfigurationModel smsConfigurationModel = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetNetworkProvider(networkTypeCode);

                //smsCampaignModel.NetworkTypeCode = networkTypeCode; /// Store Network Code
                smsConfigurationModel.SendPhoneNo = sendToPhoneNo;
                smsConfigurationModel.OriginalContactNo = originalContactNo;

                smsConfigurationModel.IsOnNet = smsConfigurationModel.SourceNetworksID.Equals(networkTypeCode) ? true : false;            //Verify the On Net and Off Net
                //message = CommonMethod.ReplaceSpecilChar(message);          //Replace specila character 
                //smsSendingID = smsSendingID + "-" + smsCampaignModel.TelcoID + "-" + Convert.ToInt32(smsCampaignModel.IsOnNet);
                //ServiceURL = GetUrl(smsCampaignModel, message, smsSendingID, shortCode);

                //result = SendSmsToClient(ServiceURL);

                // write to log file
                B2BayLogger.Log("GetSMSConfigurationModel");
                B2BayLogger.WriteLogsToFile();

                return smsConfigurationModel;
            }
            catch (Exception ex)
            {
                B2BayLogger.Log("There is Some Error:" + ex.Message);
                B2BayLogger.WriteLogsToFile();
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + networkTypeCode, 1, PageNames.SMS_CMPService, 0));
                throw ex;
            }

            return null;
        }
        public SMSConfigurationModel GetSMSConfigurationModel(string sendToPhoneNo,string telcoNetworkCode)
        {
            //string ServiceURL = string.Empty;
            string networkTypeCode = string.Empty;
            string originalContactNo = string.Empty;
            try
            {
                originalContactNo = sendToPhoneNo;
                sendToPhoneNo = LazySingleton<CommonBLL>.Instance.ConvertContactNo92(sendToPhoneNo);

                if (!string.IsNullOrEmpty(telcoNetworkCode) && telcoNetworkCode.Length==3 && ( telcoNetworkCode =="032" ||telcoNetworkCode =="030"||telcoNetworkCode =="033"||
                    telcoNetworkCode =="034"||telcoNetworkCode =="031"))
                {
                    networkTypeCode = telcoNetworkCode;
                }
                else                
                if (sendToPhoneNo.Length == 11) 
                {
                    networkTypeCode = sendToPhoneNo.Substring(0, 3);

                }
                else
                {
                    networkTypeCode = sendToPhoneNo.Substring(2, 2);
                    networkTypeCode = "0" + networkTypeCode;
                }
                
                // Fill SMSConfigurationModel Mode
                SMSConfigurationModel smsConfigurationModel = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetNetworkProvider(networkTypeCode);

                //smsCampaignModel.NetworkTypeCode = networkTypeCode; /// Store Network Code
                smsConfigurationModel.SendPhoneNo = sendToPhoneNo;
                smsConfigurationModel.OriginalContactNo = originalContactNo;

                smsConfigurationModel.IsOnNet = smsConfigurationModel.SourceNetworksID.Equals(networkTypeCode) ? true : false;            //Verify the On Net and Off Net
                //message = CommonMethod.ReplaceSpecilChar(message);          //Replace specila character 
                //smsSendingID = smsSendingID + "-" + smsCampaignModel.TelcoID + "-" + Convert.ToInt32(smsCampaignModel.IsOnNet);
                //ServiceURL = GetUrl(smsCampaignModel, message, smsSendingID, shortCode);

                //result = SendSmsToClient(ServiceURL);

                // write to log file
                B2BayLogger.Log("GetSMSConfigurationModel");
                B2BayLogger.WriteLogsToFile();

                return smsConfigurationModel;
            }
            catch (Exception ex)
            {
                B2BayLogger.Log("There is Some Error:" + ex.Message);
                B2BayLogger.WriteLogsToFile();
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + networkTypeCode, 1, PageNames.SMS_CMPService, 0));
                throw ex;
            }

            return null;
        }

        public string GetSMSSendingID(string organizationID, string compainID, string smsMaxID)
        {
            StringBuilder smsID = new StringBuilder();
            smsID.Append(organizationID);
            smsID.Append("-");
            smsID.Append(compainID);
            smsID.Append("-");
            smsID.Append(smsMaxID);

            return smsID.ToString();
        }

        #region "Private Methods"

        private bool SendSmsToClient(string HostURI)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(HostURI);
            String test = String.Empty;
            request.Method = "GET";

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                test = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();

                return true;
            }
        }



        #endregion

        #region Network Provider Url information

        private string GetUrl(SMSConfigurationModel smsCampaignModel, string message, string smsSendingID, string shortCode)
        {
            StringBuilder sbUrl = new StringBuilder();
            sbUrl.Append("http://");
            sbUrl.Append(smsCampaignModel.SMSGateway);
            sbUrl.Append("/cgi-bin/sendsms?&");
            sbUrl.Append("username=");
            sbUrl.Append(smsCampaignModel.UserName);
            sbUrl.Append("&password=");
            sbUrl.Append(smsCampaignModel.Password);
            sbUrl.Append("&to=");
            sbUrl.Append(smsCampaignModel.SendPhoneNo);
            sbUrl.Append("&from=");
            sbUrl.Append(shortCode);
            sbUrl.Append("&charset=UTF-8&coding=2");
            // &charset = 
            sbUrl.Append("&text=");
            sbUrl.Append(message);
            sbUrl.Append("&dlr-mask=31&dlr-url=http://");
            sbUrl.Append(ConfigurationHelper.HostingIP);
            sbUrl.Append("/");
            sbUrl.Append(ConfigurationHelper.WCFServiceName);
            sbUrl.Append("/SMSDeliveryResponse");
            //sbUrl.Append("/Test/");
            //Phone Number
            sbUrl.Append("/%p");
            sbUrl.Append("/");
            sbUrl.Append(smsSendingID);
            //Message
            sbUrl.Append("/%d");
            sbUrl.Append("/%i");

            return sbUrl.ToString();
        }

        private string GetUrl(SMSConfigurationModel smsCampaignModel, string message, string smsSendingID, string shortCode, string lang)
        {
            StringBuilder sbUrl = new StringBuilder();
            sbUrl.Append("http://");
            sbUrl.Append(smsCampaignModel.SMSGateway);
            sbUrl.Append("/cgi-bin/sendsms?&");
            sbUrl.Append("username=");
            sbUrl.Append(smsCampaignModel.UserName);
            sbUrl.Append("&password=");
            sbUrl.Append(smsCampaignModel.Password);
            sbUrl.Append("&to=");
            sbUrl.Append(smsCampaignModel.SendPhoneNo);
            sbUrl.Append("&from=");
            sbUrl.Append(shortCode);
            if (string.IsNullOrEmpty(lang) || !lang.ToLower().Equals("en"))
            {
                sbUrl.Append("&charset=UTF-8&coding=2");
            }
            // &charset = 
            sbUrl.Append("&text=");
            sbUrl.Append(message);
            sbUrl.Append("&dlr-mask=31&dlr-url=http://");
            sbUrl.Append(ConfigurationHelper.HostingIP);
            sbUrl.Append("/");
            sbUrl.Append(ConfigurationHelper.WCFServiceName);
            sbUrl.Append("/SMSDeliveryResponse");
            //sbUrl.Append("/Test/");
            //Phone Number
            sbUrl.Append("/%p");
            sbUrl.Append("/");
            sbUrl.Append(smsSendingID);
            //Message
            sbUrl.Append("/%d");
            sbUrl.Append("/%i");

            return sbUrl.ToString();
        }
        #endregion
    }
}