﻿using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Common;
using SMS.CMP.BE.CustomEnums;
using SMS.CMP.BLL.CMP;
using SMS.CMPService.ApplicationClassess;
using SMS.CMPService.ApplicationClassess.Log;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;

namespace SMS.CMPService.SendRequest
{
    public class BulkSendSMSRequest
    {
        public int? CampaignID { get; set; }
        public int? OrganizationID { get; set; }
        public string ShortCode { get; set; }
        public string Message { get; set; }
        public BulkSendSMSRequest()
        { }

        public BulkSendSMSRequest(int? campaignID,int? organizationID,string shortCode)
        {
            this.CampaignID = campaignID;
            this.OrganizationID = organizationID;
            this.ShortCode = shortCode;
        }
        public BulkSendSMSRequest(int? campaignID, int? organizationID)
        {
            this.CampaignID = campaignID;
            this.OrganizationID = organizationID;
           
        }

        public bool SendBulkSMS()
        {
            B2BayLogger.Log("Call Methods SendBulkSMS :Get All contact again campaign and organization");
           // ContactBLL contactBLL = new ContactBLL();
           // Thread.Sleep(1000);
            List<ContactModel> contacts= LazySingleton<ContactBLL>.Instance.GetCampaignContacts(this.OrganizationID, this.CampaignID);

            if (contacts != null && contacts.Count > 0)
            {
                foreach (ContactModel contact in contacts)
                {
                    VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser( this.OrganizationID,this.CampaignID);
                    if (result != null && result.SMS_SendingID > 0)
                    {
                        string shortCode = string.IsNullOrEmpty(this.ShortCode) ? result.ShortCode : this.ShortCode;
                        B2BayLogger.Log("shortCode" + shortCode);
                        string message = string.IsNullOrEmpty(this.Message) ? result.SMSMessage : this.Message;
                        B2BayLogger.Log("shortCode" + message);
                        string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(this.OrganizationID.ToString(), this.CampaignID.ToString(), result.SMS_SendingID.ToString());
                        LazySingleton<RequestService>.Instance.SendRequest(contact.Phone, message, ID, shortCode);
                        B2BayLogger.Log("SendRequest" );
                        SMSTransactionModel SMSModel = new SMSTransactionModel();
                        SMSModel.CampaignID = Convert.ToInt32(this.CampaignID);
                        SMSModel.OrganizationID = Convert.ToInt32(this.OrganizationID);
                        SMSModel.SendMessage = message;
                        SMSModel.ContactNo = contact.Phone;
                        SMSModel.SMSSendingID = result.SMS_SendingID;
                        SMSModel.ContactID = contact.ID;
                        SMSModel.Mode = RequestSourceName.Portal.GetHashCode();
                        LazySingleton<SMSTransactionBLL>.Instance.Save(SMSModel);
                    }
                    else
                    {
                        B2BayLogger.Log("Not Validate");
                    }
                }

            }
            else
            {
                B2BayLogger.Log("No Contacts  against campaign and organization");
            }
            B2BayLogger.WriteLogsToFile();
            return true;
        }

    }
}