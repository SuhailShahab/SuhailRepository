﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Common;
using SMS.CMP.BE.CustomEnums;
using SMS.CMP.BE.CustomExcetion.APIExcetion;
using SMS.CMP.BE.SMSQueue;
//using SMS.CMP.BE.SMSQueue;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.SchedulerInfo;
using SMS.CMP.BLL.SMSQueue;
using SMS.CMPService.ApplicationClassess;
using SMS.CMPService.ApplicationClassess.Log;
using SMS.CMPService.SendRequest;
using System;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Threading;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <19-10-2015 09:43:16AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "CMPService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select CMPService.svc or CMPService.svc.cs at the Solution Explorer and start debugging.
    public class CMPService : ICMPService
    {
        private static readonly object Locker = new object();
        public void SendSMS(string campaignID, string organizationgID, string toPhoneNo, string message)
        {
            try
            {
                B2BayLogger.Log("Call Method SendSMS1");

                if (ConfigurationHelper.IsSecured)      //check security encodeing enable then Decode Organization ID and Campaign ID
                {
                    campaignID = CustomSecurity.DecodeFrom64(campaignID);
                    organizationgID = CustomSecurity.DecodeFrom64(organizationgID);
                }
                Thread.Sleep(9000);
                B2BayLogger.Log("Wait ended");
                lock (Locker)
                {

                    if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID) && !string.IsNullOrEmpty(toPhoneNo) && !string.IsNullOrEmpty(message))
                    {
                        B2BayLogger.Log("Request send12");
                        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));  // verifty validity of provided orgainzation id and compaign id 
                        if (result != null && result.SMS_SendingID > 0)
                        {
                            // ========================================= Generate and Get SMS ID ======================================= //
                            string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(organizationgID, campaignID, result.SMS_SendingID.ToString());

                            // ========================================= Send Request ======================================= //

                            SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.SendRequest(toPhoneNo, message, ID, result.ShortCode);

                            // =================================== Add record in SMS Transactions =================================//
                            SMSTransactionModel SMSModel = new SMSTransactionModel();
                            SMSModel.CampaignID = Convert.ToInt32(campaignID);
                            SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
                            SMSModel.SendMessage = message;
                            SMSModel.ContactNo = toPhoneNo;
                            SMSModel.SMSSendingID = result.SMS_SendingID;
                            SMSModel.TelcoID = smsConfigurationModel.TelcoID;
                            SMSModel.IsOnNet = smsConfigurationModel.IsOnNet;
                            SMSModel.DeliveryStatusID = CampaignStautes.InitiateCampaign.GetHashCode();
                            SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

                            LazySingleton<SMSTransactionBLL>.Instance.Save(SMSModel);
                            // Thread.Sleep(1000);
                        }
                        else
                        {
                            B2BayLogger.Log("No Validate");
                            B2BayLogger.Log("Campaign is expired or remaing sms sending is zeror ");
                        }
                    }
                    else
                    {
                        B2BayLogger.Log("Something is missing or wrong.");
                        B2BayLogger.Log("campaignID " + campaignID);
                        B2BayLogger.Log("toPhoneNo " + toPhoneNo);
                        B2BayLogger.Log("message " + message);
                    }
                }
            }
            catch (Exception ex)
            {
                string ErroCode = "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message;
                B2BayLogger.Log(ErroCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }

            B2BayLogger.WriteLogsToFile();
        }

        #region OldData
        /*
        public void SendSMSData(string campaignID, string organizationgID, CMP.BE.APIClasses.SMSMessageModel message)
        {
            try
            {
                B2BayLogger.Log("Call Method SendSMS");

                if (ConfigurationHelper.IsSecured)          //check security encodeing enable then Decode Organization ID and Campaign ID
                {
                    campaignID = CustomSecurity.DecodeFrom64(campaignID);
                    organizationgID = CustomSecurity.DecodeFrom64(organizationgID);
                }
                Thread.Sleep(2000);
                B2BayLogger.Log("Wait for Send Request");
                //Check the SMS  Phone Number Validataion

                LazySingleton<SMSValidation>.Instance.CheckValidSMS(message.PhoneNo);


                if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID) && !string.IsNullOrEmpty(message.PhoneNo) && !string.IsNullOrEmpty(message.SMSMessage))
                {
                    lock (Locker)
                    {
                        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                        if (result != null && result.SMS_SendingID > 0)
                        {
                            // ========================================= Generate and Get SMS ID ======================================= //
                            string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(organizationgID, campaignID, result.SMS_SendingID.ToString());

                            // ========================================= Send Request ======================================= //


                            SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.SendRequest(message.PhoneNo, message.SMSMessage, ID, result.ShortCode);

                            // =================================== Add record in SMS Transactions =================================//
                            SMSTransactionModel SMSModel = new SMSTransactionModel();
                            SMSModel.CampaignID = Convert.ToInt32(campaignID);
                            SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
                            SMSModel.SendMessage = message.SMSMessage;
                            SMSModel.ContactNo = message.PhoneNo;
                            SMSModel.SMSSendingID = result.SMS_SendingID;
                            SMSModel.TelcoID = smsConfigurationModel.TelcoID;
                            SMSModel.IsOnNet = smsConfigurationModel.IsOnNet;
                            SMSModel.DeliveryStatusID = SMSDeliveryStatuses.SendToSMSC.GetHashCode();
                            SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

                            LazySingleton<SMSTransactionBLL>.Instance.Save(SMSModel);
                        }
                        else
                        {
                            B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
                        }
                    }
                }
                else
                {
                    B2BayLogger.Log("Something is missing or wrong.");
                    B2BayLogger.Log("campaignID " + campaignID);
                    B2BayLogger.Log("toPhoneNo " + message.PhoneNo);
                    B2BayLogger.Log("message " + message.SMSMessage);
                }
            }
            catch (InvalidPhoneNo ex)
            {


                // =================================== Add record in SMS Transactions =================================//
                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                if (result != null && result.SMS_SendingID > 0)
                {
                    SMSTransactionModel SMSModel = new SMSTransactionModel();
                    SMSModel.CampaignID = Convert.ToInt32(campaignID);
                    SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
                    SMSModel.SendMessage = message.SMSMessage;
                    SMSModel.ContactNo = message.PhoneNo;
                    SMSModel.SMSSendingID = result.SMS_SendingID;
                    SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
                    SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

                    LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
                }


                //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
                B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }
            catch (Exception ex)
            {

                string ErroCode = "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message;
                B2BayLogger.Log(ErroCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }

            B2BayLogger.WriteLogsToFile();
            Thread.Sleep(1000);
        }
        */
        #endregion
        public void SendSMSData(string campaignID, string organizationgID, CMP.BE.APIClasses.SMSMessageModel message)
        {
            B2BayLogger.Log("ConfigurationHelper.IsBuffered" + ConfigurationHelper.IsBuffered.ToString());


            if (ConfigurationHelper.IsBuffered)
            {
                this.StoreDataIntoBuffer(campaignID, organizationgID, "en", message);
            }
            else
            {
                this.SendDirectToService(ref campaignID, ref organizationgID, "en", message);
            }

        }

        /// <summary>
        /// Send SMS with Language Info
        /// </summary>
        /// <param name="campaignID"></param>
        /// <param name="organizationgID"></param>
        /// <param name="lang"></param>
        /// <param name="message"></param>
        public void SMSSend(string campaignID, string organizationgID, string lang, SMSMessageModel message)
        {
            B2BayLogger.Log("ConfigurationHelper.IsBuffered" + ConfigurationHelper.IsBuffered.ToString());


            if (ConfigurationHelper.IsBuffered)
            {
                this.StoreDataIntoBuffer(campaignID, organizationgID, lang, message);
            }
            else
            {
                this.SendDirectToService(ref campaignID, ref organizationgID, lang, message);
            }
        }
        public void SMSByTelcoCode(string campaignID, string organizationgID, string lang,string telcoCode, SMSMessageModel message)
        {
            B2BayLogger.Log("ConfigurationHelper.IsBuffered" + ConfigurationHelper.IsBuffered.ToString());
           
            this.StoreDataIntoBuffer(campaignID, organizationgID, lang,telcoCode, message);
           
        }

        //private  void SendDirectToService(ref string campaignID, ref string organizationgID, CMP.BE.APIClasses.SMSMessageModel message)
        //{
        //    try
        //    {
        //        B2BayLogger.Log("Call Method SendSMS");

        //        if (ConfigurationHelper.IsSecured)          //check security encodeing enable then Decode Organization ID and Campaign ID
        //        {
        //            campaignID = CustomSecurity.DecodeFrom64(campaignID);
        //            organizationgID = CustomSecurity.DecodeFrom64(organizationgID);
        //        }
        //        Thread.Sleep(2000);
        //        B2BayLogger.Log("Wait for Send Request");
        //        //Check the SMS  Phone Number Validataion


        //        LazySingleton<SMSValidation>.Instance.CheckValidSMS(message.PhoneNo);


        //        if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID) && !string.IsNullOrEmpty(message.PhoneNo) && !string.IsNullOrEmpty(message.SMSMessage))
        //        {
        //            lock (Locker)
        //            {
        //                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
        //                if (result != null && result.SMS_SendingID > 0)
        //                {
        //                    // ========================================= Generate and Get SMS ID ======================================= //
        //                    string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(organizationgID, campaignID, result.SMS_SendingID.ToString());

        //                    // ========================================= Send Request ======================================= //

        //                    string converPhoneNumber = LazySingleton<CommonBLL>.Instance.ConvertContactNo92(message.PhoneNo);
        //                    SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.SendRequest(converPhoneNumber, message.SMSMessage, ID, result.ShortCode);

        //                    // =================================== Add record in SMS Transactions =================================//
        //                    SMSTransactionModel SMSModel = new SMSTransactionModel();
        //                    SMSModel.CampaignID = Convert.ToInt32(campaignID);
        //                    SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
        //                    SMSModel.SendMessage = message.SMSMessage;
        //                    SMSModel.ContactNo = converPhoneNumber;
        //                    SMSModel.OriginalContactNo = message.PhoneNo; 
        //                    SMSModel.SMSSendingID = result.SMS_SendingID;
        //                    SMSModel.TelcoID = smsConfigurationModel.TelcoID;
        //                    SMSModel.IsOnNet = smsConfigurationModel.IsOnNet;
        //                    SMSModel.DeliveryStatusID = SMSDeliveryStatuses.SendToSMSC.GetHashCode();
        //                    SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

        //                    LazySingleton<SMSTransactionBLL>.Instance.Save(SMSModel);
        //                }
        //                else
        //                {
        //                    B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
        //                }
        //            }
        //        }
        //        else
        //        {
        //            B2BayLogger.Log("Something is missing or wrong.");
        //            B2BayLogger.Log("campaignID " + campaignID);
        //            B2BayLogger.Log("toPhoneNo " + message.PhoneNo);
        //            B2BayLogger.Log("message " + message.SMSMessage);
        //        }
        //    }
        //    catch (InvalidPhoneNo ex)
        //    {


        //        // =================================== Add record in SMS Transactions =================================//
        //        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
        //        if (result != null && result.SMS_SendingID > 0)
        //        {
        //            SMSTransactionModel SMSModel = new SMSTransactionModel();
        //            SMSModel.CampaignID = Convert.ToInt32(campaignID);
        //            SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
        //            SMSModel.SendMessage = message.SMSMessage;
        //            SMSModel.ContactNo = message.PhoneNo;
        //            SMSModel.SMSSendingID = result.SMS_SendingID;
        //            SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
        //            SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

        //            LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
        //        }


        //        //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
        //        B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_CMPService, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.WriteLogsToFile();
        //    }
        //    catch (Exception ex)
        //    {

        //        string ErroCode = "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message;
        //        B2BayLogger.Log(ErroCode);
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.WriteLogsToFile();
        //    }

        //    B2BayLogger.WriteLogsToFile();
        //    Thread.Sleep(1000);
        //}
        private void SendDirectToService(ref string campaignID, ref string organizationgID, string lang, CMP.BE.APIClasses.SMSMessageModel message)
        {
            try
            {
                B2BayLogger.Log("Call Method SendSMS");

                if (ConfigurationHelper.IsSecured)          //check security encodeing enable then Decode Organization ID and Campaign ID
                {
                    campaignID = CustomSecurity.DecodeFrom64(campaignID);
                    organizationgID = CustomSecurity.DecodeFrom64(organizationgID);
                }
                Thread.Sleep(2000);
                B2BayLogger.Log("Wait for Send Request");
                //Check the SMS  Phone Number Validataion


                LazySingleton<SMSValidation>.Instance.CheckValidSMS(message.PhoneNo);


                if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID) && !string.IsNullOrEmpty(message.PhoneNo) && !string.IsNullOrEmpty(message.SMSMessage))
                {
                    lock (Locker)
                    {
                        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                        if (result != null && result.SMS_SendingID > 0)
                        {
                            // ========================================= Generate and Get SMS ID ======================================= //
                            string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(organizationgID, campaignID, result.SMS_SendingID.ToString());

                            // ========================================= Send Request ======================================= //

                            string converPhoneNumber = LazySingleton<CommonBLL>.Instance.ConvertContactNo92(message.PhoneNo);
                            SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.SendRequest(converPhoneNumber, message.SMSMessage, ID, result.ShortCode, lang);

                            // =================================== Add record in SMS Transactions =================================//
                            SMSTransactionModel SMSModel = new SMSTransactionModel();
                            SMSModel.CampaignID = Convert.ToInt32(campaignID);
                            SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
                            SMSModel.SendMessage = message.SMSMessage;
                            SMSModel.ContactNo = converPhoneNumber;
                            SMSModel.OriginalContactNo = message.PhoneNo;
                            SMSModel.SMSSendingID = result.SMS_SendingID;
                            SMSModel.TelcoID = smsConfigurationModel.TelcoID;
                            SMSModel.IsOnNet = smsConfigurationModel.IsOnNet;
                            SMSModel.DeliveryStatusID = SMSDeliveryStatuses.SendToSMSC.GetHashCode();
                            SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();
                            SMSModel.Lang = lang;
                            bool IsEncodeOn = SMSModel.Lang.ToLower().Equals("en") ? false : true;
                            SMSModel.NoOfSMS = LazySingleton<ServerInfoBLL>.Instance.GetTotalNoOfSMS(message.SMSMessage, IsEncodeOn);
                            LazySingleton<SMSTransactionBLL>.Instance.Save(SMSModel);
                        }
                        else
                        {
                            B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
                        }
                    }
                }
                else
                {
                    B2BayLogger.Log("Something is missing or wrong.");
                    B2BayLogger.Log("campaignID " + campaignID);
                    B2BayLogger.Log("toPhoneNo " + message.PhoneNo);
                    B2BayLogger.Log("message " + message.SMSMessage);
                }
            }
            catch (InvalidPhoneNo ex)
            {


                // =================================== Add record in SMS Transactions =================================//
                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                if (result != null && result.SMS_SendingID > 0)
                {
                    SMSTransactionModel SMSModel = new SMSTransactionModel();
                    SMSModel.CampaignID = Convert.ToInt32(campaignID);
                    SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
                    SMSModel.SendMessage = message.SMSMessage;
                    SMSModel.ContactNo = message.PhoneNo;
                    SMSModel.SMSSendingID = result.SMS_SendingID;
                    SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
                    SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

                    LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
                }


                //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
                B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }
            catch (Exception ex)
            {

                string ErroCode = "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message;
                B2BayLogger.Log(ErroCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }

            B2BayLogger.WriteLogsToFile();
            Thread.Sleep(1000);
        }

        /// <summary>
        /// Store Data Into Buffer Storage
        /// </summary>
        /// <param name="campaignID"></param>
        /// <param name="organizationgID"></param>
        /// <param name="message"></param>
        //private void StoreDataIntoBuffer(string campaignID, string organizationgID, CMP.BE.APIClasses.SMSMessageModel message)
        //{
        //    try
        //    {
        //        B2BayLogger.Log("Call Method StoreDataIntoBuffer");

        //        if (ConfigurationHelper.IsSecured)          //check security encodeing enable then Decode Organization ID and Campaign ID
        //        {
        //            campaignID = CustomSecurity.DecodeFrom64(campaignID);
        //            organizationgID = CustomSecurity.DecodeFrom64(organizationgID);
        //        }
        //        Thread.Sleep(2000);
        //        B2BayLogger.Log("Wait for Send Request");
        //        //Check the SMS  Phone Number Validataion

        //        LazySingleton<SMSValidation>.Instance.CheckValidSMS(message.PhoneNo);


        //        if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID) && !string.IsNullOrEmpty(message.PhoneNo) && !string.IsNullOrEmpty(message.SMSMessage))
        //        {
        //            lock (Locker)
        //            {
        //                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
        //                if (result != null && result.SMS_SendingID > 0)
        //                {
        //                    // ========================================= Generate and Get SMS ID ======================================= //
        //                    string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(organizationgID, campaignID, result.SMS_SendingID.ToString());

        //                    //// ========================================= SMS Configuration Model======================================= //
        //                    SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.GetSMSConfigurationModel(message.PhoneNo);
        //                    //// ========================================= SMS Configuration Model ======================================= //

        //                    //// ========================================= Insert Into buffer Containner ======================================= //
        //                    SMSQueueModel smsQueueModel = new SMSQueueModel();
        //                    // Store Data into a SMSQueueModel
        //                    FillSMSQueueModel(campaignID, organizationgID, message, result, ID, smsQueueModel, smsConfigurationModel);

        //                    // Save To Que Table
        //                    LazySingleton<SMSQueueBLL>.Instance.Save(smsQueueModel);
        //                    //// ========================================= Insert Into buffer Containner ======================================= //

        //                }
        //                else
        //                {
        //                    B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
        //                }
        //            }
        //        }
        //        else
        //        {
        //            B2BayLogger.Log("Something is missing or wrong.");
        //            B2BayLogger.Log("campaignID " + campaignID);
        //            B2BayLogger.Log("toPhoneNo " + message.PhoneNo);
        //            B2BayLogger.Log("message " + message.SMSMessage);
        //        }
        //    }
        //    catch (InvalidPhoneNo ex)
        //    {


        //        // =================================== Add record in SMS Transactions =================================//
        //        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
        //        if (result != null && result.SMS_SendingID > 0)
        //        {
        //            SMSTransactionModel SMSModel = new SMSTransactionModel();
        //            SMSModel.CampaignID = Convert.ToInt32(campaignID);
        //            SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
        //            SMSModel.SendMessage = message.SMSMessage;
        //            SMSModel.ContactNo = message.PhoneNo;
        //            SMSModel.SMSSendingID = result.SMS_SendingID;
        //            SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
        //            SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

        //            LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
        //        }


        //        //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
        //        B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_CMPService, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.WriteLogsToFile();
        //    }
        //    catch (Exception ex)
        //    {

        //        string ErroCode = "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message;
        //        B2BayLogger.Log(ErroCode);
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.WriteLogsToFile();
        //    }

        //    B2BayLogger.WriteLogsToFile();
        //    Thread.Sleep(1000);
        //}
        private void StoreDataIntoBuffer(string campaignID, string organizationgID, string lang, CMP.BE.APIClasses.SMSMessageModel message)
        {
            try
            {
                B2BayLogger.Log("Call Method StoreDataIntoBuffer");

                if (ConfigurationHelper.IsSecured)          //check security encodeing enable then Decode Organization ID and Campaign ID
                {
                    campaignID = CustomSecurity.DecodeFrom64(campaignID);
                    organizationgID = CustomSecurity.DecodeFrom64(organizationgID);
                }
                Thread.Sleep(2000);
                B2BayLogger.Log("Wait for Send Request");
                //Check the SMS  Phone Number Validataion

                LazySingleton<SMSValidation>.Instance.CheckValidSMS(message.PhoneNo);


                if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID) && !string.IsNullOrEmpty(message.PhoneNo) && !string.IsNullOrEmpty(message.SMSMessage))
                {
                    lock (Locker)
                    {
                        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                        if (result != null && result.SMS_SendingID > 0)
                        {
                            // ========================================= Generate and Get SMS ID ======================================= //
                            string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(organizationgID, campaignID, result.SMS_SendingID.ToString());

                            //// ========================================= SMS Configuration Model======================================= //
                            SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.GetSMSConfigurationModel(message.PhoneNo);
                            //// ========================================= SMS Configuration Model ======================================= //

                            //// ========================================= Insert Into buffer Containner ======================================= //
                            SMSQueueModel smsQueueModel = new SMSQueueModel();
                            // Store Data into a SMSQueueModel
                            smsQueueModel.Lang = lang;
                            bool IsEncodeOn = smsQueueModel.Lang.ToLower().Equals("en") ? false : true;
                            smsQueueModel.NoOfSMS = LazySingleton<ServerInfoBLL>.Instance.GetTotalNoOfSMS(message.SMSMessage, IsEncodeOn);
                            FillSMSQueueModel(campaignID, organizationgID, message, result, ID, smsQueueModel, smsConfigurationModel);

                            // Save To Que Table
                            LazySingleton<SMSQueueBLL>.Instance.Save(smsQueueModel);
                            //// ========================================= Insert Into buffer Containner ======================================= //

                        }
                        else
                        {
                            B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
                        }
                    }
                }
                else
                {
                    B2BayLogger.Log("Something is missing or wrong.");
                    B2BayLogger.Log("campaignID " + campaignID);
                    B2BayLogger.Log("toPhoneNo " + message.PhoneNo);
                    B2BayLogger.Log("message " + message.SMSMessage);
                }
            }
            catch (InvalidPhoneNo ex)
            {


                // =================================== Add record in SMS Transactions =================================//
                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                if (result != null && result.SMS_SendingID > 0)
                {
                    SMSTransactionModel SMSModel = new SMSTransactionModel();
                    SMSModel.CampaignID = Convert.ToInt32(campaignID);
                    SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
                    SMSModel.SendMessage = message.SMSMessage;
                    SMSModel.ContactNo = message.PhoneNo;
                    SMSModel.SMSSendingID = result.SMS_SendingID;
                    SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
                    SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

                    LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
                }


                //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
                B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }
            catch (Exception ex)
            {

                string ErroCode = "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message;
                B2BayLogger.Log(ErroCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }

            B2BayLogger.WriteLogsToFile();
            Thread.Sleep(1000);
        }
        private void StoreDataIntoBuffer(string campaignID, string organizationgID, string lang,string telcoCode, CMP.BE.APIClasses.SMSMessageModel message)
        {
            try
            {
                B2BayLogger.Log("Call Method StoreDataIntoBuffer");

                if (ConfigurationHelper.IsSecured)          //check security encodeing enable then Decode Organization ID and Campaign ID
                {
                    campaignID = CustomSecurity.DecodeFrom64(campaignID);
                    organizationgID = CustomSecurity.DecodeFrom64(organizationgID);
                }
                Thread.Sleep(2000);
                B2BayLogger.Log("Wait for Send Request");
                //Check the SMS  Phone Number Validataion

                LazySingleton<SMSValidation>.Instance.CheckValidSMS(message.PhoneNo);


                if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID) && !string.IsNullOrEmpty(message.PhoneNo) && !string.IsNullOrEmpty(message.SMSMessage))
                {
                    lock (Locker)
                    {
                        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                        if (result != null && result.SMS_SendingID > 0)
                        {
                            // ========================================= Generate and Get SMS ID ======================================= //
                            string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(organizationgID, campaignID, result.SMS_SendingID.ToString());

                            //// ========================================= SMS Configuration Model======================================= //
                            SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.GetSMSConfigurationModel(message.PhoneNo, telcoCode);
                            //// ========================================= SMS Configuration Model ======================================= //

                            //// ========================================= Insert Into buffer Containner ======================================= //
                            SMSQueueModel smsQueueModel = new SMSQueueModel();
                            // Store Data into a SMSQueueModel
                            smsQueueModel.Lang = lang;
                            bool IsEncodeOn = smsQueueModel.Lang.ToLower().Equals("en") ? false : true;
                            smsQueueModel.NoOfSMS = LazySingleton<ServerInfoBLL>.Instance.GetTotalNoOfSMS(message.SMSMessage, IsEncodeOn);
                            FillSMSQueueModel(campaignID, organizationgID, message, result, ID, smsQueueModel, smsConfigurationModel);

                            // Save To Que Table
                            LazySingleton<SMSQueueBLL>.Instance.Save(smsQueueModel);
                            //// ========================================= Insert Into buffer Containner ======================================= //

                        }
                        else
                        {
                            B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
                        }
                    }
                }
                else
                {
                    B2BayLogger.Log("Something is missing or wrong.");
                    B2BayLogger.Log("campaignID " + campaignID);
                    B2BayLogger.Log("toPhoneNo " + message.PhoneNo);
                    B2BayLogger.Log("message " + message.SMSMessage);
                }
            }
            catch (InvalidPhoneNo ex)
            {


                // =================================== Add record in SMS Transactions =================================//
                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                if (result != null && result.SMS_SendingID > 0)
                {
                    SMSTransactionModel SMSModel = new SMSTransactionModel();
                    SMSModel.CampaignID = Convert.ToInt32(campaignID);
                    SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
                    SMSModel.SendMessage = message.SMSMessage;
                    SMSModel.ContactNo = message.PhoneNo;
                    SMSModel.SMSSendingID = result.SMS_SendingID;
                    SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
                    SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

                    LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
                }


                //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
                B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }
            catch (Exception ex)
            {

                string ErroCode = "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message;
                B2BayLogger.Log(ErroCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }

            B2BayLogger.WriteLogsToFile();
            Thread.Sleep(1000);
        }


        /// <summary>
        /// Fill SMS Queue Model
        /// </summary>
        /// <param name="campaignID"></param>
        /// <param name="organizationgID"></param>
        /// <param name="message"></param>
        /// <param name="result"></param>
        /// <param name="ID"></param>
        /// <param name="smsQueueModel"></param>
        /// <param name="smsConfigurationModel"></param>
        private static void FillSMSQueueModel(string campaignID, string organizationgID, CMP.BE.APIClasses.SMSMessageModel message, VerificationResult result, string ID, SMSQueueModel smsQueueModel, SMSConfigurationModel smsConfigurationModel)
        {
            // Fill SMS Configuratiol Model
            smsQueueModel.SMSGateway = smsConfigurationModel.SMSGateway;
            smsQueueModel.UserName = smsConfigurationModel.UserName;
            smsQueueModel.Password = smsConfigurationModel.Password;
            smsQueueModel.TelcoID = smsConfigurationModel.TelcoID;
            smsQueueModel.IsOnNet = smsConfigurationModel.IsOnNet;
            smsQueueModel.SMSSendingID = result.SMS_SendingID;
            //smsQueueModel.SMSSendingID = ID + "-" + smsQueueModel.TelcoID + "-" + Convert.ToInt32(smsQueueModel.IsOnNet);
            smsQueueModel.SendMessage = CommonMethod.ReplaceSpecilChar(message.SMSMessage);

            smsQueueModel.ShortCode = result.ShortCode;
            smsQueueModel.PriorityID = result.PriorityID;

            /// Extract Later
            //model.ServiceURL = GetUrl(smsCampaignModel, model.SendMessage, model.SMSSendingID, model.ShortCode);

            string networkTypeCode = string.Empty;
            if (smsConfigurationModel.SendPhoneNo.Length == 11)
            {
                networkTypeCode = smsConfigurationModel.SendPhoneNo.Substring(0, 3);
            }
            else
            {
                networkTypeCode = smsConfigurationModel.SendPhoneNo.Substring(2, 2);
                networkTypeCode = "0" + networkTypeCode;
            }

            smsQueueModel.CampaignID = Convert.ToInt32(campaignID);
            smsQueueModel.OrganizationID = Convert.ToInt32(organizationgID);

            smsQueueModel.Phone = LazySingleton<CommonBLL>.Instance.ConvertContactNo92(message.PhoneNo);
            smsQueueModel.ContactNo = message.PhoneNo;

            smsQueueModel.DeliveryStatusID = BufferStatusNames.AddToBuffer.GetHashCode();
            smsQueueModel.Mode = RequestSourceName.WebAPI.GetHashCode();
            smsQueueModel.IsSend = BufferStatusNames.AddToBuffer.GetHashCode();  /// Push to Buffer 
        }

        /// <summary>
        /// Updte the reponse of Sending SMs
        /// smsid split in different parameter
        /// 0= Oragnization ID,1=Campaign ID,SMS Sending ID= 2,  Telco ID = 3, Is On Net =4
        /// </summary>
        /// <param name="to"></param>
        /// <param name="smsid"></param>
        /// <param name="type"></param>
        /// <param name="network"></param>
        public void SMSDeliveryResponse(string to, string smsid, string type, string network)
        {
            string message = string.Empty;

            try
            {
                message = to + smsid + type + network;

                // ============================================= Entry to log file ============================================== //
                B2BayLogger.Log(message);
                B2BayLogger.Log("Method Name (SMSDeliveryResponse)");
                B2BayLogger.Log("To Phone No " + to + " smsid " + smsid + " Status-type " + type);

                if (!string.IsNullOrEmpty(smsid))
                {
                    string[] ids = smsid.Split('-');
                    //LazySingletonBLL<SMSTransactionBLL>.Instance.UpdateSMSDeliveryStatus(new SMSTransactionModel(Convert.ToInt32(ids[0]), Convert.ToInt32(ids[1]), Convert.ToInt32(ids[2]), Convert.ToInt32(type), to, network, Convert.ToInt32(ids[3])));
                    int result = LazySingletonBLL<SMSTransactionBLL>.Instance.UpdateSMSDeliveryStatus(new SMSTransactionModel()
                      {
                          OrganizationID = Convert.ToInt32(ids[0]),
                          CampaignID = Convert.ToInt32(ids[1]),
                          SMSSendingID = Convert.ToInt32(ids[2]),
                          DeliveryStatusID = Convert.ToInt32(type),
                          ContactNo = to,
                          Network = network,
                          TelcoID = Convert.ToInt32(ids[3]),
                          IsOnNet = Convert.ToBoolean(Convert.ToInt32(ids[4]))

                      });

                    B2BayLogger.Log("TelcoID " + ids[3] + " Is On Net " + ids[4]);
                    B2BayLogger.Log("Update Result " + result.ToString());
                }

                B2BayLogger.WriteLogsToFile();
            }
            catch (Exception ex)
            {
                B2BayLogger.LogErr(ex.Message, ex);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SMSDeliveryResponse " + message, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.WriteLogsToFile();
            }
        }

        public void Test(string smsid, string type)
        {
            try
            {
                throw new NotImplementedException();
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SMSDeliveryResponse" + smsid, 1, PageNames.SMS_CMPService, 0));
            }
        }






        public void SMSSendByUrl(string campaignID, string organizationgID, string lang, string phoneNumber, string smsMessage)
        {

            B2BayLogger.Log("ConfigurationHelper.IsBuffered" + ConfigurationHelper.IsBuffered.ToString());
            try
            {
                if (!string.IsNullOrEmpty(phoneNumber) && !string.IsNullOrEmpty(smsMessage))
                {
                    SMSMessageModel message = new SMSMessageModel();
                    message.PhoneNo = phoneNumber;
                    message.SMSMessage = smsMessage;
                    if (ConfigurationHelper.IsBuffered)
                    {
                        this.StoreDataIntoBuffer(campaignID, organizationgID, lang, message);
                    }
                    else
                    {
                        this.SendDirectToService(ref campaignID, ref organizationgID, lang, message);
                    }
                }

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SMSSendByUrl", 1, PageNames.SMS_CMPService, 0));
            }



        }
    }
}
