﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <19-10-2015 09:43:16AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPService.ApplicationClassess
{
    public class ConfigurationHelper
    {
        public static string SMSServiceUrl
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["SMSServiceUrl"];
            }
        }

        public static string SMSUserName
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["SMSUserName"];
            }
        }

        public static string SMSPassword
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["SMSPassword"];
            }
        }

        public static string SMSSendFrom
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["SMSSendFrom"];
            }

        }

        public static string SMSGateWay
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["SMSGateWay"];
            }
        }

        public static string HostingIP
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["HostingIP"];
            }
        }

        public static string WCFServiceName
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["WCFServiceName"];
            }
        }

        public static string LogFilePath
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["LogFilePath"];
            }
        }

        public static bool ShowLog
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["ShowLog"]);
            }
        }

        public static bool IsSecured
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["IsSecured"]);
            }
        }

        /// <summary>
        /// Direct Send SMS Set IsBuffered="false" OR Send SMS Form Buffered Set IsBuffered="true"
        /// </summary>
        public static bool IsBuffered
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["IsBuffered"]);
            }
        }

        
    }
}