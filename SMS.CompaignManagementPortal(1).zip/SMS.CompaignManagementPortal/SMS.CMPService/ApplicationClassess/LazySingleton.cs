﻿using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <19-10-2015 09:43:16AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPService.ApplicationClassess
{
    public abstract class LazySingleton<T>
    where T : new()
    {
        private static readonly Lazy<T> lazy = new Lazy<T>(() => new T());

        public static T Instance
        {
            get
            {
                return lazy.Value;
            }
        }
    }

}
