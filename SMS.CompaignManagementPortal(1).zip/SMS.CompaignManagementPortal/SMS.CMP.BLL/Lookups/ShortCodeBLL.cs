﻿using BE.CustomEnums;
using BLL.Common;
using BLL.CustomExceptions;
using DAL.Common;
using DAL.Lookups;
using SMS.CMP.BE.Lookups;
using SMS.CMP.DAL.Lookups;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.Lookups
{
    public class ShortCodeBLL
    {
        /// <summary>
        /// Save Short Code Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(ShortCodeModel model)
        {
            Hashtable htbWhere = new Hashtable();
            htbWhere.Add(ColumnName.OrganizationID.ToString(), model.OrganizationID.ToString ());
            htbWhere.Add(ColumnName.Title, model.Title);

            CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;
            if (model.ID > 0)
            {
                if (commonBLL.IsExist(TableName.tblShortCodes, ColumnName.SortCodeID, model.ID.ToString(), commonBLL.GetClause(htbWhere,ColumnName.SortCodeID, model.ID)))
                {
                    throw new BusinessException(CustomMsg.DuplicateCode);
                }
                //return new ShortCodeDAL().Edit(model);
                model.OrganizationTitle = null;
                return LazySingletonBLL<ShortCodeDAL>.Instance.Edit(model);
            }
            else if (commonBLL.IsExist(TableName.tblShortCodes, commonBLL.GetClause(htbWhere, null, null)))
            {
                throw new BusinessException(CustomMsg.DuplicateCode);
            }

            else

                //return new ShortCodeDAL().Add(model);
            return LazySingletonBLL<ShortCodeDAL>.Instance.Add(model);
        }

        /// <summary>
        /// Get All Short Codes
        /// </summary>
        /// <returns></returns>
        public List<ShortCodeModel> GetAllShortCodes()
        {
            //DataTable dt = null;
            //dt = new ShortCodeDAL().GetAllShortCodes();
            //return BuildModel(dt);

            try
            {
                return BindData(LazySingletonBLL<ShortCodeDAL>.Instance.GetAllShortCodes());
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Delete Short Code info
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(ShortCodeModel model)
        {
          //  return new ShortCodeDAL().Delete(id);


            try
            {
                return LazySingletonBLL<ShortCodeDAL>.Instance.Delete(new ShortCodeModel(model.ID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Getting Short Codes By organization ID
        /// </summary>
        /// <returns></returns>
        public List<ShortCodeModel> GetShortCodesByOrganizationID(int orgID)
        {
            try
            {
                return BindData(LazySingletonBLL<ShortCodeDAL>.Instance.GetShortCodesByOrganizationID(orgID));
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<ShortCodeModel> GetUserShortCodes(int? userID)
        {
            try
            {
                return BindData(LazySingletonBLL<ShortCodeDAL>.Instance.GetUserShortCodes(userID));
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<ShortCodeModel> GetShortCodesByOrganizationIDs(string organizationIDs)
        {
            try
            {
                return BindData(LazySingletonBLL<ShortCodeDAL>.Instance.GetShortCodesByOrganizationIDs(organizationIDs));
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }
        public List<ShortCodeModel> GetUserShortCodesByIDs(int? userID, int? oragainzationID)
        {
            try
            {
                return BindData(LazySingletonBLL<ShortCodeDAL>.Instance.GetUserShortCodesByIDs(userID, oragainzationID));
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }

        #region "Private Methods"



        private List<ShortCodeModel> BindData(DataTable dt)
        {
            List<ShortCodeModel> lists = new List<ShortCodeModel>();
            if (dt.Rows.Count > 0)
                lists = (List<ShortCodeModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new ShortCodeModel());

            return lists;
        }
        /// <summary>
        /// Build  Short Code Model
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<ShortCodeModel> BuildModel(DataTable dt)
        {
            List<ShortCodeModel> shortCodeModelList = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                shortCodeModelList = new List<ShortCodeModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    ShortCodeModel model = new ShortCodeModel();
                    if (dt.Columns.Contains("SortCodeID") && !Convert.IsDBNull(dr["SortCodeID"]))
                        model.ID = Convert.ToInt32(dr["SortCodeID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        model.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        model.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        model.IsActive = Convert.ToBoolean(dr["IsActive"]);

                    shortCodeModelList.Add(model);
                }

                shortCodeModelList.TrimExcess();
            }

            return shortCodeModelList;
        }
        #endregion
    }
}
