﻿using BLL.Common;
using SMS.CMP.BE.Lookups;
using SMS.CMP.DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.Lookups
{
    public class SMSDeliveryStatusBLL
    {

        /// <summary>
        /// Get All SMS Delivery Satatus
        /// </summary>
        /// <returns></returns>
        public List<SMSDeliveryStatusModel> GetAllSMSDeliveryStatus()
        {
            try
            {
                return BindData(LazySingletonBLL<SMSDeliveryStatusDAL>.Instance.GetSMSDeliveryStatus());
            }

            catch (Exception ex)
            {
                throw ex;
            }


        }

        /// <summary>
        /// Get All SMS Delivery Satatus
        /// </summary>
        /// <returns></returns>
        public List<SMSDeliveryStatusModel> GetAllSMSDeliveryStatusByUserID(int _userID)
        {
            try
            {
                return BindData(LazySingletonBLL<SMSDeliveryStatusDAL>.Instance.GetSMSDeliveryStatusByUserID(_userID));
            }

            catch (Exception ex)
            {
                throw ex;
            }


        }
        
        #region "Private Method"
        /// <summary>
        /// Buid Data model by using lazy binding
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private List<SMSDeliveryStatusModel> BindData(DataTable dt)
        {
            List<SMSDeliveryStatusModel> lists = new List<SMSDeliveryStatusModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSDeliveryStatusModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSDeliveryStatusModel());
            return lists;
        }
        #endregion

    }
}
