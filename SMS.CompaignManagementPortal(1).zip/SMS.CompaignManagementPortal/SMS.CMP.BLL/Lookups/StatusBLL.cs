﻿using BE.CustomEnums;
using BLL.Common;
using BLL.CustomExceptions;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.LookUps;
using SMS.CMP.DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Sabeeh Goheer>
    // Create date: <16-10-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // =================================================================================================================================
    public class StatusBLL
    {
        /// <summary>
        ///  Save and Update Status Model info in DB
        /// </summary>
        /// <param name="model">Status Model</param>
        /// <returns></returns>
        public int Save(StatusModel model)
        {
            CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;
            if (model.ID > 0)
            {
                if (commonBLL.IsExist(TableName.tblStatuses, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.ID, model.ID.Value)))
                {
                    throw new BusinessException(CustomMsg.DuplicateTitle);
                }
                model.ModifiedBy = 1;
                return LazySingletonBLL<StatusDAL>.Instance.Edit(model);
            }
            else if (commonBLL.IsExist(TableName.tblStatuses, ColumnName.Title, model.Title, null))
            {
                throw new BusinessException(CustomMsg.DuplicateTitle);
            }

            else
            {
                model.CreatedBy = 1;
                return LazySingletonBLL<StatusDAL>.Instance.Add(model);
            }
        }

        /// <summary>
        /// Getting All Status Record  
        /// </summary>
        /// <returns></returns>
        public List<StatusModel> GetAllStatuses()
        {
            return BindData(LazySingletonBLL<StatusDAL>.Instance.GetAllStatuses());
        }

        /// <summary>
        /// Getting All Active Status Record  
        /// </summary>
        /// <returns></returns>
        public List<StatusModel> GetAllActiveStatuses()
        {

            return BindData(LazySingletonBLL<StatusDAL>.Instance.GetAllActiveStatuses());

        }

        /// <summary>
        /// Delete Status By ID
        /// </summary>
        /// <param name="dt">Status Model</param>
        /// <returns>Inetegr value</returns>
        /// 
        public int Delete(StatusModel model)
        {
            return LazySingletonBLL<StatusDAL>.Instance.Delete(new StatusModel(model.StatusID));
        }

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns>Mask Model</returns>
        /// 
        private List<StatusModel> BindData(DataTable dt)
        {
            List<StatusModel> lists = new List<StatusModel>();
            if (dt.Rows.Count > 0)
                lists = (List<StatusModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new StatusModel());

            return lists;
        }

    }
}
