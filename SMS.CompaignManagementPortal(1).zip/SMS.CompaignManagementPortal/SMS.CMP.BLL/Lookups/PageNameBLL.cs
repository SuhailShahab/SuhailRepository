﻿
using BE.Lookups;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BLL.Lookups
{
    public class PageNameBLL
    {
        /// <summary>
        /// Get Page Names
        /// </summary>
        /// <returns></returns>
        public List<PageNameModel> GetPages()
        {
            DataTable dt = null;
            dt = new PageNameDAL().GetPages();
            return BuildModel(dt);
        }


        #region "Private Methods"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<PageNameModel> BuildModel(DataTable dt)
        {
            List<PageNameModel> PageNames = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                PageNames = new List<PageNameModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    PageNameModel PageNamemodel = new PageNameModel();

                    if (dt.Columns.Contains("PageName") && !Convert.IsDBNull(dr["PageName"]))
                        PageNamemodel.pageName = Convert.ToString(dr["PageName"]);

                    if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                        PageNamemodel.StaticName = Convert.ToString(dr["StaticName"]);

                    if (dt.Columns.Contains("FileNameURL") && !Convert.IsDBNull(dr["FileNameURL"]))
                        PageNamemodel.FileNameURL = Convert.ToString(dr["FileNameURL"]);

                    if (dt.Columns.Contains("URL") && !Convert.IsDBNull(dr["URL"]))
                        PageNamemodel.URL = Convert.ToString(dr["URL"]);


                    PageNames.Add(PageNamemodel);
                }

                PageNames.TrimExcess();
            }

            return PageNames;
        }

        #endregion
    }
}
