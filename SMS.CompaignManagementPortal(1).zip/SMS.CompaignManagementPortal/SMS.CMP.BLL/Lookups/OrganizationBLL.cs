﻿using System;
using System.Data;
using System.Collections.Generic;
using BE.Lookups;
using BLL.Common;
using BE.CustomEnums;
using DAL.Lookups;
using SMS.CMP.BLL.Common;
using DAL.Common;
using BLL.CustomExceptions;

namespace BLL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:30AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    //   001             Sajjad Aslam           17-03-2017 03:14 PM     Using RepositoryBLL 
    // =================================================================================================================================
    public class OrganizationBLL : RepositoryBLL<OrganizationModel>
    {
        public int Save(OrganizationModel model)
        {
            CommonBLL commonBLL = new CommonBLL();
            try
            {
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblOrganizations, ColumnName.Code, model.Code, commonBLL.GetClause(ColumnName.OrganizationID, model.ID.Value)))
                    {
                        throw new BusinessException(CustomMsg.DuplicateCode);
                    }
                    else if (commonBLL.IsExist(TableName.tblOrganizations, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.OrganizationID, model.ID.Value)))
                    {
                        throw new BusinessException(CustomMsg.DuplicateTitle);
                    }
                    return new OrganizationDAL().Edit(model);
                }
                else if (commonBLL.IsExist(TableName.tblOrganizations, ColumnName.Code, model.Code, null))
                {
                    throw new BusinessException(CustomMsg.DuplicateCode);
                }
                else if (commonBLL.IsExist(TableName.tblOrganizations, ColumnName.Title, model.Title, null))
                {
                    throw new BusinessException(CustomMsg.DuplicateTitle);
                }

                else
                    return new OrganizationDAL().Add(model);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                commonBLL = null;

            }

        }
        public List<OrganizationModel> GetOrganizations()
        {
            //DataTable dt = null;
            //dt = new OrganizationDAL().GetAll();
            //return BuildModel(dt);
            try 
            {
                DataTable dt = LazySingletonDAL<OrganizationDAL>.Instance.GetAll();
                return this.BuildModellst(dt);
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
        }


        public List<OrganizationModel> GetALLOrganizations()
        {
            //DataTable dt = null;
            //dt = new OrganizationDAL().GetAllOrganizations();
            //return BuildModel(dt);
            try
            {
                DataTable dt = LazySingletonDAL<OrganizationDAL>.Instance.GetAllOrganizations();
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        /// <summary>
        /// Get Organization
        /// </summary>
        /// <returns></returns>
        public List<OrganizationModel> SelectOrganizationByUserID(int userID)
        {
            //DataTable dt = null;
            //dt = new OrganizationDAL().SelectOrganizationByUserID(userID);
            //return BuildModel(dt);
            try
            {
                DataTable dt = LazySingletonDAL<OrganizationDAL>.Instance.SelectOrganizationByUserID(userID);
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get Organization by ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public List<OrganizationModel> GetOrganization(int id)
        {
            //DataTable dt = null;
            //dt = new OrganizationDAL().SelectOrganization(id);
            //return BuildModel(dt);
            try
            {
                DataTable dt = LazySingletonDAL<OrganizationDAL>.Instance.SelectOrganization(id);
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<OrganizationModel> GetOrganization(int? userID, int? organizationID)
        {
            //DataTable dt = null;
            //try
            //{
            //    dt = new OrganizationDAL().SelectOrganization(userID, organizationID);
            //    return BuildModel(dt);
            //}
            //catch(Exception ex)
            //{
            //    throw ex;
            //}
            try
            {
                DataTable dt = LazySingletonDAL<OrganizationDAL>.Instance.SelectOrganization(userID, organizationID);
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }



        public int Delete(int id, int modifiedBy)
        {
            //OrganizationDAL organizationDAL = new OrganizationDAL();
            //int result = organizationDAL.Delete(id, modifiedBy);
            //organizationDAL = null;
            //return result;
            try
            {
                OrganizationDAL organizationDAL = new OrganizationDAL();
                int result = organizationDAL.Delete(id, modifiedBy);
                organizationDAL = null;
                return result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }

        #region "Private Methods"

        internal List<OrganizationModel> BuildModel(DataTable dt)
        {
            List<OrganizationModel> organization = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                organization = new List<OrganizationModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    OrganizationModel organizationModel = new OrganizationModel();

                    organizationModel.ID = Convert.ToInt32(dr["OrganizationID"]);
                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        organizationModel.Code = Convert.ToString(dr["Code"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        organizationModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        organizationModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    organizationModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    organization.Add(organizationModel);
                }

                organization.TrimExcess();
            }

            return organization;
        }

        #endregion
    }
}
