﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Collections;
using BE.Lookups;
using BLL.Common;
using BE.CustomEnums;
using DAL.Lookups;
using SMS.CMP.BLL.Common;
using System.Linq;
using DAL.Common;
using BLL.CustomExceptions;
namespace BLL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <26-12-2014 08:30PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time      Desription
    // 001          Muhammad Usman              30-Sep-2015             Add Method Get Permitted Districts 
    // 002          Syed Zeeshan Aqil           30-Oct-2015             Add Method GetDepartmentByOrgIDByUserID
    // CR: 003          Sohail Kamran           12-01-2016 5:30 PM      Add PerSMSRate to existing model
    // CR: 004          Sajjad Aslam           21-03-2017 12:25 PM      Code Optimization by using Repository Model and Try Catch
    // =================================================================================================================================

    public class DepartmentsBLL : RepositoryBLL<DepartmentsModel>
    {

        public int? Save(DepartmentsModel departmentModel)
        {
            Hashtable htbWhere = new Hashtable();
            htbWhere.Add(ColumnName.Code, departmentModel.Code);


            try
            {
                CommonBLL commonBLL = new CommonBLL();

                if (!string.IsNullOrEmpty(departmentModel.Title))
                {
                    if (departmentModel.DepartmentID.HasValue && departmentModel.DepartmentID.Value > 0)
                    {
                        if (commonBLL.IsExist(TableName.tblDepartments, ColumnName.Title, departmentModel.Title, commonBLL.GetClause(htbWhere, ColumnName.DepartmentID, departmentModel.DepartmentID.Value)))
                        {
                            throw new BusinessException(CustomMsg.DuplicateTitle);
                        }
                        return new DepartmentsDAL().Edit(departmentModel);
                    }
                    else if (commonBLL.IsExist(TableName.tblDepartments, ColumnName.Title, departmentModel.Title, commonBLL.GetClause(htbWhere, null, null)))
                    {
                        throw new BusinessException(CustomMsg.DuplicateTitle);
                    }
                    else
                        return new DepartmentsDAL().Add(departmentModel);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }


        public List<DepartmentsModel> GetDepartments()
        {
            //DataTable dt = null;
            //dt = new DepartmentsDAL().GetAll();
            //return BuildDataModel(dt);
            try
            {
                DataTable dt = null;
                dt = LazySingletonDAL<DepartmentsDAL>.Instance.GetAll();
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDepartments" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }

        }


        public int Delete(int departmentID)
        {
            return new DepartmentsDAL().Delete(departmentID);
        }

        public List<DepartmentsModel> GetAllDistricts()
        {
            //DataTable dt = null;
            //dt = new DepartmentsDAL().SelectDistricts();
            //return BuildDataModel(dt);
            try
            {
                DataTable dt = null;
                dt = LazySingletonDAL<DepartmentsDAL>.Instance.SelectDistricts();
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllDistricts" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public List<DepartmentsModel> GetActiveDepartments()
        {
            //DataTable dt = new DepartmentsDAL().GetActiveDepartments();
            //return BuildDataModel(dt);
            try
            {
                DataTable dt = null;
                dt = LazySingletonDAL<DepartmentsDAL>.Instance.GetActiveDepartments();
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetActiveDepartments" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        public List<DepartmentsModel> GetDepatmentsByUserID(int userID)
        {

            try
            {
                //DataTable dt = null;
                //dt = new DepartmentsDAL().GetDepatmentsByUserID(userID);
                //return BuildModelUserDept(dt);

                DataTable dt = null;
                dt = LazySingletonDAL<DepartmentsDAL>.Instance.GetDepatmentsByUserID(userID);
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDepatmentsByUserID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        public List<DepartmentsModel> SelectActiveDepartmentsByOrgID(int organizationID)
        {
            try
            {
                DataTable dt = LazySingletonDAL<DepartmentsDAL>.Instance.SelectActiveDepartmentsByOrgID(organizationID);
                return this.BuildModellst(dt);

                // DataTable dt = new DepartmentsDAL().SelectActiveDepartmentsByOrgID(organizationID);
                // return BuildDataModel(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SelectActiveDepartmentsByOrgID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }

        }
        public List<DepartmentsModel> SelectActiveDepartmentsByOrgID(int? organizationID, int? userID, int? departmentID)
        {
            //DataTable dt = new DepartmentsDAL().SelectActiveDepartmentsByOrgID(organizationID, userID, departmentID);
            //return BuildDataModel(dt);
            try
            {
                DataTable dt = null;
                dt = LazySingletonDAL<DepartmentsDAL>.Instance.SelectActiveDepartmentsByOrgID(organizationID, userID, departmentID);
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SelectActiveDepartmentsByOrgID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        public List<DepartmentsModel> SelectDepartmentsByMultiOrgID(string organizationID)
        {
            try
            {
                DataTable dt = LazySingletonDAL<DepartmentsDAL>.Instance.SelectDepartmentsByMultiOrgID(organizationID);
                return BuildModelUserDept(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SelectDepartmentsByMultiOrgID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }

        }

        /// <summary>
        /// CR: 003
        /// Get District Data from DB on the basis od Division ID
        /// </summary>
        /// <returns>return the District Model with District Data</returns>
        public List<DepartmentsModel> GetDistrictsByDivisionID(int DivisionID)
        {
            try
            {

                DataTable dt = null;
                dt = new DepartmentsDAL().GetDistrictsByDivisionID(DivisionID);
                return BuildModelUserDistrict(dt);
                //DataTable dt = LazySingletonDAL<DepartmentsDAL>.Instance.GetDistrictsByDivisionID(DivisionID);
                //return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDistrictsByDivisionID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        /// <summary>
        /// //002
        /// Get Departments  Info By Organization and User base
        /// </summary>
        /// <param name="orgID"> Current Selected Organization ID</param>
        /// <param name="userID">Current Login User ID</param>
        /// <returns>Department List</returns>
        public List<DepartmentsModel> GetDepartmentByOrgIDByUserID(int orgID, int userID)
        {
            // DataTable dt = LazySingletonBLL<DepartmentsDAL>.Instance.GetDepartmentByOrgIDByUserID(orgID, userID);
            //// DataTable dt = new DepartmentsDAL().GetDepartmentByOrgIDByUserID(orgID, userID);
            // return BuildDataModel(dt);
            try
            {
                DataTable dt = LazySingletonDAL<DepartmentsDAL>.Instance.GetDepartmentByOrgIDByUserID(orgID, userID);
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDepartmentByOrgIDByUserID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        public List<DepartmentsModel> GetDeptByOrganizationID(int orgID, int userID)
        {
            List<DepartmentsModel> departments = null;
            try
            {
                DataTable dt = LazySingletonBLL<DepartmentsDAL>.Instance.GetDepartmentByOrgIDByUserID(orgID, userID);
                departments = this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDepartmentByOrgIDByUserID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
            return departments;
        }


        public List<DepartmentsModel> spGetUserDeptByIDs(int userID, int? organizationID, int? departmentID)
        {
            try
            {
                DataTable dt = LazySingletonBLL<DepartmentsDAL>.Instance.spGetUserDeptByIDs(userID, organizationID, departmentID);
                // return BuildDataModel(dt);
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "spGetUserDeptByIDs" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }

        }

        public List<DepartmentsModel> GetBillingDepartments()
        {
            try
            {
                DataTable dt = LazySingletonDAL<DepartmentsDAL>.Instance.GetBillingDepartments();
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetBillingDepartments" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        public List<DepartmentsModel> GetDepartmentsByBillingDptID(int? billingDptID)
        {
            try
            {
                DataTable dt = LazySingletonDAL<DepartmentsDAL>.Instance.GetDepartmentsByBillingDptID(billingDptID);
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetBillingDepartments" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        #region "Private Methods"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public List<DepartmentsModel> BuildDataModel(DataTable dt)
        {
            List<DepartmentsModel> departments = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                departments = new List<DepartmentsModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    DepartmentsModel departmentModel = new DepartmentsModel();
                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                        departmentModel.DepartmentID = Convert.ToInt32(dr["DepartmentID"]);
                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                        departmentModel.ID = Convert.ToInt32(dr["DepartmentID"]);
                    if (dt.Columns.Contains("OrganizationID") && !Convert.IsDBNull(dr["OrganizationID"]))
                        departmentModel.OrganizationID = Convert.ToInt32(dr["OrganizationID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        departmentModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        departmentModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        departmentModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("Organization") && !Convert.IsDBNull(dr["Organization"]))
                        departmentModel.Organization = Convert.ToString(dr["Organization"]);
                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        departmentModel.Code = Convert.ToString(dr["Code"]);
                    if (dt.Columns.Contains("PerSMSRate") && !Convert.IsDBNull(dr["PerSMSRate"]))  // CR: 003
                        departmentModel.PerSMSRate = Convert.ToDecimal(dr["PerSMSRate"]);

                    departments.Add(departmentModel);
                }

                departments.TrimExcess();
            }

            return departments;
        }




        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns> 
        internal List<DepartmentsModel> BuildModelUserDept(DataTable dt)
        {
            List<DepartmentsModel> departments = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                departments = new List<DepartmentsModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    DepartmentsModel departmentModel = new DepartmentsModel();
                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                        departmentModel.Department = Convert.ToString(dr["DepartmentID"]);
                    if (dt.Columns.Contains("Department") && !Convert.IsDBNull(dr["Department"]))
                        departmentModel.Department = Convert.ToString(dr["Department"]);
                    if (dt.Columns.Contains("OrganizationID") && !Convert.IsDBNull(dr["OrganizationID"]))
                        departmentModel.OrganizationID = Convert.ToInt32(dr["OrganizationID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        departmentModel.Title = Convert.ToString(dr["Title"]);
                    departments.Add(departmentModel);
                }
                departments.TrimExcess();
            }

            return departments;
        }


        internal List<DepartmentsModel> BuildModelUserDistrict(DataTable dt)
        {
            List<DepartmentsModel> departments = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                departments = new List<DepartmentsModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    DepartmentsModel departmentModel = new DepartmentsModel();
                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        departmentModel.ID = Convert.ToInt32(dr["DistrictID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        departmentModel.Title = Convert.ToString(dr["Title"]);
                    departments.Add(departmentModel);
                }
                departments.TrimExcess();
            }

            return departments;
        }
        #endregion

    }
}

