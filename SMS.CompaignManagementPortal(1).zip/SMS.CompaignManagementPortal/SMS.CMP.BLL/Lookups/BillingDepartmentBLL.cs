﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Collections;
using BE.Lookups;
using BLL.Common;
using BE.CustomEnums;
using DAL.Lookups;
using SMS.CMP.BLL.Common;
using System.Linq;
using DAL.Common;
using BLL.CustomExceptions;
namespace BLL.Lookups
{
    // Created by:	<Muhammad Shakeel>
    // Created date: <22-03-2018>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================

    public class BillingDepartmentBLL : RepositoryBLL<BillingDepartmentModel>
    {

        public int? Save(List<BillingDepartmentModel> model, int? userID)
        {
            DataTable dt = null;
            int? result = null;
            int? vBillingDptID = null;
            try
            {
                if (model != null && model.Count() > 0)
                {
                    dt = this.ToDataTable((from item in model
                                           where (item.DepartmentID != null)
                                           select new
                                           {
                                               item.DepartmentID
                                           }).ToList());
                }
                if (dt != null && dt.Rows.Count > 0)
                {
                    vBillingDptID = Convert.ToInt32(model.Select(s => s.BillingDptID).FirstOrDefault());
                    result = new BillingDepartmentDAL().Save(dt, vBillingDptID, userID);
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<BillingDepartmentModel> GetBillingDepartment()
        {
            try
            {
                DataTable dt = null;
                dt = LazySingletonDAL<BillingDepartmentDAL>.Instance.GetAll();
                return this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetBillingDepartment" + ex.Message, 0, PageNames.BillingDepartment, 0));
                throw ex;
            }
        }

        public int Delete(BillingDepartmentModel model)
        {
            try
            {
                return new BillingDepartmentDAL().Delete(model);
            }
            catch (Exception)
            {
                throw;
            }
        }

        #region "Private Methods"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        public List<BillingDepartmentModel> BuildDataModel(DataTable dt)
        {
            List<BillingDepartmentModel> BillingDepartment = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                BillingDepartment = new List<BillingDepartmentModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    BillingDepartmentModel departmentModel = new BillingDepartmentModel();
                    if (dt.Columns.Contains("BillingDptID") && !Convert.IsDBNull(dr["BillingDptID"]))
                        departmentModel.BillingDptID = Convert.ToInt32(dr["BillingDptID"]);
                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                        departmentModel.DepartmentID = Convert.ToInt32(dr["DepartmentID"]);

                    BillingDepartment.Add(departmentModel);
                }

                BillingDepartment.TrimExcess();
            }
            return BillingDepartment;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns> 
        internal List<BillingDepartmentModel> BuildModelUserDept(DataTable dt)
        {
            List<BillingDepartmentModel> BillingDepartment = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                BillingDepartment = new List<BillingDepartmentModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    BillingDepartmentModel departmentModel = new BillingDepartmentModel();
                    if (dt.Columns.Contains("BillingDptID") && !Convert.IsDBNull(dr["BillingDptID"]))
                        departmentModel.BillingDptID = Convert.ToInt32(dr["BillingDptID"]);
                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                        departmentModel.DepartmentID = Convert.ToInt32(dr["DepartmentID"]);

                    BillingDepartment.Add(departmentModel);
                }
                BillingDepartment.TrimExcess();
            }

            return BillingDepartment;
        }
        #endregion
    }
}

