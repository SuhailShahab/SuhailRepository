﻿using BLL.Common;
using SMS.CMP.BE.Lookups;
using SMS.CMP.DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.Lookups
{
    public class NetworksCodeBLL
    {

        public List<NetworksCodeModel> GetAllNetWorkCodes()
        {
            try
            {
                return BindData(LazySingletonBLL<NetworksCodeDAL>.Instance.GetAllNetworksCode());
            }

            catch (Exception ex)
            {
                throw ex;
            }

        }


        private List<NetworksCodeModel> BindData(DataTable dt)
        {
            List<NetworksCodeModel> lists = new List<NetworksCodeModel>();
            if (dt.Rows.Count > 0)
                lists = (List<NetworksCodeModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new NetworksCodeModel());

            return lists;
        }
    }
}
