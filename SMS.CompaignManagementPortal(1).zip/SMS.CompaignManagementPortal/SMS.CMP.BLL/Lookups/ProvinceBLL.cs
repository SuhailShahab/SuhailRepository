﻿
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using DAL.Common;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Lookups
{
    public class ProvinceBLL
    {

        public int Save(ProvinceModel model)
        {
            CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;
            if (model.ID > 0)
            {

                if (commonBLL.IsExist(TableName.tblProvinces, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.ProvinceID, model.ID)))
                {
                    throw new BusinessException(CustomMsg.DuplicateTitle);
                }
                return new ProvinceDAL().Edit(model);
            }
            else if (commonBLL.IsExist(TableName.tblProvinces, ColumnName.Title, model.Title, null))
            {
                throw new BusinessException(CustomMsg.DuplicateTitle);
            }

            else

                return new ProvinceDAL().Add(model);
        }
        /// <summary>
        /// Getting All Provinces Record  
        /// </summary>
        /// <returns></returns>
        public List<ProvinceModel> GetAllProvinces()
        {
            DataTable dt = null;
            dt = new ProvinceDAL().GetAllProvinces();
            return BuildModel(dt);
        }

        /// <summary>
        /// Getting All Active Provinces Record  
        /// </summary>
        /// <returns></returns>
        public List<ProvinceModel> GetAllActiveProvinces() 
        {
            DataTable dt = null;
            dt = new ProvinceDAL().GetAllActiveProvinces(); 
            return BuildModel(dt);
        }


        /// <summary>
        /// Getting Province By ID
        /// </summary>
        /// <returns></returns>
        public List<ProvinceModel> GetProvinceByID(int id)
        {
            DataTable dt = null;
            dt = new ProvinceDAL().GetProvincesByID(id);
            return BuildModel(dt);
        }

        public int Delete(int id)
        {
            return new ProvinceDAL().Delete(id);
        }

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<ProvinceModel> BuildModel(DataTable dt)
        {
            List<ProvinceModel> provinceModelList = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                provinceModelList = new List<ProvinceModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    ProvinceModel model = new ProvinceModel();
                    if (dt.Columns.Contains("ProvinceID") && !Convert.IsDBNull(dr["ProvinceID"]))
                        model.ID = Convert.ToInt32(dr["ProvinceID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        model.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        model.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        model.IsActive = Convert.ToBoolean(dr["IsActive"]);

                    provinceModelList.Add(model);
                }

                provinceModelList.TrimExcess();
            }

            return provinceModelList;
        }
    }
}
