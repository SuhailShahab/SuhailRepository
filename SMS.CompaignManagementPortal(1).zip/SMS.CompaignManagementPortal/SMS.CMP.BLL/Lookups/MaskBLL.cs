﻿using BE.CustomEnums;
using BLL.Common;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using SMS.CMP.DAL.Lookups;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <16-10-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // =================================================================================================================================
    public class MaskBLL
    {
        /// <summary>
        ///  Save and Update Mask Model info in DB
        /// </summary>
        /// <param name="model">Mask Model</param>
        /// <returns></returns>
        public int Save(MaskModel model)
        {

            int Result = 0;
            CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;
            if (model.ID > 0)
            {
                model.ModifiedBy = 1;
                Result = LazySingletonBLL<MaskDAL>.Instance.Edit(model);
            }
            else
            {
                model.CreatedBy = 1;
                Result = LazySingletonBLL<MaskDAL>.Instance.Add(model);
            }

            return Result;
        }


        /// <summary>
        /// Getting All Mask Record  
        /// </summary>
        /// <returns></returns>
        public List<MaskModel> GetAllMasks()
        {
            return BindData(LazySingletonBLL<MaskDAL>.Instance.GetAllMasks());
        }

        /// <summary>
        /// Getting All Mask Record  
        /// </summary>
        /// <returns></returns>
        public List<MaskModel> GetMasksByShortCodeID(int shortCodeID, int departmentID)
        {
            return BindData(LazySingletonBLL<MaskDAL>.Instance.GetMasksByShortCodeID(shortCodeID, departmentID));
        }

        /// <summary>
        /// Getting All Active Mask Record  
        /// </summary>
        /// <returns></returns>
        public List<MaskModel> GetAllActiveMasks()
        {

            return BindData(LazySingletonBLL<MaskDAL>.Instance.GetAllActiveMasks());

        }

        /// <summary>
        /// Delete Mask  Info
        /// </summary>
        /// <param name="model">Mask Model</param>
        /// <returns></returns>
        public int Delete(MaskModel model)
        {
            return LazySingletonBLL<MaskDAL>.Instance.Delete(model);
        }



        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns>Mask Model</returns>
        /// 
        private List<MaskModel> BindData(DataTable dt)
        {
            List<MaskModel> lists = new List<MaskModel>();
            if (dt.Rows.Count > 0)
                lists = (List<MaskModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new MaskModel());

            return lists;
        }

    }
}
