﻿using BE.CustomEnums;
using BLL.Common;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{
    public class AddressBookContactBLL
    {
        /*
        public List<AddressBookContactsModel> GetAllAddressBookContact()
        {
            return BindData(LazySingletonBLL<AddressBookContactDAL>.Instance.GetAllsBookContact());
        }
        */

        public List<AddressBookContactsModel> GetAllAddressBookContactBySearch(int addressBookID, int organizationID)
        {
            return BindData(LazySingletonBLL<AddressBookContactDAL>.Instance.GetAllsBookContactBySearch( addressBookID,  organizationID));
        }


        private List<AddressBookContactsModel> BindData(DataTable dt)
        {
            List<AddressBookContactsModel> lists = new List<AddressBookContactsModel>();
            if (dt.Rows.Count > 0)

                lists = (List<AddressBookContactsModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new AddressBookContactsModel());

            return lists;
        }
       
    }
}
