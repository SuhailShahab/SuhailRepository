﻿using BE.CustomEnums;
using BLL.Common;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Common;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{

    // =================================================================================================================================
    // Create by:	<Sohail Shahab>
    // Create date: <11/19/2015 8:18:55 PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // CR:001       Syed Zeeshan Aqil           24-11-2015 01:37 PM         This method "GetSMSTransactionResponses" user to Get The Transaction Response
    // =================================================================================================================================
    public class SMSTransactionBLL
    {
        /// <summary>
        /// Save the Transaction Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(SMSTransactionModel model)
        {
            try
            {
                if (model.SMSTransactionID > 0)
                {

                    return LazySingletonBLL<SMSTransactionDAL>.Instance.Edit(model);
                }

                else
                {
                    return LazySingletonBLL<SMSTransactionDAL>.Instance.Add(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        public int AddInvalidSMSTransaction(SMSTransactionModel model)
        {

            try
            {
                return LazySingletonBLL<SMSTransactionDAL>.Instance.AddInvalidSMSTransaction(model);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public int UpdateSMSDeliveryStatus(SMSTransactionModel model)
        {
            try
            {
                return LazySingletonBLL<SMSTransactionDAL>.Instance.UpdateSMSDeliveryStatus(model);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// For Getting all the Transaction Information
        /// </summary>
        /// <returns></returns>
        public List<SMSTransactionModel> GetAllTransactions()
        {
            return BindData(LazySingletonBLL<SMSTransactionDAL>.Instance.GetAll());
        }


        /// <summary>
        /// // 001 
        /// This Method is use to get the sms transection responses by campaign and response ID
        /// </summary>
        /// <param name="campaignID">Selectd Capmaign ID</param>
        /// <param name="responseID">Selected Response ID</param>
        /// <returns>Transaction Response List</returns>
        public List<SMSTransactionModel> GetSMSTransactionResponses(int campaignID, int responseID, string replyPhoneNo, int? recordID)
        {
            return BindData(LazySingletonBLL<SMSTransactionDAL>.Instance.GetSMSTransactionResponses(campaignID, responseID, replyPhoneNo, recordID));
        }



        //public int? VerifiedUser(int? organizationID, int? compainedID)
        //{
        //    try
        //    {
        //        int? vResult = null;
        //        DataTable dt = new DataTable();
        //        SMSTransactionDAL smsTransactionDAL = new SMSTransactionDAL();
        //        dt = smsTransactionDAL.VerifiedUser(organizationID, compainedID);
        //        if (dt != null && dt.Rows.Count > 0 && !Convert.IsDBNull(dt.Rows[0]["TransactionID"]))
        //        {
        //            vResult = Convert.ToInt32(dt.Rows[0]["TransactionID"])+1;
        //        }
        //        return vResult;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //    }
        //    return null;

        //}


        public VerificationResult VerifiedUser(int? organizationID, int? compainedID)
        {
            try
            {

                DataTable dt = new DataTable();
                // smsTransactionDAL = new SMSTransactionDAL();

                VerificationResult result = null;
                dt = LazySingletonDAL<SMSTransactionDAL>.Instance.VerifiedUser(organizationID, compainedID);
                if (dt != null && dt.Rows.Count > 0 && !Convert.IsDBNull(dt.Rows[0]["TransactionID"]))
                {
                    result = new VerificationResult();
                    result.SMS_SendingID = Convert.ToInt32(dt.Rows[0]["TransactionID"]) + 1;
                    if (dt.Columns.Contains("ShortCode"))
                        result.ShortCode = Convert.ToString(dt.Rows[0]["ShortCode"]);
                    if (dt.Columns.Contains("SMSMessage"))
                        result.SMSMessage = Convert.ToString(dt.Rows[0]["SMSMessage"]);
                    if (dt.Columns.Contains("VersionNo"))
                        result.VersionNo = Convert.ToInt32(dt.Rows[0]["VersionNo"]);
                    if (dt.Columns.Contains("PriorityID") && !Convert.IsDBNull(dt.Rows[0]["PriorityID"]))
                        result.PriorityID = Convert.ToInt32(dt.Rows[0]["PriorityID"]);

                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }


        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns>Transaction Model</returns>
        /// 
        private List<SMSTransactionModel> BindData(DataTable dt)
        {
            List<SMSTransactionModel> lists = new List<SMSTransactionModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSTransactionModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSTransactionModel());

            return lists;
        }

        /// <summary>
        /// For Getting Transaction Information By CmpaignID
        /// </summary>
        /// <returns></returns>
        public List<SMSTransactionModel> GetTransactionsByCampaignID(int CampaignID, int Mode, string filterdCSVList, string phoneNo, int Status, string dtFrom, string dtTo)
        {
            //DataTable dt = new DataTable();
            //dt = LazySingletonBLL<SMSTransactionDAL>.Instance.GetTransactionsByCampaignID(CampaignID, Mode, filterdCSVList, phoneNo, Status);
            //return dt;
            try
            {
                return BindData(LazySingletonBLL<SMSTransactionDAL>.Instance.GetTransactionsByCampaignID(CampaignID, Mode, filterdCSVList, phoneNo, Status, dtFrom, dtTo));
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        /// <summary>
        /// Get Transaction Information 
        /// </summary>
        /// <param name="CampaignID"></param>
        /// <param name="Mode"></param>
        /// <param name="phoneNo"></param>
        /// <returns></returns>
        public List<SMSTransactionModel> GetTransactionsDetailByCampaignID(int CampaignID, int Mode, string phoneNo)
        {
            //return BindData(LazySingletonBLL<SMSTransactionDAL>.Instance.GetTransactionsDetailByCampaignID(CampaignID, Mode, phoneNo));
            try
            {
                return BindData(LazySingletonBLL<SMSTransactionDAL>.Instance.GetTransactionsDetailByCampaignID(CampaignID, Mode, phoneNo));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



    }
}
