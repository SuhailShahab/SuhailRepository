﻿using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using DAL.Common;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;

namespace SMS.CMP.BLL.CMP
{

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <23-11-2015 03:37 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// 001          Sued Zeeshan Aqil           19-Nov- 2015 12:30 PM       Add Method  GetSMSResponseMessage to get Message
// 002           Sajjad Aslam                13-03-2017 12:11 PM        Load data on Filter base (adding parametter isLoad in GetSMSResponses)
// =================================================================================================================================


    public class SMSInboxBLL
    {

        ///// <summary>
        ///// Getting 
        ///// </summary>
        ///// <returns></returns>
        //public List<SMSTemplateModel> GetSMSInbox()
        //{
        //    //try
        //    //{
        //    //    return BindData(LazySingletonBLL<SMSTemplateDAL>.Instance.GetAllSMSTemplates());
        //    //}

        //    //catch (Exception ex)
        //    //{
        //    //    throw ex;
        //    //}
        //}

        /// <summary>
        /// Disable SMS Template
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(SMSTemplateModel model)
        {
            try
            {
                return LazySingletonBLL<SMSTemplateDAL>.Instance.Delete(new SMSTemplateModel(model.ID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        // <summary>
        ///  Get SMS Responses Infromation from Database
        /// </summary>
        /// <param name="model"> SMS Responses Model</param>
        /// <param name="search">Search Model</param>
        /// <returns>SMS Responses View Model</returns>
        /// 
        #region "old function"
        /*
        public SMSResponseViewModel GetSMSResponses(SMSResponseViewModel model, SearchModel search)
        {
            List<SMSResponseModel> smsResponse = new List<SMSResponseModel>();

            List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(model.User.UserID.Value);
            if (organizations != null && organizations.Count > 0)
                model.Organizations = organizations;


            if (model.User.OrganizationID > 0 && model.User.DepartmentID > 0)
            {
                // when single org and dept assign
                search.OrganizaitonID = model.User.OrganizationID;
                search.UserID = model.User.UserID;
                search.DepartmentID = model.User.DepartmentID;

                model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, search.UserID.Value);
                model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(search.OrganizaitonID.Value, model.User.DepartmentID, null);
                smsResponse = BindData(LazySingletonBLL<SMSInboxDAL>.Instance.GetSMSResponses(search));
            }
            else if (model.User.OrganizationID > 0 && model.User.DepartmentID == 0)
            {
                search.OrganizaitonID = model.User.OrganizationID;
                search.UserID = model.User.UserID;

                model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, search.UserID.Value);
                model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(search.OrganizaitonID.Value, search.DepartmentID.Value, null);
                smsResponse = BindData(LazySingletonBLL<SMSInboxDAL>.Instance.GetSMSResponses(search));
            }
            else
            {
                search.UserID = model.User.UserID;

                model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, model.User.UserID.Value);
                model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(search.OrganizaitonID.Value, search.DepartmentID.Value, null);
                smsResponse = BindData(LazySingletonBLL<SMSInboxDAL>.Instance.GetSMSResponses(search));
            }
            if (smsResponse != null && smsResponse.Count > 0)
            {
                model.SMSResponse = smsResponse;
                model.TotalCount = smsResponse[0].RESULT_COUNT.Value;
            }


            return model;

        }
         */
        #endregion
        public SMSResponseViewModel GetSMSResponses(SMSResponseViewModel model, SearchModel search, bool isLoad)
        {
            try
            {
                List<SMSResponseModel> smsResponse = new List<SMSResponseModel>();

                List<OrganizationModel> organizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(model.User.UserID.Value);
                if (organizations != null && organizations.Count > 0)
                    model.Organizations = organizations;

                List<DepartmentsModel> departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(model.User.OrganizationID.Value, model.User.UserID.Value);
                if (departments != null && departments.Count > 0)
                    model.Departments = departments;

                if (model.User.OrganizationID > 0 && model.User.DepartmentID > 0)
                {
                    search.OrganizaitonID = model.User.OrganizationID;
                    search.UserID = model.User.UserID;
                    search.DepartmentID = model.User.DepartmentID;

                    model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, search.UserID.Value);
                    model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(search.OrganizaitonID.Value, model.User.DepartmentID, null);
                    smsResponse = BindData(LazySingletonBLL<SMSInboxDAL>.Instance.GetSMSResponses(search));
                }
                else if (model.User.OrganizationID > 0 && model.User.DepartmentID == 0 && isLoad == true)
                {
                    search.OrganizaitonID = model.User.OrganizationID;
                    search.UserID = model.User.UserID;

                    model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, search.UserID.Value);
                    model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(search.OrganizaitonID.Value, search.DepartmentID.Value, null);
                    smsResponse = BindData(LazySingletonBLL<SMSInboxDAL>.Instance.GetSMSResponses(search));
                }
                else if (model.User.OrganizationID == 0 && model.User.DepartmentID == 0 && isLoad == true)
                {
                    model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, model.User.UserID.Value);
                    model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(search.OrganizaitonID.Value, search.DepartmentID.Value, null);
                    smsResponse = BindData(LazySingletonBLL<SMSInboxDAL>.Instance.GetSMSResponses(search));
                }
                else
                {
                    search.UserID = model.User.UserID;
                 
                    //model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, model.User.UserID.Value);
                    model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(search.OrganizaitonID.Value, search.DepartmentID.Value, null);
                }
                if (smsResponse != null && smsResponse.Count > 0)
                {
                    model.SMSResponse = smsResponse;
                    model.TotalCount = smsResponse[0].RESULT_COUNT.Value;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }

            return model;

        }

        /// <summary>
        /// // 001
        /// This Method is use to get the Transaction Response Message 
        /// </summary>
        /// <param name="responseID">Selected Response ID</param>
        /// <returns>Transaction SMS Response Message</returns>
        public string GetSMSResponseMessage(int responseID, int recordID)
        {
            try
            {
                return LazySingletonBLL<SMSInboxDAL>.Instance.GetSMSResponseMessage(responseID, recordID);
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }


        /// <summary>
        /// For Getting SMS Response Report Data
        /// </summary>
        /// <param name="responseID"></param>
        /// <returns></returns> 
        public DataSet GetSMSResponseData(int organizationID, int departmentID, int campaignID, string datefrom, string dateTo, int Status, string PhoneNo)
        {
            try
            {
                DataSet ds = LazySingletonBLL<SMSInboxDAL>.Instance.GetSMSResponseData(organizationID, departmentID, campaignID, datefrom, dateTo, Status, PhoneNo);
                return ds;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Bind the Model with Datatable
        /// </summary>
        /// <param name="dt">Data Table</param>
        /// <returns>Response List  of SMS Response Model</returns>
        private List<SMSResponseModel> BindData(DataTable dt)
        {
            List<SMSResponseModel> lists = new List<SMSResponseModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSResponseModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSResponseModel());

            return lists;
        }
    }
}
