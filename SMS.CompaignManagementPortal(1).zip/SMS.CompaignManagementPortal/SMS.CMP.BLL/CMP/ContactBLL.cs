﻿

using BE.CustomEnums;
using BLL.Common;
using BLL.CustomExceptions;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace SMS.CMP.BLL.CMP
{
    public class ContactBLL
    {
        /// <summary>
        /// Saving Model Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(ContactModel model)
        {
            Hashtable htbWhere = new Hashtable();
            htbWhere.Add(ColumnName.OrganizationID.ToString(), model.OrganizationID.ToString());
            htbWhere.Add(ColumnName.DepartmentID.ToString(), model.DepartmentID.ToString());


            int result = 0;
            try
            {
                CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;

                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblContacts, ColumnName.Phone, model.Phone, commonBLL.GetClause(htbWhere, ColumnName.ContactID, model.ID.Value)))
                    {
                        throw new BusinessException(CustomMsg.DuplicateNumber);
                    }

                    model.OrganizationTitle = null;
                    result = LazySingletonBLL<ContactDAL>.Instance.Edit(model);
                }

                else if (commonBLL.IsExist(TableName.tblContacts, ColumnName.Phone, model.Phone, commonBLL.GetClause(htbWhere, null, null)))
                {
                    throw new BusinessException(CustomMsg.DuplicateNumber);
                }
                else
                {
                    //   model.CreatedBy = 1;

                    result = LazySingletonBLL<ContactDAL>.Instance.Add(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
       

        /// <summary>
        /// Get All Contacts Information
        /// </summary>
        /// <returns></returns>
        public List<ContactModel> GetAllContacts(int? userId)
        {
            try
            {
                return BindData(LazySingletonBLL<ContactDAL>.Instance.GetAllContacts(userId));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        

        /// <summary>
        /// Get All Contact With Paging
        /// </summary>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public List<ContactModel> GetAllContactsWithPaging(int pageNo, int pageSize, int? userId, int? departmentID, int? organizationID)
        {
            try
            {
                return BindData(LazySingletonBLL<ContactDAL>.Instance.GetAllContactWithPaging(pageNo, pageSize, userId, departmentID, organizationID));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

       


        /// <summary>
        /// Get All Contacts with Paging with Search Text
        /// </summary>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="userId"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<ContactModel> GetAllContactsWithPaging(int pageNo, int pageSize, int? userId, string searchText, int? departmentID, int? organizationID)
        {
            try
            {
                return BindData(LazySingletonBLL<ContactDAL>.Instance.GetAllContactWithPaging(pageNo, pageSize, userId, searchText, departmentID, organizationID));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        //Not Used  in Application
        /// <summary>
        /// Get All Active Contacts
        /// </summary>
        /// <returns></returns>
        //public List<ContactModel> GetAllActiveContacts()
        //{
        //    try
        //    {
        //        return BindData(LazySingletonBLL<ContactDAL>.Instance.GetAllActiveContacts());
        //    }

        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        /// <summary>
        /// Get All Active Contacts
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public List<ContactModel> GetAllActiveContacts(int organizationID, int departmentID, int pageNo, int pageSize,int? campaignID)
        {
            try
            {
                return BindData(LazySingletonBLL<ContactDAL>.Instance.GetAllContacts(organizationID, departmentID, pageNo, pageSize, campaignID));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }



        public List<ContactModel> SearchContacts(int organizationID, int departmentID, int pageNo, int pageSize, string searchText,int? campaignID)
        {
            try
            {
                return BindData(LazySingletonBLL<ContactDAL>.Instance.SearchContacts(organizationID, departmentID, pageNo, pageSize, searchText, campaignID));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        ///  Get All Active Contacts
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="addressBookID"></param>
        /// <returns></returns>
        public List<ContactModel> GetAllActiveContacts(int organizationID, int? departmenID, int addressBookID, bool isViewOnly)
        {
            try
            {
                if (isViewOnly)

                    return BuildModel(new ContactDAL().GetAllActiveContacts(organizationID, departmenID, addressBookID)).Where(p => p.Assigned == true).ToList();

                else

                    return BuildModel(new ContactDAL().GetAllActiveContacts(organizationID, departmenID, addressBookID));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /* Not Useed in Application
        /// <summary>
        ///  Get All Active Contacts with Paging
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="departmenID"></param>
        /// <param name="addressBookID"></param>
        /// <param name="isViewOnly"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public List<ContactModel> GetAllActiveContacts(int organizationID, int? departmenID, int addressBookID, bool isViewOnly, int pageNo, int pageSize)
        {
            try
            {
                if (isViewOnly)

                    return BuildModel(new ContactDAL().GetAllActiveContactsForViewOnly(organizationID, addressBookID, pageNo, pageSize)).ToList();

                else

                    return BuildModel(new ContactDAL().GetAllActiveContacts(organizationID, departmenID, addressBookID, pageNo, pageSize));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        */
        public List<ContactModel> GetAddressBookContacts(int organizationID, int? departmenID, int addressBookID, bool? isViewOnly, int pageNo, int pageSize)
        {
            try
            {
                DataTable dt = LazySingletonDAL<ContactDAL>.Instance.GetAddressBookContacts(organizationID, departmenID, addressBookID, pageNo, pageSize, isViewOnly);
                return BuildModel(dt);
               
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        
        /* Not use in applicatoin
        /// <summary>
        ///  Get All Active Contacts with Paging with search
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="departmenID"></param>
        /// <param name="addressBookID"></param>
        /// <param name="isViewOnly"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns> </returns>
        public List<ContactModel> GetAllActiveContacts(int organizationID, int? departmenID, int addressBookID, bool isViewOnly, int pageNo, int pageSize, string searchText)
        {
            try
            {

                if (isViewOnly)

                    //return BuildModel(new ContactDAL().GetAllActiveContacts(organizationID, departmenID, addressBookID, pageNo, pageSize,false) ).Where(p => p.Assigned == true).ToList();
                    return BuildModel(new ContactDAL().GetAllActiveContacts(organizationID, departmenID, addressBookID, pageNo, pageSize, isViewOnly, searchText)).ToList();

                else

                    return BuildModel(new ContactDAL().GetAllActiveContacts(organizationID, departmenID, addressBookID, pageNo, pageSize, isViewOnly, searchText));


            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
         */
        public List<ContactModel> GetAddressBookContactSearch(int organizationID, int? departmenID, int addressBookID, bool isViewOnly, int pageNo, int pageSize, string searchText)
        {
            try
            {

                return BuildModel(new ContactDAL().GetAddressBookContactSearch(organizationID, departmenID, addressBookID, pageNo, pageSize, isViewOnly, searchText));


            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        

        /// <summary>
        /// Co
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="addressBookID"></param>
        /// <param name="isViewOnly"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public List<ContactModel> GetAllActiveContacts(int organizationID, int addressBookID, bool isViewOnly, int pageNo, int pageSize)
        {
            try
            {
                if (isViewOnly)

                    return BuildModel(new ContactDAL().GetAllActiveContacts(organizationID, addressBookID, pageNo, pageSize)).Where(p => p.Assigned == true).ToList();

                else

                    return BuildModel(new ContactDAL().GetAllActiveContacts(organizationID, addressBookID, pageNo, pageSize));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Campaingn Contacts
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <param name="versionNo"></param>
        /// <param name="IsBuffered"></param>
        /// <returns></returns>
        public List<ContactModel> GetCampaignContacts(int? organizationID, int? campaignID, int? versionNo,bool IsBuffered )
        {
            try
            {
                DataTable dt = LazySingletonDAL<ContactDAL>.Instance.GetCampaignContacts(organizationID, campaignID, versionNo, IsBuffered);
                return BuildModel(dt);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }


        public bool IsExistCampaignContact(int? organizationID, int? campaignID, int? versoinNo)
        {
            try
            {
                return LazySingletonDAL<ContactDAL>.Instance.IsExistCampaignContact(organizationID, campaignID, versoinNo);

            }

            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// disable existing entry 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(ContactModel model)
        {
            try
            {
                return LazySingletonBLL<ContactDAL>.Instance.Delete(new ContactModel(model.ID.Value));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Get IDs from 
        /// </summary>
        /// <param name="models"></param>
        /// <returns></returns>
        public string GetIDs(List<ContactModel> models)
        {
            List<string> items = new List<string>();

            if (models.Count > 0)
            {
                foreach (ContactModel model in models)
                {
                    if (model.ID > 0)
                        items.Add(Convert.ToString(model.ID));
                }

                return string.Join(",", items.ToArray());
            }

            return null;
        }

        #region "private Methods"

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private List<ContactModel> BindData(DataTable dt)
        {
            List<ContactModel> lists = new List<ContactModel>();
            if (dt.Rows.Count > 0)
                lists = (List<ContactModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new ContactModel());

            return lists;
        }
       

        /// <summary>
        /// here is model building
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<ContactModel> BuildModel(DataTable dt)
        {
            List<ContactModel> lists = new List<ContactModel>();
            if (dt!=null && dt.Rows.Count > 0)
                lists = LazySingletonBLL<CommonBuildModel>.Instance.BuildModel<ContactModel>(dt, new ContactModel()).ToList();
            /*
            List<ContactModel> ContactsList = new List<ContactModel>();

            if (dt != null && dt.Rows.Count > 0)
            {
                ContactModel model = null;

                foreach (DataRow dr in dt.Rows)
                {
                    model = new ContactModel();

                    if (dt.Columns.Contains("ContactID") && !Convert.IsDBNull(dr["ContactID"]))
                        model.ID = Convert.ToInt32(dr["ContactID"]);
                    if (dt.Columns.Contains("FirstName") && !Convert.IsDBNull(dr["FirstName"]))
                        model.FirstName = Convert.ToString(dr["FirstName"]);
                    if (dt.Columns.Contains("LastName") && !Convert.IsDBNull(dr["LastName"]))
                        model.LastName = Convert.ToString(dr["LastName"]);
                    if (dt.Columns.Contains("Email") && !Convert.IsDBNull(dr["Email"]))
                        model.Email = Convert.ToString(dr["Email"]);
                    if (dt.Columns.Contains("Phone") && !Convert.IsDBNull(dr["Phone"]))
                        model.Phone = Convert.ToString(dr["Phone"]);
                    if (dt.Columns.Contains("FirstName") && !Convert.IsDBNull(dr["FirstName"]))
                        model.FirstName = Convert.ToString(dr["FirstName"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        model.Status = Convert.ToBoolean(Convert.ToString(dr["IsActive"]));

                    if (dt.Columns.Contains("Assigned") && !Convert.IsDBNull(dr["Assigned"]))
                        model.Assigned = Convert.ToBoolean(Convert.ToString(dr["Assigned"]) == "1" ? true : false);
                    if (dt.Columns.Contains("OrganizationID") && !Convert.IsDBNull(dr["OrganizationID"]))
                        model.OrganizationID = Convert.ToInt32(dr["OrganizationID"]);
                    if (dt.Columns.Contains("CreatedBy") && !Convert.IsDBNull(dr["CreatedBy"]))
                        model.CreatedBy = Convert.ToInt32(dr["CreatedBy"]);

                    if (dt.Columns.Contains("RESULT_COUNT") && !Convert.IsDBNull(dr["RESULT_COUNT"]))
                        model.RESULT_COUNT = Convert.ToInt32(dr["RESULT_COUNT"]);


                    //if (dt.Columns.Contains("ModifiedBy") && !Convert.IsDBNull(dr["ModifiedBy"]))
                    //    model.ModifiedBy = Convert.ToInt32(dr["ModifiedBy"]);



                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                        model.DepartmentID = Convert.ToInt32(dr["DepartmentID"]);

                    ContactsList.Add(model);
              
                }
            }
            return ContactsList;
             */
            return lists;
        }
        #endregion

    }
}
