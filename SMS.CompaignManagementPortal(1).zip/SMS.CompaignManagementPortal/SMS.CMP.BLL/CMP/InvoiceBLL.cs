﻿using BLL.Common;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{
    public class InvoiceBLL
    {
        /// <summary>
        ///  Save and Update Invoice Model info in DB
        /// </summary>
        /// <param name="model">Invoice Model</param>
        /// <returns></returns>
        public int Save(InvoiceModel model)
        {

            int Result = 0;
            CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;
            if (model.PaymentInvoiceID > 0)
            {
                Result = LazySingletonBLL<InvoiceDAL>.Instance.Edit(model);
            }
            else
            {
                Result = LazySingletonBLL<InvoiceDAL>.Instance.Add(model);
            }

            return Result;
        }

        /// <summary>
        /// Getting All Invoice Info
        /// </summary>
        /// <returns></returns>
        public List<InvoiceModel> GetAllInvoiceInfo(int? organizationID, int? departmentID, int? campaignID, int? PageNo, int? PageSize, string searchText)
        {
            return BindData(LazySingletonBLL<InvoiceDAL>.Instance.GetAllInvoiceInfo(organizationID, departmentID, campaignID, PageNo, PageSize, searchText));
        }


        public InvoiceModel GetPayableAmount(int departmentID, int organizationID, int campaignID, string dateOfInvoice)
        {
            // DataTable dt = new DataTable();

            List<InvoiceModel> lists = new List<InvoiceModel>();
            InvoiceModel invoice = new InvoiceModel();

            lists = BindData(LazySingletonBLL<InvoiceDAL>.Instance.GetPayableAmount(departmentID, organizationID, campaignID, dateOfInvoice));
            if (lists.Count > 0)
                return lists[0];
            else
                return invoice;
        }

        /// <summary>
        ///  Get Payment Invoice Detail 
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <param name="dtFrom"></param>
        /// <param name="dtTo"></param>
        /// <returns></returns>
        public List<InvoiceModel> GetPaymentInvoice(int organizationID, int paymentMode, int finalPaymentInvoiceID)
        {
            try
            {
                return BindData(LazySingletonBLL<InvoiceDAL>.Instance.GetPaymentInvoice(organizationID, paymentMode, finalPaymentInvoiceID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns>Mask Model</returns>
        /// 
        private List<InvoiceModel> BindData(DataTable dt)
        {
            List<InvoiceModel> lists = new List<InvoiceModel>();
            if (dt.Rows.Count > 0)
                lists = (List<InvoiceModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new InvoiceModel());

            return lists;
        }

        /// <summary>
        /// Build Model for FInal Payment Invoice Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns> List<FinalPaymentInvoiceModel> </returns>
        /// 
        private List<FinalPaymentInvoiceModel> BindDataFinalPaymentInvoice(DataTable dt)
        {
            List<FinalPaymentInvoiceModel> lists = new List<FinalPaymentInvoiceModel>();
            if (dt.Rows.Count > 0)
                lists = (List<FinalPaymentInvoiceModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new FinalPaymentInvoiceModel());

            return lists;
        }

        /// <summary>
        /// Getting All Invoice Info
        /// </summary>
        /// <returns></returns>
        public List<FinalPaymentInvoiceModel> GetFinalPaymentInvoice()
        {
            return BindDataFinalPaymentInvoice(LazySingletonBLL<InvoiceDAL>.Instance.GetFinalPaymentInvoice());
        }

        /// <summary>
        /// Getting All Campaign Payment Invoice Info
        /// </summary>
        /// <returns></returns>
        public List<InvoiceModel> GetAllCampaignPaymentInvoice(int? organizationID, int? departmentID, DateTime dateOfInvoice)
        {
            return BindData(LazySingletonBLL<InvoiceDAL>.Instance.GetAllCampaignPaymentInvoice(organizationID, departmentID, dateOfInvoice));
        }

        /// <summary>
        ///  Get Campaign Payement Invoice Data by Final Invoice ID
        /// </summary>
        /// <returns></returns>
        public List<InvoiceModel> GetCampaignPaymentInvoiceInfo(string FinalInvoiceNo)
        {
            return BindData(LazySingletonBLL<InvoiceDAL>.Instance.GetCampaignPaymentInvoiceInfo(FinalInvoiceNo));
        }

        /// <summary>
        /// saving invoices against final invoice
        /// </summary>
        /// <returns></returns>
        public int SaveFinalInvoice(List<InvoiceListModel> model, int CreatedBy)
        {
            int result = 0;
            DataTable dtInvoiceIDs = null;
            dtInvoiceIDs = (DataTable)LazySingletonBLL<CommonBuildModel>.Instance.PaymentInvoiceInfoTable(model);
            result = LazySingletonBLL<InvoiceDAL>.Instance.SaveFinalInvoice(dtInvoiceIDs, CreatedBy);
            return result;

        }
    }
}
