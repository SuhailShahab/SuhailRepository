﻿using BE.CustomEnums;
using BLL.Common;
using BLL.CustomExceptions;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;

namespace SMS.CMP.BLL.CMP
{
    public class SMSTemplateBLL
    {
        /// <summary>
        /// Save Method
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(SMSTemplateModel model)
        {
            int result = 0;
            try
            {
                CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblSMSTemplates, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.TempalteID, model.ID.Value)))
                    {
                        throw new BusinessException(CustomMsg.DuplicateTitle);
                    }
                    return LazySingletonBLL<SMSTemplateDAL>.Instance.Edit(model);
                }
                else if (commonBLL.IsExist(TableName.tblSMSTemplates, ColumnName.Title, model.Title, null))
                {
                    throw new BusinessException(CustomMsg.DuplicateTitle);
                }
                else
                {
                    
                    return LazySingletonBLL<SMSTemplateDAL>.Instance.Add(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// Getting 
        /// </summary>
        /// <returns></returns>
        public List<SMSTemplateModel> GetAllSMSTemplates(int? orgID, int? deptID,int? userID)
        {
            try
            {
                return BindData(LazySingletonBLL<SMSTemplateDAL>.Instance.GetAllSMSTemplates(orgID, deptID, userID));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        /// <summary>
        /// Get All sms templates with paging
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="deptID"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public List<SMSTemplateModel> GetAllSMSTemplates(int? orgID, int? deptID,int? userID,int pageNo, int pageSize)
        {
            try
            {
                return BindData(LazySingletonBLL<SMSTemplateDAL>.Instance.GetAllSMSTemplates(orgID, deptID, userID, pageNo, pageSize));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="deptID"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<SMSTemplateModel> GetAllSMSTemplates(int? orgID, int? deptID, int? userID, int pageNo, int pageSize, string searchText)
        {
            try
            {
                return BindData(LazySingletonBLL<SMSTemplateDAL>.Instance.GetAllSMSTemplates(orgID, deptID, userID, pageNo, pageSize, searchText));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        

        /// <summary>
        ///  Get Active SMS Templates
        /// </summary>
        /// <param name="orgID">Selected Organization ID</param>
        /// <param name="deptID">Selected Department ID</param>
        /// <returns>SMS TemplateList</returns>
        public List<SMSTemplateModel> GetAllActiveSMSTemplates(int? orgID, int? deptID)
        {
            try
            {
                return BindData(LazySingletonBLL<SMSTemplateDAL>.Instance.GetAllActiveSMSTemplates(orgID, deptID));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Disable SMS Template
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(SMSTemplateModel model)
        {
            try
            {
             return LazySingletonBLL<SMSTemplateDAL>.Instance.Delete(new SMSTemplateModel (model.ID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Bind SMS Template Model
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private List<SMSTemplateModel> BindData(DataTable dt)
        {
            List<SMSTemplateModel> lists = new List<SMSTemplateModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSTemplateModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSTemplateModel());

            return lists;
        }
    }
}
