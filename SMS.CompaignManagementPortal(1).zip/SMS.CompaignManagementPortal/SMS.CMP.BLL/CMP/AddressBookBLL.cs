﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{
    public class AddressBookBLL
    {
        /// <summary>
        ///  Save and Update Address Book Model info in DB
        /// </summary>
        /// <param name="model">Address Book Model</param>
        /// <returns></returns>
        public int Save(AddressBooksModel model)
        {
            CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;
            Hashtable htbWhere = new Hashtable();

            htbWhere.Add(ColumnName.OrganizationID.ToString(), model.OrganizationID);
           // CommonBLL.GetClause(htbWhere, ColumnName.OrganizationID.ToString(), model.OrganizationID);
            if (model.AddressBookID > 0)
            {
               
                if (commonBLL.IsExist(TableName.tblAddressBooks, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.AddressBookID, model.AddressBookID.Value)))
                {
                    throw new BusinessException(CustomMsg.DuplicateTitle);
                }

                return LazySingletonBLL<AddressBookDAL>.Instance.Edit(model);
               
            }
            else if (commonBLL.IsExist(TableName.tblAddressBooks, ColumnName.Title, model.Title, commonBLL.GetClause(htbWhere, null, null)))
            {
                throw new BusinessException(CustomMsg.DuplicateTitle);
            }

            else
                return LazySingletonBLL<AddressBookDAL>.Instance.Add(model);
        }

        /// <summary>
        /// Assign Contacts
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="addressBookID"></param>
        /// <param name="listContact"></param>
        /// <returns></returns>
        public int DeleteAddressBookContact(List<ContactModel> listContacts, int? organizationID, int? addressBookID, int? departmentID, bool? isDeletedAll=false)
        {
            int result = 0;
            DataTable dtContacts = null;
            CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;

            try
            {
                if (listContacts != null && listContacts.Count>0)
                {
                    listContacts = listContacts.Where(l => l.Assigned == true).ToList();//CR:
                    dtContacts = GetContactsTable(listContacts);
                }
                
                

                if ((dtContacts != null && dtContacts.Rows.Count > 0) || (isDeletedAll.Value && isDeletedAll.Value))
                {
                    result = new AddressBookDAL().DeleteAddressBookContact(dtContacts, organizationID, addressBookID, departmentID, isDeletedAll);                   
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        public int AssignContacts(List<ContactModel> listContacts, int? organizationID, int? addressBookID, int? departmentID, bool? isIncludeExistingAddresBook)
        {
            int result = 0;
            DataTable dtContacts = null;

            CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;

            try
            {
                if (listContacts != null && listContacts.Count > 0)
                {
                    listContacts = listContacts.Where(l => l.Assigned == true).ToList();//CR:
                     dtContacts = GetContactsTable(listContacts);
                }



                if (dtContacts!=null && dtContacts.Rows.Count > 0)
                {
                    result = new AddressBookDAL().UpdateAddressBookContact(dtContacts, organizationID, addressBookID, departmentID, isIncludeExistingAddresBook);
                    //result = LazySingletonBLL<AddressBookDAL>.Instance.UpdateAddressBookContact(dtContacts, organizationID, addressBookID);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        /// <summary>
        /// Getting All Address Book Record  
        /// </summary>
        /// <returns></returns>
        public List<AddressBooksModel> GetAllAddressBooks()
        {
            return BindData(LazySingletonBLL<AddressBookDAL>.Instance.GetAllAddressBooks());
        }

        /// <summary>
        /// Get All Address Book Without Paging
        /// </summary>
        /// <param name="ogrID"></param>
        /// <param name="deptID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public List<AddressBooksModel> GetAllAddressBooksByIDs(int? ogrID, int? deptID, int? userID)
        {
            return BindData(LazySingletonBLL<AddressBookDAL>.Instance.GetAllAddressBooksByIDs(ogrID, deptID,userID));
        }

        /// <summary>
        /// Get Address Book With Paging 
        /// </summary>
        /// <param name="ogrID"></param>
        /// <param name="deptID"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public List<AddressBooksModel> GetAllAddressBooksByIDs(int? ogrID, int? deptID, int? userID,int pageNo, int pageSize)
        {
            return BindData(LazySingletonBLL<AddressBookDAL>.Instance.GetAllAddressBooksByIDs(ogrID, deptID, userID, pageNo, pageSize));
        }
        
        /// <summary>
        /// Get Address Book With Paging along search Text
        /// </summary>
        /// <param name="ogrID"></param>
        /// <param name="deptID"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<AddressBooksModel> GetAllAddressBooksByIDs(int? ogrID, int? deptID, int? userID, int pageNo, int pageSize, string searchText)
        {
            return BindData(LazySingletonBLL<AddressBookDAL>.Instance.GetAllAddressBooksByIDs(ogrID, deptID, userID, pageNo, pageSize, searchText));
        }

        /// <summary>
        /// Getting All Active Address Book Record  
        /// </summary>
        /// <returns></returns>
        public List<AddressBooksModel> GetAllActiveAddressBooks()
        {

            return BindData(LazySingletonBLL<AddressBookDAL>.Instance.GetAllActiveAddressBooks());

        }

        /// <summary>
        /// Delete Address Book info
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(AddressBooksModel model)
        {
            return LazySingletonBLL<AddressBookDAL>.Instance.Delete(RemoveDeleteFields(model));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="contacts"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        
        public DataTable SaveImportContacts(DataTable dtContacts, int organizationID, int departmentID, int addressBookID, int? createdBy)
        {
            DataTable dt = null;
            try
            {
                dt=  new AddressBookDAL().SaveImportContacts(dtContacts, organizationID,departmentID, addressBookID, createdBy);
            }
            catch ( Exception ex)
            {
                throw ex;
            }

            return dt;
        }


        //public int SaveImportContacts(DataTable dtContacts, int organizationID, int departmentID, int addressBookID, int? createdBy)
        //{
        //    int success = 0;

        //    try
        //    {

        //        success = new AddressBookDAL().SaveImportContacts(dtContacts, organizationID, departmentID, addressBookID, createdBy);
        //        //success = LazySingletonBLL<AddressBookDAL>.Instance.SaveImportContacts(dtContacts, organizationID, addressBookID, createdBy);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return success;
        //}

        /// <summary>
        /// Saving
        /// </summary>
        /// <param name="dtContacts"></param>
        /// <param name="organizationID"></param>
        /// <param name="createdBy"></param>
        /// <returns></returns>
        public DataTable SaveImportContacts(DataTable dtContacts, int organizationID, int departmentID,  int? createdBy)
        {
            DataTable dt = null;

            try
            {
               // dt = new AddressBookDAL().SaveImportContacts(dtContacts, organizationID, departmentID, createdBy);
                dt = LazySingletonDAL<AddressBookDAL>.Instance.SaveImportContacts(dtContacts, organizationID, departmentID, createdBy);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveImportContacts", 0, PageNames.Contact, createdBy));
                throw ex;
            }

            return dt;
        }

        /// <summary>
        /// Getting All Address Book Record  
        /// </summary>
        /// <returns></returns>
        public List<AddressBooksModel> GetAddressBooksWithContactsByOrgID(int orgID, int deptID, int? campaignID)
        {
            return BindData(LazySingletonBLL<AddressBookDAL>.Instance.GetAddressBooksWithContactsByOrgID(orgID, deptID, campaignID));
        }


        #region "Private Methods"

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns>Address Book Model</returns>
        /// 
        private List<AddressBooksModel> BindData(DataTable dt)
        {
            List<AddressBooksModel> lists = new List<AddressBooksModel>();
            if (dt.Rows.Count > 0)

                lists =LazySingletonBLL<CommonBuildModel>.Instance.BuildModel<AddressBooksModel>(dt, new AddressBooksModel()).ToList();

            return lists;
        }


        /// <summary>
        /// Get address ids from address Book model
        /// </summary>
        /// <param name="address">Address book Model</param>
        /// <returns></returns>
        public string GetAddressIDs(List<AddressBooksModel> address)
        {
            List<string> items = new List<string>();

            if (address.Count > 0)
            {
                foreach (AddressBooksModel addres in address)
                {
                    if (addres.AddressBookID > 0)
                        items.Add(Convert.ToString(addres.AddressBookID));
                }

                return string.Join(",", items.ToArray());
            }

            return null;
        }
        #endregion
        #region "Private Methods"

        internal DataTable GetContactsTable(List<ContactModel> contacts)
        {
            DataTable dt = new DataTable();

            DataColumn dc = new DataColumn("ID", typeof(int));
            dt.Columns.Add(dc);

            dc = new DataColumn("Assigned", typeof(bool));
            dt.Columns.Add(dc);

            DataRow dr = null;

            if (contacts.Count > 0)
            {
                foreach (ContactModel contact in contacts)
                {
                    dr = dt.NewRow();

                    dr["ID"] = contact.ID;
                    dr["Assigned"] = contact.Assigned;

                    dt.Rows.Add(dr);
                }

               
            }

            return dt;
        }


        public AddressBooksModel RemoveDeleteFields(AddressBooksModel model)
        {

            model.DepartmentID = null;
            model.OrganizationID = null;
            model.Title = null;
            model.IsActive = null;

            return model;
        }
        #endregion
    }
}
