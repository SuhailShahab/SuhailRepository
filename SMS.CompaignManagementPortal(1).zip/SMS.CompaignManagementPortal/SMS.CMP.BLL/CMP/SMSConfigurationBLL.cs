﻿using BLL.Common;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{
    public class SMSConfigurationBLL
    {
        /// <summary>
        /// Save the SMSConfigurationModel Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(SMSConfigurationModel model)
        {
            CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;
            if (model.ConfigurationID > 0)
            {
                return LazySingletonBLL<SMSConfigurationDAL>.Instance.Edit(model);
            }
            else
            {
                return LazySingletonBLL<SMSConfigurationDAL>.Instance.Add(model);
            }

        }


        /// <summary>
        /// For Getting all the SMSConfigurationModel Information
        /// </summary>
        /// <returns></returns>
        public List<SMSConfigurationModel> GetAllConfiguration()
        {
            return BindData(LazySingletonBLL<SMSConfigurationDAL>.Instance.GetAll());
        }



        /// <summary>
        /// For Getting all the SMSConfigurationModel Information
        /// </summary>
        /// <returns></returns>
        public List<SMSConfigurationModel> GetConfiguration()
        {
            return BindData(LazySingletonBLL<SMSConfigurationDAL>.Instance.GetConfiguration()); 
        }

        public List<SMSConfigurationModel> GetActiveTelcos()
        {
            try
            {
                DataTable dt = LazySingletonDAL<SMSConfigurationDAL>.Instance.GetActiveTelcos();
                List<SMSConfigurationModel> configurations = BindData(dt);
                if (configurations != null && configurations.Count > 0)
                {
                    return configurations;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public SMSConfigurationModel GetNetworkProvider(string networktypeCode)
        {
            try
            {
                DataTable dt = LazySingletonDAL<SMSConfigurationDAL>.Instance.GetNetworkProvider(networktypeCode);
                List<SMSConfigurationModel> configurations = BindData(dt);
                if (configurations != null && configurations.Count > 0)
                {
                    return configurations[0];
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
       
        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns>SMSConfigurationModel Model</returns>
        /// 
        private List<SMSConfigurationModel> BindData(DataTable dt)
        {
            List<SMSConfigurationModel> lists = new List<SMSConfigurationModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSConfigurationModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSConfigurationModel());

            return lists;
        }
    }
}
