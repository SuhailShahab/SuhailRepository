﻿using BE.CustomEnums;
using BLL.Common;
using BLL.CustomExceptions;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date:  <09-11-2015 05:54 PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
    public class TelcoBLL
    {


        #region "Public Methods"

        public List<TelcoModel> GetTelcoPayments(int? telcoId)
        {
            List<TelcoModel> result = new List<TelcoModel>();
            try
            {
                return BindData(LazySingletonBLL<TelcoDAL>.Instance.GetTelcoPayments(telcoId));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<TelcoModel> GetActiveTelcoPayments(int? telcoId)
        {
            List<TelcoModel> result = new List<TelcoModel>();
            try
            {
                return BindData(LazySingletonBLL<TelcoDAL>.Instance.GetActiveTelcoPayments(telcoId));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<TelcoModel> GetTelcoByPaymentID(int paymentID, bool isOnNet)
        {
            //List<TelcoModel> result = new List<TelcoModel>();
            //return BindData(LazySingletonBLL<TelcoDAL>.Instance.SelectTelcoByPaymentID(paymentID, isOnNet));
            try
            {
                return BindData(LazySingletonBLL<TelcoDAL>.Instance.SelectTelcoByPaymentID(paymentID, isOnNet));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Save Method
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int? Save(TelcoModel model)
        {
            int result = 0;
            try
            {
                CommonBLL commonBLL = LazySingletonDAL<CommonBLL>.Instance;
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblTelcoPaymentInformations, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.TelcoPaymentID, model.ID.Value)))
                        throw new BusinessException(CustomMsg.DuplicateTitle);

                    model.TelcoName = null;
                    return LazySingletonBLL<TelcoDAL>.Instance.Edit(model);
                }
                else if (commonBLL.IsExist(TableName.tblTelcoPaymentInformations, ColumnName.Title, model.Title, null))
                    throw new BusinessException(CustomMsg.DuplicateTitle);
                else
                    return LazySingletonBLL<TelcoDAL>.Instance.Add(model);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }


        /// <summary>
        /// Get All Telco Payment Informations
        /// </summary>
        /// <returns></returns>
        public List<TelcoModel> GetAllTelcoPayments()
        {
            List<TelcoModel> result = new List<TelcoModel>();
            try
            {
                return BindData(LazySingletonBLL<TelcoDAL>.Instance.GetAllTelcoPayments());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get All Telco Payment Informations with demand based Paging
        /// </summary>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public List<TelcoModel> GetAllTelcoPayments(int pageNo, int pageSize)
        {
            List<TelcoModel> result = new List<TelcoModel>();
            try
            {
                return BindData(LazySingletonBLL<TelcoDAL>.Instance.GetAllTelcoPayments(pageNo, pageSize));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get All Telco Payment Informations with demand based Paging along search text
        /// </summary>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<TelcoModel> GetAllTelcoPayments(int pageNo, int pageSize, string searchText)
        {
            List<TelcoModel> result = new List<TelcoModel>();
            try
            {
                return BindData(LazySingletonBLL<TelcoDAL>.Instance.GetAllTelcoPayments(pageNo, pageSize, searchText));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get All Telco Comapnies
        /// </summary>
        /// <returns></returns>
        public List<TelcoModel> GetctiveTelcoCompanies()
        {
            List<TelcoModel> result = new List<TelcoModel>();
            try
            {
                return BindData(LazySingletonBLL<TelcoDAL>.Instance.GetctiveTelcoCompanies());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Delete Telco Payment Information
        /// </summary>
        /// <param name="model">telco model</param>
        /// <returns></returns>
        public int Delete(TelcoModel model)
        {
            try
            {
                return LazySingletonBLL<TelcoDAL>.Instance.Delete(new TelcoModel(model.ID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion

        #region "Private Methods"
        private List<TelcoModel> BindData(DataTable dt)
        {
            List<TelcoModel> lists = new List<TelcoModel>();
            if (dt.Rows.Count > 0)
                lists = (List<TelcoModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new TelcoModel());

            return lists;
        }
        #endregion
    }
}
