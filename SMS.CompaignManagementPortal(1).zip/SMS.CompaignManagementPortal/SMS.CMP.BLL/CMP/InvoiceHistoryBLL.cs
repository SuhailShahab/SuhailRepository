﻿using BLL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{
    public class InvoiceHistoryBLL
    {
        /// <summary>
        /// Get Payment Invoice Ledger
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <param name="dtFrom"></param>
        /// <param name="dtTo"></param>
        /// <returns></returns>
        public List<InvoiceHistoryModel> GetPaymentInvoiceLedger(int organizationID, int? campaignID, DateTime dtFrom, DateTime dtTo)
        {
            //return BindData(LazySingletonBLL<InvoiceHistoryDAL>.Instance.GetPaymentInvoiceLedger(organizationID, campaignID, dtFrom, dtTo));
            try
            {
                return BindData(LazySingletonBLL<InvoiceHistoryDAL>.Instance.GetPaymentInvoiceLedger(organizationID, campaignID, dtFrom, dtTo));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #region "Private Methods"
        private List<InvoiceHistoryModel> BindData(DataTable dt)
        {
            List<InvoiceHistoryModel> lists = new List<InvoiceHistoryModel>();
            if (dt.Rows.Count > 0)
                lists = (List<InvoiceHistoryModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new InvoiceHistoryModel());

            return lists;
        }
        #endregion "Private Methods"
    }
}
