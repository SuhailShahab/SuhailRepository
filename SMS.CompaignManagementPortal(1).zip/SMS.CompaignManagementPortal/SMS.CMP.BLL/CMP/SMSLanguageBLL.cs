﻿using BLL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{
    public class SMSLanguageBLL
    {
        public List<SMSLanguageModel> GetAllSMSLanguages()
        {
            try
            {
                return BindData(LazySingletonBLL<SMSLanguageDAL>.Instance.GetAll());
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        #region "private Methods"
        private List<SMSLanguageModel> BindData(DataTable dt)
        {
            List<SMSLanguageModel> lists = new List<SMSLanguageModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSLanguageModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSLanguageModel());

            return lists;
        }
        #endregion
    }
}
