﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.Common;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
namespace SMS.CMP.BLL.CMP
{
    public class PaymentBLL : RepositoryBLL<PaymentModel>
    {
       

       /// <summary>
        /// Get All Purchased Bucket History Records
       /// </summary>
       /// <param name="orgID">Selected Organizaiton ID</param>
       /// <param name="deptID">Selected Department ID</param>
       /// <param name="userID">Selected User ID</param>
       /// <returns>Payment List</returns>
        public List<PaymentModel> GetPurchasedBucketsHistoryByOrgID(int? orgID, int? deptID, int? userID)
        {
            List<PaymentModel> result = new List<PaymentModel>();
            try
            {
                return BindData(LazySingletonBLL<PaymentDAL>.Instance.GetPurchasedBucketsHistoryByOrgID(orgID, deptID, userID));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetPurchasedBucketsHistoryByOrgID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        /// <summary>
        /// Get Payments
        /// </summary>
        /// <param name="LoginID"></param>
        /// <param name="OrganizationID"></param>
        /// <returns></returns>
        public List<PaymentModel> GetPayment(int? LoginID, int? OrganizationID)
        {
            List<PaymentModel> result = new List<PaymentModel>();
            try
            {
                return BindData(LazySingletonBLL<PaymentDAL>.Instance.GetPayment(LoginID, OrganizationID));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetPayment" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="LoginID"></param>
        /// <param name="OrganizationID"></param>
        /// <param name="campaignID"></param>
        /// <returns></returns>
        public List<PaymentModel> GetPaymentByCampaignID(int? LoginID, int? OrganizationID, int campaignID, DateTime fromDate, DateTime toDate, int departmentID)
        {
            List<PaymentModel> result = new List<PaymentModel>();
            try
            {
                return BindData(LazySingletonBLL<PaymentDAL>.Instance.GetPayment(LoginID, OrganizationID, campaignID, fromDate, toDate, departmentID));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetPaymentByCampaignID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

       
      

        #region Private Method

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt"></param>
        /// <returns>List<PaymentModel></returns>
        private List<PaymentModel> BindData(DataTable dt)
        {
            List<PaymentModel> lists = new List<PaymentModel>();
            if (dt.Rows.Count > 0)
                lists = (List<PaymentModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new PaymentModel());

            return lists;
        }

        #endregion

    }
}
