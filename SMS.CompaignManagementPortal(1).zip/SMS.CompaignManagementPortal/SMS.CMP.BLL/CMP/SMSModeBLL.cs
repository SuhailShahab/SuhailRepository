﻿using BLL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{
    public class SMSModeBLL
    {
        public List<SMSModeModel> GetAllActiveContacts()
        {
            try
            {
                return BindData(LazySingletonBLL<SMSModeDAL>.Instance.GetAllSMSModes());
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region "private Methods"
        private List<SMSModeModel> BindData(DataTable dt)
        {
            List<SMSModeModel> lists = new List<SMSModeModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSModeModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSModeModel());

            return lists;
        }
        #endregion
    }
}
