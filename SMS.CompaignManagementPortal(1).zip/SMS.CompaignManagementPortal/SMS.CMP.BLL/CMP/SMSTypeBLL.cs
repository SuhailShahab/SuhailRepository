﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using SMS.CMP.BE.CMP;
using SMS.CMP.DAL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.CMP
{
    //////////////////////////////////////////////////////////////
    //
    //  Class: SMSTypeBLL
    //  ------------------
    //  Namespace : SMS.CMP.BLL.CMP
    //  Author: Sohail Kamran
    //  Dated:  19 - 11 - 2015 
    //  Description:  SMS Type BLL
    //
    //////////////////////////////////////////////////////////////
    
    public class SMSTypeBLL
    {

        /// <summary>
        /// Saving SMS Type information
        /// </summary>
        /// <param name="smsTypeModel"></param>
        /// <returns></returns>
        public int Save(SMSTypesModel smsTypeModel)
        {
            int Result = 0;
            try
            {
                SMSTypeDAL objSMSTypeDAL = new SMSTypeDAL();

                if (!string.IsNullOrEmpty(smsTypeModel.Title))
                {
                    if (smsTypeModel.SMSTypeID > 0)
                    {
                        if (LazySingletonBLL<CommonBLL>.Instance.IsExist(TableName.tblSMSTypes, ColumnName.Title, smsTypeModel.Title, LazySingletonBLL<CommonBLL>.Instance.GetClause(ColumnName.SMSTypeID, smsTypeModel.SMSTypeID.Value)))
                        {
                            throw new BusinessException(CustomMsg.DuplicateTitle);
                        }
                        Result = objSMSTypeDAL.Edit(smsTypeModel);
                    }
                    else if (LazySingletonBLL<CommonBLL>.Instance.IsExist(TableName.tblSMSTypes, ColumnName.Title, smsTypeModel.Title, null))
                    {
                        throw new BusinessException(CustomMsg.DuplicateTitle);
                    }
                    else
                        Result = objSMSTypeDAL.Add(smsTypeModel);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Result;
        }

        /// <summary>
        /// Get All SMS Types 
        /// </summary>
        /// <returns></returns>
        public List<SMSTypesModel> GetSMSTypes()
        {
            DataTable dt = null;
            dt = new SMSTypeDAL().GetAll();
            return BuildModel(dt);
        }

        /// <summary>
        /// disable SMS Type
        /// </summary>
        /// <param name="SMSTypeID"></param>
        /// <returns></returns>
        public int Delete(int SMSTypeID)
        {
            int Result = new SMSTypeDAL().Delete(SMSTypeID);
            return Result;
        }


        #region "Private & Internal Methods"

        internal List<SMSTypesModel> BuildModel(DataTable dt)
        {
            List<SMSTypesModel> SMSTypes = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                SMSTypes = new List<SMSTypesModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    SMSTypesModel SMSTypesModel = new SMSTypesModel();
                    if (dt.Columns.Contains("SMSTypeID") && !Convert.IsDBNull(dr["SMSTypeID"]))
                        SMSTypesModel.SMSTypeID = Convert.ToInt32(dr["SMSTypeID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        SMSTypesModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        SMSTypesModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        SMSTypesModel.IsActive = Convert.ToBoolean(dr["IsActive"]);

                    SMSTypes.Add(SMSTypesModel);
                }

                SMSTypes.TrimExcess();
            }
            return SMSTypes;
        }
        #endregion
    }
}
