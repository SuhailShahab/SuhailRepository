﻿using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using SMS.CMP.DAL.CMPsmsCampaign;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE.CustomEnums;
using SMS.CMP.BLL.Common;
using SMS.CMP.DAL.SMSQueue;

namespace SMS.CMP.BLL.CMP
{

    // =================================================================================================================================
    // Create by:	<Atif Farroq>
    // Create date: <19-10-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // CR:001       Syed Zeeshan Aqil           19-Nov- 2015 12:30 PM       Add Method  GetSMSSendMessage to get Message
    // CR:002       Syed Zeeshan Aqil           04-Dec- 2015 05:21 PM       Add Method  GetAllCampaignesSchedule to get the Campaign Schedule list
    // CR:003       Sajjad Aslam                20-Mar- 2017 12:37 PM       Code optimization and add try catch block and logs
    // =================================================================================================================================
    public class SMSCampaignBLL : RepositoryBLL<SMSCampaignModel>
    {

        #region "Public  Methods"

        /// <summary>
        /// Add edit Campaign info
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(SMSCampaignModel model)
        {
            DataTable dtUploadContacts = null;
            try
            {
                if (model.Contacts != null && model.Contacts.Count > 0)
                {
                    dtUploadContacts = (DataTable)LazySingletonBLL<CommonBuildModel>.Instance.ToDataTable(
                        (from contact in model.Contacts
                         select new { contact.ID }).ToList());
                }
                else
                {
                    dtUploadContacts = (DataTable)LazySingletonBLL<CommonBuildModel>.Instance.ContactTableID();
                }

                if (model.AddressBooks != null && model.AddressBooks.Count > 0)
                {
                    model.AddressIDs = string.Join(",", model.AddressBooks.Select(ab => ab.AddressBookID).ToArray());
                }


                if (model.CampaignID > 0)
                {
                    return LazySingletonBLL<SMSCampaignDAL>.Instance.Edit(RemoveEditFields(model), dtUploadContacts);
                }
                else
                {
                    return LazySingletonBLL<SMSCampaignDAL>.Instance.Add(model, dtUploadContacts);
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Save" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }
        /*
        public int Save(SMSCampaignModel model)
        {
            DataTable dtUploadContacts = null;
            
            if (model.Contacts!= null && model.Contacts.Count>0 )
            {
                model.ContactsInfo = string.Join(",", model.Contacts.Select(c => c.ID).ToArray());
            }

            if (model.AddressBooks != null && model.AddressBooks.Count > 0)
            {
                model.AddressIDs = string.Join(",", model.AddressBooks.Select(ab => ab.AddressBookID).ToArray());
            }
                
              
            if (model.CampaignID > 0)
            {
                //model.ContactsInfo = (String)LazySingletonBLL<ContactBLL>.Instance.GetIDs(model.Contacts);
                //model.AddressIDs = (String)LazySingletonBLL<AddressBookBLL>.Instance.GetAddressIDs(model.AddressBooks);

                if (model.UploadContacts != null)
                    dtUploadContacts = (DataTable)LazySingletonBLL<CommonBuildModel>.Instance.ToDataTable(model.UploadContacts);
                else
                    dtUploadContacts = (DataTable)LazySingletonBLL<CommonBuildModel>.Instance.ContactTable();

                //model = RemoveFields(model);
                return LazySingletonBLL<SMSCampaignDAL>.Instance.Edit(RemoveEditFields(model), dtUploadContacts);

            }
            else
            {
                //model.ContactsInfo = (String)LazySingletonBLL<ContactBLL>.Instance.GetIDs(model.Contacts);
                //model.AddressIDs = (String)LazySingletonBLL<AddressBookBLL>.Instance.GetAddressIDs(model.AddressBooks);

                if (model.UploadContacts != null)
                    dtUploadContacts = (DataTable)LazySingletonBLL<CommonBuildModel>.Instance.ToDataTable(model.UploadContacts);
                else
                    dtUploadContacts = (DataTable)LazySingletonBLL<CommonBuildModel>.Instance.ContactTable();

                return LazySingletonBLL<SMSCampaignDAL>.Instance.Add(model, dtUploadContacts);
            }

        }
         */

        public int? UpdateCampaignStatus(string csvOfCampaigns)
        {
            int? result = null;
            try
            {
                result = LazySingletonDAL<SMSCampaignDAL>.Instance.UpdateCampaignStatus(csvOfCampaigns);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "UpdateCampaignStatus" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }

            return result;
        }

        public int? SetCampaignStatus(int? campaignID)
        {
            int? result = null;
            try
            {
                result = LazySingletonDAL<SMSCampaignDAL>.Instance.SetCampaignStatus(campaignID);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SetCampaignStatus" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// Delete Campaign info
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(SMSCampaignModel model)
        {
            try
            {
                return LazySingletonBLL<SMSCampaignDAL>.Instance.Delete(model);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Delete" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        /// <summary>
        /// Get All Api Log information By Campain ID
        /// </summary>
        /// <param name="campaignedID"></param>
        /// <returns></returns>
        public SMSCampaignLogViewModel GetAllCampaingsByID(int campaignID, int pageNo, int pageSize, SMSCampaignLogViewModel model, int showStatus, string fromDate, string toDate)
        {
            List<SMSTransactionModel> transections = null;
            try
            {
                DataSet ds = LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllCampaingsByID(campaignID, pageNo, pageSize, showStatus, fromDate, toDate);

                transections = BindTransactionData(ds.Tables[0]);

                if (transections != null && transections.Count > 0)
                {
                    model.Transactions = transections;
                    model.TTotalCount = transections[0].RESULT_COUNT.Value;
                }
                else
                    model.TTotalCount = 0;

                List<CampaignStatus> statuslists = new List<CampaignStatus>();

                if (ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                {
                    statuslists = (List<CampaignStatus>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[1], new CampaignStatus());
                    model.CampaignStatuses = statuslists;
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllCampaingsByID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
            return model;
        }



        /// <summary>
        /// Get All Api Log information By Campain ID  
        /// </summary>
        /// <param name="campaignedID"></param>
        /// <returns></returns>
        public SMSCampaignLogViewModel GetAllCampaingsByID(int campaignID, int pageNo, int pageSize, string searchText, SMSCampaignLogViewModel model, int showStatus, string fromDate, string toDate)
        {

            List<SMSTransactionModel> transections = null;
            try
            {
                DataSet ds = LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllCampaingsByID(campaignID, pageNo, pageSize, searchText, showStatus, fromDate, toDate);

                transections = BindTransactionData(ds.Tables[0]);

                if (transections != null && transections.Count > 0)
                {
                    model.Transactions = transections;
                    model.TTotalCount = transections[0].RESULT_COUNT.Value;
                }
                else
                    model.TTotalCount = 0;

                List<CampaignStatus> statuslists = new List<CampaignStatus>();

                if (ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                {
                    statuslists = (List<CampaignStatus>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[1], new CampaignStatus());
                    model.CampaignStatuses = statuslists;
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllCampaingsByID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
            return model;
        }

        /// <summary>
        /// Get All Api Log information By Campain ID with paging
        /// </summary>
        /// <param name="campaignedID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public SMSCampaignLogViewModel GetAllApiLogByID(int campaignID, int pageNo, int pageSize, SMSCampaignLogViewModel model, int showStatus, string fromDate, string toDate)
        {

            List<SMSTransactionModel> transections = null;
            try
            {
                DataSet ds = LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllApiLogByID(campaignID, pageNo, pageSize, showStatus, fromDate, toDate);
                transections = BindTransactionData(ds.Tables[0]);
                if (transections != null && transections.Count > 0)
                {
                    model.Transactions = transections;
                    model.TTotalCount = transections[0].RESULT_COUNT.Value;
                }
                else
                    model.TTotalCount = 0;

                List<CampaignStatus> statuslists = new List<CampaignStatus>();

                if (ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                {
                    statuslists = (List<CampaignStatus>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[1], new CampaignStatus());
                    model.CampaignStatuses = statuslists;
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllCampaingsByID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
            return model;
            //return BindTransactionData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllApiLogByID(campaignID, pageNo, pageSize));
        }

        /// <summary>
        /// Get All Api Log information By Campain ID with paging & search
        /// </summary>
        /// <param name="campaignedID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public SMSCampaignLogViewModel GetAllApiLogByID(int campaignID, int pageNo, int pageSize, string searchText, SMSCampaignLogViewModel model, int showStatus, string fromDate, string toDate)
        {

            List<SMSTransactionModel> transections = null;
            try
            {
                DataSet ds = LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllApiLogByID(campaignID, pageNo, pageSize, searchText, showStatus, fromDate, toDate);

                transections = BindTransactionData(ds.Tables[0]);

                if (transections != null && transections.Count > 0)
                {
                    model.Transactions = transections;
                    model.TTotalCount = transections[0].RESULT_COUNT.Value;
                }
                else
                    model.TTotalCount = 0;

                List<CampaignStatus> statuslists = new List<CampaignStatus>();

                if (ds.Tables.Count > 1 && ds.Tables[1].Rows.Count > 0)
                {
                    statuslists = (List<CampaignStatus>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[1], new CampaignStatus());
                    model.CampaignStatuses = statuslists;
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllApiLogByID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
            return model;
            //return BindTransactionData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllApiLogByID(campaignedID, pageNo, pageSize, searchText));
        }






        public List<SMSTransactionModel> GetAllApiLogByID(int campaignedID)
        {
            try
            {
                return BindTransactionData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllApiLogByID(campaignedID));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllApiLogByID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }



        /// <summary>
        ///  Get All AllCampaings info
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public List<SMSCampaignLog> GetAllCampaign(SMSCampaignLog model)
        {
            try
            {
                return BindCampaignData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllCampaings(model));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindCampaignData" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        /// <summary>
        /// Get All AllCampaings with demand based paging 
        /// </summary>
        /// <param name="model"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public List<SMSCampaignLog> GetAllCampaign(SMSCampaignLog model, int pageNo, int pageSize)
        {
            try
            {
                return BindCampaignData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllCampaings(model, pageNo, pageSize));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindCampaignData" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        /// <summary>
        /// Get All AllCampaings with demand based paging along search
        /// </summary>
        /// <param name="model"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<SMSCampaignLog> GetAllCampaign(SMSCampaignLog model, int pageNo, int pageSize, string searchText)
        {
            try
            {
                return BindCampaignData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllCampaings(model, pageNo, pageSize, searchText));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindCampaignData" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        public List<StartingCampaign> GetAllStartedCampaingsInfo()
        {
            try
            {
                DataTable dt = LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllStartedCampaingsInfo();

                return (List<StartingCampaign>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new StartingCampaign());

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllStartedCampaingsInfo" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        /// <summary>
        /// Get Campaign by Organization ID and Campaign ID
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <returns></returns>
        public StartingCampaign GetCampaingsInfoByIDs(int? organizationID, int? campaignID)
        {
            try
            {
                DataTable dt = LazySingletonBLL<SMSCampaignDAL>.Instance.SelectCampaingsInfoByIDs(organizationID, campaignID);

                List<StartingCampaign> campaigns = (List<StartingCampaign>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new StartingCampaign());

                if (campaigns != null && campaigns.Count > 0)
                {
                    return campaigns[0];
                }
                return null;

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetCampaingsInfoByIDs" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }
        /// <summary>
        /// This method is call after validation of campaign. It is use in response campiaing
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <returns></returns>
        public StartingCampaign GetValidCampaingsInfoByIDs(int? organizationID, int? campaignID)
        {
            try
            {
                DataTable dt = LazySingletonBLL<SMSCampaignDAL>.Instance.SelectValidCampaingsInfoByIDs(organizationID, campaignID);

                List<StartingCampaign> campaigns = (List<StartingCampaign>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new StartingCampaign());

                if (campaigns != null && campaigns.Count > 0)
                {
                    return campaigns[0];
                }
                return null;

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetValidCampaingsInfoByIDs" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        /// <summary>
        /// Service Response Information
        /// </summary>
        /// <param name="campaignID"></param>
        /// <returns></returns>
        public SMSCampaignModel GetServiceResponseInfo(int campaignID)
        {
            try
            {
                DataTable dt = LazySingletonBLL<SMSCampaignDAL>.Instance.SelectServiceResponseInfo(campaignID);
                return ((List<SMSCampaignModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSCampaignModel())).FirstOrDefault();

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetServiceResponseInfo" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        public bool IsExistStartCampaignInfo()
        {
            bool result = false;
            try
            {
                result = LazySingletonBLL<SMSCampaignDAL>.Instance.IsExistStartCampaignInfo();
                return result;

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "IsExistStartCampaignInfo" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        /// <summary>
        /// Get Campaign Information
        /// </summary>
        /// <param name="organizationID">Selected Organization ID</param>
        /// <returns></returns>
        public List<SMSCampaignModel> GetAllCampaingsInfo(int? orgID, int? deptId, int? userID)
        {
            try
            {
                return BindData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllCampaingsInfo(orgID, deptId, userID));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllCampaingsInfo" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        public List<SMSCampaignModel> GetCampaignsByDeptID(int deptID)
        {
            List<SMSCampaignModel> campaigns = null;
            try
            {
                DataTable dt = LazySingletonBLL<SMSCampaignDAL>.Instance.GetCampaignsByDeptID(deptID);
                campaigns = this.BuildModellst(dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetCampaignsByDeptID" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
            return campaigns;
        }



        /// <summary>
        /// Get All Campaings with paging
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="deptId"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public List<SMSCampaignModel> GetAllCampaingsInfo(int? orgID, int? deptId, int? userID, int pageNo, int pageSize)
        {
            try
            {
                return BindDataExtended(LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllCampaingsInfo(orgID, deptId, userID, pageNo, pageSize));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllCampaingsInfo" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        /// <summary>
        /// Get All Campaings with paging along search
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="deptId"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<SMSCampaignModel> GetAllCampaingsInfo(int? orgID, int? deptId, int? userID, int pageNo, int pageSize, string searchText)
        {
            try
            {
                return BindData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllCampaingsInfo(orgID, deptId, userID, pageNo, pageSize, searchText));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllCampaingsInfo" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        /// <summary>
        /// Get Campaigns Information
        /// </summary>
        /// <param name="orgID">selected Organiaiton ID</param>
        /// <param name="deptId">Selected Department ID</param>
        /// <param name="userID">Current Login User ID</param>
        /// <returns>Campaign Model List</returns>
        public List<SMSCampaignModel> GetCampaings(int? orgID, int? deptId, int? userID)
        {
            //return BindData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetCampaings(orgID, deptId, userID));
            try
            {
                return BindData(LazySingletonBLL<SMSCampaignDAL>.Instance.GetCampaings(orgID, deptId, userID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetCampaingSendMessage(int CampaignID)
        {
            try
            {
                return LazySingletonBLL<SMSCampaignDAL>.Instance.GetCampaingSendMessage(CampaignID);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetCampaingSendMessage" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        /// <summary>
        /// Get all Campaign Edit Info
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public SMSCampaignModel GetSMSCampaignAddressContact(SMSCampaignModel model)
        {
            DataTable dtAddress = null;
            DataTable dtContact = null;
            DataTable dtDept = null;
            DataTable dtUser = null;
            DataTable dtShortCodes = null;
            DataTable dtTempalte = null;
            DataTable dtMask = null;
            DataTable dtMask2 = null;
            DataTable dtProcessStatus = null;
            DataTable dtMappedCampaignSchedules = null;

            try
            {
                DataSet ds = LazySingletonBLL<SMSCampaignDAL>.Instance.GetSMSCampaignAddressContact(model.CampaignID, model.OrganizationID, model.DepartmentID, model.ShortCodeID, model.IncomingShortCodeID);
                if (ds.Tables[0].Rows.Count > 0)
                    dtAddress = ds.Tables[0];

                if (ds.Tables[1].Rows.Count > 0)
                    dtContact = ds.Tables[1];

                if (ds.Tables[2].Rows.Count > 0)
                    dtDept = ds.Tables[2];

                if (ds.Tables[3].Rows.Count > 0)
                    dtUser = ds.Tables[3];

                if (ds.Tables[4].Rows.Count > 0)
                    dtShortCodes = ds.Tables[4];

                if (ds.Tables[5].Rows.Count > 0)
                    dtTempalte = ds.Tables[5];

                if (ds.Tables[6].Rows.Count > 0)
                    dtMask = ds.Tables[6];

                if (ds.Tables[7].Rows.Count > 0)
                    dtProcessStatus = ds.Tables[7];

                if (ds.Tables[8].Rows.Count > 0)
                    dtMappedCampaignSchedules = ds.Tables[8];


                if (model.IncomingShortCodeID.HasValue)
                {
                    if (ds.Tables[9].Rows.Count > 0)
                        dtMask2 = ds.Tables[9];

                    model.IncomingMasks = (List<MaskModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dtMask2, new MaskModel());
                }


                model.AddressBooks = (List<AddressBooksModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dtAddress, new AddressBooksModel());
                model.Contacts = (List<ContactModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dtContact, new ContactModel());
                model.Departments = new DepartmentsBLL().BuildDataModel(dtDept);
                model.Users = (List<UserModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dtUser, new UserModel());
                model.ShortCodes = (List<ShortCodeModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dtShortCodes, new ShortCodeModel());
                model.SMSTemplates = (List<SMSTemplateModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dtTempalte, new SMSTemplateModel());
                model.Masks = (List<MaskModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dtMask, new MaskModel());
                model.ProcessingStatuses = (List<ProcessingStatusModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dtProcessStatus, new ProcessingStatusModel());
                model.MappedCampaignSchedules = (List<ScheduleModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dtMappedCampaignSchedules, new ScheduleModel());
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetSMSCampaignAddressContact" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
            return model;
        }



        /// <summary>
        /// Get the Trasaction Message by Trasaction ID
        /// 001
        /// </summary>
        /// <param name="transactionID">Selected Transaction ID</param>
        /// <returns>Transaction SMS Sending Message</returns>
        public string GetSMSSendMessage(int transactionID)
        {
            try
            {
                return LazySingletonBLL<SMSCampaignDAL>.Instance.GetSMSSendMessage(transactionID);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetSMSSendMessage" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }


        public List<ProcessingStatusModel> GetProcessingStatuses()
        {
            try
            {
                DataTable dt = LazySingletonBLL<SMSCampaignDAL>.Instance.GetProcessingStatuses();
                List<ProcessingStatusModel> lists = new List<ProcessingStatusModel>();
                if (dt.Rows.Count > 0)
                    lists = (List<ProcessingStatusModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new ProcessingStatusModel());
                return lists;
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetProcessingStatuses" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }

        }


        /// <summary>
        /// CR:002 
        /// Get  Campaignes Schedule Time Slots
        /// </summary>
        /// <param name="fromDate">Selected Date </param>
        /// <returns>Selected Campaignes Time Slot in List</returns>
        public List<ScheduleModel> GetAllCampaignesSchedule(string fromDate)
        {
            try
            {
                DataTable dt = LazySingletonBLL<SMSCampaignDAL>.Instance.GetAllCampaignesSchedule(fromDate);
                List<ScheduleModel> lists = new List<ScheduleModel>();
                if (dt.Rows.Count > 0)
                    lists = (List<ScheduleModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new ScheduleModel());

                return lists;
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllCampaignesSchedule" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }





        #endregion

        #region "Private  Methods"

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns>SMSConfigurationModel Model</returns>
        /// 
        private List<SMSCampaignLog> BindCampaignData(DataTable dt)
        {
            List<SMSCampaignLog> lists = new List<SMSCampaignLog>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSCampaignLog>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSCampaignLog());

            return lists;
        }


        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns>SMSConfigurationModel Model</returns>
        /// 
        private List<SMSTransactionModel> BindTransactionData(DataTable dt)
        {
            List<SMSTransactionModel> lists = new List<SMSTransactionModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSTransactionModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSTransactionModel());

            return lists;
        }

        /// <summary>
        /// Remove Fields from Model
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private SMSCampaignModel RemoveEditFields(SMSCampaignModel model)
        {

            // model.PaymentID = null;
            model.SMSTypeID = null;
            //model.MaskID = null;
            model.Confirmation = null;
            //model.Repetition = null;
            model.PurchaseDate = null;
            model.ExpiryDate = null;
            //model.PerSMSRate = null;
            //model.TotalAllocatedSMS = null;
            //model.TotalAmount = null;
            //model.TotalRemainSMS = null;
            // model.HasRun = null;
            model.UserID = null;
            //model.DepartmentID = null;



            return model;
        }

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt">Database Table</param>
        /// <returns>SMSConfigurationModel Model</returns>
        /// 
        private List<SMSCampaignModel> BindData(DataTable dt)
        {
            List<SMSCampaignModel> lists = new List<SMSCampaignModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSCampaignModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSCampaignModel());

            return lists;
        }


        private List<SMSCampaignModel> BindDataExtended(DataTable dt)
        {
            List<SMSCampaignModel> lists = new List<SMSCampaignModel>();
            if (dt.Rows.Count > 0)
                lists = (List<SMSCampaignModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModelExtend(dt, new SMSCampaignModel());

            return lists;
        }

        private List<CampaignPriorityModel> BindDataPriority(DataTable dt)
        {
            List<CampaignPriorityModel> lists = new List<CampaignPriorityModel>();
            if (dt.Rows.Count > 0)
                lists = (List<CampaignPriorityModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModelExtend(dt, new CampaignPriorityModel());

            return lists;
        }
        #endregion

        public int ReinitiateCampaign(int? campaignID, int? organizationID, int? versionNo)
        {
            int? ret = null;
            try
            {
                ret = LazySingletonBLL<SMSCampaignDAL>.Instance.ReinitiateCampaign(campaignID, organizationID, versionNo);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "ReinitiateCampaign" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw;
            }
            return ret.Value;
        }

        public List<CampaignPriorityModel> GetCampaignsPriority(int? organizationID, int? departmentID, int? campaignID)
        {
            try
            {
                return BindDataPriority(LazySingletonBLL<SMSQueueDAL>.Instance.GetCampaignsPriority(organizationID, departmentID, campaignID));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllCampaingsInfo" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
        }

        public int? EditCampaignsPriority(int? campaignID, int? priorityID, int? newPriorityID)
        {
            int? result = null;
            try
            {
                if (campaignID != null && campaignID > 0)
                {
                    result = LazySingletonBLL<SMSQueueDAL>.Instance.EditCampaignsPriority(campaignID, priorityID, newPriorityID);
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Save" + ex.Message, 0, PageNames.SMS_PortalService, 0));
                throw ex;
            }
            return Convert.ToInt32(result);
        }
    }
}


