﻿using BLL.Common;
using SMS.CMP.DAL.Reports;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.Reports
{
    public class CommonReportsBLL
    {
        public DataTable GetSMSStatSummary(int? deliveryStatusID, int? telcoID, int? smsModeID, int? smsLangID, int? isOnNet, DateTime? dtFrom, DateTime? dtTo, bool isIncludeDate)
        {
            //return LazySingletonBLL<CommonReportsDAL>.Instance.GetSMSStatSummary(deliveryStatusID, telcoID, smsModeID, smsLangID, isOnNet, dtFrom, dtTo, isIncludeDate);
            try
            {
                return LazySingletonBLL<CommonReportsDAL>.Instance.GetSMSStatSummary(deliveryStatusID, telcoID, smsModeID, smsLangID, isOnNet, dtFrom, dtTo, isIncludeDate);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetCompaignWiseStat(int? organizationID, int? departmentID, int? smsLangID, int? smsMode, int? isOnNet, string filterdListCSVCompaign, string filterdListCSV, DateTime? fromDate, DateTime? toDate, double? SMSPerRate, int? TelcoID)
        {
            try
            {
                return LazySingletonBLL<CommonReportsDAL>.Instance.GetCompaignWiseStat(organizationID, departmentID, smsLangID, smsMode, isOnNet, filterdListCSVCompaign, filterdListCSV, fromDate, toDate, SMSPerRate, TelcoID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetDepartmentWiseStat(int? organizationID, int? departmentID, int? smsLangID, int? smsMode, int? isOnNet, string filterdListCSVCompaign, string filterdListCSV, DateTime? fromDate, DateTime? toDate, double? SMSPerRate, int? TelcoID)
        {
            try
            {
                return LazySingletonBLL<CommonReportsDAL>.Instance.GetCompaignWiseStat(organizationID, departmentID, smsLangID, smsMode, isOnNet, filterdListCSVCompaign, filterdListCSV, fromDate, toDate, SMSPerRate, TelcoID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// DepartmentWiseStat
        /// </summary>
        /// <param name="TelcoID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public DataTable GetDepartmentWiseStat(int? TelcoID, DateTime? fromDate, DateTime? toDate)
        {
            try
            {
                return LazySingletonBLL<CommonReportsDAL>.Instance.GetDepartmentWiseStat(TelcoID, fromDate, toDate);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// MonthWiseSMSStat
        /// </summary>
        /// <param name="TelcoID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public DataTable GetMonthWiseSMSStat(int? TelcoID, DateTime? fromDate, DateTime? toDate)
        {
            try
            {
                return LazySingletonBLL<CommonReportsDAL>.Instance.GetMonthWiseSMSStat(TelcoID, fromDate, toDate);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// DepartmentWiseMonthlySMSStat
        /// </summary>
        /// <param name="DepartmentID"></param>
        /// <param name="TelcoID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public DataTable GetDepartmentWiseMonthlySMSStat(int? DepartmentID, int? TelcoID, DateTime? fromDate, DateTime? toDate)
        {
            try
            {
                return LazySingletonBLL<CommonReportsDAL>.Instance.GetDepartmentWiseMonthlySMSStat(DepartmentID, TelcoID, fromDate, toDate);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// GetSMSStatDetail
        /// </summary>
        /// <param name="deliveryStatusID"></param>
        /// <param name="telcoID"></param>
        /// <param name="smsModeID"></param>
        /// <param name="smsLangID"></param>
        /// <param name="isOnNet"></param>
        /// <param name="dtFrom"></param>
        /// <param name="dtTo"></param>
        /// <param name="isIncludeDate"></param>
        /// <returns></returns>
        public DataTable GetSMSStatDetail(int? deliveryStatusID, int? telcoID, int? smsModeID, int? smsLangID, int? isOnNet, DateTime? dtFrom, DateTime? dtTo, bool isIncludeDate)
        {
            try
            {
                return LazySingletonBLL<CommonReportsDAL>.Instance.GetSMSStatDetail(deliveryStatusID, telcoID, smsModeID, smsLangID, isOnNet, dtFrom, dtTo, isIncludeDate);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
