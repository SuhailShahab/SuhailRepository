﻿using BLL.Common;
using DAL.Common;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.DAL.APIClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Create date: <05-11-2015 11:05AM>
// =================================================================================================================================
// SR#              Created By                 Modified Date/Time          Desription
// 000              Suhail Shahab                                          This class is using in Web API (Inter API). This class 
//                                                                         save the customer response form mobile
// ===================================================== Modification History ======================================================
// SR#              Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
namespace SMS.CMP.BLL.APIClasses
{
   public  class CustomerResponseBLL
    {
       public int? AddCustomerResponse(CustomerResponseModel model)
       {
           int? result;
           try
           {
              result = LazySingletonDAL<CustomerResponseDAL>.Instance.AddResponse(model);
           }
           catch(Exception ex)
           {
               throw ex;
           }
           return result;
       }

       public List<CustomerResponseModel> GetCustoermResponses(int? campaignID, string replyPhoneNO)
       {
           List<CustomerResponseModel> lists = null;
           try
           {

               DataTable dt = LazySingletonDAL<CustomerResponseDAL>.Instance.GetResponse(campaignID, replyPhoneNO);
               if (dt.Rows.Count > 0)
                   lists = (List<CustomerResponseModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new CustomerResponseModel());

           }
           catch (Exception ex)
           {
               throw ex;
           }

           return lists;
       }

       public int? UpdateSMSConfirmationInfo(CustomerResponseModel model)
       {
           int? result;
           try
           {
              result = LazySingletonDAL<CustomerResponseDAL>.Instance.UpdateSMSConfrimatonInfo(model);
           }
           catch (Exception ex)
           {
               throw ex;
           }
           return result;

       }

       public int? AddCustomerConfirmation(CustomerResponseModel model)
       {
           int? result;
           try
           {
               result = LazySingletonDAL<CustomerResponseDAL>.Instance.AddConfirmation(model);
           }
           catch (Exception ex)
           {
               throw ex;
           }
           return result;

       }
    }
}
