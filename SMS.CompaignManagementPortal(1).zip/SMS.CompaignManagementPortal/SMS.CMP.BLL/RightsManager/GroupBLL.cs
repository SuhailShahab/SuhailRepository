﻿using System;
using System.Data;
using System.Collections.Generic;
using BE.RightsManager;
using BLL.Common;
using BE.CustomEnums;
using DAL.RightsManager;
using BLL.CustomExceptions;


namespace BLL.RightsManager
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil >
    // Create date: <7/10/2014 2:07:32 AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // CR: 001  -   Muhammad Hammad Shahid      11-07-2014 12:32PM      Add GetGroups methods
    // =================================================================================================================================
    public class GroupBLL
    {
        /// <summary>
        /// Save the Group Info
        /// </summary>  
        /// <param name="groupModel"></param>
        /// <returns>Result of  add or Updated Status</returns>
        public int Save(GroupModel groupModel)
        {
            CommonBLL commonBLL = new CommonBLL();
            if (groupModel.ID > 0)
            {
                if (commonBLL.IsExist(TableName.tblGroups, ColumnName.Title, groupModel.Title, commonBLL.GetClause(ColumnName.GroupID, groupModel.ID)))
                {
                    throw new BusinessException(CustomMsg.DuplicateTitle);
                }
                return new GroupDAL().Edit(groupModel);
            }
            else if (commonBLL.IsExist(TableName.tblGroups, ColumnName.Title, groupModel.Title, null))
            {
                throw new BusinessException(CustomMsg.DuplicateTitle);
            }

            else
                return new GroupDAL().Add(groupModel);
        }

        /// <summary>
        /// Get all Group Info
        /// </summary>
        /// <returns>result of Group in GroupModel class</returns
        public List<GroupModel> GetGroup()
        {
            DataTable dt = null;
            //dt = new GroupDAL().SelectGroups();
            dt = new GroupDAL().SelectGroups();
            return BuildModel(dt);
        }

        /// <summary>
        /// Get Group Info for dropDown list
        /// </summary>
        /// <returns></returns>
        public DataTable GetGroups()
        {
            DataTable dt = null;
            dt = new GroupDAL().GetGroups();
            return dt;
        }
        /// <summary>
        /// Get Group Info for dropDown list
        /// </summary>
        /// <returns></returns>
        public  List<GroupModel> GetAppGroups()
        {
            DataTable dt = null;
            dt = new GroupDAL().GetGroups();
            return BuildModel(dt);
        }

        /// <summary>
        /// Delete the Group By ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>success or error Type on delete </returns>
        public int Delete(int id, int modifiedBy)
        {
            return new GroupDAL().Delete(id, modifiedBy);
        }

        //public int SaveGroupRights(int GroupID, DataTable Rights, DataTable csrRights)
        //{
        //    return new GroupDAL().AddGroupPermissions(GroupID,Rights, csrRights);
        //}
        public int SaveGroupRights(int groupID, UserGroupRights gourpRiths)
        {
            return new GroupDAL().AddGroupPermissions(groupID, gourpRiths);
        }
        
       

        public DataSet GetGroupRights(int GroupID)
        {
            return new GroupDAL().GetGroupPermissions(GroupID);
        }

        

        #region "Private Methods"

        /// <summary>
        /// Bind the Group Model with Data Table
        /// </summary>
        /// <param name="dt"></param>
        /// <returns>GroupModel class</returns>
        internal List<GroupModel> BuildModel(DataTable dt)
        {
            List<GroupModel> groups = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                groups = new List<GroupModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    GroupModel groupModel = new GroupModel();
                    if (dt.Columns.Contains("GroupID") && !Convert.IsDBNull(dr["GroupID"]))
                    groupModel.ID = Convert.ToInt32(dr["GroupID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                    groupModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                    groupModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    groupModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    groups.Add(groupModel);
                }

                groups.TrimExcess();
            }

            return groups;
        }

        #endregion
 
    }
}
