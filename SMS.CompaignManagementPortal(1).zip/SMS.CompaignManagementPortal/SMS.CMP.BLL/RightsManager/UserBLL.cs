﻿
using BE.CustomEnums;
using BE.RightsManager;
using BLL.Common;
using BLL.CustomExceptions;
using DAL.Common;
using DAL.RightsManagers;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <11-07-2014 12:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR: 001  -   Syed Zeeshan Aqil           10-12-2014 03:32PM          Add datatable property dtUserRights for save user rights table
// CR:002       Muhammad Hammad Shahid      30-12-2014 05:55:19PM       Add GetUsersByFCCenter() and BuildModel() methods
// CR: 003  -      Suhial Shahab          28-05-2015 03:32PM      Add  New Add Method  For Add User Right with new parameter FC District ID
// CR: 004  -      Suhial Shahab          28-05-2015 03:32PM      Add  New Edit Method For Add User Right with new parameter FC District ID
// CR: 005  -     Muhammad Usman          30-06-2015 03:32PM      Add  New Method for getting UserTypes
// CR: 006  -      Syed Zeeshan Aqil      30-10-2015 02:32 PM      Add  Method GetUsersByOrgIDBydeptID
// =================================================================================================================================
namespace BLL.RightsManager
{
    public class UserBLL
    {



        /// <summary>
        ///  CR: 003
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public int Save(UserRegistration user)
        {
            try
            {
                return LazySingletonDAL<UserDAL>.Instance.Add(user, user.CreatedBy);
                // return new UserDAL().Add(user, user.CreatedBy);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }



        public int Update(UserRegistration user)
        {
            return new UserDAL().Edit(user, user.CreatedBy);
        }


        
        public int Delete(int UserID)
        {
            return new UserDAL().Delete(UserID);
        }
        public DataSet GetUserByID(int UserID)
        {
            return new UserDAL().SelectUserByID(UserID);
        }
        public DataTable GetDistirctByUserID(int UserID)
        {
            return new UserDAL().SelectDistrictByUserID(UserID);
        }
        public DataSet GetUsers(int DistrictID, int TehsilID, int UnionCouncilID, Int32 PageNumber, Int32 PageSize, string SearchIn = "", string Keyword = "")
        {
            return new UserDAL().SelectUsers(DistrictID, PageNumber, PageSize, SearchIn, Keyword);
        }
        public DataSet GetUserByLogin(string UserName)
        {
            return new UserDAL().SelectUserByLogin(UserName);
        }


        /// <summary>
        ///  CR: 006
        /// Get user list on the bases of Organization and Department ID
        /// </summary>
        /// <param name="orgID">selected Organization Id</param>
        /// <param name="deptID">Selected Department ID</param>
        /// <returns>User List</returns>
        public List<UserModel> GetUsersByOrgIDByDeptID(int orgID, int deptID)
        {
            try
            {
                DataTable dt = new UserDAL().GetUsersByOrgIDByDeptID(orgID, deptID);

                List<UserModel> users = (List<UserModel>)LazySingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    return users;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        

        public UserModel GeLoginUserInfoByLogin(string UserName)
        {
            try
            {
                DataSet dsUserInfo = LazySingletonDAL<UserDAL>.Instance.SelectUserByLogin(UserName);
                DataTable dt = dsUserInfo.Tables[TableName.tblUsers.ToString()];
                List<UserModel> users = (List<UserModel>)LazySingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    return users[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }
        public UserModel GeLoginUserInfoByLogin(int loginID)
        {
            try
            {
                DataSet dsUserInfo = LazySingletonDAL<UserDAL>.Instance.SelectUserByID(loginID);
                DataTable dt = dsUserInfo.Tables[TableName.tblUsers.ToString()];
                List<UserModel> users = (List<UserModel>)LazySingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    return users[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        //public R GetUserInformationByLogin(string UserName)
        //{
        //    return new UserDAL().SelectUserByLogin(UserName);
        //}

        public DataSet GetUserRightInfoByID(int userID)
        {
            try
            {
                return new UserDAL().SelectUserRightInfoByID(userID);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public List<UserModelView> GetUsersByFCCenter(string FCCode, string Condition = "")
        {
            DataTable dt = null;
            dt = new UserDAL().SelectUsersByFCCenter(FCCode, Condition);
            return BuildModelCollection(dt);
        }

        public List<UserModelView> SelectUsersByFCCenterID(int locationID)
        {
            DataTable dt = null;
            dt = new UserDAL().SelectUsersByFCCenterID(locationID);
            return BuildModelCollection(dt);
        }
        // CR: 005
        public DataTable SelectUserByTypeID(int DistrictID, int UserTypeID)
        {
            DataTable dt = null;
            dt = new UserDAL().SelectUserByTypeID(DistrictID, UserTypeID);
            return dt;
        }

        public bool IsValidateUser(string loginName, string password)
        {
            try
            {
                return LazySingletonDAL<UserDAL>.Instance.IsValidateUser(loginName, password);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int ResetPassword(string loginName, string oldpassword, string newpassword, int? loginID, bool IsAdmin)
        {
            object result = 0;
            try
            {
                if (loginID.HasValue)
                {
                    result = new UserDAL().UpdatePassword(loginName, oldpassword, newpassword, loginID, IsAdmin);
                }
                else { 
                    throw new BusinessException(CutomMessage.InvalidUser);                    
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Convert.ToInt32(result);
        }

        #region "Method With Model Retrun"

        public List<UserModelView> GetUsers(int DistrictID, Int32 PageNumber, Int32 PageSize, out int TotalRecord, string SearchIn = "", string Keyword = "")
        {
            DataSet ds = new UserDAL().SelectUsers(DistrictID, PageNumber, PageSize, SearchIn, Keyword);
            TotalRecord = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
            return BuildModelCollection(ds.Tables[0]);
        }
        
        public List<UserModelView> GetUsersLoginNameInfo()
        {
            DataSet ds = new UserDAL().GetUsersLoginNameInfo();
            return BuildModelCollection(ds.Tables[0]);
        }

        public UserModel GetUserByID(int UserID, string v)
        {
            DataSet ds = null;
            ds = new UserDAL().SelectUserByID(UserID);
            return BuildModel(ds);
        }


        #endregion

        #region "Private Methods"

        internal List<UserModelView> BuildModelCollection(DataTable dt)
        {
            List<UserModelView> collection = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                collection = new List<UserModelView>();
                foreach (DataRow dr in dt.Rows)
                {
                    UserModelView model = new UserModelView();

                    if (dt.Columns.Contains("UserID") && !Convert.IsDBNull(dr["UserID"]))
                        model.UserID = Convert.ToInt32(dr["UserID"].ToString());
                    if (dt.Columns.Contains("UserTypeID") && !Convert.IsDBNull(dr["UserTypeID"]))
                        model.UserTypeID = Convert.ToInt32(dr["UserTypeID"].ToString());
                    if (dt.Columns.Contains("ID") && !Convert.IsDBNull(dr["ID"]))
                        model.UserID = Convert.ToInt32(dr["ID"].ToString());
                    if (dt.Columns.Contains("UserName") && !Convert.IsDBNull(dr["UserName"]))
                        model.UserName = dr["UserName"].ToString();
                    if (dt.Columns.Contains("EmployeeName") && !Convert.IsDBNull(dr["EmployeeName"]))
                        model.EmployeeName = Convert.ToString(dr["EmployeeName"]);
                    if (dt.Columns.Contains("CNIC") && !Convert.IsDBNull(dr["CNIC"]))
                        model.CNIC = Convert.ToString(dr["CNIC"]);
                    if (dt.Columns.Contains("District") && !Convert.IsDBNull(dr["District"]))
                        model.District = Convert.ToString(dr["District"]);
                    if (dt.Columns.Contains("CellNumber") && !Convert.IsDBNull(dr["CellNumber"]))
                        model.CellNumber = Convert.ToString(dr["CellNumber"]);
                    if (dt.Columns.Contains("EMail") && !Convert.IsDBNull(dr["EMail"]))
                        model.EMail = Convert.ToString(dr["EMail"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        model.IsActive = Convert.ToBoolean(dr["IsActive"].ToString());

                    collection.Add(model);
                }

                collection.TrimExcess();
            }

            return collection;
        }

        internal UserModel BuildModel(DataSet ds)
        {
            UserModel model = new UserModel();

            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];

                if (ds.Tables[0].Columns.Contains("UserID") && !Convert.IsDBNull(dr["UserID"]))
                    model.UserID = Convert.ToInt32(dr["UserID"].ToString());
                if (ds.Tables[0].Columns.Contains("OrganizationID") && !Convert.IsDBNull(dr["OrganizationID"]))
                    model.OrganizationID = Convert.ToInt32(dr["OrganizationID"].ToString());

                if (ds.Tables[0].Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                    model.DistrictID = Convert.ToInt32(dr["DistrictID"].ToString());


                if (ds.Tables[0].Columns.Contains("UserName") && !Convert.IsDBNull(dr["UserName"]))
                    model.UserName = dr["UserName"].ToString();
                if (ds.Tables[0].Columns.Contains("EmployeeName") && !Convert.IsDBNull(dr["EmployeeName"]))
                    model.EmployeeName = Convert.ToString(dr["EmployeeName"]);
                if (ds.Tables[0].Columns.Contains("CNIC") && !Convert.IsDBNull(dr["CNIC"]))
                    model.CNIC = Convert.ToString(dr["CNIC"]);
                if (ds.Tables[0].Columns.Contains("EMail") && !Convert.IsDBNull(dr["EMail"]))
                    model.EMail = Convert.ToString(dr["EMail"]);
                if (ds.Tables[0].Columns.Contains("CellNumber") && !Convert.IsDBNull(dr["CellNumber"]))
                    model.CellNumber = Convert.ToString(dr["CellNumber"]);
                //if (ds.Tables[0].Columns.Contains("PermitGroupID") && !Convert.IsDBNull(dr["PermitGroupID"]))
                //    model.GroupID = Convert.ToInt32(dr["PermitGroupID"].ToString());
                //if (ds.Tables[0].Columns.Contains("UserType") && !Convert.IsDBNull(dr["UserType"]))
                //    model.UserType = Convert.ToString(dr["UserType"]);
                //if (ds.Tables[0].Columns.Contains("PermitGroupID") && !Convert.IsDBNull(dr["PermitGroupID"]))
                //    model.GroupID = Convert.ToInt32(dr["PermitGroupID"].ToString());
                //if (ds.Tables[0].Columns.Contains("UserTypeID") && !Convert.IsDBNull(dr["UserTypeID"]))
                //    model.UserTypeID = Convert.ToString(dr["UserType"]);

                if (ds.Tables[0].Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    model.IsActive = Convert.ToBoolean(dr["IsActive"].ToString());

                //if (ds.Tables[0].Columns.Contains("JoiningDate") && !Convert.IsDBNull(dr["JoiningDate"]))
                //    model.JoinDate = Convert.ToDateTime(dr["JoiningDate"].ToString());
                //if (ds.Tables[0].Columns.Contains("ResignedDate") && !Convert.IsDBNull(dr["ResignedDate"]))
                //    model.ResignedDate = Convert.ToDateTime(dr["ResignedDate"].ToString());
                //if (ds.Tables[0].Columns.Contains("InActiveReason") && !Convert.IsDBNull(dr["InActiveReason"]))
                //    model.BlockReason = Convert.ToString(dr["InActiveReason"]);

                if (ds.Tables[0].Columns.Contains("AllowFileRemove") && !Convert.IsDBNull(dr["AllowFileRemove"]))
                    model.AllowFileRemoved = Convert.ToBoolean(dr["AllowFileRemove"].ToString());


            }

            return model;
        }

        //internal List<ServiceModel> BuildServiceModel(DataTable dt)
        //{
        //    List<ServiceModel> collection = new List<ServiceModel>();

        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            ServiceModel model = new ServiceModel();

        //            if (dt.Columns.Contains("ServiceID") && !Convert.IsDBNull(dr["ServiceID"]))
        //                model.ID = Convert.ToInt32(dr["ServiceID"].ToString());

        //            collection.Add(model);
        //        }

        //        collection.TrimExcess();
        //    }

        //    return collection;
        //}

        //internal List<TaskStatusModel> BuildStatusModel(DataTable dt)
        //{
        //    List<TaskStatusModel> collection = new List<TaskStatusModel>();

        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            TaskStatusModel model = new TaskStatusModel();

        //            if (dt.Columns.Contains("StatusID") && !Convert.IsDBNull(dr["StatusID"]))
        //                model.ID = Convert.ToInt32(dr["StatusID"].ToString());

        //            collection.Add(model);
        //        }

        //        collection.TrimExcess();
        //    }

        //    return collection;
        //}

        internal List<CentrePermittedReportAndForms> BuildCenterModel(DataTable dt)
        {
            List<CentrePermittedReportAndForms> collection = new List<CentrePermittedReportAndForms>();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    CentrePermittedReportAndForms model = new CentrePermittedReportAndForms();

                    if (dt.Columns.Contains("AppFeatureID") && !Convert.IsDBNull(dr["AppFeatureID"]))
                        model.FeatureID = Convert.ToInt32(dr["AppFeatureID"].ToString());

                    collection.Add(model);
                }

                collection.TrimExcess();
            }

            return collection;
        }

        //internal List<ServiceUserRights> BuildServiceUserRightsModel(DataTable dt)
        //{
        //    List<ServiceUserRights> collection = new List<ServiceUserRights>();

        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        int Row = 1;
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            ServiceUserRights model = new ServiceUserRights();

        //            model.RowID = Row;
        //            if (dt.Columns.Contains("ServiceID") && !Convert.IsDBNull(dr["ServiceID"]))
        //                model.ServiceID = Convert.ToInt32(dr["ServiceID"].ToString());
        //            if (dt.Columns.Contains("IsEditDeliveryDate") && !Convert.IsDBNull(dr["IsEditDeliveryDate"]))
        //                model.EnableDeliveryDateEditing = Convert.ToBoolean(dr["IsEditDeliveryDate"].ToString());

        //            collection.Add(model);
        //            Row++;
        //        }

        //        collection.TrimExcess();
        //    }

        //    return collection;
        //}

        #endregion
    }
}
