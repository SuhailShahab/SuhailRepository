﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.Dashboard;
using SMS.CMP.BLL.Common;
using SMS.CMP.DAL.Dashboard;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.Dashboard
{
    public class DashboardBLL : RepositoryBLL<DashboardModel>
    {

        /// <summary>
        /// Get All Dashboard Records
        /// </summary>
        /// <returns></returns>
        public List<DashboardModel> GetAllDashboardRecords(DashboardModel model)
        {
            List<DashboardModel> dashboard = null;
            try
            {
                DataTable dt = LazySingletonBLL<DashboardDAL>.Instance.GetAllDashboardRecords(model);
                dashboard = this.BuildModellst(dt);
                //return BindData(LazySingletonBLL<DashboardDAL>.Instance.GetAllDashboardRecords(model));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllDashboardRecords" + ex.Message, 0, "DashboardBLL", 0));
                throw ex;
            }
            return dashboard;
        }

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private List<DashboardModel> BindData(DataTable dt)
        {
            List<DashboardModel> lists = new List<DashboardModel>();
            try
            {
                
                if (dt.Rows.Count > 0)
                    lists = (List<DashboardModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DashboardModel());
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindData" + ex.Message, 0, "DashboardBLL", 0));
                throw ex;
            }
            return lists;
        }

    }
}
