﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Common
{
    public abstract class LazySingletonBLL<T>
    where T : new()
    {
        private static readonly Lazy<T> lazy = new Lazy<T>(() => new T());

        public static T Instance
        {
            get
            {
                return lazy.Value;
            }
        }
    }

    //==============MultitonPattern=====================================
    public abstract class LazyMultiton<T>
        where T : new()
    {

        private static readonly Dictionary<int, T> serverPool =
       new Dictionary<int, T>
        {
            {1,new  T()},
            {2,new  T()},
            {3,new  T() }
        };
        private static readonly object _lock = new object();
        private static readonly Random random = new Random();
        private static readonly object randomLock = new object();
        public static T Instance()
        {
            lock (randomLock)
            {
                int key = random.Next(1, (serverPool.Count + 1));
                Console.WriteLine("Key=" + key.ToString());
                return serverPool[key];
            }

        }
    }


}
