﻿using BE.Common;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Common
{
   public  class CommonBuildModel
    {
       /// <summary>
       /// 
       /// </summary>
       /// <typeparam name="T"></typeparam>
       /// <param name="dt"></param>
       /// <param name="objectType"></param>
       /// <returns></returns>
       public  IList<T> BuildModel<T>(DataTable dt, T objectType)
       {
           Type handlerType = objectType.GetType();
           if (dt != null && dt.Rows.Count > 0)
           {
               IList<T> genList = new List<T>();
               foreach (DataRow dr in dt.Rows)
               {
                   T item = (T)Activator.CreateInstance(handlerType);
                   foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                   {
                       foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                       {
                           MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                           if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                           {
                               propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                               break;
                           }
                       }

                   }
                   genList.Add(item);
               }
               return genList;
           }

           return null;

       }
       

       public IList<T> BuildModelExtend<T>(DataTable dt, T objectType)
       {
           Type handlerType = objectType.GetType();
           if (dt != null && dt.Rows.Count > 0)
           {
               IList<T> genList = new List<T>();
               foreach (DataRow dr in dt.Rows)
               {
                   T item = (T)Activator.CreateInstance(handlerType);
                   foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                   {
                       foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                       {
                           MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                           if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                           {
                               if ( !string.IsNullOrEmpty(mappingInfoAttribute.DataType ) && mappingInfoAttribute.DataType.Equals("bool"))
                               {
                                   propertyInfo.SetValue(item,Convert.ToBoolean(dr[mappingInfoAttribute.ColumnName]));
                                   break;
                               }
                               else
                               {
                                   propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                                   break;
                               }
                               
                           }
                       }

                   }
                   genList.Add(item);
               }
               return genList;
           }

           return null;

       }

       public IList<T> BuildModel<T>(DataTable dt)
       {

           if (dt != null && dt.Rows.Count > 0)
           {
               IList<T> genList = new List<T>();
               foreach (DataRow dr in dt.Rows)
               {
                   T item = Activator.CreateInstance<T>();
                   foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                   {
                       foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                       {
                           MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                           if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                           {
                               propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                               break;
                           }
                       }

                   }
                   genList.Add(item);
               }
               return genList;
           }

           return null;

       }
       public List<T> BuildModellst<T>(DataTable dt)
       {

           if (dt != null && dt.Rows.Count > 0)
           {
               List<T> genList = new List<T>();
               foreach (DataRow dr in dt.Rows)
               {
                   T item = Activator.CreateInstance<T>();
                   foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                   {
                       foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                       {
                           MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                           if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                           {
                               propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                               break;
                           }
                       }

                   }
                   genList.Add(item);
               }
               return genList;
           }

           return null;

       }
       public DataTable ToDataTable<T>(IList<T> list)
       {
           PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(T));
           DataTable table = new DataTable();
           for (int i = 0; i < props.Count; i++)
           {
               PropertyDescriptor prop = props[i];
               table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
           }
           object[] values = new object[props.Count];
           foreach (T item in list)
           {
               for (int i = 0; i < values.Length; i++)
                   values[i] = props[i].GetValue(item) ?? DBNull.Value;
               table.Rows.Add(values);
           }
           return table;
       }


       public DataTable ContactTable()
       {
           DataTable dt = new DataTable();
           dt.Columns.Add(new DataColumn("ContactID", typeof(int)));
           dt.Columns.Add(new DataColumn("FirstName", typeof(string)));
           dt.Columns.Add(new DataColumn("LastName", typeof(string)));
           dt.Columns.Add(new DataColumn("Email", typeof(string)));
           dt.Columns.Add(new DataColumn("Phone", typeof(string)));
           return dt;
       }
         public DataTable ContactTableID()
       {
           DataTable dt = new DataTable();
           dt.Columns.Add(new DataColumn("ID", typeof(int)));          
           return dt;
       }

       public DataTable PaymentInvoiceInfoTable(List<InvoiceListModel> model)
       {
           DataTable dt = new DataTable();
           dt.Columns.Add("PaymentInvoiceID", typeof(System.Int32));
           DataRow dr = null;
           foreach (InvoiceListModel item in model)
           {

               if (item.PaymentInvoiceID != null && item.Checked)
               {
                   dr = dt.NewRow();
                   dr["PaymentInvoiceID"] = item.PaymentInvoiceID;
                   dt.Rows.Add(dr);
               }
           }

           return dt;
       }

    
    }
}
