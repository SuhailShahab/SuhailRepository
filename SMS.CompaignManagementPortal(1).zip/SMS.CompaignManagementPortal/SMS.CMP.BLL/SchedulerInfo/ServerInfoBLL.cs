﻿using BLL.Common;
using DAL.Common;
using SMS.CMP.DAL.SchedularInfo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.SchedulerInfo
{
   public  class ServerInfoBLL : BaseBLL
    {
       public bool IsActiveServer(int? ID)
       {
           try
           {
               return LazySingletonDAL<ServerInfoDAL>.Instance.IsActiveServer(ID);
           }
           catch (Exception ex)
           {
               throw ex;
           }
           
       }

       public int? UpdateServerActive(int? ID)
       {
           int? result = 0;
           try
           {
               result = LazySingletonDAL<ServerInfoDAL>.Instance.UpdateServerActive(ID);
           }
           catch (Exception ex)
           {
               throw ex;
           }
           return result;
       }

       /// <summary>
       /// Count the Actual SMS Send
       /// </summary>
       /// <param name="message"></param>
       /// <param name="IsEncodeOn"></param>
       /// <returns></returns>
       public int? GetTotalNoOfSMS(string message, bool IsEncodeOn)
       {
           if (string.IsNullOrEmpty(message))
           {
               return 1;
           }
           else
           {

               int messageLengh = message.Length;
               int singleSMSChar = 0;

               if (IsEncodeOn)
               {
                   singleSMSChar = 67;
               }
               else
               {
                   singleSMSChar = 153;
               }

               int totalNumberOfSMS = messageLengh / singleSMSChar;
               int remainderOfSMS = messageLengh % singleSMSChar;

               if (totalNumberOfSMS == 0)
               {
                   totalNumberOfSMS = totalNumberOfSMS + 1;
               }
               else if (remainderOfSMS > 0)
               {
                   totalNumberOfSMS = totalNumberOfSMS + 1;
               }

               return totalNumberOfSMS;

           }
       }

    }
}
