﻿
using BE.Lookups;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.BLL.CMP;
//using SMS.CMP.BE.SMSQueue;
using SMS.CMP.DAL.SMSQueue;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BLL.SMSQueue
{

    // =================================================================================================================================
    // Create by:	<sohail Shahab>
    // Create date: <30-11-2015 12:16 AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription

    // CR:001       Syed Zeeshan Aqil           30-Nov- 2015 12:14 PM       Add Method  spGetSMSQueues to get SMS Queues Information
    // CR:002       Syed Zeeshan Aqil           30-Nov- 2015 12:34 PM       Add Method  GetSMSQueueMessage to get SMS Queues Message
    // CR:003       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  GetSMSQueueList 
    // CR:004       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  GetNextSMSQueue To get Buffer SMS 
    // CR:005       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  PurgeBuffer To Purge whole table
    // CR:006       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  MarkSMSQueueSendStatus To update status
    // CR:007       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  IsExistPendingSMSQueue To check table rows count
    // CR:008       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  ResetSMSQueue To re-send failed sms to beffer



    // =================================================================================================================================

    public class SMSQueueBLL
    {
        /// <summary>
        /// Saving SMS Que Model 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(SMSQueueModel model)
        {
            return LazySingletonBLL<SMSQueueDAL>.Instance.Add(model);
        }

        public int SaveBulk(List<SMSQueueModel> lstContacts)
        {
            SMSQueueModel smsQueueModel = new SMSQueueModel();
            try
            {
                DataTable dt = null;
                smsQueueModel.OrganizationID = lstContacts[0].OrganizationID;
                smsQueueModel.CampaignID = lstContacts[0].CampaignID;
                smsQueueModel.SendMessage = lstContacts[0].SendMessage;
                smsQueueModel.DeliveryStatusID = lstContacts[0].DeliveryStatusID;
                smsQueueModel.IsSend = lstContacts[0].IsSend;
                smsQueueModel.ResponseID = lstContacts[0].ResponseID;
                smsQueueModel.VersionNo = lstContacts[0].VersionNo;
                smsQueueModel.Lang = lstContacts[0].Lang;
                smsQueueModel.NoOfSMS = lstContacts[0].NoOfSMS;



                dt = LazySingletonBLL<CommonBuildModel>.Instance.ToDataTable((from queueData in lstContacts
                                                                              select new
                                                                              {
                                                                                  queueData.SMSGateway,
                                                                                  queueData.UserName,
                                                                                  queueData.Password,

                                                                                  queueData.IsOnNet,
                                                                                  queueData.SMSSendingID,
                                                                                  queueData.ContactID,
                                                                                  queueData.Phone,
                                                                                  queueData.ContactNo,
                                                                                  queueData.ShortCode,
                                                                                  queueData.Mode,
                                                                                  queueData.TelcoID,


                                                                              }).ToList());
                return LazySingletonBLL<SMSQueueDAL>.Instance.AddBulkQueue(smsQueueModel, dt);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, ex.Message, 1, "SMSQueueBLL", 0));
                throw ex;
            }
        }
        public int? SaveSMS(BulkSMSModel model)
        {

            int? result = 0;
            try
            {
                if (model.ID.HasValue && model.ID.Value > 0)
                {
                    result = LazySingletonBLL<SMSQueueDAL>.Instance.EditSMS(model);
                }
                else
                {
                    result = LazySingletonBLL<SMSQueueDAL>.Instance.AddSMS(model);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public int? AddBulkSMSToBuffer(BulkSMSModel bulkSMSModel)
        {
            try
            {
                return LazySingletonBLL<SMSQueueDAL>.Instance.AddBulkSMSToBuffer(bulkSMSModel);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int? DeleteSMS(int id)
        {
            try
            {
                return LazySingletonBLL<SMSQueueDAL>.Instance.DeleteSMS(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int? AddBulkSMS(int createdBY, BulkSMSModel bulkSMSModel)
        {
            try
            {
                return LazySingletonBLL<SMSQueueDAL>.Instance.AddBulkSMS(createdBY, bulkSMSModel);
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<BulkContactModel> GetAllBulkContactsWithPaging(int pageNo, int pageSize, int? userId)
        {
            try
            {
                return BindDataForBulkSMS(LazySingletonBLL<SMSQueueDAL>.Instance.GetAllBulkContactWithPaging(pageNo, pageSize, userId));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<BulkContactModel> GetAllBulkContactWithPagingByText(int pageNo, int pageSize, int? userId, int? organizationID, int? departmentID, string searchText)
        {
            try
            {
                return BindDataForBulkSMS(LazySingletonBLL<SMSQueueDAL>.Instance.GetAllBulkContactWithPagingByText(pageNo, pageSize, userId, organizationID, departmentID, searchText));
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// CR:004
        /// get alll 
        /// </summary>
        /// <returns></returns>
        public List<SMSQueueModel> GetNextSMSQueue()
        {
            return BindData(LazySingletonBLL<SMSQueueDAL>.Instance.GetNextSMSQueue());
        }
        /// <summary>
        /// CR:004
        /// get alll 
        /// </summary>
        /// <returns></returns>
        public List<SMSQueueModel> GetNextSMSQueueByIDs(int? telcoID, int? smsThroughput)
        {
            try
            {
                return BindData(LazySingletonBLL<SMSQueueDAL>.Instance.GetNextSMSQueueByIDs(telcoID, smsThroughput));
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        /// <summary>
        /// CR:006 
        /// update SMSQueue Send Status
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int MarkSMSQueueSendStatus(SMSQueueModel model)
        {
            try
            {
                return LazySingletonBLL<SMSQueueDAL>.Instance.UpdateSMSQueueSendStatus(model);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        /// <summary>
        /// CR:005
        /// Purge the whole table
        /// </summary>
        /// <returns></returns>
        public int PurgeBufferData()
        {
            int ret = 0;
            ret = LazySingletonBLL<SMSQueueDAL>.Instance.PurgeBuffer();
            return ret;
        }

        /// <summary>
        /// CR:007 
        /// Check Existing Pending SMS Queue
        /// </summary>
        /// <returns></returns>
        public bool IsExistPendingSMSQueue()
        {
            bool result = false;
            try
            {
                result = LazySingletonBLL<SMSQueueDAL>.Instance.IsExistPendingSMSQueue();
                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        /// <summary>
        ///  CR:001
        ///  Get SMs Queue Infromation from Database
        /// </summary>
        /// <param name="model"> SMS Queue Model</param>
        /// <param name="search">Search Model</param>
        /// <returns>SMS Queue View Model</returns>
        public SMSQueueViewModel spGetSMSQueues(SMSQueueViewModel model, SearchModel search)
        {
            //List<SMSQueueModel> smsQueue = new List<SMSQueueModel>();

            //List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(model.User.UserID.Value);
            //if (organizations != null && organizations.Count > 0)
            //    model.Organizations = organizations;


            //if (model.User.OrganizationID > 0 && model.User.DepartmentID > 0)
            //{

            //    search.OrganizaitonID = model.User.OrganizationID;
            //    search.UserID = model.User.UserID;
            //    search.DepartmentID = model.User.DepartmentID;

            //    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, search.UserID.Value);
            //    model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(search.OrganizaitonID.Value, model.User.DepartmentID, null);
            //    smsQueue = BindData(LazySingletonBLL<SMSQueuesDAL>.Instance.spGetSMSQueues(search));
            //}
            //else if (model.User.OrganizationID > 0 && model.User.DepartmentID == 0)
            //{
            //    search.OrganizaitonID = model.User.OrganizationID;
            //    search.UserID = model.User.UserID;

            //    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, search.UserID.Value);
            //    model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(search.OrganizaitonID.Value, search.DepartmentID.Value, null);
            //    smsQueue = BindData(LazySingletonBLL<SMSQueuesDAL>.Instance.spGetSMSQueues(search));
            //}
            //else
            //{
            //    search.UserID = model.User.UserID;

            //    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, model.User.UserID.Value);
            //    model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(search.OrganizaitonID.Value, search.DepartmentID.Value, null);
            //    smsQueue = BindData(LazySingletonBLL<SMSQueuesDAL>.Instance.spGetSMSQueues(search));
            //}
            //if (smsQueue != null && smsQueue.Count > 0)
            //{
            //    model.SMSQueues = smsQueue;
            //    model.TotalCount = smsQueue[0].RESULT_COUNT.Value;
            //}


            //return model;

            try
            {
                List<SMSQueueModel> smsQueue = new List<SMSQueueModel>();

                List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(model.User.UserID.Value);
                if (organizations != null && organizations.Count > 0)
                    model.Organizations = organizations;


                if (model.User.OrganizationID > 0 && model.User.DepartmentID > 0)
                {

                    search.OrganizaitonID = model.User.OrganizationID;
                    search.UserID = model.User.UserID;
                    search.DepartmentID = model.User.DepartmentID;

                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, search.UserID.Value);
                    model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(search.OrganizaitonID.Value, model.User.DepartmentID, null);
                    smsQueue = BindData(LazySingletonBLL<SMSQueuesDAL>.Instance.spGetSMSQueues(search));
                }
                else if (model.User.OrganizationID > 0 && model.User.DepartmentID == 0)
                {
                    search.OrganizaitonID = model.User.OrganizationID;
                    search.UserID = model.User.UserID;

                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, search.UserID.Value);
                    model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(search.OrganizaitonID.Value, search.DepartmentID.Value, null);
                    smsQueue = BindData(LazySingletonBLL<SMSQueuesDAL>.Instance.spGetSMSQueues(search));
                }
                else
                {
                    search.UserID = model.User.UserID;

                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(search.OrganizaitonID.Value, model.User.UserID.Value);
                    model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(search.OrganizaitonID.Value, search.DepartmentID.Value, null);
                    smsQueue = BindData(LazySingletonBLL<SMSQueuesDAL>.Instance.spGetSMSQueues(search));
                }
                if (smsQueue != null && smsQueue.Count > 0)
                {
                    model.SMSQueues = smsQueue;
                    model.TotalCount = smsQueue[0].RESULT_COUNT.Value;
                }


                return model;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// CR:002
        /// This Method is use to get the SMS Queue  Message 
        /// </summary>
        /// <param name="queueID">Selected Queue ID</param>
        /// <returns>Transaction SMS Queue Message</returns>
        public string GetSMSQueueMessage(int queueID)
        {
            //return LazySingletonBLL<SMSQueuesDAL>.Instance.GetSMSQueueMessage(queueID);
            try
            {
                return LazySingletonBLL<SMSQueuesDAL>.Instance.GetSMSQueueMessage(queueID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// CR:009
        /// Set SMS Queue Model
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int SetQueueDeliveryStatus(SMSQueueModel model)
        {
            try
            {
                return LazySingletonBLL<SMSQueueDAL>.Instance.SetQueueDeliveryStatus(model);
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        /// <summary>
        /// CR:008 
        /// Reset SMS Queue
        /// </summary>
        /// <param name="campaignID"></param>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public int ResetSMSQueue(int campaignID, int organizationID)
        {
            try
            {
                return LazySingletonBLL<SMSQueueDAL>.Instance.ResetSMSQueue(campaignID, organizationID);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        /// <summary>
        /// CR:003
        /// SMS Queue List
        /// </summary>
        /// <returns></returns>
        public DataTable GetSMSQueueList(int organizationID, int campaignID)
        {
            //DataTable dt = null;
            //dt = LazySingletonBLL<SMSQueueDAL>.Instance.GetCurrentSMSQueue(organizationID, campaignID);
            //return dt.Copy();
            try
            {
                DataTable dt = null;
                dt = LazySingletonBLL<SMSQueueDAL>.Instance.GetCurrentSMSQueue(organizationID, campaignID);
                return dt.Copy();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region "Private Methods"
        private List<SMSQueueModel> BindData(DataTable dt)
        {
            List<SMSQueueModel> lists = new List<SMSQueueModel>();
            if (dt.Rows.Count > 0)

                lists = (List<SMSQueueModel>)LazySingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SMSQueueModel());

            return lists;
        }
        private List<BulkContactModel> BindDataForBulkSMS(DataTable dt)
        {
            IList<BulkContactModel> lists = null;
            if (dt.Rows.Count > 0)
            {
                lists = LazySingletonBLL<CommonBuildModel>.Instance.BuildModel<BulkContactModel>(dt, new BulkContactModel());
                return lists.ToList();
            }

            return null;
        }

        #endregion

    }
}
