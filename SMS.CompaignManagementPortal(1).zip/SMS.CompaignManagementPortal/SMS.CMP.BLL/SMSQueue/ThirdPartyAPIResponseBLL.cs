﻿using DAL.Common;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.DAL.SMSQueue;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// =================================================================================================================================
// Create by:	<sohail Shahab>
// Create date: <10-12-2015 08:59 AM>
// Manage the Third Party API Telnor Reposne
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription

namespace SMS.CMP.BLL.SMSQueue
{
    public class ThirdPartyAPIResponseBLL
    {
        /// <summary>
        /// Add the reposne of ThirdParty API Resposne in case of sending sms successfully
        /// </summary>
        /// <param name="thirdPartyAPIResponseModel"></param>
        /// <returns></returns>
        public int? AddThirdPartyResponse(ThirdPartyAPIResponseModel thirdPartyAPIResponseModel)
        {
            int? result;
            try
            {
                result = LazySingletonDAL<ThirdPartyAPIResponseDAL>.Instance.Add(thirdPartyAPIResponseModel);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        /// <summary>
        /// Update third Party Response Data
        /// </summary>
        public void UpdateThirdPartyResponse()
        {
            try
            {
                LazySingletonDAL<ThirdPartyAPIResponseDAL>.Instance.UpdateThirdPartyResponse();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

       

        /// <summary>
        /// Update Third Party Response Data By ID
        /// </summary>
        /// <param name="thirdPartyAPIResponseID"></param>
        /// <param name="statusID"></param>
        public void UpdateThirdPartyResponseByID(int? thirdPartyAPIResponseID, int? statusID)
        {
            try
            {
                LazySingletonDAL<ThirdPartyAPIResponseDAL>.Instance.UpdateThirdPartyResponseByID(thirdPartyAPIResponseID, statusID);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// For Checking Record Existance
        /// </summary>
        /// <param name="thirdPartyAPIResponseID"></param>
        /// <param name="statusID"></param>
        public bool  IsExistsRecords()
        {
            int? result = 0;
            try
            {
                result = LazySingletonDAL<ThirdPartyAPIResponseDAL>.Instance.IsExistsRecords();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (result.HasValue)
            {
                return Convert.ToBoolean(result.Value);
            }

            return false;
        }

        public int? RemoveRecords()
        {
            return 1;
        }
    }
}
