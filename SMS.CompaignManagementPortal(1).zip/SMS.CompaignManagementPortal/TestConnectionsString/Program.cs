﻿using BLL.Common;
using SMS.CMP.BLL.SchedulerInfo;
using SMS.CMP.BLL.SMSQueue;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestConnectionsString
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isActiveServer = false;
            try
            {
                if (Convert.ToInt32(ConfigurationManager.AppSettings["TestDB"]) == 1)
                {
                    isActiveServer = LazySingletonBLL<ServerInfoBLL>.Instance.IsActiveServer(1);
                    Console.WriteLine("CMP DB Ok");
                   // throw  new Exception("test");
                    Console.Read();
                }
                else
                {
                    isActiveServer = LazySingletonBLL<SMSQueueBLL>.Instance.IsExistPendingSMSQueue();
                    Console.WriteLine("Configuration DB Ok");
                    Console.Read();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error"+ex.Message);
               
                Console.Read();
            }
           
             
        }
    }
}
