﻿using System;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <06-05-2016 02:15:45PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
namespace BE
{
    public class SMSModel
    {
        public string PhoneNo { get; set; }
        public string SMSMessage { get; set; }

        #region "Constructors"

        public SMSModel()
        {

        }

        public SMSModel(string ContactNo, string Message)
        {
            this.PhoneNo = ContactNo;
            this.SMSMessage = Message;
        }

        #endregion
    }
}
