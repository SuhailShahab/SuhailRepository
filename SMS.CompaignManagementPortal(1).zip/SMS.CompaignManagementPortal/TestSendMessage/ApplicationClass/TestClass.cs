﻿using BE;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using TestSendMessage.TestWCFService;

namespace TestSendMessage.ApplicationClass
{
   public  class TestClass
    {
       public void SendSMSAlert(string MobileNo, string Message)
       {
           SMSModel sms = new SMSModel(MobileNo, Message);
           string Data = "";

           try
           {
               // serailze model object to json string
               DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(SMSModel));
               MemoryStream mem = new MemoryStream();
               ser.WriteObject(mem, sms);
               Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

               // process the request and get response as string
              // string ServiceURL = "http://sms.punjab.gov.pk/api/cmpservice.svc/smssend/NjYx/Mg==/en";//"http://sms.punjab.gov.pk/api/cmpservice.svc/smssend/MzAz/MTI=/en";//ConfigurationHelper.SMSGatewayURL;
              // string ServiceURL = "https://connect.jazzcmt.com/sendsms_url.html?Username=03070984927&Password=Jazz@1234&From=9100&To=03320754179&Message=صبح بخیر";
               string ServiceURL = "https://connect.jazzcmt.com/sendsms_url.html?Username=03070984927&Password=Jazz@1234&From=9100&To=" + MobileNo + "&Message=" + Message;
               WebClient webClient = new WebClient();
               webClient.Headers["Content-type"] = "application/json";
               webClient.Encoding = Encoding.UTF8;

               Uri address = new Uri(ServiceURL);
             string result =  webClient.UploadString(address, "POST", Data);
           }
           catch (Exception ex)
           {
              
           }
       }

       //public static async Task<string> SendSmsToClient(string url)
       //{
       //    WebRequest wr = WebRequest.Create(url);
       //    var response = await wr.GetResponseAsync();
       //    using (var stm = response.GetResponseStream())
       //    {
       //        using (var reader = new StreamReader(stm))
       //        {
       //            var content = await reader.ReadToEndAsync();
       //            return content;
       //        }
       //    }
       //}

       public bool SendSmsToClient1(string hostURI)
       {
           WebRequest request = WebRequest.Create(hostURI);
           request.Method = "GET";
           //return true;

           using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
           {
               Stream dataStream = response.GetResponseStream();
               StreamReader reader = new StreamReader(dataStream);
               string test = reader.ReadToEnd();
               reader.Close();
               dataStream.Close();

               return true;
           }

       }

       public dynamic TestMethod(string applicantID)
       {
           dynamic nic;
           using (PITBFacilitationCentreServiceClient proxy = new PITBFacilitationCentreServiceClient())
           {


               nic = proxy.GetNICRecordByApplicantID(applicantID);
             

           }
           return nic;
       }
    }
}
