﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestSendMessage.ApplicationClass;

namespace TestSendMessage
{
    class Program
    {
        static void Main(string[] args)
        {
             TestClass tesMessage = new TestClass();
             tesMessage.SendSMSAlert("03464295192", "test Mesage from shahab");

            // new   TestClass().SendSmsToClient1("http://localhost:55176/PITBFacilitationCentreService.svc/GetNICRecordByApplicantID/FCBWP-D-081118-007685");
            //dynamic abc =   new TestClass().TestMethod("FCBWP-D-081118-007685");

           // new TestClass().SendSMSAlert("", "");
            /*
            decimal A = 17;
            decimal B = 23;
            decimal C = (A / B) * 100;
            Console.WriteLine(C);
            decimal Percentage = Math.Round(100 - C);
            Console.WriteLine(Percentage);
            decimal r = Math.Round(Convert.ToDecimal(10.005));
           // AppDomain.CurrentDomain.ProcessExit += ProcessExitHandler;
            Console.WriteLine("Email Successfully");
            Environment.Exit(0);
            */
        }

        static void ProcessExitHandler(object sender, EventArgs e)
        {
            throw new NotImplementedException("You can't shut me down. I quit!");
        }
    }
}
