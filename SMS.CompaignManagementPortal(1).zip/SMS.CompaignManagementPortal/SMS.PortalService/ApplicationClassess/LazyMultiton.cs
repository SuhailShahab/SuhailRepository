﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS.PortalService.ApplicationClassess
{
    //==============MultitonPattern=====================================
    public abstract class LazyMultiton<T>
        where T : new()
    {

        private static readonly Dictionary<int, T> serverPool =
       new Dictionary<int, T>
        {
            {1,new  T()},
            {2,new  T()},
            {3,new  T()},
            {4,new  T()},
            {5,new  T() }
        };
        private static readonly object _lock = new object();
        private static readonly Random random = new Random();
        private static readonly object randomLock = new object();
        public static T Instance()
        {
            lock (randomLock)
            {
                int key = random.Next(1, (serverPool.Count + 1));
                Console.WriteLine("Key=" + key.ToString());
                return serverPool[key];
            }

        }
    }
}