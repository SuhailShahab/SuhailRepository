﻿using System;
using System.Web.Configuration;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <27-10-2015 03:43:16PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.PortalService.ApplicationClassess
{
    public class ConfigurationHelper
    {
        public static string SMSServiceUrl
        {
            get
            {
                return WebConfigurationManager.AppSettings["SMSServiceUrl"];
            }
        }

        public static string SMSUserName
        {
            get
            {
                return WebConfigurationManager.AppSettings["SMSUserName"];
            }
        }

        public static string SMSPassword
        {
            get
            {
                return WebConfigurationManager.AppSettings["SMSPassword"];
            }
        }

        public static string SMSSendFrom
        {
            get
            {
                return WebConfigurationManager.AppSettings["SMSSendFrom"];
            }
        }

        public static string SMSGateWay
        {
            get
            {
                return WebConfigurationManager.AppSettings["SMSGateWay"];
            }
        }

        public static string HostingIP
        {
            get
            {
                return WebConfigurationManager.AppSettings["HostingIP"];
            }
        }

        public static string LogFilePath
        {
            get
            {
                return WebConfigurationManager.AppSettings["LogFilePath"];
            }
        }

        public static bool ShowLog
        {
            get
            {
                return Convert.ToBoolean(WebConfigurationManager.AppSettings["ShowLog"]);
            }
        }
        public static bool IsBuffered
        {
            get
            {
                return Convert.ToBoolean(WebConfigurationManager.AppSettings["IsBuffered"]);
            }
        }

        public static bool IsBufferedForReply
        {
            get
            {
                return Convert.ToBoolean(WebConfigurationManager.AppSettings["IsBufferedForReply"]);
            }
        }

        
        public static bool IsSecured
        {
            get
            {
                return Convert.ToBoolean(WebConfigurationManager.AppSettings["IsSecured"]);
            }
        }

        public static string ResponeMessage
        {
            get
            {
                return WebConfigurationManager.AppSettings["ResponeMessage"];
            }
        }


        //public static bool IsSavedBulkDataInQueue
        //{
        //    get
        //    {
        //        return Convert.ToBoolean(WebConfigurationManager.AppSettings["IsSavedBulkDataInQueue"]);
        //    }
        //}
    }
}