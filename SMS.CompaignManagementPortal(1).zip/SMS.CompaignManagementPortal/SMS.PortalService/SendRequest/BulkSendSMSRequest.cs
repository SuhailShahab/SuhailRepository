﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Common;
using SMS.CMP.BE.CustomEnums;
using SMS.CMP.BE.CustomExcetion.APIExcetion;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.SchedulerInfo;
using SMS.CMP.BLL.SMSQueue;
using SMS.PortalService.ApplicationClassess;
using SMS.PortalService.ApplicationClassess.Log;
using SMS.PortalService.DataModel;
using System;
using System.Collections.Generic;
using System.Threading;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <19-10-2015 09:43:16AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// 001          Suhail                          27-01-2016                      Add New Column NoOfSMS
// =================================================================================================================================
namespace SMS.CMPService.SendRequest
{
    public class BulkSendSMSRequest:IDisposable
    {
        private static readonly object Locker = new object();
        private static readonly object contactsLocker = new object();
        public int? CampaignID { get; set; }
        public int? OrganizationID { get; set; }
        public int? VersoinNo { get; set; }
        public string ShortCode { get; set; }
        public string Message { get; set; }
        public int? NoOfSMS { get; set; }
        public BulkSendSMSRequest()
        { }

        public BulkSendSMSRequest(int? campaignID, int? organizationID, string shortCode)
        {
            this.CampaignID = campaignID;
            this.OrganizationID = organizationID;
            this.ShortCode = shortCode;
        }

        public BulkSendSMSRequest(int? campaignID, int? organizationID)
        {
            this.CampaignID = campaignID;
            this.OrganizationID = organizationID;
        }

        //public bool SendBulkSMS()
        //{
        //    B2BayLogger.Log("Call Methods SendBulkSMS :Get All contact again campaign and Organization/Customer");
        //    Thread.Sleep(6000);

            

        //    // ======================================= Get all contacts against provided organization and campaign ================================================= //
        //    //    /// In Case Of Bufffered will select All Contacts at once ....
        //    //    /// In Case Of Non - Bufffered will select top 50 Contacts one by one ....

        //    List<ContactModel> contacts =  LazySingletonBLL<ContactBLL>.Instance.GetCampaignContacts(this.OrganizationID, this.CampaignID, this.VersoinNo, ConfigurationHelper.IsBuffered);

        //    if (contacts != null && contacts.Count > 0)
        //    {
        //        foreach (ContactModel contact in contacts)
        //        {
        //            VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(this.OrganizationID, this.CampaignID);       // verifty validity of provided orgainzation id and compaign id 
        //            if (result != null && result.SMS_SendingID > 0)
        //            {
        //                string shortCode = string.IsNullOrEmpty(this.ShortCode) ? result.ShortCode : this.ShortCode;
        //                B2BayLogger.Log("shortCode" + shortCode);

        //                string message = string.IsNullOrEmpty(this.Message) ? result.SMSMessage : this.Message;
        //                B2BayLogger.Log("message" + message);

        //                // ========================================= Generate and Get SMS ID ======================================= //
        //                string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(this.OrganizationID.ToString(), this.CampaignID.ToString(), result.SMS_SendingID.ToString());

        //                // ========================================= Send Request ======================================= //
        //                SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.SendRequest(contact.Phone, message, ID, shortCode);
        //                B2BayLogger.Log("SendRequest");

        //                // =================================== Add record in SMS Transactions ================================= //
        //                SMSTransactionModel SMSModel = new SMSTransactionModel();
        //                SMSModel.CampaignID = Convert.ToInt32(this.CampaignID);
        //                SMSModel.OrganizationID = Convert.ToInt32(this.OrganizationID);
        //                SMSModel.SendMessage = message;
        //                SMSModel.ContactNo = contact.Phone;
        //                SMSModel.OriginalContactNo  = contact.Phone;// LazySingleton<CommonBLL>.Instance.ConvertContactNo92(smsConfigurationModel.SendPhoneNo);
        //                SMSModel.SMSSendingID = result.SMS_SendingID;
        //                SMSModel.ContactID = contact.ID;
        //                SMSModel.TelcoID = smsConfigurationModel.TelcoID;
        //                SMSModel.IsOnNet = smsConfigurationModel.IsOnNet;
        //                SMSModel.Mode = RequestSourceName.Portal.GetHashCode();
        //                SMSModel.VersionNo = this.VersoinNo;
        //                LazySingleton<SMSTransactionBLL>.Instance.Save(SMSModel);
        //            }
        //            else
        //            {
        //                B2BayLogger.Log("Not Validate");
        //            }
        //        }

        //        if (contacts != null && contacts.Count > 0 && LazySingleton<ContactBLL>.Instance.IsExistCampaignContact(this.OrganizationID, this.CampaignID,this.VersoinNo))
        //        {
        //            this.SendBulkSMS();
        //        }
        //    }
        //    else
        //    {
        //        B2BayLogger.Log("No Contacts  against campaign and Organization/Customer");
        //    }

        //    B2BayLogger.WriteLogsToFile();

        //    return true;
        //}

        public bool SendBulkSMS(string language)
        {
            B2BayLogger.Log("Call Methods SendBulkSMS :Get All contact again campaign and Organization/Customer");
            Thread.Sleep(6000);



            // ======================================= Get all contacts against provided organization and campaign ================================================= //
            //    /// In Case Of Bufffered will select All Contacts at once ....
            //    /// In Case Of Non - Bufffered will select top 50 Contacts one by one ....
            lock (contactsLocker)
            {
                List<ContactModel> contacts = LazySingletonBLL<ContactBLL>.Instance.GetCampaignContacts(this.OrganizationID, this.CampaignID, this.VersoinNo, ConfigurationHelper.IsBuffered);

                if (contacts != null && contacts.Count > 0)
                {
                    foreach (ContactModel contact in contacts)
                    {
                        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(this.OrganizationID, this.CampaignID);       // verifty validity of provided orgainzation id and compaign id 
                        if (result != null && result.SMS_SendingID > 0)
                        {
                            string shortCode = string.IsNullOrEmpty(this.ShortCode) ? result.ShortCode : this.ShortCode;
                            B2BayLogger.Log("shortCode" + shortCode);

                            string message = string.IsNullOrEmpty(this.Message) ? result.SMSMessage : this.Message;
                            B2BayLogger.Log("message" + message);

                            // ========================================= Generate and Get SMS ID ======================================= //
                            string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(this.OrganizationID.ToString(), this.CampaignID.ToString(), result.SMS_SendingID.ToString());

                            // ========================================= Send Request ======================================= //
                            SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.SendRequest(contact.Phone, message, ID, shortCode, language);
                            B2BayLogger.Log("SendRequest");

                            // =================================== Add record in SMS Transactions ================================= //
                            SMSTransactionModel SMSModel = new SMSTransactionModel();
                            SMSModel.CampaignID = Convert.ToInt32(this.CampaignID);
                            SMSModel.OrganizationID = Convert.ToInt32(this.OrganizationID);
                            SMSModel.SendMessage = message;
                            SMSModel.ContactNo = contact.Phone;
                            SMSModel.OriginalContactNo = contact.Phone;// LazySingleton<CommonBLL>.Instance.ConvertContactNo92(smsConfigurationModel.SendPhoneNo);
                            SMSModel.SMSSendingID = result.SMS_SendingID;
                            SMSModel.ContactID = contact.ID;
                            SMSModel.TelcoID = smsConfigurationModel.TelcoID;
                            SMSModel.IsOnNet = smsConfigurationModel.IsOnNet;
                            SMSModel.Mode = RequestSourceName.Portal.GetHashCode();
                            SMSModel.VersionNo = this.VersoinNo;
                            SMSModel.Lang = language;
                            SMSModel.NoOfSMS = this.NoOfSMS;
                            LazySingleton<SMSTransactionBLL>.Instance.Save(SMSModel);
                        }
                        else
                        {
                            B2BayLogger.Log("Not Validate");
                        }
                    }

                    if (contacts != null && contacts.Count > 0 && LazySingleton<ContactBLL>.Instance.IsExistCampaignContact(this.OrganizationID, this.CampaignID, this.VersoinNo))
                    {
                        this.SendBulkSMS(language);
                    }
                }
                else
                {
                    B2BayLogger.Log("No Contacts  against campaign and Organization/Customer");
                }
            }

            B2BayLogger.WriteLogsToFile();

            return true;
        }



        /// <summary>
        /// Send Portal Data into Buffer 
        /// </summary>
        /// <returns></returns>
        //public bool SendDataIntoBuffer()
        //{
        //    B2BayLogger.Log("Call Methods StoreDataIntoBuffer :Get All contact again campaign and Organization/Customer");

        //    // ======================================= Get all contacts against provided organization and campaign ================================================= //
        //    //    /// In Case Of Bufffered will select All Contacts at once ....
        //    //    /// In Case Of Non - Bufffered will select top 50 Contacts one by one ....

        //    List<ContactModel> contacts = LazySingletonBLL<ContactBLL>.Instance.GetCampaignContacts(this.OrganizationID, this.CampaignID, this.VersoinNo, ConfigurationHelper.IsBuffered);

        //    if (contacts != null && contacts.Count > 0)
        //    {
        //        string message = string.Empty;
        //        string phone = string.Empty;

        //        try
        //        {
        //            foreach (ContactModel contact in contacts)
        //            {
        //                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(this.OrganizationID, this.CampaignID);       // verifty validity of provided orgainzation id and compaign id 
        //                if (result != null && result.SMS_SendingID > 0)
        //                {

        //                    phone = contact.Phone;
        //                    string shortCode = string.IsNullOrEmpty(this.ShortCode) ? result.ShortCode : this.ShortCode;
        //                    B2BayLogger.Log("shortCode" + shortCode);

        //                    message = string.IsNullOrEmpty(this.Message) ? result.SMSMessage : this.Message;
        //                    B2BayLogger.Log("message" + message);

        //                    // ========================================= Generate and Get SMS ID ======================================= //
        //                    string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(this.OrganizationID.ToString(), this.CampaignID.ToString(), result.SMS_SendingID.ToString());

        //                    //// ========================================= SMS Configuration Model======================================= //
        //                    SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.GetSMSConfigurationModel(contact.Phone);
        //                    //// ========================================= SMS Configuration Model ======================================= //

                         
        //                    //// ========================================= Fill SMSQueue Model ======================================= //
        //                    SMSQueueModel smsQueueModel = new SMSQueueModel();
        //                    FillSMSQueueModel(this.CampaignID, this.OrganizationID,   message, result.SMS_SendingID, smsQueueModel, smsConfigurationModel);
        //                    smsQueueModel.Mode = RequestSourceName.Portal.GetHashCode();
        //                    smsQueueModel.ContactID = contact.ID;
        //                    smsQueueModel.ShortCode = shortCode;
        //                    smsQueueModel.VersionNo = this.VersoinNo;

        //                    B2BayLogger.Log("Filling SMS Queue Model Complete");

        //                    //// ========================================= Insert Into buffer Containner ======================================= //
        //                    // Save To Que Table
        //                    LazySingleton<SMSQueueBLL>.Instance.Save(smsQueueModel);
        //                    //// ========================================= Insert Into buffer Containner ======================================= //

        //                    B2BayLogger.Log("SMS Queued Successfully");
        //                    B2BayLogger.WriteLogsToFile();

        //                }
        //                else
        //                {
        //                    B2BayLogger.Log("Not Validate");
        //                }
        //            }
        //        }
        //        catch (InvalidPhoneNo ex)
        //        {

        //            // =================================== Add record in SMS Transactions =================================//
        //            VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(this.OrganizationID, this.CampaignID);          // verifty validity of provided orgainzation id and compaign id 
        //            if (result != null && result.SMS_SendingID > 0)
        //            {
        //                SMSTransactionModel SMSModel = new SMSTransactionModel();
        //                SMSModel.CampaignID = this.CampaignID;
        //                SMSModel.OrganizationID = this.OrganizationID;
        //                SMSModel.SendMessage = message;
        //                SMSModel.ContactNo = phone;
        //                SMSModel.SMSSendingID = result.SMS_SendingID;
        //                SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
        //                SMSModel.Mode = RequestSourceName.Portal.GetHashCode();
        //                LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
        //            }


        //            //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
        //            B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
        //            LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_CMPService, 0));
        //            B2BayLogger.Log(ex.Message);
        //            B2BayLogger.WriteLogsToFile();
        //        }

        //        if (contacts != null && contacts.Count > 0 && LazySingleton<ContactBLL>.Instance.IsExistCampaignContact(this.OrganizationID, this.CampaignID, this.VersoinNo))
        //        {
        //            this.SendDataIntoBuffer();
        //        }
        //    }
        //    else
        //    {
        //        B2BayLogger.Log("No Contacts  against campaign and Organization/Customer");
        //    }

        //    B2BayLogger.WriteLogsToFile();

        //    return true;
        //}
        public bool SendDataIntoBuffer(string language)
        {
            B2BayLogger.Log("Call Methods StoreDataIntoBuffer :Get All contact again campaign and Organization/Customer");

            // ======================================= Get all contacts against provided organization and campaign ================================================= //
            //    /// In Case Of Bufffered will select All Contacts at once ....
            //    /// In Case Of Non - Bufffered will select top 50 Contacts one by one ....
            lock (contactsLocker)
            {
                List<ContactModel> contacts = LazySingletonBLL<ContactBLL>.Instance.GetCampaignContacts(this.OrganizationID, this.CampaignID, this.VersoinNo, ConfigurationHelper.IsBuffered);

                if (contacts != null && contacts.Count > 0)
                {
                    string message = string.Empty;
                    string phone = string.Empty;
                   // bool IsSaveBulkQueueData = ConfigurationHelper.IsSavedBulkDataInQueue;
                   // List<SMSQueueModel> lstSMSQueue = null;
                    try
                    {
                       // if (IsSaveBulkQueueData) lstSMSQueue = new List<SMSQueueModel>();

                        foreach (ContactModel contact in contacts)
                        {
                            VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(this.OrganizationID, this.CampaignID);       // verifty validity of provided orgainzation id and compaign id 
                            B2BayLogger.Log("===Verfied User===");
                            if (result != null && result.SMS_SendingID > 0)
                            {

                                phone = contact.Phone;
                                string shortCode = string.IsNullOrEmpty(this.ShortCode) ? result.ShortCode : this.ShortCode;
                                B2BayLogger.Log("shortCode" + shortCode);

                                message = string.IsNullOrEmpty(this.Message) ? result.SMSMessage : this.Message;
                                B2BayLogger.Log("message" + message);

                                // ========================================= Generate and Get SMS ID ======================================= //
                                string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(this.OrganizationID.ToString(), this.CampaignID.ToString(), result.SMS_SendingID.ToString());

                                //// ========================================= SMS Configuration Model======================================= //
                                SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.GetSMSConfigurationModel(contact.Phone);
                                //// ========================================= SMS Configuration Model ======================================= //


                                //// ========================================= Fill SMSQueue Model ======================================= //
                                SMSQueueModel smsQueueModel = new SMSQueueModel();
                                FillSMSQueueModel(this.CampaignID, this.OrganizationID, message, result.SMS_SendingID, smsQueueModel, smsConfigurationModel);
                                smsQueueModel.Mode = RequestSourceName.Portal.GetHashCode();
                                smsQueueModel.ContactID = contact.ID;
                                smsQueueModel.ShortCode = shortCode;
                                smsQueueModel.VersionNo = this.VersoinNo;
                                smsQueueModel.Lang = language;
                                smsQueueModel.NoOfSMS = this.NoOfSMS;//CR:100
                                B2BayLogger.Log("Filling SMS Queue Model Complete");

                                //// ========================================= Insert Into buffer Containner ======================================= //
                                // Save To Que Table
                                LazySingleton<SMSQueueBLL>.Instance.Save(smsQueueModel);
                                //// ========================================= Insert Into buffer Containner ======================================= //



                                B2BayLogger.Log("SMS Queued Successfully");
                                B2BayLogger.WriteLogsToFile();

                            }
                            else
                            {
                                B2BayLogger.Log("Not Validate");
                            }
                        }

                      
                    }
                    catch (InvalidPhoneNo ex)
                    {

                        // =================================== Add record in SMS Transactions =================================//
                        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(this.OrganizationID, this.CampaignID);          // verifty validity of provided orgainzation id and compaign id 
                        if (result != null && result.SMS_SendingID > 0)
                        {
                            SMSTransactionModel SMSModel = new SMSTransactionModel();
                            SMSModel.CampaignID = this.CampaignID;
                            SMSModel.OrganizationID = this.OrganizationID;
                            SMSModel.SendMessage = message;
                            SMSModel.ContactNo = phone;
                            SMSModel.SMSSendingID = result.SMS_SendingID;
                            SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
                            SMSModel.Mode = RequestSourceName.Portal.GetHashCode();
                            LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
                        }


                        //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
                        B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
                        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_CMPService, 0));
                        B2BayLogger.Log(ex.Message);
                        B2BayLogger.WriteLogsToFile();
                    }

                    //if (contacts != null && contacts.Count > 0 && LazySingleton<ContactBLL>.Instance.IsExistCampaignContact(this.OrganizationID, this.CampaignID, this.VersoinNo))
                    //{
                    //    this.SendDataIntoBuffer(language);
                    //}
                }
                else
                {
                    B2BayLogger.Log("No Contacts  against campaign and Organization/Customer");
                }
            }//End of Locker

            B2BayLogger.WriteLogsToFile();

            return true;
        }


        /// <summary>
        /// Fill SMS Queue Model
        /// </summary>
        /// <param name="campaignID"></param>
        /// <param name="organizationgID"></param>
        /// <param name="message"></param>
        /// <param name="result"></param>
        /// <param name="ID"></param>
        /// <param name="smsQueueModel"></param>
        /// <param name="smsConfigurationModel"></param>
        private static void FillSMSQueueModel(int? campaignID, int? organizationgID,  string message, int SMSSendingID, SMSQueueModel smsQueueModel, SMSConfigurationModel smsConfigurationModel)
        {
            // Fill SMS Configuratiol Model
            smsQueueModel.SMSGateway = smsConfigurationModel.SMSGateway;
            smsQueueModel.UserName = smsConfigurationModel.UserName;
            smsQueueModel.Password = smsConfigurationModel.Password;
            smsQueueModel.TelcoID = smsConfigurationModel.TelcoID;
            smsQueueModel.IsOnNet = smsConfigurationModel.IsOnNet;
            smsQueueModel.SMSSendingID = SMSSendingID;         
            smsQueueModel.SendMessage = CommonMethod.ReplaceSpecilChar(message);
            string networkTypeCode = smsConfigurationModel.SendPhoneNo.Substring(0, 3);          
            smsQueueModel.CampaignID =campaignID;
            smsQueueModel.OrganizationID = organizationgID;          
            smsQueueModel.Phone = smsConfigurationModel.SendPhoneNo;
            smsQueueModel.ContactNo = smsConfigurationModel.OriginalContactNo;

            smsQueueModel.DeliveryStatusID = BufferStatusNames.AddToBuffer.GetHashCode();
            smsQueueModel.IsSend = BufferStatusNames.AddToBuffer.GetHashCode(); ; /// Push to Buffer 
          
        }

        /// <summary>
        /// Count the Actual SMS Send
        /// IsEncodeOn is False if language is English(En) else True
        /// </summary>
        /// <param name="message"></param>
        /// <param name="IsEncodeOn"></param>
        /// <returns></returns>
        //public int? GetTotalNoOfSMS(string message,bool IsEncodeOn)
        //{
        //    if (string.IsNullOrEmpty(message))
        //    {
        //        return 1;
        //    }
        //    else
        //    {

        //        int messageLengh = message.Length;
        //        int singleSMSChar = 0;

        //        if (IsEncodeOn)
        //        {
        //            singleSMSChar = 67;
        //        }
        //        else
        //        {
        //            singleSMSChar = 153;
        //        }

        //        int totalNumberOfSMS = messageLengh / singleSMSChar;
        //        int remainderOfSMS = messageLengh % singleSMSChar;

        //        if (totalNumberOfSMS == 0)
        //        {
        //            totalNumberOfSMS = totalNumberOfSMS + 1;
        //        }
        //        else if (remainderOfSMS > 0)
        //        {
        //            totalNumberOfSMS = totalNumberOfSMS + 1;
        //        }

        //        return totalNumberOfSMS;

        //    }
        //}



        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignID"></param>
        /// <param name="organizationgID"></param>
        /// <param name="phoneNumber"></param>
        /// <param name="message"></param>
        /// <param name="responseID"></param>
        //public void  SendReplySMSDirectToSMC(string campaignID, string organizationgID, string phoneNumber,string message,int? responseID)
        //{
        //    try
        //    {
        //        B2BayLogger.Log("Call Method SendSMS");

             
        //        Thread.Sleep(2000);
        //        B2BayLogger.Log("Wait for Send Request");
        //        //Check the SMS  Phone Number Validataion

        //        LazySingleton<SMSValidation>.Instance.CheckValidSMS(phoneNumber);


        //        if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID) && !string.IsNullOrEmpty(phoneNumber) && !string.IsNullOrEmpty(message))
        //        {
        //            lock (Locker)
        //            {
        //                int orgID = Convert.ToInt32(organizationgID);
        //                int campID = Convert.ToInt32(campaignID);
        //                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(orgID, campID);          // verifty validity of provided orgainzation id and compaign id 
        //                if (result != null && result.SMS_SendingID > 0)
        //                {

        //                    // ========================================= Get Valid Campaing Info ======================================= //
        //                    StartingCampaign startingCampaign = LazySingleton<SMSCampaignBLL>.Instance.GetValidCampaingsInfoByIDs(orgID, campID);
        //                    // ========================================= Generate and Get SMS ID ======================================= //
        //                    string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(organizationgID, campaignID, result.SMS_SendingID.ToString());
        //                    // ========================================= Send Request ======================================= //
        //                    string convertedNumber = LazySingleton<CommonBLL>.Instance.ConvertContactNo92(phoneNumber);
        //                    SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.SendRequest(convertedNumber, message, ID, result.ShortCode);
        //                    // =================================== Add record in SMS Transactions =================================//
        //                    SMSTransactionModel SMSModel = new SMSTransactionModel();
        //                    SMSModel.CampaignID = Convert.ToInt32(campaignID);
        //                    SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
        //                    SMSModel.SendMessage = message;
        //                    SMSModel.ContactNo = convertedNumber;
        //                    SMSModel.OriginalContactNo = phoneNumber;
        //                    SMSModel.SMSSendingID = result.SMS_SendingID;
        //                    SMSModel.TelcoID = smsConfigurationModel.TelcoID;
        //                    SMSModel.IsOnNet = smsConfigurationModel.IsOnNet;
        //                    SMSModel.DeliveryStatusID = SMSDeliveryStatuses.SendToSMSC.GetHashCode();
        //                    SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();
        //                    SMSModel.ResponseID = responseID;

        //                    if (startingCampaign.ResponseLanguageMode.HasValue && startingCampaign.ResponseLanguageMode.Value)
        //                    {
        //                        SMSModel.Lang = MessageLanguage.UR.ToString().ToLower();
        //                    }
        //                    else
        //                    {
        //                        SMSModel.Lang = MessageLanguage.EN.ToString().ToLower();
        //                    }
        //                    SMSModel.NoOfSMS = startingCampaign.ResponseNoOfSMS;

        //                    LazySingleton<SMSTransactionBLL>.Instance.Save(SMSModel);
        //                }
        //                else
        //                {
        //                    B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
        //                }
        //            }
        //        }
        //        else
        //        {
        //            B2BayLogger.Log("Something is missing or wrong.");
        //            B2BayLogger.Log("campaignID " + campaignID);
        //            B2BayLogger.Log("toPhoneNo " + LazySingleton<CommonBLL>.Instance.ConvertContactNo92(phoneNumber));
        //            B2BayLogger.Log("message " + message);
        //        }
        //    }
        //    catch (InvalidPhoneNo ex)
        //    {


        //        // =================================== Add record in SMS Transactions =================================//
        //        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
        //        if (result != null && result.SMS_SendingID > 0)
        //        {
        //            SMSTransactionModel SMSModel = new SMSTransactionModel();
        //            SMSModel.CampaignID = Convert.ToInt32(campaignID);
        //            SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
        //            SMSModel.SendMessage = message;
        //            //SMSModel.ContactNo = phoneNumber;
        //            SMSModel.ContactNo = LazySingleton<CommonBLL>.Instance.ConvertContactNo92(phoneNumber);
        //            SMSModel.SMSSendingID = result.SMS_SendingID;
        //            SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
        //            SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

        //            LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
        //        }


        //        //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
        //        B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_PortalService, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.WriteLogsToFile();
        //    }
        //    catch (Exception ex)
        //    {

        //        string ErroCode = "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message;
        //        B2BayLogger.Log(ErroCode);
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.WriteLogsToFile();
        //    }

        //    B2BayLogger.WriteLogsToFile();
        //    Thread.Sleep(1000);
        //}

        public void SendReplySMSDirectToSMC(string campaignID, SMSCampaignModel smsCampaignModel, string phoneNumber, ResponseModel resultResponseMessage, int? responseID)
        {
            try
            {
                B2BayLogger.Log("Call Method SendSMS");


                Thread.Sleep(2000);
                B2BayLogger.Log("Wait for Send Request");
                //Check the SMS  Phone Number Validataion

                LazySingleton<SMSValidation>.Instance.CheckValidSMS(phoneNumber);


                if (!string.IsNullOrEmpty(campaignID) && !smsCampaignModel.OrganizationID.HasValue && smsCampaignModel.OrganizationID.Value > 0 && !string.IsNullOrEmpty(phoneNumber) && !string.IsNullOrEmpty(resultResponseMessage.ResponseMessage))
                {
                    lock (Locker)
                    {
                        
                        int campID = Convert.ToInt32(campaignID);
                        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(smsCampaignModel.OrganizationID.Value, campID);          // verifty validity of provided orgainzation id and compaign id 
                        if (result != null && result.SMS_SendingID > 0)
                        {

                            // ========================================= Get Valid Campaing Info ======================================= //
                            StartingCampaign startingCampaign = LazySingleton<SMSCampaignBLL>.Instance.GetValidCampaingsInfoByIDs(smsCampaignModel.OrganizationID.Value, campID);
                            // ========================================= Generate and Get SMS ID ======================================= //
                            string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(smsCampaignModel.OrganizationID.Value.ToString(), campaignID, result.SMS_SendingID.ToString());
                            // ========================================= Send Request ======================================= //
                            string convertedNumber = LazySingleton<CommonBLL>.Instance.ConvertContactNo92(phoneNumber);
                            SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.SendRequest(convertedNumber, resultResponseMessage.ResponseMessage, ID, result.ShortCode);
                            // =================================== Add record in SMS Transactions =================================//
                            SMSTransactionModel SMSModel = new SMSTransactionModel();
                            SMSModel.CampaignID = Convert.ToInt32(campaignID);
                            SMSModel.OrganizationID = smsCampaignModel.OrganizationID;
                            SMSModel.SendMessage = resultResponseMessage.ResponseMessage;
                            SMSModel.ContactNo = convertedNumber;
                            SMSModel.OriginalContactNo = phoneNumber;
                            SMSModel.SMSSendingID = result.SMS_SendingID;
                            SMSModel.TelcoID = smsConfigurationModel.TelcoID;
                            SMSModel.IsOnNet = smsConfigurationModel.IsOnNet;
                            SMSModel.DeliveryStatusID = SMSDeliveryStatuses.SendToSMSC.GetHashCode();
                            SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();
                            SMSModel.ResponseID = responseID;

                            //IF message send form Campaign
                            if (startingCampaign.ResponseLanguageMode.HasValue)
                            {
                                if (startingCampaign.ResponseLanguageMode.Value)
                                {
                                    SMSModel.Lang = MessageLanguage.UR.ToString().ToLower();
                                }
                                else
                                {
                                    SMSModel.Lang = MessageLanguage.EN.ToString().ToLower();
                                }

                                SMSModel.NoOfSMS = startingCampaign.ResponseNoOfSMS;
                            }
                            else
                            {
                                //=== IF Message send from ThirdParty response
                                bool isEnCodingOn = false;
                                if (!string.IsNullOrEmpty(resultResponseMessage.IsEnCodingON) && resultResponseMessage.IsEnCodingON.Equals("Y"))
                                {
                                    SMSModel.Lang = MessageLanguage.UR.ToString().ToLower();
                                    isEnCodingOn = true;
                                }
                                else
                                {
                                    SMSModel.Lang = MessageLanguage.EN.ToString().ToLower();

                                }
                                SMSModel.NoOfSMS = LazySingleton<ServerInfoBLL>.Instance.GetTotalNoOfSMS(resultResponseMessage.ResponseMessage, isEnCodingOn);

                            }

                            LazySingleton<SMSTransactionBLL>.Instance.Save(SMSModel);
                        }
                        else
                        {
                            B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
                        }
                    }
                }
                else
                {
                    B2BayLogger.Log("Something is missing or wrong.");
                    B2BayLogger.Log("campaignID " + campaignID);
                    B2BayLogger.Log("toPhoneNo " + LazySingleton<CommonBLL>.Instance.ConvertContactNo92(phoneNumber));
                    B2BayLogger.Log("message " + resultResponseMessage.ResponseMessage);
                }
            }
            catch (InvalidPhoneNo ex)
            {


                // =================================== Add record in SMS Transactions =================================//
                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(smsCampaignModel.OrganizationID.Value, Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                if (result != null && result.SMS_SendingID > 0)
                {
                    SMSTransactionModel SMSModel = new SMSTransactionModel();
                    SMSModel.CampaignID = Convert.ToInt32(campaignID);
                    SMSModel.OrganizationID = smsCampaignModel.OrganizationID.Value;
                    SMSModel.SendMessage = resultResponseMessage.ResponseMessage;
                    //SMSModel.ContactNo = phoneNumber;
                    SMSModel.ContactNo = LazySingleton<CommonBLL>.Instance.ConvertContactNo92(phoneNumber);
                    SMSModel.SMSSendingID = result.SMS_SendingID;
                    SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
                    SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();

                    LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
                }


                //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
                B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_PortalService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }
            catch (Exception ex)
            {

                string ErroCode = "campaignID" + campaignID + "organizationgID" + smsCampaignModel.OrganizationID.Value + "  " + resultResponseMessage.ResponseMessage;
                B2BayLogger.Log(ErroCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }

            B2BayLogger.WriteLogsToFile();
            Thread.Sleep(1000);
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="campaignID"></param>
        /// <param name="organizationgID"></param>
        /// <param name="phoneNumber"></param>
        /// <param name="message"></param>
        /// <param name="responseID"></param>
        //public void SendReplyDataIntoBuffer(string campaignID, string organizationgID, string phoneNumber, string message, int? responseID)
        //{
        //    try
        //    {
        //        B2BayLogger.Log("Call Method SendReplyDataIntoBuffer");


        //        Thread.Sleep(2000);
        //        B2BayLogger.Log("Wait for Send Request");
        //        //Check the SMS  Phone Number Validataion

        //        LazySingleton<SMSValidation>.Instance.CheckValidSMS(LazySingleton<CommonBLL>.Instance.ConvertContactNo92(phoneNumber));


        //        if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID) && !string.IsNullOrEmpty(phoneNumber) && !string.IsNullOrEmpty(message))
        //        {
        //            lock (Locker)
        //            {
        //               int orgID =Convert.ToInt32(organizationgID);
        //               int campID = Convert.ToInt32(campaignID);
        //                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(orgID,campID );          // verifty validity of provided orgainzation id and compaign id 
        //                if (result != null && result.SMS_SendingID > 0)
        //                {

        //                        // ========================================= Get Valid Campaing Info ======================================= //
        //                        StartingCampaign startingCampaign = LazySingleton<SMSCampaignBLL>.Instance.GetValidCampaingsInfoByIDs(orgID, campID);
        //                        // ========================================= Generate and Get SMS ID ======================================= //
        //                        string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(organizationgID, campaignID, result.SMS_SendingID.ToString());
        //                        // ========================================= Send Request ======================================= //
        //                        //// ========================================= SMS Configuration Model======================================= //
        //                        SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.GetSMSConfigurationModel(phoneNumber);
        //                        //// ========================================= SMS Configuration Model ======================================= //

        //                        //// ========================================= Fill SMSQueue Model ======================================= //
        //                        SMSQueueModel smsQueueModel = new SMSQueueModel();
        //                        FillSMSQueueModel(Convert.ToInt32(campaignID), Convert.ToInt32(organizationgID), message, result.SMS_SendingID, smsQueueModel, smsConfigurationModel);
        //                        smsQueueModel.ResponseID = responseID;
        //                        smsQueueModel.Mode = RequestSourceName.WebAPI.GetHashCode();
        //                        smsQueueModel.ShortCode = result.ShortCode;
        //                        if (startingCampaign.ResponseLanguageMode.HasValue && startingCampaign.ResponseLanguageMode.Value)
        //                        {
        //                            smsQueueModel.Lang =MessageLanguage.UR.ToString().ToLower();
        //                        }
        //                        else 
        //                        {
        //                            smsQueueModel.Lang = MessageLanguage.EN.ToString().ToLower();
        //                        }
        //                        smsQueueModel.NoOfSMS = startingCampaign.ResponseNoOfSMS;

        //                        B2BayLogger.Log("Filling SMS Queue Model Complete");

        //                        //// ========================================= Insert Into buffer Containner ======================================= //
        //                        // Save To Que Table
        //                        LazySingleton<SMSQueueBLL>.Instance.Save(smsQueueModel);
        //                        //// ========================================= Insert Into buffer Containner ======================================= //

        //                        B2BayLogger.Log("SMS Queued Successfully");
        //                        B2BayLogger.WriteLogsToFile();
                            

        //                }
        //                else
        //                {
        //                    B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
        //                }
        //            }
        //        }
        //        else
        //        {
        //            B2BayLogger.Log("Something is missing or wrong.");
        //            B2BayLogger.Log("campaignID " + campaignID);
        //            B2BayLogger.Log("toPhoneNo " + phoneNumber);
        //            B2BayLogger.Log("message " + message);
        //        }
        //    }
        //    catch (InvalidPhoneNo ex)
        //    {


        //        // =================================== Add record in SMS Transactions =================================//
        //        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
        //        if (result != null && result.SMS_SendingID > 0)
        //        {
        //            SMSTransactionModel SMSModel = new SMSTransactionModel();
        //            SMSModel.CampaignID = Convert.ToInt32(campaignID);
        //            SMSModel.OrganizationID = Convert.ToInt32(organizationgID);
        //            SMSModel.SendMessage = message;
        //            SMSModel.ContactNo = phoneNumber;
        //            SMSModel.SMSSendingID = result.SMS_SendingID;
        //            SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
        //            SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();
        //            LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
        //        }


        //        //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
        //        B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_PortalService, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.WriteLogsToFile();
        //    }
        //    catch (Exception ex)
        //    {

        //        string ErroCode = "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message;
        //        B2BayLogger.Log(ErroCode);
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.WriteLogsToFile();
        //    }

        //    B2BayLogger.WriteLogsToFile();
        //    Thread.Sleep(1000);
        //}
        public void SendReplyDataIntoBuffer(string campaignID, SMSCampaignModel smsCampaignModel, string phoneNumber, ResponseModel resultResponseMessage, int? responseID)
        {
            try
            {
                B2BayLogger.Log("Call Method SendReplyDataIntoBuffer");


                Thread.Sleep(2000);
                B2BayLogger.Log("Wait for Send Request");
                //Check the SMS  Phone Number Validataion

                LazySingleton<SMSValidation>.Instance.CheckValidSMS(LazySingleton<CommonBLL>.Instance.ConvertContactNo92(phoneNumber));


                if (!string.IsNullOrEmpty(campaignID) && smsCampaignModel.OrganizationID.HasValue && smsCampaignModel.OrganizationID.Value > 0 && !string.IsNullOrEmpty(phoneNumber) && !string.IsNullOrEmpty(resultResponseMessage.ResponseMessage))
                {
                    lock (Locker)
                    {
                       
                        int campID = Convert.ToInt32(campaignID);
                        VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(smsCampaignModel.OrganizationID.Value, campID);          // verifty validity of provided orgainzation id and compaign id 
                        if (result != null && result.SMS_SendingID > 0)
                        {

                            // ========================================= Get Valid Campaing Info ======================================= //
                            StartingCampaign startingCampaign = LazySingleton<SMSCampaignBLL>.Instance.GetValidCampaingsInfoByIDs(smsCampaignModel.OrganizationID.Value, campID);
                            // ========================================= Generate and Get SMS ID ======================================= //
                            string ID = LazySingleton<RequestService>.Instance.GetSMSSendingID(smsCampaignModel.OrganizationID.Value.ToString(), campaignID, result.SMS_SendingID.ToString());
                            // ========================================= Send Request ======================================= //
                            //// ========================================= SMS Configuration Model======================================= //
                            SMSConfigurationModel smsConfigurationModel = LazySingleton<RequestService>.Instance.GetSMSConfigurationModel(phoneNumber);
                            //// ========================================= SMS Configuration Model ======================================= //

                            //// ========================================= Fill SMSQueue Model ======================================= //
                            SMSQueueModel smsQueueModel = new SMSQueueModel();
                            FillSMSQueueModel(Convert.ToInt32(campaignID), smsCampaignModel.OrganizationID.Value, resultResponseMessage.ResponseMessage, result.SMS_SendingID, smsQueueModel, smsConfigurationModel);
                            smsQueueModel.ResponseID = responseID;
                            smsQueueModel.Mode = RequestSourceName.WebAPI.GetHashCode();
                            smsQueueModel.ShortCode = result.ShortCode;

                            //IF message send form Campaign
                            if (smsCampaignModel.ResponseLanguageMode.HasValue)
                            {
                                if (smsCampaignModel.ResponseLanguageMode.Value)
                                {
                                    smsQueueModel.Lang = MessageLanguage.UR.ToString().ToLower();
                                }
                                else
                                {
                                    smsQueueModel.Lang = MessageLanguage.EN.ToString().ToLower();
                                }

                                smsQueueModel.NoOfSMS = startingCampaign.ResponseNoOfSMS;
                            }
                            else
                            {
                                //=== IF Message send from ThirdParty response
                                bool isEnCodingOn= false ;
                                if (!string.IsNullOrEmpty(resultResponseMessage.IsEnCodingON) && resultResponseMessage.IsEnCodingON.ToLower().Equals("y"))
                                {
                                    smsQueueModel.Lang = MessageLanguage.UR.ToString().ToLower();
                                    isEnCodingOn =true;
                                }
                                else
                                {
                                    smsQueueModel.Lang = MessageLanguage.EN.ToString().ToLower();
                                    
                                }
                                smsQueueModel.NoOfSMS = LazySingleton<ServerInfoBLL>.Instance.GetTotalNoOfSMS(resultResponseMessage.ResponseMessage, isEnCodingOn);

                            }

                            B2BayLogger.Log("EndCodeing is " + resultResponseMessage.IsEnCodingON);
                            B2BayLogger.Log("Language is " + smsQueueModel.Lang);
                            B2BayLogger.Log("No Of SMS " + smsQueueModel.NoOfSMS);

                            B2BayLogger.Log("Filling SMS Queue Model Complete");

                            //// ========================================= Insert Into buffer Containner ======================================= //
                            // Save To Que Table
                            LazySingleton<SMSQueueBLL>.Instance.Save(smsQueueModel);
                            //// ========================================= Insert Into buffer Containner ======================================= //

                            B2BayLogger.Log("SMS Queued Successfully");
                            B2BayLogger.WriteLogsToFile();


                        }
                        else
                        {
                            B2BayLogger.Log("Not Validate:Campaign is expired or remaing sms sending is zeror ");
                        }
                    }
                }
                else
                {
                    B2BayLogger.Log("Something is missing or wrong.");
                    B2BayLogger.Log("campaignID " + campaignID);
                    B2BayLogger.Log("toPhoneNo " + phoneNumber);
                    B2BayLogger.Log("message " + resultResponseMessage.ResponseMessage);
                }
            }
            catch (InvalidPhoneNo ex)
            {


                // =================================== Add record in SMS Transactions =================================//
                VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(smsCampaignModel.OrganizationID.Value, Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                if (result != null && result.SMS_SendingID > 0)
                {
                    SMSTransactionModel SMSModel = new SMSTransactionModel();
                    SMSModel.CampaignID = Convert.ToInt32(campaignID);
                    SMSModel.OrganizationID = smsCampaignModel.OrganizationID.Value;
                    SMSModel.SendMessage = resultResponseMessage.ResponseMessage;
                    SMSModel.ContactNo = phoneNumber;
                    SMSModel.SMSSendingID = result.SMS_SendingID;
                    SMSModel.DeliveryStatusID = SMSDeliveryStatuses.InValidPhoneNumber.GetHashCode();
                    SMSModel.Mode = RequestSourceName.WebAPI.GetHashCode();
                    LazySingleton<SMSTransactionBLL>.Instance.AddInvalidSMSTransaction(SMSModel);
                }


                //string ErroCode = "Phone Nunmber" + message.PhoneNo + "campaignID" + campaignID + "organizationgID" + organizationgID + "  " + message.SMSMessage;
                B2BayLogger.Log("ErrorCode " + ex.ErrorCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ex.ErrorCode, 1, PageNames.SMS_PortalService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }
            catch (Exception ex)
            {

                string ErroCode = "campaignID" + campaignID + "organizationgID" + smsCampaignModel.OrganizationID.Value + "  " + resultResponseMessage.ResponseMessage;
                B2BayLogger.Log(ErroCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }

            B2BayLogger.WriteLogsToFile();
            Thread.Sleep(1000);
        }

        public void Dispose()
        {
            // Dispose of unmanaged resources.
            this.Dispose();
            // Suppress finalization.
            GC.SuppressFinalize(this);

        }
    }
}