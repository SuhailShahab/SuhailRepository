﻿using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.APIClasses;
using SMS.CMP.BLL.CMP;
using SMS.CMPService.SendRequest;
using SMS.PortalService.ApplicationClassess;
using SMS.PortalService.ApplicationClassess.Log;
using SMS.PortalService.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS.PortalService.SendRequest
{
    public class ResponseCampaignRequest:IDisposable
    {

        public string CampaingKeyWord { get; set; }
        public string ReplyPhoneNo { get; set; }
        public string ReplyMessage { get; set; }
        public string ShortCode { get; set; }
        public int? CampaignID { get; set; }
        public string OriginalNumber { get; set; }

        public ResponseCampaignRequest(string replyKeyworld, string replyPhone, string originalNumber, string replyMessage, string shortCode, int campaignID)
        {
            this.CampaingKeyWord = replyKeyworld;
            this.ReplyPhoneNo = replyPhone;
            this.OriginalNumber = originalNumber;
            this.ReplyMessage = replyMessage;
            this.ShortCode = shortCode;
            this.CampaignID = campaignID;
            this.UpdateReponse();
        }
        private  void UpdateReponse()
        {
            string rsultMesage = string.Empty;
            try
            {
                //Set Response Model
                // int campaingId = Convert.ToInt32(campaignID);
                CustomerResponseModel customermodel = new CustomerResponseModel(this.CampaingKeyWord, this.ReplyPhoneNo, this.ReplyMessage, this.ShortCode, this.CampaignID.Value);
                customermodel.OriginalContactNo = this.OriginalNumber;
                B2BayLogger.Log("Add User Response");

                //Add Citizen Response in database
                //int? resultID = BLL.Common.LazySingletonBLL<CustomerResponseBLL>.Instance.AddCustomerResponse(customermodel);
                int? resultID = BLL.Common.LazyMultiton<CustomerResponseBLL>.Instance().AddCustomerResponse(customermodel);
                B2BayLogger.Log("Add Citizen message in database with ID =" + resultID);
                B2BayLogger.WriteLogsToFile();
                B2BayLogger.Log("Send Reponse to Third Party");
               
                //Set Reponse to Third Party.
                //Get Service Url and Method Name from campaign
                //SMSCampaignModel smsCampaignModel = BLL.Common.LazySingletonBLL<SMSCampaignBLL>.Instance.GetServiceResponseInfo(this.CampaignID.Value);
                SMSCampaignModel smsCampaignModel = BLL.Common.LazyMultiton<SMSCampaignBLL>.Instance().GetServiceResponseInfo(this.CampaignID.Value);
                ThirdParyResponseModel resultResponseMessage = null;

                //Send Check Reply message send  to Thirdparty app or service and customer
                if (smsCampaignModel != null && !string.IsNullOrEmpty(smsCampaignModel.MethodName) && !string.IsNullOrEmpty(smsCampaignModel.ServiceUrl))
                {
                    //Assign the Customer service value to send customer reposne to thirdParty
                    customermodel.ServiceUrl = smsCampaignModel.ServiceUrl;
                    B2BayLogger.Log("Service Url:" + smsCampaignModel.ServiceUrl);
                    B2BayLogger.Log("MethodName:" + smsCampaignModel.MethodName);
                    customermodel.MethodName = smsCampaignModel.MethodName;

                    //Split the Short Code to get the Sending message code
                    if (!string.IsNullOrEmpty(this.ShortCode))
                    {
                        string[] arryShotCode = this.ShortCode.Split('-');
                        if (arryShotCode.Length > 1)
                        {
                            customermodel.ShortCode = arryShotCode[1];
                        }
                        else
                        {
                            customermodel.ShortCode = arryShotCode[0];
                        }

                    }


                    B2BayLogger.WriteLogsToFile();
                    B2BayLogger.Log("resultMessage");

                    //Call the ThirdPaty Application/Service to send custormer response
                     customermodel.RecordID = resultID.HasValue ? resultID.Value : 0;
                     customermodel.ID = customermodel.RecordID;
                     B2BayLogger.Log("Save Record ID " + customermodel.RecordID);
                    B2BayLogger.Log("Send message to Pirth party");
                    //resultResponseMessage = LazySingleton<RequestService>.Instance.SendResponseToClient(customermodel);
                    resultResponseMessage = LazyMultiton<RequestService>.Instance().SendResponseToClient(customermodel);
                    //resultResponseMessage = LazySingleton<RequestService>.Instance.TestToClient(customermodel);


                    //If Reposne message is not set from ThirdParty then send the replay message enter in the campaign
                    rsultMesage = resultResponseMessage != null && !string.IsNullOrEmpty(resultResponseMessage.Response.ResponseMessage) ? resultResponseMessage.Response.ResponseMessage : smsCampaignModel.ResponseMessage;
                    //If Third Party Response Message is not null then Response language Mod is NUll.It mean we have to count the no of message form method
                    if (!string.IsNullOrEmpty(resultResponseMessage.Response.ResponseMessage))
                    {
                        smsCampaignModel.ResponseLanguageMode = null;
                    }


                    if (resultResponseMessage != null && !string.IsNullOrEmpty(resultResponseMessage.Response.ConfirmationCode))
                    {
                        B2BayLogger.Log("Verify the confirmation code to update the record" + resultResponseMessage.Response.ConfirmationCode);
                        B2BayLogger.Log("ThirdPary Data1" + resultResponseMessage.Result);
                        ///Update the Customer response table with confirmation code                   
                       // CustomerResponseModel confrimationModel = new CustomerResponseModel(resultResponseMessage.Response.ConfirmationCode, customermodel.ID);
                        CustomerResponseModel confrimationModel = new CustomerResponseModel(resultResponseMessage.Response.ConfirmationCode, null, customermodel.RecordID, this.CampaignID, this.ReplyPhoneNo);
                        confrimationModel.ThirtParyResult = resultResponseMessage.Result;
                       // int? updateResult = BLL.Common.LazySingletonBLL<CustomerResponseBLL>.Instance.UpdateSMSConfirmationInfo(confrimationModel);
                       // int? updateResult = BLL.Common.LazySingletonBLL<CustomerResponseBLL>.Instance.AddCustomerConfirmation(confrimationModel);
                        int? updateResult = BLL.Common.LazyMultiton<CustomerResponseBLL>.Instance().AddCustomerConfirmation(confrimationModel);
                        B2BayLogger.Log("ThirdPary Data2" + resultResponseMessage.Result);
                       

                    }


                    B2BayLogger.Log("Static ResponseMessage:" + smsCampaignModel.ResponseMessage);
                    B2BayLogger.Log("rsultMesage:" + rsultMesage);
                    B2BayLogger.Log("Send Reponse Successfully");

                }//End of Send SMS to Client

                //Send Reply messge to customer
               
                if (smsCampaignModel != null && resultResponseMessage != null && resultResponseMessage.Response != null && !string.IsNullOrEmpty(rsultMesage))
                {
                    B2BayLogger.Log("Message Send Reply Message to Citizen form Third Party (IsSend)= " + resultResponseMessage.Response.IsSend);
                    B2BayLogger.Log("Send Reply to Customer");
                    if (!string.IsNullOrEmpty(resultResponseMessage.Response.IsSend) && resultResponseMessage.Response.IsSend.ToLower().Equals("y"))
                    {
                        if (ConfigurationHelper.IsBufferedForReply)
                        {
                            resultResponseMessage.Response.ResponseMessage = rsultMesage;
                            //In case of buffered
                            // LazySingleton<BulkSendSMSRequest>.Instance.SendReplyDataIntoBuffer(Convert.ToString(campaingId), Convert.ToString(smsCampaignModel.OrganizationID), originalNumber, rsultMesage, resultID);
                           // LazySingleton<BulkSendSMSRequest>.Instance.SendReplyDataIntoBuffer(this.CampaignID.Value.ToString(), smsCampaignModel, this.OriginalNumber, resultResponseMessage.Response, resultID);
                           LazyMultiton<BulkSendSMSRequest>.Instance().SendReplyDataIntoBuffer(this.CampaignID.Value.ToString(), smsCampaignModel, this.OriginalNumber, resultResponseMessage.Response, resultID);
          
                        }
                        else
                        {
                            //Without  buffered
                            //LazySingleton<BulkSendSMSRequest>.Instance.SendReplySMSDirectToSMC(this.CampaignID.Value.ToString(), smsCampaignModel, this.OriginalNumber, resultResponseMessage.Response, resultID);
                          LazyMultiton<BulkSendSMSRequest>.Instance().SendReplySMSDirectToSMC(this.CampaignID.Value.ToString(), smsCampaignModel, this.OriginalNumber, resultResponseMessage.Response, resultID);
     
                        }

                    }


                }
                else
                {
                    B2BayLogger.Log("Not Send Reply to Customer");
                }
                
            }
            catch(Exception ex)
            {
               
                throw ex;
            }
            finally
            {
                this.Dispose();
            }
           

            B2BayLogger.WriteLogsToFile();
        }
        public void Dispose()
        {
            // Dispose of unmanaged resources.
          //  this.Dispose();
            // Suppress finalization.
          //  GC.SuppressFinalize(this);

        }
    }
}