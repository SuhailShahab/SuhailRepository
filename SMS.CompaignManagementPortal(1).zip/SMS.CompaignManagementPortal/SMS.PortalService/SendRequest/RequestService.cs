﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Common;
using SMS.CMP.BLL.CMP;
//using SMS.CMPService.ApplicationClassess;
//using SMS.CMPService.ApplicationClassess.Log;
using SMS.PortalService.ApplicationClassess;
using SMS.PortalService.ApplicationClassess.Log;
using SMS.PortalService.DataModel;
using System;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <19-10-2015 09:43:16AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPService.SendRequest
{
    public class RequestService
    {
        public SMSConfigurationModel GetSMSConfigurationModel(string sendToPhoneNo)
        {
           string networkTypeCode = string.Empty;
           string originalContactNo = string.Empty;

            try
            {
                originalContactNo = sendToPhoneNo;
                 sendToPhoneNo= LazySingleton<CommonBLL>.Instance.ConvertContactNo92(sendToPhoneNo);

                if (sendToPhoneNo.Length == 11)
                {
                    networkTypeCode = sendToPhoneNo.Substring(0, 3);

                }
                else
                {
                    networkTypeCode = sendToPhoneNo.Substring(2, 2);
                    networkTypeCode = "0" + networkTypeCode;
                }

                // Fill SMSConfigurationModel Mode
                SMSConfigurationModel smsConfigurationModel = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetNetworkProvider(networkTypeCode);
                smsConfigurationModel.SendPhoneNo = sendToPhoneNo;
                smsConfigurationModel.OriginalContactNo = originalContactNo;

                smsConfigurationModel.IsOnNet = smsConfigurationModel.SourceNetworksID.Equals(networkTypeCode) ? true : false;            //Verify the On Net and Off Net
                // write to log file
                B2BayLogger.Log("GetSMSConfigurationModel - Complete");
                B2BayLogger.WriteLogsToFile();

                return smsConfigurationModel;
            }
            catch (Exception ex)
            {
                B2BayLogger.Log("There is Some Error:" + ex.Message);
                B2BayLogger.WriteLogsToFile();
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + networkTypeCode, 1, PageNames.SMS_CMPService, 0));
                throw ex;
            }

            return null;
        }

        public SMSConfigurationModel SendRequest(string sendToPhoneNo, string message, string smsSendingID, string shortCode)
        {
            bool? result = null;
            string ServiceURL = string.Empty;

            try
            {
                string networkTypeCode = string.Empty;
                if (sendToPhoneNo.Length == 11)
                {
                    networkTypeCode = sendToPhoneNo.Substring(0, 3);

                }
                else
                {
                    networkTypeCode = sendToPhoneNo.Substring(2, 2);
                    networkTypeCode = "0" + networkTypeCode;
                }
                // =================================== Identify network provide =================================//
                SMSConfigurationModel smsCampaignModel = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetNetworkProvider(networkTypeCode);
                smsCampaignModel.SendPhoneNo = sendToPhoneNo;
                smsCampaignModel.IsOnNet = smsCampaignModel.SourceNetworksID.Equals(networkTypeCode) ? true : false;        // Verify the On net and Off Net
                message = CommonMethod.ReplaceSpecilChar(message);

                smsSendingID = smsSendingID + "-" + smsCampaignModel.TelcoID + "-" + Convert.ToInt32(smsCampaignModel.IsOnNet);

                ServiceURL = this.GetUrl(smsCampaignModel, message, smsSendingID, shortCode);

                B2BayLogger.Log(ServiceURL);
                result = SendSmsToClient(ServiceURL);

                B2BayLogger.Log("Send Request successfully.");
                B2BayLogger.WriteLogsToFile();

                return smsCampaignModel;
            }
            catch (Exception ex)
            {
                B2BayLogger.Log("There is Some Error:"+ex.Message);
                B2BayLogger.WriteLogsToFile();
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ServiceURL, 1, PageNames.SMS_CMPService, 0));
                throw ex;
            }

            return null;
        }
        public SMSConfigurationModel SendRequest(string sendToPhoneNo, string message, string smsSendingID, string shortCode,string lang)
        {
            bool? result = null;
            string ServiceURL = string.Empty;

            try
            {
                string networkTypeCode = string.Empty;
                if (sendToPhoneNo.Length == 11)
                {
                    networkTypeCode = sendToPhoneNo.Substring(0, 3);

                }
                else
                {
                    networkTypeCode = sendToPhoneNo.Substring(2, 2);
                    networkTypeCode = "0" + networkTypeCode;
                }
                // =================================== Identify network provide =================================//
                SMSConfigurationModel smsCampaignModel = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetNetworkProvider(networkTypeCode);
                smsCampaignModel.SendPhoneNo = sendToPhoneNo;
                smsCampaignModel.IsOnNet = smsCampaignModel.SourceNetworksID.Equals(networkTypeCode) ? true : false;        // Verify the On net and Off Net
                message = CommonMethod.ReplaceSpecilChar(message);

                smsSendingID = smsSendingID + "-" + smsCampaignModel.TelcoID + "-" + Convert.ToInt32(smsCampaignModel.IsOnNet);

                ServiceURL = this.GetUrl(smsCampaignModel, message, smsSendingID, shortCode, lang);

                B2BayLogger.Log(ServiceURL);
                result = SendSmsToClient(ServiceURL);

                B2BayLogger.Log("Send Request successfully.");
                B2BayLogger.WriteLogsToFile();

                return smsCampaignModel;
            }
            catch (Exception ex)
            {
                B2BayLogger.Log("There is Some Error:" + ex.Message);
                B2BayLogger.WriteLogsToFile();
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(null, ex.Message + " " + ServiceURL, 1, PageNames.SMS_CMPService, 0));
                throw ex;
            }

            return null;
        }

        public ThirdParyResponseModel SendResponseToClient(CustomerResponseModel customerResponseModel)
        {
            ThirdParyResponseModel result = null;
            try
            {
                result = this.SendReponseToThirdPary(customerResponseModel);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        public ThirdParyResponseModel TestToClient(CustomerResponseModel customerResponseModel)
        {
            B2BayLogger.Log("Call Method SendReponseToThirdPary");

            string result = "reuslt";
            ThirdParyResponseModel thirdParyResponse = new ThirdParyResponseModel();

            ResponseModel responseModel = new ResponseModel();
            responseModel.ReplyMessage = customerResponseModel.ReplyMessage;
            responseModel.ReplyPhoneNumber = customerResponseModel.ReplyPhoneNo;
            responseModel.ResponseDate = DateTime.Now.ToString(); //"22-11-2015 13:10:40";
            responseModel.ShortCode = customerResponseModel.ShortCode;
            responseModel.ID = Convert.ToString(customerResponseModel.ID);
            
            responseModel.ResponseMessage  = "test Message";
            responseModel.ConfirmationCode = "confir";
            B2BayLogger.WriteLogsToFile();


            thirdParyResponse.Response = responseModel;
            thirdParyResponse.Result = result;
            return thirdParyResponse;
        }
        //public ResponseModel SendResponseToClient(CustomerResponseModel customerResponseModel)
        //{
        //    ResponseModel result = null ;
        //    try
        //    {
        //       result= this.SendReponseToThirdPary(customerResponseModel);
        //    }
        //    catch(Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return result;
        //}

        public bool SendSmsToClient(string HostURI)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(HostURI);
            request.Method = "GET";
            String test = String.Empty;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                test = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();

                return true;
            }
        }
        private ThirdParyResponseModel SendReponseToThirdPary(CustomerResponseModel customerResponseModel)
        {
            B2BayLogger.Log("Call Method SendReponseToThirdPary");

            string result = string.Empty;
            ThirdParyResponseModel thirdParyResponse = new ThirdParyResponseModel();

            ResponseModel responseModel = new ResponseModel();
            responseModel.ReplyMessage = customerResponseModel.ReplyMessage;
            responseModel.ReplyPhoneNumber = customerResponseModel.ReplyPhoneNo;
            responseModel.ResponseDate = DateTime.Now.ToString(); //"22-11-2015 13:10:40";
            responseModel.ShortCode = customerResponseModel.ShortCode;
            responseModel.ID = Convert.ToString(customerResponseModel.ID);
            B2BayLogger.WriteLogsToFile();

            string strDataMoedel = "";
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(ResponseModel));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, responseModel);
                strDataMoedel = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                //WebOperationContext.Current.OutgoingResponse.Headers.Add("data", Data);
            }
            catch (Exception ex)
            {
                throw new Exception("Data contract serializer exception : " + ex.Message);
            }


            // process the request and get response as string
            string ServiceURL = customerResponseModel.ServiceUrl;

            WebClient webClient = new WebClient();

            try
            {
                webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;
                webClient.Headers["datatype"] = "json";
            }
            catch (Exception ex)
            {
                throw new Exception("Web client exception : " + ex.Message);
            }


            try
            {

                Uri address = new Uri(ServiceURL + "/" + customerResponseModel.MethodName);
                result = webClient.UploadString(address, "POST", strDataMoedel);
            }
            catch (Exception ex)
            {

                throw new Exception("Service connectivity exception : " + ex.Message);
            }

            ResponseModel resultModel = null;
            try
            {

                resultModel = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ResponseModel>(result);
            }
            catch (Exception ex)
            {
                B2BayLogger.Log("Respone Form ThirdParty" + result+""+ex.Message);
                throw new Exception("Invalid respone Form ThirdParty : " + ex.Message);
            }
            thirdParyResponse.Response = resultModel;
            thirdParyResponse.Result = result;
            return thirdParyResponse;
        }
        //private ResponseModel SendReponseToThirdPary(CustomerResponseModel customerResponseModel)
        //{
        //    B2BayLogger.Log("Call Method SendReponseToThirdPary");

        //     string result = string.Empty;
        //    ResponseModel responseModel = new ResponseModel();
        //    responseModel.ReplyMessage = customerResponseModel.ReplyMessage;
        //    responseModel.ReplyPhoneNumber = customerResponseModel.ReplyPhoneNo;
        //    responseModel.ResponseDate = DateTime.Now.ToString(); //"22-11-2015 13:10:40";
        //    responseModel.ShortCode = customerResponseModel.ShortCode;
        //    responseModel.ID = Convert.ToString(customerResponseModel.ID);
        //    B2BayLogger.WriteLogsToFile();

        //    string strDataMoedel = "";
        //    try
        //    {
        //        DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(ResponseModel));
        //        MemoryStream mem = new MemoryStream();
        //        ser.WriteObject(mem, responseModel);
        //        strDataMoedel = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

        //        //WebOperationContext.Current.OutgoingResponse.Headers.Add("data", Data);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Data contract serializer exception : " + ex.Message);
        //    }


        //    // process the request and get response as string
        //    string ServiceURL = customerResponseModel.ServiceUrl;

        //    WebClient webClient = new WebClient();

        //    try
        //    {
        //        webClient.Headers["Content-type"] = "application/json";
        //        webClient.Encoding = Encoding.UTF8;
        //        webClient.Headers["datatype"] = "json";
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Web client exception : " + ex.Message);
        //    }


        //    try
        //    {               

        //        Uri address = new Uri(ServiceURL + "/" + customerResponseModel.MethodName);
        //        result = webClient.UploadString(address, "POST", strDataMoedel);
        //    }
        //    catch (Exception ex)
        //    {

        //        throw new Exception("Service connectivity exception : " + ex.Message);
        //    }
          
        //    ResponseModel resultModel = null;
        //    try
        //    {
                
        //        resultModel = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ResponseModel>(result);
        //    }
        //    catch (Exception ex)
        //    {
        //        B2BayLogger.Log("Respone Form ThirdParty" + result);
        //        throw new Exception("Invalid respone Form ThirdParty : " + ex.Message);
        //    }
           
        //    return resultModel;
        //}

        public string GetSMSSendingID(string organizationID, string compainID, string smsMaxID)
        {
            StringBuilder smsID = new StringBuilder();

            smsID.Append(organizationID);
            smsID.Append("-");
            smsID.Append(compainID);
            smsID.Append("-");
            smsID.Append(smsMaxID);

            return smsID.ToString();
        }

        #region Network Provider Url information

        public string GetUrl(string sendToPhoneNo, string message, string smsSendingID, string shortCode)
        {
            string networkTypeCode = sendToPhoneNo.Substring(0, 3);
            SMSConfigurationModel smsCampaignModel = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetNetworkProvider(networkTypeCode);
            StringBuilder sbUrl = new StringBuilder();
            sbUrl.Append("http://");
            sbUrl.Append(smsCampaignModel.SMSGateway);
            sbUrl.Append("/cgi-bin/sendsms?&");
            sbUrl.Append("username=");
            sbUrl.Append(smsCampaignModel.UserName);
            sbUrl.Append("&password=");
            sbUrl.Append(smsCampaignModel.Password);
            sbUrl.Append("&to=");
            sbUrl.Append(sendToPhoneNo);
            sbUrl.Append("&from=");
            sbUrl.Append(shortCode);
            sbUrl.Append("&text=");
            sbUrl.Append(message);
            sbUrl.Append("&dlr-mask=31&dlr-url=http://");
            sbUrl.Append(ConfigurationHelper.HostingIP);
            sbUrl.Append("/PortalService.svc");
            sbUrl.Append("/SMSDeliveryResponse");
            //sbUrl.Append("/Test/");
            sbUrl.Append("/%p");
            sbUrl.Append("/");
            sbUrl.Append(smsSendingID);
            sbUrl.Append("/%d");
            sbUrl.Append("/%i");

            return sbUrl.ToString();
        }

        public string GetUrl(SMSConfigurationModel smsCampaignModel, string message, string smsSendingID, string shortCode)
        {
            StringBuilder sbUrl = new StringBuilder();

            


            sbUrl.Append("http://");
            sbUrl.Append(smsCampaignModel.SMSGateway);
            sbUrl.Append("/cgi-bin/sendsms?&");
            sbUrl.Append("username=");
            sbUrl.Append(smsCampaignModel.UserName);
            sbUrl.Append("&password=");
            sbUrl.Append(smsCampaignModel.Password);
            sbUrl.Append("&to=");
            sbUrl.Append(smsCampaignModel.SendPhoneNo);
            sbUrl.Append("&from=");
            sbUrl.Append(shortCode);
            sbUrl.Append("&charset=UTF-8&coding=2");
            sbUrl.Append("&text=");
            sbUrl.Append(message);
            sbUrl.Append("&dlr-mask=31&dlr-url=http://");
            sbUrl.Append(ConfigurationHelper.HostingIP);
            sbUrl.Append("/PortalService.svc");
            sbUrl.Append("/SMSDeliveryResponse");
            //sbUrl.Append("/Test/");
            sbUrl.Append("/%p");
            sbUrl.Append("/");
            sbUrl.Append(smsSendingID);
            sbUrl.Append("/%d");
            sbUrl.Append("/%i");

            return sbUrl.ToString();
        }
        public string GetUrl(SMSConfigurationModel smsCampaignModel, string message, string smsSendingID, string shortCode,string lang)
        {
            StringBuilder sbUrl = new StringBuilder();




            sbUrl.Append("http://");
            sbUrl.Append(smsCampaignModel.SMSGateway);
            sbUrl.Append("/cgi-bin/sendsms?&");
            sbUrl.Append("username=");
            sbUrl.Append(smsCampaignModel.UserName);
            sbUrl.Append("&password=");
            sbUrl.Append(smsCampaignModel.Password);
            sbUrl.Append("&to=");
            sbUrl.Append(smsCampaignModel.SendPhoneNo);
            sbUrl.Append("&from=");
            sbUrl.Append(shortCode);
            if(string.IsNullOrEmpty(lang)&& lang.ToLower().Equals("en"))
            {

            }
            else
            {
                sbUrl.Append("&charset=UTF-8&coding=2");
            }
            
            sbUrl.Append("&text=");
            sbUrl.Append(message);
            sbUrl.Append("&dlr-mask=31&dlr-url=http://");
            sbUrl.Append(ConfigurationHelper.HostingIP);
            sbUrl.Append("/PortalService.svc");
            sbUrl.Append("/SMSDeliveryResponse");
            //sbUrl.Append("/Test/");
            sbUrl.Append("/%p");
            sbUrl.Append("/");
            sbUrl.Append(smsSendingID);
            sbUrl.Append("/%d");
            sbUrl.Append("/%i");

            return sbUrl.ToString();
        }

        #endregion
    }


    //[System.Runtime.Serialization.DataContract]
    //public class ResponseModel
    //{
    //    [System.Runtime.Serialization.DataMember]
    //    public string ReplyMessage { get; set; }
    //    [System.Runtime.Serialization.DataMember]
    //    public string ReplyPhoneNumber { get; set; }
    //    [System.Runtime.Serialization.DataMember]
    //    public string ResponseDate { get; set; }
    //    [System.Runtime.Serialization.DataMember]
    //    public string ShortCode { get; set; }
    //    [System.Runtime.Serialization.DataMember]
    //    public string ConfirmationCode { get; set; }
    //    [System.Runtime.Serialization.DataMember]
    //    public string ResponseMessage { get; set; }
    //    [System.Runtime.Serialization.DataMember]
    //    public string ID { get; set; }
    //}
    [System.Runtime.Serialization.DataContract]
    public class ResultModel
    {
       [System.Runtime.Serialization.DataMember]
        public string status { get; set; }
        
    }
}