﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS.PortalService.DataModel
{
    public class ThirdParyResponseModel
    {
        public ResponseModel Response { get; set; }
        public string Result { get; set; }
    }
}