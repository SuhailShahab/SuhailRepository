﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Common;
using SMS.CMP.BLL.APIClasses;
using SMS.CMP.BLL.CMP;
using SMS.CMPService.SendRequest;
using SMS.PortalService.ApplicationClassess;
using SMS.PortalService.ApplicationClassess.Log;
using SMS.PortalService.DataModel;
using SMS.PortalService.SendRequest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Web;
using System.Threading;
using System.Threading.Tasks;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <27-10-2015 03:43:16PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.PortalService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "PortalService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select PortalService.svc or PortalService.svc.cs at the Solution Explorer and start debugging.
    public class PortalService : IPortalService
    {
        object lockerMain = new object();
        object lockerResponseReq = new object();

        public void SendSMSFromPortal(string campaignID, string organizationgID)
        {
            try
            {
                B2BayLogger.Log("Call Method SendSMS");

                if (!string.IsNullOrEmpty(campaignID) && !string.IsNullOrEmpty(organizationgID))
                {
                    VerificationResult result = LazySingleton<SMSTransactionBLL>.Instance.VerifiedUser(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));          // verifty validity of provided orgainzation id and compaign id 
                    if (result != null && result.SMS_SendingID > 0)
                    {
                        B2BayLogger.Log("Validate campaign ");

                        B2BayLogger.Log("Get Campaing Infor sp Name: spGetCampaignInfoByIDs ");
                        StartingCampaign startingCampaign = LazySingleton<SMSCampaignBLL>.Instance.GetCampaingsInfoByIDs(Convert.ToInt32(organizationgID), Convert.ToInt32(campaignID));
                        BulkSendSMSRequest singleRequest = new BulkSendSMSRequest(Convert.ToInt32(campaignID), Convert.ToInt32(organizationgID));
                        singleRequest.VersoinNo = result.VersionNo;
                        //singleRequest.SendBulkSMS();
                        B2BayLogger.Log("Call SendBulkSMS");                      

                        singleRequest.Message = startingCampaign.SMSMessage;
                        singleRequest.VersoinNo = startingCampaign.VersionNo;
                        singleRequest.NoOfSMS = startingCampaign.NoOfSMS;
                        B2BayLogger.Log("Message " + startingCampaign.SMSMessage + "ShortCode " + startingCampaign.ShortCode + "organizationID " + organizationgID + "capaignID " + campaignID);

                        B2BayLogger.Log("Call SendBulkSMS");
                        if (ConfigurationHelper.IsBuffered)
                        {
                            //With Buffered 
                            singleRequest.SendDataIntoBuffer(startingCampaign.Lang);
                        }
                        else
                        {
                            //Direct to SMSC
                            singleRequest.SendBulkSMS(startingCampaign.Lang);
                        }

                        B2BayLogger.Log("Send Request using method SendBulkSMS");
                        singleRequest = null;
                    }
                    else
                    {
                        B2BayLogger.Log("No Campaign Found against Orgainzatio and Campaing " + organizationgID + ":" + campaignID);
                    }
                }
            }
            catch (Exception ex)
            {
                string ErroCode = "SendSMSFromPortal :campaignID" + campaignID + "organizationgID" + organizationgID;
                B2BayLogger.Log(ErroCode);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, ex.Message + " " + ErroCode, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.WriteLogsToFile();
            }

            B2BayLogger.WriteLogsToFile();
        }

        /// <summary>
        /// Updte the reponse of Sending SMs
        /// smsid split in different parameter
        /// 0= Oragnization ID,1=Campaign ID,SMS Sending ID= 2,  Telco ID = 3, Is On Net =4
        /// </summary>
        /// <param name="to"></param>
        /// <param name="smsid"></param>
        /// <param name="type"></param>
        /// <param name="network"></param>
        public void SMSDeliveryResponse(string to, string smsid, string type, string network)
        {
            string message = string.Empty;

            try
            {
                message = to + " " + smsid + type + network;

                // ============================================= Entry to log file ============================================== //
                B2BayLogger.Log(message);
                B2BayLogger.Log("Update Respnse");
                B2BayLogger.Log("To :" + to + " smsid:" + smsid + " type:" + type);

                if (!string.IsNullOrEmpty(smsid))
                {
                    string[] ids = smsid.Split('-');
                    B2BayLogger.Log("TelcoID" + ids[3] + "Is On Net " + ids[4]);

                    LazySingletonBLL<SMSTransactionBLL>.Instance.UpdateSMSDeliveryStatus(new SMSTransactionModel()
                    {
                        OrganizationID = Convert.ToInt32(ids[0]),
                        CampaignID = Convert.ToInt32(ids[1]),
                        SMSSendingID = Convert.ToInt32(ids[2]),
                        DeliveryStatusID = Convert.ToInt32(type),
                        ContactNo = to,
                        Network = network,
                        TelcoID = Convert.ToInt32(ids[3]),
                        IsOnNet = Convert.ToBoolean(Convert.ToInt32(ids[4]))

                    });
                }

                B2BayLogger.WriteLogsToFile();
            }
            catch (Exception ex)
            {
                B2BayLogger.LogErr(ex.Message, ex);
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SMSDeliveryResponse " + message, 1, PageNames.SMS_CMPService, 0));
                B2BayLogger.WriteLogsToFile();
            }
        }

        public string Generatekey(string campaingID, string organizationID)
        {
            B2BayLogger.Log("CampaignID: " + CustomSecurity.EncodePasswordToBase64(campaingID));
            B2BayLogger.Log("OrganizationgID: " + CustomSecurity.EncodePasswordToBase64(organizationID));
            B2BayLogger.WriteLogsToFile();

            return "CampaignID: " + CustomSecurity.EncodePasswordToBase64(campaingID) + " OrganizationgID: " + CustomSecurity.EncodePasswordToBase64(organizationID);
        }

        public void SendBulkSMS()
        {
            B2BayLogger.Log("Bulk Starting Camgaigns....");
            
            try
            {
                B2BayLogger.Log("Get Starting Camgaigns....");

                lock (lockerMain)
                {
                    List<StartingCampaign> campains = LazySingleton<SMSCampaignBLL>.Instance.GetAllStartedCampaingsInfo();
                    // List<StartingCampaign> campains = smsCampaignBLL.GetAllStartedCampaingsInfo();
                    if (campains != null && campains.Count > 0)
                    {
                        int noOfCampain = campains.Count;
                        Task[] taskArray = null;

                        for (int j = 0; j < noOfCampain; j++)           //==== Get Campaing one by one
                        {
                            // foreach (StartingCampaign campain in campains)
                            {
                                int? capaignID = Convert.ToInt32(campains[j].CampaignID);
                                int? organizationID = Convert.ToInt32(campains[j].OrganizationID);

                                taskArray = new Task[noOfCampain];
                                taskArray[j] = Task.Factory.StartNew((Object obj) =>
                                {
                                    BulkSendSMSRequest singleRequest = new BulkSendSMSRequest(capaignID, organizationID, campains[j].ShortCode);

                                    singleRequest.Message = campains[j].SMSMessage;
                                    singleRequest.VersoinNo = campains[j].VersionNo;
                                    singleRequest.NoOfSMS = campains[j].NoOfSMS;
                                    B2BayLogger.Log("Message " + campains[j].SMSMessage + "ShortCode " + campains[j].ShortCode + "organizationID " + organizationID + "capaignID " + capaignID);

                                    B2BayLogger.Log("Call SendBulkSMS");
                                    B2BayLogger.Log("==========Campaign Nanme" + campains[j].Title + "==========================");
                                    if (ConfigurationHelper.IsBuffered)
                                    {
                                        //With Buffered 
                                       
                                            singleRequest.SendDataIntoBuffer(campains[j].Lang);
                                    }
                                    else
                                    {
                                        //Direct to SMSC
                                        singleRequest.SendBulkSMS(campains[j].Lang);
                                    }


                                }, j);

                                B2BayLogger.WriteLogsToFile();
                                Thread.Sleep(1000);
                            }
                        }

                        B2BayLogger.Log("*** Wait for completion of all created tasks ***");

                        try
                        {
                            Task.WaitAll(taskArray);
                        }
                        catch
                        { }
                        B2BayLogger.Log("*** Batch of task Complete ***");


                        if (campains != null && campains.Count > 0)
                        {
                            string cvsOfCampaigns = string.Join(",", campains.Select(l => l.CampaignID).ToArray());
                            int? result = LazySingletonBLL<SMSCampaignBLL>.Instance.UpdateCampaignStatus(cvsOfCampaigns);
                        }
                    }
                    else
                    {
                        B2BayLogger.Log("*** NO Campaign found ***");
                    }
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SendBulkSMS" + ex.Message, 1, PageNames.SMS_PortalService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.LogErr(ex.Message, ex);
                B2BayLogger.WriteLogsToFile();
            }

            B2BayLogger.WriteLogsToFile();
        }

        /// <summary>
        /// Save Customer Response
        /// </summary>
        /// <param name="campaingKeyWorld"></param>
        /// <param name="replyPhoneNo"></param>
        /// <param name="replyMessage"></param>
        /// <param name="shortCode"></param>
        /// <param name="campaignID"></param>
        /// <returns></returns>
        public string CampaignResponse(string campaingKeyWord, string replyPhoneNo, string replyMessage, string shortCode, string campaignID)
        {
            string rsultMesage = string.Empty;
            
            try
            {

                lock (lockerResponseReq)
                {

                    B2BayLogger.Log("===============Processing Start... Received Message From User==================================");

                    B2BayLogger.Log("campaingKeyWorld: " + campaingKeyWord + " replyPhoneNo: " + replyPhoneNo + " replyMessage: " + replyMessage + " shortCode: " + shortCode + " campaignID: " + campaignID);
                    B2BayLogger.WriteLogsToFile();
                    string originalNumber = replyPhoneNo;
                    //Remove the 92 and +92 from Phone number
                    if (!string.IsNullOrEmpty(replyPhoneNo) && replyPhoneNo.Length == 12)
                    {
                        replyPhoneNo = replyPhoneNo.Substring(2, replyPhoneNo.Length - 2);
                        replyPhoneNo = "0" + replyPhoneNo;
                    }
                    else if (!string.IsNullOrEmpty(replyPhoneNo) && replyPhoneNo.Length == 13)
                    {
                        replyPhoneNo = replyPhoneNo.Substring(3, replyPhoneNo.Length - 3);
                        replyPhoneNo = "0" + replyPhoneNo;
                    }


                    //Set Plan Text
                    WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
                    // new ResponseCampaignRequest(campaingKeyWord, replyPhoneNo, originalNumber, replyMessage, shortCode, Convert.ToInt32(campaignID));
                    B2BayLogger.Log("==========Wait for 2000====");
                    Thread.Sleep(2000);
                    // Task taskA = Task.Run(() => new ResponseCampaignRequest(campaingKeyWord, replyPhoneNo, originalNumber, replyMessage, shortCode, Convert.ToInt32(campaignID)));
                    Task taskA = Task.Factory.StartNew(() => new ResponseCampaignRequest(campaingKeyWord, replyPhoneNo, originalNumber, replyMessage, shortCode, Convert.ToInt32(campaignID)));
                    B2BayLogger.Log("==========Wait for Completion of Thread task====");
                    taskA.Wait();
                    B2BayLogger.Log("==========Kill Thread====");

                    B2BayLogger.WriteLogsToFile();
                    //==============*X*=====================================
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "CampainResponse" + ex.Message, 1, PageNames.SMS_PortalService, 0));
                B2BayLogger.Log(ex.Message);
                B2BayLogger.LogErr(ex.Message, ex);
                B2BayLogger.WriteLogsToFile();
            }
            B2BayLogger.Log("==============Processing END======================================");
            B2BayLogger.WriteLogsToFile();
            return rsultMesage;
        }

        #region Old Code
        //public string CampaignResponse(string campaingKeyWord, string replyPhoneNo, string replyMessage, string shortCode, string campaignID)
        //{
        //    string rsultMesage = string.Empty;

        //    try
        //    {


        //        B2BayLogger.Log("===============Processing Start... Received Message From User==================================");

        //        B2BayLogger.Log("campaingKeyWorld: " + campaingKeyWord + " replyPhoneNo: " + replyPhoneNo + " replyMessage: " + replyMessage + " shortCode: " + shortCode + " campaignID: " + campaignID);
        //        B2BayLogger.WriteLogsToFile();
        //        string originalNumber = replyPhoneNo;
        //        //Remove the 92 and +92 from Phone number
        //        if (!string.IsNullOrEmpty(replyPhoneNo) && replyPhoneNo.Length == 12)
        //        {
        //            replyPhoneNo = replyPhoneNo.Substring(2, replyPhoneNo.Length - 2);
        //            replyPhoneNo = "0" + replyPhoneNo;
        //        }
        //        else if (!string.IsNullOrEmpty(replyPhoneNo) && replyPhoneNo.Length == 13)
        //        {
        //            replyPhoneNo = replyPhoneNo.Substring(3, replyPhoneNo.Length - 3);
        //            replyPhoneNo = "0" + replyPhoneNo;
        //        }


        //        //Set Plan Text
        //        WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";

        //        //Set Response Model
        //        int campaingId = Convert.ToInt32(campaignID);
        //        CustomerResponseModel customermodel = new CustomerResponseModel(campaingKeyWord, replyPhoneNo, replyMessage, shortCode, campaingId);
        //        customermodel.OriginalContactNo = originalNumber;
        //        B2BayLogger.Log("Add User Response");

        //        //Add Citizen Response in database
        //        int? resultID = BLL.Common.LazySingletonBLL<CustomerResponseBLL>.Instance.AddCustomerResponse(customermodel);

        //        B2BayLogger.Log("Send Reponse to Third Party");
        //        //Set Reponse to Third Party.
        //        //Get Service Url and Method Name from campaign
        //        SMSCampaignModel smsCampaignModel = BLL.Common.LazySingletonBLL<SMSCampaignBLL>.Instance.GetServiceResponseInfo(campaingId);
        //        ThirdParyResponseModel resultResponseMessage = null;

        //        //Send Check Reply message send  to Thirdparty app or service and customer
        //        if (smsCampaignModel != null && !string.IsNullOrEmpty(smsCampaignModel.MethodName) && !string.IsNullOrEmpty(smsCampaignModel.ServiceUrl))
        //        {
        //            //Assign the Customer service value to send customer reposne to thirdParty
        //            customermodel.ServiceUrl = smsCampaignModel.ServiceUrl;
        //            B2BayLogger.Log("Service Url:" + smsCampaignModel.ServiceUrl);
        //            B2BayLogger.Log("MethodName:" + smsCampaignModel.MethodName);
        //            customermodel.MethodName = smsCampaignModel.MethodName;

        //            //Split the Short Code to get the Sending message code
        //            if (!string.IsNullOrEmpty(shortCode))
        //            {
        //                string[] arryShotCode = shortCode.Split('-');
        //                if (arryShotCode.Length > 1)
        //                {
        //                    customermodel.ShortCode = arryShotCode[1];
        //                }
        //                else
        //                {
        //                    customermodel.ShortCode = arryShotCode[0];
        //                }

        //            }


        //            B2BayLogger.WriteLogsToFile();
        //            B2BayLogger.Log("resultMessage");

        //            //Call the ThirdPaty Application/Service to send custormer response
        //            customermodel.ID = resultID.HasValue ? resultID.Value : 0;
        //            B2BayLogger.Log("Send message to Pirth party");
        //            resultResponseMessage = LazySingleton<RequestService>.Instance.SendResponseToClient(customermodel);


        //            //If Reposne message is not set from ThirdParty then send the replay message enter in the campaign
        //            rsultMesage = resultResponseMessage != null && !string.IsNullOrEmpty(resultResponseMessage.Response.ResponseMessage) ? resultResponseMessage.Response.ResponseMessage : smsCampaignModel.ResponseMessage;
        //            //If Third Party Response Message is not null then Response language Mod is NUll.It mean we have to count the no of message form method
        //            if (!string.IsNullOrEmpty(resultResponseMessage.Response.ResponseMessage))
        //            {
        //                smsCampaignModel.ResponseLanguageMode = null;
        //            }


        //            if (resultResponseMessage != null && !string.IsNullOrEmpty(resultResponseMessage.Response.ConfirmationCode))
        //            {
        //                B2BayLogger.Log("Verify the confirmation code to update the record" + resultResponseMessage.Response.ConfirmationCode);
        //                B2BayLogger.Log("ThirdPary Data" + resultResponseMessage.Result);
        //                ///Update the Customer response table with confirmation code                   
        //                CustomerResponseModel confrimationModel = new CustomerResponseModel(resultResponseMessage.Response.ConfirmationCode, customermodel.ID);
        //                confrimationModel.ThirtParyResult = resultResponseMessage.Result;
        //                int? updateResult = BLL.Common.LazySingletonBLL<CustomerResponseBLL>.Instance.UpdateSMSConfirmationInfo(confrimationModel);


        //            }


        //            B2BayLogger.Log("Static ResponseMessage:" + smsCampaignModel.ResponseMessage);
        //            B2BayLogger.Log("rsultMesage:" + rsultMesage);
        //            B2BayLogger.Log("Send Reponse Successfully");

        //        }//End of Send SMS to Client

        //        //Send Reply messge to customer
        //        B2BayLogger.Log("Message Send Reply Message to Citizen form Third Party (IsSend)= " + resultResponseMessage.Response.IsSend);
        //        if (smsCampaignModel != null && resultResponseMessage != null && resultResponseMessage.Response != null && !string.IsNullOrEmpty(rsultMesage))
        //        {
        //            B2BayLogger.Log("Send Reply to Customer");
        //            if (!string.IsNullOrEmpty(resultResponseMessage.Response.IsSend) && resultResponseMessage.Response.IsSend.ToLower().Equals("y"))
        //            {
        //                if (ConfigurationHelper.IsBufferedForReply)
        //                {
        //                    resultResponseMessage.Response.ResponseMessage = rsultMesage;
        //                    //In case of buffered
        //                    // LazySingleton<BulkSendSMSRequest>.Instance.SendReplyDataIntoBuffer(Convert.ToString(campaingId), Convert.ToString(smsCampaignModel.OrganizationID), originalNumber, rsultMesage, resultID);
        //                    LazySingleton<BulkSendSMSRequest>.Instance.SendReplyDataIntoBuffer(Convert.ToString(campaingId), smsCampaignModel, originalNumber, resultResponseMessage.Response, resultID);
        //                }
        //                else
        //                {
        //                    //Without  buffered
        //                    LazySingleton<BulkSendSMSRequest>.Instance.SendReplySMSDirectToSMC(Convert.ToString(campaingId), smsCampaignModel, originalNumber, resultResponseMessage.Response, resultID);
        //                }

        //            }


        //        }
        //        else
        //        {
        //            B2BayLogger.Log("Not Send Reply to Customer");
        //        }

        //        B2BayLogger.WriteLogsToFile();
        //        //==============*X*=====================================

        //    }
        //    catch (Exception ex)
        //    {
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "CampainResponse" + ex.Message, 1, PageNames.SMS_PortalService, 0));
        //        B2BayLogger.Log(ex.Message);
        //        B2BayLogger.LogErr(ex.Message, ex);
        //        B2BayLogger.WriteLogsToFile();
        //    }
        //    B2BayLogger.Log("==============Processing END======================================");
        //    B2BayLogger.WriteLogsToFile();
        //    return rsultMesage;
        //}
        public string CampaignResponseRequest(string campaingKeyWord, string replyPhoneNo, string replyMessage, string shortCode, string campaignID)
        {
            string rsultMesage = string.Empty;

            try
            {


                B2BayLogger.Log("===============Processing Start... Received Message From User==================================");

                B2BayLogger.Log("campaingKeyWorld: " + campaingKeyWord + " replyPhoneNo: " + replyPhoneNo + " replyMessage: " + replyMessage + " shortCode: " + shortCode + " campaignID: " + campaignID);
                B2BayLogger.WriteLogsToFile();
                string originalNumber = replyPhoneNo;
                //Remove the 92 and +92 from Phone number
                if (!string.IsNullOrEmpty(replyPhoneNo) && replyPhoneNo.Length == 12)
                {
                    replyPhoneNo = replyPhoneNo.Substring(2, replyPhoneNo.Length - 2);
                    replyPhoneNo = "0" + replyPhoneNo;
                }
                else if (!string.IsNullOrEmpty(replyPhoneNo) && replyPhoneNo.Length == 13)
                {
                    replyPhoneNo = replyPhoneNo.Substring(3, replyPhoneNo.Length - 3);
                    replyPhoneNo = "0" + replyPhoneNo;
                }


                //Set Plan Text
                WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";

                //Set Response Model
                int campaingId = Convert.ToInt32(campaignID);
                CustomerResponseModel customermodel = new CustomerResponseModel(campaingKeyWord, replyPhoneNo, replyMessage, shortCode, campaingId);
                customermodel.OriginalContactNo = originalNumber;
                B2BayLogger.Log("Add User Response");

                //Add Citizen Response in database
                int? resultID = BLL.Common.LazySingletonBLL<CustomerResponseBLL>.Instance.AddCustomerResponse(customermodel);

                B2BayLogger.Log("Send Reponse to Third Party");
                //Set Reponse to Third Party.
                //Get Service Url and Method Name from campaign
                SMSCampaignModel smsCampaignModel = BLL.Common.LazySingletonBLL<SMSCampaignBLL>.Instance.GetServiceResponseInfo(campaingId);
                ThirdParyResponseModel resultResponseMessage = null;

                //Send Check Reply message send  to Thirdparty app or service and customer
                if (smsCampaignModel != null && !string.IsNullOrEmpty(smsCampaignModel.MethodName) && !string.IsNullOrEmpty(smsCampaignModel.ServiceUrl))
                {
                    //Assign the Customer service value to send customer reposne to thirdParty
                    customermodel.ServiceUrl = smsCampaignModel.ServiceUrl;
                    B2BayLogger.Log("Service Url:" + smsCampaignModel.ServiceUrl);
                    B2BayLogger.Log("MethodName:" + smsCampaignModel.MethodName);
                    customermodel.MethodName = smsCampaignModel.MethodName;

                    //Split the Short Code to get the Sending message code
                    if (!string.IsNullOrEmpty(shortCode))
                    {
                        string[] arryShotCode = shortCode.Split('-');
                        if (arryShotCode.Length > 1)
                        {
                            customermodel.ShortCode = arryShotCode[1];
                        }
                        else
                        {
                            customermodel.ShortCode = arryShotCode[0];
                        }

                    }


                    B2BayLogger.WriteLogsToFile();
                    B2BayLogger.Log("resultMessage");

                    //Call the ThirdPaty Application/Service to send custormer response
                    customermodel.ID = resultID.HasValue ? resultID.Value : 0;
                    B2BayLogger.Log("Send message to Pirth party");
                    resultResponseMessage = LazySingleton<RequestService>.Instance.SendResponseToClient(customermodel);


                    //If Reposne message is not set from ThirdParty then send the replay message enter in the campaign
                    rsultMesage = resultResponseMessage != null && !string.IsNullOrEmpty(resultResponseMessage.Response.ResponseMessage) ? resultResponseMessage.Response.ResponseMessage : smsCampaignModel.ResponseMessage;
                    //If Third Party Response Message is not null then Response language Mod is NUll.It mean we have to count the no of message form method
                    if (!string.IsNullOrEmpty(resultResponseMessage.Response.ResponseMessage))
                    {
                        smsCampaignModel.ResponseLanguageMode = null;
                    }


                    if (resultResponseMessage != null && !string.IsNullOrEmpty(resultResponseMessage.Response.ConfirmationCode))
                    {
                        B2BayLogger.Log("Verify the confirmation code to update the record" + resultResponseMessage.Response.ConfirmationCode);
                        B2BayLogger.Log("ThirdPary Data" + resultResponseMessage.Result);
                        ///Update the Customer response table with confirmation code                   
                        CustomerResponseModel confrimationModel = new CustomerResponseModel(resultResponseMessage.Response.ConfirmationCode, customermodel.ID);
                        confrimationModel.ThirtParyResult = resultResponseMessage.Result;
                        int? updateResult = BLL.Common.LazySingletonBLL<CustomerResponseBLL>.Instance.UpdateSMSConfirmationInfo(confrimationModel);


                    }


                    B2BayLogger.Log("Static ResponseMessage:" + smsCampaignModel.ResponseMessage);
                    B2BayLogger.Log("rsultMesage:" + rsultMesage);
                    B2BayLogger.Log("Send Reponse Successfully");

                }//End of Send SMS to Client

                //Send Reply messge to customer
                B2BayLogger.Log("Message Send Reply Message to Citizen form Third Party (IsSend)= " + resultResponseMessage.Response.IsSend);
                if (smsCampaignModel != null && resultResponseMessage != null && resultResponseMessage.Response != null && !string.IsNullOrEmpty(rsultMesage))
                {
                    B2BayLogger.Log("Send Reply to Customer");
                    if (!string.IsNullOrEmpty(resultResponseMessage.Response.IsSend) && resultResponseMessage.Response.IsSend.ToLower().Equals("y"))
                    {
                        if (ConfigurationHelper.IsBufferedForReply)
                        {
                            resultResponseMessage.Response.ResponseMessage = rsultMesage;
                            //In case of buffered
                            // LazySingleton<BulkSendSMSRequest>.Instance.SendReplyDataIntoBuffer(Convert.ToString(campaingId), Convert.ToString(smsCampaignModel.OrganizationID), originalNumber, rsultMesage, resultID);
                            LazySingleton<BulkSendSMSRequest>.Instance.SendReplyDataIntoBuffer(Convert.ToString(campaingId), smsCampaignModel, originalNumber, resultResponseMessage.Response, resultID);
                        }
                        else
                        {
                            //Without  buffered
                            LazySingleton<BulkSendSMSRequest>.Instance.SendReplySMSDirectToSMC(Convert.ToString(campaingId), smsCampaignModel, originalNumber, resultResponseMessage.Response, resultID);
                        }

                    }


                }
                else
                {
                    B2BayLogger.Log("Not Send Reply to Customer");
                }

                B2BayLogger.WriteLogsToFile();
                //==============*X*=====================================

            }
            catch (Exception ex)
            {
                throw ex;
            }
           
            return rsultMesage;
        }
        #endregion 
    

        public void GetCenterLocation(string districtName)
        {
            B2BayLogger.Log("===============Get FC Location Info================================");
        }
    }
}
