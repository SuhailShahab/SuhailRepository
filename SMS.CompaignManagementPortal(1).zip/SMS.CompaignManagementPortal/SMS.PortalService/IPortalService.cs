﻿using System;
using System.ServiceModel;
using System.ServiceModel.Web;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <27-10-2015 03:43:16PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.PortalService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IPortalService" in both code and config file together.
    [ServiceContract]
    public interface IPortalService
    {
        [OperationContract]
        [WebGet(UriTemplate = "SendSMSFromPortal/{campaignID}/{organizationgID}")]
        void SendSMSFromPortal(string campaignID, string organizationgID);

        [OperationContract]
        [WebGet(UriTemplate = "SendBulkSMS")]
        void SendBulkSMS();

        [OperationContract]
        [WebGet(UriTemplate = "SMSDeliveryResponse/{to}/{smsid}/{type}/{from}")]
        void SMSDeliveryResponse(string to, string smsid, string type, string from);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Xml, 
            UriTemplate = "Generatekey/{campaingID}/{organizationID}")]
        string Generatekey(string campaingID, string organizationID);

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Xml, 
            UriTemplate = "CampaignResponse/{campaingKeyWord}?replyPhoneNo={replyPhoneNo}&replyMessage={replyMessage}&shortCode={shortCode}&campaignID={campaignID}")]
        string CampaignResponse(string campaingKeyWord, string replyPhoneNo, string replyMessage, string shortCode, string campaignID);

        
    }

    
}
