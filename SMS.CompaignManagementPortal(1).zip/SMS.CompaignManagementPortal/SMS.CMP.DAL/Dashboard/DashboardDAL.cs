﻿using DAL.Common;
using SMS.CMP.BE.Dashboard;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.Dashboard
{
    public class DashboardDAL : DALBase
    {
        public DashboardDAL()
        {

        }
        public DashboardDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public DashboardDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// Get all Mask Info
        /// </summary>
        /// <returns>Mask Table info</returns>
        public DataTable GetAllDashboardRecords(DashboardModel model)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashboardItemsCounts", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    if (model.OrganizationID.HasValue && model.OrganizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = model.OrganizationID;
                    }

                    if (model.DepartmentID.HasValue && model.DepartmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = model.DepartmentID;
                    }

                    if (model.UserID.HasValue && model.UserID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = model.UserID;
                    }

                    sqlDadp.Fill(dt);
                    dt.TableName = "tblDashboardItems";
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
    }
}
