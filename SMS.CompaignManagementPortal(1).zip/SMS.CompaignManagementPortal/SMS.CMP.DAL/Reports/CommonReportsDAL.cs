﻿using DAL.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.Reports
{
    public class CommonReportsDAL : DALBase
    {
        public DataTable GetSMSStatSummary(int? deliveryStatusID, int? telcoID, int? smsModeID, int? smsLangID, int? isOnNet, DateTime? dtFrom, DateTime? dtTo, bool isIncludeDate)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSStatSummary", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    if (deliveryStatusID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DeliveryStatusID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DeliveryStatusID"].Value = deliveryStatusID.Value;
                    }
                    if (telcoID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TelcoID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@TelcoID"].Value = telcoID.Value;
                    }

                    if (smsModeID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SMSMode", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SMSMode"].Value = smsModeID.Value;
                    }
                    if (smsLangID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SMSLangID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SMSLangID"].Value = smsLangID.Value;
                    }
                    if (isOnNet.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IsOnNet", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@IsOnNet"].Value = isOnNet.Value;
                    }
                    if (dtFrom.HasValue)


                        if (isIncludeDate)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dtFrom", SqlDbType.DateTime));
                            sqlDadp.SelectCommand.Parameters["@dtFrom"].Value = dtFrom.Value;
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dtTo", SqlDbType.DateTime));
                            sqlDadp.SelectCommand.Parameters["@dtTo"].Value = dtTo.Value;
                        }


                    sqlDadp.Fill(dt);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return dt;
        }

        public DataTable GetCompaignWiseStat(int? organizationID, int? departmentID, int? smsLangID, int? smsMode, int? isOnNet, string filterdListCSVCompaign, string filterdListCSV, DateTime? fromDate, DateTime? toDate, double? SMSPerRate, int? TelcoID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCompaignWiseStat", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    if (organizationID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID.Value;
                    }
                    if (departmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID.Value;
                    }
                    if (smsLangID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SMSLangID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SMSLangID"].Value = smsLangID.Value;
                    }
                    if (smsMode.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SMSMode", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SMSMode"].Value = smsMode.Value;
                    }
                    if (isOnNet.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IsOnNet", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@IsOnNet"].Value = isOnNet.Value;
                    }
                    if (filterdListCSVCompaign != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Compaigns", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@Compaigns"].Value = filterdListCSVCompaign;
                    }
                    if (filterdListCSV != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DeliveryStatus", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@DeliveryStatus"].Value = filterdListCSV;
                    }
                    if (fromDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.DateTime));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate.Value;
                    }
                    if (toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.DateTime));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate.Value;
                    }
                    if (SMSPerRate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SMSPerRate", SqlDbType.Decimal));
                        sqlDadp.SelectCommand.Parameters["@SMSPerRate"].Value = SMSPerRate.Value;
                    }
                    if (TelcoID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TelcoID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@TelcoID"].Value = TelcoID.Value;
                    }
                    sqlDadp.Fill(dt);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return dt;
        }


        /// <summary>
        /// DepartmentWiseStat
        /// </summary>
        /// <param name="TelcoID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public DataTable GetDepartmentWiseStat(int? TelcoID, DateTime? fromDate, DateTime? toDate)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spBillingDepartmentDetailData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (TelcoID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TelcoID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@TelcoID"].Value = TelcoID.Value;
                    }
                    if (fromDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@StartDate"].Value = fromDate.Value;
                    }
                    if (toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@EndDate"].Value = toDate.Value;
                    }
                    sqlDadp.Fill(dt);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return dt;
        }

        /// <summary>
        /// MonthWiseSMSStat
        /// </summary>
        /// <param name="TelcoID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public DataTable GetMonthWiseSMSStat(int? TelcoID, DateTime? fromDate, DateTime? toDate)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spMontlyBillingCountData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (TelcoID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TelcoID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@TelcoID"].Value = TelcoID.Value;
                    }
                    if (fromDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@StartDate"].Value = fromDate.Value;
                    }
                    if (toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@EndDate"].Value = toDate.Value;
                    }
                    sqlDadp.Fill(dt);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return dt;
        }

        public DataTable GetDepartmentWiseMonthlySMSStat(int? DepartmentID, int? TelcoID, DateTime? fromDate, DateTime? toDate)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spMontlyBillingDepartmentCountData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (DepartmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = DepartmentID.Value;
                    }
                    if (TelcoID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TelcoID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@TelcoID"].Value = TelcoID.Value;
                    }
                    if (fromDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@StartDate"].Value = fromDate.Value;
                    }
                    if (toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@EndDate"].Value = toDate.Value;
                    }
                    sqlDadp.Fill(dt);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return dt;
        }

        /// <summary>
        /// GetSMSStatDetail
        /// </summary>
        /// <param name="deliveryStatusID"></param>
        /// <param name="telcoID"></param>
        /// <param name="smsModeID"></param>
        /// <param name="smsLangID"></param>
        /// <param name="isOnNet"></param>
        /// <param name="dtFrom"></param>
        /// <param name="dtTo"></param>
        /// <param name="isIncludeDate"></param>
        /// <returns></returns>
        public DataTable GetSMSStatDetail(int? deliveryStatusID, int? telcoID, int? smsModeID, int? smsLangID, int? isOnNet, DateTime? dtFrom, DateTime? dtTo, bool isIncludeDate)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSStatDetailData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    if (deliveryStatusID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DeliveryStatusID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DeliveryStatusID"].Value = deliveryStatusID.Value;
                    }
                    if (telcoID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TelcoID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@TelcoID"].Value = telcoID.Value;
                    }

                    if (smsModeID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SMSMode", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SMSMode"].Value = smsModeID.Value;
                    }
                    if (smsLangID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SMSLangID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SMSLangID"].Value = smsLangID.Value;
                    }
                    if (isOnNet.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IsOnNet", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@IsOnNet"].Value = isOnNet.Value;
                    }
                    if (dtFrom.HasValue)
                        if (isIncludeDate)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.DateTime));
                            sqlDadp.SelectCommand.Parameters["@StartDate"].Value = dtFrom.Value;
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.DateTime));
                            sqlDadp.SelectCommand.Parameters["@EndDate"].Value = dtTo.Value;
                        }
                    sqlDadp.Fill(dt);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return dt;
        }

    }
}
