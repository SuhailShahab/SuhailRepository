﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.Common
{
   public  class DALConfigBase
    {
        private string m_spConnectionString = "ConfigDBConnectionString";
        public string DBName;
        /// Defualt constructor
        /// </summary>
        public DALConfigBase()
        {
            this.m_spConnectionString = ConfigurationManager.ConnectionStrings["ConfigDBConnectionString"].ConnectionString.ToString();            
        }
      

        protected string spConnectionString
        {
            get { return m_spConnectionString; }
        }

       

        //protected void ConCloseDisponse(SqlConnection con)
        //{
        //    if (con.State == ConnectionState.Open)
        //        con.Close();
        //    con.Dispose();
        //}
        //protected void ConnectionClose(SqlConnection con)
        //{
        //    if (con.State == ConnectionState.Open)
        //        con.Close();
        //}
        //protected void OpenConnection(SqlConnection con)
        //{
        //    if (con.State == ConnectionState.Closed)
        //        con.Open();
        //}
        protected SqlConnection dbConnection;
        protected SqlTransaction dbTransaction;
    }
}
