﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Common
{
   public  class SqlUtility
    {
       //public List<SqlParameter> GetAddParameter(object obj)
       //{
       //    PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
       //    var sqlParams = new List<SqlParameter>();
       //    foreach (var f in fields)
       //    {
       //        foreach (Object objColumName in f.GetCustomAttributes(true))
       //        {
       //            MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;

       //            var p = f.GetValue(obj, null);
       //            if (p != null)
       //                sqlParams.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));

       //        }
       //    }
       //    return sqlParams;
       //}
       public List<SqlParameter> GetAddParameter(object obj)
       {
           PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
           var sqlParams = new List<SqlParameter>();
           foreach (var f in fields)
           {
               foreach (Object objColumName in f.GetCustomAttributes(true))
               {

                   MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;
                  
                       var p = f.GetValue(obj, null);
                       if (p != null)
                       {
                           sqlParams.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                           break;
                       }                       
                  

               }
           }
           return sqlParams;
       }

       public void GetAddParameter(object obj, SqlCommand sqlCommand)
       {
           PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
          
           foreach (var f in fields)
           {
               foreach (Object objColumName in f.GetCustomAttributes(true))
               {

                   MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;
                  
                       var p = f.GetValue(obj, null);
                       if (p != null && !mappingInfoAttribute.Transient)
                       {
                           sqlCommand.Parameters.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                           break;
                       }
                           
                   


               }
           }
          
       }


       public void GetAddParameterExtented(object obj, SqlCommand sqlCommand)
       {
           PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

           foreach (var f in fields)
           {
               foreach (Object objColumName in f.GetCustomAttributes(true))
               {

                   MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;

                   var p = f.GetValue(obj, null);
                   if (p != null && p != "" && !mappingInfoAttribute.Transient)
                   {
                       sqlCommand.Parameters.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                       break;
                   }




               }
           }

       }
       public void GetAddParameter1(object obj, SqlCommand sqlCommand)
       {
           PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

           foreach (var f in fields)
           {
               foreach (Object objColumName in f.GetCustomAttributes(true))
               {

                   MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;
                   
                   if(!string.IsNullOrEmpty(mappingInfoAttribute.DataType) && mappingInfoAttribute.DataType.Equals("bool"))
                   {
                       var p = Convert.ToInt32(f.GetValue(obj, null));
                       if (p != null &&  !mappingInfoAttribute.Transient)
                       {
                           sqlCommand.Parameters.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                           break;
                       }
                   }
                   else
                   {
                       var p = f.GetValue(obj, null);
                       if (p != null && p != "" && !mappingInfoAttribute.Transient)
                       {
                           sqlCommand.Parameters.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                           break;
                       }
                   }
                  
                  




               }
           }

       }
       //public static void GetAddParameter(object obj, SqlCommand sqlCommand)
       //{
       //    PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

       //    foreach (var f in fields)
       //    {
       //        foreach (Object objColumName in f.GetCustomAttributes(true))
       //        {

       //            MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;

       //            var p = f.GetValue(obj, null);
       //            if (p != null)
       //            {
       //                sqlCommand.Parameters.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
       //                break;
       //            }




       //        }
       //    }

       //}


       
    }
}
