﻿
using DAL.Common;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.DAL.Common;
//using SMS.CMP.BE.SMSQueue;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.SMSQueue
{


    // =================================================================================================================================
    // Create by:	<Sohail Kamran>
    // Create date: <30-11-2015 12:00 AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // CR:001       Syed Zeeshan Aqil           30-Nov- 2015 12:14 PM       Add Method  spGetSMSQueues to get SMS Queues Information
    // CR:002       Syed Zeeshan Aqil           30-Nov- 2015 12:34 PM       Add Method  GetSMSQueueMessage to get SMS Queues Message
    // CR:003       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  GetCurrentSMSQueue To get 
    // CR:004       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  GetNextSMSQueue To get Buffer SMS 
    // CR:005       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  PurgeBuffer To Purge whole table
    // CR:006       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  UpdateSMSQueueSendStatus To update status
    // CR:007       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  IsExistPendingSMSQueue To check table rows count
    // CR:008       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  ResetSMSQueue To re-send failed sms to beffer
    // CR:009       SOHAIL KAMRAN               30-Nov- 2015 12:34 PM       Add Method  SetQueueDeliveryStatus set Status




    // =================================================================================================================================
    /// <summary>
    /// SMS Data Access Layer
    /// </summary>
    public class SMSQueueDAL : DALConfigBase
    {
        public SMSQueueDAL()
        {

        }
        public SMSQueueDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public SMSQueueDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }


        /// <summary>
        /// Add SMS Entry in SMS Que Model
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(SMSQueueModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddSMSSQueue";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);
                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }
        public int AddBulkQueue(SMSQueueModel model, DataTable dt)
        {
            object result = 0;
            SqlConnection con = null;

            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    using (SqlCommand sqlCmd = new SqlCommand())
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddBulkSMSSQueue";
                        LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);
                        sqlCmd.Parameters.Add("@dtSMSQueue", SqlDbType.Structured);
                        sqlCmd.Parameters["@dtSMSQueue"].Value = dt;
                        result = sqlCmd.ExecuteNonQuery();

                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(1);

        }

        public int? AddBulkSMSToBuffer(BulkSMSModel bulkSMSModel)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();


                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "spAddBulkSMSToBuffer";

                    sqlCmd.Parameters.Add("@OrganizationID", SqlDbType.Int);
                    sqlCmd.Parameters["@OrganizationID"].Value = bulkSMSModel.OrganizationID;

                    sqlCmd.Parameters.Add("@CampaignID", SqlDbType.Int);
                    sqlCmd.Parameters["@CampaignID"].Value = bulkSMSModel.CampaignID;

                    result = sqlCmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }
        #region Add Bulk SMS
        public int? AddBulkSMS(int createdby, BulkSMSModel bulkSMSModel)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();


                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "spAddBulkSMS";


                    sqlCmd.Parameters.Add("@CreatedBy", SqlDbType.Int);
                    sqlCmd.Parameters["@CreatedBy"].Value = createdby;

                    sqlCmd.Parameters.Add("@IsEncodeOn", SqlDbType.Bit);
                    sqlCmd.Parameters["@IsEncodeOn"].Value = Convert.ToInt32(bulkSMSModel.IsEncodeOn);

                    sqlCmd.Parameters.Add("@tblBulkSMS", SqlDbType.Structured);
                    sqlCmd.Parameters["@tblBulkSMS"].Value = bulkSMSModel.BulkSMS;

                    sqlCmd.Parameters.Add("@OrganizationID", SqlDbType.Int);
                    sqlCmd.Parameters["@OrganizationID"].Value = bulkSMSModel.OrganizationID;

                    sqlCmd.Parameters.Add("@DepartmentID", SqlDbType.Int);
                    sqlCmd.Parameters["@DepartmentID"].Value = bulkSMSModel.DepartmentID;

                    sqlCmd.Parameters.Add("@CampaignID", SqlDbType.Int);
                    sqlCmd.Parameters["@CampaignID"].Value = bulkSMSModel.CampaignID;



                    result = sqlCmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }
        public int? AddSMS(BulkSMSModel bulkSMSModel)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();


                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "spAddSMS";

                    LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(bulkSMSModel, sqlCmd);

                    result = sqlCmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }
        public int? EditSMS(BulkSMSModel bulkSMSModel)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();


                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "spEditSMS";

                    LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(bulkSMSModel, sqlCmd);

                    result = sqlCmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }
        public int? DeleteSMS(int id)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();


                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "spDeleteSMS";
                    sqlCmd.Parameters.Add(new SqlParameter("@SMSID", SqlDbType.Int));
                    sqlCmd.Parameters["@SMSID"].Value = id;


                    result = sqlCmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }
        public DataTable GetAllBulkContactWithPaging(int pageNo, int pageSize, int? userId)
        {
            object result = 0;
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {

                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllBulkContactsPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (userId.HasValue && userId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add("@CreatedBy", SqlDbType.Int);
                        sqlDadp.SelectCommand.Parameters["@CreatedBy"].Value = userId;
                    }
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.Fill(dt);
                    return dt;

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return null;
        }
        public DataTable GetAllBulkContactWithPagingByText(int pageNo, int pageSize, int? userId, int? organizationID, int? departmentID, string shearText)
        {
            object result = 0;
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {

                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllContactsByText", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (userId.HasValue && userId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add("@CreatedBy", SqlDbType.Int);
                        sqlDadp.SelectCommand.Parameters["@CreatedBy"].Value = userId;
                    }
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (organizationID.HasValue && organizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;
                    }
                    if (departmentID.HasValue && departmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    if (!string.IsNullOrEmpty(shearText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = shearText;
                    }

                    sqlDadp.Fill(dt);
                    return dt;

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return null;
        }

        #endregion
        /// <summary>
        /// CR:004
        /// Select All SMS Ques List
        /// </summary>
        /// <returns></returns>

        public DataTable GetNextSMSQueue()
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetNextSMSQueue", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetNextSMSQueueByIDs(int? telcoID, int? smsThroughput)
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetNextSMSQueueByTelcoID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                if (telcoID.HasValue)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TelcoID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@TelcoID"].Value = telcoID;
                }

                if (smsThroughput.HasValue)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SMSThroughput", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@SMSThroughput"].Value = smsThroughput;
                }


                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// CR:003 
        /// Get SMS Que List
        /// </summary>
        /// <returns></returns>
        public DataTable GetCurrentSMSQueue(int organizationID, int campaignID)
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGetCurrentSMSQueue", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;


                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        /// <summary>
        /// CR:005 
        /// Purge from Buffer
        /// </summary>
        /// <returns></returns>
        public int PurgeBuffer()
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spPurgeBuffer";
                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);

        }



        /// <summary>
        /// CR:006 
        /// update SMSQueue Send Status
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int UpdateSMSQueueSendStatus(SMSQueueModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdatSMSQueueSendStatus";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter1(model, sqlCmd);
                result = sqlCmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }


        /// <summary>
        /// CR:007
        /// check table rows count
        /// </summary>
        /// <returns></returns>
        public bool IsExistPendingSMSQueue()
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spIsExistSMSQueue", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);

                if (dt != null && dt.Rows.Count > 0)
                {
                    return Convert.ToBoolean(dt.Rows[0][0]);
                }

                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        /// <summary>
        /// CR:009  
        /// Set SMS Queue Model
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int SetQueueDeliveryStatus(SMSQueueModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spSetQueueDeliveryStatus";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter1(model, sqlCmd);
                result = sqlCmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// CR:008  
        /// Reset SMS Queue
        /// </summary>
        /// <param name="campaignID"></param>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public int ResetSMSQueue(int campaignID, int organizationID)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spResetSMSQueue";
                //LazySingletonDAL<SqlUtility>.Instance.GetAddParameter1(model, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                sqlCmd.Parameters["@CampaignID"].Value = campaignID;
                sqlCmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                sqlCmd.Parameters["@OrganizationID"].Value = organizationID;


                result = sqlCmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        public DataTable GetCampaignsPriority(int? organizationID, int? departmentID, int? campaignID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignsPriority", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public int? EditCampaignsPriority(int? campaignID, int? priorityID, int? newPriorityID)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditCampaignsPriority";

                sqlCmd.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                sqlCmd.Parameters["@CampaignID"].Value = campaignID;

                sqlCmd.Parameters.Add(new SqlParameter("@PriorityID", SqlDbType.Int));
                sqlCmd.Parameters["@PriorityID"].Value = priorityID;

                sqlCmd.Parameters.Add(new SqlParameter("@NewPriorityID", SqlDbType.Int));
                sqlCmd.Parameters["@NewPriorityID"].Value = newPriorityID;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

    }
}
