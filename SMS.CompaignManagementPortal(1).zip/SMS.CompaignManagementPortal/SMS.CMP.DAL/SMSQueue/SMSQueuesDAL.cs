﻿
using DAL.Common;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.DAL.Common;
//using SMS.CMP.BE.SMSQueue;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.SMSQueue
{


// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <30-11-2015 12:00 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR:001       Syed Zeeshan Aqil           30-Nov- 2015 12:14 PM       Add Method  spGetSMSQueues to get SMS Queues Information
// CR:002       Syed Zeeshan Aqil           30-Nov- 2015 12:34 PM       Add Method  GetSMSQueueMessage to get SMS Queues Message
// =================================================================================================================================
    /// <summary>
    /// SMS Data Access Layer
    /// </summary>
    public class SMSQueuesDAL : DALBase
    {
        public SMSQueuesDAL()
        {

        }
        public SMSQueuesDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public SMSQueuesDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// // CR:001 
        ///  This Method use to Get the SMS Queues
        /// </summary>
        /// <param name="search">Search Model</param>
        /// <returns>Get SMS Queues Data Table</returns>
        public DataTable spGetSMSQueues(SearchModel search)
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSQueues", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                if (search.OrganizaitonID.HasValue && search.OrganizaitonID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = search.OrganizaitonID.Value;
                }

                if (search.DepartmentID.HasValue && search.DepartmentID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = search.DepartmentID.Value;
                }

                if (search.UserID.HasValue && search.UserID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = search.UserID.Value;
                }

                if (search.FromDate != "")
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@FromDate"].Value = search.FromDate;
                }

                if (search.Todate != "")
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@ToDate"].Value = search.Todate;
                }

                if (search.CampaignID.HasValue && search.CampaignID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = search.CampaignID.Value;
                }


                if (search.SearchText != "")
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@SearchText"].Value = search.SearchText;
                }


                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@PageNo"].Value = search.PageNo;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@PageSize"].Value = search.PageSize;


                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// CR:002
        /// This Method is use to get the SMS Queue  Message 
        /// </summary>
        /// <param name="queueID">Selected Queue ID</param>
        /// <returns>Transaction SMS Queue Message</returns>
        public string GetSMSQueueMessage(int queueID)
        {
            DataTable dt = new DataTable();
            string strMessage = "";
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSQueueMessage", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@QueueID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@QueueID"].Value = queueID;

                sqlDadp.Fill(dt);
                if (dt.Rows.Count > 0)
                    strMessage = dt.Rows[0]["SMSMessage"].ToString();

                return strMessage;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

      
    }
}
