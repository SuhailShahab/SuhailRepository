﻿using DAL.Common;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.DAL.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// =================================================================================================================================
// Create by:	<sohail Shahab>
// Create date: <10-12-2015 08:59 AM>
// Manage the Third Party API Telnor Reposne
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
namespace SMS.CMP.DAL.SMSQueue
{
    public class ThirdPartyAPIResponseDAL : DALConfigBase
    {
        public ThirdPartyAPIResponseDAL()
        {

        }
        public ThirdPartyAPIResponseDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public ThirdPartyAPIResponseDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int? Add(ThirdPartyAPIResponseModel model)
        {
            int? result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddThirdPartyAPIRepsonse";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);
                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return result;

        }


        /// <summary>
        /// CR:004
        /// For Getting Third Party Response Data
        /// </summary>
        /// <returns></returns>

        public DataTable GetThirdPartyResponseData()
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetThirdPartyResponseData", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// CR:004
        /// For Update Third Party Response Status
        /// </summary>
        /// <returns></returns>

        public void UpdateThirdPartyResponse()
        {

            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdateThirdPartyResponse";
                sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }


        /// <summary>
        /// CR:004
        /// For Update Third Party Response By ID
        /// </summary>
        /// <returns></returns>

        public void UpdateThirdPartyResponseByID(int? thirdPartyAPIResponseID, int? statusID)
        {

            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdateThirdPartyResponseByID";

                sqlCmd.Parameters.Add(new SqlParameter("@ThirdPartyAPIResponseID", SqlDbType.Int));
                sqlCmd.Parameters["@ThirdPartyAPIResponseID"].Value = thirdPartyAPIResponseID;

                sqlCmd.Parameters.Add(new SqlParameter("@StatusID", SqlDbType.Int));
                sqlCmd.Parameters["@StatusID"].Value = statusID;

                sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }


        /// <summary>
        /// 
        /// For Checking Record Existance
        /// </summary>
        /// <returns></returns>
        public int? IsExistsRecords()
        {
            int? result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open(); 
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spIsExistPendingSMS";
                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return result;
        }
    }
}
