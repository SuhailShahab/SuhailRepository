﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
    public class AddressBookDAL:DALBase
    {
        public AddressBookDAL()
        {

        }
        public AddressBookDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public AddressBookDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// Add Address Book Info
        /// </summary>
        /// <param name="model">Address Book Model</param>
        /// <returns></returns>
        public int Add(AddressBooksModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddAddressBooks";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Edit  Address Book
        /// </summary>
        /// <param name="model">Address Book Model</param>
        /// <returns></returns>
        public int Edit(AddressBooksModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditAddressBooks";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Update Address Book Contact
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int UpdateAddressBookContact(DataTable dtContacts, int? organizationID, int? addressBookID, int? departmentID,bool? isIncludeExistingAddresBook)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdateAddressBookContact";

                sqlCmd.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                sqlCmd.Parameters["@AddressBookID"].Value = addressBookID;

                sqlCmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                sqlCmd.Parameters["@OrganizationID"].Value = organizationID;

                sqlCmd.Parameters.Add(new SqlParameter("@addressBook", SqlDbType.Structured));
                sqlCmd.Parameters["@addressBook"].Value = dtContacts;

                sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                sqlCmd.Parameters["@DepartmentID"].Value = departmentID;

              
                sqlCmd.Parameters.Add(new SqlParameter("@AddExistingAddBook", SqlDbType.Bit));
                sqlCmd.Parameters["@AddExistingAddBook"].Value = Convert.ToBoolean(isIncludeExistingAddresBook);

                //if (isIncludeExistingAddresBook)
                //{
                //    sqlCmd.Parameters.Add(new SqlParameter("@AddExistingAddBook", SqlDbType.Int));
                //    sqlCmd.Parameters["@AddExistingAddBook"].Value = Convert.ToInt32(isIncludeExistingAddresBook);
                //}             
                

                result = Convert.ToInt32(sqlCmd.ExecuteNonQuery());
                con.Close();
               // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }
        public int DeleteAddressBookContact(DataTable dtContacts, int? organizationID, int? addressBookID, int? departmentID, bool? isDeletedAll)
        {
            int result;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteAddressBookContact";

                sqlCmd.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                sqlCmd.Parameters["@AddressBookID"].Value = addressBookID;

                sqlCmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                sqlCmd.Parameters["@OrganizationID"].Value = organizationID;

                sqlCmd.Parameters.Add(new SqlParameter("@addressBook", SqlDbType.Structured));
                sqlCmd.Parameters["@addressBook"].Value = dtContacts;

                sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                sqlCmd.Parameters["@DepartmentID"].Value = departmentID;

                if (isDeletedAll.HasValue && isDeletedAll.Value)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@IsDeletedAll", SqlDbType.Bit));
                    sqlCmd.Parameters["@IsDeletedAll"].Value = isDeletedAll;
                }
               

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Get all Address Book Info
        /// </summary>
        /// <returns>Mask Table info</returns>
        public DataTable GetAllAddressBooks()
        {
            DataTable dt = new DataTable();
          //  SqlConnection con = null;
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllAddressBooks", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public DataTable GetAllAddressBooksByIDs(int? ogrID, int? deptID, int? userID)
        {
            DataTable dt = new DataTable();
           
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllAddressBooksByOrgID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    if (ogrID.HasValue && ogrID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = ogrID;
                    }
                    if (deptID.HasValue && deptID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;
                    }

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //finally
            //{
            //    if (con != null && con.State == ConnectionState.Open)
            //    {
            //        con.Close();
            //        con.Dispose();
            //    }
            //}
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ogrID"></param>
        /// <param name="deptID"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataTable GetAllAddressBooksByIDs(int? ogrID, int? deptID, int? userID, int pageNo, int pageSize)
        {
            DataTable dt = new DataTable();
          //  SqlConnection con = null;
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllAddressBooksWithPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    if (ogrID.HasValue && ogrID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = ogrID;
                    }
                    if (deptID.HasValue && deptID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;
                    }

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //finally
            //{
            //    if (con != null && con.State == ConnectionState.Open)
            //    {
            //        con.Close();
            //        con.Dispose();
            //    }
            //}
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ogrID"></param>
        /// <param name="deptID"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public DataTable GetAllAddressBooksByIDs(int? ogrID, int? deptID, int? userID, int pageNo, int pageSize, string searchText)
        {
            DataTable dt = new DataTable();
           // SqlConnection con = null;
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllAddressBooksWithPagingSearch", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    if (ogrID.HasValue && ogrID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = ogrID;
                    }
                    if (deptID.HasValue && deptID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;
                    }

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //finally
            //{
            //    if (con != null && con.State == ConnectionState.Open)
            //    {
            //        con.Close();
            //        con.Dispose();
            //    }
            //}
        }


        /// <summary>
        /// Get All Active Address Book info
        /// </summary>
        /// <returns>Address Book Table Info</returns>
        public DataTable GetAllActiveAddressBooks()
        {
            DataTable dt = new DataTable();
           // SqlConnection con = null;
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveAddressBooks", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //finally
            //{
            //    if (con != null && con.State == ConnectionState.Open)
            //    {
            //        con.Close();
            //        con.Dispose();
            //    }
            //}
        }

        /// <summary>
        /// Delte Address Book Info By ID
        /// </summary>
        /// <param name="model">Address Book Model</param>
        /// <returns></returns>
        public int Delete(AddressBooksModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteAddressBooks";

                //LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);
                sqlCmd.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                sqlCmd.Parameters["@AddressBookID"].Value = model.AddressBookID;

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }


        /// <summary>
        /// Update Contacts by Uploading Files
        /// </summary>
        /// <param name="dtcontacts"></param>
        /// <param name="organizationID"></param>
        /// <param name="departmentID"></param>
        /// <param name="CreatedBy"></param>
        /// <returns></returns>
        public DataTable SaveImportContacts(DataTable dtcontacts, int organizationID, int departmentID, int? CreatedBy)
        {

            DataTable dt = new DataTable();
           // SqlConnection con = null;
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spAddImportContactsByOrgID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CreatedBy"].Value = CreatedBy;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ImportContacts", SqlDbType.Structured));
                    sqlDadp.SelectCommand.Parameters["@ImportContacts"].Value = dtcontacts;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //finally
            //{
            //    if (con != null && con.State == ConnectionState.Open)
            //    {
            //        con.Close();
            //        con.Dispose();
            //    }
            //}

        }


        /// <summary>
        /// Save Import Contacts
        /// </summary>
        /// <param name="dtcontacts"></param>
        /// <param name="organizationID"></param>
        /// <param name="CreatedBy"></param>
        /// <returns></returns>
        //public int SaveImportContacts(DataTable dtcontacts, int organizationID, int departmentID,  int? CreatedBy)
        //{
        //    object result = 0;
        //    SqlConnection con = new SqlConnection(this.spConnectionString);
        //    SqlCommand sqlCmd = new SqlCommand();

        //    try
        //    {
        //        con.Open();
        //        sqlCmd.Connection = con;
        //        sqlCmd.CommandType = CommandType.StoredProcedure;
        //        sqlCmd.CommandText = "spAddImportContactsByOrgID";

        //        sqlCmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
        //        sqlCmd.Parameters["@OrganizationID"].Value = organizationID;

        //        sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
        //        sqlCmd.Parameters["@DepartmentID"].Value = departmentID;

        //        sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
        //        sqlCmd.Parameters["@CreatedBy"].Value = CreatedBy;

        //        sqlCmd.Parameters.Add(new SqlParameter("@ImportContacts", SqlDbType.Structured));
        //        sqlCmd.Parameters["@ImportContacts"].Value = dtcontacts;

        //        result = Convert.ToInt32(sqlCmd.ExecuteScalar());
        //        con.Close();
        //        //return Convert.ToInt32(result);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        if (con.State == ConnectionState.Open)
        //            con.Close();
        //    }
        //    return Convert.ToInt32(result);
        //}


        //public DataTable SaveImportContacts(DataTable dtcontacts, int organizationID, int departmentID, int addressBookID, int? CreatedBy)
        //{

        //    DataTable dt = new DataTable();
        //    try
        //    {
        //        SqlConnection con = new SqlConnection(this.spConnectionString);
        //        SqlDataAdapter sqlDadp = new SqlDataAdapter("spAddImportContacts", con);
        //        sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

        //        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
        //        sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;

        //        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
        //        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

        //        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
        //        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;


        //        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
        //        sqlDadp.SelectCommand.Parameters["@CreatedBy"].Value = CreatedBy;

        //        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ImportContacts", SqlDbType.Structured));
        //        sqlDadp.SelectCommand.Parameters["@ImportContacts"].Value = dtcontacts;

        //        sqlDadp.Fill(dt);
        //        return dt;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }



        //}


        /// <summary>
        /// Save Import Contacts.
        /// </summary>
        /// <param name="contacts"></param>
        /// <param name="addressBooksModel"></param>
        /// <returns></returns>
        /// 
        public DataTable SaveImportContacts(DataTable dtcontacts, int organizationID, int departmentID, int addressBookID, int? CreatedBy)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();
            DataTable dt = new DataTable();
            try
            {


                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddImportContacts";

                // LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                sqlCmd.Parameters["@AddressBookID"].Value = addressBookID;

                sqlCmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                sqlCmd.Parameters["@OrganizationID"].Value = organizationID;

                sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                sqlCmd.Parameters["@DepartmentID"].Value = departmentID;


                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = CreatedBy;

                sqlCmd.Parameters.Add(new SqlParameter("@ImportContacts", SqlDbType.Structured));
                sqlCmd.Parameters["@ImportContacts"].Value = dtcontacts;

                sqlCmd.CommandTimeout = 0;

                result = Convert.ToInt32(sqlCmd.ExecuteNonQuery());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return dt;
            //return Convert.ToInt32(result);

        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public DataTable GetAddressBooksWithContactsByOrgID(int orgID, int deptID, int? campaignID)
        {
            DataTable dt = new DataTable();
          //  SqlConnection con = null;
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAddressBooksWithContactsByOrgID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;

                    if (campaignID.HasValue && campaignID.Value >0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;
                    }
                   

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //finally
            //{
            //    if (con != null && con.State == ConnectionState.Open)
            //    {
            //        con.Close();
            //        con.Dispose();
            //    }
            //}
        }
      
    }
}
