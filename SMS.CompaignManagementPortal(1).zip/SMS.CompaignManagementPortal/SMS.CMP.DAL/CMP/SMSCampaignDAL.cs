﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMPsmsCampaign
{
    // =================================================================================================================================
    // Create by:	<Atif Farroq>
    // Create date: <19-10-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // CR:001       Syed Zeeshan Aqil           19-Nov- 2015 12:30 PM       Add Method  GetSMSSendMessage to get Message
    // CR:002       Syed Zeeshan Aqil           25-Nov- 2015 01:27 PM       Add Method  GetProcessingStatuses to get the Campaign processing Statuses
    // CR:003       Syed Zeeshan Aqil           04-Dec- 2015 05:21 PM       Add Method  GetAllCampaignesSchedule to get the Campaign Schedule list
    // =================================================================================================================================
    public class SMSCampaignDAL : DALBase
    {
        public int Add(SMSCampaignModel model, DataTable dtUploadContacts)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddSMSCampaign";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@UploadContacts", SqlDbType.Structured));
                sqlCmd.Parameters["@UploadContacts"].Value = dtUploadContacts;

                //sqlCmd.Parameters.Add(new SqlParameter("@PerSMSRate", SqlDbType.Decimal));
                //sqlCmd.Parameters["@PerSMSRate"].Value = model.PerSMSRate;

                //sqlCmd.Parameters.Add(new SqlParameter("@ExpiryDate", SqlDbType.DateTime));
                //sqlCmd.Parameters["@ExpiryDate"].Value = model.ExpiryDate;

                //sqlCmd.Parameters.Add(new SqlParameter("@TotalAllocatedSMS", SqlDbType.Int));
                //sqlCmd.Parameters["@TotalAllocatedSMS"].Value = model.TotalAllocatedSMS;

                //sqlCmd.Parameters.Add(new SqlParameter("@TotalAmount", SqlDbType.Int));
                //sqlCmd.Parameters["@TotalAmount"].Value = model.TotalAmount;

                result = sqlCmd.ExecuteScalar();
                con.Close();
                // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }


        /// <summary>
        /// Update Campaign Information
        /// </summary>
        /// <param name="model">Selected Campaign odel</param>
        /// <param name="dtUploadContacts">Contacts Table</param>
        /// <returns></returns>
        public int Edit(SMSCampaignModel model, DataTable dtUploadContacts)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditSMSCampaign";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@UploadContacts", SqlDbType.Structured));
                sqlCmd.Parameters["@UploadContacts"].Value = dtUploadContacts;

                result = sqlCmd.ExecuteScalar();
                con.Close();
                // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }


        /// <summary>
        /// Update Campaing Status used in Schduler
        /// </summary>
        /// <param name="csvOfCampaigns"></param>
        /// <returns></returns>
        public int UpdateCampaignStatus(string csvOfCampaigns)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdateCampaignsStatus";
                sqlCmd.Parameters.Add(new SqlParameter("@CSV_Of_Campaigns", SqlDbType.VarChar));
                sqlCmd.Parameters["@CSV_Of_Campaigns"].Value = csvOfCampaigns;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
                // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Update Campaing Status used in Schduler
        /// </summary>
        /// <param name="csvOfCampaigns"></param>
        /// <returns></returns>
        public int SetCampaignStatus(int? campaignID)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spSetCampaignsStatus";
                sqlCmd.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                sqlCmd.Parameters["@CampaignID"].Value = campaignID.Value;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
                // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// For Getting the SMS  Campaign History Information 
        /// </summary>
        /// <returns></returns>
        public DataTable GetCampaignByID(int campaignedID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignByID", con);
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@CampaignID", campaignedID);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// For Getting the SMS Campaing Log Information 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllCampaings(SMSCampaignLog model)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSCampaigns", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (model.OrganizationID.HasValue && model.OrganizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = model.OrganizationID;
                    }

                    if (model.DepartmentID.HasValue && model.DepartmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = model.DepartmentID;
                    }

                    if (model.UserID.HasValue && model.UserID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = model.UserID;
                    }
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get All AllCampaings with demand based paging 
        /// </summary>
        /// <param name="model"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataTable GetAllCampaings(SMSCampaignLog model, int pageNo, int pageSize)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSCampaignsWithPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (model.OrganizationID.HasValue && model.OrganizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = model.OrganizationID;
                    }

                    if (model.DepartmentID.HasValue && model.DepartmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = model.DepartmentID;
                    }

                    if (model.UserID.HasValue && model.UserID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = model.UserID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;




                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get All AllCampaings with demand based paging along search
        /// </summary>
        /// <param name="model"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public DataTable GetAllCampaings(SMSCampaignLog model, int pageNo, int pageSize, string searchText)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSCampaignsWithPagingSearch", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (model.OrganizationID.HasValue && model.OrganizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = model.OrganizationID;
                    }

                    if (model.DepartmentID.HasValue && model.DepartmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = model.DepartmentID;
                    }

                    if (model.UserID.HasValue && model.UserID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = model.UserID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }



        public DataTable SelectCampaingsInfoByIDs(int? organizationID, int? campaignID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignInfoByIDs", con);//spGetAllStartCampaignInfo
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID.Value;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID.Value;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        public DataTable SelectValidCampaingsInfoByIDs(int? organizationID, int? campaignID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetValidCampaignInfoByIDs", con);//spGetAllStartCampaignInfo
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID.Value;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID.Value;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public DataTable GetAllStartedCampaingsInfo()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllStartCampaignInfo", con);//spGetAllStartCampaignInfo
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Using in Schduler Don't change with out dissucsion suhail Shahab
        /// </summary>
        /// <returns></returns>
        public bool IsExistStartCampaignInfo()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spIsExistStartCampaignInfo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    return Convert.ToBoolean(dt.Rows[0][0]);
                }

                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// For Getting the SMS Campaing Log Information  With  Pagaing
        /// </summary>
        /// <param name="campaignedID">campaing ID</param>
        /// <param name="pageNo">Page Number</param>
        /// <param name="pageSize">Page Size</param>
        /// <returns></returns>
        public DataSet GetAllCampaingsByID(int campaignedID, int pageNo, int pageSize, int showStatus, string fromDate, string toDate)
        {
            DataSet ds = new DataSet();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignDataByID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@CampaignedID", campaignedID);

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;


                    if (showStatus > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ShowStatus", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@ShowStatus"].Value = showStatus;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateFrom", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DateFrom"].Value = fromDate;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateTo", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DateTo"].Value = toDate;

                    sqlDadp.Fill(ds);
                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// For Getting the SMS Campaing Log Information  with Paging and Searching
        /// </summary>
        /// <param name="campaignedID">campaing ID</param>
        /// <param name="pageNo">Page Number</param>
        /// <param name="pageSize">Page Size</param>
        /// <returns></returns>
        public DataSet GetAllCampaingsByID(int campaignedID, int pageNo, int pageSize, string searchText, int showStatus, string fromDate, string toDate)
        {
            DataSet ds = new DataSet();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignDataByIDPaggingSearching", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@CampaignedID", campaignedID);

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateFrom", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DateFrom"].Value = fromDate;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateTo", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DateTo"].Value = toDate;

                    sqlDadp.Fill(ds);
                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// For Getting the SMS Campaing Log Information 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllCampaingsInfo(int? orgID, int? deptId, int? userID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaigns", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (orgID.HasValue && orgID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;
                    }

                    if (deptId.HasValue && deptId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptId;
                    }

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }




                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        public DataTable GetCampaignsByDeptID(int deptID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignsByDeptID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get All Campains Informations
        /// 
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="deptId"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataTable GetAllCampaingsInfo(int? orgID, int? deptId, int? userID, int pageNo, int pageSize)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignsWithPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (orgID.HasValue && orgID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;
                    }

                    if (deptId.HasValue && deptId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptId;
                    }

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;



                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public DataTable GetAllCampaingsInfo(int? orgID, int? deptId, int? userID, int pageNo, int pageSize, string searchText)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignsWithPagingSearch", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (orgID.HasValue && orgID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;
                    }

                    if (deptId.HasValue && deptId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptId;
                    }

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;
                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get Service Response
        /// </summary>
        /// <param name="campaignID"></param>
        /// <returns></returns>
        /// 
        public DataTable SelectServiceResponseInfo(int campaignID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetServiceResponseInfo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get Campaigns Information
        /// </summary>
        /// <param name="orgID">selected Organiaiton ID</param>
        /// <param name="deptId">Selected Department ID</param>
        /// <param name="userID">Current Login User ID</param>
        /// <returns>Campaign DataTable</returns>
        public DataTable GetCampaings(int? orgID, int? deptId, int? userID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaign", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (orgID.HasValue && orgID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;
                    }

                    if (deptId.HasValue && deptId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptId;
                    }

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }




                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        public string GetCampaingSendMessage(int CampaignID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignSendMessage", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = CampaignID;

                    sqlDadp.Fill(dt);
                }
                return dt.Rows[0]["SendMessage"].ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public DataTable GetAllCampaingsInfo(int? organizationID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignsByOrgID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (organizationID.HasValue && organizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;
                    }

                    //if (userID.HasValue && userID.Value > 0)
                    //{
                    //    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    //    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    //}

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }






        /// <summary>
        /// For Getting the SMS Campaing Log Information 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllApiLogByID(int campaignedID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetApiLogByID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@CampaignedID", campaignedID);
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// For Getting the SMS Campaing Log Information  with paging
        /// </summary>
        /// <param name="campaignedID">Selected Campaing ID</param>
        /// <param name="pageNo">Selected Page number</param>
        /// <param name="pageSize">Page Size</param>
        /// <param name="showStatus">show Status in case of 1</param>
        /// <returns></returns>
        public DataSet GetAllApiLogByID(int campaignedID, int pageNo, int pageSize, int showStatus, string fromDate, string toDate)
        {
            DataSet ds = new DataSet();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetApiLogByIDWithPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@CampaignedID", campaignedID);

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;


                    if (showStatus > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ShowStatus", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@ShowStatus"].Value = showStatus;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateFrom", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DateFrom"].Value = fromDate;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateTo", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DateTo"].Value = toDate;

                    sqlDadp.Fill(ds);
                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// For Getting the SMS Campaing Log Information  with paging and search
        /// </summary>
        /// <param name="campaignedID">Selected Campaing ID</param>
        /// <param name="pageNo">Selected Page number</param>
        /// <param name="searchText">Searching Text</param>
        /// <param name="pageSize">Page Size</param>
        /// <param name="showStatus">show Status in case of 1</param>
        /// <returns></returns>
        public DataSet GetAllApiLogByID(int campaignedID, int pageNo, int pageSize, string searchText, int showStatus, string fromDate, string toDate)
        {
            DataSet ds = new DataSet();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetApiLogByIDWithPagingSearch", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@CampaignedID", campaignedID);


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;
                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }


                    if (showStatus > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ShowStatus", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@ShowStatus"].Value = showStatus;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateFrom", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DateFrom"].Value = fromDate;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateTo", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DateTo"].Value = toDate;

                    sqlDadp.Fill(ds);
                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get SMS Campaign Address and Contacts
        /// </summary>
        /// <param name="campaignID">Selected Campaign ID</param>
        /// <returns></returns>
        public DataSet GetSMSCampaignAddressContact(int? campaignID, int? orgID, int? deptID, int? shortcodeID, int? IncomingShortCodeID)
        {
            DataSet ds = new DataSet();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSCampaignAddressContact", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID.Value;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID.Value;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID.Value;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ShortCodeID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@ShortCodeID"].Value = shortcodeID.Value;

                    if (IncomingShortCodeID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IncomingShortCodeID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@IncomingShortCodeID"].Value = IncomingShortCodeID.Value;
                    }




                    sqlDadp.Fill(ds);
                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Update  Campaign Info set as Di Active
        /// </summary>
        /// <param name="model">Campaign Model</param>
        /// <returns></returns>
        public int Delete(SMSCampaignModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteCampaigns";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);
        }



        /// <summary>
        /// This Method is user to get the Trasaction Message Which send from API
        /// CR:001
        /// </summary>
        /// <param name="transactionID">Selected Transaction ID</param>
        /// <returns>Transaction SMS Sending Message</returns>
        public string GetSMSSendMessage(int transactionID)
        {
            DataTable dt = new DataTable();
            string strMessage = "";
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSMessageByTransactionID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SMSTransactionID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@SMSTransactionID"].Value = transactionID;

                    sqlDadp.Fill(dt);
                }
                if (dt.Rows.Count > 0)
                    strMessage = dt.Rows[0]["SendMessage"].ToString();

                return strMessage;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get the Campaign processing Statuses
        /// </summary>
        /// <returns>Processing Status DataTable</returns>
        public DataTable GetProcessingStatuses()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetProcessingStatuses", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }



        /// <summary>
        /// CR:003
        /// Get  Campaignes Schedule Time Slots
        /// </summary>
        /// <param name="fromDate">Selected Date </param>
        /// <returns>Seleced Campaignes Time Slot in DataTable</returns>
        public DataTable GetAllCampaignesSchedule(string fromDate)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllCampaignesSchedule", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.DateTime));
                    sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        public int ReinitiateCampaign(int? campaignID, int? organizationID, int? versionNo)
        {
            SqlConnection con = null;
            int? Ret = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("spValidateRemainingContacts", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                        cmd.Parameters["@CampaignID"].Value = campaignID.Value;

                        cmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        cmd.Parameters["@OrganizationID"].Value = organizationID.Value;

                        cmd.Parameters.Add(new SqlParameter("@VersionNo", SqlDbType.Int));
                        cmd.Parameters["@VersionNo"].Value = versionNo.Value;

                        cmd.Parameters.Add(new SqlParameter("@HasRemain", SqlDbType.VarChar, 50));
                        cmd.Parameters["@HasRemain"].Direction = ParameterDirection.Output;

                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                        Ret = Convert.ToInt32(cmd.Parameters["@HasRemain"].Value);
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
            //throw new NotImplementedException();

            return Ret.Value;
        }
    }
}
