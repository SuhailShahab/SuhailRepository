﻿using BE.RightsManager;
using DAL.Common;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <23-11-2015 03:37 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// 001          Syed Zeeshan Aqil           19-Nov- 2015 12:30 PM       Add Method  GetSMSResponseMessage to get Message
// 002          Syed Zeeshan Aqil           19-Nov- 2015 12:30 PM       Add Method  GetSMSResponses to get SMS REsponses Date
// =================================================================================================================================



    public class SMSInboxDAL : DALBase
    {
        public SMSInboxDAL()
        {

        }
        public SMSInboxDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public SMSInboxDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(SMSTemplateModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteSMSTemplate";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Get SMS Templates
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllSMSTemplates()
        {
            DataTable dt = new DataTable();
            
            try
            {
                using ( SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllSMSTemplates", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //finally
            //{
            //    if (con != null && con.State == ConnectionState.Open)
            //    {
            //        con.Close();
            //        con.Dispose();
            //    }
            //}
        }


        /// <summary>
        /// // 001
        /// This Method is use to get the Transaction Response Message 
        /// </summary>
        /// <param name="responseID">Selected Response ID</param>
        /// <returns>Transaction SMS Response Message</returns>
        public string GetSMSResponseMessage(int responseID,int recordID)
        {
            DataTable dt = new DataTable();
            string strMessage = "";
           
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSResponseMessage", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ResponseID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@ResponseID"].Value = responseID;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RecordID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@RecordID"].Value = recordID;

                    sqlDadp.Fill(dt);
                }
                if (dt.Rows.Count > 0)
                    strMessage = dt.Rows[0]["SMSMessage"].ToString();

                return strMessage;
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }

        /// <summary>
        /// // 002
        ///  This Method use to Get the SMS Responses
        /// </summary>
        /// <param name="search">Search Model</param>
        /// <returns>Get SMS Response Data Table</returns>
        public DataTable GetSMSResponses(SearchModel search)
        {
            DataTable dt = new DataTable();
           
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSResponses", con);
                    sqlDadp.SelectCommand.CommandTimeout = 0;
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (search.OrganizaitonID.HasValue && search.OrganizaitonID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = search.OrganizaitonID.Value;
                    }

                    if (search.DepartmentID.HasValue && search.DepartmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = search.DepartmentID.Value;
                    }

                    if (search.UserID.HasValue && search.UserID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = search.UserID.Value;
                    }

                    if (search.FromDate != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = search.FromDate;
                    }

                    if (search.Todate != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = search.Todate;
                    }

                    if (search.CampaignID.HasValue && search.CampaignID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = search.CampaignID.Value;
                    }


                    if (search.SearchText != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = search.SearchText;
                    }


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = search.PageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = search.PageSize;
                    

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }


        /// <summary>
        /// For Getting SMS Reponse Report Data
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="departmentID"></param>
        /// <param name="campaignID"></param>
        /// <param name="datefrom"></param>
        /// <param name="dateTo"></param>
        /// <param name="Status"></param>
        /// <param name="PhoneNo"></param>
        /// <returns></returns>
        public DataSet GetSMSResponseData(int organizationID, int departmentID, int campaignID, string datefrom, string dateTo, int Status, string PhoneNo)
        {
            DataSet ds = new DataSet();
           
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSResponseData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;

                    if (datefrom != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateFrom", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@DateFrom"].Value = datefrom;
                    }

                    if (dateTo != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateTo", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@Dateto"].Value = dateTo;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Status", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@Status"].Value = Status;

                    if (PhoneNo != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PhoneNo", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@PhoneNo"].Value = PhoneNo;
                    }

                    sqlDadp.Fill(ds);
                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }
    }
}
