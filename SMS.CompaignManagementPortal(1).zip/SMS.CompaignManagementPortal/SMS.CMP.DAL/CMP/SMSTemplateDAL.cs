﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
    public class SMSTemplateDAL : DALBase
    {
        public SMSTemplateDAL()
        {

        }
        public SMSTemplateDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public SMSTemplateDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// Saving sms template Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(SMSTemplateModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddSMSTemplate";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Edit SMS Template Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Edit(SMSTemplateModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditSMSTemplates";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
               // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(SMSTemplateModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteSMSTemplate";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="deptID"></param>
        /// <returns></returns>
        public DataTable GetAllActiveSMSTemplates(int? orgID, int? deptID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveSMSTemplates", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (orgID.HasValue && orgID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;
                    }

                    if (deptID.HasValue && deptID.Value > 0)
                    {

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;
                    }


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get SMS Templates
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllSMSTemplates(int? orgID, int? deptID, int? userID)
       {
           DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllSMSTemplates", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (orgID.HasValue && orgID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;
                    }

                    if (deptID.HasValue && deptID.Value > 0)
                    {

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserId"].Value = userID;

                    sqlDadp.Fill(dt);
                }
               return dt;
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (con != null && con.State == ConnectionState.Open)
               {
                   con.Close();
                   con.Dispose();
               }
           }
       }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="orgID"></param>
        /// <param name="deptID"></param>
        /// <param name="userID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataTable GetAllSMSTemplates(int? orgID, int? deptID, int? userID, int pageNo, int pageSize)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllSMSTemplatesWithPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (orgID.HasValue && orgID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;
                    }

                    if (deptID.HasValue && deptID.Value > 0)
                    {

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserId"].Value = userID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        public DataTable GetAllSMSTemplates(int? orgID, int? deptID, int? userID, int pageNo, int pageSize, string searchText)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllSMSTemplatesWithPagingSearch", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (orgID.HasValue && orgID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;
                    }

                    if (deptID.HasValue && deptID.Value > 0)
                    {

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserId"].Value = userID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }



                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


    }
}
