﻿using DAL.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
    public class InvoiceHistoryDAL : DALBase
    {

         public InvoiceHistoryDAL()
        {
        }
        public InvoiceHistoryDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public InvoiceHistoryDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// Get Payment Invoice Ledger
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <param name="dtFrom"></param>
        /// <param name="dtTo"></param>
        /// <returns></returns>
        public DataTable GetPaymentInvoiceLedger(int organizationID, int? campaignID, DateTime dtFrom, DateTime dtTo)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetPaymentInvoiceLedger", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.DateTime));
                    sqlDadp.SelectCommand.Parameters["@FromDate"].Value = dtFrom;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.DateTime));
                    sqlDadp.SelectCommand.Parameters["@ToDate"].Value = dtTo;
                    if (campaignID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID ", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CampaignID "].Value = campaignID;
                    }
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

    }
}
