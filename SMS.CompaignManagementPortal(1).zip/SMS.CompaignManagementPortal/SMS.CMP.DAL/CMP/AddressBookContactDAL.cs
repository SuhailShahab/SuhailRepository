﻿using DAL.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
    public class AddressBookContactDAL : DALBase
    {

        public AddressBookContactDAL()
        {

        }
        public AddressBookContactDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public AddressBookContactDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /* Not Used in Applicatoin
        public DataTable GetAllsBookContact()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {


                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllAddressBooksContacts", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if(con!=null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        */

        /// <summary>
        /// 
        /// </summary>
        /// <param name="addressBookID"></param>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public DataTable GetAllsBookContactBySearch(int addressBookID, int organizationID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllAddressBooksContactBy", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


      
    }
}
