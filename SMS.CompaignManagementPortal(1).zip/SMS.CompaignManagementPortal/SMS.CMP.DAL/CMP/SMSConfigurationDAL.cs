﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
    public class SMSConfigurationDAL:DALBase
    {        /// <summary>
        /// For Saving the SMS Configuration Information
        /// </summary>
        /// <param name="smsConfigurationModel"></param>
        /// <returns></returns>
        public int Add(SMSConfigurationModel smsConfigurationModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddSMSConfiguration";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(smsConfigurationModel, sqlCmd);
                result = sqlCmd.ExecuteScalar();
                con.Close();
               // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// For Editing the SMS Configuration Information
        /// </summary>
        /// <param name="smsSMSConfigurationModel"></param>
        /// <returns></returns>
        public int Edit(SMSConfigurationModel smsSMSConfigurationModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditSMSConfiguration";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(smsSMSConfigurationModel, sqlCmd);
                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// For Getting the SMS Configuration Information 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable(); 
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spSelectSMSConfiguration", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public DataTable GetActiveTelcos()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetActiveTelcos", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// For Getting the SMS Configuration Information 
        /// </summary>
        /// <returns></returns>
        public DataTable GetConfiguration() 
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSConfiguration", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);}
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public DataTable GetNetworkProvider(string networktypeProviderCode)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetNetworkProvider", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SourceNetworksID", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@SourceNetworksID"].Value = networktypeProviderCode;
                sqlDadp.Fill(dt);}
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
    }
}
