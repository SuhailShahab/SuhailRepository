﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <4-11-2015 01:37 PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// 001          Syed Zeeshan Aqil           24-11-2015 01:37 PM         This method "GetSMSTransactionResponses" user to Get The Transaction Response
// =================================================================================================================================

    public class SMSTransactionDAL : DALBase
    {
        /// <summary>
        /// For Saving the SMS Transaction Information
        /// </summary>
        /// <param name="smsTransactionModel"></param>
        /// <returns></returns>
        public int Add(SMSTransactionModel smsTransactionModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddSMSTransaction";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(smsTransactionModel, sqlCmd);
                result = sqlCmd.ExecuteScalar();
                con.Close();
                // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }
        ///// <summary>
        ///// Add Response Message send by Third Parity
        ///// </summary>
        ///// <param name="smsTransactionModel"></param>
        ///// <returns></returns>
        //public int AddResponseSMS(SMSTransactionModel smsTransactionModel)
        //{
        //    object result = 0;
        //    SqlConnection con = new SqlConnection(this.spConnectionString);
        //    SqlCommand sqlCmd = new SqlCommand();

        //    try
        //    {
        //        con.Open();
        //        sqlCmd.Connection = con;
        //        sqlCmd.CommandType = CommandType.StoredProcedure;
        //        sqlCmd.CommandText = "spAddSMSResponseTransaction";
        //        LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(smsTransactionModel, sqlCmd);
        //        result = sqlCmd.ExecuteScalar();
        //        con.Close();
        //        // return Convert.ToInt32(result);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        if (con.State == ConnectionState.Open)
        //            con.Close();
        //    }
        //    return Convert.ToInt32(result);

        //}

        public int AddInvalidSMSTransaction(SMSTransactionModel smsTransactionModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddInvalidSMSTransaction";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(smsTransactionModel, sqlCmd);
                result = sqlCmd.ExecuteScalar();
                con.Close();
                // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// For Editing the SMS Transaction Information
        /// </summary>
        /// <param name="smsTransactionModel"></param>
        /// <returns></returns>
        public int Edit(SMSTransactionModel smsTransactionModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditSMSTransaction";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(smsTransactionModel, sqlCmd);
                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// For Getting the SMS Transaction Information 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSTransaction", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }



        /// <summary>
        /// For Update SMS Delivery Status
        /// </summary>
        /// <param name="smsTransactionModel"></param>
        /// <returns></returns>
        public int UpdateSMSDeliveryStatus(SMSTransactionModel smsTransactionModel)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdateSMSDeliveryStatus";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter1(smsTransactionModel, sqlCmd);
                result = sqlCmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }


        /// <summary>
        /// For Getting the SMS Transaction Information used in Webportal
        /// </summary>
        /// <returns></returns>
        public DataTable VerifiedUser(int? organizationID, int? CompainedID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spVerifiedUser", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    //sqlDadp.SelectCommand.Parameters.AddWithValue("@OrganizationID", organizationID);
                    //sqlDadp.SelectCommand.Parameters.AddWithValue("@CompainedID", CompainedID);
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CompainedID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CompainedID"].Value = CompainedID;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// For Getting the SMS Transaction Information By Campaign ID
        /// </summary>
        /// <returns></returns>
        public DataTable GetTransactionsByCampaignID(int CampaignID, int mode, string filterdCSVList, string phoneNo, int Status, string dtFrom, string dtTo)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSTransactionByCampainID", con);

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Mode", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@Mode"].Value = mode;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = CampaignID;

                    if (filterdCSVList != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DeliveryStatus", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@DeliveryStatus"].Value = filterdCSVList;
                    }

                    if (phoneNo != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PhoneNo", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@PhoneNo"].Value = phoneNo;
                    }


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Status", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@Status"].Value = Status;

                    if (dtFrom != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateFrom", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@DateFrom"].Value = dtFrom;
                    }

                    if (dtTo != "")
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateTo", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@Dateto"].Value = dtTo;
                    }

                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        public DataTable GetTransactionsDetailByCampaignID(int CampaignID, int mode, string phoneNo)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSTransactionsByCampainID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.AddWithValue("@Mode", mode);
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@CampaignID", CampaignID);

                    if (!string.IsNullOrEmpty(phoneNo))
                    {
                        sqlDadp.SelectCommand.Parameters.AddWithValue("@PhoneNo", phoneNo);

                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// // 001 
        /// This Method is use to get the sms transection responses by campaign and response ID
        /// </summary>
        /// <param name="campaignID">Selectd Capmaign ID</param>
        /// <param name="responseID">Selected Response ID</param>
        /// <returns>Transaction Response DataTable</returns>
        public DataTable GetSMSTransactionResponses(int campaignID, int responseID,string replyPhoneNo,int? recordID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSTransactionResponses", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ResponseID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@ResponseID"].Value = responseID;

                    if (recordID.HasValue && recordID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RecordID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RecordID"].Value = recordID;
                    }
                    

                    if (!string.IsNullOrEmpty(replyPhoneNo))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ContactNo", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@ContactNo"].Value = replyPhoneNo;
                    }


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


    }
}
