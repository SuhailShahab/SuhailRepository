﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
    public class ContactDAL : DALBase
    {
        public ContactDAL()
        {

        }
        public ContactDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public ContactDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// Add Contact Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(ContactModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddContact";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

       

        /// <summary>
        /// Edit Contact Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Edit(ContactModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditContact";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Get Contacts With Paging
        /// </summary>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public DataTable GetAllContactWithPaging(int pageNo, int pageSize, int? userId, int? departmentID, int? organizationID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllContactsPaging", con);
                    sqlDadp.SelectCommand.CommandTimeout = 0;
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (userId.HasValue && userId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserId"].Value = userId.Value;
                    }

                    if (departmentID.HasValue && departmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID.Value;
                    }

                    if (organizationID.HasValue && organizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID.Value;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();                    
                }
            }
        }

      


        /// <summary>
        /// Get All Contacts with Paging with Search Text
        /// </summary>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="userId"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public DataTable GetAllContactWithPaging(int pageNo, int pageSize, int? userId, string searchText, int? departmentID, int? organizationID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllContactsPagingSearch", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (userId.HasValue && userId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserId"].Value = userId.Value;
                    }

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }

                    if (departmentID.HasValue && departmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID.Value;
                    }

                    if (organizationID.HasValue && organizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID.Value;
                    }

                    sqlDadp.SelectCommand.CommandTimeout = 0;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        /// <summary>
        //// Get All Contacts List 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllContacts(int? userId)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllContacts", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (userId.HasValue && userId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserId"].Value = userId.Value;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        //Not User in Application
        /// <summary>
        /// Get All Active Contacts
        /// </summary>
        /// <returns></returns>
        //public DataTable GetAllActiveContacts()
        //{
        //    DataTable dt = new DataTable();
        //    SqlConnection con = null;
        //    try
        //    {
        //        using (con = new SqlConnection(this.spConnectionString))
        //        {
        //            SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveContacts", con);
        //            sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
        //            sqlDadp.Fill(dt);
        //        }
        //        return dt;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        if (con != null && con.State == ConnectionState.Open)
        //        {
        //            con.Close();
        //            con.Dispose();
        //        }
        //    }
        //}

        /// <summary>
        /// Get Active Contacts By Org ID
        /// </summary>
        /// <param name="OrganizationID"></param>
        /// <returns></returns>
        public DataTable GetAllContacts(int OrganizationID, int departmentID, int pageNo, int pageSize,int? campaignID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllContactsByOrgID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (OrganizationID > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = OrganizationID;
                    }
                    if (departmentID > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    if (campaignID.HasValue && campaignID.Value>0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get Active Contacts By Org ID
        /// </summary>
        /// <param name="OrganizationID"></param>
        /// <returns></returns>
        public DataTable SearchContacts(int OrganizationID, int departmentID, int pageNo, int pageSize, string searchText,int? campaignID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spSearchContacts", con);
                    sqlDadp.SelectCommand.CommandTimeout = 0;
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (OrganizationID > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = OrganizationID;
                    }
                    if (departmentID > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    if (campaignID.HasValue && campaignID.Value >0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get GetAllActiveContacts by OrgID & Address Book
        /// </summary>
        /// <param name="OrganizationID"></param>
        /// <returns></returns>
        public DataTable GetAllActiveContacts(int organizationID, int? departmenID, int addressBookID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllContactsByOrgIDAndAddrBookID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;

                    if (departmenID.HasValue && departmenID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmenID.Value;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /*
        //Not use in application
        /// <summary>
        /// Get All Active Contacts For view only
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="addressBookID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataTable GetAllActiveContactsForViewOnly(int organizationID, int addressBookID, int pageNo, int pageSize)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveContactsViewOnlyWithPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;



                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        */
        /* Not Used in Application
        public DataTable GetAllActiveContacts(int organizationID, int? departmenID, int addressBookID, int pageNo, int pageSize)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveContactsWithPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;

                    if (departmenID.HasValue && departmenID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmenID.Value;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    //sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IncludeAll", SqlDbType.Bit));
                    //sqlDadp.SelectCommand.Parameters["@IncludeAll"].Value = IncludeAll;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
         
         */
        public DataTable GetAddressBookContacts(int organizationID, int? departmenID, int addressBookID, int pageNo, int pageSize,bool? isView)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAddressBookContactsPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.CommandTimeout = 0;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;

                    if (departmenID.HasValue && departmenID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmenID.Value;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IsView", SqlDbType.Bit));
                    sqlDadp.SelectCommand.Parameters["@IsView"].Value = isView;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        /* Not Used in Application
        public DataTable GetAllActiveContacts(int organizationID, int? departmenID, int addressBookID, int pageNo, int pageSize, bool IncludeAll, string searchText)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveContactsWithPagingSearch", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;

                    if (departmenID.HasValue && departmenID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmenID.Value;
                    }


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IncludeAll", SqlDbType.Bit));
                    sqlDadp.SelectCommand.Parameters["@IncludeAll"].Value = IncludeAll;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
         */
        public DataTable GetAddressBookContactSearch(int organizationID, int? departmenID, int addressBookID, int pageNo, int pageSize, bool IncludeAll, string searchText)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAddressBookContactsWithPagingSearch", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;

                    if (departmenID.HasValue && departmenID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmenID.Value;
                    }


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IncludeAll", SqlDbType.Bit));
                    sqlDadp.SelectCommand.Parameters["@IncludeAll"].Value = IncludeAll;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="addressBookID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataTable GetAllActiveContacts(int organizationID, int addressBookID, int pageNo, int pageSize)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetContactsWithPaging", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public DataTable GetAllActiveContacts(int organizationID, int addressBookID, int pageNo, int pageSize, string searchText)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetContactsWithPagingSearch", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AddressBookID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AddressBookID"].Value = addressBookID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get All Contacts on which sms are not send
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="addressBookID"></param>
        /// <returns></returns>
        public DataTable GetCampaignContacts(int? organizationID, int? campaignID,int? versionNo, bool IsBuffered)
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignContacts", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;
                    if (versionNo.HasValue && versionNo.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VersionNo", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@VersionNo"].Value = versionNo;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IsBuffered", SqlDbType.Bit));
                    sqlDadp.SelectCommand.Parameters["@IsBuffered"].Value = IsBuffered;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public bool IsExistCampaignContact(int? organizationID, int? campaignID, int? versoinNo )
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spIsExistCampaignContact", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VersionNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@VersionNo"].Value = versoinNo;



                    sqlDadp.Fill(dt);
                }

                if (dt != null && dt.Rows.Count > 0)
                {
                    return Convert.ToBoolean(dt.Rows[0][0]);
                }

                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Disable Contact Entry
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(ContactModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteContact";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteNonQuery());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

    }
}
