﻿using DAL.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
   public class FinalPaymentInvoiceDAL : DALBase
    {

        public FinalPaymentInvoiceDAL()
        {
        }
        public FinalPaymentInvoiceDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public FinalPaymentInvoiceDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }


        /// <summary>
        /// Get final payment invoice title
        /// </summary>
        /// <returns></returns>
        public DataTable GetFinalPaymentInvoiceTitles(int orgID, int deptID)
        {
            DataTable dt = new DataTable ();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetFinalPaymentInvoiceTitles", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizaitonID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizaitonID"].Value = orgID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;

                    sqlDadp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
            return dt;
        }


    }
}
