﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
    public class InvoiceDAL : DALBase
    {

        public InvoiceDAL()
        {
        }
        public InvoiceDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public InvoiceDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }



        /// <summary>
        /// Add Invoice Info
        /// </summary>
        /// <param name="model">Mask Model</param>
        /// <returns></returns>
        public int Add(InvoiceModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddInvoice";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Edit Mask Info
        /// </summary>
        /// <param name="model">Mask Model</param>
        /// <returns></returns>
        public int Edit(InvoiceModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditInvoice";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }


        /// <summary>
        /// Get all Invoice Info
        /// </summary>
        /// <returns>Invoice Table info</returns>
        public DataTable GetAllInvoiceInfo(int? organizationID, int? departmentID, int? campaignID, int? PageNo, int? PageSize, string searchText)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetInvoiceInfo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (organizationID.HasValue && organizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID.Value;
                    }

                    if (departmentID.HasValue && departmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID.Value;
                    }

                    if (campaignID.HasValue && campaignID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID.Value;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = PageNo.Value;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = PageSize.Value;

                    if (!string.IsNullOrEmpty(searchText))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get Payable Amount Info
        /// </summary>
        /// <returns></returns>
        public DataTable GetPayableAmount(int departmentID, int organizationID, int campaignID, string dateofInvoice)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetPayableAmount", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateofInvoice", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DateofInvoice"].Value = dateofInvoice;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }



        /// <summary>
        /// Get Payment Invoice 
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <param name="dtFrom"></param>
        /// <param name="dtTo"></param>
        /// <returns></returns>
        public DataTable GetPaymentInvoice(int organizationID,  int paymentMode, int finalPaymentInvoiceID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetPaymentInvoice", con);

                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Mode", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@Mode"].Value = paymentMode;

                    //sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.DateTime));
                    //sqlDadp.SelectCommand.Parameters["@FromDate"].Value = dtFrom;

                    //sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.DateTime));
                    //sqlDadp.SelectCommand.Parameters["@ToDate"].Value = dtTo;

                    //if (campaignID.HasValue)
                    //{
                    //    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID ", SqlDbType.Int));
                    //    sqlDadp.SelectCommand.Parameters["@CampaignID "].Value = campaignID;
                    //}

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FinalPaymentInvoiceID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@FinalPaymentInvoiceID"].Value = finalPaymentInvoiceID;



                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get all campaign Payment Invoice 
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <param name="dtFrom"></param>
        /// <returns></returns>
        public DataTable GetAllCampaignPaymentInvoice(int? organizationID, int? DepartmentID, DateTime dateOfInvoice)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllCampaignPaymentInvoice", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DateofInvoice", SqlDbType.DateTime));
                    sqlDadp.SelectCommand.Parameters["@DateofInvoice"].Value = dateOfInvoice;

                    if (organizationID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;
                    }

                    if (DepartmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = DepartmentID;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get Campaign Payement Invoice Data by Final Invoice ID
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <param name="dtFrom"></param>
        /// <returns></returns>
        public DataTable GetCampaignPaymentInvoiceInfo(string FinalInvoiceNo)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCampaignPaymentInvoiceInfo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FinalInvoiceNo", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@FinalInvoiceNo"].Value = FinalInvoiceNo;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get final Payment Invoice 
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <param name="dtFrom"></param>
        /// <returns></returns>
        public DataTable GetFinalPaymentInvoice()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetFinalPaymentInvoice", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        
        /// <summary>
        /// Add Invoice Info
        /// </summary>
        /// <param name="model">Mask Model</param>
        /// <returns></returns>
        public int SaveFinalInvoice(DataTable dtInvoiceIDs, int CreatedBy)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddFinalInvoiceInfo";

                sqlCmd.Parameters.Add(new SqlParameter("@PaymentInvoiceInfo", SqlDbType.Structured));
                sqlCmd.Parameters["@PaymentInvoiceInfo"].Value = dtInvoiceIDs;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = CreatedBy;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
               // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

    }
}
