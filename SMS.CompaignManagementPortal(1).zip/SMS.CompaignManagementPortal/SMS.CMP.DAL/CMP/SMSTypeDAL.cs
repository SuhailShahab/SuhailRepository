﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
    public class SMSTypeDAL : DALBase
    {
        public int Add(SMSTypesModel smsTypeModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddSMSType";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(smsTypeModel, sqlCmd);
                //SqlUtility.GetAddParameter(smsTypeModel, sqlCmd);
                result = sqlCmd.ExecuteScalar();
                con.Close();
               // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }


        public int Edit(SMSTypesModel smsTypeModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.CommandText = "spEditDistrict";
                sqlCmd.CommandText = "spEditSMSType";
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(smsTypeModel, sqlCmd);
               // SqlUtility.GetAddParameter(smsTypeModel, sqlCmd);
                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        public DataTable GetAll()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAlleSMSTypes", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public int Delete(int SMSTypeID)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.CommandText = "spEditDistrict";
                sqlCmd.CommandText = "spDeleteSMSType";

                sqlCmd.Parameters.Add(new SqlParameter("@SMSTypeID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@SMSTypeID"].Value = SMSTypeID;

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }
    }
}
