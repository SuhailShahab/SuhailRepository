﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.CMP
{
    public class PaymentDAL : DALBase
    {

        public PaymentDAL()
        {

        }

        public PaymentDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }

        public PaymentDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// Get All Purchased Bucket History Records
        /// </summary>
        /// <param name="orgID">Selected Organizaiton ID</param>
        /// <param name="deptID">Selected Department ID</param>
        /// <param name="userID">Selected User ID</param>
        /// <returns>Payment Data Table</returns>
        public DataTable GetPurchasedBucketsHistoryByOrgID(int? orgID, int? deptId, int? userID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("GetPurchasedBucketsHistoryByOrgID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    if (orgID.HasValue && orgID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;
                    }

                    if (deptId.HasValue && deptId.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptId;
                    }

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get Payments
        /// </summary>
        /// <param name="LoginID"></param>
        /// <param name="OrganizationID"></param>
        /// <returns></returns>
        public DataTable GetPayment(int? LoginID, int? OrganizationID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("GetPayments", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                if (LoginID.HasValue && OrganizationID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = OrganizationID;
                }

                if (OrganizationID.HasValue && LoginID.Value > 0 )
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@userID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@userID"].Value = LoginID;
                }

                sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get Payment By campaignID
        /// </summary>
        /// <param name="LoginID"></param>
        /// <param name="OrganizationID"></param>
        /// <param name="campaignID"></param>
        /// <returns></returns>
        public DataTable GetPayment(int? LoginID, int? OrganizationID, int campaignID, DateTime fromDate, DateTime toDate, int departmentID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("GetPaymentsByCampaignID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;



                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                    sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                    sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate;

                    if (LoginID.HasValue && LoginID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = OrganizationID;
                    }

                    if (OrganizationID.HasValue && OrganizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@userID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@userID"].Value = LoginID;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }    

    }
}
