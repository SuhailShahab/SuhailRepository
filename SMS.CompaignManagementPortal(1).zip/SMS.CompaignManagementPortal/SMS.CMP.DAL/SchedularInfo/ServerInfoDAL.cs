﻿using DAL.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.SchedularInfo
{
    public class ServerInfoDAL : DALBase
    {
        public bool IsActiveServer(int? id)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection dbConnection = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetServerByID", dbConnection);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@ID"].Value = id;

                    sqlDadp.Fill(dt);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        return Convert.ToBoolean(dt.Rows[0]["IsRunning"]);
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int? UpdateServerActive(int? id)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "UpdateActiveServer";

                sqlCmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ID"].Value = id;



                result = sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                    con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }
    }
}
