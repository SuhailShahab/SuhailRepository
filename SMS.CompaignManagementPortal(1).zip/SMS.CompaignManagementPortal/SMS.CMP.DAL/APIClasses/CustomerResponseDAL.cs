﻿using DAL.Common;
using SMS.CMP.BE.APIClasses;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Create date: <05-11-2015 11:05AM>
// =================================================================================================================================
// SR#              Created By                 Modified Date/Time          Desription
// 000              Suhail Shahab                                          This class is using in Web API (Inter API). This class 
//                                                                         save the customer response form mobile
// ===================================================== Modification History ======================================================
// SR#              Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
namespace SMS.CMP.DAL.APIClasses
{
    public class CustomerResponseDAL : DALBase
    {
        /// <summary>
        /// Save the customer response form mobile
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int? AddResponse(CustomerResponseModel model)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddCustomerResponse";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return result;

        }
        public int? AddConfirmation(CustomerResponseModel model)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddCustomerConfirmation";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                //return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return result;

        }

        public DataTable GetResponse(int? campaignID, string replyPhoneNo)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCustomerResponse", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CampaignID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@CampaignID"].Value = campaignID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ReplyPhoneNo", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@ReplyPhoneNo"].Value = replyPhoneNo;

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int? UpdateSMSConfrimatonInfo(CustomerResponseModel model)
        {
            int? result ;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdateSMSConfirmationInfo";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
                // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return result;
        }
    }
}
