﻿using DAL.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BE.Lookups;

namespace DAL.Lookups
{
    public class ErrorLogDAL:DALBase
    {
        /// <summary>
        /// Get Error Record from loG
        /// </summary>
        /// <param name="logID"></param>
        /// <param name="LocationID"></param>
        /// <param name="ServiceID"></param>
        /// <param name="DivisionID"></param>
        /// <param name="DistrictID"></param>
        /// <param name="PageName"></param>
        /// <param name="dateFrom"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public DataTable GetErrorRecords(ErrorLogModel ErrorLogModel)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetErrorLogRecords", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (ErrorLogModel.PageStaticName != null)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageName", SqlDbType.NVarChar));
                        sqlDadp.SelectCommand.Parameters["@PageName"].Value = ErrorLogModel.PageStaticName.Trim();
                    }
                    if (ErrorLogModel.logID > 0 && ErrorLogModel.logID != null)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@logID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@logID"].Value = ErrorLogModel.logID;
                    }
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dateFrom", SqlDbType.DateTime));
                    if (ErrorLogModel.FromDate != null)
                        sqlDadp.SelectCommand.Parameters["@dateFrom"].Value = ErrorLogModel.FromDate;
                    else
                        sqlDadp.SelectCommand.Parameters["@dateFrom"].Value = DateTime.Now;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dateTo", SqlDbType.DateTime));

                    if (ErrorLogModel.ToDate != null)
                        sqlDadp.SelectCommand.Parameters["@dateTo"].Value = ErrorLogModel.ToDate;
                    else
                        sqlDadp.SelectCommand.Parameters["@dateTo"].Value = DateTime.Now;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public DataTable GetErrorRecords()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetErrorLogRecords", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dateFrom", SqlDbType.DateTime));

                    sqlDadp.SelectCommand.Parameters["@dateFrom"].Value = DateTime.Now;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dateTo", SqlDbType.DateTime));

                    sqlDadp.SelectCommand.Parameters["@dateTo"].Value = DateTime.Now;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public DataTable GetErrorLogsBySearchCretira(int? searchByID, string searchByMessage)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {

                    using (SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDataByIDandTextFromErrorLog", con))
                    {
                        sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                        if (searchByID.HasValue && searchByID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchType", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@SearchType"].Value = searchByID;
                        }

                        if (!string.IsNullOrEmpty(searchByMessage))
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                            sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchByMessage;
                        }


                        sqlDadp.Fill(dt);
                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int AddError(ErrorLogModel error)
        {
            object result = 0;

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;

                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddApplicationErrorLog";

                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@Method", SqlDbType.VarChar));
                            sqlCmd.Parameters["@Method"].Value = error.Method;
                        }


                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@Message", SqlDbType.VarChar));
                            sqlCmd.Parameters["@Message"].Value = error.Message;
                        }

                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar));
                            sqlCmd.Parameters["@StackTrace"].Value = error.StackTrace;
                        }

                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@Source", SqlDbType.VarChar));
                            sqlCmd.Parameters["@Source"].Value = error.Source;
                        }
                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@PageName", SqlDbType.VarChar));
                            sqlCmd.Parameters["@PageName"].Value = error.PageName;
                        }
                        result = sqlCmd.ExecuteScalar();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt32(result);
        }

        public int Add(ErrorLogModel error)
        {
            object result = 0;

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddApplicationErrorLog";

                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@Method", SqlDbType.VarChar));
                            sqlCmd.Parameters["@Method"].Value = error.Method;
                        }


                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@Message", SqlDbType.VarChar));
                            sqlCmd.Parameters["@Message"].Value = error.Message;
                        }

                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar));
                            sqlCmd.Parameters["@StackTrace"].Value = error.StackTrace;
                        }

                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@Source", SqlDbType.VarChar));
                            sqlCmd.Parameters["@Source"].Value = error.Source;
                        }


                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt32(result);
        }
    }
}
