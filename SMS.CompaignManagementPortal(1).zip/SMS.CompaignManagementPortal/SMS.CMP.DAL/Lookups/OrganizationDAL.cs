﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using DAL.Common;
using BE.Lookups;


namespace DAL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    //   001             Sajjad Aslam           17-03-2017 03:20 PM     add finally block to close connection 
    // =================================================================================================================================
    public class OrganizationDAL : DALBase
    {
        /// <summary>
        /// save Department information
        /// </summary>
        /// <param name="relationModel">Set object of DepartmentModel type</param>
        /// <returns></returns>
        public int Add(OrganizationModel organizationModel)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddOrganization";

                // LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameter(departmentModel, false, sqlCmd);               

                SetSqlParameters(organizationModel, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = organizationModel.CreatedBy;

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                //con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
            return result;
        }

        private static void SetSqlParameters(OrganizationModel organizationModel, SqlCommand sqlCmd)
        {
            sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Code"].Value = organizationModel.Code;

            sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Title"].Value = organizationModel.Title;

            sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Description"].Value = organizationModel.Description;


            sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
            bool status = organizationModel.Status ?? false;
            sqlCmd.Parameters["@IsActive"].Value = status ? 1 : 0;

        }

        /// <summary>
        /// Update Department information
        /// </summary>
        /// <param name="organizationModel">Set object of DepartmentModel type</param>
        /// <returns></returns>
        public int Edit(OrganizationModel organizationModel)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditOrganization";

                sqlCmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                sqlCmd.Parameters["@OrganizationID"].Value = organizationModel.ID;
                SetSqlParameters(organizationModel, sqlCmd);
                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = organizationModel.CreatedBy;

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                //con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
            return result;
        }

        /// <summary>
        /// Delete Department information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, int modifiedBy)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteOrganization";

                sqlCmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                sqlCmd.Parameters["@OrganizationID"].Value = id;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = Convert.ToInt32(modifiedBy);

                result = sqlCmd.ExecuteNonQuery();
               // con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
            return result;
        }
        /// <summary>
        /// Get all Active Department
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetorganizations", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        public DataTable GetAllOrganizations()
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllOrganization", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        /// <summary>
        /// Get all Department
        /// </summary>
        /// <returns></returns>
        public DataTable SelectOrganizationByUserID(int userID)
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetOrganization", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@UserID", userID);

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        public DataTable SelectOrganization(int id)
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetOrganizationByID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = id;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        public DataTable SelectOrganization(int? userID, int? organizationID)
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserOrganizations", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (organizationID.HasValue && organizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;
                    }
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


    }
}
