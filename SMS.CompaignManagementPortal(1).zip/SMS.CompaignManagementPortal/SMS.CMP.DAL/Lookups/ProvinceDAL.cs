﻿using BE.Lookups;
using DAL.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Lookups
{
    public class ProvinceDAL : DALBase
    {
        public ProvinceDAL()
        {

        }
        public ProvinceDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public ProvinceDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }


        /// <summary>
        /// save GeneralDistrict information
        /// </summary>
        /// <param name="relationModel">Set object of GeneralDistrictModel type</param>
        /// <returns></returns>
        public int Add(ProvinceModel provinceModel)
        { 
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                // sqlCmd.CommandText = "spAddDistrict";
                sqlCmd.CommandText = "spAddProvince";

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = provinceModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = provinceModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = provinceModel.IsActive ? 1 : 0;

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Update District information
        /// </summary>
        /// <param name="provinceModel">Set object of DistrictModel type</param>
        /// <returns></returns>
        public int Edit(ProvinceModel provinceModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.CommandText = "spEditDistrict";
                sqlCmd.CommandText = "spEditProvince";

                sqlCmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int));
                sqlCmd.Parameters["@ID"].Value = provinceModel.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = provinceModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = provinceModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = provinceModel.IsActive ? 1 : 0;

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Delete District information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                //_sqlCmd.CommandText = "spDeleteDistrict";
                _sqlCmd.CommandText = "spDeleteProvince";

                _sqlCmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int));
                _sqlCmd.Parameters["@ID"].Value = id;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }


        public DataTable GetAllProvinces()
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllProvinces", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        public DataTable GetAllActiveProvinces() 
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveProvinces", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }



        public DataTable GetProvincesByID(int id)
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetProvincesByID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return dt;
        }
    }
}
