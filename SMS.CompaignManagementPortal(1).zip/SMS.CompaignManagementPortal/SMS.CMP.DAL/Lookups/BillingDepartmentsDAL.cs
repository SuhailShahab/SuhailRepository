﻿using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using DAL.Common;
using BE.Lookups;

namespace DAL.Lookups
{
    // Created by:	<Muhammad Shakeel>
    // Created date: <22-03-2018>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================

    public class BillingDepartmentDAL : DALBase
    {
        public int? Save(DataTable dt, int? billingDptID, int? userID)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spSaveBillingDepartment";

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = userID;

                sqlCmd.Parameters.Add(new SqlParameter("@BillingDptID", SqlDbType.Int));
                sqlCmd.Parameters["@BillingDptID"].Value = billingDptID;

                sqlCmd.Parameters.Add(new SqlParameter("@udBillingDept", SqlDbType.Structured));
                sqlCmd.Parameters["@udBillingDept"].Value = dt;

                result = sqlCmd.ExecuteNonQuery();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public int Delete(BillingDepartmentModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteBillingDepartment";

                sqlCmd.Parameters.Add(new SqlParameter("@BillingDptID", SqlDbType.Int));
                sqlCmd.Parameters["@BillingDptID"].Value = model.BillingDptID;

                sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                sqlCmd.Parameters["@DepartmentID"].Value = model.DepartmentID;

                result = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
            return result;
        }

        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetBillingDepartment", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

    }
}