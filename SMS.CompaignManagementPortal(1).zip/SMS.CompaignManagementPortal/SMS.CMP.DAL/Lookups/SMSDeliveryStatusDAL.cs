﻿using DAL.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.Lookups
{
    public class SMSDeliveryStatusDAL : DALBase
    {

        /// <summary>
        /// Get All SMS Delivery Status
        /// </summary>
        /// <returns></returns>
        public DataTable GetSMSDeliveryStatus()
        {
            DataTable dt = new DataTable();
            
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllSMSDeliveryStatus", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return dt;
        }

        /// <summary>
        /// Get All SMS Delivery Status By UserID
        /// </summary>
        /// <returns></returns>
        public DataTable GetSMSDeliveryStatusByUserID(int _userID)
        {
            DataTable dt = new DataTable();


            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSMSDeliveryStatusByUserID", con);
                    
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = _userID;

                    sqlDadp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return dt;
        }

    }
}
