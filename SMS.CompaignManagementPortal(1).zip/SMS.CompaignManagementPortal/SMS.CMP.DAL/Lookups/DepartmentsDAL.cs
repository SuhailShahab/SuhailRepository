﻿using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using DAL.Common;
using BE.Lookups;

namespace DAL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <26-12-2014 08:30PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time      Desription
    // 001          Muhammad Usman              30-Sep-2015             Add Method Permitted Districts
    // 002          Syed Zeeshan Aqil           30-Oct-2015             Add Method GetDepartmentByOrgIDByUserID
    // 003          Sajjad Aslam                17-03-2017 03:25 PM     add finally block to close connection 
    // =================================================================================================================================

    public class DepartmentsDAL : DALBase
    {
        /// <summary>
        /// save Departments information
        /// </summary>
        /// <param name="relationModel">Set object of Departments type</param>
        /// <returns></returns>
        public int? Add(DepartmentsModel departmentModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddDepartments";

                AddCommonParameters(departmentModel, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = departmentModel.CreatedBy;


                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                //con.Close();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
            return null;

        }

        /// <summary>
        /// Update Department information
        /// </summary>
        /// <param name="districtModel">Set object of Department type</param>
        /// <returns></returns>
        public int? Edit(DepartmentsModel departmentModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.CommandText = "spEditDistrict";
                sqlCmd.CommandText = "spEditDepartments";


                AddCommonParameters(departmentModel, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@DepartmentID"].Value = departmentModel.DepartmentID;


                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = departmentModel.CreatedBy;


                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                //con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return result;
        }

        /// <summary>
        /// Add Common Parameters
        /// </summary>
        /// <param name="departmentModel"></param>
        /// <param name="sqlCmd"></param>
        private static void AddCommonParameters(DepartmentsModel departmentModel, SqlCommand sqlCmd)
        {
            sqlCmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.NVarChar));
            sqlCmd.Parameters["@OrganizationID"].Value = departmentModel.OrganizationID;

            sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Title"].Value = departmentModel.Title;

            sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Code"].Value = departmentModel.Code;

            sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Description"].Value = departmentModel.Description;

            sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
            bool status = departmentModel.Status ?? false;
            sqlCmd.Parameters["@IsActive"].Value = status ? 1 : 0;

            sqlCmd.Parameters.Add(new SqlParameter("@PerSMSRate", SqlDbType.Decimal));
            sqlCmd.Parameters["@PerSMSRate"].Value = departmentModel.PerSMSRate;

            if (departmentModel.SMSLimit.HasValue)
            {
                sqlCmd.Parameters.Add(new SqlParameter("@SMSLimit", SqlDbType.Int));
                sqlCmd.Parameters["@SMSLimit"].Value = departmentModel.SMSLimit;
            }

            if (departmentModel.IsAllowedCampaingName.HasValue)
            {
                sqlCmd.Parameters.Add(new SqlParameter("@IsAllowedCampaingName", SqlDbType.Bit));
                sqlCmd.Parameters["@IsAllowedCampaingName"].Value = departmentModel.IsAllowedCampaingName;
            }

            
        }

        /// <summary>
        /// Delete Department information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteDepartments";

                _sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                _sqlCmd.Parameters["@DepartmentID"].Value = id;

                _result = _sqlCmd.ExecuteNonQuery();
                //_con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con != null && _con.State == ConnectionState.Open)
                {
                    _con.Close();
                    _con.Dispose();
                }
            }
            return _result;
        }

        /// <summary>
        /// Get all Departments use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartments", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get all Departments by Organization ID use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable SelectActiveDepartmentsByOrgID(int organizationID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetActiveDepartmentsByOrganizationID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@OrganizationID", organizationID);
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get All User department against organistaion ID
        /// </summary>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public DataTable SelectActiveDepartmentsByOrgID(int? organizationID, int? userID, int? departmentID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserDepartmentsByOrganizationID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (departmentID.HasValue && departmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    if (organizationID.HasValue && organizationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;

                    }
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get all Departments by Multiple organization ID use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable SelectDepartmentsByMultiOrgID(string organizationID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartmentsByMultiOrganizationID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.AddWithValue("@OrganizationID", organizationID);
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get all districts
        /// CR:001
        /// Mofied the sp name by suhail shahab. now sp is get all active disticts
        /// </summary>
        /// <returns></returns>
        public DataTable SelectDistricts()
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    //SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrict", con);
                    // SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistrict", con);
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllGeneralDistricts", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get  districts by Division ID
        /// CR:002
        /// </summary>
        /// <returns></returns>
        public DataTable GetDistrictsByDivisionID(int DivisionID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    //SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictByDivisionID", con);
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistrictByDivisionID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = DivisionID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get all Departments use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable GetActiveDepartments()
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetActiveDepartments", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }



        /// <summary>
        /// //002
        /// Get Departments  Info By Organization and User base
        /// </summary>
        /// <param name="orgID"> Current Selected Organization ID</param>
        /// <param name="userID">Current Login User ID</param>
        /// <returns>Department DataTable</returns>
        public DataTable GetDepartmentByOrgIDByUserID(int orgID, int userID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartmentsByOrgIDByUserID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get  districts by Division ID
        /// CR:002
        /// </summary>
        /// <returns></returns>
        public DataTable GetDepatmentsByUserID(int userID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepatmentsByUserID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// This method will be user for user, 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="organizationID"></param>
        /// <param name="departmentID"></param>
        /// <returns></returns>
        public DataTable spGetUserDeptByIDs(int userID, int? organizationID, int? departmentID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserDeptByIDs", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    if (organizationID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = organizationID;
                    }

                    if (organizationID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public DataTable GetBillingDepartments()
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetBillingDepartments", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        public DataTable GetDepartmentsByBillingDptID(int? billingDptID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartmentsByBillingDptID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@BillingDptID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@BillingDptID"].Value = billingDptID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
    }
}
