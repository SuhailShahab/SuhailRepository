﻿using DAL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.Lookups
{

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <16-10-2015 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================


    public class MaskDAL : DALBase
    {

         public MaskDAL()
        {

        }
        public MaskDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public MaskDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// Add Mask Info
        /// </summary>
        /// <param name="model">Mask Model</param>
        /// <returns></returns>
        public int Add(MaskModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddMask";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Edit Mask Info
        /// </summary>
        /// <param name="model">Mask Model</param>
        /// <returns></returns>
        public int Edit(MaskModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditMask";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Get all Mask Info
        /// </summary>
        /// <returns>Mask Table info</returns>
        public DataTable GetAllMasks()
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllMasks", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get all Mask Info by Short COde ID 
        /// </summary>
        /// <returns>Mask Table info</returns>
        public DataTable GetMasksByShortCodeID(int shortCodeiD,int departmentID)
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetMaskByShortCodeID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ShortCodeID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@ShortCodeID"].Value = shortCodeiD;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get All Active Mask info
        /// </summary>
        /// <returns>Mask Table Info</returns>
        public DataTable GetAllActiveMasks()
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveMasks", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Delte Mask Info By ID
        /// </summary>
        /// <param name="model">Mask Model</param>
        /// <returns></returns>
        public int Delete(MaskModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();
            MaskModel mod = new MaskModel();
            mod.Status = model.Status;
            mod.ID = model.ID;
            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteMaskByID";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(mod, sqlCmd);

                //sqlCmd.Parameters.Add(new SqlParameter("@MaskID", SqlDbType.Int));
                //sqlCmd.Parameters["@MaskID"].Value = model.MaskID;

                //sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                //sqlCmd.Parameters["@IsActive"].Value = model.Status ? 1 : 0;


                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

    }
}
