﻿using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using DAL.Common;
using BE.Lookups;

namespace DAL.Lookups
{
    // =================================================================================================================================
    // Create by:	<syed Zeeshan Aqil>
    // Create date: <18-08-2014 02:01 PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class DivisionDAL : DALBase
    {
        /// <summary>
        /// save Division information
        /// </summary>
        /// <param name="relationModel">Set object of DivisionModel type</param>
        /// <returns></returns>
        public int? Add(DivisionModel divisionModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddDivision";

                //sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@Title"].Value = divisionModel.Title;

                //sqlCmd.Parameters.Add(new SqlParameter("@TitleUrdu", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@TitleUrdu"].Value = divisionModel.TitleUrdu;

                //sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@Description"].Value = divisionModel.Description;

                //sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@Code"].Value = divisionModel.Code;

                //sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                //sqlCmd.Parameters["@IsActive"].Value = divisionModel.Status ? 1 : 0;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = divisionModel.CreatedBy;
                SetSqlParameters(divisionModel, sqlCmd);

                result = sqlCmd.ExecuteScalar();
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return null;

        }

        /// <summary>
        /// Update Division information
        /// </summary>
        /// <param name="divisionModel">Set object of DivisionModel type</param>
        /// <returns></returns>
        public int? Edit(DivisionModel divisionModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditDivision";

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@DivisionID"].Value = divisionModel.ID;

                SetSqlParameters(divisionModel, sqlCmd);
                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = divisionModel.CreatedBy;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        private static void SetSqlParameters(DivisionModel divisionModel, SqlCommand sqlCmd)
        {
            sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Title"].Value = divisionModel.Title;

            //sqlCmd.Parameters.Add(new SqlParameter("@TitleUrdu", SqlDbType.NVarChar));
            //sqlCmd.Parameters["@TitleUrdu"].Value = divisionModel.TitleUrdu;

            sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Description"].Value = divisionModel.Description;

            sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Code"].Value = divisionModel.Code;

            sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
            bool status = divisionModel.Status ?? false;
            sqlCmd.Parameters["@IsActive"].Value = status ? 1 : 0;

            sqlCmd.Parameters.Add(new SqlParameter("@ProvinceID", SqlDbType.Int));
            sqlCmd.Parameters["@ProvinceID"].Value = divisionModel.ProvinceID;
        }

        /// <summary>
        /// Delete Division information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, int modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteDivision";

                _sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                _sqlCmd.Parameters["@DivisionID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Get all Active Divisions use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDivisions", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get all Active Divisions use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll(int? divisionID)
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDivisions", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    if (divisionID.HasValue && divisionID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                    }


                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Get all Division
        /// </summary>
        /// <returns></returns>
        public DataTable Select()
        {
            DataTable dt = new DataTable();

            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDivision", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


    }
}
