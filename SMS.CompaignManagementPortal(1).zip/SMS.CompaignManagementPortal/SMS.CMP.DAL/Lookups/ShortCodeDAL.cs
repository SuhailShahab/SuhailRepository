﻿using DAL.Common;
using SMS.CMP.BE.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.Lookups
{
    public class ShortCodeDAL : DALBase
    {

        /// <summary>
        /// Saving Short Code Information
        /// </summary>
        /// <param name="shortCodeModel"></param>
        /// <returns></returns>
        public int Add(ShortCodeModel shortCodeModel)
        {
            object result = 0;

            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddShortCode";


                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(shortCodeModel, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();

                // return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Edit Short Code info
        /// </summary>
        /// <param name="shortCodeModel"></param>
        /// <returns></returns>
        public int Edit(ShortCodeModel shortCodeModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.CommandText = "spEditShortCode";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(shortCodeModel, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Delete Short Code
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(ShortCodeModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //_sqlCmd.CommandText = "spDeleteDistrict";
                sqlCmd.CommandText = "spDeleteShortCode";

                //sqlCmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int));
                //sqlCmd.Parameters["@ID"].Value = id;

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, sqlCmd);

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// Getting All Short Codes
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllShortCodes()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllShortCodes", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }


        /// <summary>
        /// Getting Short Codes by organization ID
        /// </summary>
        /// <returns></returns>
        public DataTable GetShortCodesByOrganizationID(int orgID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("GetShortCodesByOrgID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        public DataTable GetShortCodesByOrganizationIDs(string oragainzationIDs)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserShortCodeByIDs", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationIDs", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@OrganizationIDs"].Value = oragainzationIDs;

                    sqlDadp.Fill(dt);
                }
                return dt;


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        public DataTable GetUserShortCodesByIDs(int? userID, int? oragainzationID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("GetUserShortCodesByIDs", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (oragainzationID.HasValue && oragainzationID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = oragainzationID.Value;
                    }


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID.Value;

                    sqlDadp.Fill(dt);
                }
                return dt;


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }
        public DataTable GetUserShortCodes(int? userID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserShortCodeByID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(dt);
                }
                return dt;


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

    }
}
