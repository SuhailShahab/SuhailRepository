﻿using BE.Lookups;
using DAL.Common;
using SMS.CMP.BE.LookUps;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.DAL.Lookups
{
    public class StatusDAL : DALBase
    {
        public StatusDAL()
        {

        }
        public StatusDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public StatusDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// save status Model information
        /// </summary>
        /// <param name="relationModel">Set object of status Model type</param>
        /// <returns></returns>
        public int Add(StatusModel statusModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddStatuses";

                //LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(statusModel, sqlCmd);
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(statusModel, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return Convert.ToInt32(result);

        }

        /// <summary>
        /// Update Status information
        /// </summary>
        /// <param name="provinceModel">Set object of statusModel type</param>
        /// <returns></returns>
        public int Edit(StatusModel statusModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditStatuses";

                //LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(statusModel, sqlCmd);
                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(statusModel, sqlCmd);

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Delete Status information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(StatusModel model)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteStatus";

                LazySingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, _sqlCmd);
                //LazySingletonDAL<SqlUtility>.Instance.GetAddParameter(model, _sqlCmd);

                _result = Convert.ToInt32(_sqlCmd.ExecuteScalar());
                _con.Close();
                return Convert.ToInt32(_result);
            
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open)
                    _con.Close();
            }

            return _result;
        }

        /// <summary>
        /// Get Status information
        /// </summary>
        /// <param name=""></param>
        /// <returns>StatusModel Object</returns>
        public DataTable GetAllStatuses()
        {
            DataTable dt = new DataTable();
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllStatuses", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

        /// <summary>
        /// Get Active Status information
        /// </summary>
        /// <param name=""></param>
        /// <returns>StatusModel Object</returns>
        public DataTable GetAllActiveStatuses()
        {
            DataTable dt = new DataTable();
            
            
            SqlConnection con = null;
            try
            {
                using (con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveStatuses", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }
        }

    }
}
