﻿using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using DAL.Common;
using BE.RightsManager;
using BE.CustomEnums;



// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <11-07-2014 10:20AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// CR: 001  -      Syed Zeeshan Aqil      30-10-2015 02:32 PM      Add  Method GetUsersByOrgIDByDeptID
//===========================================

namespace DAL.RightsManagers
{
    public class UserDAL : DALBase
    {
        /// <summary>
        /// </summary>
        /// <param name="user"></param>
        /// <param name="createdBy"></param>
        /// <returns></returns>
        public int Add(UserRegistration user, int? createdBy)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddUser";

                SetUserSqlParameters(user, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar));
                sqlCmd.Parameters["@Password"].Value = CustomSecurity.EncodePasswordToBase64(user.Password);

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = createdBy;

                result = sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }



        /// <summary>
        /// </summary>
        /// <param name="user"></param>
        /// <param name="modifiedBy"></param>
        /// <returns></returns>
        public int Edit(UserRegistration user, int? modifiedBy)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditUser";

                this.SetUserSqlParameters(user, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlCmd.Parameters["@UserID"].Value = user.UserID;



                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;



                if (user.ResignDate.HasValue)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@ResignedDate", SqlDbType.DateTime));
                    sqlCmd.Parameters["@ResignedDate"].Value = user.ResignDate;
                }



                result = sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// Delete user information
        /// </summary>
        /// <param name="_userID"></param>
        /// <returns></returns>
        public int Delete(int _userID)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteUser";

                _sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                _sqlCmd.Parameters["@UserID"].Value = _userID;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Get user information against provided user id
        /// </summary>
        /// <param name="_userID"></param>
        /// <returns></returns>
        public DataSet SelectUserByID(int _userID)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserByID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@UserID"].Value = _userID;

                sqlDadp.Fill(ds);
                ds.Tables[0].TableName = TableName.tblUsers.ToString();
                // ds.Tables[1].TableName = TableName.tblUserDistricts.ToString();

                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Get user information against provided user id
        /// </summary>
        /// <param name="_userID"></param>
        /// <returns></returns>
        public DataTable SelectDistrictByUserID(int _userID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictByUserID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@UserID"].Value = _userID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get user information against User Type and District
        /// </summary>
        /// <param name="_userID"></param>
        /// <returns></returns>
        public DataTable SelectUserByTypeID(int DistrictID, int UserTypeID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spUsersByUserType", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;
                sqlDadp.SelectCommand.Parameters["@UserTypeID"].Value = UserTypeID;

                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get all users with paging for listing
        /// </summary>
        /// <param name="_districtID"></param>
        /// <param name="_tehsilID"></param>
        /// <param name="_unionCouncilID"></param>
        /// <param name="_PageNumber"></param>
        /// <param name="_PageSize"></param>
        /// <param name="_culture"></param>
        /// <param name="_searchIn"></param>
        /// <param name="_keyword"></param>
        /// <returns></returns>
        public DataSet SelectUsers(int _districtID, Int32 _pageNumber, Int32 _pageSize, string _searchIn, string _keyword)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetUser", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = _districtID;

                //_sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TehsilID", SqlDbType.Int));
                //_sqlDadp.SelectCommand.Parameters["@TehsilID"].Value = _tehsilID;

                //_sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UnionCouncilID", SqlDbType.Int));
                //_sqlDadp.SelectCommand.Parameters["@UnionCouncilID"].Value = _unionCouncilID;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNumber", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@PageNumber"].Value = _pageNumber;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@PageSize"].Value = _pageSize;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchIn", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@SearchIn"].Value = _searchIn;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Keyword", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Keyword"].Value = _keyword;

                _sqlDadp.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// get user information against provided user name
        /// </summary>
        /// <param name="login"></param>
        /// <param name="_cultureID"></param>
        /// <returns></returns>
        public DataSet SelectUserByLogin(string login)
        {
            DataSet ds = new DataSet();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserByUserName", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@UserName"].Value = login;

                sqlDadp.Fill(ds);

                ds.Tables[0].TableName = TableName.tblUsers.ToString();
                // ds.Tables[1].TableName = TableName.tblUserDistricts.ToString();



                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get user information against provided user id
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public DataSet SelectUserRightInfoByID(int userID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserRighInfoByLoginID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(ds);

                    ds.Tables[0].TableName = TableName.tblUsers.ToString();
                    ds.Tables[1].TableName = TableName.tblUserDistricts.ToString();

                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Get all users Login Name and ID information for drop down in user reset password page
        /// </summary>
        /// <param name=""></param>
        /// <returns>Dataset</returns>
        public DataSet GetUsersLoginNameInfo()
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetUserLoginNames", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable SelectUsersByFCCenterID(int locationID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUsersByLocationID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LocationID", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@LocationID"].Value = locationID;

                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool IsValidateUser(string loginName, string password)
        {
            DataTable dt = new DataTable();


            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spIsValidateUser", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@UserName"].Value = loginName;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@Password"].Value = CustomSecurity.EncodePasswordToBase64(password);

                sqlDadp.Fill(dt);
                if (dt == null)
                {
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(dt.Rows[0]["Result"]);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public DataTable SelectUsersByFCCenter(string fcCode, string condition)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUsersByLocation", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LocationCode", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@LocationCode"].Value = fcCode;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Clause", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@Clause"].Value = condition;

                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get User Listing 
        /// </summary>
        /// <param name="DistrictID"></param>
        /// <param name="FCLocationID"></param>
        /// <returns></returns>
        public DataTable GetUserListing(int DistrictID, string LocationCode, bool IsAllRecord)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserListing", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LocationCode", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@LocationCode"].Value = LocationCode;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SelectAllRecord", SqlDbType.Bit));
                sqlDadp.SelectCommand.Parameters["@SelectAllRecord"].Value = IsAllRecord;


                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #region "Private Methods"

        internal void SetUserSqlParameters(UserRegistration user, SqlCommand sqlCmd)
        {

            sqlCmd.Parameters.Add(new SqlParameter("@UserDasboardMenu", SqlDbType.Structured));
            sqlCmd.Parameters["@UserDasboardMenu"].Value = user.UserDashboardMenu;

            sqlCmd.Parameters.Add(new SqlParameter("@UserOrganizations", SqlDbType.Structured));
            sqlCmd.Parameters["@UserOrganizations"].Value = user.UserOrganizations;

            sqlCmd.Parameters.Add(new SqlParameter("@UserDepartments", SqlDbType.Structured));
            sqlCmd.Parameters["@UserDepartments"].Value = user.UserDepartments;

            sqlCmd.Parameters.Add(new SqlParameter("@UserShortCode", SqlDbType.Structured));
            sqlCmd.Parameters["@UserShortCode"].Value = user.UserShortCode;

            sqlCmd.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
            sqlCmd.Parameters["@OrganizationID"].Value = user.OrganizationID;

            sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
            sqlCmd.Parameters["@DepartmentID"].Value = user.DepartmentID;

            sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
            sqlCmd.Parameters["@DistrictID"].Value = user.GeneralDistrictID;

            sqlCmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
            sqlCmd.Parameters["@UserName"].Value = user.LoginName;

            sqlCmd.Parameters.Add(new SqlParameter("@EmployeeName", SqlDbType.VarChar));
            sqlCmd.Parameters["@EmployeeName"].Value = user.EmployeeName;

            sqlCmd.Parameters.Add(new SqlParameter("@CNIC", SqlDbType.VarChar));
            sqlCmd.Parameters["@CNIC"].Value = user.CNIC;

            sqlCmd.Parameters.Add(new SqlParameter("@EMail", SqlDbType.VarChar));
            sqlCmd.Parameters["@EMail"].Value = user.EMail;

            sqlCmd.Parameters.Add(new SqlParameter("@CellNumber", SqlDbType.VarChar));
            sqlCmd.Parameters["@CellNumber"].Value = user.CellNumber;

            sqlCmd.Parameters.Add(new SqlParameter("@PermitGroupID", SqlDbType.Int));
            sqlCmd.Parameters["@PermitGroupID"].Value = user.GroupID;//g.permitGroupID;

            sqlCmd.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.VarChar));
            sqlCmd.Parameters["@UserTypeID"].Value = user.UserTypeID;

            sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
            sqlCmd.Parameters["@IsActive"].Value = user.Status;

            sqlCmd.Parameters.Add(new SqlParameter("@InActiveReason", SqlDbType.VarChar));
            sqlCmd.Parameters["@InActiveReason"].Value = user.BlockReason;


            sqlCmd.Parameters.Add(new SqlParameter("@IsEnforceRight", SqlDbType.Bit));
            sqlCmd.Parameters["@IsEnforceRight"].Value = user.EnforceRight.HasValue && user.EnforceRight.Value ? 1 : 0;

            if (user.JoinDate.HasValue)
            {
                sqlCmd.Parameters.Add(new SqlParameter("@JoiningDate", SqlDbType.DateTime));
                sqlCmd.Parameters["@JoiningDate"].Value = user.JoinDate;
            }

            if (user.AddressDivisionID.HasValue)
            {
                sqlCmd.Parameters.Add(new SqlParameter("@AddressDivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@AddressDivisionID"].Value = user.AddressDivisionID;
            }

            if (user.AddressDistrictID.HasValue)
            {
                sqlCmd.Parameters.Add(new SqlParameter("@AddressDistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@AddressDistrictID"].Value = user.AddressDistrictID;
            }

            if (!string.IsNullOrEmpty(user.FullAddress))
            {
                sqlCmd.Parameters.Add(new SqlParameter("@FullAddress", SqlDbType.NVarChar));
                sqlCmd.Parameters["@FullAddress"].Value = user.FullAddress;
            }

            sqlCmd.Parameters.Add(new SqlParameter("@FileAdd", SqlDbType.Bit));
            sqlCmd.Parameters["@FileAdd"].Value = user.FileAdd;

            sqlCmd.Parameters.Add(new SqlParameter("@FileView", SqlDbType.Bit));
            sqlCmd.Parameters["@FileView"].Value = user.FileView;

            sqlCmd.Parameters.Add(new SqlParameter("@FileRemove", SqlDbType.Bit));
            sqlCmd.Parameters["@FileRemove"].Value = user.FileRemove;

            sqlCmd.Parameters.Add(new SqlParameter("@FileDownload", SqlDbType.Bit));
            sqlCmd.Parameters["@FileDownload"].Value = user.FileDownload;

            sqlCmd.Parameters.Add(new SqlParameter("@AllowUpdate", SqlDbType.Bit));
            sqlCmd.Parameters["@AllowUpdate"].Value = user.AllowUpdate;

            sqlCmd.Parameters.Add(new SqlParameter("@ModifyCampaign", SqlDbType.Bit));
            sqlCmd.Parameters["@ModifyCampaign"].Value = user.ModifyCampaign;

            sqlCmd.Parameters.Add(new SqlParameter("@UserSMSDeliveryStatus", SqlDbType.Structured));
            sqlCmd.Parameters["@UserSMSDeliveryStatus"].Value = user.UserSMSDeliveryStatus;
            if (user.IsEnforceSMSBucked.HasValue)
            {
                sqlCmd.Parameters.Add(new SqlParameter("@IsEnforceSMSBucked", SqlDbType.Bit));
                sqlCmd.Parameters["@IsEnforceSMSBucked"].Value = user.IsEnforceSMSBucked;
            }

        }

        #endregion


        public int UpdatePassword(string loginName, string oldpassword, string newpassword, int? loginID, bool IsAdmin)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spResetPassword";

                        sqlCmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
                        sqlCmd.Parameters["@UserName"].Value = loginName;

                        sqlCmd.Parameters.Add(new SqlParameter("@OldPassword", SqlDbType.VarChar));
                        sqlCmd.Parameters["@OldPassword"].Value = CustomSecurity.EncodePasswordToBase64(oldpassword);

                        sqlCmd.Parameters.Add(new SqlParameter("@NewPassword", SqlDbType.VarChar));
                        sqlCmd.Parameters["@NewPassword"].Value = CustomSecurity.EncodePasswordToBase64(newpassword);

                        sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                        sqlCmd.Parameters["@ModifiedBy"].Value = loginID;

                        sqlCmd.Parameters.Add(new SqlParameter("@IsAdmin", SqlDbType.Bit));
                        sqlCmd.Parameters["@IsAdmin"].Value = IsAdmin;

                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {

                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }

            return Convert.ToInt32(result);
        }



        /// <summary>
        /// 001
        /// Get user list on the bases of Organization and Department ID
        /// </summary>
        /// <param name="orgID">selected Organization Id</param>
        /// <param name="deptID">Selected Department ID</param>
        /// <returns>User DataTable</returns>
        public DataTable GetUsersByOrgIDByDeptID(int orgID, int deptID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUsersByOrgIDByDeptID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@OrganizationID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@OrganizationID"].Value = orgID;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;


                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
