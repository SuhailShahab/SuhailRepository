﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using SMS.Count.CMPProcess.ApplicationClasses;
namespace SMS.Count.CMPProcess
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Utility.Test();
            Environment.Exit(0);
        }
    }
}
