﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Count.CMPProcess.ApplicationClasses
{
    class Utility
    {
        public static void Test()
        {
            Process currentProcess = Process.GetCurrentProcess();
            Process[] processlist = Process.GetProcesses();
            int cout = processlist.Where(a => a.ProcessName.Equals("SMS.API.Response")).Count();

            foreach(Process p  in processlist)
            {
                Console.WriteLine(p.ProcessName + " " + p.ExitCode);
                Console.WriteLine();
            }

            if(cout==0)
            {
               // Utility.Run("SMS.API.Response",null);
              //  System.Diagnostics.Process.Start("SMS.API.Response.exe");
                Utility.Test2();
            }
            Console.Read();
          
        }

        public static string Run(string fileName, string args)
        {
            string returnvalue = string.Empty;

            ProcessStartInfo info = new ProcessStartInfo(fileName);
            info.UseShellExecute = false;
            info.Arguments = args;
            info.RedirectStandardInput = true;
            info.RedirectStandardOutput = true;
            info.CreateNoWindow = true;

            using (Process process = Process.Start(info))
            {
                StreamReader sr = process.StandardOutput;
                returnvalue = sr.ReadToEnd();
            }

            return returnvalue;
        }
        public static void Test2()
        {
            Process myProcess = new Process();

            try
            {
                /*
                myProcess.StartInfo.UseShellExecute = false;
                // You can start any process, HelloWorld is a do-nothing example.
                myProcess.StartInfo.FileName = @"C:\tfs_Sohail\SMS.CMP\SMS.CompaignManagementPortal\SMS.API.Response\bin\Debug\SMS.API.Response.exe";
                myProcess.StartInfo.CreateNoWindow = true;
                myProcess.Start();
                 * */
                // This code assumes the process you are starting will terminate itself.
                // Given that is is started without a window so you cannot terminate it
                // on the desktop, it must terminate itself or you can do it programmatically
                // from this application using the Kill method.


                string str = @"C:\tfs_Sohail\SMS.CMP\SMS.CompaignManagementPortal\SMS.API.Response\bin\Debug\SMS.API.Response.exe";
                Process process = new Process();
                process.StartInfo.FileName = str;
                process.Start();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}
