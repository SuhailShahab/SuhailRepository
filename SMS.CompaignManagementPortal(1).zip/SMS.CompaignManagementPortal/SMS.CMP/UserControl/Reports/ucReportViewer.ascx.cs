﻿using ApplicationClasses;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.UserControl.Reports
{
    public partial class ucReportViewer : System.Web.UI.UserControl
    {
        #region Custom Properties

        public string ReportName { get; set; }

        public List<Microsoft.Reporting.WebForms.ReportParameter> ParamList { get; set; }

        public List<Microsoft.Reporting.WebForms.ReportDataSource> DataSourceList { get; set; }

        private string testProperty;

        public string TestProperty
        {
            get { return testProperty; }
            set { testProperty = value; }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
           // string a = "  $('#ctl00_ContentPlaceHolder1_ucReportViewer1_cRptViewer_ctl05_ctl04_ctl00_Menu').append('<button id='printreport1' type='button' class='btn btn-mini' ><i class='fa fa-print'></i></button></div>')";
      // a = a + " $('#ctl00_cphBody_rv1_ctl05_ctl04_ctl00_Menu').children('div:gt(2)').css('display', 'none') ";
            string scriptVar = "var isIE = /*@cc_on!@*/false || !!document.documentMode;        if (isIE) {            $('#printreport').hide();   }";
        //  scriptVar =scriptVar+   "$($("#ReportViewer1_fixedTable").find('td[colspan=3] div[id^="ReportViewer1"]')[1]).find('div').first().append('<div class="printButtoniFrame"><button id="printButtoniFrameBtn" type="button" class="btn btn-mini" ><i class="fa fa-print"></i></button></div>')";
          //  scriptVar = scriptVar + a;
            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", scriptVar, true);
        }

        #region Custom Methods

        public void LoadLocalReport()
        {
            try
            {
                cRptViewer.Width = Unit.Pixel(950);
                cRptViewer.Height = Unit.Pixel(700);

                // Update report and refresh
                string ReportPath = HttpContext.Current.Server.MapPath("/") + "ContentPages//Reoprts//Reports//" + this.GetReportPath() + ".rdlc";
                cRptViewer.LocalReport.ReportPath = ReportPath;
                
                if (this.ParamList != null && this.ParamList.Count > 0)
                {
                    cRptViewer.LocalReport.SetParameters(this.ParamList);
                }
                cRptViewer.LocalReport.DataSources.Clear();
                if (this.DataSourceList != null && this.DataSourceList.Count > 0)
                {
                    for (int i = 0; i < this.DataSourceList.Count; i++)
                    {
                        cRptViewer.LocalReport.DataSources.Add(this.DataSourceList[i]);
                    }
                }

                cRptViewer.LocalReport.Refresh();

            }
            catch (Exception ex)
            {

             //   Common.AddErrorLog(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));

            }
        }

        public string GetReportPath()
        {
            StringBuilder sbReprotPath = new StringBuilder();
            // sbReprotPath.Append(RptConfig.ReportPath);

            sbReprotPath.Append(this.ReportName);
            // sbReprotPath.Append(".rdl");
            return sbReprotPath.ToString();
        }
        #endregion 
    }
}