﻿

var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var ref_all_rec = [];
var ref_allDepartments = [];
var refSearchText = '';
var YesNo = [{ Title: 'English', Value: false }, { Title: 'Urdu', Value: true }];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($("#main"))) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.Organizations = ko.observableArray();
    self.file = ko.observable(new FileModel(null));
    self.Departments = ko.observableArray();
    self.Campaigns = ko.observableArray();

    self.SearchText = ko.observable(refSearchText);

    self.User = ko.observable(new UserRightsModel(null));
    

    if (items != null) {
       
        if (items.Contacts != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(items.Contacts, function (item) {
                self.allRecords.push(new BulkSMSModel(item));
                ref_all_rec.push(new BulkSMSModel(item))
            });
        }

        if (items.Organizations != null) {
            ko.utils.arrayForEach(items.Organizations, function (item) {
                self.Organizations.push(new OrganizationModel(item));
            });
        }

        if (items.Departments != null) {
            self.Departments([]);
            ko.utils.arrayForEach(items.Departments, function (item) {
                self.Departments.push(new DepartmentModel(item));
            });
        }

        self.PageSize(items.PageSize);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());
        //var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {

        $.ajax({
            url: "BulkSMS.aspx/GetDepartments",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {

                if (data.d.Departments != null) {
                    self.Departments([]);
                    ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Departments), function (dept) {
                        self.Departments.push(new DepartmentModel(dept));
                    });
                }

                refModel = new BulkSMSModel(item);
                var mod = new BulkSMSModel(item);
                self.editModel(mod);
                self.editModel().DepartmentID(item.DepartmentID());
                self.allRecords.remove(item);
                self.isEdit(true);
            },
            error: function (request) {
                alert(Error);
            }
        });


        //============= Fill Campaign======================

       
            if (item.OrganizationID() != undefined && item.DepartmentID() != undefined) {
                $.ajax({
                    url: "BulkSMS.aspx/GetCampaigns",
                    type: 'POST',
                    data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "' , departmentID :'" + ko.toJSON(item.DepartmentID()) + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        if (NotifyMe(data.d.Notification)) {
                            if (data.d.Campaigns != null) {
                                self.Campaigns([]);
                                ko.utils.arrayForEach(data.d.Campaigns, function (itm) {
                                    self.Campaigns.push(new CommonModel(itm));
                                });
                            }

                            refModel = new BulkSMSModel(item);
                            var mod = new BulkSMSModel(item);
                            self.editModel(mod);
                            self.editModel().DepartmentID(item.DepartmentID());
                            self.editModel().CampaignID(item.CampaignID());
                            self.allRecords.remove(item);
                            self.isEdit(true);
                        }
                    },
                    error: function (er, _rr) {
                        NotifyMe("error|" + er.statusText);
                    }
                });
            }
            else {
                self.Campaigns([]);
            }
     


    };

    self.cancelRecord = function () {
        var mod = new BulkSMSModel(null);
        self.editModel(mod);
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    };

    self.resetRecord = function () {
       
        LoadRecord();
    };

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "BulkSMS.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    self.allRecords.remove(item);
                    LoadRecord();
                }
            },
            error: function (request) {
                alert(Error);
            }
        });
        //}
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "BulkSMS.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {

                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.ID > 0) {
                           
                            self.editModel(new BulkSMSModel(null));
                            // mod.allAddressBook(all_addressBook);
                            self.isEdit(false);
                            LoadRecord(viewModel.main());
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };
    self.sendSMS = function () {
       
            $.ajax({
                url: "BulkSMS.aspx/SendSMS",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {

                    if (NotifyMe(data.d.Notification)) {

                        self.editModel(new BulkSMSModel(null));                       
                        LoadRecord(viewModel.main());
                        
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
      
    };
    self.Filter = function (data, event) {
        if ($('.search').val().trim() != '') {
            refSearchText = self.SearchText();
            LoadRecordSearch(viewModel.main(), refSearchText);
        }
        else {
            NotifyMe("info|Please type something in search box");
        }
        event.preventDefault();
        event.stopPropagation();
        //return true;
    };

    self.Reload = function () {
        refSearchText = '';
        LoadRecord();
    };

    self.uploadFile = function () {
        $.ajax({
            url: "BulkSMS.aspx",
            type: "POST",
            contentType: false,
            processData: false,
            data: function () {
                var data = new FormData();
                var Item = viewModel.main().file().File();
                data.append("organizationID", self.editModel().OrganizationID());
                data.append("departmentID", self.editModel().DepartmentID());
                data.append("CampaignID", self.editModel().CampaignID());
                data.append("IsEncodeOn", self.editModel().IsEncodeOn());
                data.append("chosenFile", Item);
                return data;
            }(),
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            },
            success: function (response, textStatus) {
                NotifyMe("success|Contact has been uploaded successfully.");
                LoadRecord();
            }
        });
    }

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        if (self.SearchText() == '')
            LoadRecord(viewModel.main());
        else
            LoadRecordSearch(viewModel.main(), self.SearchText())
    };

    self.getDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "BulkSMS.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.Departments != null) {
                            self.Departments([]);
                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                self.Departments.push(new DepartmentModel(dept));
                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else {
            self.Departments([]);
        }
    };

    self.getCampaigns = function (item) {
        if (item.OrganizationID() != undefined && item.DepartmentID() != undefined) {
            $.ajax({
                url: "BulkSMS.aspx/GetCampaigns",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "' , departmentID :'" + ko.toJSON(item.DepartmentID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.Campaigns != null) {
                            self.Campaigns([]);
                            ko.utils.arrayForEach(data.d.Campaigns, function (itm) {
                                self.Campaigns.push(new CommonModel(itm));
                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else {
            self.Campaigns([]);
        }
    };
}

function BulkSMSModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.FirstName = ko.observable(ko.utils.unwrapObservable(item.FirstName));
        self.LastName = ko.observable(ko.utils.unwrapObservable(item.LastName));
        self.Phone = ko.observable(ko.utils.unwrapObservable(item.Phone));
        self.Email = ko.observable(ko.utils.unwrapObservable(item.Email));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.CampaignID = ko.observable(ko.utils.unwrapObservable(item.CampaignID)); 
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.IsEnable = ko.observable(ko.utils.unwrapObservable(item.IsEnable));
        self.UserGroupID = ko.observable(ko.utils.unwrapObservable(item.UserGroupID));
        self.OrganizationTitle = ko.observable(ko.utils.unwrapObservable(item.OrganizationTitle));
        self.DepartmentTitle = ko.observable(ko.utils.unwrapObservable(item.DepartmentTitle));
        self.IsEncodeOn = ko.observable(ko.utils.unwrapObservable(item.IsEncodeOn).toString());
        self.MessageEnglish = ko.observable(ko.utils.unwrapObservable(item.MessageEnglish) || '');
        self.MessageUrdu = ko.observable(ko.utils.unwrapObservable(item.MessageUrdu) || '');
        self.CampaignTitle = ko.observable(ko.utils.unwrapObservable(item.CampaignTitle));
        self.CreatedDate = ko.observable(ko.utils.unwrapObservable(item.CreatedDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.CreatedDate).substring(6, 19))) : ko.utils.unwrapObservable(item.CreatedDate));
        self.CreatedDateDisplay = ko.observable(ko.utils.unwrapObservable(item.CreatedDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.CreatedDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.CreatedDate));
        self.StatusTitle = ko.observable(ko.utils.unwrapObservable(item.StatusTitle));
        self.RowNumber = ko.observable(ko.utils.unwrapObservable(item.RowNumber));
    }
    else {
        self.ID = ko.observable();
        self.FirstName = ko.observable('');
        self.LastName = ko.observable('');
        self.Phone = ko.observable('');
        self.Email = ko.observable('');
        self.Status = ko.observable(true);
        self.OrganizationID = ko.observable(0);
        self.IsEnable = ko.observable(true);
        self.UserGroupID = ko.observable();
        self.OrganizationTitle = ko.observable('');
        self.DepartmentTitle = ko.observable('');
        self.DepartmentID = ko.observable();
        self.CampaignID = ko.observable();
        self.IsEncodeOn = ko.observable('false');
        self.MessageEnglish = ko.observable('');
        self.MessageUrdu = ko.observable('');
        self.CampaignTitle = ko.observable('');
        self.StatusTitle = ko.observable('');
        self.CreatedDate = ko.observable(null);
        self.CreatedDateDisplay = ko.observable(null);
        self.RowNumber = ko.observable(0);
    }

    self.browseFile = function (file) {
        viewModel.main().file(new FileModel(file));
    };

    self.CharacterCount = ko.computed(function () {
        return (1500 - parseInt(self.MessageEnglish().length)) < 0 ? 'Limit Exceeded' : 1500 - parseInt(self.MessageEnglish().length);
    });

    self.MessageCountEn = ko.computed(function () {
        //return parseInt(parseInt(self.TemplateMessageEng().length) % 153) == 0 ? parseInt(parseInt(self.TemplateMessageEng().length) / 153) || 0 : parseInt(parseInt(self.TemplateMessageEng().length) / 153) + 1 || 0;   comment by hammad - 27-01-2016 05:34:19PM

        var count = parseInt(parseInt(self.MessageEnglish().length) % 153) == 0 ? parseInt(parseInt(self.MessageEnglish().length) / 153) || 0 : parseInt(parseInt(self.MessageEnglish().length) / 153) + 1 || 0;
         return count;
    });

    self.CharacterCountUr = ko.computed(function () {
        return (1000 - parseInt(self.MessageUrdu().length)) < 0 ? 'Limit Exceeded' : 1000 - parseInt(self.MessageUrdu().length);
    });

    self.MessageCountUr = ko.computed(function () {
        //return parseInt(parseInt(self.TemplateMessageUrdu().length) % 67) == 0 ? parseInt(parseInt(self.TemplateMessageUrdu().length) / 67) || 0 : parseInt(parseInt(self.TemplateMessageUrdu().length) / 67) + 1 || 0;  comment by hammad - 27-01-2016 05:34:19PM

        var count = parseInt(parseInt(self.MessageUrdu().length) % 67) == 0 ? parseInt(parseInt(self.MessageUrdu().length) / 67) || 0 : parseInt(parseInt(self.MessageUrdu().length) / 67) + 1 || 0;
        return count;
    });
}

function OrganizationModel(item) {
    var self = this;
    self.OrganizationID = ko.observable(item.ID);
    self.Title = ko.observable(item.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.ID = ko.observable(item.DepartmentID);
    self.Title = ko.observable(item.Title);
    self.OrganizationID = ko.observable(item.OrganizationID);
}

function CommonModel(item) {
    var self = this;
    self.CampaignID = ko.observable(item.CampaignID);
    self.Title = ko.observable(item.Title);
}

function FileModel(file) {
    var self = this;
    if (file != null) {
        self.File = ko.observable(file);
        self.Name = ko.observable(file.name);
    }
    else {
        self.File = ko.observable('');
        self.Name = ko.observable('');
    }
}

function uploadFile(file, organizationID, departmentID) {
    $.ajax({
        url: "BulkSMS.aspx",
        type: "POST",
        contentType: false,
        processData: false,
        data: function () {
            var data = new FormData();
            var Item = file;
            data.append("organizationID", organizationID);
            data.append("departmentID", departmentID);
            data.append("chosenFile", Item);
            return data;
        }(),
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        },
        success: function (response, textStatus) {
            alert('contact updated successfully.');
        }
    });
}

function UserRightsModel(item) {
    var self = this;
    if (item != null) {
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
    }
    else {
        self.OrganizationID = ko.observable(0);
        self.DepartmentID = ko.observable(0);
        self.UserID = ko.observable(0);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord(null);
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {

    $.ajax({
        url: "BulkSMS.aspx/GetRecord",
        type: 'POST',
        dataType: "json",
        data: "{jsonModel : '" + ko.toJSON(mod) + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new BulkSMSModel(null));

                //viewModel.main().editModel().IsEnable(data.d.IsEnable);
                //if (!data.d.IsEnable) {
                //    viewModel.main().editModel().OrganizationID(data.d.UserGroupID);
                //}

                viewModel.main().User(new UserRightsModel(data.d.User));

                if (viewModel.main().User().OrganizationID() != 0 && viewModel.main().User().DepartmentID() != 0) {

                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());


                    $.ajax({
                        url: "BulkSMS.aspx/GetCampaigns",
                        type: 'POST',
                        data: "{organizationID : '" + ko.toJSON(viewModel.main().editModel().OrganizationID()) + "' , departmentID :'" + ko.toJSON(viewModel.main().editModel().DepartmentID()) + "'}",
                        dataType: "json",
                        contentType: "application/json; charset=utf-8",
                        success: function (data) {
                            if (NotifyMe(data.d.Notification)) {
                                if (data.d.Campaigns != null) {
                                    viewModel.main().Campaigns([]);
                                    ko.utils.arrayForEach(data.d.Campaigns, function (itm) {
                                        viewModel.main().Campaigns.push(new CommonModel(itm));
                                    });
                                }
                            }
                        },
                        error: function (er, _rr) {
                            NotifyMe("error|" + er.statusText);
                        }
                    });
                }
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new BulkSMSModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}


function LoadRecordSearch(mod, searchText) {

    //alert('a');
    $.ajax({
        url: "BulkSMS.aspx/GetRecordSearch",
        type: 'POST',
        dataType: "json",
        data: "{jsonModel : '" + ko.toJSON(mod) + "', searchText : '" + searchText + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new BulkSMSModel(null));

                //viewModel.main().editModel().IsEnable(data.d.IsEnable);
                //if (!data.d.IsEnable) {
                //    viewModel.main().editModel().OrganizationID(data.d.UserGroupID);
                //}

                viewModel.main().User(new UserRightsModel(data.d.User));

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new BulkSMSModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}
