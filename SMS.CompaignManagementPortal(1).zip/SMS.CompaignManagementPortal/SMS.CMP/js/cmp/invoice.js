﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var refSearchText = '';

ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};
//** Validation Engine Custom binding **\\
ko.bindingHandlers.valid = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($("#main"))) {
            $(element).validationEngine('validate');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()) || new Date(),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        //ko.utils.registerEventHandler(element, "blur", function () {
        //    $(element).validationEngine('validate');
        //});
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        //var text = allBindingsAccessor().value || {};
        //if (text() != undefined) {
        //    $(element).validationEngine('validate');
        //}
    }
};

function wrapperModel(item) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();
    self.Campaigns = ko.observableArray();
    self.PageNo = ko.observable(1);
    self.SearchText = ko.observable(refSearchText);
    self.TotalResults = ko.observable(0);
    //self.TotalCount = ko.observable(0);

    if (item != null) {

        if (item.Invoices != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(item.Invoices, function (item) {
                self.allRecords.push(new InvoiceModel(item));
                ref_all_rec.push(new InvoiceModel(item));
            });
        }

        if (item.Organizations != null) {

            ko.utils.arrayForEach(item.Organizations, function (item) {
                self.Organizations.push(new OrganizationModel(item));
            });
        }

        self.PageNo(item.PageNo == 0 ? 1 : item.PageNo);
        self.TotalResults(item.TotalCount);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());
    }

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        LoadRecord(viewModel.main());
    };

    self.editRecord = function (item) {

        $.ajax({
            url: "Invoice.aspx/GetDepartments",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "',departmentID : '" + ko.toJSON(item.DepartmentID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {

                if (data.d.Departments != null) {
                    self.Departments([]);
                    ko.utils.arrayForEach(data.d.Departments, function (item) {
                        self.Departments.push(new DepartmentModel(item));
                    });
                }

                if (data.d.Campaigns != null) {
                    viewModel.main().Campaigns([]);
                    ko.utils.arrayForEach(data.d.Campaigns, function (item) {
                        viewModel.main().Campaigns.push(new CampaignModel(item));
                    });
                }

                refModel = new InvoiceModel(item);
                var mod = new InvoiceModel(item);
                self.editModel(mod);
                self.editModel().DepartmentID(item.DepartmentID());
                self.editModel().CampaignID(item.CampaignID());
                viewModel.main().editModel().PaidAmount(0);
                self.allRecords.remove(item);
                self.isEdit(true);
                $('.PaidAmount').attr('readonly', false);
                $('.debit').attr('checked', true);
                $('.credit').attr('checked', false);
                self.editModel().Mode('1');

            },
            error: function (request) {
                alert(Error);
            }
        });
    };

    self.clearRecord = function () {
        LoadRecord(null);
    }

    self.cancelRecord = function () {

        var mod = new InvoiceModel(null);
        self.editModel(mod);
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord(null);
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {

            var CalculatedPayableAmount = viewModel.main().editModel().PayableAmount() - viewModel.main().editModel().PaidAmount();

            if (viewModel.main().editModel().TotalAmount() > 0 && viewModel.main().editModel().PayableAmount() > 0) {

                if (self.isEdit() && viewModel.main().editModel().Mode() == 1 && viewModel.main().editModel().PaidAmount() == 0) {

                    NotifyMe('error|Paid Amount cannot be zero')
                }
                else {
                    if ( !(self.isEdit()) || CalculatedPayableAmount >= 0) {


                        $.ajax({
                            url: "Invoice.aspx/SaveRecord",
                            type: 'POST',
                            data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                            dataType: "json",
                            contentType: "application/json; charset=utf-8",
                            success: function (data) {
                                if (NotifyMe(data.d.Notification)) {
                                    if (data.d.PaymentInvoiceID > 0) {
                                        LoadRecord(null);
                                    }
                                }
                            },
                            error: function (request) {
                            }
                        });
                    }
                    else {
                        NotifyMe('error|Paid amount can not be greater than payable amount.')
                    }
                }
            }
            else {
                NotifyMe('error|Record cannot be save')
            }
        }
    };



    self.getPayableAmount = function () {

        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "Invoice.aspx/GetPayableAmount",
                type: 'POST',
                data: "{departmentID : '" + ko.toJSON(viewModel.main().editModel().DepartmentID()) + "',organizationID : '" + ko.toJSON(viewModel.main().editModel().OrganizationID()) + "',campaignID : '" + ko.toJSON(viewModel.main().editModel().CampaignID()) + "',pageNo : '" + ko.toJSON(viewModel.main().PageNo()) + "',searchText : '" + ko.toJSON(refSearchText) + "',dateOfInvoice : '" + viewModel.main().editModel().DateofInvoice().format('MM/dd/yyyy') + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {


                        if (data.d.PayableAmount > 0) {
                            viewModel.main().editModel().PayableAmount(data.d.PayableAmount);
                            viewModel.main().editModel().Quantity(data.d.Quantity);
                            viewModel.main().editModel().Rate(data.d.Rate);
                            viewModel.main().editModel().TotalAmount(data.d.TotalAmount);
                            viewModel.main().editModel().NoOfMessage(data.d.NoOfMessage);

                        }
                        else {
                            viewModel.main().editModel().PayableAmount(0);
                            viewModel.main().editModel().Quantity(0);
                            viewModel.main().editModel().Rate(0);
                            viewModel.main().editModel().TotalAmount(0);
                            viewModel.main().editModel().NoOfMessage(0);
                        }


                        if (data.d.Invoices != null) {
                            ref_all_rec = [];
                            viewModel.main().allRecords([]);
                            ko.utils.arrayForEach(data.d.Invoices, function (item) {
                                viewModel.main().allRecords.push(new InvoiceModel(item));
                                ref_all_rec.push(new InvoiceModel(item));
                            });
                        }
                        else {
                            viewModel.main().allRecords([]);
                        }

                        self.TotalResults(data.d.TotalCount);
                    }
                },
                error: function (request) {
                }
            });
        }
    };

    self.Filter = function () {

        if ($('.search').val().trim() != '') {
            refSearchText = $('.search').val().trim();
            self.SearchText(refSearchText);
            LoadRecord(viewModel.main());
        }
        else {
            NotifyMe("info|Please type something in search box");
        }

    };

    self.Reload = function () {

        refSearchText = '';
        self.SearchText('');
        LoadRecord(viewModel.main());
    }
}

function InvoiceModel(item) {
    var self = this;

    if (item != null) {

        self.PaymentInvoiceID = ko.observable(ko.utils.unwrapObservable(item.PaymentInvoiceID));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.Organization = ko.observable(ko.utils.unwrapObservable(item.Organization));
        self.CampaignID = ko.observable(ko.utils.unwrapObservable(item.CampaignID));
        self.DateofInvoice = ko.observable(ko.utils.unwrapObservable(item.DateofInvoice).toString("dd/MM/yyyy").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.DateofInvoice).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.DateofInvoice));
        self.PayableAmount = ko.observable(ko.utils.unwrapObservable(item.PayableAmount));
        self.PaidAmount = ko.observable(ko.utils.unwrapObservable(item.PaidAmount));
        self.Campaign = ko.observable(ko.utils.unwrapObservable(item.Campaign));
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.Department = ko.observable(ko.utils.unwrapObservable(item.Department));
        self.Mode = ko.observable(ko.utils.unwrapObservable(item.Mode || '').toString());
        self.Quantity = ko.observable(ko.utils.unwrapObservable(item.Quantity));
        self.Rate = ko.observable(ko.utils.unwrapObservable(item.Rate));
        self.TotalAmount = ko.observable(ko.utils.unwrapObservable(item.TotalAmount));
        self.NoOfMessage = ko.observable(ko.utils.unwrapObservable(item.NoOfMessage));
    }
    else {

        self.PaymentInvoiceID = ko.observable();
        self.OrganizationID = ko.observable();
        self.Organization = ko.observable();
        self.CampaignID = ko.observable();
        self.DateofInvoice = ko.observable();
        self.PayableAmount = ko.observable(0);
        self.PaidAmount = ko.observable(0);
        self.Campaign = ko.observable();
        self.DepartmentID = ko.observable();
        self.Department = ko.observable();
        self.Mode = ko.observable('2');
        self.Quantity = ko.observable();
        self.Rate = ko.observable();
        self.TotalAmount = ko.observable(0);
        self.NoOfMessage = ko.observable(0);

    }

    self.OrganizationID.subscribe(function (newValue) {

        $.ajax({
            url: "Invoice.aspx/GetDepartments",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(newValue) + "',departmentID : '" + ko.toJSON(self.DepartmentID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                viewModel.main().Campaigns([]);
                if (data.d.Departments != null) {
                    viewModel.main().Departments([]);
                    ko.utils.arrayForEach(data.d.Departments, function (item) {
                        viewModel.main().Departments.push(new DepartmentModel(item));
                    });
                }
            },
            error: function (request) {
            }
        });

    });

    self.DepartmentID.subscribe(function (newValue) {

        $.ajax({
            url: "Invoice.aspx/GetDepartments",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(self.OrganizationID()) + "',departmentID : '" + ko.toJSON(newValue) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {

                if (data.d.Campaigns != null) {
                    viewModel.main().Campaigns([]);
                    ko.utils.arrayForEach(data.d.Campaigns, function (item) {
                        viewModel.main().Campaigns.push(new CampaignModel(item));
                    });
                }
            },
            error: function (request) {
            }
        });

    });
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function OrganizationModel(item) {
    var self = this;
    self.ID = ko.observable(item.ID);
    self.Title = ko.observable(item.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.ID = ko.observable(item.DepartmentID);
    self.Title = ko.observable(item.Title);
}

function CampaignModel(item) {
    var self = this;
    self.ID = ko.observable(item.CampaignID);
    self.Title = ko.observable(item.Title);
}


$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord(null);
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {

    $.ajax({
        url: "Invoice.aspx/GetRecord",
        type: 'POST',
        dataType: "json",
        data: "{jsonModel : '" + ko.toJSON(mod) + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            $('.PaidAmount').attr('readonly', true);
            viewModel.main(new wrapperModel(data.d));
            viewModel.main().editModel(new InvoiceModel(null));
        },
        error: function (request) {
        }
    });
}

