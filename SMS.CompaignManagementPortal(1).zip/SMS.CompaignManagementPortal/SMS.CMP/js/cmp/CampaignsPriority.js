﻿// =================================================================================================================================
// Create by:	<M.Shakeel>
// Create date:  <07-03-2018 12:30PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
var pageName = "CampaignsPriority.aspx";
var viewModel = new ViewModel();
var refModel = null;
var refSearchText = '';
//** TimePicker Custom binding **\\

ko.bindingHandlers.timeValue = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
        var tpicker = $(element).timepicker();
        tpicker.on('changeTime.timepicker', function (e) {

            //Asignar la hora y los minutos
            var value = valueAccessor();
            if (!value) {
                throw new Error('timeValue binding observable not found');
            }
            var date = ko.unwrap(value);
            var mdate = moment(date || new Date());
            var hours24;
            if (e.time.meridian == "AM") {
                if (e.time.hours == 12)
                    hours24 = 0;
                else
                    hours24 = e.time.hours;
            }
            else {
                if (e.time.hours == 12) {
                    hours24 = 12;
                }
                else {
                    hours24 = e.time.hours + 12;
                }
            }

            mdate.hours(hours24)
            mdate.minutes(e.time.minutes);
            $(element).data('updating', true);
            value(mdate.toDate());
            $(element).data('updating', false);


        })
    },
    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
        //Avoid recursive calls
        if ($(element).data('updating')) {
            return;
        }
        var date = ko.unwrap(valueAccessor()) || new Date();

        if (date) {
            var time = moment(date).format("hh:mmA");
            //var matches = time.match(/(\d{1,2}):(\d{2})/);
            //var zone = parseInt(matches[0]) >= 12 ? 'PM' : 'AM';
            //time = matches[1] + ':' + matches[2] + ' ' + zone;
            $(element).timepicker('setTime', time);
        }
        else {
            // $(element).timepicker('clear');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};


ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($(element))) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.ShowUpdate = ko.observable(false);

    self.PageSize = ko.observable(5);

    self.ContactCurrentPage = ko.observable(1);
    self.ContactPageSize = ko.observable(50);

    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);
    self.SearchText = ko.observable(refSearchText);

    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();
    self.Campaings = ko.observableArray();

    self.OrganizationID = ko.observable();
    self.DepartmentID = ko.observable();
    self.CampaingID = ko.observable();

    if (items != null) {

        self.PageSize(items.PageSize);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());

        if (items.Organizations != null) {
            self.Organizations([]);
            self.Organizations(items.Organizations);
        }
    };

    self.Filter = function (data, event) {
        LoadRecordSearch(self.OrganizationID(), self.DepartmentID(), self.CampaingID());
    };


    self.getFilterDepartments = function (item) {
        if (item.OrganizationID != undefined) {
            $.ajax({
                url: pageName + "/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d != null) {
                            if (data.d.Departments != null) {
                                self.Departments([]);
                                self.Departments(data.d.Departments);
                            }
                        }
                    }
                    else {
                        self.Departments([]);
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else
            self.Departments([]);
    };

    self.getFilterCampaings = function (item) {
        if (item.OrganizationID() != undefined && item.DepartmentID() != undefined && item.OrganizationID() > 0 && item.DepartmentID() > 0) {
            $.ajax({
                url: pageName + "/GetCampaings",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "', departmentID : '" + ko.toJSON(item.DepartmentID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d != null) {
                            if (data.d.Campaignslist != null) {
                                self.Campaings([]);
                                self.Campaings(data.d.Campaignslist);
                            }
                        }
                    }
                    else {
                        self.Campaings([]);
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else
            self.Departments([]);
    };
}


function CampaignPriorityModel(item) {
    var self = this;

    if (item != null) {
        self.CampaignID = ko.observable(ko.utils.unwrapObservable(item.CampaignID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.PriorityID = ko.observable(ko.utils.unwrapObservable(item.PriorityID));
        self.TotalSMS = ko.observable(ko.utils.unwrapObservable(item.TotalSMS));
        self.NewPriorityID = ko.observable(ko.utils.unwrapObservable(item.NewPriorityID));
    }
    else {
        self.CampaignID = ko.observable(null);
        self.Title = ko.observable(null);
        self.PriorityID = ko.observable(null);
        self.TotalSMS = ko.observable(null);
        self.NewPriorityID = ko.observable(null);
    }
    self.isHide = ko.observable(false);


    self.editRecord = function (item) {
        item.isHide(true);
    };

    self.saveRecord = function (item) {
        $.ajax({
            url: pageName + "/UpdateCampaignPriority",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                LoadRecordSearch(viewModel.main().OrganizationID(), viewModel.main().DepartmentID(), viewModel.main().CampaingID());
            },
            error: function (request) {
                //alert(Error);
            }
        });
    };

    self.cancelRecord = function (item) {
        item.isHide(false);
    };
}


function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {

    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord(isLoad, mod) {
    isLoad = isLoad || false;
    $.ajax({
        url: pageName + "/GetRecord",
        type: 'POST',
        data: "{jsonModel : '" + ko.toJSON(mod) + "', isLoad : '" + isLoad + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new CampaignPriorityModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function LoadRecordSearch(OrganizationID, DepartmentID, CampaignID) {
    if (OrganizationID != undefined && DepartmentID != undefined && OrganizationID > 0 && DepartmentID > 0) {

        if (CampaignID == undefined) {
            CampaignID = -1;
        }
        $.ajax({
            url: pageName + "/GetRecordSearch",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(OrganizationID) + "', departmentID : '" + ko.toJSON(DepartmentID) + "', campaignID : '" + ko.toJSON(CampaignID) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    viewModel.main().allRecords([]);
                    if (data.d.CampaignsPriority != null) {
                        ko.utils.arrayForEach(data.d.CampaignsPriority, function (item) {
                            viewModel.main().allRecords.push(new CampaignPriorityModel(item));
                        });
                    }
                }
                else {
                    viewModel.main(new wrapperModel(null));
                    viewModel.main().editModel(new CampaignPriorityModel(null));
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    }
}