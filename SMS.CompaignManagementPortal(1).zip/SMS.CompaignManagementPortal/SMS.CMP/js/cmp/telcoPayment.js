﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var all_dept = [];
var refSearchText = '';

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

ko.bindingHandlers.mask = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor.get('value') || allBindingsAccessor.get('text') || {};
        ko.utils.registerEventHandler(element, "change", function () {
            $(element).text(maskValue(ko.utils.unwrapObservable(text)));
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var options = allBindingsAccessor().mask || {};
        var text = allBindingsAccessor.get('value') || allBindingsAccessor.get('text') || {};
        var ret = options.type == 'amount' ? 'Rs.' + maskValue(ko.utils.unwrapObservable(text)) : maskValue(ko.utils.unwrapObservable(text));
        options.updateParam == 'text' ? $(element).text(ret) : $(element).val(ret);

    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);
    self.SearchText = ko.observable(refSearchText);

    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.TelcoCompanies = ko.observableArray();
    self.isView = ko.observable(false);
    self.TelcoID = ko.observable();

    if (items != null) {

        if (items.TelcoCompanies != null) {
            ko.utils.arrayForEach(items.TelcoCompanies, function (item) {
                self.TelcoCompanies.push(new TelcoCompaniesModel(item));
            });
        }

        if (items.TelcoPayments != null) {
            self.allRecords([]);
            ko.utils.arrayForEach(items.TelcoPayments, function (item) {
                self.allRecords.push(new TelcoModel(item));
            });
        }


        self.PageSize(items.PageSize);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);

        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());

    }


    self.editRecord = function (item) {
        refModel = new TelcoModel(item);
        var modle = new TelcoModel(item);
        self.editModel(modle);
        self.allRecords.remove(item);
        self.isEdit(true);
    };

    self.cancelRecord = function () {
        self.editModel(new TelcoModel(null));
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "TelcoPayment.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.Status(false);
                    LoadRecord();
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        //}
    };

    self.saveRecord = function () {

        if ($('form').validationEngine('validate')) {

            if (viewModel.main().editModel().ExpiryDate() >= viewModel.main().editModel().PurchaseDate()) {
                $.ajax({
                    url: "TelcoPayment.aspx/SaveRecord",
                    type: 'POST',
                    data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        if (NotifyMe(data.d.Notification)) {
                            if (data.d.ID > 0) {
                                var mod = new TelcoModel(data.d);
                                self.allRecords.unshift(mod);
                                self.editModel(new TelcoModel(null));
                                self.isEdit(false);

                                LoadRecord();
                            }
                        }
                    },
                    error: function (er, _rr) {
                        NotifyMe("error|" + er.statusText);
                    }
                });
            }
            else {
                alert("Expiry Date should be greater and equal to purchase date")
            }

        }
    };

    self.Filter = function (data, event) {
        if ($('.search').val().trim() != '') {
            refSearchText = self.SearchText();
            viewModel.main().PageNo(1);
            LoadRecordSearch(viewModel.main(), refSearchText);

        }
        else {
            NotifyMe("info|Please type something in search box");
        }
        event.preventDefault();
        event.stopPropagation();
        //return true;
    };

    self.Reload = function () {
        refSearchText = '';
        LoadRecord();
    };

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        if (self.SearchText() == '')
            LoadRecord(viewModel.main());
        else
            LoadRecordSearch(viewModel.main(), self.SearchText())
    };
}

function TelcoModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.TelcoID = ko.observable(ko.utils.unwrapObservable(item.TelcoID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.TelcoName = ko.observable(ko.utils.unwrapObservable(item.TelcoName));
        self.IsOnNet = ko.observable(ko.utils.unwrapObservable(item.IsOnNet));

        self.PurchaseDate = ko.observable(ko.utils.unwrapObservable(item.PurchaseDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.PurchaseDate).substring(6, 19))) : ko.utils.unwrapObservable(item.PurchaseDate));
        self.ExpiryDate = ko.observable(ko.utils.unwrapObservable(item.ExpiryDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.ExpiryDate).substring(6, 19))) : ko.utils.unwrapObservable(item.ExpiryDate));

        self.TotalSMS = ko.observable(ko.utils.unwrapObservable(item.TotalSMS));
        self.RemainingSMS = ko.observable(ko.utils.unwrapObservable(item.RemainingSMS));
        self.UsedSMS = ko.observable(ko.utils.unwrapObservable(item.UsedSMS));
        self.PerSMSRate = ko.observable(ko.utils.unwrapObservable(item.PerSMSRate));
        self.TotalBalance = ko.observable(ko.utils.unwrapObservable(item.TotalBalance));

        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.VersionNo = ko.observable(ko.utils.unwrapObservable(item.VersionNo));

    }
    else {
        self.ID = ko.observable();
        self.TelcoID = ko.observable();
        self.Title = ko.observable();
        self.TelcoName = ko.observable();
        self.IsOnNet = ko.observable();

        self.PurchaseDate = ko.observable(new Date());
        self.ExpiryDate = ko.observable(new Date());

        self.TotalSMS = ko.observable(0);
        self.RemainingSMS = ko.observable(0);
        self.UsedSMS = ko.observable(0);
        self.PerSMSRate = ko.observable(0);
        self.TotalBalance = ko.observable(0);
        self.Status = ko.observable();
        self.VersionNo = ko.observable();

    }

    self.TotalSMS.subscribe(function (newValue) {
        self.RemainingSMS(self.ID() != null && self.ID() != undefined ? newValue - self.UsedSMS() : newValue);
    });

    self.TotalBalance = ko.computed(function () {
        return self.TotalSMS() * self.PerSMSRate();
    });
}

function TelcoCompaniesModel(org) {
    var self = this;
    self.ID = ko.observable(org.TelcoID);
    self.Title = ko.observable(org.Title);
}


function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {
    $.ajax({
        url: "TelcoPayment.aspx/GetRecords",
        type: 'POST',
        data: "{jsonModel : '" + ko.toJSON(mod) + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new TelcoModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new TelcoModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function LoadRecordSearch(mod, searchText) {
    $.ajax({
        url: "TelcoPayment.aspx/GetRecordSearch",
        type: 'POST',
        data: "{jsonModel : '" + ko.toJSON(mod) + "', searchText : '" + searchText + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new TelcoModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new TelcoModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}


function maskValue(value) {
    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}