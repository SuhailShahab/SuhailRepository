﻿
var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var all_addressBook = [];
var msgTypes = [{ 'Title': 'Message (english)', 'MessageType': '2' }, { 'Title': 'Message (urdu)', 'MessageType': '3' }];
var refSearchText = '';
var minuteInterval = 10;
var ref_CampaignSchedules = [];
var all_organization = []; //
var all_departments = [];//
//** TimePicker Custom binding **\\

ko.bindingHandlers.timeValue = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
        var tpicker = $(element).timepicker();
        tpicker.on('changeTime.timepicker', function (e) {

            //Asignar la hora y los minutos
            var value = valueAccessor();
            if (!value) {
                throw new Error('timeValue binding observable not found');
            }
            var date = ko.unwrap(value);
            var mdate = moment(date || new Date());
            var hours24;
            if (e.time.meridian == "AM") {
                if (e.time.hours == 12)
                    hours24 = 0;
                else
                    hours24 = e.time.hours;
            }
            else {
                if (e.time.hours == 12) {
                    hours24 = 12;
                }
                else {
                    hours24 = e.time.hours + 12;
                }
            }

            mdate.hours(hours24)
            mdate.minutes(e.time.minutes);
            $(element).data('updating', true);
            value(mdate.toDate());
            $(element).data('updating', false);


        })
    },
    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
        //Avoid recursive calls
        if ($(element).data('updating')) {
            return;
        }
        var date = ko.unwrap(valueAccessor()) || new Date();

        if (date) {
            var time = moment(date).format("hh:mmA");
            //var matches = time.match(/(\d{1,2}):(\d{2})/);
            //var zone = parseInt(matches[0]) >= 12 ? 'PM' : 'AM';
            //time = matches[1] + ':' + matches[2] + ' ' + zone;
            $(element).timepicker('setTime', time);
        }
        else {
            // $(element).timepicker('clear');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};


ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($(element))) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.AllowUpdate = ko.observable(true);
    self.IsAllowedChangedExpirtyDate = ko.observable(true);
    self.PageSize = ko.observable(5);

    self.ContactCurrentPage = ko.observable(1);
    self.ContactPageSize = ko.observable(50);

    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);
    self.SearchText = ko.observable(refSearchText);

    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.CampaignStatistics = ko.observableArray();

    self.SMSTypes = ko.observableArray();
    self.SMSTemplates = ko.observableArray();
    self.Masks = ko.observableArray();
    self.IncomingMasks = ko.observableArray();
    self.ShortCodes = ko.observableArray();
    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();
    self.DepartmentsFilter = ko.observableArray(); //
    self.Users = ko.observableArray();
    self.ProcessingStatuses = ko.observableArray();
    self.OrganizationID = ko.observable(); //
    self.DepartmentID = ko.observable(); //
    self.ShowPriorityID = ko.observable(false); //06-03-2018, ShowPriorityID
    self.AssignContacts = ko.observableArray();
    self.AssignGroups = ko.observableArray();

    self.CampaignSchedules = ko.observableArray();
    self.MappedCampaignSchedules = ko.observableArray();

    self.SelectDate = ko.observable(new Date().format("d/M/yyyy"));

    ref_CampaignSchedules = [];
    ko.utils.arrayForEach(new Array(24), function (sched) {
        ref_CampaignSchedules.push(new CampaignScheduleModel(sched));
    });
    self.CampaignSchedules([]);
    self.CampaignSchedules(ref_CampaignSchedules);

    self.hasAssignAllContacts = ko.observable(false);
    self.hasAssignAllBooks = ko.observable(false);

    self.User = ko.observable(new UserRightsModel(null));

    if (items != null) {

        self.ShowPriorityID = ko.observable(ko.utils.unwrapObservable(items.ShowPriorityID)); //06-03-2018, ShowPriorityID

        self.AllowUpdate(ko.utils.unwrapObservable(items.AllowUpdate));

        if (items.SMSCampaignsLog != null) {
            self.CampaignStatistics.push(new CampaignStatisticsModel(items.SMSCampaignsLog[0]));
        }
        else {
            self.CampaignStatistics.push(new CampaignStatisticsModel(null));
        }

        if (items.MappedCampaignSchedules != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.MappedCampaignSchedules), function (sched) {
                self.MappedCampaignSchedules.push(new CampaignScheduleModel(sched));
            });
        }

        if (items.SMSTypes != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.SMSTypes), function (smsType) {
                self.SMSTypes.push(new SMSTypeModel(smsType));
            });
        }

        if (items.SMSTemplates != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.SMSTemplates), function (smsTemp) {
                self.SMSTemplates.push(new SMSTemplateModel(smsTemp));
            });
        }


        if (items.ShortCodes != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.ShortCodes), function (code) {
                self.ShortCodes.push(new ShortCodeModel(code));
            });
        }

        if (items.Organizations != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Organizations), function (organ) {
                self.Organizations.push(new OrganizationModel(organ));
            });
        }

        if (items.Departments != null) {
            self.Departments([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Departments), function (dept) {
                self.Departments.push(new DepartmentModel(dept));
            });
        }

        if (items.Users != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Users), function (user) {
                self.Users.push(new UserModel(user));
            });
        }

        if (items.ProcessingStatuses != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.ProcessingStatuses), function (status) {
                self.ProcessingStatuses.push(new ProcessingStatusModel(status));
            });
        }

        if (items.SMSCampaignsLog != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(items.SMSCampaignsLog, function (item) {
                self.allRecords.push(new SMSCampaignModel(item));
                ref_all_rec.push(new SMSCampaignModel(item))
            });
        }

        //  self.ContactPageSize(items.ContactPageSize || 50);
        self.PageSize(items.PageSize);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());
    };

    self.editRecord = function (item) {
        //debugger
        $.ajax({
            url: "SMSCampaign.aspx/GetSMSCampaignAddressContact",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    var temp = [];
                    if (data.d.AddressBooks != null) {
                        ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.AddressBooks), function (book) {
                            temp.push(new AddressBookModel(book));
                        });
                        item.AddressBooks(temp);
                    }

                    if (data.d.Contacts != null) {
                        temp = [];
                        item.Contacts([]);
                        ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Contacts), function (cntct) {
                            temp.push(new ContactModel(cntct));
                        });
                        item.Contacts(temp);
                    }

                    // console.log(data.d.Contacts.length + " addressbook = " + data.d.AddressBooks.length);

                    if (data.d.Departments != null) {
                        temp = [];
                        self.Departments([]);
                        ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Departments), function (dept) {
                            temp.push(new DepartmentModel(dept));
                        });
                        self.Departments(temp);
                    }

                    if (data.d.Users != null) {
                        temp = [];
                        self.Users([]);
                        ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Users), function (user) {
                            temp.push(new UserModel(user));
                        });
                        self.Users(temp);
                    }

                    if (data.d.ShortCodes != null) {
                        temp = [];
                        self.ShortCodes([]);
                        ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.ShortCodes), function (shrt) {
                            temp.push(new ShortCodeModel(shrt));
                        });
                        self.ShortCodes(temp);
                    }

                    if (data.d.Masks != null) {
                        temp = [];
                        self.Masks([]);
                        ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Masks), function (msk) {
                            temp.push(new MaskModel(msk));

                        });
                        self.Masks(temp);
                    }

                    if (data.d.IncomingMasks != null) {
                        temp = [];
                        self.IncomingMasks([]);
                        ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.IncomingMasks), function (msk) {
                            temp.push(new MaskModel(msk));
                        });
                        self.IncomingMasks(temp);
                    }

                    if (data.d.ProcessingStatuses != null) {
                        temp = [];
                        self.ProcessingStatuses([]);
                        ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.ProcessingStatuses), function (prc) {
                            temp.push(new ProcessingStatusModel(prc));
                        });
                        self.ProcessingStatuses(temp);
                    }

                    if (data.d.SMSTemplates != null) {
                        temp = [];
                        self.SMSTemplates([]);
                        ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.SMSTemplates), function (templ) {
                            temp.push(new SMSTemplateModel(templ));
                        });
                        self.SMSTemplates(temp);
                    }

                    $('.tblSchedual tr td').removeClass('highlight');
                    if (data.d.MappedCampaignSchedules != null) {
                        viewModel.main().MappedCampaignSchedules([]);
                        ko.utils.arrayForEach(data.d.MappedCampaignSchedules, function (sched) {
                            self.MappedCampaignSchedules.push(new CampaignScheduleModel(sched));
                            sched.ColIndex = Math.ceil(sched.ColIndex / minuteInterval);
                            sched.ColIndex = sched.ColIndex == 0 ? 1 : sched.ColIndex + 1;
                            var r_idx = sched.RowIndex == 0 ? 1 : sched.RowIndex + 1;
                            highlightCells(r_idx, sched.ColIndex, sched.CellCount, '', true);
                        });
                    }

                    refModel = new SMSCampaignModel(item);
                    self.editModel(new SMSCampaignModel(item));
                    self.editModel().DepartmentID(item.DepartmentID());
                    self.editModel().UserID(item.UserID());
                    self.editModel().MaskID(item.MaskID());
                    self.editModel().IncomingMaskID(item.IncomingMaskID());
                    self.editModel().TemplateID(item.TemplateID());
                    self.SelectDate(item.CampaignStartDate());
                    self.allRecords.remove(item);
                    self.isEdit(true);

                }
            },
            error: function (request) {
                alert(Error);
            }
        });
    };

    self.cancelRecord = function () {
        LoadRecord(false);
    };

    self.removeRecord = function (item) {
        $.ajax({
            url: "SMSCampaign.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.IsActive(false);
                    LoadRecord(true);
                }
            },
            error: function (request) {
                alert(Error);
            }
        });
    };

    self.sendRecord = function (item) {
        $.ajax({
            url: "SMSCampaign.aspx/SendCampaign",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.IsActive(false);
                    //NotifyMe("inactivesuccess");
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };

    self.stopProceed = function (mod) {
        $.ajax({
            url: "SMSCampaign.aspx/SetCampaignProceed",
            type: 'POST',
            data: "{campaignID : '" + mod.CampaignID() + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d > 0) {
                    mod.ProcessingStatusTitle('Processed');
                    NotifyMe("inactivesuccess");
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };

    self.reinitiateCampaign = function (mod) {
        $.ajax({
            url: "SMSCampaign.aspx/ReInitiateCampaign",
            type: 'POST',
            data: "{campaignID : '" + mod.CampaignID() + "', organizationID : '" + mod.OrganizationID() + "', versionNo : '" + mod.VersionNo() + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (data.d != null && data.d != "") {
                        if (data.d == 1) {
                            mod.ProcessingStatusTitle('Initiate Campaign');
                            NotifyMe("info|Campaign has been reset successfully.");
                        }
                        else if (data.d == 3) {
                            NotifyMe("info|There is no pending message in campaign.");
                        }
                    }
                    //NotifyMe("inactivesuccess");
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            if (viewModel.main().editModel().CampaignStartDate() != null && viewModel.main().editModel().CampaignStartDate() != '') {
                if (validateEmptyMessage(viewModel.main().editModel())) {
                    $.ajax({
                        url: "SMSCampaign.aspx/SaveRecord",
                        type: 'POST',
                        data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                        dataType: "json",
                        contentType: "application/json; charset=utf-8",
                        success: function (data) {
                            if (NotifyMe(data.d.Notification)) {
                                if (data.d != null) {
                                    var mod = new SMSCampaignModel(viewModel.main().editModel());
                                    self.allRecords.unshift(mod);
                                    self.editModel(new SMSCampaignModel(null));
                                    self.isEdit(false);
                                    LoadRecord(false);
                                    //NotifyMe("saverecordSuccess");
                                }
                            }
                        },
                        error: function (er, _rr) {
                            NotifyMe("error|" + er.statusText);
                        }
                    });

                }
                else {
                    NotifyMe("warning|Please add some text in message box.");
                }
            }
            else {
                NotifyMe("warning|Please select Schedule Time.");
            }
        }
    };

    self.assignContacts = function () {
        ko.utils.arrayForEach(ko.utils.unwrapObservable(self.AssignContacts), function (cntct) {
            if (cntct.Assigned()) {
                self.editModel().Contacts.push(new ContactModel(cntct));
            }
        });

        $('#ContactModal').modal('hide');
    };

    self.assignGroups = function () {
        ko.utils.arrayForEach(ko.utils.unwrapObservable(self.AssignGroups), function (grp) {
            if (grp.Assigned()) {

                //if (self.editModel().AddressBooks.indexOf(grp) < 0) {
                //    self.editModel().AddressBooks.push(new AddressBookModel(grp));
                //}
                //Check Item already Exist
                var match = ko.utils.arrayFirst(self.editModel().AddressBooks(), function (item) {
                    return grp.AddressBookID() == item.AddressBookID();
                });

                if (!match) {
                    self.editModel().AddressBooks.push(new AddressBookModel(grp));
                }

            }
        });
        $('#AddressBookModal').modal('hide');
    };

    self.getDepartments = function (item) {

        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "SMSCampaign.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {

                        self.Departments([]);
                        if (data.d.Departments != null) {

                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                self.Departments.push(new DepartmentModel(dept));
                            });
                        }

                        self.ShortCodes([]);
                        if (data.d.ShortCodes != null) {

                            ko.utils.arrayForEach(data.d.ShortCodes, function (shrt) {
                                self.ShortCodes.push(new ShortCodeModel(shrt));
                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        viewModel.main().Masks([]);
        viewModel.main().IncomingMasks([]);
    };

    self.getFilterDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "SMSCampaign.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d != null) {
                            self.DepartmentsFilter([]);
                            if (all_departments != null) {
                                all_departments = [];
                            }
                            if (data.d.Departments != null)
                                ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                    self.DepartmentsFilter.push(new DepartmentModel(dept));
                                    all_departments.push(new DepartmentModel(dept));
                                });
                        }
                    }
                    else {
                        self.DepartmentsFilter([]);
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else
            self.DepartmentsFilter([]);
    };

    self.getUsers = function (item) {
      //  alert(getUsers.SMSLimit());
      //  alert(getUsers.IsAllowUpdateCampaignName());
        if (item.DepartmentID() != undefined && item.OrganizationID() != undefined) {
            $.ajax({
                url: "SMSCampaign.aspx/GetUsers",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "', departmentID : '" + ko.toJSON(item.DepartmentID()) + "', shortcodeID : '" + ko.toJSON(item.ShortCodeID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.Users != null) {
                            self.Users([]);
                            ko.utils.arrayForEach(data.d.Users, function (user) {
                                self.Users.push(new UserModel(user));
                            });
                        }

                        if (data.d.SMSTemplates != null) {
                            self.SMSTemplates([]);
                            ko.utils.arrayForEach(data.d.SMSTemplates, function (user) {
                                self.SMSTemplates.push(new SMSTemplateModel(user));
                            });
                        }

                        if (data.d.ShortCodes != null) {
                            self.ShortCodes([]);
                            ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.ShortCodes), function (code) {
                                self.ShortCodes.push(new ShortCodeModel(code));
                            });
                        }

                        if (data.d.Masks != null) {
                            self.Masks([]);
                            self.IncomingMasks([]);
                            ko.utils.arrayForEach(data.d.Masks, function (msk) {
                                self.Masks.push(new MaskModel(msk));
                                self.IncomingMasks.push(new MaskModel(msk));
                            });



                        }
                    }
                    else {
                        self.Users([]);
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });

            var filter_dept = ko.utils.arrayFilter(self.Departments(), function (dept) {
                return ko.utils.unwrapObservable(dept.DepartmentID) == ko.utils.unwrapObservable(item.DepartmentID);
            });
            if (filter_dept != null && filter_dept.length > 0 && filter_dept != '') {
                item.PerSMSRate(ko.utils.unwrapObservable(filter_dept[0].PerSMSRate));
                item.TotalAllocatedSMS(ko.utils.unwrapObservable(filter_dept[0].SMSLimit));
                //item.IsAllowedCampaingName(ko.utils.unwrapObservable(false));
                item.IsAllowedCampaingName(ko.utils.unwrapObservable(filter_dept[0].IsAllowedCampaingName));
            }
        }
    };

    self.assignAllBooks = function (items, obj) {
        if (self.hasAssignAllBooks()) {
            ko.utils.arrayForEach(items.AssignGroups(), function (item) {
                item.Assigned(true);
            });
        }
        else {
            ko.utils.arrayForEach(items.AssignGroups(), function (item) {
                item.Assigned(false);
            });
        }
        return true;
    };

    self.assignAllContacts = function (items, obj, event) {
        if (self.hasAssignAllContacts()) {
            ko.utils.arrayForEach(items.AssignContacts(), function (item) {
                item.Assigned(true);
            });
        }
        else {
            ko.utils.arrayForEach(items.AssignContacts(), function (item) {
                item.Assigned(false);
            });
        }
        return true;
    };

    self.Filter = function (data, event) {
        //if ($('#txtSearch').val().trim() != '') {
        refSearchText = self.SearchText();
        viewModel.main().PageNo(1);
        LoadRecordSearch(ko.utils.unwrapObservable(self.OrganizationID()), ko.utils.unwrapObservable(self.DepartmentID()), viewModel.main(), refSearchText);

        //}
        //else {
        //    NotifyMe("info|Please type something in search box");
        //}
        event.preventDefault();
        event.stopPropagation();
        //return true;
    };

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        //if (self.SearchText() == '')
        //    LoadRecord(true,viewModel.main());
        //else
        LoadRecordSearch(ko.utils.unwrapObservable(self.OrganizationID()), ko.utils.unwrapObservable(self.DepartmentID()), viewModel.main(), self.SearchText())
    };

    self.Reload = function () {
        refSearchText = '';
        //LoadRecord(true);
        self.SearchText('');
        LoadRecordSearch(ko.utils.unwrapObservable(self.OrganizationID()), ko.utils.unwrapObservable(self.DepartmentID()), viewModel.main(), self.SearchText())
    };

    self.templateChange = function () {
        if (this.TemplateID() != null && this.TemplateID() != undefined) {
            this.MessageType('1');
        }
        else if (this.MessageType() != '' && this.MessageType() != null && this.CampaignID() != null) {
            this.MessageType(this.MessageType());
        }
        else {
            this.MessageType('2');
        }
    };

    self.searchRecord = function () {
        self.ContactCurrentPage(1);
        var searchText = $(".searchContact").val();
        self.viewMoreContats(null, null, searchText, true);
    };

    self.reloadContact = function () {
        self.ContactCurrentPage(1);
        $(".searchContact").val('');
        viewModel.main().AssignContacts([]);
        self.viewMoreContats(null, null, '', false);
    }

    self.viewMoreContats = function (data, event, searchText, isReload) {
        searchText = searchText || '';
        isReload = isReload || false;
        // alert(self.editModel().CampaignID());
        $.ajax({
            url: "SMSCampaign.aspx/GetContactsSearch",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(self.editModel().OrganizationID()) + "',departmentID : '" + ko.toJSON(self.editModel().DepartmentID()) + "',pageNo : '" + ko.toJSON(self.ContactCurrentPage()) + "',pageSize : '" + ko.toJSON(self.ContactPageSize()) + "',searchText : '" + searchText + "', campaignID:'" + self.editModel().CampaignID() + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (isReload) {
                        viewModel.main().AssignContacts([]);
                    }
                    if (data.d.Contacts != null) {
                        ko.utils.arrayForEach(data.d.Contacts, function (contact) {
                            viewModel.main().AssignContacts.push(new ContactModel(contact));
                        });
                        viewModel.main().ContactCurrentPage(parseInt(viewModel.main().ContactCurrentPage()) + 1);
                    }
                    else {
                        NotifyMe("info|Sorry.. No record found");
                    }
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };

    self.closeContactPopUp = function () {
        self.ContactCurrentPage(1);
        $(".searchContact").val('');
    };

    self.cellClick = function (data, event) {
        var target;
        if (event.target) target = event.target;
        else if (event.srcElement) target = event.srcElement;

        if (!$(target).hasClass('highlighted')) {

            var contactsCount = 0;
            contactsCount = $(".tblContacts > tbody tr td > input[type='checkbox']:checked").length;

            if (self.editModel().AddressBooks().length > 0) {
                ko.utils.arrayForEach(self.editModel().AddressBooks(), function (item) {
                    //if (ko.utils.unwrapObservable(item.Assigned)) {
                    contactsCount = contactsCount + ko.utils.unwrapObservable(item.AddressBookContactsCount);
                    //}
                });
            }

            ko.utils.arrayForEach(self.MappedCampaignSchedules(), function (item) {
                if (item != undefined) {
                    if (item.ScheduleID() == self.editModel().CampaignID() || item.ScheduleID() == null || item.ScheduleID() == undefined) {
                        UnHighlightCells(item.RowIndex(), item.ColIndex() / minuteInterval, item.CellCount());
                        self.MappedCampaignSchedules.remove(item);
                    }
                }
            });

            var colIndex = parseInt($(target).parent().children().index($(target)));
            var rowIndex = parseInt($(target).parent().parent().children().index($(target).parent()) + 1);
            var cellCounts = Math.ceil(parseInt(parseInt(contactsCount || 0) / 1000) / minuteInterval);
            cellCounts = cellCounts < 1 ? 1 : cellCounts;

            var currentTime = new Date();
            var dat = new Date(self.SelectDate());
            dat.setHours(rowIndex - 1);
            dat.setMinutes((colIndex - 1) == 6 ? 59 : (colIndex - 1) * 10);
            if (dat >= currentTime) {
                self.editModel().ScheduleTime(dat);
                self.editModel().CampaignStartDate(dat);
                self.SelectDate(dat);
                highlightCells(rowIndex, colIndex, cellCounts, viewModel.main().editModel().Title());
            }
            else {
                NotifyMe('info|Please select future time.');
            }
            var mode = new CampaignScheduleModel(null);
            mode.RowIndex(rowIndex);
            mode.ColIndex(colIndex * 10);
            mode.CellCount(cellCounts);
            self.MappedCampaignSchedules.push(mode);
        }
        else {
            NotifyMe('info|Sorry this slot has been occupied already');
        }
    };

    self.cellHover = function (data, event) {
        var target;
        if (event.target) target = event.target;
        else if (event.srcElement) target = event.srcElement;

        var colIndex = parseInt(($(target).parent().children().index($(target)) - 1) * 10);
        var rowIndex = parseInt($(target).parent().parent().children().index($(target).parent()));
        $(target).text(rowIndex + ' : ' + colIndex + ' - ' + rowIndex + ' : ' + parseInt(parseInt(colIndex) + 9));
    };

    self.cellUnhover = function (data, event) {
        var target;
        if (event.target) target = event.target;
        else if (event.srcElement) target = event.srcElement;
        $(target).text('');
    };

    self.getAllSchedule = function () {
        $.ajax({
            url: "SMSCampaign.aspx/GetAllSchedules",
            type: 'POST',
            data: "{scheduleDate : '" + self.SelectDate().format('MM/dd/yyyy') + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    $('.tblSchedual tr td').removeClass('highlight');
                    $('.tblSchedual tr td').removeClass('highlighted');
                    if (data.d.MappedCampaignSchedules != null) {
                        viewModel.main().MappedCampaignSchedules([]);
                        ko.utils.arrayForEach(data.d.MappedCampaignSchedules, function (sched) {
                            viewModel.main().MappedCampaignSchedules.push(new CampaignScheduleModel(sched));
                            sched.ColIndex = Math.ceil(sched.ColIndex / minuteInterval);
                            sched.ColIndex = sched.ColIndex == 0 ? 1 : sched.ColIndex + 1;
                            var r_idx = sched.RowIndex == 0 ? 1 : sched.RowIndex + 1;
                            highlightCells(r_idx, sched.ColIndex, sched.CellCount, '', true);
                        });
                    }
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };

    self.scheduleCampaign = function () {
        //var dat = new Date(self.SelectDate());
        //dat.setHours(rowIndex);
        //dat.setMinutes(colIndex * 10);
        //self.editModel().ScheduleTime(dat);
        //self.editModel().CampaignStartDate(dat);
        $('#ScheduleModal').modal('hide');
    };

    self.scheduleTime = function () {
        self.getAllSchedule();
        $('#ScheduleModal').modal('show');
        $('#ScheduleModal').focus();
    };

    self.scheduleModalClose = function () {
        if (self.editModel().CampaignID() != null && self.editModel().CampaignID() != undefined) {
            if (refModel != null) {
                self.editModel().ScheduleTime(refModel.ScheduleTime());
                self.editModel().CampaignStartDate(refModel.CampaignStartDate());
                self.SelectDate(refModel.CampaignStartDate());
            }
        }
        else {
            self.editModel().ScheduleTime('');
            self.editModel().CampaignStartDate('');
            $('.tblSchedual tr td').removeClass('highlight');
            $('.tblSchedual tr td').removeClass('highlighted');
        }
        $('#ScheduleModal').modal('hide');
    };
}

function CampaignScheduleModel(sched) {
    var self = this;
    if (sched != null) {
        self.ScheduleID = ko.observable(sched.ScheduleID);
        self.Title = ko.observable(sched.Title);
        self.IsHighlight = ko.observable(sched.IsHighlight || false);
        self.RowIndex = ko.observable(sched.RowIndex || 0);
        self.ColIndex = ko.observable(sched.ColIndex || 0);
        self.CellCount = ko.observable(sched.CellCount || 0);
        self.ScheduleDate = ko.observable(sched.ScheduleDate);
    }
    else {
        self.ScheduleID = ko.observable();
        self.Title = ko.observable('');
        self.IsHighlight = ko.observable('');
        self.RowIndex = ko.observable(0);
        self.ColIndex = ko.observable(0);
        self.CellCount = ko.observable(0);
        self.ScheduleDate = ko.observable('');
    }
}

function CampaignStatisticsModel(item) {
    var self = this;
    if (item != null) {
        self.DailyCampaigns = ko.observable(ko.utils.unwrapObservable(item.DailyCampaigns));
        self.MonthlyCampaigns = ko.observable(ko.utils.unwrapObservable(item.MonthlyCampaigns));
        self.YearlyCampaigns = ko.observable(ko.utils.unwrapObservable(item.YearlyCampaigns));
        self.WeeklyCampaigns = ko.observable(ko.utils.unwrapObservable(item.WeeklyCampaigns));
    }
    else {
        self.DailyCampaigns = ko.observable(0);
        self.MonthlyCampaigns = ko.observable(0);
        self.MonthlyCampaigns = ko.observable(0);
        self.WeeklyCampaigns = ko.observable(0);
        self.YearlyCampaigns = ko.observable(0);
    }
}

function SMSCampaignModel(item) {
    var self = this;

    if (item != null) {
        self.CampaignID = ko.observable(ko.utils.unwrapObservable(item.CampaignID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.SMSTypeID = ko.observable(ko.utils.unwrapObservable(item.SMSTypeID));
        self.MaskID = ko.observable(ko.utils.unwrapObservable(item.MaskID));

        self.TemplateID = ko.observable(ko.utils.unwrapObservable(item.TemplateID));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.UserID = ko.observable(ko.utils.unwrapObservable(item.UserID));
        self.StatusID = ko.observable(ko.utils.unwrapObservable(item.StatusID));
        self.ShortCodeID = ko.observable(ko.utils.unwrapObservable(item.ShortCodeID));
        self.MessageEnglish = ko.observable(ko.utils.unwrapObservable(item.MessageEnglish));
        self.MessageUrdu = ko.observable(ko.utils.unwrapObservable(item.MessageUrdu));
        self.MessageType = ko.observable(ko.utils.unwrapObservable(item.MessageType).toString());
        self.EndDate = ko.observable(ko.utils.unwrapObservable(item.EndDate));
        self.Confirmation = ko.observable(ko.utils.unwrapObservable(item.Confirmation));
        self.Repetition = ko.observable(ko.utils.unwrapObservable(item.Repetition));
        self.IsSchedule = ko.observable(ko.utils.unwrapObservable(item.IsSchedule));
        self.CampaignStartDate = ko.observable(ko.utils.unwrapObservable(item.CampaignStartDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.CampaignStartDate).substring(6, 19))) : ko.utils.unwrapObservable(item.CampaignStartDate));
        self.ScheduleTime = ko.observable(ko.utils.unwrapObservable(item.ScheduleTime).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.ScheduleTime).substring(6, 19))) : ko.utils.unwrapObservable(item.ScheduleTime));

        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.UserID = ko.observable(ko.utils.unwrapObservable(item.UserID));
        self.PaymentID = ko.observable(ko.utils.unwrapObservable(item.PaymentID));
        self.CampaignID = ko.observable(ko.utils.unwrapObservable(item.CampaignID));
        self.PurchaseDate = ko.observable(ko.utils.unwrapObservable(item.PurchaseDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.PurchaseDate).substring(6, 19))) : ko.utils.unwrapObservable(item.PurchaseDate));
        self.ExpiryDate = ko.observable(ko.utils.unwrapObservable(item.ExpiryDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.ExpiryDate).substring(6, 19))) : ko.utils.unwrapObservable(item.ExpiryDate));
        self.TotalAllocatedSMS = ko.observable(ko.utils.unwrapObservable(item.TotalAllocatedSMS));
        self.TotalRemainSMS = ko.observable(ko.utils.unwrapObservable(item.TotalRemainSMS));
        self.PerSMSRate = ko.observable(ko.utils.unwrapObservable(item.PerSMSRate));
        self.IsActive = ko.observable(ko.utils.unwrapObservable(item.IsActive));
        self.Contacts = ko.observableArray();
        self.AddressBooks = ko.observableArray();
        //self.ReSchedule = ko.observable(false); //CR:001
        self.ReSchedule = ko.observable(ko.utils.unwrapObservable(item.ReSchedule)); //CR:001

        self.HasRun = ko.observable(ko.utils.unwrapObservable(item.HasRun));
        self.ProcessingStatusTitle = ko.observable(ko.utils.unwrapObservable(item.ProcessingStatusTitle));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.VersionNo = ko.observable(ko.utils.unwrapObservable(item.VersionNo));

        self.InforceBucket = ko.observable(ko.utils.unwrapObservable(item.InforceBucket));

        if (ko.utils.unwrapObservable(item.Contacts) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(item.Contacts), function (contact) {
                self.Contacts.push(new ContactModel(contact));
            });
        }
        if (ko.utils.unwrapObservable(item.AddressBooks) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(item.AddressBooks), function (grp) {
                self.AddressBooks.push(new AddressBookModel(grp));
            });
        }


        self.ServiceUrl = ko.observable(ko.utils.unwrapObservable(item.ServiceUrl));
        self.ResponseMessage = ko.observable(ko.utils.unwrapObservable(item.ResponseMessage));
        self.MethodName = ko.observable(ko.utils.unwrapObservable(item.MethodName));

        self.IncomingMaskID = ko.observable(ko.utils.unwrapObservable(item.IncomingMaskID));
        self.IncomingShortCodeID = ko.observable(ko.utils.unwrapObservable(item.IncomingShortCodeID));

        // code added by hammad - 27-01-2016 03:53:28PM, start

        self.NoOfSMSEng = ko.observable();
        self.NoOfSMSUrd = ko.observable();

        self.ResponseMessageType = ko.observable(ko.utils.unwrapObservable(item.ResponseLanguageMode) == true ? '1' : '0');
        self.ResponseLanguageMode = ko.observable();
        self.ResponseMessageUrdu = ko.observable(ko.utils.unwrapObservable(item.ResponseMessageUrdu));

        self.ResponseNoOfSMSEng = ko.observable();
        self.ResponseNoOfSMSUrd = ko.observable();

        // code added by hammad - 27-01-2016 03:53:28PM, end
        self.PriorityID = ko.observable(ko.utils.unwrapObservable(item.PriorityID)); //06-03-2018, PriorityID
        self.IsAllowedCampaingName = ko.observable(ko.utils.unwrapObservable(item.IsAllowedCampaingName) || true);


    }
    else {
        self.CampaignID = ko.observable('');
        self.Title = ko.observable();
        self.SMSTypeID = ko.observable('');
        self.MaskID = ko.observable('');
        self.TemplateID = ko.observable('');
        self.UserID = ko.observable('');
        self.StatusID = ko.observable('');
        self.ShortCodeID = ko.observable('');
        self.MessageEnglish = ko.observable('');
        self.MessageUrdu = ko.observable('');
        self.MessageType = ko.observable('2');
        self.EndDate = ko.observable('');
        self.Confirmation = ko.observable(false);
        self.Repetition = ko.observable(false);
        self.IsSchedule = ko.observable(false);
        self.CampaignStartDate = ko.observable('');
        self.ScheduleTime = ko.observable('');
        self.PaymentID = ko.observable();
        self.UserID = ko.observable();
        self.DepartmentID = ko.observable();
        self.CampaignID = ko.observable();
        self.PurchaseDate = ko.observable('');
        self.ExpiryDate = ko.observable('');
        self.TotalAllocatedSMS = ko.observable(0);
        self.TotalRemainSMS = ko.observable(0);
        self.PerSMSRate = ko.observable(0);
        self.OrganizationID = ko.observable();
        self.Contacts = ko.observableArray();
        self.AddressBooks = ko.observableArray();

        self.ReSchedule = ko.observable(false); //CR:001

        self.HasRun = ko.observable(1);
        self.ProcessingStatusTitle = ko.observable('');
        self.IsActive = ko.observable();
        self.Status = ko.observable();

        self.VersionNo = ko.observable(null);

        self.ServiceUrl = ko.observable('');
        self.ResponseMessage = ko.observable('');
        self.MethodName = ko.observable('');

        self.IncomingMaskID = ko.observable('');
        self.IncomingShortCodeID = ko.observable('');
        self.InforceBucket = ko.observable(false);

        // code added by hammad - 27-01-2016 03:53:28PM, start

        self.NoOfSMSEng = ko.observable();
        self.NoOfSMSUrd = ko.observable();

        self.ResponseMessageType = ko.observable('0');
        self.ResponseLanguageMode = ko.observable(false);
        self.ResponseMessageUrdu = ko.observable('');

        self.ResponseNoOfSMSEng = ko.observable();
        self.ResponseNoOfSMSUrd = ko.observable();

        // code added by hammad - 27-01-2016 03:53:28PM, end
        self.PriorityID = ko.observable(null); //06-03-2018, PriorityID
        self.IsAllowedCampaingName = ko.observable(true);
    }

    self.CharacterCount = ko.computed(function () {
        return (3000 - parseInt(self.MessageEnglish().length)) < 0 ? 'Limit Exceeded' : 3000 - parseInt(self.MessageEnglish().length);
    });

    self.MessageCountEn = ko.computed(function () {
        //return parseInt(parseInt(self.MessageEnglish().length) % 153) == 0 ? parseInt(parseInt(self.MessageEnglish().length) / 153) || 0 : parseInt(parseInt(self.MessageEnglish().length) / 153) + 1 || 0; // comment by hammad - 27-01-2016 15:53:28 for implement no of sms count

        var count = parseInt(parseInt(self.MessageEnglish().length) % 153) == 0 ? parseInt(parseInt(self.MessageEnglish().length) / 153) || 0 : parseInt(parseInt(self.MessageEnglish().length) / 153) + 1 || 0;
        self.NoOfSMSEng(count);
        return count;
    });

    self.CharacterCountUr = ko.computed(function () {
        return (1000 - parseInt(self.MessageUrdu().length)) < 0 ? 'Limit Exceeded' : 1000 - parseInt(self.MessageUrdu().length);
    });

    self.MessageCountUr = ko.computed(function () {
        //return parseInt(parseInt(self.MessageUrdu().length) % 67) == 0 ? parseInt(parseInt(self.MessageUrdu().length) / 67) || 0 : parseInt(parseInt(self.MessageUrdu().length) / 67) + 1 || 0;       // comment by hammad - 27-01-2016 15:53:28 for implement no of sms count

        var count = parseInt(parseInt(self.MessageUrdu().length) % 67) == 0 ? parseInt(parseInt(self.MessageUrdu().length) / 67) || 0 : parseInt(parseInt(self.MessageUrdu().length) / 67) + 1 || 0;
        self.NoOfSMSUrd(count);
        return count;
    });

    // added by hammad on 27-01-2016 04:07:03PM, response message urdu
    self.ResponseMsgCharacterCountEng = ko.computed(function () {
        return self.ResponseMessage() != null ? (640 - parseInt(self.ResponseMessage().length)) < 0 ? 'Limit Exceeded' : 640 - parseInt(self.ResponseMessage().length) : 0;
    });

    self.ResponseMsgMode = ko.computed(function () {
        self.ResponseLanguageMode(self.ResponseMessageType() == '0' ? false : true);
    });

    self.ResponseMsgCountEng = ko.computed(function () {
        //return parseInt(parseInt(self.MessageEnglish().length) % 153) == 0 ? parseInt(parseInt(self.MessageEnglish().length) / 153) || 0 : parseInt(parseInt(self.MessageEnglish().length) / 153) + 1 || 0; // comment by hammad - 27-01-2016 15:53:28 for implement no of sms count

        if (self.ResponseMessage() != null && self.ResponseMessage().length > 0) {
            var count = parseInt(parseInt(self.ResponseMessage().length) % 153) == 0 ? parseInt(parseInt(self.ResponseMessage().length) / 153) || 0 : parseInt(parseInt(self.ResponseMessage().length) / 153) + 1 || 0;
            self.ResponseNoOfSMSEng(count);
            return count;
        }
        return 0;
    });

    self.ResponseMsgCharacterCountUrd = ko.computed(function () {
        return self.ResponseMessageUrdu() != null ? (1280 - parseInt(self.ResponseMessageUrdu().length)) < 0 ? 'Limit Exceeded' : 1280 - parseInt(self.ResponseMessageUrdu().length) : 0;
    });

    self.ResponseMsgCountUrd = ko.computed(function () {
        //return parseInt(parseInt(self.MessageUrdu().length) % 67) == 0 ? parseInt(parseInt(self.MessageUrdu().length) / 67) || 0 : parseInt(parseInt(self.MessageUrdu().length) / 67) + 1 || 0;       // comment by hammad - 27-01-2016 15:53:28 for implement no of sms count
        if (self.ResponseMessageUrdu() == null) self.ResponseMessageUrdu('');

        var count = parseInt(parseInt(self.ResponseMessageUrdu().length) % 67) == 0 ? parseInt(parseInt(self.ResponseMessageUrdu().length) / 67) || 0 : parseInt(parseInt(self.ResponseMessageUrdu().length) / 67) + 1 || 0;
        self.ResponseNoOfSMSUrd(count);
        return count;
    });

    self.TotalAmount = ko.computed(function () {
        return parseFloat(self.TotalAllocatedSMS() * self.PerSMSRate()).toFixed(2);
    });

    self.PerSMSRate.subscribe(function (newValue) {
        self.PerSMSRate(parseFloat(newValue).toFixed(2));
    });
    //self.TemplateID.subscribe(function (newValue) {
    //    if (newValue != null && newValue != undefined) {
    //        self.MessageType('1');
    //    }
    //    else {
    //        self.MessageType('2');
    //    }
    //});

    //self.MessageType.subscribe(function (newValue) {
    //    newValue == "2" ? self.MessageUrdu('') : newValue == "3" ? self.MessageEnglish('') : self.MessageEnglish('');
    //});

    self.CampaignStartDate.subscribe(function (newValue) {
        self.PurchaseDate(newValue || '');
    });

    self.TotalAllocatedSMS.subscribe(function (newvalue) {
        self.TotalRemainSMS(self.CampaignID() != null ? self.TotalRemainSMS() : newvalue);
    });

    self.CampaignEndDate = ko.computed(function () {
        return self.ExpiryDate() || '';
    });

    self.reSchedule = function () {
        if (this.ReSchedule()) {
            self.HasRun(1);
        }
        return true;
    }

    self.getContacts = function (item) {
        if (item.OrganizationID() != undefined && item.DepartmentID() != undefined) {
            // alert(item.CampaignID());
            viewModel.main().ContactCurrentPage(1);
            $.ajax({
                url: "SMSCampaign.aspx/GetContacts",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "',departmentID : '" + ko.toJSON(item.DepartmentID()) + "',pageNo : '" + ko.toJSON(viewModel.main().ContactCurrentPage()) + "',pageSize : '" + ko.toJSON(viewModel.main().ContactPageSize()) + "' ,campaignID: '" + item.CampaignID() + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        viewModel.main().AssignContacts([]);
                        if (data.d.Contacts != null) {
                            ko.utils.arrayForEach(data.d.Contacts, function (contact) {
                                viewModel.main().AssignContacts.push(new ContactModel(contact));
                            });
                            viewModel.main().ContactCurrentPage(parseInt(viewModel.main().ContactCurrentPage()) + 1);
                        }
                        $('#ContactModal').modal('show');
                        $('#ContactModal input:first-child').focus();
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else {
            NotifyMe("info|Select organization & department first");
        }
    };

    self.getAddressBook = function (item) {
        // alert(item.CampaignID());
        if (item.OrganizationID() != undefined && item.DepartmentID() != undefined) {
            $.ajax({
                url: "SMSCampaign.aspx/GetAddress",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "', departmentID : '" + ko.toJSON(item.DepartmentID()) + "',campaignID : '" + item.CampaignID() + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        var temp = [];
                        viewModel.main().AssignGroups([]);

                        ko.utils.arrayForEach(data.d.AddressBooks, function (grp) {
                            temp.push(new AddressBookModel(grp));
                        });

                        ko.utils.arrayForEach(viewModel.main().editModel().AddressBooks(), function (address) {
                            ko.utils.arrayForEach(temp, function (grp) {
                                if (ko.utils.unwrapObservable(grp.AddressBookID) == ko.utils.unwrapObservable(address.AddressBookID))
                                    grp.Assigned(true);
                            });
                        });

                        viewModel.main().AssignGroups(temp);
                        $('#AddressBookModal').modal('show');
                        $('#AddressBookModal input:first-child').focus();
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else {
            NotifyMe("info|Select organization & department first");
        }
    };

    self.getMasks = function (item) {
        if (item.ShortCodeID() != undefined) {

            if (item.DepartmentID() != undefined) {
                $.ajax({
                    url: "SMSCampaign.aspx/GetMasksByShortCodeID",
                    type: 'POST',
                    data: "{shortCodeID : '" + ko.toJSON(item.ShortCodeID()) + "',departmentID : '" + item.DepartmentID() + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        viewModel.main().Masks([]);
                        if (data.d.Masks != null) {

                            ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Masks), function (msk) {
                                viewModel.main().Masks.push(new MaskModel(msk));

                            });
                        }
                    },
                    error: function (request) {
                    }
                });
            }
        }
    };

    self.getImcommingMasks = function (item) {
        if (item.IncomingShortCodeID() != undefined) {

            if (item.DepartmentID() != undefined) {
                $.ajax({
                    url: "SMSCampaign.aspx/GetMasksByShortCodeID",
                    type: 'POST',
                    data: "{shortCodeID : '" + ko.toJSON(item.IncomingShortCodeID()) + "',departmentID : '" + item.DepartmentID() + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        viewModel.main().IncomingMasks([]);


                        if (data.d.Masks != null) {

                            ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Masks), function (msk) {
                                viewModel.main().IncomingMasks.push(new MaskModel(msk));
                            });
                        }
                    },
                    error: function (request) {
                    }
                });
            }
        }
    };

    self.removeContact = function () {
        self.Contacts.remove(this);
    };

    self.removeAddressbook = function () {
        self.AddressBooks.remove(this);
    };
}

function ContactModel(contact) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(contact.ID));
    self.Assigned = ko.observable(ko.utils.unwrapObservable(contact.Assigned || false));
    self.FirstName = ko.observable(ko.utils.unwrapObservable(contact.FirstName));
    self.LastName = ko.observable(ko.utils.unwrapObservable(contact.LastName));
    self.Email = ko.observable(ko.utils.unwrapObservable(contact.Email));
    self.Phone = ko.observable(ko.utils.unwrapObservable(contact.Phone));
    self.OrganizationID = ko.observable(ko.utils.unwrapObservable(contact.OrganizationID));
    self.CampaignID = ko.observable(ko.utils.unwrapObservable(contact.CampaignID));
    self.RowNumber = ko.observable(ko.utils.unwrapObservable(contact.RowNumber));
}

function AddressBookModel(addrbook) {
    var self = this;
    self.Assigned = ko.observable(ko.utils.unwrapObservable(addrbook.Assigned || false));
    self.AddressBookID = ko.observable(ko.utils.unwrapObservable(addrbook.AddressBookID));
    self.Title = ko.observable(ko.utils.unwrapObservable(addrbook.Title));
    self.OrganizationID = ko.observable(ko.utils.unwrapObservable(addrbook.OrganizationID));
    self.AddressBookContactsCount = ko.observable(ko.utils.unwrapObservable(addrbook.AddressBookContactsCount || 0));

    self.RowNumber = ko.observable(ko.utils.unwrapObservable(addrbook.RowNumber));
}

function MaskModel(mask) {
    var self = this;
    self.ID = ko.observable(mask.ID);
    self.Title = ko.observable(mask.Title);
}

function SMSTemplateModel(temp) {
    var self = this;
    self.ID = ko.observable(temp.ID);
    self.Title = ko.observable(temp.Title);
    self.TemplateMessage = ko.observable(temp.TemplateMessage);
}

function SMSTypeModel(smsType) {
    var self = this;
    self.SMSTypeID = ko.observable(smsType.SMSTypeID);
    self.Title = ko.observable(smsType.Title);
}

function PaymentTypeModel(payment) {
    var self = this;
    if (payment != null) {
        self.PaymentID = ko.observable(payment.PaymentID);
        self.CampaignID = ko.observable(payment.CampaignID);
        self.PurchaseDate = ko.observable(payment.PurchaseDate);
        self.ExpiryDate = ko.observable(payment.ExpiryDate);
        self.TotalAllocatedSMS = ko.observable(payment.TotalAllocatedSMS);
        self.TotalRemainSMS = ko.observable(payment.TotalRemainSMS);
        self.PerSMSRate = ko.observable(payment.PerSMSRate);
        self.InforceBucket = ko.observable(payment.InforceBucket);
    }
    else {
        self.PaymentID = ko.observable(0);
        self.CampaignID = ko.observable(0);
        self.PurchaseDate = ko.observable('');
        self.ExpiryDate = ko.observable('');
        self.TotalAllocatedSMS = ko.observable(0);

        self.TotalRemainSMS = ko.observable(0);
        //  self.TotalAmount = ko.observable(0);
        self.PerSMSRate = ko.observable(0);
        self.InforceBucket = ko.observable();
    }
}

function ShortCodeModel(code) {
    var self = this;
    self.SMSTypeID = ko.observable(code.ID);
    self.Title = ko.observable(code.Title);
}

function OrganizationModel(org) {
    var self = this;
    self.ID = ko.observable(org.ID);
    self.Title = ko.observable(org.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.DepartmentID = ko.observable(item.DepartmentID);
    self.OrganizationID = ko.observable(item.OrganizationID);
    self.Title = ko.observable(item.Title);
    self.PerSMSRate = ko.observable(item.PerSMSRate || 0);
    self.IsAllowedCampaingName = ko.observable(item.IsAllowedCampaingName || true);
    self.SMSLimit = ko.observable(item.SMSLimit || 0);
}

function UserModel(item) {
    var self = this;
    self.DepartmentID = ko.observable(item.DepartmentID);
    self.UserID = ko.observable(item.UserID);
    self.EmployeeName = ko.observable(item.EmployeeName);
}

function UserRightsModel(item) {
    var self = this;
    if (item != null) {
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
        self.UserTypeID = ko.observable(item.UserTypeID);

    }
    else {
        self.OrganizationID = ko.observable(0);
        self.DepartmentID = ko.observable(0);
        self.UserID = ko.observable(0);
        self.UserTypeID = ko.observable(0);
    }
}

function ProcessingStatusModel(item) {
    var self = this;
    if (item != null) {
        self.ProcessingStatusID = ko.observable(item.ProcessingStatusID);
        self.Title = ko.observable(item.Title);
    }
    else {
        self.ProcessingStatusID = ko.observable(0);
        self.Title = ko.observable();
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    // $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });


    //$('.tblSchedual td:not(:first-child)').live('click', function () {
    //    var colIndex = parseInt($(this).parent().children().index($(this)) * 10);
    //    var rowIndex = parseInt($(this).parent().parent().children().index($(this).parent()) + 1);
    //    $(this).find('input').css('display', 'block');
    //});

    //$('.tblSchedual td:not(:first-child)').live('mouseover', function () {
    //    var colIndex = parseInt($(this).parent().children().index($(this)) * 10);
    //    var rowIndex = parseInt($(this).parent().parent().children().index($(this).parent()) + 1);
    //    if ($(this).find('label').text().trim() == '') {
    //        $(this).text(rowIndex + ' : ' + colIndex + ' PM');
    //    }
    //});

    //$('.tblSchedual td:not(:first-child)').live('mouseout', function () {
    //    $(this).text('');
    //});

    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord(isLoad, mod) {
    isLoad = isLoad || false;
    $.ajax({
        url: "SMSCampaign.aspx/GetRecord",
        type: 'POST',
        data: "{jsonModel : '" + ko.toJSON(mod) + "', isLoad : '" + isLoad + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new SMSCampaignModel(null));
                viewModel.main().editModel().PerSMSRate(data.d.SMSCampaign != null ? data.d.SMSCampaign.PerSMSRate : 0 || 0);
                viewModel.main().editModel().TotalAllocatedSMS(data.d.SMSCampaign != null ? data.d.SMSCampaign.TotalAllocatedSMS : 0 || 0);
                viewModel.main().User(new UserRightsModel(data.d.User));
                //if (viewModel.main().User().IsEnforceSMSBucked()!)
                viewModel.main().editModel().InforceBucket(data.d.User.IsEnforceSMSBucked);
                //viewModel.main().OrganizationID(organizationID);
                //viewModel.main().Departments(all_departments);
                //viewModel.main().DepartmentID(departmentID);

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());

                if (viewModel.main().User().UserID() != 0)
                    viewModel.main().editModel().UserID(viewModel.main().User().UserID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new SMSCampaignModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function LoadRecordSearch(organizationID, departmentID, mod, searchText) {
    organizationID = organizationID || 0;
    departmentID = departmentID || 0;
    var a = 1;
    $.ajax({
        url: "SMSCampaign.aspx/GetRecordSearch",
        type: 'POST',
        data: "{organizationID : '" + ko.toJSON(organizationID) + "', departmentID : '" + ko.toJSON(departmentID) + "', jsonModel : '" + ko.toJSON(mod) + "', searchText : '" + searchText + "'}",

        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new SMSCampaignModel(null));
                viewModel.main().User(new UserRightsModel(data.d.User));

                viewModel.main().OrganizationID(organizationID);
                viewModel.main().DepartmentsFilter(all_departments);
                viewModel.main().DepartmentID(departmentID);

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());

                if (viewModel.main().User().UserID() != 0)
                    viewModel.main().editModel().UserID(viewModel.main().User().UserID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new SMSCampaignModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}
/*
function LoadRecord(mod) {
    $.ajax({
        url: "SMSCampaign.aspx/GetRecord",
        type: 'POST',
        data: "{jsonModel : '" + ko.toJSON(mod) + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new SMSCampaignModel(null));
                viewModel.main().editModel().PerSMSRate(data.d.SMSCampaign != null ? data.d.SMSCampaign.PerSMSRate : 0 || 0);
                viewModel.main().User(new UserRightsModel(data.d.User));

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());

                if (viewModel.main().User().UserID() != 0)
                    viewModel.main().editModel().UserID(viewModel.main().User().UserID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new SMSCampaignModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function LoadRecordSearch(mod, searchText) {
    $.ajax({
        url: "SMSCampaign.aspx/GetRecordSearch",
        type: 'POST',
        data: "{jsonModel : '" + ko.toJSON(mod) + "', searchText : '" + searchText + "'}",

        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new SMSCampaignModel(null));
                viewModel.main().User(new UserRightsModel(data.d.User));

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());

                if (viewModel.main().User().UserID() != 0)
                    viewModel.main().editModel().UserID(viewModel.main().User().UserID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new SMSCampaignModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}
*/

function highlightCells(rowIndex, colIndex, cellsCount, campaignName, allocated) {
    var itration = 0;
    var NoOfbox = Math.ceil(60 / minuteInterval);

    var x = cellsCount == colIndex ? colIndex : cellsCount > colIndex ? cellsCount - colIndex : colIndex - cellsCount;
    if (x != 0 && cellsCount > 0) {
        for (var i = colIndex; i <= (colIndex + x) ; i++) {
            if (cellsCount - itration > 0)
                allocated ? $('.tblSchedual tr:eq(' + rowIndex + ') td:eq(' + i + ')').addClass('highlighted') : $('.tblSchedual tr:eq(' + rowIndex + ') td:eq(' + i + ')').addClass('highlight');

            ++itration;
            if (i == NoOfbox) {
                rowIndex++;
                highlightCells(rowIndex, 1, cellsCount - itration, campaignName, allocated);
            }
        }
    }
    else if (x == 0) {
        for (var i = 0; i < cellsCount; i++) {
            allocated ? $('.tblSchedual tr:eq(' + rowIndex + ') td:eq(' + i + colIndex + ')').addClass('highlighted') : $('.tblSchedual tr:eq(' + rowIndex + ') td:eq(' + i + colIndex + ')').addClass('highlight');
        }
    }
}

function UnHighlightCells(rowIndex, colIndex, cellsCount) {
    var itration = 0;
    var NoOfbox = Math.ceil(60 / minuteInterval);

    var x = cellsCount == colIndex ? colIndex : cellsCount > colIndex ? cellsCount - colIndex : colIndex - cellsCount;
    if (x != 0 && cellsCount > 0) {
        for (var i = colIndex; i <= (colIndex + x) ; i++) {
            if (cellsCount - itration > 0)
                $('.tblSchedual tr:eq(' + rowIndex + ') td:eq(' + i + ')').removeClass('highlight');

            ++itration;
            if (i == NoOfbox) {
                rowIndex++;
                UnHighlightCells(rowIndex, 1, cellsCount - itration);
            }
        }
    }
    else if (x == 0) {
        for (var i = 0; i < cellsCount; i++) {
            $('.tblSchedual tr:eq(' + rowIndex + ') td:eq(' + i + colIndex + ')').removeClass('highlight');
        }
    }
}

function validateEmptyMessage(obj) {
    var ret = false;

    if (obj.TemplateID() == null) {
        if (obj.MessageType() == 2) {
            if (obj.MessageCountEn() > 0)
                ret = true;
        }
        else if (obj.MessageType() == 3) {
            if (obj.MessageCountUr() > 0)
                ret = true;
        }
    }
    else {
        ret = true;
    }
    return ret;
}