﻿var viewModel = new ViewModel();
var refSearchText = '';

//** TimePicker Custom binding **\\
ko.bindingHandlers.timeValue = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
        var tpicker = $(element).timepicker();
        tpicker.on('changeTime.timepicker', function (e) {

            //Asignar la hora y los minutos
            var value = valueAccessor();
            if (!value) {
                throw new Error('timeValue binding observable not found');
            }
            var date = ko.unwrap(value);
            var mdate = moment(date || new Date());
            var hours24;
            if (e.time.meridian == "AM") {
                if (e.time.hours == 12)
                    hours24 = 0;
                else
                    hours24 = e.time.hours;
            }
            else {
                if (e.time.hours == 12) {
                    hours24 = 12;
                }
                else {
                    hours24 = e.time.hours + 12;
                }
            }

            mdate.hours(hours24)
            mdate.minutes(e.time.minutes);
            $(element).data('updating', true);
            value(mdate.toDate());
            $(element).data('updating', false);


        })
    },
    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
        //Avoid recursive calls
        if ($(element).data('updating')) {
            return;
        }
        var date = ko.unwrap(valueAccessor()) || new Date();

        if (date) {
            var time = moment(date).format("hh:mmA");
            //var matches = time.match(/(\d{1,2}):(\d{2})/);
            //var zone = parseInt(matches[0]) >= 12 ? 'PM' : 'AM';
            //time = matches[1] + ':' + matches[2] + ' ' + zone;
            $(element).timepicker('setTime', time);
        }
        else {
            // $(element).timepicker('clear');
        }
    }
};

//** DatePicker Custom binding **\\
//ko.bindingHandlers.datepicker = {
//    init: function (element, valueAccessor, allBindingsAccessor) {
//        var $el = $(element);
//        //initialize datepicker with some optional options
//        var options = allBindingsAccessor().datepickerOptions || {};
//        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

//        $el.datepicker(options);
//        //handle the field changing
//        ko.utils.registerEventHandler(element, "change", function () {
//            var observable = valueAccessor();
//            observable($el.datepicker("getDate"));
//        });
//        //handle disposal (if KO removes by the template binding)
//        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
//            $el.datepicker("destroy");
//        });
//    },
//    update: function (element, valueAccessor) {
//        var value = ko.utils.unwrapObservable(valueAccessor()),
//        $el = $(element),
//        current = $el.datepicker("getDate");
//        if (value.toString().indexOf("Date") > 0) {
//            value = new Date(parseInt(value.substring(6, 19)));
//        }
//        if (value - current !== 0) {
//            $el.datepicker("setDate", value);
//            valueAccessor()($el.datepicker("getDate"));
//        }
//    }
//};


ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()) || new Date(),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.AllowUpdate = ko.observable(true);
    self.PageSize = ko.observable(5);

    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);
    self.SearchText = ko.observable(refSearchText);

    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();
    self.ShortCodes = ko.observableArray();
    self.SMSCampaigns = ko.observableArray();

    self.OrganizationID = ko.observable(0);
    self.DepartmentID = ko.observable(0);
    self.ShortCodeID = ko.observable(0);
    self.CampaignID = ko.observable(0);
    self.UserID = ko.observable(0);

    self.FromDate = ko.observable('');
    self.ToDate = ko.observable('');
   
    self.SMSTitle = ko.observable('');

    self.allRecords = ko.observableArray();
    self.User = ko.observable(new UserRightsModel(null));
    self.SendMessage = ko.observable('');

    if (items != null) {

        if (items.Organizations != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Organizations), function (organ) {
                self.Organizations.push(new OrganizationModel(organ));
            });
        }

        if (items.Departments != null) {
            self.Departments([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Departments), function (dept) {
                self.Departments.push(new DepartmentModel(dept));
            });
        }

        if (items.ShortCodes != null) {
            self.ShortCodes([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.ShortCodes), function (code) {
                self.ShortCodes.push(new ShortCodeModel(code));
            });
        }

        if (items.SMSCampaigns != null) {
            self.SMSCampaigns([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.SMSCampaigns), function (camp) {
                self.SMSCampaigns.push(new CampaignModel(camp));
            });
        }

        if (items.SMSResponse != null) {
            self.allRecords([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.SMSResponse), function (trans) {
                self.allRecords.push(new SMSResponceModel(trans));
            });
        }
        else {
            self.allRecords([]);
        }

        self.PageSize(items.PageSize || 2);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());
    }

    self.Filter = function (data, event) {
        if ($('.search').val().trim() != '') {
            self.SearchText($('.search').val());
            refSearchText = $('.search').val();
            viewModel.main().PageNo(0);
            LoadRecord(viewModel.main(), true);
        }
        else {
            NotifyMe("info|Please type something in search box");
        }
        event.preventDefault();
        event.stopPropagation();
    };

    self.Reload = function () {
        refSearchText = '';
        self.SearchText($('.search').val(''));
        viewModel.main().PageNo(0);
        LoadRecord(viewModel.main(), true);
    };

    self.getRecord = function () {
        if ($('form').validationEngine('validate')) {
            LoadRecord(viewModel.main(), true);
        }
    };

    self.Reset = function () {
        viewModel.main().PageNo(0);
        LoadRecord(viewModel.main(), false);
    };

    self.getDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "SMSInbox.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.Departments != null) {
                            self.Departments([]);
                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                self.Departments.push(new DepartmentModel(dept));
                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.getCampaigns = function (item) {
        if (item.OrganizationID() != undefined && item.DepartmentID() != undefined) {
            $.ajax({
                url: "SMSInbox.aspx/GetSMSCampaigns",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "',deptID : '" + ko.toJSON(item.DepartmentID()) + "',userID : '" + ko.toJSON(item.UserID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.SMSCampaigns != null) {
                            self.SMSCampaigns([]);
                            ko.utils.arrayForEach(data.d.SMSCampaigns, function (camp) {
                                self.SMSCampaigns.push(new CampaignModel(camp));
                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        LoadRecord(viewModel.main(), true);
    };
}

function UserRightsModel(item) {
    var self = this;
    if (item != null) {
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
    }
    else {
        self.OrganizationID = ko.observable(0);
        self.DepartmentID = ko.observable(0);
        self.UserID = ko.observable(0);
    }
}

function SMSResponceModel(item) {
    var self = this;
    if (item != null) {
        self.RecordID = ko.observable(item.RecordID);
        self.ResponseID = ko.observable(item.ResponseID);
        self.CampaignID = ko.observable(item.CampaignID);
        self.ReplyKeyword = ko.observable(item.ReplyKeyword);
        self.ReplyPhoneNo = ko.observable(item.ReplyPhoneNo);
        self.ReplyMessage = ko.observable(item.ReplyMessage);
        self.ShortCode = ko.observable(item.ShortCode);
        self.Mask = ko.observable(item.Mask);
        self.CreatedDate = ko.observable(item.CreatedDate != null ? new Date(parseInt(item.CreatedDate.substring(6, 19))).format('dd/M/yyyy') : '-');
        self.CreatedTime = ko.observable(item.CreatedDate != null ? new Date(parseInt(item.CreatedDate.substring(6, 19))).format('hh:mm:ss tt') : '-');
        self.ConfirmationDate = ko.observable(item.ConfirmationDate != null ? new Date(parseInt(item.ConfirmationDate.substring(6, 19))).format('dd/M/yyyy') : '-');
        self.ConfirmationTime = ko.observable(item.ConfirmationDate != null ? new Date(parseInt(item.ConfirmationDate.substring(6, 19))).format('hh:mm:ss tt') : '-');
        self.ConfirmationCode = ko.observable(item.ConfirmationCode);
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
    }
    else {
        self.ResponseID = ko.observable();
        self.CampaignID = ko.observable();
        self.ReplyKeyword = ko.observable();
        self.ReplyPhoneNo = ko.observable();
        self.ReplyMessage = ko.observable();
        self.CreatedDate = ko.observable();
        self.CreatedTime = ko.observable();
        self.ShortCode = ko.observable();
        self.Mask = ko.observable();
        self.ConfirmationTime = ko.observable();
        self.ConfirmationDate = ko.observable();
        self.ConfirmationCode = ko.observable();
        self.OrganizationID = ko.observable();
        self.DepartmentID = ko.observable();
        self.UserID = ko.observable();
        self.RecordID = ko.observable();
    }

    self.SMSTransactions = ko.observableArray();

    self.getTransactions = function (item) {
       // alert(item.ReplyPhoneNo())
        $.ajax({
            url: "SMSInbox.aspx/GetSMSTransactionResponses",
            type: 'POST',
            data: "{campaignID : '" + ko.toJSON(item.CampaignID()) + "', responseID : '" + ko.toJSON(item.ResponseID()) + "',replyPhoneNo :'" + item.ReplyPhoneNo() + "',recordID :'" + item.RecordID() + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (data.d.SMSTransactions != null && data.d.SMSTransactions != '') {
                        item.SMSTransactions([]);

                        ko.utils.arrayForEach(viewModel.main().allRecords(), function (trans) {
                            trans.SMSTransactions([]);
                        });

                        ko.utils.arrayForEach(data.d.SMSTransactions, function (trans) {
                            item.SMSTransactions.push(new SMSTransactionModel(trans));
                        });
                    }
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };

    self.getResponceMsg = function (item) {
        $.ajax({
            url: "SMSInbox.aspx/GetSMSResponseMessage",
            type: 'POST',
            data: "{responseID : '" + ko.toJSON(item.ResponseID()) + "',recordID : '" + ko.toJSON(item.RecordID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (data.d.ReplyMessage != null) {
                        viewModel.main().SendMessage(data.d.ReplyMessage);
                        viewModel.main().SMSTitle('Received Message');
                        $('#SMSModal').modal('show');
                    }
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };
}

function SMSTransactionModel(item) {
    var self = this;
    if (item != null) {
        self.SMSTransactionID = ko.observable(item.SMSTransactionID);
        self.CampaignID = ko.observable(item.CampaignID);
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.ContactNo = ko.observable(item.ContactNo);
        self.SendMessage = ko.observable(item.SendMessage);
        self.RecieveMessage = ko.observable(item.RecieveMessage);
        self.DeliveryStatusID = ko.observable(item.DeliveryStatusID);
        self.SendingDate = ko.observable(item.SendingDate != null ? new Date(parseInt(item.SendingDate.substring(6, 19))).format('dd/M/yyyy') : '-');
        self.SendingTime = ko.observable(item.SendingDate != null ? new Date(parseInt(item.SendingDate.substring(6, 19))).format('hh:mm:ss tt') : '-');
        self.Mode = ko.observable(item.Mode);
        self.DeliveredDate = ko.observable(item.DeliveredDate != null ? new Date(parseInt(item.DeliveredDate.substring(6, 19))).format('dd/M/yyyy') : '-');
        self.DeliveredTime = ko.observable(item.DeliveredDate != null ? new Date(parseInt(item.DeliveredDate.substring(6, 19))).format('hh:mm:ss tt') : '-');
        self.ContactID = ko.observable(item.ContactID);
        self.Network = ko.observable(item.Network || '-');
        self.SMSSendingID = ko.observable(item.SMSSendingID);
        self.TotalAllocatedSMS = ko.observable(item.TotalAllocatedSMS);
        self.StartDate = ko.observable(item.StartDate);
        self.EndDate = ko.observable(item.EndDate);
        self.Mask = ko.observable(item.Mask || '-');
        self.ShortCode = ko.observable(item.ShortCode || '-');
        self.SMSSendingStatus = ko.observable(item.SMSSendingStatus);
        self.TelcoID = ko.observable(item.TelcoID);
        self.IsOnNet = ko.observable(item.IsOnNet);
    }
    else {
        self.SMSTransactionID = ko.observable();
        self.CampaignID = ko.observable();
        self.OrganizationID = ko.observable();
        self.ContactNo = ko.observable();
        self.SendMessage = ko.observable();
        self.RecieveMessage = ko.observable();
        self.DeliveryStatusID = ko.observable();
        self.SendingDate = ko.observable();
        self.SendingTime = ko.observable();
        self.DeliveredTime = ko.observable();
        self.Mode = ko.observable();
        self.DeliveredDate = ko.observable();
        self.ContactID = ko.observable();
        self.Network = ko.observable();
        self.SMSSendingID = ko.observable();
        self.TotalAllocatedSMS = ko.observable();
        self.StartDate = ko.observable();
        self.EndDate = ko.observable();
        self.Mask = ko.observable();
        self.ShortCode = ko.observable();
        self.SMSSendingStatus = ko.observable();
        self.TelcoID = ko.observable();
        self.IsOnNet = ko.observable();
    }

    self.getMessage = function (item) {
        $.ajax({
            url: "SMSInbox.aspx/GetSMSSendMessage",
            type: 'POST',
            data: "{transactionID : '" + ko.toJSON(item.SMSTransactionID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (data.d.SendMessage != null) {
                        viewModel.main().SendMessage(data.d.SendMessage);
                        viewModel.main().SMSTitle('Response Message');
                        $('#SMSModal').modal('show');
                    }
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    }
}

function CampaignModel(code) {
    var self = this;
    self.CampaignID = ko.observable(code.CampaignID);
    self.Title = ko.observable(code.Title);
}

function ShortCodeModel(code) {
    var self = this;
    self.SMSTypeID = ko.observable(code.ID);
    self.Title = ko.observable(code.Title);
}

function OrganizationModel(org) {
    var self = this;
    self.ID = ko.observable(org.ID);
    self.Title = ko.observable(org.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.DepartmentID = ko.observable(item.DepartmentID);
    self.OrganizationID = ko.observable(item.OrganizationID);
    self.Title = ko.observable(item.Title);
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    LoadRecord(new wrapperModel(null));
    ko.applyBindings(viewModel);
});

function  LoadRecord(mod, isLoad) {
    isLoad = isLoad || false;
    var fromDate = mod.FromDate() != undefined && mod.FromDate() != "" ? mod.FromDate().format('M/dd/yyyy') : "";
   
    var toDate = mod.ToDate() != undefined && mod.ToDate() != "" ? mod.ToDate().format('M/dd/yyyy') : "";
    var searchText = mod.SearchText() || "";
    $.ajax({
        url: "SMSInbox.aspx/GetRecord",
        type: 'POST',
        data: "{organizationID : '" + ko.toJSON(mod.OrganizationID() || 0) + "', departmentID : '" + ko.toJSON(mod.DepartmentID() || 0) + "', campaignID : '" + ko.toJSON(mod.CampaignID() || 0) + "', pageNo : '" + mod.PageNo() + "', fromDate : '" + fromDate + "', toDate : '" + toDate + "', searchText : '" + searchText + "', isLoad : '" + isLoad + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().User(new UserRightsModel(data.d.User));

                if (!isLoad) {
                    if (viewModel.main().User().OrganizationID() != 0)
                        viewModel.main().OrganizationID(viewModel.main().User().OrganizationID());

                    if (viewModel.main().User().DepartmentID() != 0)
                        viewModel.main().DepartmentID(viewModel.main().User().DepartmentID());

                    if (viewModel.main().User().UserID() != 0)
                        viewModel.main().UserID(viewModel.main().User().UserID());
                }
                else {
                    viewModel.main().OrganizationID(mod.OrganizationID());
                    viewModel.main().DepartmentID(mod.DepartmentID());
                    viewModel.main().UserID(mod.UserID());
                    viewModel.main().CampaignID(mod.CampaignID());

                
                    viewModel.main().FromDate(mod.FromDate());
                    viewModel.main().ToDate(mod.ToDate());
                }

            }
            else {
                viewModel.main(new wrapperModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

