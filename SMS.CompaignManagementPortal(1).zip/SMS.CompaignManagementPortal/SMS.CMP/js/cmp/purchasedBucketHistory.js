﻿var viewModel = new ViewModel();
var ref_allDept = [];
var all_organization = [];
var all_departments = [];

ko.bindingHandlers.mask = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor.get('value') || allBindingsAccessor.get('text') || {};
        ko.utils.registerEventHandler(element, "change", function () {
            $(element).text(maskValue(ko.utils.unwrapObservable(text)));
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var options = allBindingsAccessor().mask || {};
        var text = allBindingsAccessor.get('value') || allBindingsAccessor.get('text') || {};
        var ret = options.type == 'amount' ? 'Rs.' + maskValue(ko.utils.unwrapObservable(text)) : maskValue(ko.utils.unwrapObservable(text));
        options.updateParam == 'text' ? $(element).text(ret) : $(element).val(ret);

    }
};

function wrapperModel(items) {
    var self = this;
    self.PageSize = ko.observable(5);
    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();

    self.OrganizationID = ko.observable();
    self.DepartmentID = ko.observable();

    self.PaymentStatistics = ko.observableArray();

    self.User = ko.observable(new UserRightsModel(null));

    self.Payments = ko.observableArray();

    if (items != null) {

        if (items.Payments != null) {
            self.PaymentStatistics.push(new CampaignStatisticsModel(items.Payments[0]));
        }
        else {
            self.PaymentStatistics.push(new CampaignStatisticsModel(null));
        }

        if (ko.utils.unwrapObservable(items.Organizations) != null) {
            self.Organizations([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Organizations), function (organ) {
                self.Organizations.push(new OrganizationModel(organ));
                all_organization.push(new OrganizationModel(organ));
            });
        }
        else {
            self.Organizations(all_organization);
        }

        if (ko.utils.unwrapObservable(items.Departments) != null) {
            self.Departments([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Departments), function (dept) {
                self.Departments.push(new DepartmentModel(dept));
            });
        }

        if (ko.utils.unwrapObservable(items.Payments) != null) {
            self.Payments([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Payments), function (payment) {
                self.Payments.push(new BucketModel(payment));
            });

            self.PageSize(5);
            var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.Payments(), null, self.PageSize());
        }
        else {
            self.Payments([]);
        }
    };

    self.getRecord = function () {
        LoadRecord(ko.utils.unwrapObservable(this.OrganizationID()), ko.utils.unwrapObservable(this.DepartmentID()), true);
    };

    self.getDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "PurchasedBucketsHistory.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d != null) {
                            self.Departments([]);
                            if (all_departments != null) {
                                all_departments = [];
                            }
                            if (data.d.Departments != null)
                                ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                    self.Departments.push(new DepartmentModel(dept));
                                    all_departments.push(new DepartmentModel(dept));
                                });
                        }
                    }
                    //if (NotifyMe(data.d.Notification)) {
                    //    if (data.d.Departments != null) {
                    //        self.Departments([]);
                    //        ref_allDept = [];
                    //        ko.utils.arrayForEach(data.d.Departments, function (dept) {
                    //            self.Departments.push(new DepartmentModel(dept));
                    //            ref_allDept.push(new DepartmentModel(dept));
                    //        });
                    //    }
                    //}
                    else {
                       // ref_allDept = [];
                        self.Departments([]);
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else
            self.Departments([]);
    };

    self.getLogs = function (item) {
        LoadRecord(ko.utils.unwrapObservable(item.OrganizationID()), ko.utils.unwrapObservable(item.DepartmentID()), true);
    }
}

function CommonModel(common) {
    var self = this;
    self.ID = ko.observable(common.ID);
    self.Title = ko.observable(common.Title);
}


function OrganizationModel(org) {
    var self = this;
    self.ID = ko.observable(org.ID);
    self.Title = ko.observable(org.Title);
    // self.Code = ko.observable(org.Code);
}

function DepartmentModel(item) {
    var self = this;
    self.DepartmentID = ko.observable(item.DepartmentID);
    self.OrganizationID = ko.observable(item.OrganizationID);
    self.Title = ko.observable(item.Title);
    // self.Code = ko.observable(item.Code);
}

function UserRightsModel(item) {
    var self = this;
    if (item != null) {
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
    }
    else {
        self.OrganizationID = ko.observable(0);
        self.DepartmentID = ko.observable(0);
        self.UserID = ko.observable(0);
    }
}

function BucketModel(item) {
    var self = this;
    self.PaymentID = ko.observable(item.PaymentID);
    self.CampaignID = ko.observable(item.CampaignID);

    self.PurchaseDate = ko.observable(ko.utils.unwrapObservable(item.PurchaseDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.PurchaseDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.PurchaseDate));
    self.ExpiryDate = ko.observable(ko.utils.unwrapObservable(item.ExpiryDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.ExpiryDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.ExpiryDate));

    self.PurchaseDateTime = ko.observable(ko.utils.unwrapObservable(item.PurchaseDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.PurchaseDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.PurchaseDate));
    self.ExpiryDateTime = ko.observable(ko.utils.unwrapObservable(item.ExpiryDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.ExpiryDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.ExpiryDate));

    self.TotalAllocatedSMS = ko.observable(ko.utils.unwrapObservable(item.TotalAllocatedSMS));
    self.TotalRemainSMS = ko.observable(ko.utils.unwrapObservable(item.TotalRemainSMS));
    self.TotalAmount = ko.observable(ko.utils.unwrapObservable(item.TotalAmount));
    self.PerSMSRate = ko.observable(item.PerSMSRate);

    self.OrganizationCode = ko.observable(item.OrganizationCode);
    self.DepartmentCode = ko.observable(item.DepartmentCode);
    self.DepartmentTitle = ko.observable(item.DepartmentTitle);
    self.OrganizationTitle = ko.observable(item.OrganizationTitle);
    self.CampaignTitle = ko.observable(item.CampaignTitle);

    self.BucketExpire = ko.computed(function () {
        return new Date(self.ExpiryDate()) == new Date() ? true : false;
    });

    self.UsedSMS = ko.computed(function () {
        return parseInt(self.TotalAllocatedSMS() || 0) - parseInt(self.TotalRemainSMS() || 0);
    });
}

function CampaignStatisticsModel(item) {
    var self = this;
    if (item != null) {
        self.DailyCampaigns = ko.observable(ko.utils.unwrapObservable(item.DailyCampaigns));
        self.MonthlyCampaigns = ko.observable(ko.utils.unwrapObservable(item.MonthlyCampaigns));
        self.YearlyCampaigns = ko.observable(ko.utils.unwrapObservable(item.YearlyCampaigns));
        self.WeeklyCampaigns = ko.observable(ko.utils.unwrapObservable(item.WeeklyCampaigns));
    }
    else {
        self.DailyCampaigns = ko.observable(0);
        self.MonthlyCampaigns = ko.observable(0);
        self.MonthlyCampaigns = ko.observable(0);
        self.WeeklyCampaigns = ko.observable(0);
        self.YearlyCampaigns = ko.observable(0);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    // $(".maskMe").maskMoney();
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord(organizationID, departmentID, isLoad) {
    organizationID = organizationID || 0;
    departmentID = departmentID || 0;
    isLoad = isLoad || false;
    $.ajax({
        url: "PurchasedBucketsHistory.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        data: "{organizationID : '" + ko.toJSON(organizationID) + "', departmentID : '" + ko.toJSON(departmentID) + "', isLoad : '" + isLoad + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().User(new UserRightsModel(data.d.User));

                viewModel.main().OrganizationID(organizationID);
                viewModel.main().Departments(all_departments);
                viewModel.main().DepartmentID(departmentID);

                //if (viewModel.main().User().OrganizationID() != 0) {
                //    viewModel.main().OrganizationID(viewModel.main().User().OrganizationID());
                //}
                //else {
                //    viewModel.main().OrganizationID(organizationID);
                //}

                if (viewModel.main().User().DepartmentID() != 0) {
                    viewModel.main().DepartmentID(viewModel.main().User().DepartmentID());
                }
                else {
                    viewModel.main().DepartmentID(departmentID || 0);
                }
            }
            else {
                viewModel.main(new wrapperModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function maskValue(value) {
    return value != null ? value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '';
}