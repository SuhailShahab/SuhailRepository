﻿

var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var ref_all_rec = [];
var ref_allDepartments = [];
var refSearchText = '';
var all_Organization = [];


ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($("#main"))) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.Organizations = ko.observableArray();
    self.file = ko.observable(new FileModel(null));
    self.Departments = ko.observableArray();
    self.OrganizationID = ko.observable();
    self.DepartmentID = ko.observable();
    self.Pager = ko.observable(0);
    self.SearchText = ko.observable(refSearchText);

    self.User = ko.observable(new UserRightsModel(null));

    if (items != null) {

        if (items.Contacts != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(items.Contacts, function (item) {
                self.allRecords.push(new ContactModel(item));
                ref_all_rec.push(new ContactModel(item))
            });
        }

        if (items.Organizations != null) {
            self.Organizations([]);
            if (all_Organization != null && items.Organizations.length> 0) {
                all_Organization = [];
            }
            ko.utils.arrayForEach(items.Organizations, function (item) {
                self.Organizations.push(new OrganizationModel(item));
                all_Organization.push(new OrganizationModel(item))
            });
        } else {
            self.Organizations(all_Organization);

        }

        if (items.Departments != null) {
            self.Departments([]);
            ko.utils.arrayForEach(items.Departments, function (item) {
                self.Departments.push(new DepartmentModel(item));
               // self.DepartmentID()
            });
        }

        self.PageSize(items.PageSize);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());
        //var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {

        $.ajax({
            url: "Contact.aspx/GetDepartments",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                
                if (data.d.Departments != null) {
                    self.Departments([]);
                    ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Departments), function (dept) {
                        self.Departments.push(new DepartmentModel(dept));
                    });
                }

                refModel = new ContactModel(item);
                var mod = new ContactModel(item);
                self.editModel(mod);
                self.editModel().DepartmentID(item.DepartmentID());
                self.allRecords.remove(item);
                self.isEdit(true);
            },
            error: function (request) {
                alert(Error);
            }
        });

      
    };

    self.cancelRecord = function () {
        var mod = new ContactModel(null);
        self.editModel(mod);
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "Contact.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    self.allRecords.remove(item);
                    LoadRecord();
                }
            },
            error: function (request) {
                alert(Error);
            }
        });
        //}
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "Contact.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {

                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.ID > 0) {
                            var mod = new ContactModel(data.d);
                            self.allRecords.unshift(mod);
                            self.editModel(new ContactModel(null));
                            // mod.allAddressBook(all_addressBook);
                            self.isEdit(false);
                            LoadRecord(viewModel.main());
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.Filter = function (data, event) {
        //if ($('.search').val().trim() != '') {
            refSearchText = self.SearchText();
            LoadRecordSearch(viewModel.main(), refSearchText);
        /*}
        else {
            NotifyMe("info|Please type something in search box");
        }*/
        event.preventDefault();
        event.stopPropagation();
        //return true;
    };

    self.Reload = function () {
        refSearchText = '';
        LoadRecord();
    };

    self.uploadFile = function () {
        $.ajax({
            url: "Contact.aspx",
            type: "POST",
            contentType: false,
            processData: false,
            data: function () {
                var data = new FormData();
                var Item = viewModel.main().file().File();
                data.append("organizationID", self.editModel().OrganizationID());
                data.append("departmentID", self.editModel().DepartmentID());
                data.append("chosenFile", Item);
                return data;
            }(),
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            },
            success: function (response, textStatus) {
                NotifyMe("success|File has been saved successfully.");
                LoadRecord();
            }
        });
    }

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        /*if (self.SearchText() == '')
            LoadRecord(viewModel.main());
        else*/
            LoadRecordSearch(viewModel.main(), self.SearchText())
    };

    self.getDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "Contact.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.Departments != null) {
                            self.Departments([]);
                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                self.Departments.push(new DepartmentModel(dept));
                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else {
            self.Departments([]);
        }
    };

    // Added by Mudassir

    self.getSearchDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "Contact.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.Departments != null) {
                            self.Departments([]);
                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                self.Departments.push(new DepartmentModel(dept));

                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else {
            self.Departments([]);
        }
    };

}

function ContactModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.FirstName = ko.observable(ko.utils.unwrapObservable(item.FirstName));
        self.LastName = ko.observable(ko.utils.unwrapObservable(item.LastName));
        self.Phone = ko.observable(ko.utils.unwrapObservable(item.Phone));
        self.Email = ko.observable(ko.utils.unwrapObservable(item.Email));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.CampaignID = ko.observable(ko.utils.unwrapObservable(item.CampaignID));
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.IsEnable = ko.observable(ko.utils.unwrapObservable(item.IsEnable));
        self.UserGroupID = ko.observable(ko.utils.unwrapObservable(item.UserGroupID));
        self.OrganizationTitle = ko.observable(ko.utils.unwrapObservable(item.OrganizationTitle));
        self.DepartmentTitle = ko.observable(ko.utils.unwrapObservable(item.DepartmentTitle));
        
    }
    else {
        self.ID = ko.observable();
        self.FirstName = ko.observable('');
        self.LastName = ko.observable('');
        self.Phone = ko.observable('');
        self.Email = ko.observable('');
        self.Status = ko.observable(true);
        self.OrganizationID = ko.observable();
        self.IsEnable = ko.observable(true);
        self.UserGroupID = ko.observable();
        self.OrganizationTitle = ko.observable('');
        self.DepartmentTitle = ko.observable('');
        self.DepartmentID = ko.observable();
    }
    
    self.browseFile = function (file) {
        viewModel.main().file(new FileModel(file));
    };

}

function OrganizationModel(item) {
    var self = this;
    self.OrganizationID = ko.observable(item.ID);
    self.Title = ko.observable(item.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.ID = ko.observable(item.ID);
    self.Title = ko.observable(item.Title);
    self.OrganizationID = ko.observable(item.OrganizationID);
}

function FileModel(file) {
    var self = this;
    if (file != null) {
        self.File = ko.observable(file);
        self.Name = ko.observable(file.name);
    }
    else {
        self.File = ko.observable('');
        self.Name = ko.observable('');
    }
}

function uploadFile(file, organizationID,departmentID) {
    $.ajax({
        url: "Contact.aspx",
        type: "POST",
        contentType: false,
        processData: false,
        data: function () {
            var data = new FormData();
            var Item = file;
            data.append("organizationID", organizationID);
            data.append("departmentID", departmentID);
            data.append("chosenFile", Item);
            return data;
        }(),
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        },
        success: function (response, textStatus) {
            alert('contact updated successfully.');
        }
    });
}

function UserRightsModel(item) {
    var self = this;
    if (item != null) {
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
    }
    else {
        self.OrganizationID = ko.observable(0);
        self.DepartmentID = ko.observable(0);
        self.UserID = ko.observable(0);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord(null);
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {

    $.ajax({
        url: "Contact.aspx/GetRecord",
        type: 'POST',
        dataType: "json",
        data: "{jsonModel : '" + ko.toJSON(mod) + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new ContactModel(null));

                //viewModel.main().editModel().IsEnable(data.d.IsEnable);
                //if (!data.d.IsEnable) {
                //    viewModel.main().editModel().OrganizationID(data.d.UserGroupID);
                //}

                viewModel.main().User(new UserRightsModel(data.d.User));
               
                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new ContactModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}


function LoadRecordSearch(mod, searchText) {

    //alert('a');
    $.ajax({
        url: "Contact.aspx/GetRecordSearch",
        type: 'POST',
        dataType: "json",
        data: "{jsonModel : '" + ko.toJSON(mod) + "', searchText : '" + searchText + "', organizationID : '" + mod.OrganizationID() + "', departmentID : '" + mod.DepartmentID() + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new ContactModel(null));
                viewModel.main().Organizations(all_Organization);
                viewModel.main().OrganizationID(mod.OrganizationID());
                viewModel.main().DepartmentID(mod.DepartmentID());

                //
                //viewModel.main().editModel().IsEnable(data.d.IsEnable);
                //if (!data.d.IsEnable) {
                //    viewModel.main().editModel().OrganizationID(data.d.UserGroupID);
                //}

                viewModel.main().User(new UserRightsModel(data.d.User));

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new ContactModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}
