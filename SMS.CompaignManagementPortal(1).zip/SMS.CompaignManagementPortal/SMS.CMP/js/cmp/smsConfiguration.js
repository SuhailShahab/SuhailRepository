﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.NetworksCodes = ko.observableArray();

    if (items.SMSConfiguration != null) {
        ref_all_rec = [];
        ko.utils.arrayForEach(items.SMSConfiguration, function (item) {
            self.allRecords.push(new SMSConfigurationModel(item));
            ref_all_rec.push(new SMSConfigurationModel(item))
        });

        if (items.NetworksCode != null) {

            ko.utils.arrayForEach(items.NetworksCode, function (item) {
                self.NetworksCodes.push(new NetworkModel(item));
            });

            self.PageSize(20);
            var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
        }

        self.editRecord = function (item) {
            refModel = new SMSConfigurationModel(item);
            self.editModel(new SMSConfigurationModel(item));
            self.allRecords.remove(item);
            self.isEdit(true);
        };

        self.cancelRecord = function () {
            self.editModel(new SMSConfigurationModel(null));
            self.allRecords.push(refModel);
            self.isEdit(false);
            LoadRecord();
        };

        self.removeRecord = function (item) {
            //if (getConfirmation()) {
            $.ajax({
                url: "SMSConfiguration.aspx/RemoveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(item) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        item.Status(false);
                        LoadRecord();
                        //NotifyMe("inactivesuccess");
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
            //}
        };

        self.saveRecord = function () {
            if ($('form').validationEngine('validate')) {
                $.ajax({
                    url: "SMSConfiguration.aspx/SaveRecord",
                    type: 'POST',
                    data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        if (NotifyMe(data.d.Notification)) {
                            if (data.d.ConfigurationID > 0) {
                                LoadRecord();
                                //NotifyMe("saverecordSuccess");
                            }
                        }
                    },
                    error: function (er, _rr) {
                        NotifyMe("error|" + er.statusText);
                    }
                });
            }
        };

    }
}
function SMSConfigurationModel(item) {

    var self = this;

    if (item != null) {

        self.ConfigurationID = ko.observable(ko.utils.unwrapObservable(item.ConfigurationID));
        self.SMSGateway = ko.observable(ko.utils.unwrapObservable(item.SMSGateway));
        self.UserName = ko.observable(ko.utils.unwrapObservable(item.UserName));
        self.IsDefault = ko.observable(ko.utils.unwrapObservable(item.IsDefault));
        self.SourceNetworksID = ko.observable(ko.utils.unwrapObservable(item.SourceNetworksID));
        self.Password = ko.observable(ko.utils.unwrapObservable(item.Password));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.IsOffNetChecked = ko.observable(ko.utils.unwrapObservable(item.IsOffNetChecked));
        self.IsChecked = ko.observable(ko.utils.unwrapObservable(item.IsChecked));
        self.SMSThroughput = ko.observable(ko.utils.unwrapObservable(item.SMSThroughput));
    }
    else {

        self.ConfigurationID = ko.observable();
        self.SMSGateway = ko.observable();
        self.UserName = ko.observable();
        self.IsDefault = ko.observable(false);
        self.SourceNetworksID = ko.observable();
        self.Password = ko.observable();
        self.Title = ko.observable();
        self.IsOffNetChecked = ko.observable(false);
        self.IsChecked = ko.observable(true);
        self.SMSThroughput = ko.observable(0);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function NetworkModel(item) {

    var self = this;
    self.SourceNetworksID = ko.observable(item.NetworkCode);
    self.Title = ko.observable(item.Title);
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "SMSConfiguration.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new SMSConfigurationModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new SMSConfigurationModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}
