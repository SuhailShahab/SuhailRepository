﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var refSearchText = '';

ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};
//** Validation Engine Custom binding **\\
ko.bindingHandlers.valid = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($("#main"))) {
            $(element).validationEngine('validate');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()) || new Date(),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        //ko.utils.registerEventHandler(element, "blur", function () {
        //    $(element).validationEngine('validate');
        //});
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        //var text = allBindingsAccessor().value || {};
        //if (text() != undefined) {
        //    $(element).validationEngine('validate');
        //}
    }
};

function wrapperModel(item) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();
    self.Campaigns = ko.observableArray();
    self.PageNo = ko.observable(1);
    self.SearchText = ko.observable(refSearchText);
    self.TotalResults = ko.observable(0);
    self.AllPayments = ko.observableArray();

    if (item != null) {

        if (item.lstFinalPaymentInvoices != null) {
            ref_all_rec = [];
            self.allRecords([]);
            ko.utils.arrayForEach(item.lstFinalPaymentInvoices, function (item) {
                self.allRecords.push(new InvoiceModel(item));
                ref_all_rec.push(new InvoiceModel(item));
            });
        }

        if (item.Organizations != null) {

            ko.utils.arrayForEach(item.Organizations, function (item) {
                self.Organizations.push(new OrganizationModel(item));
            });
        }

        self.PageSize(5);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.clearRecord = function () {
        LoadRecord(null);
    }

    self.cancelRecord = function () {
        var mod = new InvoiceModel(null);
        self.editModel(mod);
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord(null);
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {

            $.ajax({
                url: "FinalInvoice.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel().InvoicesList()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d != null) {
                            LoadRecord(null);
                        }
                    }
                },
                error: function (request) {
                }
            });
        }
    };

    self.getAllInvoices = function () {

        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "FinalInvoice.aspx/GetAllCampaignPaymentInvoice",
                type: 'POST',
                data: "{departmentID : '" + ko.toJSON(viewModel.main().editModel().DepartmentID()) + "',organizationID : '" + ko.toJSON(viewModel.main().editModel().OrganizationID()) + "',campaignID : '" + ko.toJSON(viewModel.main().editModel().CampaignID()) + "',pageNo : '" + ko.toJSON(viewModel.main().PageNo()) + "',searchText : '" + ko.toJSON(refSearchText) + "',dateOfInvoice : '" + viewModel.main().editModel().DateofInvoice().format('MM/dd/yyyy') + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        viewModel.main().editModel().InvoicesList([]);
                        if (data.d != null) {
                            ko.utils.arrayForEach(data.d, function (item) {
                                viewModel.main().editModel().InvoicesList.push(new InvoicesListModel(item));
                            });
                        }
                        else {
                            viewModel.main().editModel().InvoicesList([]);
                        }
                    }
                },
                error: function (request) {
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {
                return item.FinalPaymentInvoiceNo().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                       item.DateofInvoice().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                        item.DepartmentName().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                        item.OrganizationName().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;

            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {

        refSearchText = '';
        self.SearchText('');
        LoadRecord(viewModel.main());
    }

    self.showAllPayments = function (mod) {
        $.ajax({
            url: "FinalInvoice.aspx/GetCampaignPaymentInvoiceInfo",
            type: 'POST',
            data: "{FinalInvoiceNo : '" + mod.FinalPaymentInvoiceNo() + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    viewModel.main().AllPayments([]);
                    if (data.d != null) {
                        ko.utils.arrayForEach(data.d, function (item) {
                            viewModel.main().AllPayments.push(new InvoiceModel(item));
                        });
                    }
                    else {
                        viewModel.main().AllPayments([]);
                    }
                    $('#paymentModal').modal('show');
                }
            },
            error: function (request) {
            }
        });
    }
}

function InvoiceModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID || 0));
        self.FinalPaymentInvoiceNo = ko.observable(ko.utils.unwrapObservable(item.FinalPaymentInvoiceNo || ''));
        self.PaymentInvoiceID = ko.observable(ko.utils.unwrapObservable(item.PaymentInvoiceID || 0));
        self.DateofInvoice = ko.observable(ko.utils.unwrapObservable(item.DateofInvoice || ''));
        self.CampaignID = ko.observable(ko.utils.unwrapObservable(item.CampaignID || 0));
        self.PaymentInvoiceTitle = ko.observable(ko.utils.unwrapObservable(item.PaymentInvoiceTitle || ''));

        self.CampaignName = ko.observable(ko.utils.unwrapObservable(item.CampaignName || ''));
        self.DepartmentName = ko.observable(ko.utils.unwrapObservable(item.DepartmentName || ''));
        self.OrganizationName = ko.observable(ko.utils.unwrapObservable(item.OrganizationName || ''));

        self.PaymentInvoiceID = ko.observable(ko.utils.unwrapObservable(item.PaymentInvoiceID));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.Organization = ko.observable(ko.utils.unwrapObservable(item.Organization));
        self.CampaignID = ko.observable(ko.utils.unwrapObservable(item.CampaignID));
        self.DateofInvoice = ko.observable(ko.utils.unwrapObservable(item.DateofInvoice).toString("dd/MM/yyyy").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.DateofInvoice).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.DateofInvoice));
        self.PayableAmount = ko.observable(ko.utils.unwrapObservable(item.PayableAmount));
        self.PaidAmount = ko.observable(ko.utils.unwrapObservable(item.PaidAmount));
        self.Campaign = ko.observable(ko.utils.unwrapObservable(item.Campaign));
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.Department = ko.observable(ko.utils.unwrapObservable(item.Department));
        self.Mode = ko.observable(ko.utils.unwrapObservable(item.Mode || '').toString());
        self.Quantity = ko.observable(ko.utils.unwrapObservable(item.Quantity));
        self.NoOfMessage = ko.observable(ko.utils.unwrapObservable(item.NoOfMessage));
        self.Rate = ko.observable(ko.utils.unwrapObservable(item.Rate));
        self.TotalAmount = ko.observable(ko.utils.unwrapObservable(item.TotalAmount));
        self.ShortCodeOrMask = ko.observable(ko.utils.unwrapObservable(item.ShortCodeOrMask));
        self.InvoicesList = ko.observableArray();
    }
    else {
        self.FinalPaymentInvoiceNo = ko.observable();
        self.PaymentInvoiceID = ko.observable();

        self.ID = ko.observable();
        self.PaymentInvoiceID = ko.observable();
        self.DateofInvoice = ko.observable();
        self.CampaignID = ko.observable();
        self.PaymentInvoiceTitle = ko.observable();

        self.CampaignName = ko.observable('');
        self.DepartmentName = ko.observable('');
        self.OrganizationName = ko.observable('');

        self.OrganizationID = ko.observable();
        self.Organization = ko.observable();
        self.CampaignID = ko.observable();
        self.DateofInvoice = ko.observable();
        self.PayableAmount = ko.observable(0);
        self.PaidAmount = ko.observable(0);
        self.Campaign = ko.observable();
        self.DepartmentID = ko.observable();
        self.Department = ko.observable();
        self.Mode = ko.observable('2');
        self.Quantity = ko.observable();
        self.NoOfMessage = ko.observable();
        self.Rate = ko.observable();
        self.TotalAmount = ko.observable(0);
        self.ShortCodeOrMask = ko.observable('');
        self.InvoicesList = ko.observableArray();
    }

    self.OrganizationID.subscribe(function (newValue) {

        $.ajax({
            url: "FinalInvoice.aspx/GetDepartments",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(newValue) + "',departmentID : '" + ko.toJSON(self.DepartmentID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                viewModel.main().Campaigns([]);
                if (data.d.Departments != null) {
                    viewModel.main().Departments([]);
                    ko.utils.arrayForEach(data.d.Departments, function (item) {
                        viewModel.main().Departments.push(new DepartmentModel(item));
                    });
                }
            },
            error: function (request) {
            }
        });

    });

    self.DepartmentID.subscribe(function (newValue) {

        $.ajax({
            url: "FinalInvoice.aspx/GetDepartments",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(self.OrganizationID()) + "',departmentID : '" + ko.toJSON(newValue) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {

                if (data.d.Campaigns != null) {
                    viewModel.main().Campaigns([]);
                    ko.utils.arrayForEach(data.d.Campaigns, function (item) {
                        viewModel.main().Campaigns.push(new CampaignModel(item));
                    });
                }
            },
            error: function (request) {
            }
        });

    });
}

function InvoicesListModel(inv) {
    var self = this;
    self.Campaign = ko.observable(ko.utils.unwrapObservable(inv.Campaign));
    self.Checked = ko.observable(ko.utils.unwrapObservable(inv.Checked));
    self.PaymentInvoiceID = ko.observable(ko.utils.unwrapObservable(inv.PaymentInvoiceID));
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function OrganizationModel(item) {
    var self = this;
    self.ID = ko.observable(item.ID);
    self.Title = ko.observable(item.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.ID = ko.observable(item.DepartmentID);
    self.Title = ko.observable(item.Title);
}

function CampaignModel(item) {
    var self = this;
    self.ID = ko.observable(item.CampaignID);
    self.Title = ko.observable(item.Title);
}


$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord(null);
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {
    $.ajax({
        url: "FinalInvoice.aspx/GetRecord",
        type: 'POST',
        dataType: "json",
        data: "{jsonModel : '" + ko.toJSON(mod) + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {

            viewModel.main(new wrapperModel(data.d));
            viewModel.main().editModel(new InvoiceModel(null));
        },
        error: function (request) {
        }
    });
}

