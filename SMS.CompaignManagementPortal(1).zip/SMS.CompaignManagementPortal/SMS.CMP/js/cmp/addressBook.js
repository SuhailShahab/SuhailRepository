﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var all_dept = [];
var refSearchText = '';
var all_contacts = [];
var all_DepartmentsNew = [];

var depID;
ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.ContactCount = ko.observable(0);
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);
    self.SearchText = ko.observable(refSearchText);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();
    self.DepartmentsNew = ko.observableArray();
    self.UserDepartments = ko.observableArray();
    // added for search controles
    //self.SearchDepartments = ko.observableArray();

    self.ContactCurrentPage = ko.observable(1);
    self.ContactPageSize = ko.observable(50);

    self.UserDepartmentID = ko.observable(0);
   // self.SelectDepartmentID = ko.observable(0);
    self.DeptID = ko.observable();
    self.FilterOrganizationID = ko.observable();
    //self.AddresBookContactCount = ko.observable(0);
    

    self.file = ko.observable();
    self.isView = ko.observable(false);

    self.OrganizationID = ko.observable();
    self.AddressBookID = ko.observable();

    self.User = ko.observable(new UserRightsModel(null));

    self.AssigneeContacts = ko.observableArray();
    self.hasAssignAllContacts = ko.observable(false);
    self.IsAddAllExistingAddBookContact = ko.observable(true);  // change by sufyan ali 22-3-2018

    if (items != null) {
        if (items.AddressBooks != null) {
            ref_all_rec = [];
            if (items.AddressBooks != null) {
                ko.utils.arrayForEach(items.AddressBooks, function (item) {
                    self.allRecords.push(new AdderssBookModel(item));
                    ref_all_rec.push(new AdderssBookModel(item))
                });
            }
        }
        if (items.Organizations != null) {
            ko.utils.arrayForEach(items.Organizations, function (item) {
                self.Organizations.push(new OrganizationModel(item));
            });
        }

        if (items.Departments != null) {
            ko.utils.arrayForEach(items.Departments, function (item) {
                self.Departments.push(new DepartmentModel(item));
               // self.DepartmentsNew.push(new DepartmentModel(item));
            });
        }

        self.PageSize(items.PageSize);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());
    }
    
    self.UserDepartmentID.subscribe(function (newValue) {
        var filter_contacts = ko.utils.arrayFilter(all_contacts, function (contact) {
            return ko.utils.unwrapObservable(contact.DepartmentID()) == newValue;
        });

        self.AssigneeContacts(filter_contacts);

    });

    self.editRecord = function (item) {
        self.getDepartments(item);
        refModel = new AdderssBookModel(item);
        var modle = new AdderssBookModel(item);
        self.editModel(modle);
        self.allRecords.remove(item);
        self.isEdit(true);
    };


    

    self.cancelRecord = function () {
        self.editModel(new AdderssBookModel(null));
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "AddressBook.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.IsActive(false);
                    LoadRecord();
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        //}
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "AddressBook.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.AddressBookID > 0) {
                            var mod = new AdderssBookModel(data.d);
                            self.allRecords.unshift(mod);
                            self.editModel(new AdderssBookModel(null));
                            self.isEdit(false);
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.Filter = function (data, event) {
        //if ($('.search').val().trim() != '') {
            refSearchText = self.SearchText();
            viewModel.main().PageNo(1);
            LoadRecordSearch(viewModel.main(), refSearchText);

        //}
        //else {
        //    NotifyMe("info|Please type something in search box");
        //}
        event.preventDefault();
        event.stopPropagation();
        //return true;
    };

    self.Reload = function () {
        refSearchText = '';
        LoadRecord();
    };

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        //if (self.SearchText()=='')
        //    LoadRecord(viewModel.main());
        //else
            LoadRecordSearch(viewModel.main(), self.SearchText())
    };

    self.RemoveFile = function () {
        self.file(null);
    };

    self.getDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "AddressBook.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.Departments != null) {
                            self.Departments([]);
                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                self.Departments.push(new DepartmentModel(dept));
                            });
                            self.editModel().DepartmentID(item.DepartmentID());
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else {
            self.Departments([]);
        }
    }

    // Added by Mudassir

    self.getSearchDepartments = function (item) {
        if (item.FilterOrganizationID() != undefined) {
            $.ajax({
                url: "AddressBook.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.FilterOrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.Departments != null) {
                            self.DepartmentsNew([]);
                            all_DepartmentsNew = [];
                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                all_DepartmentsNew.push(new DepartmentModel(dept));
                               
                                self.DepartmentsNew.push(new DepartmentModel(dept));
                            });

                            self.DepartmentsNew(all_DepartmentsNew);
                            //self.editModel().DepartmentID(item.DepartmentID());
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else {
            self.DepartmentsNew([]);
        }
    }


    self.assignAllContacts = function (items, obj, event) {
        if (self.hasAssignAllContacts()) {
            ko.utils.arrayForEach(self.AssigneeContacts(), function (item) {
                item.Assigned(true);
            });
        }
        else {
            ko.utils.arrayForEach(self.AssigneeContacts(), function (item) {
                item.Assigned(false);
            });
        }
        return true;
    };
    
    self.searchRecord = function () {
        self.ContactCurrentPage(1);
        var searchText = $(".searchlookup").val();
        self.viewMoreContats(null, null, searchText, true);
    };

    self.reloadContact = function () {
        self.ContactCurrentPage(1);
        self.UserDepartmentID(0);
        $(".searchlookup").val('');
        viewModel.main().AssigneeContacts([]);
        
        self.viewMoreContats(null, null, '', false);
    }
    
    self.viewMoreContats = function (data, event, searchText, isReload) {
        searchText = searchText || '';
       // alert(self.UserDepartmentID());
        //var deptID = null;
        //if (self.UserDepartmentID() == undefined)
        //{
        //    deptID = depID
        //}
        //else
        //{
        //    deptID = self.UserDepartmentID();
        //}
       /// self.DeptID(depID);
        
        isReload = isReload || false;
        $.ajax({
            url: "AddressBook.aspx/GetContactsSearch",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(ko.utils.unwrapObservable(self.OrganizationID)) + "', addressBookID : '" + ko.toJSON(ko.utils.unwrapObservable(self.AddressBookID)) + "', isView : '" + ko.toJSON(self.isView()) + "', pageNo : '" + ko.toJSON(self.ContactCurrentPage()) + "', pageSize : '" + ko.toJSON(self.ContactPageSize()) + "', searchText : '" + searchText + "',  departmentID : '" + ko.toJSON(depID) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {

                    if (isReload) {
                        viewModel.main().AssigneeContacts([]);
                    }
                    if (data.d.Contacts != null) {
                        all_contacts = [];
                        ko.utils.arrayForEach(data.d.Contacts, function (contact) {
                            viewModel.main().AssigneeContacts.push(new ContactModel(contact));
                            all_contacts.push(new ContactModel(contact))
                        });

                        if (viewModel.main().isView() == false)
                            viewModel.main().UserDepartmentID(ko.utils.unwrapObservable(data.d.UserDepartmentID));
                    
                        viewModel.main().ContactCurrentPage(parseInt(viewModel.main().ContactCurrentPage()) + 1);
                    }
                    else {
                        NotifyMe("info|Sorry.. No record found");
                    }
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };

    self.closePopUp = function () {
        self.ContactCurrentPage(1);
        self.ContactCount(0);
        $(".searchlookup").val('');
    }
}

function AdderssBookModel(item) {
    var self = this;

    if (item != null) {
        self.AddressBookID = ko.observable(ko.utils.unwrapObservable(item.AddressBookID));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));

        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.IsActive = ko.observable(ko.utils.unwrapObservable(item.IsActive));
        self.Contacts = ko.observableArray();
        if (ko.utils.unwrapObservable(item.Contatcs) != null && ko.utils.unwrapObservable(item.Contatcs) != '') {
            ko.utils.arrayForEach(item.Contacts, function (contact) {
                self.Contacts.push(new ContactModel(contact));
            });
        }
        self.IsEnable = ko.observable(ko.utils.unwrapObservable(item.IsEnable));
        self.UserGroupID = ko.observable(ko.utils.unwrapObservable(item.UserGroupID));
        self.NoOfContacts = ko.observable(ko.utils.unwrapObservable(item.NoOfContacts));
        
    }
    else {

        self.NoOfContacts = ko.observable();

        self.AddressBookID = ko.observable();
        self.Title = ko.observable();
        self.OrganizationID = ko.observable();
        self.DepartmentID = ko.observable();
        self.IsActive = ko.observable(true);

        self.Contacts = ko.observableArray();

        self.IsEnable = ko.observable(true);
        self.UserGroupID = ko.observable();
    }

    self.assignContacts = function (arg, itm, obj) {
        viewModel.main().isView(arg == 'view' ? true : false);
        viewModel.main().file(new FileModel(null));
        viewModel.main().AssigneeContacts([]);
        $('.contact-file').val('');

        viewModel.main().OrganizationID(ko.utils.unwrapObservable(itm.OrganizationID));
        viewModel.main().AddressBookID(ko.utils.unwrapObservable(itm.AddressBookID));
        
        depID = ko.utils.unwrapObservable(itm.DepartmentID);
      
        viewModel.main().ContactCurrentPage(1);
        $.ajax({
            url: "AddressBook.aspx/GetContacts",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(ko.utils.unwrapObservable(itm.OrganizationID)) + "', addressBookID : '" + ko.toJSON(ko.utils.unwrapObservable(itm.AddressBookID)) + "', isView : '" + ko.toJSON(viewModel.main().isView()) + "', pageNo : '" + ko.toJSON(viewModel.main().ContactCurrentPage()) + "', pageSize : '" + ko.toJSON(viewModel.main().ContactPageSize()) + "',  departmentID : '" + ko.toJSON(itm.DepartmentID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    viewModel.main().AssigneeContacts([]);
                    all_contacts = [];
                    if (data.d.Contacts != null) {                       
                        
                        ko.utils.arrayForEach(data.d.Contacts, function (contact) {

                            all_contacts.push(new ContactModel(contact))
                        });
                        /* Not Neeed in every case list should be fill
                        if (viewModel.main().isView() == true) {
                            
                            

                            ko.utils.arrayForEach(data.d.Contacts, function (contact) {
                                if (viewModel.main().isView() == true) {
                                 
                                  //  viewModel.main().AssigneeContacts.push(new ContactModel(contact));
                                    all_contacts.push(new ContactModel(contact))
                                }
                            });
                        }
                        else {

                            ko.utils.arrayForEach(data.d.Contacts, function (contact) {
                               
                                all_contacts.push(new ContactModel(contact))
                            });
                        }*/
                        
                    }
                    viewModel.main().AssigneeContacts(all_contacts);
                    viewModel.main().ContactCurrentPage(parseInt(viewModel.main().ContactCurrentPage()) + 1);

                    viewModel.main().UserDepartments([]);
                    if (data.d.Departments != null) {
                        ko.utils.arrayForEach(data.d.Departments, function (dept) {
                            viewModel.main().UserDepartments.push(new DepartmentModel(dept));
                        });
                    }


                    if (viewModel.main().isView() == false) {
                        viewModel.main().UserDepartmentID(ko.utils.unwrapObservable(data.d.UserDepartmentID));
                        viewModel.main().ContactCount(0);
                    }
                    else
                        viewModel.main().ContactCount(ko.utils.unwrapObservable(itm.NoOfContacts));


                    $('#UploadModal input:first-child').focus();
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };

    //self.getContact = function () {
    //    $.ajax({
    //        url: "AddressBook.aspx/GetContacts",
    //        type: 'POST',
    //        data: "{organizationID : '" + ko.toJSON(self.OrganizationID) + "', addressBookID : '" + ko.toJSON(self.AddressBookID) + "'}",
    //        dataType: "json",
    //        contentType: "application/json; charset=utf-8",
    //        success: function (data) {
    //            if (NotifyMe(data.d.Notification)) {
    //                if (data.d.Contacts != null) {
    //                    ko.utils.arrayForEach(data.d.Contacts, function (contact) {
    //                        self.Contacts.push(new ContactModel(contact));
    //                    });
    //                    viewModel.main().ContactCurrentPage(parseInt(viewModel.main().ContactCurrentPage()) + 1);
    //                }
    //            }
    //        },
    //        error: function (er, _rr) {
    //            NotifyMe("error|" + er.statusText);
    //        }
    //    });
    //};

    self.deleteSeledPhoneNos = function () {
        var filter_Phones = '';

        filter_Phones = ko.utils.arrayFilter(viewModel.main().AssigneeContacts(), function (item) {
            return ko.utils.unwrapObservable(item.Assigned) == true;
        });

        if (filter_Phones.length == 0)
        {
            NotifyMe("info|Please select at least one pohne number.");
        }
        else  if ( confirm("Total Selected Phone numbers: " + filter_Phones.length + " Do you want to deleted selected Phone numbers?") )
        {
                     

            var data = {
                organizationID: viewModel.main().OrganizationID(),
                addressBookID: viewModel.main().AddressBookID(),
                assigneeContacts: ko.toJS(filter_Phones),
                departmentID: depID
            }
            $.ajax({
                url: "AddressBook.aspx/DeleteSeledPhoneNos",
                type: 'POST',
                data: JSON.stringify(data),
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        NotifyMe("info:|Total Select Phone numbers deleted:");
                        $('#UploadModal').modal('hide');
                        
                        LoadRecord(viewModel.main());

                    }
                },
                error: function (er, _rr) {
                    // NotifyMe("error|" + er.statusText);
                    NotifyMe("error|There is something wrong.Please contact with administrator.");
                }
            });
        }
       
    }
    self.deleteAllPhoneNos = function () {
       

        if (confirm(" Do you want to delete All Phnoe numbers form address book?")) {


            var data = {
                organizationID: viewModel.main().OrganizationID(),
                addressBookID: viewModel.main().AddressBookID(),                
                departmentID: depID
            }
            $.ajax({
                url: "AddressBook.aspx/DeleteAllPhoneNos",
                type: 'POST',
                data: JSON.stringify(data),
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {                       
                        $('#UploadModal').modal('hide');

                        LoadRecord(viewModel.main());

                    }
                },
                error: function (er, _rr) {
                    // NotifyMe("error|" + er.statusText);
                    NotifyMe("error|There is something wrong.Please contact with administrator.");
                }
            });
        }
        //else {
        //    alert("not delted item");
        //}
    }

    self.saveContacts = function (condition,data) {
        //viewModel.main().UserDepartmentID()
        // viewModel.main().IsAddAllExistingAddBookContact(condition);

        var filter_Phones = '';

        filter_Phones = ko.utils.arrayFilter(viewModel.main().AssigneeContacts(), function (item) {
            return ko.utils.unwrapObservable(item.Assigned) == true;
        });

        var data = {
            organizationID: viewModel.main().OrganizationID(),
            addressBookID: viewModel.main().AddressBookID(),
            assigneeContacts: ko.toJS(filter_Phones),
            departmentID: depID,
            IsCludeAddressBook:condition
        }
        
        $.ajax({
            url: "AddressBook.aspx/AssignContacts",
            type: 'POST',
            data: JSON.stringify(data),//"{IsCludeAddressBook: '" + viewModel.main().IsAddAllExistingAddBookContact() + "',organizationID : '" + ko.toJSON(ko.utils.unwrapObservable(viewModel.main().OrganizationID)) + "', addressBookID : '" + ko.toJSON(ko.utils.unwrapObservable(viewModel.main().AddressBookID)) + "',  assigneeContacts : '" + ko.toJSON(viewModel.main().AssigneeContacts()) + "',  departmentID : '" + ko.toJSON(depID) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (viewModel.main().file() != undefined && viewModel.main().file().Name() != '') {
                        uploadFile(viewModel.main().file().File(), ko.utils.unwrapObservable(viewModel.main().OrganizationID), ko.utils.unwrapObservable(viewModel.main().AddressBookID), ko.utils.unwrapObservable(viewModel.main().UserDepartmentID));
                    }
                    else {
                        $('#UploadModal').modal('hide');
                    }
                    LoadRecord(viewModel.main());

                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        
    };
    
    self.browseFile = function (file) {
        viewModel.main().file(new FileModel(file));
    };
}

function uploadFile(file, organizationID, addressbookID, departmentID) {
    $('#overlay').addClass('blockShow');
    $.ajax({
        url: "AddressBook.aspx",
        type: "POST",
        contentType: false,
        processData: false,
        data: function () {
            var data = new FormData();
            var Item = file;
            data.append("organizationID", organizationID);
            data.append("addressBookID", addressbookID);
            data.append("departmentID", departmentID);
            
            data.append("chosenFile", Item);
            return data;
        }(),
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        },
        success: function (response, textStatus) {
            $('#UploadModal').modal('hide');
            viewModel.main().file(new FileModel(null));
            viewModel.main().OrganizationID(null);
            viewModel.main().AddressBookID(null);
            viewModel.main().AssigneeContacts([]);
            $('.contact-file').val('');
            $('#overlay').removeClass('blockShow');
            $('#UploadModal').modal('hide');
            NotifyMe("success|File has been saved successfully.");
        }
    });
}

function FileModel(file) {
    var self = this;
    if (file != null) {
        self.File = ko.observable(file);
        self.Name = ko.observable(file.name);
    }
    else {
        self.File = ko.observable('');
        self.Name = ko.observable('');
    }
}

function ContactModel(contact) {
    var self = this;
    self.Assigned = ko.observable(contact.Assigned || false);
    self.FirstName = ko.observable(contact.FirstName);
    self.LastName = ko.observable(contact.LastName);
    self.Email = ko.observable(contact.Email);
    self.Phone = ko.observable(contact.Phone);
    self.OrganizationID = ko.observable(contact.OrganizationID);
    self.CampaignID = ko.observable(contact.CampaignID);
    self.ID = ko.observable(contact.ID);
    self.DepartmentID = ko.observable(contact.DepartmentID);
    self.RowNumber = ko.observable(contact.RowNumber);

    
}


function OrganizationModel(org) {
    var self = this;
    self.ID = ko.observable(org.ID);
    self.Title = ko.observable(org.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.DepartmentID = ko.observable(item.DepartmentID);
    self.OrganizationID = ko.observable(item.OrganizationID);
    self.Title = ko.observable(item.Title);
}

function UserRightsModel(item) {
    var self = this;
    if (item != null) {
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
    }
    else {
        self.OrganizationID = ko.observable(0);
        self.DepartmentID = ko.observable();
        self.UserID = ko.observable(0);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {
    $.ajax({
        url: "AddressBook.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        data: "{jsonModel : '" + ko.toJSON(mod) + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new AdderssBookModel(null));
                viewModel.main().User(new UserRightsModel(data.d.User));

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new AdderssBookModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function LoadRecordSearch(mod, searchText) {
    $.ajax({
        url: "AddressBook.aspx/GetRecordSearch",
        type: 'POST',
        dataType: "json",
        data: "{jsonModel : '" + ko.toJSON(mod) + "', searchText : '" + searchText + "', organizationID : '" + mod.FilterOrganizationID() + "', departmentID : '" + mod.DeptID() + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new AdderssBookModel(null));
                viewModel.main().User(new UserRightsModel(data.d.User));
               
                viewModel.main().DepartmentsNew(all_DepartmentsNew);

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());

                viewModel.main().FilterOrganizationID(mod.FilterOrganizationID());
                viewModel.main().DeptID(mod.DeptID());

            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new AdderssBookModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}