﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var all_Dept = [];
var msgTypes = [{ 'Title': 'Message (english)', 'MessageType': '2' }, { 'Title': 'Message (urdu)', 'MessageType': '3' }];
var refSearchText = '';
var englishSMS = '';
var urduSMS = '';

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($("#main"))) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);

    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();

    self.SearchText = ko.observable(refSearchText);
    self.User = ko.observable(new UserRightsModel(null));

    //if (items.Templates) {
    //    ref_all_rec = [];
    //    ko.utils.arrayForEach(items.Templates, function (item) {
    //        self.allRecords.push(new SMSTemplateModel(item));
    //        ref_all_rec.push(new SMSTemplateModel(item))
    //    });
    //}

    if (items != null) {
        if (items.Templates != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(items.Templates, function (item) {
                self.allRecords.push(new SMSTemplateModel(item));
                ref_all_rec.push(new SMSTemplateModel(item))
            });
        }
        if (items.Organizations != null) {
            ko.utils.arrayForEach(items.Organizations, function (item) {
                self.Organizations.push(new OrganizationModel(item));
            });
        };

        if (items.Departments != null) {
            ko.utils.arrayForEach(items.Departments, function (item) {
                self.Departments.push(new DepartmentModel(item));
            });
        }

        self.PageSize(items.PageSize);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);

        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());
    }

    /// var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());


    self.editRecord = function (item) {

        self.getDepartments(item);
        refModel = new SMSTemplateModel(item);

        self.editModel(new SMSTemplateModel(item));
        self.allRecords.remove(item);
        self.isEdit(true);
    };

    self.cancelRecord = function () {
        self.Departments([]);
        self.editModel(new SMSTemplateModel(null));
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    };


    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        if (self.SearchText() == '')
            LoadRecord(viewModel.main());
        else
            LoadRecordSearch(viewModel.main(), self.SearchText())
    };

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "SMSTemplate.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.IsActive(false);
                    LoadRecord();
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        //}
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            if (validateEmptyMessage(viewModel.main().editModel())) {
                $.ajax({
                    url: "SMSTemplate.aspx/SaveRecord",
                    type: 'POST',
                    data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        //if (NotifyMe(data.d.Notification)) {
                        if (NotifyMe(data.d.Notification)) {
                            LoadRecord();
                            //NotifyMe("saverecordSuccess");
                        }
                        //}
                    },
                    error: function (er, _rr) {
                        NotifyMe("error|" + er.statusText);
                    }
                });
            }
            else {
                NotifyMe("warning|Please add some text in message box.");
            }
        }
    };

    self.Filter = function (data, event) {
        if ($('.search').val().trim() != '') {
            refSearchText = self.SearchText();
            viewModel.main().PageNo(1);
            LoadRecordSearch(viewModel.main(), refSearchText);

        }
        else {
            NotifyMe("info|Please type something in search box");
        }
        event.preventDefault();
        event.stopPropagation();
        //return true;
    };

    self.Reload = function () {
        refSearchText = '';
        LoadRecord();
    };

    self.getDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "SMSTemplate.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        self.Departments([]);
                        all_Dept = [];
                        if (data.d.Departments != null) {
                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                self.Departments.push(new DepartmentModel(dept));
                                all_Dept.push(new DepartmentModel(dept));
                            });
                        }
                        self.editModel().DepartmentID(item.DepartmentID());
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    }
}

function OrganizationModel(org) {
    var self = this;
    self.ID = ko.observable(org.ID);
    self.Title = ko.observable(org.Title);
}

function DepartmentModel(item) {
    var self = this;
    if (item != null) {
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.Title = ko.observable(item.Title);
    }
    else {
        self.DepartmentID = ko.observable(0);
        self.OrganizationID = ko.observable(0);
        self.Title = ko.observable(0);
    }
}

function UserRightsModel(item) {
    var self = this;
    if (item != null) {
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
    }
    else {
        self.OrganizationID = ko.observable(0);
        self.DepartmentID = ko.observable(0);
        self.UserID = ko.observable(0);
    }
}

function SMSTemplateModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.TemplateMessageEng = ko.observable(ko.utils.unwrapObservable(item.TemplateMessageEng || ''));
        self.IsActive = ko.observable(ko.utils.unwrapObservable(item.IsActive));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.Organization = ko.observable(ko.utils.unwrapObservable(item.Organization));
        self.MessageType = ko.observable(ko.utils.unwrapObservable(item.MessageType || 2).toString());
        self.TemplateMessageUrdu = ko.observable(ko.utils.unwrapObservable(item.TemplateMessageUrdu || ''));

        self.NoOfSMSEng = ko.observable();
        self.NoOfSMSUrd = ko.observable();
    }
    else {
        self.ID = ko.observable();
        self.Title = ko.observable();
        self.TemplateMessageEng = ko.observable('');
        self.IsActive = ko.observable(true);
        self.OrganizationID = ko.observable();
        self.DepartmentID = ko.observable();
        self.Organization = ko.observable();
        self.MessageType = ko.observable('2');
        self.TemplateMessageUrdu = ko.observable('');

        self.NoOfSMSEng = ko.observable();
        self.NoOfSMSUrd = ko.observable();
    }

    self.CharacterCount = ko.computed(function () {
        return (1500 - parseInt(self.TemplateMessageEng().length)) < 0 ? 'Limit Exceeded' : 1500 - parseInt(self.TemplateMessageEng().length);
    });

    self.MessageCountEn = ko.computed(function () {
        //return parseInt(parseInt(self.TemplateMessageEng().length) % 153) == 0 ? parseInt(parseInt(self.TemplateMessageEng().length) / 153) || 0 : parseInt(parseInt(self.TemplateMessageEng().length) / 153) + 1 || 0;   comment by hammad - 27-01-2016 05:34:19PM

        var count = parseInt(parseInt(self.TemplateMessageEng().length) % 153) == 0 ? parseInt(parseInt(self.TemplateMessageEng().length) / 153) || 0 : parseInt(parseInt(self.TemplateMessageEng().length) / 153) + 1 || 0;
        self.NoOfSMSEng(count);
        return count;
    });

    self.CharacterCountUr = ko.computed(function () {
        return (1000 - parseInt(self.TemplateMessageUrdu().length)) < 0 ? 'Limit Exceeded' : 1000 - parseInt(self.TemplateMessageUrdu().length);
    });

    self.MessageCountUr = ko.computed(function () {
        //return parseInt(parseInt(self.TemplateMessageUrdu().length) % 67) == 0 ? parseInt(parseInt(self.TemplateMessageUrdu().length) / 67) || 0 : parseInt(parseInt(self.TemplateMessageUrdu().length) / 67) + 1 || 0;  comment by hammad - 27-01-2016 05:34:19PM

        var count = parseInt(parseInt(self.TemplateMessageUrdu().length) % 67) == 0 ? parseInt(parseInt(self.TemplateMessageUrdu().length) / 67) || 0 : parseInt(parseInt(self.TemplateMessageUrdu().length) / 67) + 1 || 0;
        self.NoOfSMSUrd(count);
        return count;
    });

    self.messageTypeChange = function (item) {

        if (item.MessageType() == 2) {
            self.TemplateMessageEng(item.TemplateMessageEng());
        }
        else {
            self.TemplateMessageUrdu(item.TemplateMessageUrdu());
        }

        return true;
    };
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function OrganizationModel(item) {
    var self = this;
    self.OrganizationID = ko.observable(item.ID);
    self.Title = ko.observable(item.Title);
}

$(document).ready(function () {

    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {

    $.ajax({
        url: "SMSTemplate.aspx/GetRecord",
        type: 'POST',
        data: "{jsonModel : '" + ko.toJSON(mod) + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new SMSTemplateModel(null));
                viewModel.main().User(new UserRightsModel(data.d.User));

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new SMSTemplateModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function LoadRecordSearch(mod, searchText) {

    $.ajax({
        url: "SMSTemplate.aspx/GetRecordSearch",
        type: 'POST',
        data: "{jsonModel : '" + ko.toJSON(mod) + "', searchText : '" + searchText + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new SMSTemplateModel(null));
                viewModel.main().User(new UserRightsModel(data.d.User));

                if (viewModel.main().User().OrganizationID() != 0)
                    viewModel.main().editModel().OrganizationID(viewModel.main().User().OrganizationID());

                if (viewModel.main().User().DepartmentID() != 0)
                    viewModel.main().editModel().DepartmentID(viewModel.main().User().DepartmentID());
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new SMSTemplateModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function validateEmptyMessage(obj) {
    var ret = false;

    if (obj.MessageType() == 2) {
        if (obj.MessageCountEn() > 0)
            ret = true;
    }
    else if (obj.MessageType() == 3) {
        if (obj.MessageCountUr() > 0)
            ret = true;
    }
    return ret;
}