$(document).ready(function () {
    $(document).ajaxSend(function (event, xhr, options) {
       $('#overlay').show();
    });
    $(document).ajaxSuccess(function () {
        $('#overlay').hide();
    });
    $(document).ajaxStop(function () {
        $('#overlay').hide();
    });
    $(document).ajaxComplete(function () {
        $('#overlay').hide();
    });
    $(document).ajaxError(function () {
        $('#overlay').hide();
    });
});