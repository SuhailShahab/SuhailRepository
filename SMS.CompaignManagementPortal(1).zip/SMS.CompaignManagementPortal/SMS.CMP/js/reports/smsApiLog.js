﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var refSearchText = '';
var refTSearchText = '';
var orgID;
var deptID;
var all_organization = [];
var all_departments = [];


//** TimePicker Custom binding **\\
ko.bindingHandlers.timeValue = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
        var tpicker = $(element).timepicker();
        tpicker.on('changeTime.timepicker', function (e) {

            //Asignar la hora y los minutos
            var value = valueAccessor();
            if (!value) {
                throw new Error('timeValue binding observable not found');
            }
            var date = ko.unwrap(value);
            var mdate = moment(date || new Date());
            var hours24;
            if (e.time.meridian == "AM") {
                if (e.time.hours == 12)
                    hours24 = 0;
                else
                    hours24 = e.time.hours;
            }
            else {
                if (e.time.hours == 12) {
                    hours24 = 12;
                }
                else {
                    hours24 = e.time.hours + 12;
                }
            }

            mdate.hours(hours24)
            mdate.minutes(e.time.minutes);
            $(element).data('updating', true);
            value(mdate.toDate());
            $(element).data('updating', false);


        })
    },
    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
        //Avoid recursive calls
        if ($(element).data('updating')) {
            return;
        }
        var date = ko.unwrap(valueAccessor()) || new Date();

        if (date) {
            var time = moment(date).format("hh:mmA");
            //var matches = time.match(/(\d{1,2}):(\d{2})/);
            //var zone = parseInt(matches[0]) >= 12 ? 'PM' : 'AM';
            //time = matches[1] + ':' + matches[2] + ' ' + zone;
            $(element).timepicker('setTime', time);
        }
        else {
            // $(element).timepicker('clear');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};


ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

//ko.bindingHandlers.validate = {
//    init: function (element, valueAccessor, allBindingsAccessor) {
//        var text = allBindingsAccessor().value || {};
//        ko.utils.registerEventHandler(element, "blur", function () {
//            $(element).validationEngine('validate');
//        });
//    },
//    update: function (element, valueAccessor, allBindingsAccessor) {
//        var text = allBindingsAccessor().value || {};
//        if (text() != undefined) {
//            $(element).validationEngine('validate');
//        }
//    }
//};


function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function wrapperModel(items) {

    var self = this;
    self.isEdit = ko.observable(false);

    self.PageSize = ko.observable(5);
    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);

    self.SearchText = ko.observable(refSearchText);

    self.TPageSize = ko.observable(5);
    self.TPageNo = ko.observable(1);
    self.TTotalResults = ko.observable(0);

    self.TSearchText = ko.observable(refTSearchText);

    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.allTransactions = ko.observableArray();

    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();

    self.OrganizationID = ko.observable();
    self.DepartmentID = ko.observable();
    self.CampaignID = ko.observable();
    self.CampaignStatuses = ko.observableArray();
    self.SendMessage = ko.observable();
    self.APIUrl = ko.observable('');
    self.APIUrl2 = ko.observable('');
    self.User = ko.observable(new UserRightsModel(null));
    var startdate = moment();
    startdate = startdate.subtract(7, "days");
    startdate = startdate.format("DD/MM/YYYY");
    
    self.FromDate = ko.observable(startdate);
    self.ToDate = ko.observable(new Date());

    if (items != null) {

        if (items.SMSCampaignLogs != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(items.SMSCampaignLogs, function (item) {
                self.allRecords.push(new SMSCampaignModel(item));
                ref_all_rec.push(new SMSCampaignModel(item))
            });
        }

        if (items.Organizations != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Organizations), function (organ) {
                self.Organizations.push(new OrganizationModel(organ));
                all_organization.push(new OrganizationModel(organ));
            });
        }
        else {
            self.Organizations(all_organization);
        }

        if (items.Departments != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Departments), function (dept) {
                self.Departments.push(new DepartmentModel(dept));
            });
        }

        self.APIUrl(items.APIUrl);
        self.APIUrl2(items.APIUrl2);
        self.PageSize(items.PageSize);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());


        self.TPager = ko.pager(self.TTotalResults, self.TPageSize);
    }
    else {
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.TPager = ko.pager(self.TTotalResults, self.TPageSize);
    }

    self.getDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "SMSApiLogs.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d != null) {
                            self.Departments([]);
                            if (all_departments != null) {
                                all_departments = [];
                            }
                            if (data.d.Departments != null)
                                ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                    self.Departments.push(new DepartmentModel(dept));
                                    all_departments.push(new DepartmentModel(dept));
                                });
                        }
                    }
                    else {
                        self.Departments([]);
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else
            self.Departments([]);
    };

    self.getLogs = function (item) {
        LoadRecord(true, ko.utils.unwrapObservable(self.OrganizationID()), ko.utils.unwrapObservable(self.DepartmentID()));
    };

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        LoadRecord(true, ko.utils.unwrapObservable(self.OrganizationID), ko.utils.unwrapObservable(self.DepartmentID), self.PageNo(), self.SearchText());
    };

    self.getTPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.TPageNo(ko.utils.unwrapObservable(currentPage));
        LoadTransations();
    };

    self.Filter = function (data, event) {
        if ($('.search').val().trim() != '') {
            refSearchText = self.SearchText();
            self.PageNo(0);
            LoadRecord(true, ko.utils.unwrapObservable(self.OrganizationID()), ko.utils.unwrapObservable(self.DepartmentID()), ko.utils.unwrapObservable(self.PageNo()), refSearchText)
        }
        else {
            NotifyMe("info|Please type something in search box");
        }
        event.preventDefault();
        event.stopPropagation();
        //return true;
    };

    self.Reload = function () {
        refSearchText = '';
        self.SearchText('');
        self.PageNo(1);
        self.Pager().CurrentPage(1);
        LoadRecord(true, ko.utils.unwrapObservable(self.OrganizationID()), ko.utils.unwrapObservable(self.DepartmentID()));
    };

    self.TFilter = function (data, event) {
        //if ($('.tsearch').val().trim() != '') {
            refTSearchText = self.TSearchText();
            self.TPageNo(0);
            LoadTransations();
        /*}
        else {
            NotifyMe("info|Please type something in search box");
        }*/
        event.preventDefault();
        event.stopPropagation();
        //return true;
    };

    self.TReload = function () {
        self.FromDate(moment().subtract(7, "days").format("DD/MM/YYYY"));
        self.ToDate(new Date());
        refTSearchText = '';
        self.TSearchText('');
        self.TPageNo(1);
        self.TPager().CurrentPage(1);
        LoadTransations();
    };

    self.editRecord = function (item) {
        self.FromDate(moment().subtract(7, "days").format("DD/MM/YYYY"));
        self.ToDate(new Date());
    $.ajax({
        url: "SMSApiLogs.aspx/GetRecordsByID",
        type: 'POST',
        data: "{campaignID : '" + ko.toJSON(item.CampaignID) + "',organizationID : '" + ko.toJSON(item.OrganizationID) + "', pageNo : '" + ko.toJSON(0) + "', searchText : '" + viewModel.main().TSearchText() + "', showStatus : '1" + "', fromDate : '" + self.FromDate().format('M/dd/yyyy') + "', toDate : '" + self.ToDate().format('M/dd/yyyy') + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main().CampaignID(ko.utils.unwrapObservable(item.CampaignID));
         //   viewModel.main().OrganizationID(ko.utils.unwrapObservable(item.OrganizationID));
            if (NotifyMe(data.d.Notification)) {
                viewModel.main().allTransactions([]);
                if (data.d.Transactions != null) {
                    ko.utils.arrayForEach(data.d.Transactions, function (item) {
                        viewModel.main().allTransactions.push(new SMSTransactionModel(item));
                    });
                }

                viewModel.main().CampaignStatuses([]);
                if (data.d.CampaignStatuses != null) {
                    viewModel.main().CampaignStatuses([]);
                    ko.utils.arrayForEach(data.d.CampaignStatuses, function (item) {
                        viewModel.main().CampaignStatuses.push(new CampaignStatusesModel(item));
                    });
                }

                viewModel.main().TPageSize(data.d.TPageSize);
                viewModel.main().TTotalResults(data.d.TTotalCount);

                viewModel.main().APIUrl(data.d.APIUrl);
                viewModel.main().APIUrl2(data.d.APIUrl2);
                viewModel.main().isEdit(true);
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
    };

}



function LoadTransations() {
    if (ko.utils.unwrapObservable(viewModel.main().CampaignID()) != undefined) {
        $.ajax({
            url: "SMSApiLogs.aspx/GetRecordsByID",
            type: 'POST',
            data: "{campaignID : '" + ko.toJSON(ko.utils.unwrapObservable(viewModel.main().CampaignID)) + "',organizationID : '" + ko.toJSON(ko.utils.unwrapObservable(viewModel.main().OrganizationID)) + "', pageNo : '" + ko.toJSON(ko.utils.unwrapObservable(viewModel.main().TPageNo)) + "', searchText : '" + viewModel.main().TSearchText() + "', showStatus : '1" + "', fromDate : '" + viewModel.main().FromDate().format('M/dd/yyyy') + "', toDate : '" + viewModel.main().ToDate().format('M/dd/yyyy') + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {

                viewModel.main().allTransactions([]);
                if (NotifyMe(data.d.Notification)) {
                    if (data.d.Transactions != null) {
                        ko.utils.arrayForEach(data.d.Transactions, function (item) {
                            viewModel.main().allTransactions.push(new SMSTransactionModel(item));
                        });
                    }
                    viewModel.main().CampaignStatuses([]);
                    if (data.d.CampaignStatuses != null) {
                        viewModel.main().CampaignStatuses([]);
                        ko.utils.arrayForEach(data.d.CampaignStatuses, function (item) {
                            viewModel.main().CampaignStatuses.push(new CampaignStatusesModel(item));
                        });
                    }

                    //viewModel.main().TPager = ko.pager(viewModel.main().TTotalResults, viewModel.main().TPageSize);
                    viewModel.main().TPager().CurrentPage(viewModel.main().TPageNo());
                    viewModel.main().TPageSize(data.d.TPageSize);
                    viewModel.main().TTotalResults(data.d.TTotalCount);
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    }
}


function OrganizationModel(org) {
    var self = this;
    self.ID = ko.observable(org.ID);
    self.Title = ko.observable(org.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.DepartmentID = ko.observable(item.DepartmentID);
    self.OrganizationID = ko.observable(item.OrganizationID);
    self.Title = ko.observable(item.Title);
}

function UserRightsModel(item) {
    var self = this;
    if (item != null) {
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
    }
    else {
        self.OrganizationID = ko.observable(0);
        self.DepartmentID = ko.observable(0);
        self.UserID = ko.observable(0);
    }
}

function SMSCampaignModel(item) {

    var self = this;

    if (item != null) {

        self.CampaignID = ko.observable(item.CampaignID);
        self.CampaignName = ko.observable(item.CampaignName);
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.Mask = ko.observable(item.Mask || '');
        self.CampaignStatus = ko.observable(item.CampaignStatus);
        self.StartDate = ko.observable(ko.utils.unwrapObservable(item.StartDate).toString("dd/MM/yyyy").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.StartDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.StartDate));
        self.DailyCampaigns = ko.observable(item.DailyCampaigns);
        self.MonthlyCampaigns = ko.observable(item.MonthlyCampaigns);
        self.YearlyCampaigns = ko.observable(item.YearlyCampaigns);
        self.WeeklyCampaigns = ko.observable(item.WeeklyCampaigns);
        
        // self.ApiURL = ko.observable(item.ApiURL);
    }
    else {

        self.CampaignID = ko.observable();
        self.CampaignName = ko.observable();
        self.OrganizationID = ko.observable();
        self.Mask = ko.observable();
        self.CampaignStatus = ko.observable();
        self.StartDate = ko.observable();
        self.DailyCampaigns = ko.observable();
        self.MonthlyCampaigns = ko.observable();
        self.MonthlyCampaigns = ko.observable();
        self.WeeklyCampaigns = ko.observable();
        self.YearlyCampaigns = ko.observable();
        // self.ApiURL = ko.observable();
    }

}

function CampaignStatusesModel(item) {
    var self = this;
    self.Title = ko.observable(item.Title);
    self.count = ko.observable(item.count);
}

function SMSTransactionModel(item) {

    var self = this;

    if (item != null) {
        self.SMSTransactionID = ko.observable(item.SMSTransactionID);
        self.Network = ko.observable(item.Network);
        self.ContactNo = ko.observable(item.ContactNo);
        self.Mask = ko.observable(item.Mask || '');
        self.SMSSendingStatus = ko.observable(item.SMSSendingStatus);
        self.StartDate = ko.observable(ko.utils.unwrapObservable(item.StartDate) != null ? ko.utils.unwrapObservable(item.StartDate).toString("dd/MM/yyyy").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.StartDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.StartDate) : '-');
        self.EndDate = ko.observable(ko.utils.unwrapObservable(item.EndDate) != null ? ko.utils.unwrapObservable(item.EndDate).toString("dd/MM/yyyy").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.EndDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.EndDate) : '-');
        self.TotalAllocatedSMS = ko.observable(item.TotalAllocatedSMS);
        self.SendingDate = ko.observable(ko.utils.unwrapObservable(item.SendingDate) != null ? ko.utils.unwrapObservable(item.SendingDate).toString("dd/MM/yyyy").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.SendingDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.SendingDate) : '-');

        self.SendingTime = ko.observable(ko.utils.unwrapObservable(item.SendingDate) != null ? ko.utils.unwrapObservable(item.SendingDate).toString("hh:mm:ss tt").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.SendingDate).substring(6, 19))).format('hh:mm:ss tt') : new Date(ko.utils.unwrapObservable(item.SendingDate)).format('hh:mm:ss tt') : '-');

        self.DeliveredDate = ko.observable(ko.utils.unwrapObservable(item.DeliveredDate) != null ? ko.utils.unwrapObservable(item.DeliveredDate).toString("dd/MM/yyyy").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.DeliveredDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.DeliveredDate) : '-');

        self.DeliveredTime = ko.observable(ko.utils.unwrapObservable(item.DeliveredDate) != null ? ko.utils.unwrapObservable(item.DeliveredDate).toString("hh:mm:ss tt").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.DeliveredDate).substring(6, 19))).format('hh:mm:ss tt') : new Date(ko.utils.unwrapObservable(item.DeliveredDate)).format('hh:mm:ss tt') : '-');
        self.SendMessage = ko.observable(item.SendMessage);
        
    }
    else {
        self.SMSTransactionID = ko.observable();
        self.Network = ko.observable();
        self.Mask = ko.observable();
        self.SMSSendingStatus = ko.observable();
        self.StartDate = ko.observable();
        self.EndDate = ko.observable();
        self.ContactNo = ko.observable();
        self.TotalAllocatedSMS = ko.observable();
        self.SendingDate = ko.observable();
        self.DeliveredDate = ko.observable();
        self.SendingTime = ko.observable();
        self.DeliveredTime = ko.observable();
        self.SendMessage = ko.observable();
    }


    self.showMessage = function (item) {
        $.ajax({
            url: "SMSApiLogs.aspx/GetSMSSendMessage",
            type: 'POST',
            data: "{transactionID : '" + ko.toJSON(item.SMSTransactionID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {

                    viewModel.main().SendMessage(data.d.SendMessage);
                    $('#myModal').modal('show');
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    }
}

$(document).ready(function () {
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord(isLoad, organizationID, departmentID, pageNo, searchText) {
    organizationID = organizationID || 0;
    departmentID = departmentID || 0;
    pageNo = pageNo || 0;
    searchText = searchText || '';
    isLoad = isLoad || false;
    //var fromDate = viewModel.main().FromDate() != undefined && viewModel.main().FromDate() != "" ? viewModel.main().FromDate().format('M/dd/yyyy') : "";
   // var toDate = viewModel.main().ToDate() != undefined && viewModel.main().ToDate() != "" ? viewModel.main().ToDate().format('M/dd/yyyy') : "";
    $.ajax({
        url: "SMSApiLogs.aspx/GetRecords",
        type: 'POST',
        data: "{organizationID : '" + ko.toJSON(organizationID) + "', departmentID : '" + ko.toJSON(departmentID) + "', pageNo : '" + ko.toJSON(pageNo) + "', searchText : '" + searchText + "', isLoad : '" + isLoad + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new SMSCampaignModel(null));
                viewModel.main().User(new UserRightsModel(data.d.User));

                viewModel.main().OrganizationID(organizationID);
                viewModel.main().Departments(all_departments);
                viewModel.main().DepartmentID(departmentID);

                //if (viewModel.main().User().OrganizationID() != 0) {
                //    viewModel.main().OrganizationID(viewModel.main().User().OrganizationID());
                //}
                //else {
                //    viewModel.main().OrganizationID(organizationID);
                //}

                if (viewModel.main().User().DepartmentID() != 0) {
                    viewModel.main().DepartmentID(viewModel.main().User().DepartmentID());
                }
                else {
                    viewModel.main().DepartmentID(departmentID);
                }
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new SMSCampaignModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

