﻿var viewModel = new ViewModel();
var refSearchText = '';

//** TimePicker Custom binding **\\
ko.bindingHandlers.timeValue = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
        var tpicker = $(element).timepicker();
        tpicker.on('changeTime.timepicker', function (e) {

            //Asignar la hora y los minutos
            var value = valueAccessor();
            if (!value) {
                throw new Error('timeValue binding observable not found');
            }
            var date = ko.unwrap(value);
            var mdate = moment(date || new Date());
            var hours24;
            if (e.time.meridian == "AM") {
                if (e.time.hours == 12)
                    hours24 = 0;
                else
                    hours24 = e.time.hours;
            }
            else {
                if (e.time.hours == 12) {
                    hours24 = 12;
                }
                else {
                    hours24 = e.time.hours + 12;
                }
            }

            mdate.hours(hours24)
            mdate.minutes(e.time.minutes);
            $(element).data('updating', true);
            value(mdate.toDate());
            $(element).data('updating', false);


        })
    },
    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
        //Avoid recursive calls
        if ($(element).data('updating')) {
            return;
        }
        var date = ko.unwrap(valueAccessor()) || new Date();

        if (date) {
            var time = moment(date).format("hh:mmA");
            //var matches = time.match(/(\d{1,2}):(\d{2})/);
            //var zone = parseInt(matches[0]) >= 12 ? 'PM' : 'AM';
            //time = matches[1] + ':' + matches[2] + ' ' + zone;
            $(element).timepicker('setTime', time);
        }
        else {
            // $(element).timepicker('clear');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};


ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.AllowUpdate = ko.observable(true);
    self.PageSize = ko.observable(5);

    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);
    self.SearchText = ko.observable(refSearchText);

    self.Organizations = ko.observableArray();
    self.Departments = ko.observableArray();
 
    self.SMSCampaigns = ko.observableArray();

    self.OrganizationID = ko.observable(0);
    self.DepartmentID = ko.observable(0);
    self.ShortCodeID = ko.observable(0);
    self.CampaignID = ko.observable(0);
    self.UserID = ko.observable(0);

    self.FromDate = ko.observable('');
    self.ToDate = ko.observable('');

    self.SMSTitle = ko.observable('');

    self.allRecords = ko.observableArray();
    self.User = ko.observable(new UserRightsModel(null));
    self.SendMessage = ko.observable('');

    if (items != null) {

        if (items.Organizations != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Organizations), function (organ) {
                self.Organizations.push(new OrganizationModel(organ));
            });
        }

        if (items.Departments != null) {
            self.Departments([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Departments), function (dept) {
                self.Departments.push(new DepartmentModel(dept));
            });
        }

       

        if (items.SMSCampaigns != null) {
            self.SMSCampaigns([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.SMSCampaigns), function (camp) {
                self.SMSCampaigns.push(new CampaignModel(camp));
            });
        }
         

        if (items.SMSQueues != null) {
            self.allRecords([]);
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.SMSQueues), function (trans) {
                self.allRecords.push(new SMSQueuesModel(trans));
            });
        }
        else {
            self.allRecords([]);
        }

        self.PageSize(items.PageSize || 2);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.TotalCount);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());
    }

    self.Filter = function (data, event) {
        if ($('.search').val().trim() != '') {
            self.SearchText($('.search').val());
            refSearchText = $('.search').val();
            viewModel.main().PageNo(0);
            LoadRecord(viewModel.main(), true);
        }
        else {
            NotifyMe("info|Please type something in search box");
        }
        event.preventDefault();
        event.stopPropagation();
    };

    self.Reload = function () {
        refSearchText = '';
        self.SearchText($('.search').val(''));
        viewModel.main().PageNo(0);
        LoadRecord(viewModel.main(), true);
    };

    self.getRecord = function () {
        if ($('form').validationEngine('validate')) {
            LoadRecord(viewModel.main(), true);
        }
    };

    self.Reset = function () {
        viewModel.main().PageNo(0);
        LoadRecord(viewModel.main(), false);
    };

    self.Resend = function () {
        $.ajax({
            url: "SMSBufferLog.aspx/ResetSMSQueue",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(self.OrganizationID()) + "',campaignID : '" + ko.toJSON(self.CampaignID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                   
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };


    self.getDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "SMSBufferLog.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.Departments != null) {
                            self.Departments([]);
                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                self.Departments.push(new DepartmentModel(dept));
                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.getCampaigns = function (item) {
        if (item.OrganizationID() != undefined && item.DepartmentID() != undefined) {
            $.ajax({
                url: "SMSBufferLog.aspx/GetSMSCampaigns",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "',deptID : '" + ko.toJSON(item.DepartmentID()) + "',userID : '" + ko.toJSON(item.UserID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.SMSCampaigns != null) {
                            self.SMSCampaigns([]);
                            ko.utils.arrayForEach(data.d.SMSCampaigns, function (camp) {
                                self.SMSCampaigns.push(new CampaignModel(camp));
                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        LoadRecord(viewModel.main(), true);
    };
}

function UserRightsModel(item) {
    var self = this;
    if (item != null) {
        self.OrganizationID = ko.observable(item.OrganizationID);
        self.DepartmentID = ko.observable(item.DepartmentID);
        self.UserID = ko.observable(item.UserID);
    }
    else {
        self.OrganizationID = ko.observable(0);
        self.DepartmentID = ko.observable(0);
        self.UserID = ko.observable(0);
    }
}

function SMSQueuesModel(item) {
    var self = this;
    if (item != null) {
        self.SMSQueueID = ko.observable(item.ID);
        self.Phone = ko.observable(item.Phone);
        self.ShortCode = ko.observable(item.ShortCode);
        self.IsSend = ko.observable(item.IsSend);
        self.SMSSendingStatus = ko.observable(item.SMSSendingStatus);
        self.CreatedDate = ko.observable(ko.utils.unwrapObservable(item.CreatedDate) != null ? ko.utils.unwrapObservable(item.CreatedDate).toString("dd/MM/yyyy").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.CreatedDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.CreatedDate) : '-');
        self.CreatedTime = ko.observable(ko.utils.unwrapObservable(item.CreatedDate) != null ? ko.utils.unwrapObservable(item.CreatedDate).toString("hh:mm:ss tt").indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.CreatedDate).substring(6, 19))).format('hh:mm:ss tt') : new Date(ko.utils.unwrapObservable(item.CreatedDate)).format('hh:mm:ss tt') : '-');
        self.SendMessage = ko.observable(item.SendMessage);
        self.PriorityID = ko.observable(item.PriorityID);
    }
    else {
        self.SMSQueueID = ko.observable();
        self.Phone = ko.observable();
        self.ShortCode = ko.observable();
        self.IsSend = ko.observable();
        self.SMSSendingStatus = ko.observable();
        self.CreatedDate = ko.observable();
        self.CreatedTime = ko.observable();
        self.SendMessage = ko.observable();
        self.PriorityID = ko.observable();
    }


    self.getResponceMsg = function (item) {
        $.ajax({
            url: "SMSBufferLog.aspx/GetSMSQueueMessage",
            type: 'POST',
            data: "{queueID : '" + ko.toJSON(item.SMSQueueID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (data.d.SendMessage != null) {
                        viewModel.main().SendMessage(data.d.SendMessage);
                        viewModel.main().SMSTitle('Sent Message');
                        $('#SMSModal').modal('show');
                    }
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    };


}


function CampaignModel(code) {
    var self = this;
    self.CampaignID = ko.observable(code.CampaignID);
    self.Title = ko.observable(code.Title);
}

function OrganizationModel(org) {
    var self = this;
    self.ID = ko.observable(org.ID);
    self.Title = ko.observable(org.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.DepartmentID = ko.observable(item.DepartmentID);
    self.OrganizationID = ko.observable(item.OrganizationID);
    self.Title = ko.observable(item.Title);
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
   
    LoadRecord(new wrapperModel(null));
    ko.applyBindings(viewModel);
});

function LoadRecord(mod, isLoad) {
    isLoad = isLoad || false;
    var fromDate = mod.FromDate() != undefined && mod.FromDate() != "" ? mod.FromDate().format('M/dd/yyyy') : "";
    var toDate = mod.ToDate() != undefined && mod.ToDate() != "" ? mod.ToDate().format('M/dd/yyyy') : "";
    var searchText = mod.SearchText() || "";
    $.ajax({
        url: "SMSBufferLog.aspx/GetRecord",
        type: 'POST',
        data: "{organizationID : '" + ko.toJSON(mod.OrganizationID() || 0) + "', departmentID : '" + ko.toJSON(mod.DepartmentID() || 0) + "', campaignID : '" + ko.toJSON(mod.CampaignID() || 0) + "', pageNo : '" + mod.PageNo() + "', fromDate : '" + fromDate + "', toDate : '" + toDate + "', searchText : '" + searchText + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().User(new UserRightsModel(data.d.User));

                if (!isLoad) {
                    if (viewModel.main().User().OrganizationID() != 0)
                        viewModel.main().OrganizationID(viewModel.main().User().OrganizationID());

                    if (viewModel.main().User().DepartmentID() != 0)
                        viewModel.main().DepartmentID(viewModel.main().User().DepartmentID());

                    if (viewModel.main().User().UserID() != 0)
                        viewModel.main().UserID(viewModel.main().User().UserID());
                }
                else {
                    viewModel.main().OrganizationID(mod.OrganizationID());
                    viewModel.main().DepartmentID(mod.DepartmentID());
                    viewModel.main().UserID(mod.UserID());
                    viewModel.main().CampaignID(mod.CampaignID());

                    viewModel.main().FromDate(mod.FromDate());
                    viewModel.main().ToDate(mod.ToDate());
                }

            }
            else {
                viewModel.main(new wrapperModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

