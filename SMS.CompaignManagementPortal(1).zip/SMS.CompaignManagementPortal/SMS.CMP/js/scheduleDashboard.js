﻿var date = new Date();
var d = date.getDate();
var m = date.getMonth();
var y = date.getFullYear();

(function () {

    ko.fullCalendar = {
        // Defines a view model class you can use to populate a calendar
        viewModel: function (configuration) {
            this.events = configuration.events;
            this.header = configuration.header;
            this.editable = configuration.editable;
            this.viewDate = configuration.viewDate || ko.observable(new Date());
        }
    };

    // The "fullCalendar" binding
    ko.bindingHandlers.fullCalendar = {
        // This method is called to initialize the node, and will also be called again if you change what the grid is bound to
        update: function (element, viewModelAccessor) {
            var viewModel = viewModelAccessor();
            element.innerHTML = "";

            $(element).fullCalendar({
                events: ko.utils.unwrapObservable(viewModel.events),
                header: viewModel.header,
                editable: viewModel.editable,
                eventLimit: true
            });
            $(element).fullCalendar('gotoDate', ko.utils.unwrapObservable(viewModel.viewDate));
        }
    };
})();

var viewModel = new ViewModel();
var tabs = [
    {
        Title: 'Director General',
        ID: '1',
        TargetID: '#home',
        IsActive: true
    },
    {
        Title: 'Joint Director (Tech)',
        ID: '2',
        TargetID: '#home',
        IsActive: true
    },
    {
        Title: 'Programe Manager (Operation)',
        ID: '3',
        TargetID: '#home',
        IsActive: true
    }
];
var tempData = [
        {
            title: 'All Day Event',
            start: new Date(y, m, 1)
        },
    {
        title: 'Long Event',
        start: new Date(y, m, d - 5),
        end: new Date(y, m, d - 2)
    },
    {
        id: 999,
        title: 'Repeating Event',
        start: new Date(y, m, d - 3, 16, 0),
        allDay: false
    },
    {
        id: 999,
        title: 'Repeating Event',
        start: new Date(y, m, d + 4, 16, 0),
        allDay: false
    },
    {
        title: 'Meeting',
        start: new Date(y, m, d, 10, 30),
        allDay: false
    },
    {
        title: 'Lunch',
        start: new Date(y, m, d, 12, 0),
        end: new Date(y, m, d, 14, 0),
        allDay: false
    },
    {
        title: 'Birthday Party',
        start: new Date(y, m, d + 1, 19, 0),
        end: new Date(y, m, d + 1, 22, 30),
        allDay: false
    },
    {
        title: 'Click for Google',
        start: new Date(y, m, 28),
        end: new Date(y, m, 29),
        url: 'http://google.com/'
    }
];


function WrapperModel(item) {
    var self = this;

    self.AllTabs = ko.observableArray();
    self.AllTabs.push(new TabModel(null));

    self.items = ko.observableArray(tempData);

    //var mod = new EventModel(null);
    //self.items.push(mod);

    self.calendarViewModel = new ko.fullCalendar.viewModel({
        events: self.items,
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
        },
        editable: false,
        viewDate: new Date()
    });


}

function EventModel(evnt) {
    var self = this;
    if (evnt != null) {
        self.title = evnt.title;
        self.start = evnt.start;
        self.end = evnt.end;
        self.allDay = false;
    }
    else {
        self.title = 'Test';
        self.start = new Date(y, m, d, 12, 0);
        self.end = new Date(y, m, d, 14, 0);
        self.allDay = false;
    }
}


function TabModel(tab) {
    var self = this;
    if (tab != null) {
        self.Title = ko.observable(tab.Title);
        self.ID = ko.observable(tab.ID);
        self.TargetID = ko.observable(tab.TargetID);
        self.IsActive = ko.observable(tab.IsActive);
    }
    else {
        self.Title = ko.observable('Director General');
        self.ID = ko.observable('1');
        self.TargetID = ko.observable('#home');
        self.IsActive = ko.observable(true);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {

    //$('#calendar').fullCalendar({
    //    defaultDate: '2015-12-12',
    //    editable: true,
    //    eventLimit: true    //,
    //    //events: [
    //    //    {
    //    //        title: 'All Day Event',
    //    //        start: '2015-12-01'
    //    //    },
    //    //    {
    //    //        title: 'Long Event',
    //    //        start: '2015-12-07',
    //    //        end: '2015-12-10'
    //    //    },
    //    //    {
    //    //        id: 999,
    //    //        title: 'Repeating Event',
    //    //        start: '2015-12-09T16:00:00'
    //    //    },
    //    //    {
    //    //        id: 999,
    //    //        title: 'Repeating Event',
    //    //        start: '2015-12-16T16:00:00'
    //    //    },
    //    //    {
    //    //        title: 'Conference',
    //    //        start: '2015-12-11',
    //    //        end: '2015-12-13'
    //    //    },
    //    //    {
    //    //        title: 'Meeting',
    //    //        start: '2015-12-12T10:30:00',
    //    //        end: '2015-12-12T12:30:00'
    //    //    },
    //    //    {
    //    //        title: 'Lunch',
    //    //        start: '2015-12-12T12:00:00'
    //    //    },
    //    //    {
    //    //        title: 'Meeting',
    //    //        start: '2015-12-12T14:30:00'
    //    //    },
    //    //    {
    //    //        title: 'Happy Hour',
    //    //        start: '2015-12-12T17:30:00'
    //    //    },
    //    //    {
    //    //        title: 'Dinner',
    //    //        start: '2015-12-12T20:00:00'
    //    //    },
    //    //    {
    //    //        title: 'Birthday Party',
    //    //        start: '2015-12-13T07:00:00'
    //    //    },
    //    //    {
    //    //        title: 'Click for Google',
    //    //        url: 'http://google.com/',
    //    //        start: '2015-12-28'
    //    //    }
    //    //]
    //});

    viewModel.main(new WrapperModel(null));
    ko.applyBindings(viewModel);

});