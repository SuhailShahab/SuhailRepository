﻿
// CR:                  Usman Mirza             10-Jun-2015            Addition of Dropdown for mapping FC District ID 


var viewModel = new ViewModel();
var all_provinces = [];
var all_organization = [];
var refModel = null;
var ref_all_rec = [];
//var all_Mapdistricts = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.organizations = ko.observableArray();

    if (items != null) {
        if (items.Departments != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(items.Departments, function (item) {
                self.allRecords.push(new DepartmentModel(item));
                ref_all_rec.push(new DepartmentModel(item));
            });
        }
        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }


    self.editRecord = function (item) {

        refModel = new DepartmentModel(item);
        var mod = new DepartmentModel(item);
        self.editModel(mod);
        self.allRecords.remove(item);
        self.isEdit(true);
    }

    self.cancelRecord = function () {
        var mod = new DepartmentModel(null);
        self.editModel(mod);
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    }

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "Department.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.Status(false);
                    LoadRecord();
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        //}
    }

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "Department.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.DepartmentID > 0) {
                            LoadRecord();
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {
                
                if (item.Description != "") {
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Organization().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                }
                else
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Organization().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;


                //return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    }

    self.Reload = function () {
        LoadRecord();
    }
}

function DepartmentModel(item) {
    var self = this;

    if (item != null) {
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.Organization = ko.observable(ko.utils.unwrapObservable(item.Organization));
        self.Code = ko.observable(ko.utils.unwrapObservable(item.Code));
        self.PerSMSRate = ko.observable(ko.utils.unwrapObservable(item.PerSMSRate || 0));
        self.SMSLimit = ko.observable(ko.utils.unwrapObservable(item.SMSLimit));
        self.IsAllowedCampaingName = ko.observable(ko.utils.unwrapObservable(item.IsAllowedCampaingName));
    }
    else {

        self.DepartmentID = ko.observable();
        self.OrganizationID = ko.observable();
        self.Title = ko.observable();
        self.Description = ko.observable();
        self.Status = ko.observable(true);
        self.Organization = ko.observable();
        self.Code = ko.observable();
        self.PerSMSRate = ko.observable(0);
        self.SMSLimit = ko.observable();
        self.IsAllowedCampaingName = ko.observable(true);
    }

}

function OrganizationModel(model) {
    var self = this;
    self.ID = ko.observable(model.ID);
    self.Title = ko.observable(model.Title);
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Department.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new DepartmentModel(null));

                if (data.d.Organizations != null) {
                    ko.utils.arrayForEach(data.d.Organizations, function (organization) {
                        viewModel.main().organizations.push(new OrganizationModel(organization));
                    });
                    all_organization = viewModel.main().organizations();
                }
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new DepartmentModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}