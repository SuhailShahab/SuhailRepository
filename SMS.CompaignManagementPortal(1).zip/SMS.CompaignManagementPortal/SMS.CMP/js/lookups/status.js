﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
          //  $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
          //  $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(item) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    if (item != null) {
        ref_all_rec = [];
        ko.utils.arrayForEach(item, function (Status) {
            self.allRecords.push(new StatusModel(Status));
            ref_all_rec.push(new StatusModel(Status));
        });

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new StatusModel(item);
        self.editModel(new StatusModel(item));
        self.allRecords.remove(item);
        self.isEdit(true);
    };

    self.cancelRecord = function () {
        self.editModel(new StatusModel(null));
        self.allRecords.push(refModel);
        self.isEdit(false);
    };

    self.removeRecord = function (item) {
        $.ajax({
            url: "Status.aspx/RemoveRecord", //../../../../Layouts/PITB.FC/Lookups/Status.aspx/RemoveStatus
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d == "true") {
                    item.IsActive(false);
                    //NotifyMe("inactivesuccess");
                }
                else if (data.d != "true" && data.d != "false") {
                    NotifyMe(data.d);
                }
            },
            error: function (request) {
                alert(Error);
            }
        });
    };

    self.saveRecord = function () {
      
            $.ajax({
                url: "Status.aspx/SaveRecord", //../../../../Layouts/PITB.FC/Lookups/Status.aspx/SaveStatus
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.d.ID > 0) {
                        var mod = new StatusModel(data.d);
                        self.allRecords.unshift(mod);
                        self.editModel(new StatusModel(null));
                        self.isEdit(false);
                    }
                },
                error: function (request) {
                }
            });
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                if (item.Description != "") {
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                }
                else
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }
}

function StatusModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.StatusID = ko.observable(ko.utils.unwrapObservable(item.StatusID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.IsActive = ko.observable(ko.utils.unwrapObservable(item.IsActive));
    }
    else {
        self.ID = ko.observable();
        self.StatusID = ko.observable();
        self.Title = ko.observable();
        self.Description = ko.observable('');
        self.IsActive = ko.observable(true);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Status.aspx/GetRecord", //../../../../Layouts/PITB.FC/Lookups/Status.aspx/GetAllStatus
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new wrapperModel(data.d));
            viewModel.main().editModel(new StatusModel(null));
        },
        error: function (request) {
        }
    });
}