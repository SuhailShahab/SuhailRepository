﻿var viewModel = new ViewModel();
var all_Features = [];

var refModel = null;
var ref_all_rec = [];
var hasChildes = [{ 'Title': 'Yes', 'ID': true }, { 'Title': 'No', 'ID': false }];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.IsAdmin = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    if (items != null) {
        ref_all_rec = [];
        if (items.ApplicationObjectes != null) {
            ko.utils.arrayForEach(items.ApplicationObjectes, function (item) {
                self.allRecords.push(new ApplicationObjectsModel(item));
                ref_all_rec.push(new ApplicationObjectsModel(item));
            });

        }

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new ApplicationObjectsModel(item);
        var mod = new ApplicationObjectsModel(item);
        mod.allFeatures(all_Features);

        self.editModel(mod);
        self.allRecords.remove(item);
        self.isEdit(true);
    }

    self.cancelRecord = function () {
        var mod = new ApplicationObjectsModel(null);
        mod.allFeatures(all_Features);

        self.editModel(mod);
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    }

    //self.removeRecord = function (item) {
    //    if (getConfirmation()) {
    //        $.ajax({
    //            url: "ApplicationObjects.aspx/RemoveRecord",
    //            type: 'POST',
    //            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
    //            dataType: "json",
    //            contentType: "application/json; charset=utf-8",
    //            success: function (data) {
    //                if (data.d == "true") {
    //                    item.Status(false);
    //                    NotifyMe("inactivesuccess");
    //                }
    //                else if (data.d != "true" && data.d != "false") {
    //                    NotifyMe(data.d);
    //                }
    //            },
    //            error: function (request) {
    //                alert(Error);
    //            }
    //        });
    //    }
    //}

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "ApplicationObjects.aspx/SaveRecord", //../../../../Layouts/PITB.FC/Lookups/Relation.aspx/SaveRelation
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.ID > 0) {
                            var mod = new ApplicationObjectsModel(data.d);
                            // mod.DocumentNatureName(getdocumentNatureTitlebyID(mod));
                            self.allRecords.unshift(mod);
                            mod = new ApplicationObjectsModel(null);

                            mod.allFeatures(all_Features);

                            self.editModel(mod);
                            self.isEdit(false);
                            LoadRecord();
                            //NotifyMe("saverecordSuccess");
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                return item.Name().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;

            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    }

    self.Reload = function () {
        LoadRecord();
    }


}

function ApplicationObjectsModel(item) {
    var self = this;
    if (item != null) {

        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.AppFeatureID = ko.observable(ko.utils.unwrapObservable(item.AppFeatureID));
        self.StaticName = ko.observable(ko.utils.unwrapObservable(item.StaticName));
        self.Name = ko.observable(ko.utils.unwrapObservable(item.Name));
        self.URL = ko.observable(ko.utils.unwrapObservable(item.URL));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.HasChild = ko.observable(ko.utils.unwrapObservable(item.HasChild || false).toString().toLowerCase());
        self.Sort = ko.observable(ko.utils.unwrapObservable(item.Sort));
        self.IsActive = ko.observable(ko.utils.unwrapObservable(item.IsActive));
        self.Icon = ko.observable(ko.utils.unwrapObservable(item.Icon));
    }
    else {

        self.ID = ko.observable();
        self.AppFeatureID = ko.observable(null);
        self.StaticName = ko.observable();
        self.Name = ko.observable();
        self.URL = ko.observable();
        self.Description = ko.observable();
        self.HasChild = ko.observable('false');
        self.Sort = ko.observable(0);
        self.IsActive = ko.observable(true);
        self.Icon = ko.observable();
    }
    self.arrHasChildes = ko.observableArray(hasChildes);
    self.allFeatures = ko.observableArray();
}

function featureModel(model) {
    var self = this;
    self.ID = ko.observable(model.ID);
    self.Name = ko.observable(model.MenuName);

}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "ApplicationObjects.aspx/GetRecords", //../../../../Layouts/PITB.FC/Lookups/Religion.aspx/GetAllReligions
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new ApplicationObjectsModel(null));
                if (data.d.Features != null) {
                    ko.utils.arrayForEach(data.d.Features, function (Feature) {
                        viewModel.main().editModel().allFeatures.push(new featureModel(Feature));
                    });
                    all_Features = viewModel.main().editModel().allFeatures();
                }
                viewModel.main().IsAdmin(data.d.IsAdmin || false);
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new ApplicationObjectsModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function getdocumentNatureTitlebyID(mod) {
    var ret = ko.utils.arrayFilter(all_Features, function (item) {
        return item.ID() == mod.AppFeatureID();
    });
    return ret[0] != undefined ? ret[0].Name() : '-';
}