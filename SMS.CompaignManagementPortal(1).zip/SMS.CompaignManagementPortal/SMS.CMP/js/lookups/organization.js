﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    if (items != null) {
        ref_all_rec = [];
        ko.utils.arrayForEach(items.Organizations, function (item) {
            self.allRecords.push(new DepartmentModel(item));
            ref_all_rec.push(new DepartmentModel(item))
        });

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new DepartmentModel(item);
        self.editModel(new DepartmentModel(item));
        self.allRecords.remove(item);
        self.isEdit(true);
    };

    self.cancelRecord = function () {
        self.editModel(new DepartmentModel(null));
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "Organization.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.Status(false);
                    LoadRecord();
                    //NotifyMe("inactivesuccess");
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        //}
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "Organization.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.ID > 0) {
                            var mod = new DepartmentModel(data.d);
                            self.allRecords.unshift(mod);
                            self.editModel(new DepartmentModel(null));
                            self.isEdit(false);
                            //NotifyMe("saverecordSuccess");
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                if (item.Description != "") {
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Code().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                }
                else
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                           item.Code().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    };

}

function DepartmentModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Code = ko.observable(ko.utils.unwrapObservable(item.Code));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
    }
    else {
        self.ID = ko.observable();
        self.Title = ko.observable();
        self.Code = ko.observable();
        self.Description = ko.observable('');
        self.Status = ko.observable(true);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Organization.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new DepartmentModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new DepartmentModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}