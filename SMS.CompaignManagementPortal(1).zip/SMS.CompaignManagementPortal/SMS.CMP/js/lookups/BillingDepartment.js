﻿// Created by:	<Muhammad Shakeel>
// Created date: <22-03-2018>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
//   SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================

var pageName = "BillingDepartment.aspx";

var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var all_departments = [];
var billingDepartmentID = null;

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

//Model to Set the Variable for Object model
function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    self.Departments = ko.observableArray();
    self.Departments = ko.observableArray();
    self.BillingDptID = ko.observable();

    if (items != null) {
        ref_all_rec = [];

        if (items.Departments != null) {
            self.Departments = items.Departments;
            all_departments = items.Departments;
        }

        if (items.DepartmentsByBilling != null) {
            ko.utils.arrayForEach(items.DepartmentsByBilling, function (item) {
                self.allRecords.push(new BillingDepartmentModel(item));
            });

            self.Departments = all_departments;
        }
        else {
            self.Departments = all_departments;
            self.allRecords.push(new BillingDepartmentModel(null));
        }
        self.BillingDptID = billingDepartmentID;

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.GetRecordsById = function (item) {
        billingDepartmentID = self.BillingDptID;
        GetRecordsById(billingDepartmentID);
    }

    self.addNewRow = function (item) {
        var len = self.allRecords().length;

        if (len == 0 || (self.allRecords()[len - 1].DepartmentID() > 0)) {

            for (index = 0; index <= len - 1; index++) {
                for (j = index + 1; j <= len - 1; j++) {
                    if (
                        viewModel.main().allRecords()[index].DepartmentID() == viewModel.main().allRecords()[j].DepartmentID()
                        ) {
                        NotifyMe('info|Record already exist');
                        return false;
                    }
                }
            }
            self.allRecords.push(new BillingDepartmentModel(null));
        }
        else {
            NotifyMe('info|Please select required value.');
        }
    };

    // Cancel the Edit  Record  And Cancel the Fields
    self.cancelRecord = function () {
        //self.editModel(new BillingDepartmentModel(null));
        LoadRecord();
    };

    self.removeRecord = function (item) {
        if (item.BillingDptID() > 0 && item.DepartmentID() > 0) {
            $.ajax({
                url: pageName + "/RemoveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(item) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        self.allRecords.remove(item);
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    // Save Record in DB
    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {

            var len = viewModel.main().allRecords().length;
            if (len == 0 || (self.allRecords()[len - 1].DepartmentID() > 0)) {

                for (index = 0; index <= len - 1; index++) {
                    for (j = index + 1; j <= len - 1; j++) {
                        if (
                            viewModel.main().allRecords()[index].DepartmentID() == viewModel.main().allRecords()[j].DepartmentID()
                            ) {
                            NotifyMe('info|Record already exist');
                            return false;
                        }
                    }
                }
                self.allRecords.push(new BillingDepartmentModel(null));
            }
            else {
                NotifyMe('info|Please select required value.');
                return false;
            }
            //make some changes here,
            $.ajax({
                url: pageName + "/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().allRecords()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        var mod = new BillingDepartmentModel(data.d);
                        self.allRecords.unshift(mod);
                        self.editModel(new BillingDepartmentModel(null));
                        billingDepartmentID = null;
                        LoadRecord();
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.Reload = function () {
        LoadRecord();
    }
}

// Object Model class 
function BillingDepartmentModel(item) {
    var self = this;

    if (item != null) {
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
    }
    else {
        self.DepartmentID = ko.observable(null);
    }
    self.BillingDptID = ko.observable(ko.utils.unwrapObservable(billingDepartmentID));
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

//Load Record form DB
function LoadRecord() {
    $.ajax({
        url: pageName + "/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new BillingDepartmentModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function GetRecordsById(BillingDptID) {

    var vParameters = "{billingDptID : '" + BillingDptID + "'}";
    if (BillingDptID > 0) {
        $.ajax({
            url: pageName + "/GetRecordsById",
            type: 'POST',
            data: vParameters,
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d) {
                    viewModel.main(new wrapperModel(data.d));
                    viewModel.main().editModel(new BillingDepartmentModel(null));
                }
                else {
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
    } else {

    }
}