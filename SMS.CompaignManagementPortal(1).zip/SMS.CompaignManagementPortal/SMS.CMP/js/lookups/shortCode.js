﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var all_Organization = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};


function wrapperModel(item) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    if (item != null) {
        ref_all_rec = [];
        ko.utils.arrayForEach(item, function (Province) {
            self.allRecords.push(new ShortCodeModel(Province));
            ref_all_rec.push(new ShortCodeModel(Province));
        });

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {

       

        refModel = new ShortCodeModel(item);
        var mod = new ShortCodeModel(item);
        mod.allOrganization(all_Organization);
        //self.editModel(new ShortCodeModel(item));
        self.editModel(mod);
        self.allRecords.remove(item);
        self.isEdit(true);
    };

    self.cancelRecord = function () {
        var mod = new ShortCodeModel(item);
        mod.allOrganization(all_Organization);
        //self.editModel(new ShortCodeModel(null));
        self.editModel(mod);
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "ShortCode.aspx/RemoveRecord", //../../../../Layouts/PITB.FC/Lookups/District.aspx/RemoveDistrict
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                 if (NotifyMe(data.d.Notification)) {
                     item.IsActive(false);
                     LoadRecord();
                    //NotifyMe("inactivesuccess");
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        //}
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "ShortCode.aspx/SaveRecord", //../../../../Layouts/PITB.FC/Lookups/District.aspx/SaveDistrict
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                    if (data.d.ID > 0) {
                        var mod = new ShortCodeModel(data.d);
                        self.allRecords.unshift(mod);
                        self.editModel(new ShortCodeModel(null));
                        mod.allOrganization(all_Organization);
                        self.isEdit(false);
                        LoadRecord();
                        //NotifyMe("saverecordSuccess");
                    }
                   }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                if (item.Description != "") {
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.OrganizationTitle().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                }
                else
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }
}

function ShortCodeModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.IsActive = ko.observable(ko.utils.unwrapObservable(item.IsActive));
        self.OrganizationTitle = ko.observable(ko.utils.unwrapObservable(item.OrganizationTitle));
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
    }
    else {
        self.ID = ko.observable();
        self.Title = ko.observable();
        self.Description = ko.observable('');
        self.IsActive = ko.observable(true);
        self.OrganizationTitle = ko.observable('');
        self.OrganizationID = ko.observable();
    }

    self.allOrganization = ko.observableArray();
}

function organizationModel(model) {
    var self = this;
    self.ID = ko.observable(model.ID);
    self.Title = ko.observable(model.Title);

}
function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "ShortCode.aspx/GetRecord", //../../../../Layouts/PITB.FC/Lookups/District.aspx/GetAllDistricts
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d.ShortCodes));
                viewModel.main().editModel(new ShortCodeModel(null));

                if (data.d.Organizations != null) {
                    ko.utils.arrayForEach(data.d.Organizations, function (org) {
                        viewModel.main().editModel().allOrganization.push(new organizationModel(org));
                    });
                    all_Organization = viewModel.main().editModel().allOrganization();
                }
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new ShortCodeModel(null));
            }

        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}