﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.editModel = ko.observable();
    self.NetworksCodes = ko.observableArray();
    self.Campaigns = ko.observableArray();
    self.Organization = ko.observableArray();

    if (items.Campaign != null) {

        ko.utils.arrayForEach(items.Campaign, function (item) {
            self.Campaigns.push(new CommonModel(item));
        });
    }

    if (items.Organizations != null) {

        ko.utils.arrayForEach(items.Organizations, function (item) {
            self.Organization.push(new CommonModel(item));
        });
    }

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "SMSConfiguration.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.Status(false);
                    LoadRecord();
                    //NotifyMe("inactivesuccess");
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        //}
    };

}

function APIModel(item) {

    var self = this;

    if (item != null) {

        self.CampaignID = ko.observable(ko.utils.unwrapObservable(item.CampaignID));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.IPAddress = ko.observable(ko.utils.unwrapObservable(item.IPAddress));
    }
    else {

        self.CampaignID = ko.observable();
        self.OrganizationID = ko.observable();
        self.IPAddress = ko.observable();
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function CommonModel(item) {

    var self = this;
    self.ID = ko.observable(item.ID);
    self.Title = ko.observable(item.Title);
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "APIGenerating.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new APIModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new APIModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}
