﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        //ko.utils.registerEventHandler(element, "blur", function () {
        //    $(element).validationEngine('validate');
        //});
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        //var text = allBindingsAccessor().value || {};
        //if (text() != undefined) {
        //    $(element).validationEngine('validate');
        //}
    }
};

function wrapperModel(item) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    self.Organizations = ko.observableArray();
    self.ShortCodes = ko.observableArray();
    self.Departments = ko.observableArray();

    if (item != null) {

        if (item.Masks != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(item.Masks, function (item) {
                self.allRecords.push(new MaskModel(item));
                ref_all_rec.push(new MaskModel(item));
            });
        }

        if (item.Organizations != null) {

            ko.utils.arrayForEach(item.Organizations, function (item) {
                self.Organizations.push(new OrganizationModel(item));
            });
        }



        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {

        $.ajax({
            url: "Mask.aspx/GetShortCodes",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {

                if (data.d.ShortCodes != null) {
                    self.ShortCodes([]);
                    ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.ShortCodes), function (code) {
                        self.ShortCodes.push(new ShortCodeModel(code));
                    });
                }

                if (data.d.Departments != null) {
                    self.Departments([]);
                    ko.utils.arrayForEach(data.d.Departments, function (item) {
                        self.Departments.push(new DepartmentModel(item));
                    });
                }

                refModel = new MaskModel(item);
                var mod = new MaskModel(item);
                self.editModel(mod);
                self.editModel().SortCodeID(item.SortCodeID());
                self.editModel().DepartmentID(item.DepartmentID());
                self.allRecords.remove(item);
                self.isEdit(true);
            },
            error: function (request) {
                alert(Error);
            }
        });
    };

    self.cancelRecord = function () {
        self.editModel(new MaskModel(null));
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "Mask.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.Status(false);
                    LoadRecord();
                }
            },
            error: function (request) {
                alert(Error);
            }
        });
        //  }
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "Mask.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.ID > 0) {
                            LoadRecord();
                        }
                    }
                },
                error: function (request) {
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                if (item.Description != "") {
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Department().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.ShortCode().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Organization().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                }
                else
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }
}

function MaskModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.MaskID = ko.observable(ko.utils.unwrapObservable(item.MaskID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.OrganizationID = ko.observable(ko.utils.unwrapObservable(item.OrganizationID));
        self.SortCodeID = ko.observable(ko.utils.unwrapObservable(item.SortCodeID));
        self.ShortCode = ko.observable(ko.utils.unwrapObservable(item.ShortCode));
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.Department = ko.observable(ko.utils.unwrapObservable(item.Department));
        self.Organization = ko.observable(ko.utils.unwrapObservable(item.Organization));
    }
    else {
        self.ID = ko.observable();
        self.MaskID = ko.observable();
        self.Title = ko.observable();
        self.Description = ko.observable('');
        self.Status = ko.observable(true);
        self.OrganizationID = ko.observable();
        self.SortCodeID = ko.observable();
        self.ShortCode = ko.observable();
        self.DepartmentID = ko.observable();
        self.Department = ko.observable();
        self.Organization = ko.observable();
    }

    self.OrganizationID.subscribe(function (newValue) {

        $.ajax({
            url: "Mask.aspx/GetShortCodes",
            type: 'POST',
            data: "{organizationID : '" + ko.toJSON(newValue) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {

                if (data.d.ShortCodes != null) {
                    viewModel.main().ShortCodes([]);
                    ko.utils.arrayForEach(data.d.ShortCodes, function (item) {
                        viewModel.main().ShortCodes.push(new ShortCodeModel(item));
                    });
                }

                if (data.d.Departments != null) {
                    viewModel.main().Departments([]);
                    ko.utils.arrayForEach(data.d.Departments, function (item) {
                        viewModel.main().Departments.push(new DepartmentModel(item));
                    });
                }
            },
            error: function (request) {
            }
        });

    });
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function OrganizationModel(item) {
    var self = this;
    self.ID = ko.observable(item.ID);
    self.Title = ko.observable(item.Title);
}

function ShortCodeModel(item) {
    var self = this;
    self.ID = ko.observable(item.ID);
    self.Title = ko.observable(item.Title);
}

function DepartmentModel(item) {
    var self = this;
    self.ID = ko.observable(item.DepartmentID);
    self.Title = ko.observable(item.Title);
}


$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Mask.aspx/GetRecord",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {

            viewModel.main(new wrapperModel(data.d));
            viewModel.main().editModel(new MaskModel(null));
        },
        error: function (request) {
        }
    });
}