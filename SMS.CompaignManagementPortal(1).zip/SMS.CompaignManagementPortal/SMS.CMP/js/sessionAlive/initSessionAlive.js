﻿$(document).ready(function () {
    var SessionWarnInterval = 900000;           //15 minutes; 3000 - 3second
    var SessionRedirectInterval = 1200000;      //20 minutes; //30000 -- 3 second
    var KeepAliveInterval = 700000;

    $.sessionTimeout({
        message: 'Your session will be locked in one minute.',
        keepAliveUrl: '~/KeepSessionAlive.aspx/MaintainSession',
        logoutUrl: '../../KeepSessionAlive.aspx/Logout',
        redirUrl: '../../KeepSessionAlive.aspx/Logout',
        warnAfter: SessionWarnInterval,
        redirAfter: SessionRedirectInterval,
        keepAliveInterval: KeepAliveInterval
    });

    
});