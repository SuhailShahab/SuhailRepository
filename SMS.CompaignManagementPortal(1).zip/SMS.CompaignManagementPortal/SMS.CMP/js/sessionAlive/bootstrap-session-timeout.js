/*
 * bootstrap-session-timeout
 * www.orangehilldev.com
 *
 * Copyright (c) 2014 Vedran Opacic
 * Licensed under the MIT license.
 */

'use strict';

(function ($) {
    jQuery.sessionTimeout = function (options) {
        var defaults = {
            title: 'Your session is about to expire!',
            message: 'Your session is about to expire.',
            logoutButton: 'Logout',
            keepAliveButton: 'Stay Connected',
            keepAliveUrl: '/keep-alive',
            ajaxType: 'POST',
            ajaxData: '',
            redirUrl: '/timed-out',
            logoutUrl: '/log-out',
            warnAfter: 1800000,   // 15 minutes
            redirAfter:1200000,  // 20 minutes
            keepAliveInterval:600000,
            keepAlive: true,
            ignoreUserActivity: false,
            onWarn: false,
            onRedir: false
        };

        var opt = defaults,
            timer;

        // extend user-set options over defaults
        if (options) {
            opt = $.extend(defaults, options);
        }

        // some error handling if options are miss-configured
        if (opt.warnAfter >= opt.redirAfter) {
            // for IE8 and earlier
            if (typeof console !== "undefined" || typeof console.error !== "undefined") {
                console.error('Session-timeout plugin is miss-configured. Option "redirAfter" must be equal or greater than "warnAfter".');
            }
            return false;
        }

        // unless user set his own callback function, prepare bootstrap modal elements and events
        if (typeof opt.onWarn !== 'function') {
            // create timeout warning dialog
            //$('body').append('<div class="modal fade" id="sessionTimeout-dialog"> \
            //  <div class="modal-dialog"> \
            //    <div class="modal-content"> \
            //      <div class="modal-header"> \
            //        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> \
            //        <h4 class="modal-title">'+ opt.title +'</h4> \
            //      </div> \
            //      <div class="modal-body">'+ opt.message +'</div> \
            //      <div class="modal-footer"> \
            //        <button id="sessionTimeout-dialog-logout" type="button" class="btn btn-default">'+ opt.logoutButton +'</button> \
            //        <button id="sessionTimeout-dialog-keepalive" type="button" class="btn btn-primary" data-dismiss="modal">'+ opt.keepAliveButton +'</button> \
            //      </div> \
            //    </div> \
            //  </div> \
            // </div>');

            $('body').append('<div id="sessionTimeout-dialog" class="overlay-area hidden"><div class="overlay-area-inner"><h1>' + opt.title + '</h1><h4>' + opt.message + '</h4><a id="sessionTimeout-dialog-logout" style="width: 125px;" class="btn btn-danger"><i class="fa fa-sign-out"></i>&nbsp;&nbsp;' + opt.logoutButton + '</a>&nbsp;<a id="sessionTimeout-dialog-connected" style="width: 125px;" class="btn btn-success"><i class="fa fa-link"></i>&nbsp;&nbsp;' + opt.keepAliveButton + '</a></div></div>');

            // "Logout" button click
            $('#sessionTimeout-dialog-logout').on('click', function () { alert(opt.logoutUrl);window.location = opt.logoutUrl; });
            // "Stay Connected" button click
            $('#sessionTimeout-dialog-connected').on('click', function () {
                // restart session timer
                startSessionTimer();
                $('#sessionTimeout-dialog').addClass('hidden');
                
            });
        }

        // reset timer on any of these events
        if (!opt.ignoreUserActivity) {
            $(document).on('keyup mouseup mousemove touchend touchmove', function () {
                startSessionTimer();
            });
        }

        // keeps the server side connection live, by pingin url set in keepAliveUrl option
        // keepAlivePinged is a helper var to ensure the functionality of the keepAliveInterval option
        var keepAlivePinged = false;
        function keepAlive() {
            if (!keepAlivePinged) {
                $.ajax({
                    type: opt.ajaxType,
                    url: opt.keepAliveUrl,
                    data: opt.ajaxData
                });
                keepAlivePinged = true;
                setTimeout(function () {
                    keepAlivePinged = false;
                }, opt.keepAliveInterval);
            }
        }

        function startSessionTimer() {
            // console.log('startSessionTimer()');
            // clear session timer
            clearTimeout(timer);

            // if keepAlive option is set to "true", ping the "keepAliveUrl" url
            if (opt.keepAlive) {
                keepAlive();
            }

            // set session timer 
            timer = setTimeout(function () {
                // check for onWarn callback function and if there is none, launch dialog
                if (typeof opt.onWarn !== 'function') {
                    $('#sessionTimeout-dialog').removeClass('hidden');
                }
                else {
                    opt.onWarn('warn');
                }
                // start dialog timer
                startDialogTimer();
            }, opt.warnAfter);
        }

        function startDialogTimer() {
            // console.log('startDialogTimer()');
            // clear session timer
            clearTimeout(timer);

            // set dialog timer 
            timer = setTimeout(function () {
                // check for onRedir callback function and if there is none, launch redirect
                if (typeof opt.onRedir !== 'function') {
                    startDialogTimer('start');
                   // alert('Your session have been expired');
                    window.location = opt.redirUrl;
                }
                else {
                    opt.onRedir();
                }
            }, (opt.redirAfter - opt.warnAfter));
        }

        // start session timer
        startSessionTimer();
    };
})(jQuery);


