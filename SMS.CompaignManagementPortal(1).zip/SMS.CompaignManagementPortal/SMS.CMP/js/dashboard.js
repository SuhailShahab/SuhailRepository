﻿var viewModel = new ViewModel();
var all_organization = [];
var all_departments = [];
//var all_campaigns = [];

function wrapperModel(items) {
    var self = this;
    self.Dashboard = ko.observableArray();
    self.Organizations = ko.observableArray();
    self.OrganizationID = ko.observable();
    self.Departments = ko.observableArray();
    self.DepartmentID = ko.observable();
    //self.Campaigns = ko.observableArray();
    //self.CampaignID = ko.observable();
    self.UserOrganizationID = ko.observable();
    self.UserDepartmentID = ko.observable();

    if (items.Dashboard != null) {
        ko.utils.arrayForEach(items.Dashboard, function (dashboard) {
            self.Dashboard.push(new DashboardModel(dashboard));
        });
    }
    if (items.Organizations != null) {
        ko.utils.arrayForEach(items.Organizations, function (item) {
            self.Organizations.push(new CommonModel(item));
            all_organization.push(new CommonModel(item));
        });
    }
    else
    {
        self.Organizations(all_organization);
    }
    if (items.Departments != null) {
        ko.utils.arrayForEach(items.Departments, function (item) {
            self.Departments.push(new CommonModel(item));
        });
    }
    //if (items.Campaigns != null) {
    //    ko.utils.arrayForEach(items.Campaigns, function (item) {
    //        self.Campaigns.push(new CommonModel(item));
    //    });
    //}

    if (items.UserDepartmentID != null)
    {
        self.UserDepartmentID(items.UserDepartmentID);
    }
    if (items.UserOrganizationID != null) {
        self.UserOrganizationID(items.UserOrganizationID);
    }

    self.getDepartments = function (item) {
        if (item.OrganizationID() != undefined) {
            $.ajax({
                url: "Dashboard.aspx/GetDepartments",
                type: 'POST',
                data: "{organizationID : '" + ko.toJSON(item.OrganizationID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d != null) {
                            self.Departments([]);
                            if (all_departments != null)
                            {
                                all_departments = [];
                            }
                            if (data.d.Departments != null)
                            ko.utils.arrayForEach(data.d.Departments, function (dept) {
                                self.Departments.push(new CommonModel(dept));
                                all_departments.push(new CommonModel(dept));
                            });
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
        else
            self.Departments([]);
    }
    //self.getCampaign = function (item) {
    //    if (item.DepartmentID() != undefined) {
    //        $.ajax({
    //            url: "Dashboard.aspx/GetCampaign",
    //            type: 'POST',
    //            data: "{departmentID : '" + ko.toJSON(item.DepartmentID()) + "'}",
    //            dataType: "json",
    //            contentType: "application/json; charset=utf-8",
    //            success: function (data) {
    //                if (NotifyMe(data.d.Notification)) {
    //                    if (data.d != null  ) {
    //                        self.Campaigns([]);
    //                        if (all_campaigns != null) {
    //                            all_campaigns = [];
    //                        }
    //                        if (data.d.Campaigns != null)
    //                        ko.utils.arrayForEach(data.d.Campaigns, function (camp) {
    //                            self.Campaigns.push(new CommonModel(camp));
    //                            all_campaigns.push(new CommonModel(camp));
    //                        });
    //                    }
    //                }
    //            },
    //            error: function (er, _rr) {
    //                NotifyMe("error|" + er.statusText);
    //            }
    //        });
    //    }
    //}
    self.getDashboard = function (item) {
        LoadRecordByFilter(ko.utils.unwrapObservable(self.OrganizationID()), ko.utils.unwrapObservable(self.DepartmentID()));
    };
}

function DashboardModel(item) {
    var self = this;
    //self.editModel = ko.observable();
    
    if (item != null) {
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Url = ko.observable(ko.utils.unwrapObservable(item.URL));
        self.Counts = ko.observable(ko.utils.unwrapObservable(item.Counts));
        self.Style = ko.observable(ko.utils.unwrapObservable(item.Style));
        self.Icon = ko.observable(ko.utils.unwrapObservable(item.Icon));
    }
    else {
        self.Title = ko.observable();
        self.Url = ko.observable('#');
        self.Counts = ko.observable();
        self.Style = ko.observable();
        self.Icon = ko.observable();
        
    }
}

function CommonModel(org) {
    var self = this;
    self.ID = ko.observable(org.ID);
    self.Title = ko.observable(org.Title);
}



function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Dashboard.aspx/GetRecord",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new wrapperModel(data.d));
            
        },
        error: function (request) {
        }
    });
}

function LoadRecordByFilter(organizationID, departmentID) {
    $.ajax({
        url: "Dashboard.aspx/GetRecordByFilter",
        type: 'POST',
        data: "{organizationID : '" + ko.toJSON(organizationID) + "', departmentID : '" + ko.toJSON(departmentID) + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new wrapperModel(data.d)); 

            viewModel.main().OrganizationID(organizationID);
            viewModel.main().Departments(all_departments);
            viewModel.main().DepartmentID(departmentID);
        },
        error: function (request) {
        }
    });
}
