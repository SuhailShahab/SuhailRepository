﻿using ApplicationClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP
{
    public partial class Error : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

      
        protected void HomeButton_Click(object sender, EventArgs e)
        {
            string url = string.Empty;
            if (CurrentUser.LoginID.HasValue)
            {
                url = "~/ContentPages/Dashboard.aspx";
            }
            else
            {
                url = "~/Login.aspx";
            }
            Response.Redirect(url, false);
        }
    }
}