﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    public partial class Group : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        /// <summary>
        /// Save group information
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns>Added GroupID as integer</returns>
        [WebMethod]
        public static GroupModel SaveRecord(string jsonModel)
        {
            int result = 0;
            GroupModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<GroupModel>(jsonModel);

                model.CreatedBy =0;

                result = new GroupBLL().Save(model);

                if (model.ID == 0)
                {
                    model.ID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }

            }
            catch (BusinessException ex)
            {
                model = new GroupModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Group, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Group, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new GroupModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new GroupModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get all groups
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static GroupModelModelView GetRecords()
        {
            GroupModelModelView model = new GroupModelModelView();

            List<GroupModel> groups = null;

            try
            {
                groups = new GroupBLL().GetGroup();
                if (groups != null && groups.Count > 0)
                    model.Groups = groups;
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Group, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Group, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new GroupModelModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new GroupModelModelView("error|" + ex.Message);
                }

            }

            return model;
        }

        /// <summary>
        /// Delete existing group against provider group
        /// </summary>
        /// <param name="jsonModel"></param>
        [WebMethod]
        public static GroupModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            GroupModel model = null;

            try
            {
                 model = new JavaScriptSerializer().Deserialize<GroupModel>(jsonModel);
                model.CreatedBy = 0;
                result = new GroupBLL().Delete(model.ID, model.CreatedBy.Value);

                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);

                
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Group, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Group, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new GroupModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new GroupModel("error|" + ex.Message);
                }
            }
            return model;
        }

        #endregion
    }
}