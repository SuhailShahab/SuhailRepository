﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using SMS.CMP.BE.LookUps;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    public partial class Status : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
       
        #region "Web Methods"

        [WebMethod]
        public static StatusModel SaveRecord(string jsonModel)
        {
            int result = 0;
            StatusModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<StatusModel>(jsonModel);
                result = new StatusBLL().Save(model);
                if (result > 0)
                {
                    model.ID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }
            }
            catch (BusinessException ex)
            {
                model = new StatusModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Status, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Status, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new StatusModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new StatusModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static StatusModelView GetRecord()
        {
            StatusModelView modelView = new StatusModelView();
            List<StatusModel> Statuses = null;

            try
            {
                Statuses = new StatusBLL().GetAllStatuses();
                if (Statuses != null && Statuses.Count > 0)
                {
                    modelView.Statuses=Statuses;
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Status, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(modelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Status, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new StatusModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new StatusModelView("error|" + ex.Message);
                }
            }

            return modelView;
        }

        [WebMethod]
        public static StatusModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            StatusModel model = null;
            try
            {
                StatusModel statusModel = new JavaScriptSerializer().Deserialize<StatusModel>(jsonModel);
                result = new StatusBLL().Delete(statusModel);
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Status, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Status, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new StatusModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new StatusModel("error|" + ex.Message);
                }
            }
            return model;

        }

        #endregion
    }
}