﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.Lookups;
using PITB.PFSA.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    public partial class ErrorLog : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static ErrorLogModelView GetRecords(string ErrorLogModel)
        {
            ErrorLogModelView modelView = new ErrorLogModelView();
            try
            {
                List<ErrorLogModel> ErrorLogs = new List<ErrorLogModel>();
                ErrorLogModel model = new ErrorLogModel();
                
                if (ErrorLogModel != "undefined")
                    model = new JavaScriptSerializer().Deserialize<ErrorLogModel>(ErrorLogModel);
                              
                ErrorLogs = new ErrorLogBLL().GetErrorLogs(model);

                if (ErrorLogs != null && ErrorLogs.Count > 0)
                    modelView.ErrorLogs = ErrorLogs;

                List<PageNameModel> Pages = new PageNameBLL().GetPages();

                modelView.PageNames = Pages;

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ErrorLog, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(modelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ErrorLog, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new ErrorLogModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new ErrorLogModelView("error|" + ex.Message);
                }
            }
            return modelView;
        }

        [WebMethod]
        public static ErrorLogModelView GetRecordsBySearchCreiteria(string jsonModel, string searchByID, string searchByMessage)
        {
            ErrorLogModelView modelView = new ErrorLogModelView();

            try
            {
                List<ErrorLogModel> ErrorLogs = new List<ErrorLogModel>();
                ErrorLogModel model = new ErrorLogModel();

                int SearchByID = 0; string SearchByMessage = null;
                if (searchByID != "" && searchByID != null && searchByID != "undefined")
                    SearchByID = Convert.ToInt32(searchByID);
                if (searchByMessage != "" && searchByMessage != null)
                    SearchByMessage = (searchByMessage);

                if (jsonModel != "undefined")
                    model = new JavaScriptSerializer().Deserialize<ErrorLogModel>(jsonModel);


                // Get records based on filter
                List<ErrorLogModel> LogErrorsList = new ErrorLogBLL().GetErrorLogsBySearchCretira(SearchByID, SearchByMessage);
                if (LogErrorsList != null && LogErrorsList.Count > 0)
                    modelView.ErrorLogs = LogErrorsList;




            }
            catch (Exception ex)
            {
               // new Common().AddErrorLog(new ErrorLogModel(ex, "GetRecordsBySearchCreiteria", PageNames.ErrorLog, CurrentUser.GetSessionUserInfo().ToString()));
                //model = new ADPFormulationPlanModelView("error|" + ex.Message);
                
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordsBySearchCreiteria", 1, PageNames.ErrorLog, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new ErrorLogModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new ErrorLogModelView("error|" + ex.Message);
                }

            }

            return modelView;
        }

    }
}