﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    // Created by:	<Muhammad Shakeel>
    // Created date: <22-03-2018>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public partial class BillingDepartment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static BillingDepartmentModel SaveRecord(string jsonModel)
        {
            int? result = 0;
            int? userID = null;
            BillingDepartmentModel billingModel = new BillingDepartmentModel();
            List<BillingDepartmentModel> model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<List<BillingDepartmentModel>>(jsonModel);
                userID = CurrentUser.LoginID;

                result = new BillingDepartmentBLL().Save(model, userID);

                if (result.HasValue && result.Value > 0)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(billingModel, CutomMessage.SavedSuccessfully);
                }
            }
            catch (BusinessException ex)
            {
                billingModel = new BillingDepartmentModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.BillingDepartment, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    billingModel = new BillingDepartmentModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    billingModel = new BillingDepartmentModel("error|" + ex.Message);
                }
            }

            return billingModel;
        }

        [WebMethod]
        public static BillingDepartmentModelView GetRecords()
        {
            BillingDepartmentModelView model = new BillingDepartmentModelView();
            try
            {
                List<DepartmentsModel> departments = new DepartmentsBLL().GetDepartments().Where(w => w.Status == true).ToList();

                if (departments != null && departments.Count > 0)
                    model.Departments = departments;

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.BillingDepartment, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new BillingDepartmentModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new BillingDepartmentModelView("error|" + ex.Message);
                }

            }

            return model;
        }

        [WebMethod]
        public static BillingDepartmentModelView GetRecordsById(string billingDptID)
        {
            BillingDepartmentModelView model = new BillingDepartmentModelView();
            try
            {
                int vBillingDptID = new JavaScriptSerializer().Deserialize<int>(billingDptID);
                List<DepartmentsModel> departments = new DepartmentsBLL().GetDepartmentsByBillingDptID(vBillingDptID);

                if (departments != null && departments.Count > 0)
                    model.DepartmentsByBilling = departments;

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.BillingDepartment, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new BillingDepartmentModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new BillingDepartmentModelView("error|" + ex.Message);
                }

            }

            return model;
        }

        [WebMethod]
        public static BillingDepartmentModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            BillingDepartmentModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<BillingDepartmentModel>(jsonModel);
                result = new BillingDepartmentBLL().Delete(model);

                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.DeletedSuccessfully);


            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.BillingDepartment, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new BillingDepartmentModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new BillingDepartmentModel("error|" + ex.Message);
                }
            }
            return model;
        }

        #endregion
    }
}