﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups 
{
    public partial class Organization : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #region "Web Methods"

        [WebMethod]
        public static OrganizationModel SaveRecord(string jsonModel)
        {
            int result = 0;
            OrganizationModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<OrganizationModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;
                result = new OrganizationBLL().Save(model);
                if (result > 0)
                {
                    model.ID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }
            }
            catch (BusinessException ex)
            {
                model = new OrganizationModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecords", 1, PageNames.Organization, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecords", 1, PageNames.Organization, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new OrganizationModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new OrganizationModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static OrganizationModelView GetRecords()
        {
            OrganizationModelView models = new OrganizationModelView();
            List<OrganizationModel> organizations = null;

            try
            {
                organizations = new OrganizationBLL().GetALLOrganizations();
                if (organizations != null && organizations.Count > 0)
                    models.Organizations = organizations;

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Organization, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(models, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Organization, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    models = new OrganizationModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    models = new OrganizationModelView("error|" + ex.Message);
                }
            }
           return models;
        }

        [WebMethod]
        public static OrganizationModel RemoveRecord(string jsonModel)
        {
           
            OrganizationModel model = null;
            try
            {
                 model = new JavaScriptSerializer().Deserialize<OrganizationModel>(jsonModel);
                int savedResult = new OrganizationBLL().Delete(model.ID.Value, 0);
              // return (savedResult > 0 ? "true" : "Record is not deleted.");
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Organization, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Organization, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new OrganizationModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new OrganizationModel("error|" + ex.Message);
                }
            }
            return model;
            //TODO: return value or message for integation   
        }

        #endregion
    }
}