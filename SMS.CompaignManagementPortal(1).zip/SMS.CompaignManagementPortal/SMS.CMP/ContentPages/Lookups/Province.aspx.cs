﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    public partial class Province : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #region "Web Methods"

        [WebMethod]
        public static ProvinceModel SaveRecord(string jsonModel)
        {
            int result = 0;
            ProvinceModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<ProvinceModel>(jsonModel);
                result = new ProvinceBLL().Save(model);
                if (result > 0)
                {
                    model.ID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }
            }
            catch (BusinessException ex)
            {
                model = new ProvinceModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Province, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Province, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ProvinceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ProvinceModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static ProvinceModelView GetRecord()
        {

            ProvinceModelView modelView = new ProvinceModelView();

            List<ProvinceModel> Provinces = null;

            try
            {
                Provinces = new ProvinceBLL().GetAllProvinces();
                if (Provinces != null && Provinces.Count > 0)
                {
                    modelView.Provinces = Provinces;
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Province, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(modelView, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Province, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new ProvinceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new ProvinceModelView("error|" + ex.Message);
                }
            }

            return modelView;
        }

        [WebMethod]
        public static ProvinceModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            ProvinceModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<ProvinceModel>(jsonModel);
                result = new ProvinceBLL().Delete(model.ID);
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);
                // return (result.HasValue && result.Value > -1 ? "true" : "false");
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Province, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Province, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ProvinceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ProvinceModel("error|" + ex.Message);
                }
            }

            return model;

        }

        #endregion
    }
}