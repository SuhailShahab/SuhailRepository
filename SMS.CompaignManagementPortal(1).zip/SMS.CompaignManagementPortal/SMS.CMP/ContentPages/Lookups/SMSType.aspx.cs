﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    public partial class SMSType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static SMSTypesModel SaveRecord(string jsonModel)
        {
            int result = 0;
            SMSTypesModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<SMSTypesModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;
                result = new SMSTypeBLL().Save(model);
                if (result > 0)
                {
                    model.SMSTypeID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }
            }
            catch (BusinessException ex)
            {
                model = new SMSTypesModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SMSType, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SMSType, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSTypesModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSTypesModel("error|" + ex.Message);
                }
            }

            return model;

        }

        [WebMethod]
        public static SMSTypeModelView GetRecords()
        {

            SMSTypeModelView modelView = new SMSTypeModelView();

            List<SMSTypesModel> model = null;

            try
            {
                model = new SMSTypeBLL().GetSMSTypes();
                if (model != null && model.Count > 0)
                    modelView.SMSTypes = model;
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.SMSType, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(modelView, ex.Message);


                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.SMSType, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new SMSTypeModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new SMSTypeModelView("error|" + ex.Message);
                }
            }

            return modelView;
        }


        [WebMethod]
        public static SMSTypesModel RemoveRecord(string jsonModel)
        {
            string result;
            SMSTypesModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<SMSTypesModel>(jsonModel);
                int savedResult = new SMSTypeBLL().Delete(model.SMSTypeID.Value);
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.SMSType, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.SMSType, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSTypesModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSTypesModel("error|" + ex.Message);
                }
            }
            return model;
        }
    }
}