﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{

    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <16-10-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // =================================================================================================================================
    public partial class Mask : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        /// <summary>
        ///  Save mask Information
        /// </summary>
        /// <param name="jsonModel">Model Jason string</param>
        /// <returns></returns>
        [WebMethod]
        public static MaskModel SaveRecord(string jsonModel)
        {
            int result = 0;
            MaskModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<MaskModel>(jsonModel);

                result = new MaskBLL().Save(model);


                if (result > 0)
                {
                    model.ID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, CutomMessage.DuplicateTitle);
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Mask, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Mask, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new MaskModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new MaskModel("error|" + ex.Message);
                }
            }
            return model;
        }

        /// <summary>
        /// Get Mask record from Model
        /// </summary>
        /// <returns>Mask List</returns>
        [WebMethod]
        public static MaskModelView GetRecord()
        {
            List<MaskModel> model = null;
            MaskModelView modelView = new MaskModelView();
            try
            {
                model = new MaskBLL().GetAllMasks();
                if (model != null && model.Count > 0)
                    modelView.Masks = model;


                List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));

                if (organizations != null && organizations.Count > 0)
                    modelView.Organizations = organizations;

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Mask, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(modelView, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Mask, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new MaskModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new MaskModelView("error|" + ex.Message);
                }
            }

            return modelView;
        }

        /// <summary>
        /// get ShortCodes By Organization ID
        /// </summary>
        /// <param name="organizationID"> Selected Organizaiton ID</param>
        /// <returns>Department List</returns>
        [WebMethod]
        public static MaskModelView GetShortCodes(string organizationID)
        {

            MaskModelView model = new MaskModelView();
            try
            {

                List<ShortCodeModel> lstShortCode = new ShortCodeBLL().GetShortCodesByOrganizationID(Convert.ToInt32(organizationID));
                List<DepartmentsModel> lstDepartments = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(organizationID));

                if (lstShortCode != null && lstShortCode.Count > 0)
                {
                    model.ShortCodes = lstShortCode;
                }
                if (lstDepartments != null && lstDepartments.Count > 0)
                {
                    model.Departments = lstDepartments;
                }

                return model;
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetShortCodes", 0, PageNames.Mask, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetShortCodes", 1, PageNames.Mask, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new MaskModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new MaskModelView("error|" + ex.Message);
                }
            }
            return model;
        }

        /// <summary>
        /// Remove Mask Record
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static MaskModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            MaskModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<MaskModel>(jsonModel);
                model.Status = false;
                result = new MaskBLL().Delete(model);
                // return (result.HasValue && result.Value > -1 ? "true" : "false");
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Division, 1));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Mask, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new MaskModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new MaskModel("error|" + ex.Message);
                }
            }
            return model;
            //TODO: return value or message for integation   
        }

        #endregion
    }
}