﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using SMS.CMP.BE.Lookups;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    public partial class ShortCode : System.Web.UI.Page
    {
        /// <summary>
        /// Page Load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        /// <summary>
        /// Saving Record [Web Method]
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static ShortCodeModel SaveRecord(string jsonModel)
        {
            int result = 0;
            ShortCodeModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<ShortCodeModel>(jsonModel);
                
                model.CreatedBy = CurrentUser.LoginID.Value;                

                result = new ShortCodeBLL().Save(model);
                if (result > 0)
                {
                    model.ID = result;
                  
                }
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (BusinessException ex)
            {
                model = new ShortCodeModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ShortCode, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ShortCode, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ShortCodeModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ShortCodeModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get Records
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static ShortCodeModelView GetRecord()
        {
            ///View Model Declaration
            ShortCodeModelView shortCodeModelView = new ShortCodeModelView();

            try
            {
                List<ShortCodeModel> shortCodes = new ShortCodeBLL().GetAllShortCodes();

                if (shortCodes != null && shortCodes.Count > 0)
                {
                    shortCodeModelView.ShortCodes = shortCodes;
                }

                List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));

                if (organizations != null && organizations.Count > 0)
                {
                    shortCodeModelView.Organizations = organizations;
                }

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ShortCode, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(shortCodeModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ShortCode, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    shortCodeModelView = new ShortCodeModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    shortCodeModelView = new ShortCodeModelView("error|" + ex.Message);
                }
            }

            return shortCodeModelView;

        }

        /// <summary>
        /// disable short code
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static ShortCodeModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            ShortCodeModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<ShortCodeModel>(jsonModel);
                result = new ShortCodeBLL().Delete(model);
              
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.ShortCode, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);


                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.ShortCode, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ShortCodeModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ShortCodeModel("error|" + ex.Message);
                }
            }
            return model;

        }

        #endregion
    }
}