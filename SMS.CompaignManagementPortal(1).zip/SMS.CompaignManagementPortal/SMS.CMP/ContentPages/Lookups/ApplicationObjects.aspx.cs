﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.RightsManager;
using SMS.CMP.BE.CustomEnums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    public partial class ApplicationObjects : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #region "Web Methods"

        [WebMethod]
        public static ApplicationObjectsModel SaveRecord(string jsonModel)
        {

            int result = 0;
            ApplicationObjectsModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<ApplicationObjectsModel>(jsonModel);

                model.CreatedBy = CurrentUser.LoginID;

                result = new ApplicationObjectsBLL().Save(model);
                if (model.ID == 0)
                {
                    model.ID = result;

                   
                }
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (BusinessException ex)
            {
                model = new ApplicationObjectsModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {

                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ApplicationObjectsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ApplicationObjectsModel("error|" + ex.Message);
                }
            }

            return model;
        }


        [WebMethod]
        public static ApplicationObjectsModelView GetRecords()
        {
            List<ApplicationObjectsModel> applicationObjectes = null;
            List<FeaturesModel> features = null;
            ApplicationObjectsModelView applicationObjectsModelView = new ApplicationObjectsModelView();

            try
            {
                applicationObjectes = new ApplicationObjectsBLL().GetAppObject();
                features = new FeatureBLL().GetFeatures();

                features = features.Where(p => p.menuLocation == MenuTypeNames.MainMenu.GetHashCode()).ToList();

                if (applicationObjectes != null && applicationObjectes.Count > 0)
                    applicationObjectsModelView.ApplicationObjectes = applicationObjectes;

                if (features != null && features.Count > 0)

                    //features.GetEnumerator().
                    applicationObjectsModelView.Features = features;
                applicationObjectsModelView.IsAdmin = false;

                return applicationObjectsModelView;
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(applicationObjectsModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    applicationObjectsModelView = new ApplicationObjectsModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    applicationObjectsModelView = new ApplicationObjectsModelView("error|" + ex.Message);
                }
            }

            return applicationObjectsModelView;
        }

        #endregion
        
    }
}