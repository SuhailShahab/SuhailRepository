﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    public partial class Department : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static DepartmentsModel SaveRecord(string jsonModel)
        {
            int? result = null;
            DepartmentsModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<DepartmentsModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;
                result = new DepartmentsBLL().Save(model);
                if (result > 0)
                {
                    model.DepartmentID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }
            }
            catch (BusinessException ex)
            {
                model = new DepartmentsModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Department, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Department, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DepartmentsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DepartmentsModel("error|" + ex.Message);
                }
            }
            return model;
        }

        [WebMethod]
        public static DepartmentsModelView GetRecords()
        {
            DepartmentsModelView modelView = new DepartmentsModelView();

            try
            {
                // Fill Model
                List<DepartmentsModel> departments = new DepartmentsBLL().GetDepartments().OrderBy(o => o.ID).ToList();

                List<OrganizationModel> organizations = new OrganizationBLL().GetOrganizations();

                if (departments != null && departments.Count > 0)
                {
                    modelView.Departments = departments;
                }

                if (organizations != null && organizations.Count > 0)
                    modelView.Organizations = organizations;

                // return modelView;
            }

            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Department, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(modelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Department, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new DepartmentsModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new DepartmentsModelView("error|" + ex.Message);
                }
            }

            return modelView;
        }

        [WebMethod]
        public static DepartmentsModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            DepartmentsModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<DepartmentsModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;

                result = new DepartmentsBLL().Delete(model.DepartmentID.Value);
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Department, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Department, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DepartmentsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DepartmentsModel("error|" + ex.Message);
                }
            }
            return model;
        }


        #endregion
    }
}