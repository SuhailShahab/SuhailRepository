﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Lookups
{
    public partial class Division : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static DivisionModel SaveRecord(string jsonModel)
        {
            int? result = null;
            DivisionModel divisionModel = null;

            try
            {
                divisionModel = new JavaScriptSerializer().Deserialize<DivisionModel>(jsonModel);

                divisionModel.CreatedBy = 0;
                result = new DivisionBLL().Save(divisionModel);
                if (divisionModel != null)
                {
                    divisionModel.ID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(divisionModel, CutomMessage.SavedSuccessfully);
                }
            }
            catch (BusinessException ex)
            {
                divisionModel = new DivisionModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Division, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(divisionModel, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Division, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    divisionModel = new DivisionModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    divisionModel = new DivisionModel("error|" + ex.Message);
                }

            }

            return divisionModel;
        }

        [WebMethod]
        public static DivisionViewModel GetRecords()
        {

            DivisionViewModel model = new DivisionViewModel();
            try
            {
                model.Divisions = new DivisionBLL().GetDivision();
                model.Provinces = new ProvinceBLL().GetAllActiveProvinces();
                //if (divisions != null && divisions.Count > 0)
                //    return divisions.ToArray();
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Division, CurrentUser.LoginID));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Division, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DivisionViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DivisionViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static DivisionModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            DivisionModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<DivisionModel>(jsonModel);
                model.CreatedBy = 0;

                result = new DivisionBLL().Delete(model.ID.Value, model.CreatedBy.Value);

                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Division, CurrentUser.LoginID));
                LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
            }

            return model;
        }

        #endregion
    }
}