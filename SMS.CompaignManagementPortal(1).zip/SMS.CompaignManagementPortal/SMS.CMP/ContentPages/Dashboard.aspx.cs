﻿
using ApplicationClasses;
using SMS.CMP.BE.Dashboard;
using SMS.CMP.BLL.Dashboard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using BE.Lookups;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using BLL.Common;
using BE.CustomEnums;

namespace SMS.CMP.ContentPages
{
    public partial class Dashboard : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #region "old GetRecord"
        /*
        [WebMethod]
        public static DashboardViewModel GetRecord()
        {
            DashboardViewModel dashboardModelView = new DashboardViewModel();
            try
            {
                List<DashboardModel> listDashboardModel = new List<DashboardModel>();
                DashboardModel model = new DashboardModel();
                model.OrganizationID = CurrentUser.OrganizationID;
                model.DepartmentID = CurrentUser.DepartmentID;
                model.UserID = CurrentUser.LoginID;
                listDashboardModel = new DashboardBLL().GetAllDashboardRecords(model).OrderBy(p => p.RowNo).ToList();

                if (listDashboardModel != null && listDashboardModel.Count > 0)
                {
                    dashboardModelView.Dashboard = new List<DashboardModel>();
                    dashboardModelView.Dashboard = listDashboardModel;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return dashboardModelView;
        }
         */
        #endregion

        #region "Web Methods"

        [WebMethod]
        public static DashboardViewModel GetRecord()
        {
            DashboardViewModel dashboardModelView = new DashboardViewModel();
            try
            {
               // List<DashboardModel> listDashboardModel = new List<DashboardModel>();
                List<DashboardModel> listDashboardModel = null;
                if(CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    DashboardModel model = new DashboardModel();
                    model.OrganizationID = CurrentUser.OrganizationID;
                    model.DepartmentID = CurrentUser.DepartmentID;
                    model.UserID = CurrentUser.LoginID;
                    listDashboardModel = LazySingletonBLL<DashboardBLL>.Instance.GetAllDashboardRecords(model).OrderBy(p => p.RowNo).ToList();

                    if (listDashboardModel != null && listDashboardModel.Count > 0)
                    {
                        //dashboardModelView.Dashboard = new List<DashboardModel>();
                        dashboardModelView.Dashboard = listDashboardModel;
                    }
                }

                List<OrganizationModel> listOrganizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(CurrentUser.LoginID.Value);
                if (listOrganizations != null && listOrganizations.Count > 0)
                {
                    dashboardModelView.Organizations = listOrganizations;
                }
                dashboardModelView.UserDepartmentID = CurrentUser.DepartmentID;
                dashboardModelView.UserOrganizationID = CurrentUser.OrganizationID;
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.SMS_PortalService, 0));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(dashboardModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ShortCode, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    dashboardModelView = new DashboardViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    dashboardModelView = new DashboardViewModel("error|" + ex.Message);
                }
            }
            return dashboardModelView;
        }

        [WebMethod]
        public static DashboardViewModel GetRecordByFilter(string organizationID, string departmentID)
        {
            DashboardViewModel dashboardModelView = new DashboardViewModel();
            try
            {
                List<DashboardModel> listDashboardModel = new List<DashboardModel>();
                DashboardModel model = new DashboardModel();
                if (!string.IsNullOrEmpty(organizationID) && organizationID != "null" && organizationID != "undefined")
                    model.OrganizationID = Convert.ToInt32(organizationID);
                else if (CurrentUser.OrganizationID.HasValue)
                    model.OrganizationID = CurrentUser.OrganizationID;                  
                    
                if (!string.IsNullOrEmpty(departmentID) && departmentID != "null" && departmentID != "undefined")
                    model.DepartmentID = Convert.ToInt32(departmentID);
                else if (CurrentUser.DepartmentID.HasValue)
                    model.DepartmentID = CurrentUser.DepartmentID;
                
                    model.UserID = CurrentUser.LoginID;
                    listDashboardModel = LazySingletonBLL<DashboardBLL>.Instance.GetAllDashboardRecords(model).OrderBy(p => p.RowNo).ToList();

                    if (listDashboardModel != null && listDashboardModel.Count > 0)
                    {
                        //dashboardModelView.Dashboard = new List<DashboardModel>();
                        dashboardModelView.Dashboard = listDashboardModel;
                    }
            }
            catch (Exception ex)
            {               
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordByFilter", 1, PageNames.SMS_PortalService, 0));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(dashboardModelView, "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(dashboardModelView, ex.Message);
                }
            }
            return dashboardModelView;
        }

        [WebMethod]
        public static DashboardViewModel GetDepartments(string organizationID)
        {
            DashboardViewModel dashboardModelView = new DashboardViewModel();

            List<DepartmentsModel> departments = null;
            try
            {
                departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDeptByOrganizationID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
               

                if (departments != null && departments.Count > 0)
                    dashboardModelView.Departments = departments;
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.SMS_PortalService, 0));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(dashboardModelView, "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(dashboardModelView, ex.Message);
                }
            }
            return dashboardModelView;
        }
        //[WebMethod]
        //public static DashboardViewModel GetCampaign(string departmentID)
        //{
        //    DashboardViewModel dashboardModelView = new DashboardViewModel();

        //    List<SMSCampaignModel> campainsList = null;
        //    try
        //    {
        //        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaignsByDeptID(Convert.ToInt32(departmentID));
        //        if (campainsList != null && campainsList.Count > 0)
        //            dashboardModelView.Campaigns = campainsList;
        //    }
        //    catch (Exception ex)
        //    {
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, ex.Message, 1, PageNames.SMS_PortalService, 0));
        //        throw ex;
        //    }
        //    return dashboardModelView;
        //}
        #endregion
    }
}