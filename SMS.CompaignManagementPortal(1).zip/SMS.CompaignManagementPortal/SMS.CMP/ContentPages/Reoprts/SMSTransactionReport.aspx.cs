﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using Microsoft.Reporting.WebForms;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.CustomEnums;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{
    public partial class SMSTransactionReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string LoingName = CurrentUser.LoginName;

            try
            {
                if (!IsPostBack)
                {
                    BindOrganizations(CurrentUser.LoginID);
                    BindModelDropdown();
                    //BindSMSDeliveryStatusList();
                    this.ddlCampaign.Items.Clear();
                    this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
                    this.ddlDepartment.Items.Clear();
                    this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));

                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 0, PageNames.SMSTransactionReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }



        #region "Button Click Events"

        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnShowReport_Click", 0, PageNames.SMSTransactionReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        #endregion

        #region "Dropdown Events"

        protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDepartment.SelectedIndex > 0)
            {
                BindSMSCampaigns(Convert.ToInt32(ddlOrganization.SelectedItem.Value), CurrentUser.LoginID, Convert.ToInt32(ddlDepartment.SelectedItem.Value));
            }
            else
            {
                this.ddlCampaign.Items.Clear();
                this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
            }

            ddlCampaign.Focus();
        }

        protected void ddlOrganization_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlOrganization.SelectedIndex > 0)
            {
                BindDepartment(Convert.ToInt32(ddlOrganization.SelectedItem.Value));
            }
            else
            {
                this.ddlCampaign.Items.Clear();
                this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));

                this.ddlDepartment.Items.Clear();
                this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
            }

            ddlOrganization.Focus();
        }

        #endregion

        #region "Bind Dropdowns"

        /// <summary>
        /// Bind SMSCampaigns
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindSMSCampaigns(int? organizationID, int? userID, int deptID)
        {
            ddlCampaign.Items.Clear();
            if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID > 0)
            {
                int? deptId = null;
                if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
                {
                    //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
                    this.ddlCampaign.DataSource = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, deptID, null);
                }
                else
                {
                    //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptId, null);
                    this.ddlCampaign.DataSource = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, deptId, null);
                }
            }
            else
            {
                //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
                this.ddlCampaign.DataSource = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, deptID, null);
            }

            this.ddlCampaign.DataTextField = "Title";
            this.ddlCampaign.DataValueField = "CampaignID";
            this.ddlCampaign.DataBind();

            ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        /// <summary>
        /// 
        /// </summary>
        private void BindModelDropdown()
        {
            this.ddlMode.Items.Clear();
            this.ddlMode.Items.Insert(0, new ListItem("Choose...", "0"));
            this.ddlMode.Items.Insert(1, new ListItem("Web API", "1"));
            this.ddlMode.Items.Insert(2, new ListItem("Web Portal", "2"));
        }

        /// <summary>
        /// Bind BindDepartment
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindDepartment(int? organizationID)
        {
            ddlDepartment.Items.Clear();

            if (CurrentUser.OrganizationID > 0)
                this.ddlDepartment.DataSource = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
            else
                this.ddlDepartment.DataSource = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(organizationID.Value);

            this.ddlDepartment.DataTextField = "Title";
            this.ddlDepartment.DataValueField = "DepartmentID";
            this.ddlDepartment.DataBind();
            ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        /// <summary>
        /// Bind Organization
        /// </summary>
        public void BindOrganizations(int? userID)
        {
            ddlOrganization.Items.Clear();
            //this.ddlOrganization.DataSource = new OrganizationBLL().SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataSource = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataTextField = "Title";
            this.ddlOrganization.DataValueField = "ID";
            this.ddlOrganization.DataBind();
            ddlOrganization.Items.Insert(0, new ListItem("Choose...", "0"));
        }


        /// <summary>
        /// Get SMS Delivery StatusList
        /// </summary>
        //public void BindSMSDeliveryStatusList()
        //{
        //    chkSMSDeliveryStatusList.Items.Clear();
        //    this.chkSMSDeliveryStatusList.DataSource = new SMSDeliveryStatusBLL().GetAllSMSDeliveryStatus();
        //    this.chkSMSDeliveryStatusList.DataTextField = "Title";
        //    this.chkSMSDeliveryStatusList.DataValueField = "ID";
        //    this.chkSMSDeliveryStatusList.DataBind();
        //    this.chkSMSDeliveryStatusList.Items.Insert(0, new ListItem("Select All", "0"));
        //}


        #endregion

        # region Custom Methods

        private void ShowReport()
        {
            UserModel currentUser = CurrentUser.GetSessionUserInfo();
            try
            {
                if (ddlOrganization.SelectedIndex > 0 && ddlCampaign.SelectedIndex > 0 && ddlMode.SelectedIndex > 0)
                {
                    SMS.CMP.UserControl.Reports.ucReportViewer viewer = (SMS.CMP.UserControl.Reports.ucReportViewer)this.ucReportViewer1;

                    if (rbStandard.Checked)
                    {
                        if (ddlMode.SelectedItem.Text == "Web API")
                            viewer.ReportName = ReportNames.TranAPIStandardReport;
                        else
                            viewer.ReportName = ReportNames.TranSMSCampainStandardReport;
                    }
                    else if (rbMatrixBased.Checked)
                    {
                        viewer.ReportName = ReportNames.TranSMSMatrixReport;
                    }
                    else
                    {
                        if (ddlMode.SelectedItem.Text == "Web API")
                            viewer.ReportName = ReportNames.TranAPIExtentedReport;
                        else
                            viewer.ReportName = ReportNames.TranSMSCampainExtentedReport;
                    }

                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();


                    if (ddlCampaign.SelectedValue != null && ddlCampaign.SelectedValue != "0")
                        parameters.Add(new ReportParameter("Campaign", this.ddlCampaign.SelectedItem.Text));



                    parameters.Add(new ReportParameter("UserName", currentUser.EmployeeName));
                    parameters.Add(new ReportParameter("Organization", this.ddlOrganization.SelectedItem.Text));
                    parameters.Add(new ReportParameter("Department", this.ddlDepartment.SelectedItem.Text));
                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsSMSCampaign", GetReportDataTable(parameters, currentUser)));

                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ShowReport", 0, PageNames.SMSTransactionReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, UserModel currentUser)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                string SelectPhone = string.Empty;

                #region "Selection Criteria"
                int CampaignID = Convert.ToInt32(ddlCampaign.SelectedValue);
                int mode = Convert.ToInt32(ddlMode.SelectedItem.Value);  // Web API : 1, Web Portal : 2
                int? userID = null;

                if (txtPhoneNo.Text != "")
                    SelectPhone = txtPhoneNo.Text;


                #region "Comment Out"
                //int status = 0;
                //List<string> selectedItemList = new List<string>();
                //foreach (ListItem item in chkSMSDeliveryStatusList.Items)
                //{
                //    if (item.Selected && Convert.ToInt32(item.Value) > 0)
                //    {
                //        selectedItemList.Add(item.Value);
                //    }
                //}

                //string filterdListCSV = string.Join(",", selectedItemList);

                //if (filterdListCSV != "")
                //{
                #endregion

                if (currentUser.OrganizationID.HasValue && currentUser.OrganizationID > 0)
                    userID = currentUser.UserID ?? null;

                //List<SMSTransactionModel> smsTransactions = new SMSTransactionBLL().GetTransactionsDetailByCampaignID(CampaignID, mode, SelectPhone);
                List<SMSTransactionModel> smsTransactions = LazySingletonBLL<SMSTransactionBLL>.Instance.GetTransactionsDetailByCampaignID(CampaignID, mode, SelectPhone);
                // List<SMSTransactionModel> smsTransactions = smsTransactionsTemp.Where(s => s.CampaignID == CampaignID).ToList();
                dt = Common.ToDataTable((from transaction in smsTransactions
                                         select new
                                         {
                                             transaction.SMSTransactionID,
                                             transaction.ShortCode,
                                             SendMessage = "",
                                             transaction.ContactNo,
                                             transaction.DeliveryStatusID,
                                             transaction.SendingDate,
                                             transaction.DeliveredDate,
                                             transaction.SMSSendingStatus
                                         }).ToList());


                string SendMessage = string.Empty;

                if (ddlMode.SelectedItem.Text != "Web API")
                {
                    SendMessage = new SMSCampaignBLL().GetCampaingSendMessage(CampaignID);
                }


                if (dt.Rows.Count > 0)
                {
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                    parameters.Add(new ReportParameter("CampaignMessage", SendMessage));

                }
                else
                {
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));
                    parameters.Add(new ReportParameter("CampaignMessage", ""));
                }
                dt.TableName = "tblSMSTransaction";

                #region "Comment Out"

                //}
                //else
                //{
                //    string script = "toastr.error('Select Checklist item.');";
                //    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                //}
                #endregion

                #endregion
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetReportDataTable", 0, PageNames.SMSTransactionReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
            return dt;
        }

        # endregion
    }
}