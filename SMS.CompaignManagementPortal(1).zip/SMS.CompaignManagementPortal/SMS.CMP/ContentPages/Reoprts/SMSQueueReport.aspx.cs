﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using Microsoft.Reporting.WebForms;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.SMSQueue;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace SMS.CMP.ContentPages.Reoprts
{
    public partial class SMSQueueReport : System.Web.UI.Page
    {
        /// <summary>
        /// On pre-Init event
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            try
            {
                #region "Comment Out"
                //if (Session["UserTable"] != null)
                //{
                //    DataTable dtUser = (DataTable)Session["UserTable"];
                //    SPWeb myWeb = SPControl.GetContextSite(Context).OpenWeb();
                //    this.MasterPageFile = myWeb.ServerRelativeUrl + dtUser.Rows[0]["MasterPageUrl"].ToString();
                //}
                //else
                //    Response.Redirect(SPContext.Current.Site.Url + "/_layouts/15/SignOut.aspx", true);
                #endregion "Comment Out"
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "OnPreInit", 0, PageNames.SMSQueueReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        /// <summary>
        /// Page Load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string LoingName = CurrentUser.LoginName; //  CurrentUser.GetSessionUserInfo()

            try
            {
                if (!IsPostBack)
                {
                    BindOrganizations(CurrentUser.LoginID);
                    this.ddlCampaign.Items.Clear();
                    this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));

                    this.ddlDepartment.Items.Clear();
                    this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));

                    #region "Comment Out"

                    // check the current user have rights to access to the page
                    //if (new Common().GetPageAccessPermission(LoingName, PageNames.SMSQueueReport, 1) == false)
                    //{
                    //    // check the current user have rights to access to the page
                    //    if (new Common().GetPageAccessPermission(LoingName, PageNames.SMSQueueReport) == false)
                    //    {
                    //        Response.Redirect("../Dashboard/Error/Error.aspx?Key=PageRightsDenied", true);
                    //    }
                    //}

                    #endregion

                }

            }

            catch (Exception ex)
            {
               
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 0, PageNames.SMSQueueReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        #region "Dropdown Events"

        /// <summary>
        /// organization dropdown index changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlOrganization_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlOrganization.SelectedIndex > 0)
            {
                BindDepartments(Convert.ToInt32(ddlOrganization.SelectedItem.Value));
            }
            else
            {
                this.ddlCampaign.Items.Clear();
                this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));

                this.ddlDepartment.Items.Clear();
                this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
            }
            ddlDepartment.Focus();
        }

        /// <summary>
        ///  dept/project dropdown index changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (ddlDepartment.SelectedIndex > 0)
            {
                BindSMSCampaigns(Convert.ToInt32(ddlOrganization.SelectedItem.Value), CurrentUser.LoginID, Convert.ToInt32(ddlDepartment.SelectedItem.Value));
            }
            else
            {
                this.ddlCampaign.Items.Clear();
                this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
            }

            ddlCampaign.Focus();
        }


        #endregion

        #region "Bind Dropdowns"

        /// <summary>
        /// Bind Department 
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindDepartments(int organizationID)
        {
            try
            {
                ddlDepartment.Items.Clear();


                if (CurrentUser.OrganizationID > 0)
                {
                    //this.ddlDepartment.DataSource = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);//.Where (p=>p.Status==true).ToList ();
                    this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);//.Where (p=>p.Status==true).ToList ();
                }
                else
                {
                    //this.ddlDepartment.DataSource = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(organizationID);
                    this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.SelectActiveDepartmentsByOrgID(organizationID);
                }

                this.ddlDepartment.DataTextField = "Title";
                this.ddlDepartment.DataValueField = "DepartmentID";
                this.ddlDepartment.DataBind();
                ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
            }
            catch (Exception ex)
            {                

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "BindDepartments", 0, PageNames.SMSQueueReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }


        /// <summary>
        /// Bind SMSCampaigns
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindSMSCampaigns(int? organizationID, int? userID, int deptID)
        {
            try
            {
                ddlCampaign.Items.Clear();

                if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID > 0)
                {
                    int? deptId = null;
                    //deptId = CurrentUser.DepartmentID ?? deptID ;
                    if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
                    {
                        //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
                        this.ddlCampaign.DataSource = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, deptID, null);
                    }
                    else
                    {
                        //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptId, null);
                        this.ddlCampaign.DataSource = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, deptId, null);
                    }
                }
                else
                {
                    //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetAllCampaingsInfo(organizationID);
                    //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
                    this.ddlCampaign.DataSource = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, deptID, null);
                }

                this.ddlCampaign.DataTextField = "Title";
                this.ddlCampaign.DataValueField = "CampaignID";
                this.ddlCampaign.DataBind();

                ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "BindSMSCampaigns", 0, PageNames.SMSQueueReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        /// <summary>
        /// Bind Organization
        /// </summary>
        public void BindOrganizations(int? userID)
        {
            ddlOrganization.Items.Clear();
            //this.ddlOrganization.DataSource = new OrganizationBLL().SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataSource = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataTextField = "Title";
            this.ddlOrganization.DataValueField = "ID";
            this.ddlOrganization.DataBind();
            ddlOrganization.Items.Insert(0, new ListItem("Choose...", "0"));
        }
        #endregion

        #region "Cutom Method"

        /// <summary>
        /// Show the  report on the basis of filter Criteria
        /// </summary>
        private void ShowReport()
        {
            UserModel currentUser = CurrentUser.GetSessionUserInfo();

            try
            {
                if (this.ddlCampaign.SelectedIndex > 0 && ddlOrganization.SelectedIndex > 0)
                {
                    SMS.CMP.UserControl.Reports.ucReportViewer viewer = (SMS.CMP.UserControl.Reports.ucReportViewer)this.ucReportViewer1;

                    viewer.ReportName = ReportNames.RptQueueReport;

                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();


                    if (ddlCampaign.SelectedValue != null && ddlCampaign.SelectedValue != "0")
                        parameters.Add(new ReportParameter("Campaign", this.ddlCampaign.SelectedItem.Text));

                    //parameters.Add(new ReportParameter("FromDate", new Common().ConvertDateFormat(DateTime.Now.ToString("dd/MM/yyyy")).ToString()));
                    //parameters.Add(new ReportParameter("ToDate", new Common().ConvertDateFormat(DateTime.Now.ToString("dd/MM/yyyy")).ToString()));

                    //parameters.Add(new ReportParameter("FromDate", new Common().ConvertDateFormat(dtpFrom.Value).ToString()));
                    //parameters.Add(new ReportParameter("ToDate", new Common().ConvertDateFormat(dtpTo.Value).ToString()));

                    parameters.Add(new ReportParameter("UserName", currentUser.EmployeeName));
                    parameters.Add(new ReportParameter("Organization", this.ddlOrganization.SelectedItem.Text));
                    parameters.Add(new ReportParameter("Department", this.ddlDepartment.SelectedItem.Text));
                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsSMSQueue", GetReportDataTable(parameters, currentUser)));

                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                }
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ShowReport", 0, PageNames.SMSQueueReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, UserModel currentUser)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                #region "Selection Criteria"
                int CampaignID = Convert.ToInt32(ddlCampaign.SelectedValue);
                int OrganizationID = Convert.ToInt32(ddlOrganization.SelectedValue);

                int? userID = null;

                if (currentUser.OrganizationID.HasValue && currentUser.OrganizationID > 0)
                    userID = currentUser.UserID ?? null;

                //dt = new SMSQueueBLL().GetSMSQueueList(OrganizationID, CampaignID);
                dt = LazySingletonBLL<SMSQueueBLL>.Instance.GetSMSQueueList(OrganizationID, CampaignID);

                if (dt.Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

                #endregion
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetReportDataTable", 0, PageNames.SMSQueueReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
            return dt;
        }

        #endregion

        #region "Button Click Events"
        /// <summary>
        /// Show Report Method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
                //pnlError.Visible = false;
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnShowReport_Click", 0, PageNames.SMSQueueReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }
        #endregion
    }
}