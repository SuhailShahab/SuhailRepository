﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using Microsoft.Reporting.WebForms;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{
    public partial class TelcoPaymentInvoiceReport : System.Web.UI.Page
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            try
            {

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "OnPreInit", 0, PageNames.TelcoPaymentInvoiceReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        /// <summary>
        /// Page Load Event 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string LoingName = CurrentUser.LoginName; //  CurrentUser.GetSessionUserInfo()

            try
            {
                if (!IsPostBack)
                {
                    this.BindNetworksCode();
                    this.ddlTelcoPayments.Items.Clear();
                    this.ddlTelcoPayments.Items.Insert(0, new ListItem("Choose...", "0"));
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.TelcoPaymentInvoiceReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        #region "Dropdown Events"

        /// <summary>
        ///  Telco Network drop down change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlNetworkCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlNetworkCode.SelectedIndex > 0)
            {
                BindTelcoPaymentes(Convert.ToInt32(ddlNetworkCode.SelectedItem.Value));
            }
            else
            {
                this.ddlTelcoPayments.Items.Clear();
                this.ddlTelcoPayments.Items.Insert(0, new ListItem("Choose...", "0"));

            }
            ddlTelcoPayments.Focus();
        }

        #endregion

        #region "Bind Dropdowns"

        /// <summary>
        /// Bind Telco dropm down
        /// </summary>
        /// 
        public void BindNetworksCode()
        {
            this.ddlNetworkCode.Items.Clear();
            //this.ddlNetworkCode.DataSource = new NetworksCodeBLL().GetAllNetWorkCodes();
            this.ddlNetworkCode.DataSource = LazySingletonBLL<NetworksCodeBLL>.Instance.GetAllNetWorkCodes();
            this.ddlNetworkCode.DataTextField = "Title";
            this.ddlNetworkCode.DataValueField = "TelcoID";
            this.ddlNetworkCode.DataBind();
            this.ddlNetworkCode.Items.Insert(0, new ListItem("Choose...", "0"));
        }


        /// <summary>
        /// Get Telco Payments
        /// </summary>
        /// <param name="telcoId"></param>
        public void BindTelcoPaymentes(int telcoId)
        {
            this.ddlTelcoPayments.Items.Clear();
            //this.ddlTelcoPayments.DataSource = new TelcoBLL().GetActiveTelcoPayments(telcoId);
            this.ddlTelcoPayments.DataSource = LazySingletonBLL<TelcoBLL>.Instance.GetActiveTelcoPayments(telcoId);
            this.ddlTelcoPayments.DataTextField = "Title";
            this.ddlTelcoPayments.DataValueField = "ID";
            this.ddlTelcoPayments.DataBind();
            this.ddlTelcoPayments.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        #endregion

        #region "Cutom Method"

        /// <summary>
        /// Show the  report on the basis of filter Criteria
        /// </summary>
        private void ShowReport()
        {
            UserModel currentUser = CurrentUser.GetSessionUserInfo();

            try
            {
                if (this.ddlNetworkCode.SelectedIndex > 0 && ddlTelcoPayments.SelectedIndex > 0)
                {
                    SMS.CMP.UserControl.Reports.ucReportViewer viewer = (SMS.CMP.UserControl.Reports.ucReportViewer)this.ucReportViewer1;
                    viewer.ReportName = ReportNames.RptTelcoPaymentInvoice;

                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();
                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsTelcoPayment", GetReportDataTable(parameters, currentUser)));

                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "ShowReport", 0, PageNames.TelcoPaymentInvoiceReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, UserModel currentUser)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                #region "Selection Criteria"
                int TelcoPaymentID = Convert.ToInt32(ddlTelcoPayments.SelectedValue);

                bool isOnNet = false;
                if (statusRadioButtons.SelectedValue == "True")
                    isOnNet = true;

                int? userID = null;

                if (currentUser.OrganizationID.HasValue && currentUser.OrganizationID > 0)
                    userID = currentUser.UserID ?? null;

                //List<TelcoModel> payments = new TelcoBLL().GetTelcoByPaymentID(TelcoPaymentID, isOnNet).ToList();
                List<TelcoModel> payments = LazySingletonBLL<TelcoBLL>.Instance.GetTelcoByPaymentID(TelcoPaymentID, isOnNet).ToList();


                dt = Common.ToDataTable((from p in payments
                                         select new
                                         {
                                             p.ID,
                                             p.PerSMSRate,
                                             p.PurchaseDate,
                                             p.ExpiryDate,
                                             p.TotalBalance,
                                             p.TotalSMS,
                                             p.RemainingSMS,
                                             p.UsedSMS,
                                             RemainBalance = Convert.ToDecimal(p.TotalBalance.Value) - (Convert.ToDecimal(p.UsedSMS.Value) * p.PerSMSRate.Value),
                                             UsedBalance = Convert.ToDecimal(p.UsedSMS.Value) * p.PerSMSRate.Value,
                                             p.Title,
                                             p.TelcoName,
                                             p.TelcoID,
                                             p.CreatedDate,
                                             p.TelcoCode

                                         }).ToList());

                dt.TableName = "Table 1";
                if (dt.Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

                #endregion
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetReportDataTable", 0, PageNames.TelcoPaymentInvoiceReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);

            }
            return dt;
        }

        #endregion

        #region "Button Click Events"
        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
                //pnlError.Visible = false;
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }
        #endregion
    }
}