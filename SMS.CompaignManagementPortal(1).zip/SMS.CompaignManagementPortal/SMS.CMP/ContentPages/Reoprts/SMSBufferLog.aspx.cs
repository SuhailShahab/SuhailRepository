﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using SMS.CMP.BE.SMSQueue;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using SMS.CMP.BLL.SMSQueue;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace SMS.CMP.ContentPages.Reoprts
{

    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <27-11-2015 11:22 AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // =================================================================================================================================
    public partial class SMSBufferLog : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        #region "Web Methods"


        /// <summary>
        /// Get Campaign Information
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static SMSQueueViewModel GetRecord(string organizationID, string departmentID, string campaignID, string pageNo, string fromDate, string toDate, string searchText)
        {
            SMSQueueViewModel model = null;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;

                model = new SMSQueueViewModel();
                int PageNo = Convert.ToInt32(pageNo);

                if (PageNo != 0)
                    model.PageNo = PageNo;
                else
                    model.PageNo = 1;

                model.PageSize = PageSize;
                model.User = User;

                SearchModel search = new SearchModel();
                search.OrganizaitonID = Convert.ToInt32(organizationID);
                search.DepartmentID = Convert.ToInt32(departmentID);
                search.CampaignID = Convert.ToInt32(campaignID);
                search.PageNo = model.PageNo;
                search.PageSize = model.PageSize;
                search.FromDate = fromDate;
                search.Todate = toDate;
                search.SearchText = searchText;


                //model = new SMSQueueBLL().spGetSMSQueues(model, search); 
                model = LazySingletonBLL<SMSQueueBLL>.Instance.spGetSMSQueues(model, search);



            }
            catch (Exception ex)
            {
               
                LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);


                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 0, PageNames.SMSBufferLog, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }

            }
            return model;
        }


        /// <summary>
        /// get Department By Organization ID
        /// </summary>
        /// <returns>Department List</returns>
        [WebMethod]
        public static SMSQueueViewModel GetDepartments(string organizationID)
        {
            SMSQueueViewModel model = new SMSQueueViewModel();
            List<DepartmentsModel> departments = null;
            try
            {
                //departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                if (departments != null && departments.Count > 0)
                    model.Departments = departments;
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode= LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 0, PageNames.SMSBufferLog, CurrentUser.GetSessionUserInfo()));
               // LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }


            }
            return model;
        }


        /// <summary>
        /// This webmethod use to get the Campaings List
        /// </summary>
        /// <param name="organizationID">Slected organization ID</param>
        /// <param name="deptID">Selected Department ID</param>
        /// <param name="userID">Select User ID</param>
        /// <returns>SMs Response View Model</returns>
        [WebMethod]
        public static SMSQueueViewModel GetSMSCampaigns(string organizationID, string deptID, string userID)
        {
            SMSQueueViewModel model = new SMSQueueViewModel();
            try
            {
                if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID > 0)
                {
                    int? deptId = null;
                    if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
                    {
                        //model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(Convert.ToInt32(organizationID), Convert.ToInt32(deptID), null);
                        model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(Convert.ToInt32(organizationID), Convert.ToInt32(deptID), null);
                    }
                    else
                    {
                        //model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(Convert.ToInt32(organizationID), deptId, null);
                        model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(Convert.ToInt32(organizationID), deptId, null);
                    }
                }
                else
                {
                    //model.SMSCampaigns = new SMSCampaignBLL().GetCampaings(Convert.ToInt32(organizationID), Convert.ToInt32(deptID), null);
                    model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(Convert.ToInt32(organizationID), Convert.ToInt32(deptID), null);
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode=LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetSMSCampaigns", 0, PageNames.SMSBufferLog, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }

            }
            return model;
        }


        /// <summary>
        /// This Web Method is use to get the Queue Message 
        /// </summary>
        /// <param name="queueID">Selected Queue ID</param>
        /// <returns>SMS Queue Model</returns>
        [WebMethod]
        public static SMSQueueModel GetSMSQueueMessage(string queueID)
        {
            SMSQueueModel model = null;
            try
            {
                model = new SMSQueueModel();
                //model.SendMessage = LazySingletonBLL<SMSQueueBLL>.Instance.GetSMSQueueMessage(Convert.ToInt32(queueID));
                model.SendMessage = new SMSQueueBLL().GetSMSQueueMessage(Convert.ToInt32(queueID));

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetSMSQueueMessage", 1, PageNames.SMSBufferLog, CurrentUser.GetSessionUserInfo()));
                // LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }
            }

            return model;
        }



        /// <summary>
        /// This web method  use to resend the SMS which remain in Queue
        /// </summary>
        /// <param name="organizationID">Selected organizaiton ID</param>
        /// <param name="campaignID">Selected campaign ID</param>
        /// <returns>SMS Queue Model</returns>
        [WebMethod]
        public static SMSQueueModel ResetSMSQueue(string organizationID, string campaignID)
        {
            SMSQueueModel model = null;
            try
            {
                model = new SMSQueueModel();
                //model.ID = new SMSQueueBLL().ResetSMSQueue(Convert.ToInt32(campaignID), Convert.ToInt32(organizationID));
                model.ID = LazySingletonBLL<SMSQueueBLL>.Instance.ResetSMSQueue(Convert.ToInt32(campaignID), Convert.ToInt32(organizationID));
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.ResentSMS);
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ResetSMSQueue", 1, PageNames.SMSBufferLog, CurrentUser.GetSessionUserInfo()));
                // LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }
            }

            return model;
        }


        #endregion

      
    }
}