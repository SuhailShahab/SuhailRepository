﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using Microsoft.Reporting.WebForms;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using SMS.CMP.BLL.Reports;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{
    public partial class SMSStatSummary : System.Web.UI.Page
    {
        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string LoingName = CurrentUser.LoginName; //  CurrentUser.GetSessionUserInfo()

            try
            {
                if (!IsPostBack)
                {
                    this.BindTelcos();
                    this.BindSMSModes();
                    this.BindSMSLanguages();
                    this.BindSMSDeliveryStatus();

                    dtpTo.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    dtpFrom.Value = DateTime.Now.ToString("dd/MM/yyyy");



                    #region "Need to Implement Page rights"
                    //dtpTo.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    //dtpFrom.Value = DateTime.Now.ToString("dd/MM/yyyy");

                    // check the current user have rights to access to the page
                    //if (new Common().GetPageAccessPermission(LoingName, PageNames.InvoiceLedgerReport, 1) == false)
                    //{
                    //    // check the current user have rights to access to the page
                    //    if (new Common().GetPageAccessPermission(LoingName, PageNames.InvoiceLedgerReport) == false)
                    //    {
                    //        Response.Redirect("../Dashboard/Error/Error.aspx?Key=PageRightsDenied", true);
                    //    }
                    //}
                    #endregion

                }

            }

            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        #region "Bind Dropdowns"

        public void BindTelcos()
        {
            try
            {
                this.ddlTelcos.Items.Clear();
                //this.ddlTelcos.DataSource = new TelcoBLL().GetctiveTelcoCompanies();
                this.ddlTelcos.DataSource = LazySingletonBLL<TelcoBLL>.Instance.GetctiveTelcoCompanies();
                this.ddlTelcos.DataTextField = "Title";
                this.ddlTelcos.DataValueField = "TelcoID";
                this.ddlTelcos.DataBind();
                this.ddlTelcos.Items.Insert(0, new ListItem("<Select All>", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindTelcos", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        public void BindSMSModes()
        {
            try
            {
                this.ddlSMSMode.Items.Clear();
                //this.ddlSMSMode.DataSource = new SMSModeBLL().GetAllActiveContacts();
                this.ddlSMSMode.DataSource = LazySingletonBLL<SMSModeBLL>.Instance.GetAllActiveContacts();
                this.ddlSMSMode.DataTextField = "Title";
                this.ddlSMSMode.DataValueField = "ID";
                this.ddlSMSMode.DataBind();
                this.ddlSMSMode.Items.Insert(0, new ListItem("<Select All>", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindSMSModes", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        public void BindSMSLanguages()
        {
            try
            {
                this.ddlSMSType.Items.Clear();
                //this.ddlSMSType.DataSource = new SMSLanguageBLL().GetAllSMSLanguages();
                this.ddlSMSType.DataSource = LazySingletonBLL<SMSLanguageBLL>.Instance.GetAllSMSLanguages();
                this.ddlSMSType.DataTextField = "Title";
                this.ddlSMSType.DataValueField = "ID";
                this.ddlSMSType.DataBind();
                this.ddlSMSType.Items.Insert(0, new ListItem("<Select All>", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindSMSTypes", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        public void BindSMSDeliveryStatus()
        {
            try
            {
                this.ddlSMSDeliveryStatus.Items.Clear();
                //this.ddlSMSDeliveryStatus.DataSource = new SMSDeliveryStatusBLL().GetAllSMSDeliveryStatus();
                this.ddlSMSDeliveryStatus.DataSource = LazySingletonBLL<SMSDeliveryStatusBLL>.Instance.GetAllSMSDeliveryStatus();
                this.ddlSMSDeliveryStatus.DataTextField = "Title";
                this.ddlSMSDeliveryStatus.DataValueField = "ID";
                this.ddlSMSDeliveryStatus.DataBind();
                this.ddlSMSDeliveryStatus.Items.Insert(0, new ListItem("<Select All>", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindSMSTypes", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }


        #endregion

        #region "Cutom Method"

        /// <summary>
        /// Show the  report on the basis of filter Criteria
        /// </summary>
        private void ShowReport()
        {
            UserModel currentUser = CurrentUser.GetSessionUserInfo();

            try
            {

                SMS.CMP.UserControl.Reports.ucReportViewer viewer = (SMS.CMP.UserControl.Reports.ucReportViewer)this.ucReportViewer1;

                List<ReportDataSource> datasources = null;
                datasources = new List<ReportDataSource>();

                List<ReportParameter> parameters = null;
                parameters = new List<ReportParameter>();

                if (Convert.ToInt32(rbtReportType.SelectedItem.Value) == 0)
                {
                    viewer.ReportName = ReportNames.SMSTelcoStatSummary;
                    // add the data sources
                    datasources.Add(new ReportDataSource("dsSMSStatSummary", GetReportDataTable(parameters, currentUser)));
                }
                else
                {
                    viewer.ReportName = ReportNames.MonthWiseSMSStat;
                    // add the data sources
                    //call is changed as we have to pass same parameters.
                    datasources.Add(new ReportDataSource("dsMonthWiseSMSStat", GetReportDataTable(parameters, currentUser)));
                }

                #region "add the parameters"
                parameters.Add(new ReportParameter("UserName", currentUser.EmployeeName));
                parameters.Add(new ReportParameter("TelcoName", Convert.ToString(ddlTelcos.SelectedItem.Text)));
                #endregion

                viewer.DataSourceList = datasources;

                // add the parameters
                viewer.ParamList = parameters;

                // load the local report (RDLC)
                viewer.LoadLocalReport();

            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ShowReport", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, UserModel currentUser)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                #region "Selection Criteria"

                int? DeliveryStatusID = null, TelcoID = null, SMSMode = null, SMSLangID = null, IsOnNet = null;

                if (ddlSMSDeliveryStatus.SelectedIndex > 0) DeliveryStatusID = Convert.ToInt32(ddlSMSDeliveryStatus.SelectedValue.ToString());
                if (ddlTelcos.SelectedIndex > 0) TelcoID = Convert.ToInt32(ddlTelcos.SelectedValue.ToString());
                if (ddlSMSMode.SelectedIndex > 0) SMSMode = Convert.ToInt32(ddlSMSMode.SelectedValue.ToString());
                if (ddlSMSType.SelectedIndex > 0) SMSLangID = Convert.ToInt32(ddlSMSType.SelectedValue.ToString());

                if (Convert.ToInt32(rbModes.SelectedItem.Value) > -1)
                {
                    IsOnNet = Convert.ToInt32(rbModes.SelectedItem.Value);
                }

                DateTime FromDate = new Common().ConvertDateFormat(dtpFrom.Value);
                DateTime ToDate = new Common().ConvertDateFormat(dtpTo.Value);

                if (Convert.ToInt32(rbtReportType.SelectedItem.Value) == 0)
                {
                    //for Summary
                    dt = LazySingletonBLL<CommonReportsBLL>.Instance.GetSMSStatSummary(DeliveryStatusID, TelcoID, SMSMode, SMSLangID, IsOnNet, FromDate, ToDate, chkIncludeDate.Checked);
                }
                else
                {
                    //for details
                    dt = LazySingletonBLL<CommonReportsBLL>.Instance.GetSMSStatDetail(DeliveryStatusID, TelcoID, SMSMode, SMSLangID, IsOnNet, FromDate, ToDate, chkIncludeDate.Checked);
                }

                if (dt.Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

                #endregion
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetReportDataTable", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
            return dt;
        }

        #endregion

        #region "Button Click Events"
        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
                //pnlError.Visible = false;
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnShowReport_Click", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }
        #endregion
    }
}