﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using Microsoft.Reporting.WebForms;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using SMS.CMP.BLL.Reports;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{
    public partial class MonthWiseSMSStat : System.Web.UI.Page
    {
        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string LoingName = CurrentUser.LoginName;

            try
            {
                if (!IsPostBack)
                {
                    this.dtpTo.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    this.dtpFrom.Value = DateTime.Now.ToString("dd/MM/yyyy");

                    this.BindTelcos();
                }

            }

            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        #region "Bind Dropdowns"

        public void BindTelcos()
        {
            try
            {
                this.ddlTelcos.Items.Clear();
                this.ddlTelcos.DataSource = LazySingletonBLL<TelcoBLL>.Instance.GetctiveTelcoCompanies();
                this.ddlTelcos.DataTextField = "Title";
                this.ddlTelcos.DataValueField = "TelcoID";
                this.ddlTelcos.DataBind();
                this.ddlTelcos.Items.Insert(0, new ListItem("Choose...", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindTelcos", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        //private bool IsChecked()
        //{
        //    bool ret = false;

        //    foreach (ListItem chk in chkSMSDeliveryStatusList.Items)
        //    {
        //        if (chk.Selected == true)
        //        {
        //            ret = true;
        //            break;
        //        }
        //    }
        //    return ret;
        //}

        #endregion

        #region "Dropdown Events"

        #endregion


        #region "Cutom Method"

        /// <summary>
        /// Show the  report on the basis of filter Criteria
        /// </summary>
        private void ShowReport()
        {
            try
            {
                if (Page.IsValid)
                {
                    UserModel currentUser = CurrentUser.GetSessionUserInfo();

                    SMS.CMP.UserControl.Reports.ucReportViewer viewer = (SMS.CMP.UserControl.Reports.ucReportViewer)this.ucReportViewer1;

                    viewer.ReportName = ReportNames.MonthWiseSMSStat;


                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();

                    parameters.Add(new ReportParameter("UserName", currentUser.EmployeeName));
                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsMonthWiseSMSStat", GetReportDataTable(parameters, currentUser)));

                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();

                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "ShowReport", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, UserModel currentUser)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                #region "Selection Criteria"

                int? TelcoID = null;

                DateTime? FromDate = null;
                DateTime? ToDate = null;

                FromDate = new Common().ConvertDateFormat(dtpFrom.Value);
                ToDate = new Common().ConvertDateFormat(dtpTo.Value);

                if (ddlTelcos.SelectedIndex > 0) TelcoID = Convert.ToInt32(ddlTelcos.SelectedValue.ToString());

                dt = LazySingletonBLL<CommonReportsBLL>.Instance.GetMonthWiseSMSStat(TelcoID, FromDate, ToDate);


                if (dt.Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

                parameters.Add(new ReportParameter("TelcoName", Convert.ToString(ddlTelcos.SelectedItem.Text)));

                #endregion
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetReportDataTable", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);

            }
            return dt;
        }




        #endregion

        #region "Button Click Events"
        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }
        #endregion
    }
}