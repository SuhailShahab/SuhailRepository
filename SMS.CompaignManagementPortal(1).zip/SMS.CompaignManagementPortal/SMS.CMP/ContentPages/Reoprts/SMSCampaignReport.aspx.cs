﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using Microsoft.Reporting.WebForms;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.CustomEnums;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{
    public partial class SMSCampaignReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string LoingName = CurrentUser.LoginName;

            try
            {
                if (!IsPostBack)
                {
                    BindOrganizations(CurrentUser.LoginID);

                    if (CurrentUser.OrganizationID == 0 && CurrentUser.DepartmentID == 0)
                    {
                        divStatus.Visible = true;
                        divrdbStatus.Visible = false;
                        BindSMSDeliveryStatusList();
                    }
                    else
                    {
                        divStatus.Visible = false;
                        divrdbStatus.Visible = true;
                    }

                    this.ddlCampaign.Items.Clear();
                    this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
                    this.ddlDepartment.Items.Clear();
                    this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));


                    /// Restrict dropdown
                    this.DropDownRestriction();
                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 0, PageNames.SMSCampaignReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
                
            }
        }

        #region "Bind Dropdowns"

        /// <summary>
        /// Bind SMSCampaigns
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindSMSCampaigns(int? organizationID, int? userID, int deptID)
        {
            ddlCampaign.Items.Clear();
            if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID > 0)
            {
                int? deptId = null;
                if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
                    this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
                else
                    this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptId, null);
            }
            else
            {
                this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
            }

            this.ddlCampaign.DataTextField = "Title";
            this.ddlCampaign.DataValueField = "CampaignID";
            this.ddlCampaign.DataBind();

            ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        /// <summary>
        /// Bind BindDepartment
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindDepartment(int? organizationID)
        {
            ddlDepartment.Items.Clear();

            if (organizationID.HasValue && organizationID > 0)
            {
                //this.ddlDepartment.DataSource = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
            }
            else
            {
                //this.ddlDepartment.DataSource = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(organizationID.Value);
                this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.SelectActiveDepartmentsByOrgID(organizationID.Value);
            }

            this.ddlDepartment.DataTextField = "Title";
            this.ddlDepartment.DataValueField = "DepartmentID";
            this.ddlDepartment.DataBind();
            ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        /// <summary>
        /// Bind Organization
        /// </summary>
        public void BindOrganizations(int? userID)
        {
            ddlOrganization.Items.Clear();
            //this.ddlOrganization.DataSource = new OrganizationBLL().SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataSource = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataTextField = "Title";
            this.ddlOrganization.DataValueField = "ID";
            this.ddlOrganization.DataBind();
            ddlOrganization.Items.Insert(0, new ListItem("Choose...", "0"));
        }
        /// <summary>
        /// Get SMS Delivery StatusList
        /// </summary>
        public void BindSMSDeliveryStatusList()
        {
            chkSMSDeliveryStatusList.Items.Clear();
            //this.chkSMSDeliveryStatusList.DataSource = new SMSDeliveryStatusBLL().GetAllSMSDeliveryStatus();
            this.chkSMSDeliveryStatusList.DataSource = LazySingletonBLL<SMSDeliveryStatusBLL>.Instance.GetAllSMSDeliveryStatus();
            //.Select (p=> new ID = p.ID, Title =;
            this.chkSMSDeliveryStatusList.DataTextField = "Title";
            this.chkSMSDeliveryStatusList.DataValueField = "ID";
            this.chkSMSDeliveryStatusList.DataBind();
            this.chkSMSDeliveryStatusList.Items.Insert(0, new ListItem("Select All", "0"));
        }

        /// <summary>
        /// if Check Is items
        /// </summary>
        /// <returns></returns>
        private bool IsChecked()
        {
            bool ret = false;

            foreach (ListItem chk in chkSMSDeliveryStatusList.Items)
            {
                if (chk.Selected == true)
                {
                    ret = true;
                    break;
                }
            }
            return ret;
        }

        #endregion

        #region "Dropdown Events"

        protected void ddlOrganization_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlOrganization.SelectedIndex > 0)
            {
                BindDepartment(Convert.ToInt32(ddlOrganization.SelectedItem.Value));
            }
            else
            {
                this.ddlCampaign.Items.Clear();
                this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));

                this.ddlDepartment.Items.Clear();
                this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
            }

            ddlOrganization.Focus();
        }

        protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDepartment.SelectedIndex > 0)
            {
                BindSMSCampaigns(Convert.ToInt32(ddlOrganization.SelectedItem.Value), CurrentUser.LoginID, Convert.ToInt32(ddlDepartment.SelectedItem.Value));
            }
            else
            {
                this.ddlCampaign.Items.Clear();
                this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
            }

            ddlCampaign.Focus();
        }

        #endregion

        #region "Button Click Events"

        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnShowReport_Click", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        #endregion

        # region Custom Methods

        /// <summary>
        /// Restrict dropdown
        /// </summary>
        private void DropDownRestriction()
        {
            if (CurrentUser.OrganizationID > 0)
            {
                //ddlOrganization.Items.FindByValue(CurrentUser.OrganizationID.ToString()).Selected = true;
                this.ddlOrganization.SelectedValue = CurrentUser.OrganizationID.Value.ToString();
                this.ddlOrganization_SelectedIndexChanged("", null);
                this.ddlOrganization.Enabled = false;
            }

            if (CurrentUser.DepartmentID > 0)
            {
                //this.ddlDepartment.Items.FindByValue(CurrentUser.DepartmentID.ToString()).Selected = true;
                this.ddlDepartment.SelectedValue = CurrentUser.DepartmentID.Value.ToString();
                this.ddlDepartment_SelectedIndexChanged("", null);
                this.ddlDepartment.Enabled = false;
            }

        }


        private void ShowReport()
        {
            UserModel currentUser = CurrentUser.GetSessionUserInfo();
            try
            {
                if (ddlOrganization.SelectedIndex > 0 && ddlCampaign.SelectedIndex > 0)
                {
                    SMS.CMP.UserControl.Reports.ucReportViewer viewer = (SMS.CMP.UserControl.Reports.ucReportViewer)this.ucReportViewer1;

                    viewer.ReportName = ReportNames.SMSCampaignReport;

                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();


                    if (ddlCampaign.SelectedValue != null && ddlCampaign.SelectedValue != "0")
                        parameters.Add(new ReportParameter("Campaign", this.ddlCampaign.SelectedItem.Text));
                    string status = "All";
                    //if (statusRadioButtons.SelectedValue == SMSDeliveryStatuses.DeliverySuccess.GetHashCode().ToString())
                    //    status = statusRadioButtons.SelectedValue;
                    //else if (statusRadioButtons.SelectedValue == SMSDeliveryStatuses.DeliveryFailure.GetHashCode().ToString())
                    //    status = statusRadioButtons.SelectedValue;
                    parameters.Add(new ReportParameter("CheckDelivered", status));
                    //parameters.Add(new ReportParameter("status", statusRadioButtons.SelectedItem.Text));
                    parameters.Add(new ReportParameter("UserName", currentUser.EmployeeName));
                    parameters.Add(new ReportParameter("Organization", this.ddlOrganization.SelectedItem.Text));
                    parameters.Add(new ReportParameter("Department", this.ddlDepartment.SelectedItem.Text));
                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsSMSCampaign", GetReportDataTable(parameters, currentUser)));

                    viewer.DataSourceList = datasources;

                    // add the parameters
                    if (chkDate.Checked)
                    {
                        parameters.Add(new ReportParameter("DateFrom", dtpFrom.Value));
                        parameters.Add(new ReportParameter("DateTo", dtpTo.Value));

                    }
                    else
                    {
                        parameters.Add(new ReportParameter("DateFrom", ""));
                        parameters.Add(new ReportParameter("DateTo", ""));
                    }


                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ShowReport", 0, PageNames.SMSCampaignReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, UserModel currentUser)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                #region "Selection Criteria"
                int CampaignID = Convert.ToInt32(ddlCampaign.SelectedValue);
                int mode = 2;
                int? userID = null;

                int status = 0;

                if (statusRdbList.SelectedValue == SMSDeliveryStatuses.DeliverySuccess.GetHashCode().ToString())
                    status = 1;
                else if (statusRdbList.SelectedValue == SMSDeliveryStatuses.DeliveryFailure.GetHashCode().ToString())
                    status = 2;
                else if (statusRdbList.SelectedValue == SMSDeliveryStatuses.DeliveredAndFailed.GetHashCode().ToString())
                    status = 3;


                List<string> selectedItemList = new List<string>();
                foreach (ListItem item in chkSMSDeliveryStatusList.Items)
                {
                    status = -1;
                    if (item.Selected && Convert.ToInt32(item.Value) > 0)
                    {
                        selectedItemList.Add(item.Value);
                    }
                }

                string filterdListCSV = string.Join(",", selectedItemList);


                if (currentUser.OrganizationID.HasValue && currentUser.OrganizationID > 0)
                    userID = currentUser.UserID ?? null;

                string phoneNo = txtPhoneNo.Text;
                //var myInClause = new int[] {1, 17};

                string dtFrom = null;
                string dtTo = null;
                if (chkDate.Checked)
                {
                    dtFrom = dtpFrom.Value;
                    dtTo = dtpTo.Value;
                }
                else
                {
                    dtFrom = "";
                    dtTo = "";
                }

                //List<SMSTransactionModel> smsTransactions = new SMSTransactionBLL().GetTransactionsByCampaignID(CampaignID, mode, filterdListCSV, phoneNo, status, dtFrom, dtTo);
                List<SMSTransactionModel> smsTransactions = LazySingletonBLL<SMSTransactionBLL>.Instance.GetTransactionsByCampaignID(CampaignID, mode, filterdListCSV, phoneNo, status, dtFrom, dtTo);
                //List<SMSTransactionModel> smsTransactions = smsTransactionsTemp.Where(s =>  myInClause.Contains (s.DeliveryStatusID.Value) && s.CampaignID == CampaignID  ).ToList();
                //List<SMSTransactionModel> smsTransactions = smsTransactionsTemp.Where(s => s.CampaignID == CampaignID).ToList();

                dt = Common.ToDataTable((from transaction in smsTransactions
                                         select new
                                         {
                                             transaction.SMSTransactionID,
                                             transaction.ShortCode,
                                             //transaction.SendMessage,
                                             SendMessage = "",
                                             transaction.ContactNo,
                                             transaction.DeliveryStatusID,
                                             transaction.SendingDate,
                                             transaction.DeliveredDate,
                                             transaction.SMSSendingStatus,

                                         }).ToList());

                string SendMessage = new SMSCampaignBLL().GetCampaingSendMessage(CampaignID);

                if (dt.Rows.Count > 0)
                {
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                    parameters.Add(new ReportParameter("CampaignMessage", SendMessage));
                }
                else
                {
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));
                    parameters.Add(new ReportParameter("CampaignMessage", "No Data"));
                }
                dt.TableName = "tblSMSTransaction";
                #endregion
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetReportDataTable", 0, PageNames.SMSCampaignReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                }

            }
            return dt;
        }

        # endregion




    }
}