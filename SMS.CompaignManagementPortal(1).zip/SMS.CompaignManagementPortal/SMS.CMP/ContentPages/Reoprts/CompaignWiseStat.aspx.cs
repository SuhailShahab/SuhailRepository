﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using Microsoft.Reporting.WebForms;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using SMS.CMP.BLL.Reports;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{
    public partial class CompaignWiseStat : System.Web.UI.Page
    {
        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string LoingName = CurrentUser.LoginName; //  CurrentUser.GetSessionUserInfo()

            try
            {
                if (!IsPostBack)
                {
                    BindOrganizations(CurrentUser.LoginID);
                    BindSMSDeliveryStatusList();
                    this.BindSMSLanguages();
                    this.BindSMSModes();

                    dtpTo.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    dtpFrom.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    this.ddlDepartment.Items.Clear();
                    this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));

                    this.BindTelcos();
                }

            }

            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        #region "Bind Dropdowns"

        /// <summary>
        /// Bind Organization
        /// </summary>
        public void BindOrganizations(int? userID)
        {
            ddlOrganization.Items.Clear();
            this.ddlOrganization.DataSource = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataTextField = "Title";
            this.ddlOrganization.DataValueField = "ID";
            this.ddlOrganization.DataBind();
            ddlOrganization.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        public void BindSMSLanguages()
        {
            try
            {
                this.ddlSMSType.Items.Clear();
                this.ddlSMSType.DataSource = LazySingletonBLL<SMSLanguageBLL>.Instance.GetAllSMSLanguages();
                this.ddlSMSType.DataTextField = "Title";
                this.ddlSMSType.DataValueField = "ID";
                this.ddlSMSType.DataBind();
                this.ddlSMSType.Items.Insert(0, new ListItem("<Select All>", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindSMSTypes", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        /// <summary>
        /// Bind BindDepartment
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindDepartment(int? organizationID)
        {
            ddlDepartment.Items.Clear();

            if (organizationID.HasValue && organizationID > 0)
            {

                this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
            }
            else
            {

                this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.SelectActiveDepartmentsByOrgID(organizationID.Value);
            }

            this.ddlDepartment.DataTextField = "Title";
            this.ddlDepartment.DataValueField = "DepartmentID";
            this.ddlDepartment.DataBind();
            ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
        }


        /// <summary>
        /// Get SMS Delivery StatusList
        /// </summary>
        public void BindSMSDeliveryStatusList()
        {
            chkSMSDeliveryStatusList.Items.Clear();
            this.chkSMSDeliveryStatusList.DataSource = LazySingletonBLL<SMSDeliveryStatusBLL>.Instance.GetAllSMSDeliveryStatus();
            this.chkSMSDeliveryStatusList.DataTextField = "Title";
            this.chkSMSDeliveryStatusList.DataValueField = "ID";
            this.chkSMSDeliveryStatusList.DataBind();
            this.chkSMSDeliveryStatusList.Items.Insert(0, new ListItem("Select All", "0"));
        }

        public void BindTelcos()
        {
            try
            {
                this.ddlTelcos.Items.Clear();
                //this.ddlTelcos.DataSource = new TelcoBLL().GetctiveTelcoCompanies();
                this.ddlTelcos.DataSource = LazySingletonBLL<TelcoBLL>.Instance.GetctiveTelcoCompanies();
                this.ddlTelcos.DataTextField = "Title";
                this.ddlTelcos.DataValueField = "TelcoID";
                this.ddlTelcos.DataBind();
                this.ddlTelcos.Items.Insert(0, new ListItem("Choose...", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindTelcos", 0, PageNames.InvoiceLedgerReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }


        /// <summary>
        /// Get SMS Modes
        /// </summary>
        public void BindSMSModes()
        {
            try
            {
                this.ddlSMSMode.Items.Clear();
                this.ddlSMSMode.DataSource = LazySingletonBLL<SMSModeBLL>.Instance.GetAllActiveContacts();
                this.ddlSMSMode.DataTextField = "Title";
                this.ddlSMSMode.DataValueField = "ID";
                this.ddlSMSMode.DataBind();
                this.ddlSMSMode.Items.Insert(0, new ListItem("<Select All>", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindSMSModes", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        /// <summary>
        /// Get Compaign List
        /// </summary>
        public void BindchkCompaingsList(int? organizationID, int? userID, int? deptID)
        {
            chkCompaingsList.Items.Clear();
            if (organizationID.HasValue && organizationID > 0 && deptID.HasValue && deptID > 0)
            {
                this.chkCompaingsList.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
            }


            this.chkCompaingsList.DataTextField = "Title";
            this.chkCompaingsList.DataValueField = "CampaignID";
            this.chkCompaingsList.DataBind();
            this.chkCompaingsList.Items.Insert(0, new ListItem("Select All", "0"));
        }

        private bool IsChecked()
        {
            bool ret = false;

            foreach (ListItem chk in chkSMSDeliveryStatusList.Items)
            {
                if (chk.Selected == true)
                {
                    ret = true;
                    break;
                }
            }
            return ret;
        }

        #endregion

        #region "Dropdown Events"

        protected void ddlOrganization_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlOrganization.SelectedIndex > 0)
            {
                BindDepartment(Convert.ToInt32(ddlOrganization.SelectedItem.Value));
            }
            else
            {
                this.ddlDepartment.Items.Clear();
                this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
            }

            ddlOrganization.Focus();
        }

        protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDepartment.SelectedIndex > 0)
            {
                BindchkCompaingsList(Convert.ToInt32(ddlOrganization.SelectedItem.Value), CurrentUser.LoginID, Convert.ToInt32(ddlDepartment.SelectedItem.Value));
            }
            else
            {
                this.chkCompaingsList.Items.Clear();
                this.chkCompaingsList.Items.Insert(0, new ListItem("Select All", "0"));
            }

            chkCompaingsList.Focus();
        }


        #endregion


        #region "Cutom Method"

        /// <summary>
        /// Show the  report on the basis of filter Criteria
        /// </summary>
        private void ShowReport()
        {
            try
            {
                if (Page.IsValid)
                {
                    UserModel currentUser = CurrentUser.GetSessionUserInfo();



                    SMS.CMP.UserControl.Reports.ucReportViewer viewer = (SMS.CMP.UserControl.Reports.ucReportViewer)this.ucReportViewer1;

                    viewer.ReportName = ReportNames.CompaignWiseStat;

                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();

                    //parameters.Add(new ReportParameter("FromDate", new Common().ConvertDateFormat(dtpFrom.Value).ToString()));
                    //parameters.Add(new ReportParameter("ToDate", new Common().ConvertDateFormat(dtpTo.Value).ToString()));

                    parameters.Add(new ReportParameter("UserName", currentUser.EmployeeName));
                    parameters.Add(new ReportParameter("SMSPerRate", txtSMSPerRate.Text));
                    parameters.Add(new ReportParameter("Organization", Convert.ToString(ddlOrganization.SelectedItem)));
                    parameters.Add(new ReportParameter("Department", Convert.ToString(ddlDepartment.SelectedItem)));

                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsCompaignWiseStat", GetReportDataTable(parameters, currentUser)));

                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();

                }
                else
                {
                    Regex1.Visible = true;
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "ShowReport", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, UserModel currentUser)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                #region "Selection Criteria"

                int? OrganizationID = null, SMSMode = null, status = null, statusCompain = null, DepartmentID = null, SMSLangID = null, IsOnNet = null, TelcoID = null;


                if (ddlOrganization.SelectedIndex > 0) OrganizationID = Convert.ToInt32(ddlOrganization.SelectedValue.ToString());
                if (ddlDepartment.SelectedIndex > 0) DepartmentID = Convert.ToInt32(ddlDepartment.SelectedValue.ToString());
                if (ddlSMSType.SelectedIndex > 0) SMSLangID = Convert.ToInt32(ddlSMSType.SelectedValue.ToString());
                if (ddlSMSMode.SelectedIndex > 0) SMSMode = Convert.ToInt32(ddlSMSMode.SelectedValue.ToString());
                if (ddlTelcos.SelectedIndex > 0) TelcoID = Convert.ToInt32(ddlTelcos.SelectedValue.ToString());

                if (Convert.ToInt32(rbModes.SelectedItem.Value) > -1)
                {
                    IsOnNet = Convert.ToInt32(rbModes.SelectedItem.Value);
                }

                double SMSPerRate = Convert.ToDouble(txtSMSPerRate.Text);


                DateTime? FromDate = null;
                DateTime? ToDate = null;

                if (chkIncludeDate.Checked)
                {
                    FromDate = new Common().ConvertDateFormat(dtpFrom.Value);
                    ToDate = new Common().ConvertDateFormat(dtpTo.Value);
                }
                else
                {
                    FromDate = null;
                    ToDate = null;
                }

                // statues check box list
                List<string> selectedItemList = new List<string>();
                foreach (ListItem item in chkSMSDeliveryStatusList.Items)
                {
                    status = -1;
                    if (item.Selected && Convert.ToInt32(item.Value) > 0)
                    {
                        selectedItemList.Add(item.Value);
                    }
                }
                string filterdListCSV = string.Join(",", selectedItemList);

                // compaign check box list
                List<string> selectedCompaignItemList = new List<string>();
                foreach (ListItem item in chkCompaingsList.Items)
                {
                    statusCompain = -1;
                    if (item.Selected && Convert.ToInt32(item.Value) > 0)
                    {
                        selectedCompaignItemList.Add(item.Value);
                    }
                }
                string filterdListCSVCompaign = string.Join(",", selectedCompaignItemList);


                dt = LazySingletonBLL<CommonReportsBLL>.Instance.GetCompaignWiseStat(OrganizationID, DepartmentID, SMSLangID, SMSMode, IsOnNet, filterdListCSVCompaign, filterdListCSV, FromDate, ToDate, SMSPerRate, TelcoID);


                if (dt.Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

                #endregion
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetReportDataTable", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);

            }
            return dt;
        }




        #endregion

        #region "Button Click Events"
        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", 0, PageNames.CompaignWiseStat, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }
        #endregion
    }
}