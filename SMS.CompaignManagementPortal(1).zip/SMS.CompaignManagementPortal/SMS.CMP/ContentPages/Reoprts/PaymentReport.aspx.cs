﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using Microsoft.Reporting.WebForms;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{
    public partial class PaymentReport : System.Web.UI.Page
    {
        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            try
            {
                #region "Comment Out"
                //if (Session["UserTable"] != null)
                //{
                //    DataTable dtUser = (DataTable)Session["UserTable"];
                //    SPWeb myWeb = SPControl.GetContextSite(Context).OpenWeb();
                //    this.MasterPageFile = myWeb.ServerRelativeUrl + dtUser.Rows[0]["MasterPageUrl"].ToString();
                //}
                //else
                //    Response.Redirect(SPContext.Current.Site.Url + "/_layouts/15/SignOut.aspx", true);
                #endregion "Comment Out"
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "OnPreInit", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            string LoingName = CurrentUser.LoginName; //  CurrentUser.GetSessionUserInfo()

            try
            {
                if (!IsPostBack)
                {

                    //dtpTo.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    //dtpFrom.Value = DateTime.Now.ToString("dd/MM/yyyy");

                    BindOrganizations(CurrentUser.LoginID);

                    //this.ddlCampaign.Items.Clear();
                    //this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));

                    this.ddlDepartment.Items.Clear();
                    this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));

                    this.ddlFinalPaymentInv.Items.Clear();
                    this.ddlFinalPaymentInv.Items.Insert(0, new ListItem("Choose...", "0"));

                    #region "Comment Out"
                    //dtpTo.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    //dtpFrom.Value = DateTime.Now.ToString("dd/MM/yyyy");

                    // check the current user have rights to access to the page
                    //if (new Common().GetPageAccessPermission(LoingName, PageNames.PaymentReport, 1) == false)
                    //{
                    //    // check the current user have rights to access to the page
                    //    if (new Common().GetPageAccessPermission(LoingName, PageNames.PaymentReport) == false)
                    //    {
                    //        Response.Redirect("../Dashboard/Error/Error.aspx?Key=PageRightsDenied", true);
                    //    }
                    //}
                    #endregion

                    /// Restrict dropdown
                    this.DropDownRestriction();

                }

            }

            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        #region "Dropdown Events"
        protected void ddlOrganization_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlOrganization.SelectedIndex > 0)
            {
                BindDepartments(Convert.ToInt32(ddlOrganization.SelectedItem.Value));
            }
            else
            {
                //this.ddlCampaign.Items.Clear();
                //this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));

                this.ddlDepartment.Items.Clear();
                this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
            }
            ddlDepartment.Focus();
        }

        protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (ddlDepartment.SelectedIndex > 0)
            {

                BindPaymentInvoices(Convert.ToInt32(ddlOrganization.SelectedItem.Value), Convert.ToInt32(ddlDepartment.SelectedItem.Value));
            }
            else
            {
                this.ddlFinalPaymentInv.Items.Clear();
                this.ddlFinalPaymentInv.Items.Insert(0, new ListItem("Choose...", "0"));
            }

            ddlFinalPaymentInv.Focus();


            //int? deptID;
            //if (ddlDepartment.SelectedIndex > 0)
            //    deptID = Convert.ToInt32(ddlOrganization.SelectedItem.Value);

            //if (ddlDepartment.SelectedIndex > 0)
            //{
            // //   BindSMSCampaigns(Convert.ToInt32(ddlOrganization.SelectedItem.Value), CurrentUser.LoginID, Convert.ToInt32(ddlDepartment.SelectedItem.Value));
            //}
            //else
            //{
            //    //this.ddlCampaign.Items.Clear();
            //    //this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
            //}

            // ddlCampaign.Focus();
        }


        #endregion

        #region "Bind Dropdowns"

        /// <summary>
        /// Bind Department 
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindDepartments(int organizationID)
        {
            try
            {
                ddlDepartment.Items.Clear();


                if (CurrentUser.OrganizationID > 0)
                {
                    //this.ddlDepartment.DataSource = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);//.Where (p=>p.Status==true).ToList ();
                    this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);//.Where (p=>p.Status==true).ToList ();
                }
                else
                {
                    //this.ddlDepartment.DataSource = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(organizationID);
                    this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.SelectActiveDepartmentsByOrgID(organizationID);
                }

                this.ddlDepartment.DataTextField = "Title";
                this.ddlDepartment.DataValueField = "DepartmentID";
                this.ddlDepartment.DataBind();
                ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindDepartments", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }


        ///// <summary>
        ///// Bind SMSCampaigns
        ///// </summary>
        ///// <param name="organizationID"></param>
        //public void BindSMSCampaigns(int? organizationID, int? userID, int deptID)
        //{
        //    try
        //    {
        //        ddlCampaign.Items.Clear();

        //        if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID > 0)
        //        {
        //            int? deptId = null;
        //            //deptId = CurrentUser.DepartmentID ?? deptID ;
        //            if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
        //                this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
        //            else
        //                this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptId, null);
        //        }
        //        else
        //        {
        //            //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetAllCampaingsInfo(organizationID);
        //            this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
        //        }

        //        this.ddlCampaign.DataTextField = "Title";
        //        this.ddlCampaign.DataValueField = "CampaignID";
        //        this.ddlCampaign.DataBind();

        //        ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
        //    }
        //    catch (Exception ex)
        //    {
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindSMSCampaigns", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
        //        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
        //    }
        //}

        /// <summary>
        /// Bind Organization
        /// </summary>
        public void BindOrganizations(int? userID)
        {
            ddlOrganization.Items.Clear();
            //this.ddlOrganization.DataSource = new OrganizationBLL().SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataSource = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataTextField = "Title";
            this.ddlOrganization.DataValueField = "ID";
            this.ddlOrganization.DataBind();
            ddlOrganization.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        private void BindPaymentInvoices(int orgID, int deptID)
        {

            try
            {
                ddlFinalPaymentInv.Items.Clear();
                //this.ddlFinalPaymentInv.DataSource = new FinalPaymentInvoiceBLL().GetFinalPaymentInvoiceTitles(orgID, deptID);
                this.ddlFinalPaymentInv.DataSource = LazySingletonBLL<FinalPaymentInvoiceBLL>.Instance.GetFinalPaymentInvoiceTitles(orgID, deptID);
                this.ddlFinalPaymentInv.DataTextField = "PaymentInvoiceTitle";
                this.ddlFinalPaymentInv.DataValueField = "ID";
                this.ddlFinalPaymentInv.DataBind();

                ddlFinalPaymentInv.Items.Insert(0, new ListItem("Choose...", "0"));
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "BindPaymentInvoices", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        #endregion

        #region "Cutom Method"



        /// <summary>
        /// Restrict dropdown
        /// </summary>
        private void DropDownRestriction()
        {
            if (CurrentUser.OrganizationID > 0)
            {
                //ddlOrganization.Items.FindByValue(CurrentUser.OrganizationID.ToString()).Selected = true;
                this.ddlOrganization.SelectedValue = CurrentUser.OrganizationID.Value.ToString();
                this.ddlOrganization_SelectedIndexChanged("", null);
                this.ddlOrganization.Enabled = false;
            }

            if (CurrentUser.DepartmentID > 0)
            {
                //this.ddlDepartment.Items.FindByValue(CurrentUser.DepartmentID.ToString()).Selected = true;
                this.ddlDepartment.SelectedValue = CurrentUser.DepartmentID.Value.ToString();
                this.ddlDepartment_SelectedIndexChanged("", null);
                this.ddlDepartment.Enabled = false;
            }

        }

        /// <summary>
        /// Show the  report on the basis of filter Criteria
        /// </summary>
        private void ShowReport()
        {
            UserModel currentUser = CurrentUser.GetSessionUserInfo();


            try
            {
                if (ddlOrganization.SelectedIndex > 0 && ddlFinalPaymentInv.SelectedIndex > 0)
                {
                    SMS.CMP.UserControl.Reports.ucReportViewer viewer = (SMS.CMP.UserControl.Reports.ucReportViewer)this.ucReportViewer1;

                    viewer.ReportName = ReportNames.CampaignsPaymentReport;

                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();


                    //string OrganizationCode =  new OrganizationBLL().GetOrganization(Convert.ToInt32(this.ddlOrganization.SelectedValue)).Select(p=>p.Code).FirstOrDefault ();
                    //string DepartmentCode = new DepartmentsBLL().GetDepartments().Where(p => p.OrganizationID == Convert.ToInt32(this.ddlOrganization.SelectedValue) && p.Status==true).Select(p => p.Code).FirstOrDefault();
                    string FinaltPaymentInvoiceNo = !string.IsNullOrEmpty(this.ddlFinalPaymentInv.SelectedItem.Text.Split('(')[0]) ? this.ddlFinalPaymentInv.SelectedItem.Text.Split('(')[0].ToString() : "";

                    //string FinaltPaymentInvoiceNo = new FinalPaymentInvoiceBLL().GetFinalPaymentInvoiceTitles(Convert.ToInt32(this.ddlOrganization.SelectedValue), Convert.ToInt32(this.ddlDepartment.SelectedValue)).Where(p => p.ID == Convert.ToInt32(this.ddlFinalPaymentInv.SelectedValue)).FirstOrDefault().FinalPaymentInvoiceNo;

                    //parameters.Add(new ReportParameter("OrganizationCode", OrganizationCode));
                    //parameters.Add(new ReportParameter("DepartmentCode", DepartmentCode));

                    //if (ddlCampaign.SelectedValue != null && ddlCampaign.SelectedValue != "0")
                    //    parameters.Add(new ReportParameter("Campaign", this.ddlCampaign.SelectedItem.Text));


                    parameters.Add(new ReportParameter("Department", this.ddlDepartment.SelectedItem.Text));

                    //parameters.Add(new ReportParameter("FromDate", new Common().ConvertDateFormat(dtpFrom.Value).ToString()));
                    //parameters.Add(new ReportParameter("ToDate", new Common().ConvertDateFormat(dtpTo.Value).ToString()));

                    parameters.Add(new ReportParameter("UserName", currentUser.EmployeeName));
                    // parameters.Add(new ReportParameter("CampaignID", this.ddlCampaign.SelectedItem.Value));
                    parameters.Add(new ReportParameter("Organization", this.ddlOrganization.SelectedItem.Text));

                    parameters.Add(new ReportParameter("PaymentInvoiceNo", FinaltPaymentInvoiceNo));

                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsPayment", GetReportDataTable(parameters, currentUser)));

                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "ShowReport", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, UserModel currentUser)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                #region "Selection Criteria"
                //int? CampaignID = null;
                //    if (ddlCampaign.SelectedIndex > 0) CampaignID  = Convert.ToInt32(ddlCampaign.SelectedValue);

                int OrganizationID = Convert.ToInt32(ddlOrganization.SelectedValue);
                int DepartmentID = Convert.ToInt32(ddlDepartment.SelectedValue);

                int? userID = null;

                if (currentUser.OrganizationID.HasValue && currentUser.OrganizationID > 0)
                    userID = currentUser.UserID ?? null;

                //DateTime FromDate = new Common().ConvertDateFormat(dtpFrom.Value);
                //DateTime ToDate = new Common().ConvertDateFormat(dtpTo.Value);

                //int paymentMode = Convert.ToInt32(rbModes.SelectedItem.Value);
                int paymentMode = 0;
                int FinPaymentInvoiceID = Convert.ToInt32(ddlFinalPaymentInv.SelectedItem.Value);

                List<InvoiceModel> invoices = LazySingletonBLL<InvoiceBLL>.Instance.GetPaymentInvoice(OrganizationID, paymentMode, FinPaymentInvoiceID).ToList();

                dt = Common.ToDataTable((from invoice in invoices

                                         select new
                                         {
                                             invoice.PaymentInvoiceID,
                                             invoice.OrganizationID,
                                             invoice.OrganizationCode,
                                             invoice.Organization,
                                             invoice.CampaignID,
                                             invoice.Campaign,
                                             invoice.DateofInvoice,
                                             invoice.FinalDateofInvoice,
                                             invoice.PayableAmount,
                                             invoice.PaidAmount,
                                             invoice.Mode,
                                             invoice.Quantity,
                                             invoice.NoOfMessage,
                                             invoice.Rate,
                                             invoice.ShortCodeOrMask,
                                             invoice.TotalAmount

                                         }).ToList());


                if (dt.Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

                #endregion
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetReportDataTable", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);

            }
            return dt;
        }

        #endregion

        #region "Button Click Events"
        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
                //pnlError.Visible = false;
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", 0, PageNames.PaymentReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }
        #endregion

        //protected void ddlCampaign_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //    if (ddlCampaign.SelectedIndex > 0)
        //    {

        //        BindPaymentInvoices(Convert.ToInt32(ddlCampaign.SelectedItem.Value));
        //    }
        //    else
        //    {
        //        this.ddlFinalPaymentInv.Items.Clear();
        //        this.ddlFinalPaymentInv.Items.Insert(0, new ListItem("Choose...", "0"));
        //    }

        //    ddlFinalPaymentInv.Focus();

        //}
    }
}