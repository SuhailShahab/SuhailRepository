﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using Microsoft.Reporting.WebForms;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.CustomEnums;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{
    public partial class APICampaignReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string LoingName = CurrentUser.LoginName;

            try
            {
                if (!IsPostBack)
                {
                    BindOrganizations(CurrentUser.LoginID);

                    /*if (CurrentUser.OrganizationID == 0 && CurrentUser.DepartmentID == 0)
                    {
                        divStatuses.Visible = true;
                        divrdbStatus.Visible = false;
                        BindSMSDeliveryStatusList();
                    }
                    else
                    {
                        divStatuses.Visible = false;
                        divrdbStatus.Visible = true;
                    }*/


                    BindSMSDeliveryStatusList(Convert.ToInt16(CurrentUser.LoginID));
                    if (chkSMSDeliveryStatusList.Items.Count > 1)
                    {
                        divStatuses.Visible = true;
                        divrdbStatus.Visible = false;
                    }
                    else
                    {
                        divStatuses.Visible = false;
                        divrdbStatus.Visible = true;
                    }

                    this.ddlCampaign.Items.Clear();
                    this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
                    this.ddlDepartment.Items.Clear();
                    this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));


                    /// Restrict dropdown
                    this.DropDownRestriction();
                }

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.APICampaignReport, CurrentUser.GetSessionUserInfo()));
            }
        }


        #region "Button Click Events"

        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtpFrom.Value != "" && dtpTo.Value != "")
                {
                    DateTime startDate = DateTime.ParseExact(dtpFrom.Value, "dd/MM/yyyy", null);
                    DateTime endDate = DateTime.ParseExact(dtpTo.Value, "dd/MM/yyyy", null);

                    if (DateTime.ParseExact(dtpFrom.Value, "dd/MM/yyyy", null) <= DateTime.ParseExact(dtpTo.Value, "dd/MM/yyyy", null))
                    {
                        ShowReport();
                    }
                    else
                    {
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "invalidSelction", "toastr.error('From Date should be less than To Date');", true);
                    }
                }
                else
                {
                    ShowReport();
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", 0, PageNames.APICampaignReport, CurrentUser.GetSessionUserInfo()));
            }
        }

        #endregion

        #region "Dropdown Events"

        protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlDepartment.SelectedIndex > 0)
            {
                BindSMSCampaigns(Convert.ToInt32(ddlOrganization.SelectedItem.Value), CurrentUser.LoginID, Convert.ToInt32(ddlDepartment.SelectedItem.Value));
            }
            else
            {
                this.ddlCampaign.Items.Clear();
                this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
            }

            ddlCampaign.Focus();
        }

        protected void ddlOrganization_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlOrganization.SelectedIndex > 0)
            {
                BindDepartment(Convert.ToInt32(ddlOrganization.SelectedItem.Value));
            }
            else
            {
                this.ddlCampaign.Items.Clear();
                this.ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));

                this.ddlDepartment.Items.Clear();
                this.ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
            }

            ddlOrganization.Focus();
        }

        #endregion

        #region "Bind Dropdowns"

        /// <summary>
        /// Bind SMSCampaigns
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindSMSCampaigns(int? organizationID, int? userID, int deptID)
        {
            ddlCampaign.Items.Clear();
            if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID > 0)
            {
                int? deptId = null;
                if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
                {
                    //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
                    this.ddlCampaign.DataSource = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, deptID, null);
                }
                else
                {
                    this.ddlCampaign.DataSource = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, deptId, null);
                }
            }
            else
            {
                //this.ddlCampaign.DataSource = new SMSCampaignBLL().GetCampaings(organizationID, deptID, null);
                this.ddlCampaign.DataSource = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, deptID, null);
            }

            this.ddlCampaign.DataTextField = "Title";
            this.ddlCampaign.DataValueField = "CampaignID";
            this.ddlCampaign.DataBind();

            ddlCampaign.Items.Insert(0, new ListItem("Choose...", "0"));
        }



        /// <summary>
        /// Bind BindDepartment
        /// </summary>
        /// <param name="organizationID"></param>
        public void BindDepartment(int? organizationID)
        {
            ddlDepartment.Items.Clear();

            if (organizationID.HasValue && organizationID > 0)
            {
                //this.ddlDepartment.DataSource = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
            }
            else
            {
                //this.ddlDepartment.DataSource = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(organizationID.Value);
                this.ddlDepartment.DataSource = LazySingletonBLL<DepartmentsBLL>.Instance.SelectActiveDepartmentsByOrgID(organizationID.Value);
            }

            this.ddlDepartment.DataTextField = "Title";
            this.ddlDepartment.DataValueField = "DepartmentID";
            this.ddlDepartment.DataBind();
            ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        /// <summary>
        /// Bind Organization
        /// </summary>
        public void BindOrganizations(int? userID)
        {
            ddlOrganization.Items.Clear();
            //this.ddlOrganization.DataSource = new OrganizationBLL().SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataSource = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(userID.Value);
            this.ddlOrganization.DataTextField = "Title";
            this.ddlOrganization.DataValueField = "ID";
            this.ddlOrganization.DataBind();
            ddlOrganization.Items.Insert(0, new ListItem("Choose...", "0"));
        }


        /// <summary>
        /// Get SMS Delivery StatusList
        /// </summary>
        public void BindSMSDeliveryStatusList(int userID)
        {
            chkSMSDeliveryStatusList.Items.Clear();
            //this.chkSMSDeliveryStatusList.DataSource = new SMSDeliveryStatusBLL().GetAllSMSDeliveryStatusByUserID(userID);
            this.chkSMSDeliveryStatusList.DataSource = LazySingletonBLL<SMSDeliveryStatusBLL>.Instance.GetAllSMSDeliveryStatusByUserID(userID);
            this.chkSMSDeliveryStatusList.DataTextField = "Title";
            this.chkSMSDeliveryStatusList.DataValueField = "ID";
            this.chkSMSDeliveryStatusList.DataBind();
            this.chkSMSDeliveryStatusList.Items.Insert(0, new ListItem("Select All", "0"));
        }


        #endregion

        # region Custom Methods
        /// <summary>
        /// Restrict dropdown
        /// </summary>
        private void DropDownRestriction()
        {
            if (CurrentUser.OrganizationID > 0)
            {
                //ddlOrganization.Items.FindByValue(CurrentUser.OrganizationID.ToString()).Selected = true;
                this.ddlOrganization.SelectedValue = CurrentUser.OrganizationID.Value.ToString();
                this.ddlOrganization_SelectedIndexChanged("", null);
                this.ddlOrganization.Enabled = false;
            }

            if (CurrentUser.DepartmentID > 0)
            {
                //this.ddlDepartment.Items.FindByValue(CurrentUser.DepartmentID.ToString()).Selected = true;
                this.ddlDepartment.SelectedValue = CurrentUser.DepartmentID.Value.ToString();
                this.ddlDepartment_SelectedIndexChanged("", null);
                this.ddlDepartment.Enabled = false;
            }

        }
        private void ShowReport()
        {
            UserModel currentUser = CurrentUser.GetSessionUserInfo();
            try
            {
                if (ddlOrganization.SelectedIndex > 0 && ddlCampaign.SelectedIndex > 0)
                {
                    SMS.CMP.UserControl.Reports.ucReportViewer viewer = (SMS.CMP.UserControl.Reports.ucReportViewer)this.ucReportViewer1;

                    if (rbtGeneric.Checked == true)
                        viewer.ReportName = ReportNames.APICampaignReport;
                    else
                        viewer.ReportName = ReportNames.APICampaignReportSMS;

                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();


                    if (ddlCampaign.SelectedValue != null && ddlCampaign.SelectedValue != "0")
                        parameters.Add(new ReportParameter("Campaign", this.ddlCampaign.SelectedItem.Text));



                    parameters.Add(new ReportParameter("UserName", currentUser.EmployeeName));
                    parameters.Add(new ReportParameter("Organization", this.ddlOrganization.SelectedItem.Text));
                    parameters.Add(new ReportParameter("Department", this.ddlDepartment.SelectedItem.Text));



                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsSMSCampaign", GetReportDataTable(parameters, currentUser)));

                    viewer.DataSourceList = datasources;

                    // add the parameters
                    if (chkDate.Checked)
                    {
                        parameters.Add(new ReportParameter("DateFrom", dtpFrom.Value));
                        parameters.Add(new ReportParameter("DateTo", dtpTo.Value));

                    }
                    else
                    {
                        parameters.Add(new ReportParameter("DateFrom", ""));
                        parameters.Add(new ReportParameter("DateTo", ""));
                    }

                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                }

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "ShowReport", 0, PageNames.APICampaignReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, UserModel currentUser)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                #region "Selection Criteria"
                int CampaignID = Convert.ToInt32(ddlCampaign.SelectedValue);
                int mode = 1;
                int? userID = null;
                string dtFrom = "";
                string dtTo = "";

                /*
                int status = 0;
                
                if (rbtStatuses.SelectedValue == SMSDeliveryStatuses.DeliverySuccess.GetHashCode().ToString())
                    status = 1;
                else if (rbtStatuses.SelectedValue == SMSDeliveryStatuses.DeliveryFailure.GetHashCode().ToString())
                    status = 2;
                */


                List<string> selectedItemList = new List<string>();
                foreach (ListItem item in chkSMSDeliveryStatusList.Items)
                {
                    //status = -1;
                    if (item.Selected && Convert.ToInt32(item.Value) > 0)
                    {
                        selectedItemList.Add(item.Value);
                    }
                }

                string filterdListCSV = string.Join(",", selectedItemList);


                string phoneNo = txtPhoneNo.Text;

                if (currentUser.OrganizationID.HasValue && currentUser.OrganizationID > 0)
                    userID = currentUser.UserID ?? null;

                if (chkDate.Checked)
                {
                    dtFrom = dtpFrom.Value;
                    dtTo = dtpTo.Value;
                }
                else
                {
                    dtFrom = "";
                    dtTo = "";
                }

                List<SMSTransactionModel> smsTransactions = LazySingletonBLL<SMSTransactionBLL>.Instance.GetTransactionsByCampaignID(CampaignID, mode, filterdListCSV, phoneNo, Convert.ToInt32(rbtStatuses.SelectedValue), dtFrom, dtTo);
                //List<SMSTransactionModel> smsTransactions = smsTransactionsTemp.Where(s => s.CampaignID == CampaignID).ToList();

                dt = Common.ToDataTable((from transaction in smsTransactions
                                         select new
                                         {
                                             transaction.SMSTransactionID,
                                             transaction.ShortCode,
                                             //transaction.SendMessage,
                                             SendMessage = "",
                                             transaction.ContactNo,
                                             transaction.DeliveryStatusID,
                                             transaction.SendingDate,
                                             transaction.DeliveredDate,
                                             transaction.SMSSendingStatus,
                                             transaction.MessageText,

                                         }).ToList());


                if (dt.Rows.Count > 0)
                {
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                    parameters.Add(new ReportParameter("CampaignMessage", ""));
                }
                else
                {
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));
                    parameters.Add(new ReportParameter("CampaignMessage", ""));
                }
                dt.TableName = "tblSMSTransaction";

                #endregion
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode= LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetReportDataTable", 0, PageNames.APICampaignReport, CurrentUser.GetSessionUserInfo()));
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode) + "')", true);
                    throw new Exception(ConfigurationHelper.GeneralMsg  + errorCode);// new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + Common.RemoveEscapeCharacters(ex.Message) + "')", true);
                    throw ex;
                }
                
            }
            return dt;
        }

        # endregion

    }
}