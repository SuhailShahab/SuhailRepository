﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.APIClasses;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{

    // =================================================================================================================================
    // Create by:	<Atif Farroq>
    // Create date: <19-10-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // 001          Sued Zeeshan Aqil           19-Nov- 2015 12:30 PM       Add Method  GetSMSSendMessage to get Message
    // CR:002       Sajjad Aslam                15-MAR-2017 02:50 PM        update method GetRecords, load data on filter base
    // =================================================================================================================================


    public partial class SMSCampaignLogs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.DataBind();
        }

        [WebMethod]
        public static SMSCampaignLogViewModel GetRecords(string organizationID, string departmentID, string jsonModel, string searchText, bool isLoad)
        {
            SMSCampaignLogViewModel model = new SMSCampaignLogViewModel();
            List<SMSCampaignLog> campainsList = null;

            try
            {

                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    model = new JavaScriptSerializer().Deserialize<SMSCampaignLogViewModel>(jsonModel);
                }
                else
                {
                    model = new SMSCampaignLogViewModel();
                    model.PageNo = 1;
                }

                model.PageSize = PageSize;


                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                model.User = User;

                // Get Organization
                if (!isLoad)
                {
                    List<OrganizationModel> organizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(CurrentUser.LoginID.Value);
                    if (organizations != null && organizations.Count > 0)
                        model.Organizations = organizations;
                }

                SMSCampaignLog smsCampaignLogModel = new SMSCampaignLog();
                smsCampaignLogModel.UserID = CurrentUser.LoginID;

                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    smsCampaignLogModel.OrganizationID = CurrentUser.OrganizationID;
                    smsCampaignLogModel.DepartmentID = CurrentUser.DepartmentID;
                    // smsCampaignLogModel.UserID = CurrentUser.LoginID;
                    // model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(smsCampaignLogModel.DepartmentID.Value, smsCampaignLogModel.UserID.Value);
                    if (!string.IsNullOrEmpty(searchText))
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(smsCampaignLogModel, model.PageNo, model.PageSize, searchText);
                    else
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(smsCampaignLogModel, model.PageNo, model.PageSize);
                    // campainsList = new SMSCampaignBLL().GetAllCampaign(smsCampaignLogModel, model.PageNo, model.PageSize);
                }
                else if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID == 0 && isLoad == true)
                {
                    smsCampaignLogModel.OrganizationID = CurrentUser.OrganizationID;
                    smsCampaignLogModel.DepartmentID = Convert.ToInt32(departmentID);
                    //model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(CurrentUser.OrganizationID.Value, CurrentUser.LoginID.Value);
                    if (!string.IsNullOrEmpty(searchText))
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(smsCampaignLogModel, model.PageNo, model.PageSize, searchText);
                    else
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(smsCampaignLogModel, model.PageNo, model.PageSize);

                }
                else if (isLoad == true)
                {
                    smsCampaignLogModel.OrganizationID = Convert.ToInt32(organizationID);
                    smsCampaignLogModel.DepartmentID = Convert.ToInt32(departmentID);
                    if (!string.IsNullOrEmpty(searchText))
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(smsCampaignLogModel, model.PageNo, model.PageSize, searchText);
                    else
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(smsCampaignLogModel, model.PageNo, model.PageSize);
                }
                

                if (campainsList != null && campainsList.Count > 0)
                {
                    model.SMSCampaignLogs = campainsList;
                    model.TotalCount = campainsList[0].RESULT_COUNT.Value;

                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.SMSCampaignsLog, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }
            }
            return model;
        }

       
        



        /// <summary>
        /// get Department By Organization ID
        /// </summary>
        /// <returns>Department List</returns>
        [WebMethod]
        public static SMSCampaignLogViewModel GetDepartments(string organizationID)
        {
            SMSCampaignLogViewModel model = new SMSCampaignLogViewModel();
            List<DepartmentsModel> departments = null;
            try
            {
                departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                if (departments != null && departments.Count > 0)
                    model.Departments = departments;
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode= LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 0, PageNames.SMSCampaignsLog, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }

            }
            return model;
        }

        /// <summary>
        /// Get Campaign Log Data from Campaign Trasaction
        /// </summary>
        /// <param name="campaignID">Selected Campaign ID</param>
        /// <param name="organizationID">Selected Organization ID</param>
        /// <param name="pageNo">Selected Page No</param>
        /// <param name="searchText">Given Search Value</param>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignLogViewModel GetRecordsByID(string campaignID, string organizationID, string pageNo, string searchText, string showStatus,string fromDate, string toDate)
        {

            SMSCampaignLogViewModel model = new SMSCampaignLogViewModel();

            try
            {


                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                int PageNo = Convert.ToInt32(pageNo);
                if (PageNo != 0)
                {
                    model.TPageNo = PageNo;
                }
                else
                {
                    model.TPageNo = 1;
                }

                model.TPageSize = PageSize;
                //string fromDate = DateTime.Today.AddDays(-7).ToString("M/dd/yyyy");
                //string toDate = DateTime.Today.ToString("M/dd/yyyy");
                //fromDate = toDate;
                //List<SMSTransactionModel> transections = null;
                if (!string.IsNullOrEmpty(searchText))
                    model = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaingsByID(Convert.ToInt32(campaignID), model.TPageNo, model.TPageSize, searchText, model, Convert.ToInt32(showStatus), fromDate, toDate);
                else
                    model = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaingsByID(Convert.ToInt32(campaignID), model.TPageNo, model.TPageSize, model, Convert.ToInt32(showStatus), fromDate, toDate);

                //if (transections != null && transections.Count > 0)
                //{
                //    model.Transactions = transections;
                //    model.TTotalCount = transections[0].RESULT_COUNT.Value;
                //}


            }

            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode =LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordsByID", 1, PageNames.SMSCampaignsLog, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }
            }

            return model;
        }


        /// <summary>
        /// Send SMS of a Campaign
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignModel SendCampaign(string jsonModel)
        {
            SMSCampaignModel smsCampaign = null;
            bool checkval = false;
            try
            {
                smsCampaign = new JavaScriptSerializer().Deserialize<SMSCampaignModel>(jsonModel);
                //checkval = new Common().SendRequest(smsCampaign.OrganizationID.Value, smsCampaign.CampaignID.Value);
                checkval = LazySingletonBLL<Common>.Instance.SendRequest(smsCampaign.OrganizationID.Value, smsCampaign.CampaignID.Value);

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SendCampaign", 0, PageNames.SMSCampaignsLog, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(smsCampaign, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(smsCampaign, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(smsCampaign, ex.Message);
                }
            }
            return smsCampaign;
        }

        /// <summary>
        /// Get Customer Responses
        /// </summary>
        /// <param name="campaignID"></param>
        /// <param name="phoneNo"></param>
        /// <returns></returns>
        [WebMethod]
        public static CustomerResponseViewModel GetCustomerResponse(string campaignID, string phoneNo)
        {
            CustomerResponseViewModel model = new CustomerResponseViewModel();
            try
            {
                if (!string.IsNullOrEmpty(phoneNo) && !string.IsNullOrEmpty(campaignID))
                {
                    if (!phoneNo.Contains("+92"))
                    {
                        phoneNo = new JavaScriptSerializer().Deserialize<string>(phoneNo);
                        phoneNo = "92" + phoneNo.Substring(1);
                        // string removeZero = phoneNo.Substring(2);
                        //phoneNo = "923334352056"; //"92" + phoneNo.Substring(2);
                    }
                    model.CustomerResponces = LazySingletonBLL<CustomerResponseBLL>.Instance.GetCustoermResponses(Convert.ToInt32(campaignID), phoneNo);

                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode= LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetCustomerResponse", 1, PageNames.SMSCampaignsLog, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }
            }
            return model;
        }


        /// <summary>
        /// Get Sending Message from Trasaction 
        /// 001 
        /// </summary>
        /// <param name="transactionID">Selected transaction ID</param>
        /// <returns>Transaction Model</returns>
        [WebMethod]
        public static SMSTransactionModel GetSMSSendMessage(string transactionID)
        {
            SMSTransactionModel model = null;
            try
            {
                model = new SMSTransactionModel();
                model.SendMessage = LazySingletonBLL<SMSCampaignBLL>.Instance.GetSMSSendMessage(Convert.ToInt32(transactionID));

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetSMSSendMessage", 1, PageNames.SMSApiLog, CurrentUser.GetSessionUserInfo()));
                //  LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }
            }

            return model;
        }
    }
}