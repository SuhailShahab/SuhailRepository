﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using SMS.CMPService.ApplicationClassess;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.Reoprts
{

// =================================================================================================================================
// Create by:	<Atif Farroq>
// Create date: <19-10-2015 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR:001       Syed Zeeshan Aqil           19-Nov- 2015 12:30 PM       Add Method  GetSMSSendMessage to get Message
// CR:002       Sajjad Aslam                15-MAR-2017 01:00 PM        update method GetRecords, load data on filter base
// =================================================================================================================================
    public partial class SMSApiLogs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Old Code"
        /*
        [WebMethod]
        public static SMSCampaignLogViewModel GetRecords(string organizationID, string departmentID, string pageNo, string searchText, bool isLoad)
        {
            SMSCampaignLogViewModel model = null; //  new SMSCampaignLogViewModel();
            List<SMSCampaignLog> smsCampaignModelList = new List<SMSCampaignLog>();

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                model = new SMSCampaignLogViewModel();
                int PageNo = Convert.ToInt32(pageNo);
                if (PageNo != 0)
                {
                    model.PageNo = PageNo;
                }
                else
                {
                    model.PageNo = 1;
                }

                model.PageSize = PageSize;

                // Fill Model
                SMSCampaignLog log = new SMSCampaignLog();


                UserModel User = new UserModel();

                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                model.User = User;

                List<SMSCampaignLog> campainsList = null;
                // Get Organization
                List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                if (organizations != null && organizations.Count > 0)
                    model.Organizations = organizations;

                // user Drop Down seletion By User Rights
                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    log.OrganizationID = CurrentUser.OrganizationID;
                    log.DepartmentID = CurrentUser.DepartmentID;
                    log.UserID = CurrentUser.LoginID;
                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(log.DepartmentID.Value, log.UserID.Value);

                    if (!string.IsNullOrEmpty(searchText))
                        campainsList = new SMSCampaignBLL().GetAllCampaign(log, model.PageNo, model.PageSize, searchText);
                    else
                        campainsList = new SMSCampaignBLL().GetAllCampaign(log, model.PageNo, model.PageSize);
                }
                else if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID == 0)
                {
                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);

                }
                else
                {



                    log.OrganizationID = Convert.ToInt32(organizationID);
                    log.DepartmentID = Convert.ToInt32(departmentID);
                    if (log.OrganizationID.Value > 0 && log.DepartmentID.Value > 0)
                    {

                        model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(log.OrganizationID.Value, CurrentUser.LoginID.Value);

                        if (!string.IsNullOrEmpty(searchText))
                            campainsList = new SMSCampaignBLL().GetAllCampaign(log, model.PageNo, model.PageSize, searchText);
                        else
                            campainsList = new SMSCampaignBLL().GetAllCampaign(log, model.PageNo, model.PageSize);



                    }
                    else if (isLoad == true)
                    {
                        log.UserID = CurrentUser.LoginID;

                        if (!string.IsNullOrEmpty(searchText))
                            campainsList = new SMSCampaignBLL().GetAllCampaign(log, model.PageNo, model.PageSize, searchText);
                        else
                            campainsList = new SMSCampaignBLL().GetAllCampaign(log, model.PageNo, model.PageSize);
                    }
                }

                if (campainsList != null && campainsList.Count > 0)
                {
                    model.SMSCampaignLogs = campainsList;

                    model.TotalCount = campainsList[0].RESULT_COUNT.Value;
                }


            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.SMSApiLog, CurrentUser.GetSessionUserInfo()));
                LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
            }
            return model;
        }
         */
        #endregion 

        [WebMethod]
        public static SMSCampaignLogViewModel GetRecords(string organizationID, string departmentID, string pageNo, string searchText, bool isLoad)
        {
            SMSCampaignLogViewModel model = new SMSCampaignLogViewModel(); 

            try
            {
                 #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                model = new SMSCampaignLogViewModel();
                int PageNo = Convert.ToInt32(pageNo);
                if (PageNo != 0)
                {
                    model.PageNo = PageNo;
                }
                else
                {
                    model.PageNo = 1;
                }

                model.PageSize = PageSize;

                // Fill Model
                SMSCampaignLog log = new SMSCampaignLog();
                log.UserID = CurrentUser.LoginID;
                //log.Users
                UserModel User = new UserModel();

                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                model.User = User;
              
                List<SMSCampaignLog> campainsList = null;
               
                if (!isLoad)
                {
                    List<OrganizationModel> organizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(CurrentUser.LoginID.Value);
                    if (organizations != null && organizations.Count > 0)
                        model.Organizations = organizations;
                }
               

                // user Drop Down seletion By User Rights
                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    log.OrganizationID = CurrentUser.OrganizationID;
                    log.DepartmentID = CurrentUser.DepartmentID;
                     if (!string.IsNullOrEmpty(searchText))
                       campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(log, model.PageNo, model.PageSize, searchText);
                    else
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(log, model.PageNo, model.PageSize);
                }
                else if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID == 0 && isLoad == true)
                {
                    // 
                    log.OrganizationID = CurrentUser.OrganizationID;
                    log.DepartmentID = Convert.ToInt32(departmentID);
                    if (!string.IsNullOrEmpty(searchText))
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(log, model.PageNo, model.PageSize, searchText);
                    else
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(log, model.PageNo, model.PageSize);
                }
                else if (isLoad == true)
                {
                    log.OrganizationID = Convert.ToInt32(organizationID);
                    log.DepartmentID = Convert.ToInt32(departmentID);
                
                    if (!string.IsNullOrEmpty(searchText))
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(log, model.PageNo, model.PageSize, searchText);
                    else
                        campainsList = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaign(log, model.PageNo, model.PageSize);
                }
              

                if (campainsList != null && campainsList.Count > 0)
                {
                    model.SMSCampaignLogs = campainsList;

                    model.TotalCount = campainsList[0].RESULT_COUNT.Value;
                }

              
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.SMSApiLog, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }
                
               
            }
            return model;
        }

        /// <summary>
        /// get Department By Organization ID
        /// </summary>
        /// <returns>Department List</returns>
        [WebMethod]
        public static SMSCampaignLogViewModel GetDepartments(string organizationID)
        {
            SMSCampaignLogViewModel model = new SMSCampaignLogViewModel();
            List<DepartmentsModel> departments = null;
            try
            {
                departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                if (departments != null && departments.Count > 0)
                    model.Departments = departments;
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs (new ErrorLogModel(ex, "GetDepartments", 0, PageNames.SMSApiLog, CurrentUser.GetSessionUserInfo()));
               // LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }

            }
            return model;
        }

        /// <summary>
        /// Get Api Log of Sms Campaing List
        /// </summary>
        /// <param name="campaignID">Selected Campaign ID</param>
        /// <param name="organizationID">Slected Organization ID</param>
        /// <param name="pageNo">Selected Page Number</param>
        /// <param name="searchText">Search Data</param>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignLogViewModel GetRecordsByID(string campaignID, string organizationID, string pageNo, string searchText, string showStatus, string fromDate, string toDate)
        {
            string endcodedIDs = "";


            SMSCampaignLogViewModel model = null; //= new SMSCampaignLogViewModel();

            //string fromDate = DateTime.Today.AddDays(-7).ToString("M/dd/yyyy");
            //string toDate = DateTime.Today.ToString("M/dd/yyyy");

            //string fromDate = DateTime.Today.AddDays(-7).ToString("M/dd/yyyy"); 
            //string toDate = DateTime.Today.ToString("M/dd/yyyy");
            try
            {

                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                model = new SMSCampaignLogViewModel();
                int PageNo = Convert.ToInt32(pageNo);
                if (PageNo != 0)
                {
                    model.TPageNo = PageNo;
                }
                else
                {
                    model.TPageNo = 1;
                }

                model.TPageSize = PageSize;

                if (showStatus == "1")
                {
                    endcodedIDs = CustomSecurity.EncodePasswordToBase64(campaignID) + "/" + CustomSecurity.EncodePasswordToBase64(organizationID);
                    String ApiURL = "(' " + "http://sms.punjab.gov.pk/api/cmpservice.svc/sendsmsdata/" + endcodedIDs + "/0333*******/SMS Message" + " ')";
                    model.APIUrl = ApiURL;
                    String ApiURL2 = "(' " + "http://sms.punjab.gov.pk/api/cmpservice.svc/smssend/" + endcodedIDs + "/en" + "/0333*******/SMS Message" + " ')";
                    model.APIUrl2 = ApiURL2;
                }


                if (!string.IsNullOrEmpty(searchText))
                    model = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllApiLogByID(Convert.ToInt32(campaignID), model.TPageNo, model.TPageSize, searchText, model, Convert.ToInt32(showStatus), fromDate, toDate);
                else
                    model = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllApiLogByID(Convert.ToInt32(campaignID), model.TPageNo, model.TPageSize, model, Convert.ToInt32(showStatus), fromDate, toDate);

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordsByID", 1, PageNames.SMSApiLog, CurrentUser.GetSessionUserInfo()));
                // LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }
            }

            return model;
        }


        /// <summary>
        /// Get Sending Message from Trasaction 
        /// CR:001 
        /// </summary>
        /// <param name="transactionID">Selected transaction ID</param>
        /// <returns>Transaction Model</returns>
        [WebMethod]
        public static SMSTransactionModel GetSMSSendMessage(string transactionID)
        {
            SMSTransactionModel model = null;
            try
            {
                model = new SMSTransactionModel();
                model.SendMessage = LazySingletonBLL<SMSCampaignBLL>.Instance.GetSMSSendMessage(Convert.ToInt32(transactionID));

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode =LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetSMSSendMessage", 1, PageNames.SMSApiLog, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                }
            }

            return model;
        }
    }
}