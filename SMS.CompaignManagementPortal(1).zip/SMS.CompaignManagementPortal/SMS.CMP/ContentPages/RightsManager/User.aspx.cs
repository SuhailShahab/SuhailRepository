﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using BLL.RightsManager;
using SMS.CMP.BE.Lookups;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.RightsManager
{
    public partial class User : System.Web.UI.Page
    {
        //protected void Page_Load(object sender, EventArgs e)
        //{

        //}

        #region "Paging Variable and Paging Properties"

        int PageSize = 5;
        int PagingSize = 5;
        int TotalRecords = 0;

        public int PageNumber
        {
            get
            {
                int val = 0;
                if (ViewState["PageNumber"] != null)
                    val = Convert.ToInt32(ViewState["PageNumber"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageNumber"] = value;
                else
                    ViewState["PageNumber"] = null;
            }
        }
        public int PageStart
        {
            get
            {
                int val = 1;
                if (ViewState["PageStart"] != null)
                    val = Convert.ToInt32(ViewState["PageStart"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageStart"] = value;
                else
                    ViewState["PageStart"] = null;
            }
        }
        public int PageCount
        {
            get
            {
                int val = 1;
                if (this.hidPageCount.Value != string.Empty)
                    val = Convert.ToInt32(this.hidPageCount.Value);
                return val;
            }
            set
            {
                if (value >= 1)
                {
                    this.hidPageCount.Value = value.ToString();
                }
            }
        }

        #endregion

        #region "Private Data Members"
        //private int? DistrictID;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    dtpJoined.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    this.GetAddressDivision();
                    GetOrganization();
                    GetDistrict();
                    this.GetAddressDistricts(0);
                    GetGroups();
                    PopulateUsers();
                    this.GetUsertypes();
                    this.dtpResigned.Disabled = true;
                    this.BindUserRights();
                    GetAllOrganizations();
                    SetAllOrganizationsVisibility();
                    divDepartments.Visible = false;
                    ddlDepartments.Items.Insert(0, new ListItem("Choose...", "0"));
                    BindSMSDeliveryStatusList();
                    GetAllFeatures();
                }
                catch (Exception ex)
                {
                    new Common().AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                }
                ViewState["UserID"] = "";
                ViewState["Edit"] = "No";
            }
        }

        #region "Methods"

        private void GetAddressDivision()
        {
            this.ddlAddressDivisions.DataSource = new DivisionBLL().GetDivisions();
            this.ddlAddressDivisions.DataValueField = "ID";
            this.ddlAddressDivisions.DataTextField = "Title";
            this.ddlAddressDivisions.DataBind();
            this.ddlAddressDivisions.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        private void GetOrganization()
        {
            ddlOrganization.DataSource = new OrganizationBLL().GetOrganizations();
            ddlOrganization.DataValueField = "ID";
            ddlOrganization.DataTextField = "Title";
            ddlOrganization.DataBind();
            ddlOrganization.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        private void GetDepartments()
        {
            ddlDepartments.Items.Clear();
            ddlDepartments.DataSource = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(ddlOrganization.SelectedValue));
            ddlDepartments.DataValueField = "DepartmentID";
            ddlDepartments.DataTextField = "Title";
            ddlDepartments.DataBind();
            ddlDepartments.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        private void GetDistrict()
        {
            List<DepartmentsModel> genralDisticts = null;



        }

        private void GetAllOrganizations()
        {
            this.chkOrganizations.DataSource = new OrganizationBLL().GetOrganizations(); ;
            this.chkOrganizations.DataValueField = "ID";
            this.chkOrganizations.DataTextField = "Title";
            this.chkOrganizations.DataBind();
            this.chkOrganizations.Items.Insert(0, new ListItem("Select All", "0"));
        }


        private void GetAllDepartmentsByOrgID(int organizationID)
        {
            chkDepartment.Items.Clear();
            this.chkDepartment.DataSource = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(organizationID);
            this.chkDepartment.DataValueField = "DepartmentID";
            this.chkDepartment.DataTextField = "Title";
            this.chkDepartment.DataBind();
            this.chkDepartment.Items.Insert(0, new ListItem("Select All", "0"));
        }


        private void GetAllFeatures()
        {
            this.chkDashboardMenu.DataSource = new FeatureBLL().GetDashboardFeature(); ;
            this.chkDashboardMenu.DataValueField = "ID";
            this.chkDashboardMenu.DataTextField = "Name";
            this.chkDashboardMenu.DataBind();
            this.chkDashboardMenu.Items.Insert(0, new ListItem("Select All", "0"));
        }

        private void GetAllShortCodesByOrgainzationID(int? organizationID)
        {
            this.cblUserShortCode.Items.Clear();
            if (organizationID.HasValue && organizationID.Value >0)
            {
                this.cblUserShortCode.Items.Clear();
                this.cblUserShortCode.DataSource = new ShortCodeBLL().GetShortCodesByOrganizationID(organizationID.Value);
                this.cblUserShortCode.DataValueField = "ID";
                this.cblUserShortCode.DataTextField = "Title";
                this.cblUserShortCode.DataBind();
                this.cblUserShortCode.Items.Insert(0, new ListItem("Select All", "0"));
            }

           
        }
        private void GetAllShortCodesByOrgainzationID(string  organizationIDs)
        {
            this.cblUserShortCode.Items.Clear();
            if (!string.IsNullOrEmpty(organizationIDs))
            {
                this.cblUserShortCode.Items.Clear();
                this.cblUserShortCode.DataSource = new ShortCodeBLL().GetShortCodesByOrganizationIDs(organizationIDs);
                this.cblUserShortCode.DataValueField = "ID";
                this.cblUserShortCode.DataTextField = "Title";
                this.cblUserShortCode.DataBind();
                this.cblUserShortCode.Items.Insert(0, new ListItem("Select All", "0"));
            }


        }

        private void GetAllDepartmentsByMultipleOrgID(string organizationID)
        {
            chkDepartment.Items.Clear();
            this.chkDepartment.DataSource = new DepartmentsBLL().SelectDepartmentsByMultiOrgID(organizationID);
            this.chkDepartment.DataValueField = "Department";
            this.chkDepartment.DataTextField = "Title";
            this.chkDepartment.DataBind();
            this.chkDepartment.Items.Insert(0, new ListItem("Select All", "0"));
        }


        private void GetAddressDistricts(int divisionID)
        {
            if (this.ddlAddressDistiricts.Items != null && this.ddlAddressDistiricts.Items.Count > 0)
            {
                this.ddlAddressDistiricts.Items.Clear();
            }
            if (divisionID > 0)
            {
                this.ddlAddressDistiricts.DataSource = new DepartmentsBLL().GetDistrictsByDivisionID(divisionID);
                this.ddlAddressDistiricts.DataValueField = "ID";
                this.ddlAddressDistiricts.DataTextField = "Title";
                this.ddlAddressDistiricts.DataBind();
            }
            this.ddlAddressDistiricts.Items.Insert(0, new ListItem("Choose...", "0"));
        }



        private void GetGroups()
        {
            ddlGroup.DataSource = new GroupBLL().GetGroups();
            ddlGroup.DataValueField = "GroupID";
            ddlGroup.DataTextField = "Title";
            ddlGroup.DataBind();
            ddlGroup.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        private void GetUsertypes()
        {
            this.ddlUserType.DataSource = new UserTypeBLL().GetAllUsersType();
            this.ddlUserType.DataTextField = "Title";
            this.ddlUserType.DataValueField = "ID";
            this.ddlUserType.DataBind();
        }

        /// <summary>
        /// Get SMS Delivery StatusList
        /// </summary>
        private void BindSMSDeliveryStatusList()
        {
            chkSMSDeliveryStatusList.Items.Clear();
            this.chkSMSDeliveryStatusList.DataSource = new SMSDeliveryStatusBLL().GetAllSMSDeliveryStatus();
            this.chkSMSDeliveryStatusList.DataTextField = "Title";
            this.chkSMSDeliveryStatusList.DataValueField = "ID";
            this.chkSMSDeliveryStatusList.DataBind();
            this.chkSMSDeliveryStatusList.Items.Insert(0, new ListItem("Select All", "0"));
        }

        private void PopulateUsers()
        {
            try
            {
                List<UserModelView> Users = new UserBLL().GetUsers(0, PageNumber, PageSize, out TotalRecords, ddlSearchBy.SelectedValue, txtSearch.Text.Trim());
                //                TotalRecords = Record;
                PageCount = Convert.ToInt32(Math.Ceiling((decimal)TotalRecords / PageSize));
                ViewState["PageCount"] = PageCount;

                if (Users != null)
                {
                    rptUsers.DataSource = Users;
                    rptUsers.DataBind();
                }
                else
                {
                    if (PageNumber > 0)
                    {
                        PageNumber = PageNumber - 1;
                        PopulateUsers();
                    }
                    else
                    {
                        rptUsers.DataSource = null;
                        rptUsers.DataBind();
                    }
                }
            }
            catch (Exception ex)
            {
                new Common().AddErrorLog(new ErrorLogModel(ex, "PopulateUsers", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
            }
        }

        /// <summary>
        /// Get provide login claim information
        /// </summary>
        /// <param name="login"></param>
        /// <returns></returns>
        private static string GetLoginClaim(string login)
        {
            string userName = login;
            /*  SPClaimProviderManager mgr = SPClaimProviderManager.Local;
              if (mgr == null) return userName;

              // comment by hammad => use to claim against window user
              //SPClaim claim = new SPClaim(SPClaimTypes.IdentityProvider, login, "http://www.w3.org/2001/XMLSchema#string", SPOriginalIssuers.Format(SPOriginalIssuerType.Windows));

              string FBAMembershipProvider = ConfigurationManager.AppSettings["FBAMembership"];
              SPClaim claim = new SPClaim(SPClaimTypes.UserLogonName, login, "http://www.w3.org/2001/XMLSchema#string", SPOriginalIssuers.Format(SPOriginalIssuerType.Forms, FBAMembershipProvider));
              userName = mgr.EncodeClaim(claim);
             */
            return userName;
        }

        private void PopulateEditPanel(int UserID)
        {
            try
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();

                ds = new UserBLL().GetUserByID(UserID);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt = ds.Tables[0];
                    dtpResigned.Disabled = false;
                    ddlOrganization.SelectedValue = dt.Rows[0]["OrganizationID"].ToString();
                    if(dt.Columns.Contains("IsEnforceSMSBucked")&& !Convert.IsDBNull(dt.Rows[0]["IsEnforceSMSBucked"]))
                    {
                        chkEnforceSMSBucket.Checked = Convert.ToBoolean(dt.Rows[0]["IsEnforceSMSBucked"]);
                    }
                   



                    txtCNIC.Text = dt.Rows[0]["CNIC"].ToString();
                    txtEmployeeName.Text = dt.Rows[0]["EmployeeName"].ToString();

                    //Address Information

                    if (dt.Columns.Contains("AddressDivisionID") && !Convert.IsDBNull(dt.Rows[0]["AddressDivisionID"]))
                    {
                        int ID = Convert.ToInt32(dt.Rows[0]["AddressDivisionID"]);
                        this.ddlAddressDivisions.SelectedValue = ID.ToString();
                        this.GetAddressDistricts(ID);
                    }

                    if (dt.Columns.Contains("AddressDistrictID") && !Convert.IsDBNull(dt.Rows[0]["AddressDistrictID"]))
                    {
                        int ID = Convert.ToInt32(dt.Rows[0]["AddressDistrictID"]);
                        this.ddlAddressDistiricts.SelectedValue = ID.ToString();
                        // this.GetAddressTehsil(ID);
                    }



                    if (dt.Columns.Contains("FullAddress") && !Convert.IsDBNull(dt.Rows[0]["FullAddress"]))
                    {
                        this.txtFullAddress.Text = Convert.ToString(dt.Rows[0]["FullAddress"]);
                    }


                    // added against CR:007

                    if (dt.Columns.Contains("EMail") && !Convert.IsDBNull(dt.Rows[0]["EMail"]))
                        txtEmail.Text = dt.Rows[0]["EMail"].ToString();
                    if (dt.Columns.Contains("CellNumber") && !Convert.IsDBNull(dt.Rows[0]["CellNumber"]))
                        txtCell.Text = dt.Rows[0]["CellNumber"].ToString();

                    if (dt.Columns.Contains("PermitGroupID") && !Convert.IsDBNull(dt.Rows[0]["PermitGroupID"]))
                    {
                        try
                        {
                            ddlGroup.SelectedValue = dt.Rows[0]["PermitGroupID"].ToString();
                        }
                        catch
                        {
                            ddlGroup.SelectedIndex = 0;
                        }
                    }
                    if (dt.Columns.Contains("UserTypeID") && !Convert.IsDBNull(dt.Rows[0]["UserTypeID"]))
                    {
                        try
                        {
                            ddlUserType.SelectedValue = dt.Rows[0]["UserTypeID"].ToString();
                        }
                        catch
                        {
                            ddlUserType.SelectedIndex = 0;
                        }
                    }

                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dt.Rows[0]["IsActive"]))
                        cbxStatus.Checked = Convert.ToBoolean(dt.Rows[0]["IsActive"].ToString());

                    if (dt.Columns.Contains("InActiveReason") && !Convert.IsDBNull(dt.Rows[0]["InActiveReason"]))
                        txtBlockReason.Text = dt.Rows[0]["InActiveReason"].ToString();

                    if (!Convert.IsDBNull(dt.Rows[0]["JoiningDate"]))
                        this.dtpJoined.Value = Convert.ToDateTime(dt.Rows[0]["JoiningDate"]).ToString("dd/MM/yyyy");

                    if (!Convert.IsDBNull(dt.Rows[0]["ResignedDate"]))
                        this.dtpResigned.Value = Convert.ToDateTime(dt.Rows[0]["ResignedDate"]).ToString("dd/MM/yyyy");

                    this.chkEnforceRight.Checked = Convert.ToBoolean(dt.Rows[0]["IsEnforceRight"].ToString());

                    txtLoginName.Text = dt.Rows[0]["UserName"].ToString();
                    //// set user login name
                    //txtLoginName.Text = dt.Rows[0]["UserName"].ToString();
                    //cppLogin.Visible = false;
                    //txtLoginName.Visible = true;

                    // set serice rights
                    GetDepartments();
                    ddlDepartments.SelectedValue = dt.Rows[0]["DepartmentID"].ToString();
                    this.cblUserRights.Items[UserRightName.FileAdd.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileAdd"]);
                    this.cblUserRights.Items[UserRightName.FileView.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileView"]);
                    this.cblUserRights.Items[UserRightName.FileRemove.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileRemove"]);
                    this.cblUserRights.Items[UserRightName.FileDownload.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileDownload"]);
                    this.cblUserRights.Items[UserRightName.AllowUpdate.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["AllowUpdate"]);
                    this.cblUserRights.Items[UserRightName.ModifyCampaign.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["ModifyCampaign"]);

                    FillUserOrganizations(UserID);
                    FillDepartmentsByMultipleOrgID();
                    FillUserDepartments(UserID);
                    SetAllOrganizationsVisibility();
                    SetAllDepartmentsVisibility();
                    FillUserDashboardMenu(UserID);
                    FillUserShortCode(UserID);
                    FillUserSMSDeliveryStatus(UserID);

                    try
                    {
                        //  string _userName = GetLoginClaim(dt.Rows[0]["UserName"].ToString());
                        //  SPUser user = SPContext.Current.Web.EnsureUser(_userName);

                        //  peUserLogin.CommaSeparatedAccounts = user.LoginName;
                        //  peUserLogin.Enabled = false;
                    }
                    catch (Exception ex)
                    {
                        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "PopulateEditPanel", 1, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('user name not found in active directory server. Please contact your administrator.');", true);
                    }
                }
            }
            catch (Exception ex)
            {

                new Common().AddErrorLog(new ErrorLogModel(ex, "PopulateEditPanel", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));

            }
        }

        private void FillUserOrganizations(int userID)
        {
            List<OrganizationModel> listUserOrganization = new List<OrganizationModel>();
            listUserOrganization = new OrganizationBLL().SelectOrganizationByUserID(userID);

            this.ClearChecked(this.chkOrganizations);

            if (listUserOrganization != null && listUserOrganization.Count > 0)
            {
                foreach (var lItems in listUserOrganization)
                {
                    foreach (ListItem item in this.chkOrganizations.Items)
                    {
                        if (item.Value == lItems.ID.ToString())
                        {
                            item.Selected = true;
                            break;
                        }
                    }
                }
            }
        }


        private void FillUserDashboardMenu(int userID)
        {
            List<FeaturesModel> listFeature = new List<FeaturesModel>();
            listFeature = new FeatureBLL().GetDashboardMenuByUserID(userID);

            this.ClearChecked(this.chkDashboardMenu);

            if (listFeature != null && listFeature.Count > 0)
            {
                foreach (var lItems in listFeature)
                {
                    foreach (ListItem item in this.chkDashboardMenu.Items)
                    {
                        if (item.Value == lItems.ID.ToString())
                        {
                            item.Selected = true;
                            break;
                        }
                    }
                }
            }
        }

        private void FillUserShortCode(int userID)
        {
            List<ShortCodeModel> lstItem = new List<ShortCodeModel>();
            lstItem = new ShortCodeBLL().GetUserShortCodes(userID);

            this.ClearChecked(this.cblUserShortCode);

            if (lstItem != null && lstItem.Count > 0)
            {
                foreach (var lItems in lstItem)
                {
                    foreach (ListItem item in this.cblUserShortCode.Items)
                    {
                        if (item.Value == lItems.ID.ToString())
                        {
                            item.Selected = true;
                            break;
                        }
                    }
                }
            }
        }

        private void FillUserDepartments(int userID)
        {
            List<DepartmentsModel> listDepartments = new List<DepartmentsModel>();
            listDepartments = new DepartmentsBLL().GetDepatmentsByUserID(userID);

            this.ClearChecked(this.chkDepartment);

            if (listDepartments != null && listDepartments.Count > 0)
            {
                foreach (var lItems in listDepartments)
                {
                    foreach (ListItem item in this.chkDepartment.Items)
                    {
                        if (item.Value == lItems.Department.ToString())
                        {
                            item.Selected = true;
                            break;
                        }
                    }
                }
            }

        }


        private void SetSeltectedCSRManagement(DataTable dtStatuses, CheckBoxList chklStatues)
        {
            this.ClearChecked(chklStatues);
            foreach (DataRow dr in dtStatuses.Rows)
            {
                foreach (ListItem item in chklStatues.Items)
                {
                    if (item.Value == dr["AppFeatureID"].ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }

        private void FillUserSMSDeliveryStatus(int userID)
        {
            List<SMSDeliveryStatusModel> listDeliveryStatus = new List<SMSDeliveryStatusModel>();
            listDeliveryStatus = new SMSDeliveryStatusBLL().GetAllSMSDeliveryStatusByUserID(userID);

            this.ClearChecked(this.chkSMSDeliveryStatusList);

            if (listDeliveryStatus != null && listDeliveryStatus.Count > 0)
            {
                foreach (var lItems in listDeliveryStatus)
                {
                    foreach (ListItem item in this.chkSMSDeliveryStatusList.Items)
                    {
                        if (item.Value == lItems.ID.ToString())
                        {
                            item.Selected = true;
                            break;
                        }
                    }
                }
            }
        }


        /// <summary>
        /// Verify login name is selects in people picker
        /// </summary>
        /// <returns></returns>
        private bool ValidatePeoplePicker()
        {
            /*
            if (Page.IsValid)
            {
                if (peUserLogin.CommaSeparatedAccounts == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Select user login name');", true);
                    peUserLogin.Focus();
                    return false;
                }
                else
                {
                    if (peUserLogin.CommaSeparatedAccounts.Contains("\\"))
                    {
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Invalid user selection');", true);
                    }
                }
            }
             */


            return true;
        }

        /// <summary>
        /// check select login Name transactions
        /// </summary>
        /// <param name="LoginName"></param>
        /// <returns></returns>
        private bool ValidateDependanceReocrd(string LoginName)
        {
            //// check data existing against user in sharepoint library
            //using (SPSite site = new SPSite(SPContext.Current.Site.ID))
            //{
            //    using (SPWeb web = site.OpenWeb(SPContext.Current.Web.ID))
            //    {
            //        DataTable dt = new UserBLL().GetUserByLogin(LoginName, Convert.ToInt32(cultureID));
            //        if (dt.Rows.Count > 0)
            //        {
            //            SPList lstTrack = web.Lists[dt.Rows[0]["DepartmentName"].ToString() + " Tasks Track"];
            //            SPQuery query = new SPQuery();
            //            SPUser user = web.EnsureUser(LoginName);

            //            query.Query = "<Where>" +
            //                            "<Eq><FieldRef Name='AssignedFrom' /><Value Type='User'>" + user.Name + "</Value></Eq>" +
            //                        "</Where>";
            //            query.RowLimit = 1;
            //            SPListItemCollection lstItems = lstTrack.GetItems(query);
            //            if (lstItems.Count > 0)
            //            {
            //                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.warning('" + new Common().GetResourceString("RecodDependance", cultureID) + "');", true);
            //                return false;
            //            }

            //            query = new SPQuery();
            //            query.Query = "<Where>" +
            //                            "<Eq><FieldRef Name='AssignedTo' /><Value Type='User'>" + user.Name + "</Value></Eq>" +
            //                        "</Where>";
            //            query.RowLimit = 1;

            //            lstItems = lstTrack.GetItems(query);
            //            if (lstItems.Count > 0)
            //            {
            //                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.warning('" + new Common().GetResourceString("RecodDependance", cultureID) + "');", true);
            //                return false;
            //            }
            //        }
            //    }
            //}

            return true;
        }

        private void ResetControls()
        {
            ddlOrganization.SelectedIndex = 0;
            this.ddlDepartments.SelectedIndex = 0;
            ddlUserType.SelectedIndex = 0;
            txtCNIC.Text = "";
            txtEmployeeName.Text = "";
            txtEmail.Text = "";
            txtCell.Text = "";
            ddlGroup.SelectedIndex = 0;
            txtLoginName.Text = string.Empty;
            cbxStatus.Checked = true;
            txtBlockReason.Text = "";
            ddlOrganization.Focus();
            ViewState["UserID"] = "";
            ViewState["Edit"] = "No";
            this.dtpJoined.Value = null;
            this.dtpResigned.Value = null;
            dtpResigned.Disabled = true;
            this.chkEnforceRight.Checked = false;
            this.ddlAddressDivisions.SelectedIndex = 0;
            this.ddlAddressDistiricts.SelectedIndex = 0;
            this.txtFullAddress.Text = string.Empty;
            this.ClearChecked(this.cblUserRights);
            this.ClearChecked(this.chkOrganizations);
            this.ClearChecked(this.chkDepartment);
            this.ClearChecked(this.chkDashboardMenu);
            this.cblUserShortCode.Items.Clear();
            this.txtPassword.Text = string.Empty;
            this.txtConfirmPassword.Text = string.Empty;
            SetAllOrganizationsVisibility();
            divDepartments.Visible = false;
            this.ClearChecked(this.chkSMSDeliveryStatusList);
            chkEnforceSMSBucket.Checked = false;
        }








        protected void ClearChecked(CheckBoxList chklStatues)
        {

            foreach (ListItem item in chklStatues.Items)
            {
                item.Selected = false;
            }

        }

        /// <summary>
        /// Get selected login window base login claim
        /// </summary>
        /// <remarks>CR:010</remarks>
        /// <returns></returns>
        private string GetLoginWindowsBaseClaim()
        {
            /*
            string login = peUserLogin.CommaSeparatedAccounts;
            if (ConfigurationManager.AppSettings["SignInMethod"].ToString() == "Form")
                login = login.Split('|')[2].ToString();
            else
                login = login.ToString().Substring(login.ToString().LastIndexOf(@"\") + 1, login.ToString().Length - (login.ToString().LastIndexOf(@"\") + 1));

            string userName = login;
            SPClaimProviderManager mgr = SPClaimProviderManager.Local;
            if (mgr == null) return userName;

            SPClaim claim = new SPClaim(SPClaimTypes.UserLogonName, login, "http://www.w3.org/2001/XMLSchema#string", SPOriginalIssuers.Format(SPOriginalIssuerType.Windows));
            userName = mgr.EncodeClaim(claim);

            return userName;
             */
            return null;
        }

        /// <summary>
        /// Add provided user login to sharepoint collections
        /// <remarks>CR:010</remarks>
        /// </summary>
        /*
        private bool SaveToSharePointCollection()
        {
            try
            {
                SPGroup groups;
                DataTable dtUser = Common.GetSessionUserTable();

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    #region "Primary Site Collection"

                    using (SPSite site = new SPSite(SPContext.Current.Site.ID))
                    {
                        site.AllowUnsafeUpdates = true;

                        using (SPWeb web = site.OpenWeb(SPContext.Current.Web.ID))
                        {
                            #region "Grant Permission"

                            web.AllowUnsafeUpdates = true;

                            // assign administrator role on user to add, edit or update
                            SPUser user = SPContext.Current.Web.CurrentUser;
                            SPRoleDefinition roleDef = web.RoleDefinitions.GetByType(SPRoleType.Administrator);

                            if (!web.HasUniqueRoleAssignments)
                            {
                                web.BreakRoleInheritance(true);
                            }

                            SPRoleAssignment spRoleAssignment = new SPRoleAssignment(user);
                            spRoleAssignment.RoleDefinitionBindings.Add(roleDef);
                            web.RoleAssignments.Add(spRoleAssignment);

                            #endregion

                            try
                            {
                                //check group exist if not add new group
                                if (isGroupAlreadyExist(web, ddlGroup.SelectedItem.Text) == false)
                                {
                                    web.SiteGroups.Add(ddlGroup.SelectedItem.Text, web.CurrentUser, web.CurrentUser, "Use this group to grant read permission on application having role of " + ddlGroup.SelectedItem.Text);

                                    //some permissions to group
                                    groups = web.SiteGroups[ddlGroup.SelectedItem.Text];
                                    SPRoleDefinition roleDefinition = web.RoleDefinitions.GetByType(SPRoleType.Reader);
                                    SPRoleAssignment roleAssigment = new SPRoleAssignment(groups);
                                    roleAssigment.RoleDefinitionBindings.Add(roleDefinition);
                                    web.RoleAssignments.Add(roleAssigment);
                                    web.Update();
                                }
                                else
                                    groups = web.Groups[ddlGroup.SelectedItem.Text];

                                // verify user exists in site collection
                                SPUser peoplePickerUser = null;
                                try
                                {
                                    peoplePickerUser = groups.Users[peUserLogin.CommaSeparatedAccounts];
                                }
                                catch
                                {
                                    peoplePickerUser = null;
                                }

                                //Add user into user site collection
                                if (peoplePickerUser == null)
                                {
                                    //add user to group
                                    groups.Users.Add(peUserLogin.CommaSeparatedAccounts, string.Empty, txtEmployeeName.Text, string.Empty);
                                    groups.Update();
                                }
                                else
                                {
                                    //update site user title in user information list
                                    SPUser profile = web.SiteUsers[peUserLogin.CommaSeparatedAccounts];
                                    profile.Name = txtEmployeeName.Text;
                                    profile.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                            finally
                            {
                                #region "Remove Permission"

                                // remove administrator role from user
                                roleDef = web.RoleDefinitions.GetByType(SPRoleType.Reader);

                                if (!web.HasUniqueRoleAssignments)
                                {
                                    web.BreakRoleInheritance(true);
                                }

                                spRoleAssignment = new SPRoleAssignment(user);
                                spRoleAssignment.RoleDefinitionBindings.Remove(roleDef);
                                web.RoleAssignments.Remove(user);

                                web.AllowUnsafeUpdates = false;

                                #endregion
                            }
                        }

                        site.AllowUnsafeUpdates = false;
                    }

                    #endregion

                    //ConfigurationManager.AppSettings["EnableServiceRelatedDocumentCenter"].ToString()
                    if (ddlFCDistricts.SelectedIndex != 0)
                    {
                        DistrictModel fcDistrict = new DistrictBLL().GetDistrictByID(Convert.ToInt32(ddlFCDistricts.SelectedValue));

                        // ====================================================================================================================================== //
                        // ==================================== check common document's document center is enable =============================================== //
                        if (fcDistrict.EnableCommonDocumentCenter)                        //ConfigurationManager.AppSettings["EnableDocumentCenter"].ToString()
                        {
                            #region "Common Documents"

                            //ConfigurationManager.AppSettings["DocumentCenterURL"].ToString()
                            using (SPSite site = new SPSite(fcDistrict.CommonDocumentCenterURL))
                            {
                                site.AllowUnsafeUpdates = true;

                                using (SPWeb web = site.OpenWeb())
                                {
                                    web.AllowUnsafeUpdates = true;

                                    groups = web.Groups["e-Khidmat Center"];        //get sharepoint group wehere user add
                                    SPUser user = null;
                                    string LoginName = GetLoginWindowsBaseClaim();             // get sharepoint claim token
                                    LoginName = web.EnsureUser(LoginName).LoginName;

                                    try
                                    {
                                        user = groups.Users[LoginName];
                                    }
                                    catch
                                    { }

                                    if (user == null)       //Add user into user site collection
                                    {
                                        //add user to group
                                        groups.Users.Add(LoginName, string.Empty, txtEmployeeName.Text, string.Empty);
                                        groups.Update();
                                    }
                                    else
                                    {
                                        SPUser profile = web.SiteUsers[user.LoginName];
                                        profile.Name = txtEmployeeName.Text;
                                        profile.Update();
                                    }

                                    web.AllowUnsafeUpdates = false;

                                }

                                site.AllowUnsafeUpdates = false;
                            }

                            #endregion
                            
                        }

                        // ====================================================================================================================================== //
                        // ============================= check service related document's document center is enable - CR:011 ==================================== //
                        if (fcDistrict.EnableServiceDocumentCenter)
                        {
                            #region "Document Center - Service Related Documents"
                            //ConfigurationManager.AppSettings["ServiceRelatedDocumentCenterURL"].ToString()
                            using (SPSite site = new SPSite(fcDistrict.ServiceDocumentCenterURL))
                            {
                                site.AllowUnsafeUpdates = true;

                                using (SPWeb web = site.OpenWeb())
                                {
                                    web.AllowUnsafeUpdates = true;

                                    groups = web.Groups["e-Khidmat Center"];        //get sharepoint group wehere user add
                                    SPUser user = null;
                                    string LoginName = GetLoginWindowsBaseClaim();             // get sharepoint claim token
                                    LoginName = web.EnsureUser(LoginName).LoginName;

                                    try
                                    {
                                        user = groups.Users[LoginName];
                                    }
                                    catch
                                    { }

                                    if (user == null)       //Add user into user site collection
                                    {
                                        //add user to group
                                        groups.Users.Add(LoginName, string.Empty, txtEmployeeName.Text, string.Empty);
                                        groups.Update();
                                    }
                                    else
                                    {
                                        SPUser profile = web.SiteUsers[user.LoginName];
                                        profile.Name = txtEmployeeName.Text;
                                        profile.Update();
                                    }

                                    web.AllowUnsafeUpdates = false;

                                }

                                site.AllowUnsafeUpdates = false;
                            }

                            #endregion
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }
        */
        #endregion

        #region "Dropdown Events"


        protected void ddlUserType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SetAllOrganizationsVisibility()
        {

            this.divOrganizations.Visible = ((this.ddlOrganization.SelectedValue == null || Convert.ToInt32(this.ddlOrganization.SelectedValue) == 0)) ? true : false;
           // this.divShortCode.Visible = ((this.ddlOrganization.SelectedValue == null || Convert.ToInt32(this.ddlOrganization.SelectedValue) == 0)) ? false : true;
        }


        private void SetAllDepartmentsVisibility()
        {
            if ((this.ddlDepartments.SelectedValue == null || Convert.ToInt32(this.ddlDepartments.SelectedValue) == 0))
            {
                this.divDepartments.Visible = true;
            }
            else
            {
                this.divDepartments.Visible = false;
            }
        }


        /// <summary>
        /// dropdown Change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>


        protected void ddlAddressDivisions_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.GetAddressDistricts(Convert.ToInt32(this.ddlAddressDivisions.SelectedValue));
            this.ddlAddressDivisions.Focus();

        }



        #endregion

        #region "CheckBox Events"

        protected void cbxStatus_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxStatus.Checked == true)
                pnlBlockReason.Visible = false;
            else
                pnlBlockReason.Visible = true;
        }

        #endregion

        #region "Set Paging Method"

        private void SetPagingControl(RepeaterItemEventArgs e)
        {
            try
            {
                DataRowView rptRow = (DataRowView)e.Item.DataItem;
                DataTable dt = new DataTable();
                dt.Columns.Add("Value");

                //Display only PageNumber upto PagingSize            
                if ((PageStart + (PagingSize - 1)) <= PageCount)
                {
                    for (int i = PageStart; i <= PageStart + (PagingSize - 1); i++)
                        dt.Rows.Add(i);
                }
                else
                {
                    for (int i = PageStart; i <= PageCount; i++)
                    dt.Rows.Add(i);
                }

                Repeater rptPaging = (Repeater)e.Item.FindControl("rptPaging");
                rptPaging.DataSource = dt;
                rptPaging.DataBind();

                if (PageNumber == 0 || PageStart == 1)
                    ((LinkButton)e.Item.FindControl("lbtnPrevious")).Enabled = false;


                if (PageNumber == PageCount - 1 || (PageStart + PagingSize - 1) > PageCount)
                    ((LinkButton)e.Item.FindControl("lbtnNext")).Enabled = false;

                Label lbl = (Label)e.Item.FindControl("lblDisplayingRecords");
                if (TotalRecords != 0)
                {
                    if (TotalRecords > (PageNumber * PageSize + PageSize))
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + (PageNumber * PageSize + PageSize) + " of " + TotalRecords + " records";
                    else
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + TotalRecords + " of " + TotalRecords + " records";
                }
                else
                {
                    lbl.Text = "Showing 0 to 0 of 0 records";
                }
            }
            catch (Exception ex)
            {
                //new Common().AddErrorLog(ex, "SetPagingControl", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.Users);
                new Common().AddErrorLog(new ErrorLogModel(ex, "SetPagingControl", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));

            }
        }

        #endregion

        #region "Repeator Events"

        protected void rptUsers_ItemCreated(object sender, RepeaterItemEventArgs e)
        {

            try
            {
                if (e.Item.ItemType == ListItemType.Footer)
                {
                    Repeater rptPaging = (Repeater)e.Item.FindControl("rptPaging");
                    rptPaging.ItemCommand += new RepeaterCommandEventHandler(rptPaging_ItemCommand);
                    rptPaging.ItemDataBound += new RepeaterItemEventHandler(rptPaging_ItemDataBound);
                }
            }
            catch (Exception ex)
            {

                new Common().AddErrorLog(new ErrorLogModel(ex, "rptUsers_ItemCreated", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));

            }
        }

        protected void rptUsers_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                try
                {
                    UserModelView model = (UserModelView)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnUserID")).Value = model.UserID.ToString();
                    ((Label)e.Item.FindControl("lblLoginName")).Text = model.UserName;
                    ((Label)e.Item.FindControl("lblEmployeeName")).Text = model.EmployeeName;
                    ((Label)e.Item.FindControl("lblCNIC")).Text = model.CNIC;
                    ((Label)e.Item.FindControl("lblDistrict")).Text = model.District;

                    if (model.IsActive)
                    {
                        ((Label)e.Item.FindControl("lblActive")).CssClass = "label label-success label-mini";
                        ((Label)e.Item.FindControl("lblActive")).Text = "<i class='fa fa-check'></i>";
                        ((Label)e.Item.FindControl("lblActive")).ToolTip = "Active";
                    }
                    else
                    {
                        ((Label)e.Item.FindControl("lblActive")).CssClass = "label label-important label-mini";
                        ((Label)e.Item.FindControl("lblActive")).Text = "<i class='fa fa-times'></i>";
                        ((Label)e.Item.FindControl("lblActive")).ToolTip = "Block";
                    }

                    LinkButton lbtnDelete = (LinkButton)e.Item.FindControl("lbtnDelete");
                    lbtnDelete.Attributes.Add("onclick", "if ( ! confirm('Do you want to delete this record?')) return false;");
                }
                catch (Exception ex)
                {
                    //new Common().AddErrorLog(ex, "rptUsers_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.Users);
                    new Common().AddErrorLog(new ErrorLogModel(ex, "rptUsers_ItemDataBound", 0, PageNames.Users, CurrentUser.LoginID));

                }
            }
            else if (e.Item.ItemType == ListItemType.Footer)
            {
                this.SetPagingControl(e);
            }
        }

        protected void rptUsers_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                txtPassword.CssClass = txtPassword.CssClass.Replace("validate[required]", "");
                txtConfirmPassword.CssClass = txtConfirmPassword.CssClass.Replace("validate[required]", "");
                string strUserID = ((HiddenField)e.Item.FindControl("hdnUserID")).Value;
                ViewState["UserID"] = strUserID;
                ViewState["Edit"] = "Yes";
                //lbtnSave.Text = "<i class='fa fa-check'></i>&nbsp;Update";

                this.PopulateEditPanel(Convert.ToInt32(strUserID));

            }
            else if (e.CommandName == "Delete")
            {
                try
                {
                    string strUserID = "1";
                    //string strUserID = ((HiddenField)e.Item.FindControl("hdnID")).Value;
                    string LoginName = ((Label)e.Item.FindControl("lblUser")).Text;
                    ViewState["UserID"] = strUserID;

                    //verify record depanded records
                    if (ValidateDependanceReocrd(LoginName))
                    {
                        //  string currentUserlogin = SPContext.Current.Web.CurrentUser.LoginName;
                        // currentUserlogin = currentUserlogin.ToString().Substring(currentUserlogin.ToString().LastIndexOf(@"\") + 1, currentUserlogin.ToString().Length - (currentUserlogin.ToString().LastIndexOf(@"\") + 1));

                        int result = new UserBLL().Delete(Convert.ToInt32(ViewState["UserID"]));
                        if (result > 0)
                        {
                            ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Record deleted successfully');", true);
                            ResetControls();
                            PopulateUsers();
                        }
                    }
                }
                catch (Exception ex)
                {
                    new Common().AddErrorLog(new ErrorLogModel(ex, "rptUsers_DeleteCommand", 1, PageNames.Users, CurrentUser.GetSessionUserInfo()));

                }
            }
            else if (e.CommandName == "Next")
            {
                if ((PageStart + PagingSize) <= PageCount)
                {
                    PageStart += PagingSize;
                    PageNumber = PageStart - 1;
                }

                PopulateUsers();
            }

            else if (e.CommandName == "Previous")
            {
                if ((PageStart - PagingSize) >= 1)
                {
                    PageStart -= PagingSize;
                    PageNumber = PageStart - 1;
                }

                PopulateUsers();
            }
        }



        #endregion

        #region "Paging Repeator Events"

        protected void rptPaging_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            LinkButton lbtnPageNumber = null;
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                lbtnPageNumber = (LinkButton)e.Item.FindControl("lbtnPageNumber");

                if (e.Item.ItemIndex == (PageNumber % PagingSize))
                {
                    ((HtmlGenericControl)e.Item.FindControl("liPageNo")).Attributes.Add("class", "active");
                }
                else
                {
                    ((HtmlGenericControl)e.Item.FindControl("liPageNo")).Attributes.Add("class", "");
                }

                lbtnPageNumber.Text = lbtnPageNumber.Text;
            }
            else if (e.Item.ItemType == ListItemType.Header)
            {
                if (PageNumber == 0 || PageStart == 1)
                {
                    ((LinkButton)e.Item.FindControl("lbtnPrevious")).Enabled = false;
                }
            }
            else if (e.Item.ItemType == ListItemType.Footer)
            {
                if (PageNumber == PageCount - 1 || (PageStart + PagingSize - 1) > PageCount)
                {
                    ((LinkButton)e.Item.FindControl("IbtnNext")).Enabled = false;
                }
            }
        }

        protected void rptPaging_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            if (e.CommandName == "PageNumber")
            {
                PageNumber = Convert.ToInt32(((LinkButton)e.Item.FindControl("lbtnPageNumber")).Text) - 1;
                PopulateUsers();
            }
        }

        #endregion

        #region "Button Click Events"

        protected void lbtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // validate user input
                if (!ValidatePeoplePicker()) return;
                if (ViewState["Edit"].ToString() != "Yes")  // add new record
                {
                    string login = txtLoginName.Text;// peUserLogin.CommaSeparatedAccounts;
                    // login = login.Split('|')[2].ToString();

                    //varify user name exist in database
                    if (new CommonBLL().SelectRecordVerification(TableName.tblUsers.ToString(), ColumnName.UserName.ToString(), login, ""))
                    {

                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('Login Name already register');", true);
                        return;
                    }

                    DateTime? dtJoine = null;
                    if (!string.IsNullOrEmpty(this.dtpJoined.Value))
                    {
                        string[] dateInfo = this.dtpJoined.Value.Split('/');
                        dtJoine = Convert.ToDateTime(dateInfo[1] + "/" + dateInfo[0] + "/" + dateInfo[2]);
                    }


                    UserRegistration user = new UserRegistration();
                    user.EnforceRight = this.chkEnforceRight.Checked;

                    user.JoinDate = dtJoine;
                   

                    user.BlockReason = txtBlockReason.Text;

                    user.Status = cbxStatus.Checked;

                    user.UserTypeID = Convert.ToInt32(ddlUserType.SelectedValue);
                    user.GroupID = Convert.ToInt32(ddlGroup.SelectedValue);
                    user.CellNumber = txtCell.Text;
                    user.EMail = txtEmail.Text;
                    user.CNIC = txtCNIC.Text;
                    user.EmployeeName = txtEmployeeName.Text;
                    user.LoginName = login;
                    user.DepartmentID = Convert.ToInt32(ddlDepartments.SelectedValue);
                    user.GeneralDistrictID = 0;
                    user.OrganizationID = Convert.ToInt32(ddlOrganization.SelectedValue);
                    user.UserOrganizations = this.FillUserOrganizations(this.chkOrganizations);
                    user.UserDepartments = this.FillUserDepartments(this.chkDepartment);
                    user.UserDashboardMenu = this.FillUserDashboardMenu(chkDashboardMenu);
                    user.UserSMSDeliveryStatus = this.FillUserSMSDeliveryStatus(chkSMSDeliveryStatusList);

                    FillUserInfo(user);
                    if (IsValidUserData(user))
                    {
                        // this.SaveToSharePointCollection();
                        int result = new UserBLL().Save(user);      // CR: 009 END
                        if (result > 0)
                        {
                            ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.success('Record saved successfully.');", true);
                            ResetControls();
                            PopulateUsers();
                        }
                    }

                } // end add new record
                else
                {

                    DateTime? dtJoine = null;
                    DateTime? dtResign = null;
                    if (!string.IsNullOrEmpty(this.dtpJoined.Value))
                    {
                        string[] dateInfo = this.dtpJoined.Value.Split('/');
                        dtJoine = Convert.ToDateTime(dateInfo[1] + "/" + dateInfo[0] + "/" + dateInfo[2]);
                    }
                    if (!string.IsNullOrEmpty(this.dtpResigned.Value))
                    {
                        string[] dateInfo = this.dtpResigned.Value.Split('/');
                        dtResign = Convert.ToDateTime(dateInfo[1] + "/" + dateInfo[0] + "/" + dateInfo[2]);
                    }

                    UserRegistration user = new UserRegistration();
                    user.EnforceRight = this.chkEnforceRight.Checked;

                    user.ResignDate = dtResign;
                    user.JoinDate = dtJoine;

                    user.BlockReason = txtBlockReason.Text;
                    user.Status = cbxStatus.Checked;
                    user.UserTypeID = Convert.ToInt32(ddlUserType.SelectedValue);
                    user.GroupID = Convert.ToInt32(ddlGroup.SelectedValue);
                    user.CellNumber = txtCell.Text;
                    user.EMail = txtEmail.Text;
                    user.CNIC = txtCNIC.Text;
                    user.EmployeeName = txtEmployeeName.Text;
                    user.LoginName = txtLoginName.Text;
                    user.GeneralDistrictID = 0;
                    user.DepartmentID = Convert.ToInt32(ddlDepartments.SelectedValue);
                    user.OrganizationID = Convert.ToInt32(ddlOrganization.SelectedValue);
                    user.UserID = Convert.ToInt32(ViewState["UserID"]);
                    FillUserInfo(user);
                    user.UserOrganizations = this.FillUserOrganizations(this.chkOrganizations);
                    user.UserDepartments = this.FillUserDepartments(this.chkDepartment);
                    user.UserDashboardMenu = this.FillUserDashboardMenu(chkDashboardMenu);
                    user.UserSMSDeliveryStatus = this.FillUserSMSDeliveryStatus(chkSMSDeliveryStatusList);
                    if (IsValidUserData(user))
                    {
                        //this.SaveToSharePointCollection();
                        int result = new UserBLL().Update(user);
                        if (result > 0)
                        {
                            txtPassword.CssClass = "validate[required]";
                            txtConfirmPassword.CssClass = "validate[required]";
                            ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.success('Record updated successfully.');", true);
                            ResetControls();
                            PopulateUsers();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "lbtnSave_Click", 1, PageNames.Users, CurrentUser.GetSessionUserInfo()));

            }
        }



        internal void FillUserInfo(UserRegistration user)
        {
            user.CreatedBy = CurrentUser.LoginID;
            if (this.ddlAddressDivisions.Items != null && this.ddlAddressDivisions.Items.Count>0)
            user.AddressDivisionID = Convert.ToInt32(this.ddlAddressDivisions.SelectedValue);
            if (this.ddlAddressDistiricts.Items != null && this.ddlAddressDistiricts.Items.Count > 0)
            user.AddressDistrictID = Convert.ToInt32(this.ddlAddressDistiricts.SelectedValue);
            user.FullAddress = this.txtFullAddress.Text;
            user.FileAdd = this.cblUserRights.Items[0].Selected;
            user.FileView = this.cblUserRights.Items[1].Selected;
            user.FileRemove = this.cblUserRights.Items[2].Selected;
            user.FileDownload = this.cblUserRights.Items[3].Selected;
            user.AllowUpdate = this.cblUserRights.Items[4].Selected;
            user.ModifyCampaign = this.cblUserRights.Items[5].Selected;
            user.Password = txtPassword.Text;
            user.UserShortCode = this.FillUserInfoFromChk(this.cblUserShortCode);
            user.IsEnforceSMSBucked = this.chkEnforceSMSBucket.Checked;
        }

        protected void lbtnCancel_Click(object sender, EventArgs e)
        {
            ResetControls();
            ViewState["PageNumber"] = null;
            PopulateUsers();
        }

        protected void lbtnSearch_Click(object sender, EventArgs e)
        {
            ViewState["PageNumber"] = null;
            PopulateUsers();
        }

        protected void lbtnReload_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            ddlSearchBy.SelectedIndex = 0;
            ViewState["PageNumber"] = null;
            PopulateUsers();
        }



        #endregion

        //protected void ddlUserType_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //    DropDownList ddl = sender as DropDownList;
        //    RepeaterItem ri = ddl.NamingContainer as RepeaterItem;

        //    if (ri != null)
        //    {
        //        DataRowView dataRowView = (DataRowView)ri.DataItem;
        //        DropDownList ddlUsers = (DropDownList)ri.FindControl("ddlUsers");
        //        DropDownList ddlDistricts = (DropDownList)ri.FindControl("ddlDistricts");
        //        string ddlUserTypeID = ((DropDownList)ri.FindControl("ddlUserType")).SelectedValue;

        //        ddlUsers.Items.Clear();

        //        ddlUsers.DataSource = new UserBLL().SelectUserByTypeID(Convert.ToInt32(ddlDistricts.SelectedValue), Convert.ToInt32(ddlUserTypeID));
        //        ddlUsers.DataTextField = "EmployeeName";
        //        ddlUsers.DataValueField = "UserID";
        //        ddlUsers.DataBind();
        //        ddlUsers.Items.Insert(0, new ListItem("Choose...", "0"));

        //    }
        //}


        #region Custom Methods

        private DataTable FillUserOrganizations(CheckBoxList chklStatues)
        {
            DataRow dr;
            DataTable dtUserOrganizations = new DataTable();
            dtUserOrganizations.Columns.Add("OrganizationID", typeof(int));
            if (string.IsNullOrEmpty(this.ddlOrganization.SelectedValue) || Convert.ToInt32(this.ddlOrganization.SelectedValue) == 0)
                foreach (ListItem litem in chklStatues.Items)
                {
                    if (litem.Selected && litem.Value != "0")
                    {
                        dr = dtUserOrganizations.NewRow();
                        dr["OrganizationID"] = litem.Value;
                        dtUserOrganizations.Rows.Add(dr);
                    }
                }

            return dtUserOrganizations;
        }


        private DataTable FillUserDashboardMenu(CheckBoxList chklStatues)
        {
            DataRow dr;
            DataTable dtUserDashboardMenu = new DataTable();
            dtUserDashboardMenu.Columns.Add("FeatureID", typeof(int));
            foreach (ListItem litem in chklStatues.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dtUserDashboardMenu.NewRow();
                    dr["FeatureID"] = litem.Value;
                    dtUserDashboardMenu.Rows.Add(dr);
                }
            }
            return dtUserDashboardMenu;
        }

        private DataTable FillUserDepartments(CheckBoxList chklStatues)
        {
            DataRow dr;
            DataTable dtUserOrganizations = new DataTable();
            dtUserOrganizations.Columns.Add("OrganizationID", typeof(int));
            dtUserOrganizations.Columns.Add("DepartmentID", typeof(int));

            foreach (ListItem litem in chklStatues.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dtUserOrganizations.NewRow();
                    dr["DepartmentID"] = litem.Value.Split('-')[0];
                    dr["OrganizationID"] = litem.Value.Split('-')[1];
                    dtUserOrganizations.Rows.Add(dr);
                }
            }

            return dtUserOrganizations;
        }

        private DataTable FillUserInfoFromChk(CheckBoxList chklStatues)
        {
            DataRow dr;
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
           

            foreach (ListItem litem in chklStatues.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dt.NewRow();
                    dr["ID"] = litem.Value;
                    dt.Rows.Add(dr);
                }
            }

            return dt;
        }

        private DataTable FillUserSMSDeliveryStatus(CheckBoxList chklStatues)
        {
            DataRow dr;
            DataTable dtUserSMSDeliveryStatus = new DataTable();
            dtUserSMSDeliveryStatus.Columns.Add("DeliveryStatusID", typeof(int));
            foreach (ListItem litem in chklStatues.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dtUserSMSDeliveryStatus.NewRow();
                    dr["DeliveryStatusID"] = litem.Value;
                    dtUserSMSDeliveryStatus.Rows.Add(dr);
                }
            }
            return dtUserSMSDeliveryStatus;
        }

        private bool IsValidUserData(UserRegistration user)
        {
            //if ((this.ddlDistrict.SelectedValue == null || Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0) && (user.UserDistricts == null || user.UserDistricts.Rows.Count == 0))
            //{
            //    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Please select at least on district.');", true);
            //    this.ddlDistrict.Focus();
            //    return false;
            //}
            return true;
        }
        private void BindUserRights()
        {
            this.cblUserRights.Items.Insert(0, new ListItem("File Add", "1"));
            this.cblUserRights.Items.Insert(1, new ListItem("File View", "2"));
            this.cblUserRights.Items.Insert(2, new ListItem("File Remove", "3"));
            this.cblUserRights.Items.Insert(3, new ListItem("File Download", "4"));
            this.cblUserRights.Items.Insert(4, new ListItem("Allow Update", "5"));
            this.cblUserRights.Items.Insert(5, new ListItem("Modify Campaign", "6"));
        }

        protected void ddlOrganization_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (ddlOrganization.SelectedValue != "0")
                {
                    GetDepartments();
                    GetAllDepartmentsByMultipleOrgID(ddlOrganization.SelectedValue.ToString());
                    this.GetAllShortCodesByOrgainzationID(Convert.ToInt32(ddlOrganization.SelectedValue));
                    SetAllOrganizationsVisibility();
                    SetAllDepartmentsVisibility();
                }
                else
                {
                    SetAllOrganizationsVisibility();
                    GetAllOrganizations();
                    ddlOrganization.Focus();
                    ddlDepartments.Items.Clear();
                    ddlDepartments.Items.Insert(0, new ListItem("Choose...", "0"));
                    ClearChecked(chkDepartment);
                    this.divDepartments.Visible = false;
                    this.GetAllShortCodesByOrgainzationID(Convert.ToInt32(ddlOrganization.SelectedValue));
                }
            }
            catch (Exception)
            {

                throw;
            }
        }


        protected void btnShowDepartments_Click(object sender, EventArgs e)
        {
            try
            {
                FillDepartmentsByMultipleOrgID();
                SetAllDepartmentsVisibility();
                if (!string.IsNullOrEmpty(Convert.ToString(ViewState["UserID"])))
                {
                    FillUserDepartments(Convert.ToInt32(ViewState["UserID"]));
                }
            }
            catch (Exception)
            {

                throw;
            }
        }


        public void FillDepartmentsByMultipleOrgID()
        {
            List<OrganizationModel> listOrganizations = new List<OrganizationModel>();

            foreach (ListItem item in chkOrganizations.Items)
            {
                if (item.Selected == true && Convert.ToInt32(item.Value) > 0)
                {
                    OrganizationModel orgModel = new OrganizationModel();
                    orgModel.ID = Convert.ToInt32(item.Value);
                    listOrganizations.Add(orgModel);
                }
            }
            string organizationIDs = string.Join(",", listOrganizations.Select(p => p.ID));
            GetAllDepartmentsByMultipleOrgID(organizationIDs);
            this.GetAllShortCodesByOrgainzationID(organizationIDs);
        }

        protected void ddlDepartments_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                GetAllDepartmentsByMultipleOrgID(ddlOrganization.SelectedValue.ToString());
                SetAllDepartmentsVisibility();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Add provided user login to sharepoint  Document Center collections
        /// 
        /// </summary>
        //private bool SaveToSharePointCollection()
        //{
        //    try
        //    {
        //        SPGroup groups;

        //        SPSecurity.RunWithElevatedPrivileges(delegate()
        //        {
        //            #region "Common Documents"

        //            using (SPSite site = new SPSite(ConfigurationManager.AppSettings["DocumentDownloadURL"].ToString()))
        //            {
        //                site.AllowUnsafeUpdates = true;

        //                using (SPWeb web = site.OpenWeb())
        //                {
        //                    web.AllowUnsafeUpdates = true;
        //                    groups = web.Groups[ConfigurationManager.AppSettings["DocumentCenterGroup"].ToString()];

        //                    SPUser user = null;
        //                    //string LoginName = GetLoginWindowsBaseClaim();             // get sharepoint claim token
        //                    string LoginName = txtLoginName.Text;
        //                    LoginName = web.EnsureUser(LoginName).LoginName;

        //                    try
        //                    {
        //                        user = groups.Users[LoginName];
        //                    }
        //                    catch
        //                    { }

        //                    if (user == null)       //Add user into user site collection
        //                    {
        //                        //add user to group
        //                        groups.Users.Add(LoginName, string.Empty, txtEmployeeName.Text, string.Empty);
        //                        groups.Update();
        //                    }
        //                    else
        //                    {
        //                        SPUser profile = web.SiteUsers[user.LoginName];
        //                        profile.Name = txtEmployeeName.Text;
        //                        profile.Update();
        //                    }

        //                    web.AllowUnsafeUpdates = false;

        //                }

        //                site.AllowUnsafeUpdates = false;
        //            }

        //            #endregion
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    return true;
        //}
        #endregion
    }
}