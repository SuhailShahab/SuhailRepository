﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.RightsManager;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.RightsManager
{
    public partial class ResetPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (CurrentUser.DepartmentID == 0 && CurrentUser.OrganizationID == 0 && CurrentUser.UserTypeID == UserTypeNames.Admin.GetHashCode())
            {
                txtLogin.Enabled = true;
                oldpassword.Enabled = false;
                GetUserLogins();
            }
            else
                txtLogin.Text = CurrentUser.LoginName;

        }

        protected void resetpassword_Click(object sender, EventArgs e)
        {
            bool IsAdminUser = false;
            string loginName, oldPassword;
            if (CurrentUser.DepartmentID == 0 && CurrentUser.OrganizationID == 0 && CurrentUser.UserTypeID == UserTypeNames.Admin.GetHashCode())
            {
                IsAdminUser = true;
                loginName = txtLogin.Text;
                oldPassword = "";
            }
            else
            {
                loginName = CurrentUser.LoginName;
                oldPassword = oldpassword.Text;
            }

            if ((retypePassword.Text == newpassword.Text) && (newpassword.Text != oldPassword))
            {
                int ret = new UserBLL().ResetPassword(loginName, oldPassword, newpassword.Text, CurrentUser.LoginID, IsAdminUser);
                if (ret > 0)
                {
                    if (!IsAdminUser)
                    {
                        HttpCookie aCookie;
                        string cookieName;
                        int limit = HttpContext.Current.Request.Cookies.Count;
                        for (int i = 0; i < limit; i++)
                        {
                            cookieName = HttpContext.Current.Request.Cookies[i].Name;
                            aCookie = new HttpCookie(cookieName);
                            aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                            HttpContext.Current.Response.Cookies.Add(aCookie); // overwrite it
                        }
                        HttpContext.Current.Session.Abandon();
                        string url = "~/Login.aspx";
                        Response.Redirect(url, false);
                    }
                    string script = "toastr.success('Password changed successfully.');";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                }
                else
                {
                    string script = "toastr.info('Password not changed. Try again.');";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                }
            }
            else
            {
                string script = "toastr.info('Password not changed as new passwords dont match or old password is same as new password.');";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            }

        }

        protected void cancelReset_Click(object sender, EventArgs e)
        {
            oldpassword.Text = "";
            newpassword.Text = "";
            retypePassword.Text = "";
        }

        private void GetUserLogins()
        {
            List<UserModelView> Users = new List<UserModelView>();
            Users = new UserBLL().GetUsersLoginNameInfo();
            /// TO DO: Set users login info in drop down///

        }
    }
}