﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.APIClasses;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.CMP
{

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <23-11-2015 03:37 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// 001           Sajjad Aslam                13-03-2017 12:11 PM         Load data on Filter base
// =================================================================================================================================


    public partial class SMSInbox : System.Web.UI.Page
    {
      
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }


        #region "Web Methods"


        /// <summary>
        /// Get Campaign Information
        /// </summary>
        /// <returns></returns>
        /// 
        #region "Old function"
        /*
        [WebMethod]
        public static SMSResponseViewModel GetRecord(string organizationID, string departmentID, string campaignID, string pageNo, string fromDate, string toDate, string searchText)
        {
            SMSResponseViewModel model = null;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;

                model = new SMSResponseViewModel();
                int PageNo = Convert.ToInt32(pageNo);

                if (PageNo != 0)
                    model.PageNo = PageNo;
                else
                    model.PageNo = 1;

                model.PageSize = PageSize;
                model.User = User;


                SearchModel search = new SearchModel();
                search.OrganizaitonID = Convert.ToInt32(organizationID);
                search.DepartmentID = Convert.ToInt32(departmentID);
                search.CampaignID = Convert.ToInt32(campaignID);
                search.PageNo = model.PageNo;
                search.PageSize = model.PageSize;
                search.FromDate = fromDate;
                search.Todate = toDate;
                search.SearchText = searchText;

                model = new SMSInboxBLL().GetSMSResponses(model, search);


            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 0, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo()));
                LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

            }
            return model;
        } */
        #endregion

        [WebMethod]
        public static SMSResponseViewModel GetRecord(string organizationID, string departmentID, string campaignID, string pageNo, string fromDate, string toDate, string searchText, bool isLoad)
        {
            SMSResponseViewModel model = null;

            try
            {
                #region "Set Page Size"
                int PageSize = ConfigurationHelper.PageSize; //Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;

                model = new SMSResponseViewModel();
                int PageNo = Convert.ToInt32(pageNo);

                if (PageNo != 0)
                    model.PageNo = PageNo;
                else
                model.PageNo = 1;

                model.PageSize = PageSize;
                model.User = User;


                SearchModel search = new SearchModel();
                search.OrganizaitonID = Convert.ToInt32(organizationID);
                search.DepartmentID = Convert.ToInt32(departmentID);
                search.CampaignID = Convert.ToInt32(campaignID);
                search.PageNo = model.PageNo;
                search.PageSize = model.PageSize;
                search.FromDate = fromDate;
                search.Todate = toDate;
                search.SearchText = searchText;
                model = LazySingletonBLL<SMSInboxBLL>.Instance.GetSMSResponses(model, search, isLoad);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 0, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSResponseViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSResponseViewModel("error|" + ex.Message);
                }

            }
            return model;
        }


        /// <summary>
        /// get Department By Organization ID
        /// </summary>
        /// <returns>Department List</returns>
        [WebMethod]
        public static SMSResponseViewModel GetDepartments(string organizationID)
        {
            SMSResponseViewModel model = new SMSResponseViewModel();
            List<DepartmentsModel> departments = null;
            try
            {
                departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                if (departments != null && departments.Count > 0)
                    model.Departments = departments;
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDepartments", 0, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSResponseViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSResponseViewModel("error|" + ex.Message);
                }

            }
            return model;
        }


        /// <summary>
        /// This webmethod use to get the Campaings List
        /// </summary>
        /// <param name="organizationID">Slected organization ID</param>
        /// <param name="deptID">Selected Department ID</param>
        /// <param name="userID">Select User ID</param>
        /// <returns>SMs Response View Model</returns>
       [WebMethod]
        public static SMSResponseViewModel GetSMSCampaigns(string organizationID, string deptID, string userID)
        {
            SMSResponseViewModel model = new SMSResponseViewModel();
            try
            {
            if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID > 0)
            {
                int? deptId = null;
                if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
                    model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(Convert.ToInt32(organizationID), Convert.ToInt32(deptID), null);
                else
                    model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(Convert.ToInt32(organizationID), deptId, null);
            }
            else
                model.SMSCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(Convert.ToInt32(organizationID), Convert.ToInt32(deptID), null);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetSMSCampaigns", 0, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetSMSCampaigns", 1, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSResponseViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSResponseViewModel("error|" + ex.Message);
                }

            }
            return model;
        }


        /// <summary>
        /// This web method is use to get all transaction responses of selected Response ID
        /// </summary>
        /// <param name="campaignID">Selected campaign ID</param>
        /// <param name="responseID">Selected response ID</param>
        /// <returns>SMS Response View Model</returns>
       [WebMethod]
       public static SMSResponseViewModel GetSMSTransactionResponses(string campaignID, string responseID, string replyPhoneNo,string recordID)
       {
           SMSResponseViewModel model = new SMSResponseViewModel();
           try
           {
               if (replyPhoneNo.Length == 11)
               {
                   replyPhoneNo = replyPhoneNo.Replace(replyPhoneNo.Substring(0, replyPhoneNo.Length), PhoneCode.PhoneCode92.GetHashCode().ToString() + replyPhoneNo.Substring(1));
               }
               model.SMSTransactions = LazySingletonBLL<SMSTransactionBLL>.Instance.GetSMSTransactionResponses(Convert.ToInt32(campaignID), Convert.ToInt32(responseID), replyPhoneNo, Convert.ToInt32(recordID));
           }
           catch (Exception ex)
           {
               //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetSMSTransactionResponses", 0, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo()));
               //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

               string errorCode = string.Empty;
               errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetSMSTransactionResponses", 1, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo())).ToString();
               if (ConfigurationHelper.IsShowGeneralMsg)
               {
                   model = new SMSResponseViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
               }
               else
               {
                   model = new SMSResponseViewModel("error|" + ex.Message);
               }

           }

           return model;
       }


       /// <summary>
       /// Get Sending Message from Trasaction 
       /// </summary>
       /// <param name="transactionID">Selected transaction ID</param>
       /// <returns>Transaction Model</returns>
       [WebMethod]
       public static SMSTransactionModel GetSMSSendMessage(string transactionID)
       {
           SMSTransactionModel model = null;
           try
           {
               model = new SMSTransactionModel();
               model.SendMessage = LazySingletonBLL<SMSCampaignBLL>.Instance.GetSMSSendMessage(Convert.ToInt32(transactionID));

           }
           catch (Exception ex)
           {
               //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetSMSSendMessage", 1, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo()));
               //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

               string errorCode = string.Empty;
               errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetSMSSendMessage", 1, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo())).ToString();
               if (ConfigurationHelper.IsShowGeneralMsg)
               {
                   model = new SMSTransactionModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
               }
               else
               {
                   model = new SMSTransactionModel("error|" + ex.Message);
               }
           }

           return model;
       }


       /// <summary>
       /// This Method is use to get the Transaction Response Message 
       /// </summary>
       /// <param name="responseID">Selected Response ID</param>
       /// <returns>SMS Response Model</returns>
       [WebMethod]
       public static SMSResponseModel GetSMSResponseMessage(string responseID,string recordID)
       {
           SMSResponseModel model = null;
           try
           {
               model = new SMSResponseModel();
               model.ReplyMessage = LazySingletonBLL<SMSInboxBLL>.Instance.GetSMSResponseMessage(Convert.ToInt32(responseID), Convert.ToInt32(recordID));

           }
           catch (Exception ex)
           {
               //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetSMSResponseMessage", 1, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo()));
               //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

               string errorCode = string.Empty;
               errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetSMSResponseMessage", 1, PageNames.SMSInbox, CurrentUser.GetSessionUserInfo())).ToString();
               if (ConfigurationHelper.IsShowGeneralMsg)
               {
                   model = new SMSResponseModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
               }
               else
               {
                   model = new SMSResponseModel("error|" + ex.Message);
               }
            }

            return model;
        }


        #endregion

        #region private Method





        #endregion

        #region public Method



        #endregion
    }
}