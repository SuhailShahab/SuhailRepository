﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace SMS.CMP.ContentPages.CMP
{
    public partial class Invoice : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region Web Methods"

        /// <summary>
        ///  Save mask Information
        /// </summary>
        /// <param name="jsonModel">Model Jason string</param>
        /// <returns></returns>
        [WebMethod]
        public static InvoiceModel SaveRecord(string jsonModel)
        {
            int result = 0;
            InvoiceModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<InvoiceModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;

                if (model.PaymentInvoiceID > 0)
                {
                    model.PayableAmount = model.PayableAmount - model.PaidAmount;
                }

                result = new InvoiceBLL().Save(model);

                if (result > 0)
                {
                    model.PaymentInvoiceID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, CutomMessage.InvoiceError);
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Invoice, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Invoice, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new InvoiceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new InvoiceModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get Invoice record from Model
        /// </summary>
        /// <returns>Invoice List</returns>
        [WebMethod]
        public static InvoiceModelView GetRecord(string jsonModel)
        {
            InvoiceModel invoiceModel = new InvoiceModel();
            InvoiceModelView modelView = new InvoiceModelView();

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion


                if (jsonModel != "null")
                {
                    modelView = new JavaScriptSerializer().Deserialize<InvoiceModelView>(jsonModel);
                }
                else
                {
                    modelView = new InvoiceModelView();
                    modelView.PageNo = 1;
                }


                List<InvoiceModel> lstInvoices = new InvoiceBLL().GetAllInvoiceInfo(0, 0, 0, modelView.PageNo, PageSize, modelView.SearchText);
                List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));

                if (organizations != null && organizations.Count > 0)
                    modelView.Organizations = organizations;

                if (lstInvoices != null && lstInvoices.Count > 0)
                {
                    modelView.Invoices = lstInvoices;
                    modelView.TotalCount = lstInvoices[0].TotalCount;
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Invoice, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    invoiceModel = new InvoiceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    invoiceModel = new InvoiceModel("error|" + ex.Message);
                }
                //LazySingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Invoice, CurrentUser.GetSessionUserInfo()));
            }

            return modelView;
        }

        /// <summary>
        /// Get Payable Amount, Quantity and Rate 
        /// </summary>
        /// <param name="departmentID"></param>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <returns></returns>
        [WebMethod]
        public static InvoiceModel GetPayableAmount(string departmentID, string organizationID, string campaignID, string pageNo, string searchText, string dateOfInvoice)
        {
            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                List<InvoiceModel> lstInvoices = new InvoiceBLL().GetAllInvoiceInfo(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), Convert.ToInt32(campaignID), Convert.ToInt32(pageNo), PageSize, "");
                InvoiceModel model = new InvoiceModel();
                model = FillModel(departmentID, organizationID, campaignID, model, dateOfInvoice);

                if (lstInvoices != null && lstInvoices.Count > 0)
                {
                    model.Invoices = lstInvoices;
                    model.TotalCount = lstInvoices[0].TotalCount;
                }

                return model;
            }
            catch (Exception)
            {
               
                throw;
            }
        }

        /// <summary>
        /// Fill Method for Getting Payable Amount, Quantity and Rate
        /// </summary>
        /// <param name="departmentID"></param>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        public static InvoiceModel FillModel(string departmentID, string organizationID, string campaignID, InvoiceModel model, string dateOfInvoice)
        {
            model = new InvoiceBLL().GetPayableAmount(Convert.ToInt32(departmentID), Convert.ToInt32(organizationID), Convert.ToInt32(campaignID), dateOfInvoice);

            //if (dt != null && dt.Rows.Count > 0)
            //{
            //    model.PayableAmount = Convert.ToDecimal(dt.Rows[0]["PayableAmount"]);
            //    model.Rate = Convert.ToDecimal(dt.Rows[0]["Rate"]);
            //    model.Quantity = Convert.ToInt32(dt.Rows[0]["Quantity"]);
            //    model.TotalAmount = Convert.ToDecimal(dt.Rows[0]["TotalAmount"]);
            //    model.TotalSMS = Convert.ToInt32(dt.Rows[0]["TotalSMS"]);
                
            //}

            return model;
        }

        /// <summary>
        /// get Departments and Campaigns By Organization ID
        /// </summary>
        /// <param name="organizationID"> Selected Organizaiton ID</param>
        /// <returns>Department and Campaign List</returns>
        [WebMethod]
        public static InvoiceModelView GetDepartments(string organizationID, string departmentID)
        {
            InvoiceModelView model = new InvoiceModelView();

            try
            {
                List<SMSCampaignModel> lstCampaigns = new List<SMSCampaignModel>();

                if (departmentID != "undefined")
                {
                    lstCampaigns = new SMSCampaignBLL().GetCampaings(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), null);
                }

                List<DepartmentsModel> lstDepartments = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(organizationID));

                if (lstDepartments != null && lstDepartments.Count > 0)
                {
                    model.Departments = lstDepartments;
                }

                if (lstCampaigns != null && lstCampaigns.Count > 0)
                {
                    model.Campaigns = lstCampaigns;
                }
                return model;
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.Invoice, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new InvoiceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new InvoiceModelView("error|" + ex.Message);
                }
               // LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetShortCodes", 0, PageNames.Invoice, CurrentUser.GetSessionUserInfo()));
            }

            return model;
        }

        #endregion

        #region  Not Used at a Time
        //public static InvoiceModel FillModelForHistory(string departmentID, string organizationID, string campaignID, InvoiceModel model)
        //{
        //    DataTable dt = new InvoiceBLL().GetPayableAmount(Convert.ToInt32(departmentID), Convert.ToInt32(organizationID), Convert.ToInt32(campaignID));
        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        model.Rate = Convert.ToDecimal(dt.Rows[0]["Rate"]);
        //        model.Quantity = Convert.ToInt32(dt.Rows[0]["Quantity"]);
        //        model.TotalAmount = Convert.ToDecimal(dt.Rows[0]["TotalAmount"]);
        //    }
        //    return model;
        //}

        #endregion
    }
}