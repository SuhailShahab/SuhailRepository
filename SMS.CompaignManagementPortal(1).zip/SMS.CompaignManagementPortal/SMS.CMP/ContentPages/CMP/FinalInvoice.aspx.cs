﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.CMP
{
    public partial class FinalInvoice : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        /// <summary>
        /// Get all records of final payment invoice
        /// </summary>
        /// <returns>Invoice List</returns>
        [WebMethod]
        public static FinalPaymentInvoiceModelView GetRecord()
        {
            FinalPaymentInvoiceModelView modelView = new FinalPaymentInvoiceModelView();
            try
            {
                List<FinalPaymentInvoiceModel> lstFinalPaymentInvoices = new InvoiceBLL().GetFinalPaymentInvoice();
                List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));

                if (organizations != null && organizations.Count > 0)
                    modelView.Organizations = organizations;

                if (lstFinalPaymentInvoices != null && lstFinalPaymentInvoices.Count > 0)
                {
                    modelView.lstFinalPaymentInvoices = lstFinalPaymentInvoices;
                    modelView.TotalCount = lstFinalPaymentInvoices.Count;
                }
            }
            catch (Exception ex)
            {
               // LazySingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Invoice, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.FinalInvoice, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new FinalPaymentInvoiceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new FinalPaymentInvoiceModelView("error|" + ex.Message);
                }
            }

            return modelView;
        }

        /// <summary>
        /// Get all Campaign Payement Invoice
        /// </summary>
        /// <returns>Invoice List</returns>
        [WebMethod]
        public static List<InvoiceModel> GetAllCampaignPaymentInvoice(string departmentID, string organizationID, string dateOfInvoice)
        {
            InvoiceModel model = null;
            List<InvoiceModel> Invoices = new List<InvoiceModel>();
            try
            {
                Invoices = new InvoiceBLL().GetAllCampaignPaymentInvoice(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), Convert.ToDateTime(dateOfInvoice));
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllCampaignPaymentInvoice", 1, PageNames.FinalInvoice, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new InvoiceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new InvoiceModel("error|" + ex.Message);
                }
               // LazySingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetAllCampaignPaymentInvoice", 1, PageNames.Invoice, CurrentUser.GetSessionUserInfo()));
            }
            return Invoices;
        }

        /// <summary>
        /// Get Campaign Payement Invoice Data by Final Invoice ID
        /// </summary>
        /// <returns>Invoice List</returns>
        [WebMethod]
        public static List<InvoiceModel> GetCampaignPaymentInvoiceInfo(string FinalInvoiceNo)
        {
            InvoiceModel model = null;
            List<InvoiceModel> Invoices = new List<InvoiceModel>();
            try
            {
                Invoices = new InvoiceBLL().GetCampaignPaymentInvoiceInfo(FinalInvoiceNo);
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllCampaignPaymentInvoice", 1, PageNames.FinalInvoice, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new InvoiceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new InvoiceModel("error|" + ex.Message);
                }
                //LazySingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetAllCampaignPaymentInvoice", 1, PageNames.Invoice, CurrentUser.GetSessionUserInfo()));
            }
            return Invoices;
        }

        /// <summary>
        /// get Departments and Campaigns By Organization ID
        /// </summary>
        /// <param name="organizationID"> Selected Organizaiton ID</param>
        /// <returns>Department and Campaign List</returns>
        [WebMethod]
        public static InvoiceModelView GetDepartments(string organizationID, string departmentID)
        {
            InvoiceModelView model = new InvoiceModelView();

            try
            {
                List<SMSCampaignModel> lstCampaigns = new List<SMSCampaignModel>();

                if (departmentID != "undefined")
                {
                    lstCampaigns = new SMSCampaignBLL().GetCampaings(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), null);
                }

                List<DepartmentsModel> lstDepartments = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(organizationID));

                if (lstDepartments != null && lstDepartments.Count > 0)
                {
                    model.Departments = lstDepartments;
                }

                if (lstCampaigns != null && lstCampaigns.Count > 0)
                {
                    model.Campaigns = lstCampaigns;
                }
                return model;
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.FinalInvoice, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new InvoiceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new InvoiceModelView("error|" + ex.Message);
                }
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetShortCodes", 0, PageNames.Invoice, CurrentUser.GetSessionUserInfo()));
            }

            return model;
        }

        /// <summary>
        ///  Save Information
        /// </summary>
        /// <param name="jsonModel">Model Jason string</param>
        /// <returns></returns>
        [WebMethod]
        public static int SaveRecord(string jsonModel)
        {
            int result = 0;
            List<InvoiceListModel> model = null;
            InvoiceModelView invoiceModelView = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<List<InvoiceListModel>>(jsonModel);

                int CreatedBy = CurrentUser.LoginID.Value;

                if (model != null && model.Count > 0)
                {
                    result = new InvoiceBLL().SaveFinalInvoice(model, CreatedBy);
                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.FinalInvoice, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    invoiceModelView = new InvoiceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    invoiceModelView = new InvoiceModelView("error|" + ex.Message);
                }
              //  LazySingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Invoice, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
            }

            return result;
        }

        #endregion
    }
}