﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using BLL.RightsManager;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Script.Serialization;
using System.Web.Services;

// =================================================================================================================================
// Create by:	<M.Shakeel>
// Create date:  <07-03-2018 12:30PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
namespace SMS.CMP.ContentPages.CMP
{
    public partial class CampaignsPriority : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        /// <summary>
        /// Save Campaign
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static CampaignPriorityModel UpdateCampaignPriority(string jsonModel)
        {
            CampaignPriorityModel model = null;
            try
            {
                int? result = 0;
                model = new JavaScriptSerializer().Deserialize<CampaignPriorityModel>(jsonModel);

                result = new SMSCampaignBLL().EditCampaignsPriority(model.CampaignID, model.PriorityID, model.NewPriorityID);

                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.CampaignsPriority, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new CampaignPriorityModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new CampaignPriorityModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get Campaign Information
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static CampaignPriorityViewModel GetRecord(string jsonModel, bool isLoad)
        {
            CampaignPriorityViewModel model = null;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                UserModel User = new UserModel();

                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                User.UserTypeID = CurrentUser.UserTypeID;

                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    model = new JavaScriptSerializer().Deserialize<CampaignPriorityViewModel>(jsonModel);
                }
                else
                {
                    model = new CampaignPriorityViewModel();
                    model.PageNo = 1;
                }

                model.PageSize = PageSize;
                model.User = User;
                if (!isLoad)
                {
                    List<OrganizationModel> organizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                    if (organizations != null && organizations.Count > 0)
                        model.Organizations = organizations;
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.CampaignsPriority, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new CampaignPriorityViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new CampaignPriorityViewModel("error|" + ex.Message);
                }

            }

            return model;
        }

        [WebMethod]
        public static CampaignPriorityViewModel GetRecordSearch(int? organizationID, int? departmentID, int? campaignID)
        {
            CampaignPriorityViewModel model = null;
            List<CampaignPriorityModel> smsCampaigns = null;
            model = new CampaignPriorityViewModel();
            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion
                if (campaignID == -1)
                {
                    campaignID = null;
                }
                smsCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaignsPriority(organizationID, departmentID, campaignID);

                if (smsCampaigns != null && smsCampaigns.Count > 0)
                {
                    model.CampaignsPriority = smsCampaigns;
                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordSearch", 1, PageNames.CampaignsPriority, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new CampaignPriorityViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new CampaignPriorityViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// get Department  and ShortCode By Organization ID
        /// </summary>
        /// <param name="organizationID"> Selected Organizaiton ID</param>
        /// <returns>Department List and Shortcode List</returns>
        [WebMethod]
        public static CampaignPriorityViewModel GetDepartments(string organizationID)
        {
            CampaignPriorityViewModel model = new CampaignPriorityViewModel();

            try
            {
                if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID.Value > 0)
                {
                    model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                }
                else
                {
                    model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.spGetUserDeptByIDs(CurrentUser.LoginID.Value, Convert.ToInt32(organizationID), null);
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.CampaignsPriority, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new CampaignPriorityViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new CampaignPriorityViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static CampaignPriorityViewModel GetCampaings(int? organizationID, int? departmentID)
        {
            CampaignPriorityViewModel model = new CampaignPriorityViewModel();

            try
            {
                if (organizationID.HasValue && organizationID.Value > 0 && departmentID.HasValue && departmentID.Value > 0)
                {
                    model.Campaignslist = LazySingletonBLL<SMSCampaignBLL>.Instance.GetCampaings(organizationID, departmentID, null);
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.CampaignsPriority, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new CampaignPriorityViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new CampaignPriorityViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion
    }
}