﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web.Script.Serialization;
using System.Web.Services;

namespace SMS.CMP.ContentPages.CMP
{
    public partial class SMSTemplate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static SMSTemplateModel SaveRecord(string jsonModel)
        {
            int result = 0;
            SMSTemplateModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<SMSTemplateModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;

                if (model.MessageType == 2)     // for english else urdu
                {
                    model.TemplateMessageUrdu = null;
                    model.NoOfSMS = model.NoOfSMSEng;
                }
                else
                {
                    model.TemplateMessageEng = null;
                    model.NoOfSMS = model.NoOfSMSUrd;
                }

                result = new SMSTemplateBLL().Save(model);

                if (result > 0)
                {
                    model.ID = result;
                }

                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (BusinessException ex)
            {
                model = new SMSTemplateModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSTemplateModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSTemplateModel("error|" + ex.Message);
                }
            }

            return model;
        }


        /// <summary>
        /// get Department By Organization ID
        /// </summary>
        /// <returns>Department List</returns>
        [WebMethod]
        public static SMSTemplateModelView GetDepartments(string organizationID)
        {
            SMSTemplateModelView model = new SMSTemplateModelView();
            List<DepartmentsModel> departments = null;
            try
            {
                departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                if (departments != null && departments.Count > 0)
                    model.Departments = departments;
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDepartments", 0, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSTemplateModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSTemplateModelView("error|" + ex.Message);
                }

            }
            return model;
        }


        /// <summary>
        /// This method user to get the record
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static SMSTemplateModelView GetRecord(string jsonModel)
        {
            SMSTemplateModelView model = null;
            List<SMSTemplateModel> listSMSTemplate = null;
            List<OrganizationModel> listOrganization = new List<OrganizationModel>();

            UserModel User = new UserModel();
            User.UserID = CurrentUser.LoginID;
            User.OrganizationID = CurrentUser.OrganizationID;
            User.DepartmentID = CurrentUser.DepartmentID;
            // model.User = new UserModel();


            try
            {

                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion


                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    model = new JavaScriptSerializer().Deserialize<SMSTemplateModelView>(jsonModel);
                }
                else
                {
                    model = new SMSTemplateModelView();
                    model.PageNo = 1;
                }

                model.PageSize = PageSize;
                model.User = User;


                List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));

                if (organizations != null && organizations.Count > 0)
                    model.Organizations = organizations;

                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    listSMSTemplate = new SMSTemplateBLL().GetAllSMSTemplates(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);
                }
                else if (CurrentUser.OrganizationID > 0)
                {
                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    listSMSTemplate = new SMSTemplateBLL().GetAllSMSTemplates(CurrentUser.OrganizationID, null, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);
                }
                else
                    listSMSTemplate = new SMSTemplateBLL().GetAllSMSTemplates(null, null, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);

                if (listSMSTemplate != null && listSMSTemplate.Count > 0)
                {
                    model.Templates = new List<SMSTemplateModel>();
                    model.Templates = listSMSTemplate;
                    model.TotalCount = listSMSTemplate[0].RESULT_COUNT.Value;
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSTemplateModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSTemplateModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static SMSTemplateModelView GetRecordSearch(string jsonModel, string searchText)
        {
            SMSTemplateModelView model = null;
            List<SMSTemplateModel> listSMSTemplate = null;
            List<OrganizationModel> listOrganization = new List<OrganizationModel>();

            UserModel User = new UserModel();
            User.UserID = CurrentUser.LoginID;
            User.OrganizationID = CurrentUser.OrganizationID;
            User.DepartmentID = CurrentUser.DepartmentID;
            // model.User = new UserModel();
            searchText = searchText.Length > 0 ? searchText : string.Empty;

            try
            {

                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion


                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    model = new JavaScriptSerializer().Deserialize<SMSTemplateModelView>(jsonModel);
                }
                else
                {
                    model = new SMSTemplateModelView();
                    model.PageNo = 1;
                }
                model.PageSize = PageSize;
                model.User = User;


                List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));

                if (organizations != null && organizations.Count > 0)
                    model.Organizations = organizations;

                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    listSMSTemplate = new SMSTemplateBLL().GetAllSMSTemplates(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID.Value, model.PageNo, model.PageSize, searchText);
                }
                else if (CurrentUser.OrganizationID > 0)
                {
                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    listSMSTemplate = new SMSTemplateBLL().GetAllSMSTemplates(CurrentUser.OrganizationID, null, CurrentUser.LoginID.Value, model.PageNo, model.PageSize, searchText);
                }
                else
                    listSMSTemplate = new SMSTemplateBLL().GetAllSMSTemplates(null, null, CurrentUser.LoginID.Value, model.PageNo, model.PageSize, searchText);

                if (listSMSTemplate != null && listSMSTemplate.Count > 0)
                {
                    model.Templates = new List<SMSTemplateModel>();
                    model.Templates = listSMSTemplate;
                    model.TotalCount = listSMSTemplate[0].RESULT_COUNT.Value;
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSTemplateModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSTemplateModelView("error|" + ex.Message);
                }
            }

            return model;
        }


        [WebMethod]
        public static SMSTemplateModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            SMSTemplateModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<SMSTemplateModel>(jsonModel);
                result = new SMSTemplateBLL().Delete(model);
                // return (result.HasValue && result.Value > -1 ? "true" : "false");
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.SMSTemplate, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSTemplateModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSTemplateModelView("error|" + ex.Message);
                }
            }

            return model;
            //TODO: return value or message for integation   
        }

        #endregion
    }
}