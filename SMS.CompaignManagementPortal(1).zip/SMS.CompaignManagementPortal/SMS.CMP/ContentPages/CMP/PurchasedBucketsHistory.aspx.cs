﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Web.Services;

namespace SMS.CMP.ContentPages.CMP
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //GetOrganization();
        }

        #region "Old Code"
        //[WebMethod]
        //public static BucketHistory GetRecords(string organizationID, string departmentID)
        //{
        //    BucketHistory model = new BucketHistory();
        //    int loginID = CurrentUser.LoginID.Value;

        //    try
        //    {
        //        UserModel User = new UserModel();
        //        User.UserID = CurrentUser.LoginID;
        //        User.OrganizationID = CurrentUser.OrganizationID;
        //        User.DepartmentID = CurrentUser.DepartmentID;
        //        model.User = User;

        //        model.Payments = new List<PaymentModel>();

        //        // Get Organization
        //        List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
        //        if (organizations != null && organizations.Count > 0)
        //            model.Organizations = organizations;

        //        // user Drop Down seletion By User Rights
        //        if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
        //        {
        //            model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
        //            model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID);
        //        }
        //        else if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID == 0)
        //        {
        //            model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
        //            model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(CurrentUser.OrganizationID, null, CurrentUser.LoginID);
        //        }
        //        else
        //        {
        //            if (Convert.ToInt32(organizationID) != 0 && Convert.ToInt32(departmentID) != 0)
        //                model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), CurrentUser.LoginID);
        //            else
        //                model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(null, null, CurrentUser.LoginID);
        //        }

        //        model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
        //    }
        //    catch (Exception ex)
        //    {
        //        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 0, PageNames.PurchasedBucketsHistory, CurrentUser.GetSessionUserInfo()));
        //        LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
        //    }

        //    return model;
        //}
        #endregion

        #region Web Methods

        [WebMethod]
        public static BucketHistory GetRecords(string organizationID, string departmentID, bool isLoad)
        {
            BucketHistory model = new BucketHistory();
            int loginID = CurrentUser.LoginID.Value;

            try
            {
                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                model.User = User;

                model.Payments = new List<PaymentModel>();

                // Get Organization
                if (!isLoad)
                {
                    List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                    if (organizations != null && organizations.Count > 0)
                        model.Organizations = organizations;
                }

                // user Drop Down seletion By User Rights
                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                  //  model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                   // model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID);
                    model.Payments = LazySingletonBLL<PaymentBLL>.Instance.GetPurchasedBucketsHistoryByOrgID(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID);
                }
                else if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID == 0 && isLoad == true)
                {
                    //model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    //model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(CurrentUser.OrganizationID, null, CurrentUser.LoginID);
                   // model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(CurrentUser.OrganizationID, Convert.ToInt32(departmentID), CurrentUser.LoginID);
                    model.Payments = LazySingletonBLL<PaymentBLL>.Instance.GetPurchasedBucketsHistoryByOrgID(CurrentUser.OrganizationID, Convert.ToInt32(departmentID), CurrentUser.LoginID);
                }
                else if (isLoad == true)
                {
                    model.Payments = LazySingletonBLL<PaymentBLL>.Instance.GetPurchasedBucketsHistoryByOrgID(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), CurrentUser.LoginID);
                    //model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), CurrentUser.LoginID);
                   
                    //if (Convert.ToInt32(organizationID) != 0 && Convert.ToInt32(departmentID) != 0)
                    //    model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), CurrentUser.LoginID);
                    //else
                    //    model.Payments = new PaymentBLL().GetPurchasedBucketsHistoryByOrgID(null, null, CurrentUser.LoginID);
                }

              //  model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);

               
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 0, PageNames.PurchasedBucketsHistory, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.PurchasedBucketsHistory, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new BucketHistory("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new BucketHistory("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// get Department By Organization ID
        /// </summary>
        /// <returns>Department List</returns>
        [WebMethod]
        public static BucketHistory GetDepartments(string organizationID)
        {
            BucketHistory model = new BucketHistory();
            List<DepartmentsModel> departments = null;

            try
            {
                departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                if (departments != null && departments.Count > 0)
                    model.Departments = departments;
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDepartments", 0, PageNames.PurchasedBucketsHistory, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.PurchasedBucketsHistory, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new BucketHistory("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new BucketHistory("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion

        # region Private Methods

        //private void GetOrganization()
        //{
        //    List<OrganizationModel> OrgList = new OrganizationBLL().GetOrganizations();
        //    ddlOrganization.DataSource = OrgList;
        //    ddlOrganization.DataValueField = "ID";
        //    ddlOrganization.DataTextField = "Title";
        //    ddlOrganization.DataBind();
        //    if (OrgList.FirstOrDefault(s => s.ID.Value == CurrentUser.OrganizationID.Value) != null) ddlOrganization.SelectedValue = OrgList.FirstOrDefault(s => s.ID.Value == CurrentUser.OrganizationID.Value).Title;
        //    else ddlOrganization.Items.Insert(0, new ListItem("Choose...", "0"));
        //}

        #endregion

    }
}