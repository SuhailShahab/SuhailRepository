﻿
// =================================================================================================================================
// Create by:	<Sohail Kamran>
// Create date: <4559	add	Sohail Kamran	19/10/2015 2:10:30 PM>

// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription

// =================================================================================================================================
using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Linq;
using BE.RightsManager;
using System.Configuration;
using BLL.CustomExceptions;

namespace SMS.CMP.ContentPages.CMP
{
    public partial class Contact : System.Web.UI.Page
    {

        //public int PageNo { get; set; }
        //public int PageSize { get; set; }
        /// <summary>
        /// page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

            //PageNo = 1;
            //PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());


            if (Page.Request.Files.Count > 0)
            {
                try
                {
                    #region "Fetting ID's from Http"
                    int organizationID = Convert.ToInt32(Page.Request.Form["organizationID"]);
                    int departmentID = Convert.ToInt32(Page.Request.Form["departmentID"]);

                    #endregion

                    #region "Getting Contacts from Files"
                    DataTable dtTemp = new Common().UploadContactsFiles(Page.Request);
                   // DataTable dtTemp = LazySingletonBLL<Common>.Instance.UploadBulkContactsFiles(Page.Request);
                    #endregion

                    #region "Validate List of contacts"
                    DataSet ds = Common.ValidateContacts(dtTemp);
                    DataTable dtContacts = ds.Tables[0].Copy();
                    DataTable dtWrongContacts = ds.Tables[1].Copy();
                    #endregion


                    #region "Saving Contacts into Contacts and Address Book Contact"
                    if (dtContacts.Rows.Count > 0)
                    {
                        // DataTable dtDuplicate = new AddressBookBLL().SaveImportContacts(dtContacts, organizationID, departmentID, CurrentUser.LoginID);
                        DataTable dtDuplicate = LazySingletonBLL<AddressBookBLL>.Instance.SaveImportContacts(dtContacts, organizationID, departmentID, CurrentUser.LoginID);
                        if (dtDuplicate.Rows.Count > 0 && !dtDuplicate.Columns.Contains("Column1")) dtWrongContacts.Merge(dtDuplicate);
                    }
                    #endregion

                }
                catch (Exception ex)
                {
                    LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.Contact, CurrentUser.GetSessionUserInfo()));

                }

            }
        }

        #region "Web Methods"

        /// <summary>
        /// save record information
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static ContactModel SaveRecord(string jsonModel)
        {
            int result = 0;

            ContactModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<ContactModel>(jsonModel);

                model.CreatedBy = CurrentUser.LoginID;
                model.ContactNo = model.Phone;
                //model.Phone = new CommonBLL().ConvertPhoneNO92(model.ContactNo);
                model.Phone = LazySingletonBLL<CommonBLL>.Instance.ConvertPhoneNO92(model.ContactNo);
                result = new ContactBLL().Save(model);
                
                if (result > 0)
                {
                    model.ID = result;
                }

                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (BusinessException ex)
            {
                model = new ContactModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ContactModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ContactModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static ContactModelView GetDepartments(string organizationID)
        {
            ContactModelView contactModelView = new ContactModelView();
            List<DepartmentsModel> listDepartment = null; //new List<DepartmentsModel>();
            //listDepartment = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(organizationID));
            listDepartment = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);

            try
            {
                if (listDepartment != null && listDepartment.Count > 0)
                {
                   // contactModelView.Departments = new List<DepartmentsModel>();
                    contactModelView.Departments = listDepartment;
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(contactModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    contactModelView = new ContactModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    contactModelView = new ContactModelView("error|" + ex.Message);
                }
                   
            }
            return contactModelView;
        }

        /// <summary>
        /// Get Records By Search 
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        
        [WebMethod]
        public static ContactModelView GetRecordSearch(string jsonModel, string searchText, string organizationID, string departmentID)
        {
            ContactModelView contactModelView = null;
            List<ContactModel> listContacts = new List<ContactModel>();
            List<OrganizationModel> listOrganization = new List<OrganizationModel>();
            int? orgID = null;
            int? deptID = null;


            searchText = searchText.Length > 0 ? searchText : string.Empty;

            try
            {
                #region "Set Page Size"
                int PageSize = ConfigurationHelper.PageSize;
                #endregion


                if (jsonModel != "null")
                {
                    contactModelView = new JavaScriptSerializer().Deserialize<ContactModelView>(jsonModel);
                }
                else
                {
                    contactModelView = new ContactModelView();
                    contactModelView.PageNo = 1;
                }
                contactModelView.PageSize = PageSize;

                #region "Filling User Model "
                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                #endregion

                contactModelView.User = User;

                #region "Filling ContactModelView Model "

                if (string.IsNullOrEmpty(organizationID) || organizationID == "null" || organizationID == "undefined")
                {
                    orgID = CurrentUser.OrganizationID;
                }
                else
                {
                    orgID = Convert.ToInt32(organizationID);
                }

                if (string.IsNullOrEmpty(departmentID) || departmentID == "null" || departmentID == "undefined")
                {
                    deptID = CurrentUser.DepartmentID;
                }
                else 
                {
                    deptID = Convert.ToInt32(departmentID);
                }

                listContacts = LazySingletonBLL<ContactBLL>.Instance.GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, CurrentUser.LoginID, searchText, deptID,orgID);
                
                /*
                if (Convert.ToInt32(organizationID) > 0 && Convert.ToInt32(departmentID) > 0)
                {
                    //listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), searchText, Convert.ToInt32(departmentID), Convert.ToInt32(organizationID));
                    //listOrganization = new OrganizationBLL().GetOrganization(CurrentUser.OrganizationID.Value);
                    listContacts = LazySingletonBLL<ContactBLL>.Instance.GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), searchText, Convert.ToInt32(departmentID), Convert.ToInt32(organizationID));
                }
                else if (Convert.ToInt32(organizationID) > 0 && Convert.ToInt32(departmentID) == 0)
                {
                    //listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), searchText,null, Convert.ToInt32(organizationID));
                    //listOrganization = new OrganizationBLL().GetOrganization(CurrentUser.OrganizationID.Value);
                    listContacts = LazySingletonBLL<ContactBLL>.Instance.GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, CurrentUser.LoginID, searchText, null, Convert.ToInt32(organizationID));
                }
                else if (Convert.ToInt32(departmentID) > 0)
                {
                    //listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), searchText, Convert.ToInt32(departmentID), null);
                    //listOrganization = new OrganizationBLL().GetOrganization(CurrentUser.OrganizationID.Value);
                    listContacts = LazySingletonBLL<ContactBLL>.Instance.GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, CurrentUser.LoginID, searchText, Convert.ToInt32(departmentID), null);
                }
                else
                {
                    //listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), searchText, null, null);
                    //listOrganization = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                    listContacts = LazySingletonBLL<ContactBLL>.Instance.GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, CurrentUser.LoginID, searchText, null, null);
                }
                */
                contactModelView.Contacts = new List<ContactModel>();
                if (listContacts != null && listContacts.Count > 0)
                {
                    contactModelView.Contacts = listContacts;
                    contactModelView.TotalCount = listContacts[0].RESULT_COUNT.Value;
                }

                contactModelView.Organizations = new List<OrganizationModel>();
                if (listOrganization != null && listOrganization.Count > 0)
                {
                    contactModelView.Organizations = listOrganization;
                }

                contactModelView.UserGroupID = CurrentUser.OrganizationID.Value;
                contactModelView.IsEnable = CurrentUser.UserTypeID.Value != UserTypeNames.Admin.GetHashCode() ? false : true;
                #endregion

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecordSearch", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(contactModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordSearch", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    contactModelView = new ContactModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    contactModelView = new ContactModelView("error|" + ex.Message);
                }
            }

            return contactModelView;

        }

        #region "Old GetRecordSearch method"
        /*public static ContactModelView GetRecordSearch(string jsonModel, string searchText)
        {
            ContactModelView contactModelView = null;
            List<ContactModel> listContacts = new List<ContactModel>();
            List<OrganizationModel> listOrganization = new List<OrganizationModel>();


            searchText = searchText.Length > 0 ? searchText : string.Empty;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion


                if (jsonModel != "null")
                {
                    contactModelView = new JavaScriptSerializer().Deserialize<ContactModelView>(jsonModel);
                }
                else
                {
                    contactModelView = new ContactModelView();
                    contactModelView.PageNo = 1;
                }
                contactModelView.PageSize = PageSize;

                #region "Filling User Model "
                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                //User.OrganizationID = organizationID;
                //User.DepartmentID = departmentID;
                #endregion

                contactModelView.User = User;

                #region "Filling ContactModelView Model "


                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), searchText, Convert.ToInt32(CurrentUser.DepartmentID), Convert.ToInt32(CurrentUser.OrganizationID));
                    listOrganization = new OrganizationBLL().GetOrganization(CurrentUser.OrganizationID.Value);
                }
                else if (CurrentUser.OrganizationID > 0)
                {
                    listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), searchText, null, Convert.ToInt32(CurrentUser.OrganizationID));
                    listOrganization = new OrganizationBLL().GetOrganization(CurrentUser.OrganizationID.Value);
                }
                else
                {
                    listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), searchText, null, null);
                    listOrganization = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                }

                contactModelView.Contacts = new List<ContactModel>();
                if (listContacts != null && listContacts.Count > 0)
                {
                    contactModelView.Contacts = listContacts;
                    contactModelView.TotalCount = listContacts[0].RESULT_COUNT.Value;
                }

                contactModelView.Organizations = new List<OrganizationModel>();
                if (listOrganization != null && listOrganization.Count > 0)
                {
                    contactModelView.Organizations = listOrganization;
                }

                contactModelView.UserGroupID = CurrentUser.OrganizationID.Value;
                contactModelView.IsEnable = CurrentUser.UserTypeID.Value != UserTypeNames.Admin.GetHashCode() ? false : true;
                #endregion

            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecordSearch", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(contactModelView, ex.Message);
            }

            return contactModelView;

        } */
        
        #endregion

        /// <summary>
        /// Get All Contacts Information
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static ContactModelView GetRecord(string jsonModel)
        {
            ContactModelView contactModelView = null;
            List<ContactModel> listContacts = new List<ContactModel>();
            List<OrganizationModel> listOrganization = new List<OrganizationModel>();

            List<DepartmentsModel> listDepartment = new List<DepartmentsModel>();

            try
            {
                #region "Set Page Size"
                //int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                int PageSize = ConfigurationHelper.PageSize;

                #endregion


                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    contactModelView = new JavaScriptSerializer().Deserialize<ContactModelView>(jsonModel);
                }
                else
                {
                    contactModelView = new ContactModelView();
                    contactModelView.PageNo = 1;
                }
                contactModelView.PageSize = PageSize;

                #region "Filling User Model "
                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                #endregion

                contactModelView.User = User;

                #region "Filling ContactModelView Model "



                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    //listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), Convert.ToInt32(CurrentUser.DepartmentID), Convert.ToInt32(CurrentUser.OrganizationID));
                    //listOrganization = new OrganizationBLL().GetOrganization(CurrentUser.OrganizationID.Value);
                    //listDepartment = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(CurrentUser.OrganizationID,CurrentUser.LoginID, CurrentUser.DepartmentID);
                    listContacts = LazySingletonBLL<ContactBLL>.Instance.GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), Convert.ToInt32(CurrentUser.DepartmentID), Convert.ToInt32(CurrentUser.OrganizationID));
                    listOrganization = LazySingletonBLL<OrganizationBLL>.Instance.GetOrganization(CurrentUser.OrganizationID.Value);
                    listDepartment = LazySingletonBLL<DepartmentsBLL>.Instance.SelectActiveDepartmentsByOrgID(CurrentUser.OrganizationID, CurrentUser.LoginID, CurrentUser.DepartmentID);
                    
                }
                else if (CurrentUser.OrganizationID > 0)
                {
                    //listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize,CurrentUser.LoginID, null, Convert.ToInt32(CurrentUser.OrganizationID));
                    //listOrganization = new OrganizationBLL().GetOrganization(CurrentUser.OrganizationID.Value);
                    //listDepartment = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(User.OrganizationID));
                    listContacts = LazySingletonBLL<ContactBLL>.Instance.GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, CurrentUser.LoginID, null, Convert.ToInt32(CurrentUser.OrganizationID));
                    listOrganization = LazySingletonBLL<OrganizationBLL>.Instance.GetOrganization(CurrentUser.OrganizationID.Value);
                    listDepartment = LazySingletonBLL<DepartmentsBLL>.Instance.SelectActiveDepartmentsByOrgID(Convert.ToInt32(User.OrganizationID), CurrentUser.LoginID, CurrentUser.DepartmentID);
                }
                else
                {
                    //code blocked to autoload all records on pageload
                    //listContacts = new ContactBLL().GetAllContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, CurrentUser.LoginID, null, null);
                    
                    //listOrganization = new OrganizationBLL().SelectOrganizationByUserID(CurrentUser.LoginID.Value);
                    listOrganization = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(CurrentUser.LoginID.Value);

                }


                contactModelView.Contacts = new List<ContactModel>();
                if (listContacts != null && listContacts.Count > 0)
                {
                    contactModelView.Contacts = listContacts;
                    contactModelView.TotalCount = listContacts[0].RESULT_COUNT.Value;
                }

                contactModelView.Organizations = new List<OrganizationModel>();
                if (listOrganization != null && listOrganization.Count > 0)
                {
                    contactModelView.Organizations = listOrganization;
                }

                if (listDepartment != null && listDepartment.Count > 0)
                {
                    contactModelView.Departments = listDepartment;
                }

                contactModelView.UserGroupID = CurrentUser.OrganizationID.Value;
                contactModelView.IsEnable = CurrentUser.UserTypeID.Value != UserTypeNames.Admin.GetHashCode() ? false : true;
                #endregion

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(contactModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    contactModelView = new ContactModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    contactModelView = new ContactModelView("error|" + ex.Message);
                }
            }

            return contactModelView;

        }

        [WebMethod]
        public static ContactModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            ContactModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<ContactModel>(jsonModel);
                result = new ContactBLL().Delete(model);
                //return (result.HasValue && result.Value > -1 ? "true" : "false");
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.DeletedSuccessfully);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ContactModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ContactModel("error|" + ex.Message);
                }

            }

            return model;
        }

        #endregion
    }
}