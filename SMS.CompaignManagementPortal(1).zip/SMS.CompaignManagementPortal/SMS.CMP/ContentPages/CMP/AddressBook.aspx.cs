﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace SMS.CMP.ContentPages.CMP
{
    public partial class AddressBook : System.Web.UI.Page
    {
        /// <summary>
        /// page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            DataTable dtWrongContacts = null;
            if (Page.Request.Files.Count > 0)
            {
                try
                {
                    #region "Fetting ID's from Http"
                    int organizationID = Convert.ToInt32(Page.Request.Form["organizationID"]);
                    int addressBookID = Convert.ToInt32(Page.Request.Form["addressBookID"]);
                    int departmentID = Convert.ToInt32(Page.Request.Form["departmentID"]);
                    #endregion

                    #region "Getting Contacts from Files"
                    DataTable dtTemp = new Common().UploadContactsFiles(Page.Request);
                    #endregion
                    DataSet ds = null;
                    DataTable dtContacts = null;
                    
                    #region "Validate List of contacts"
                    if(dtTemp!=null && dtTemp.Rows.Count>0)
                    {
                         ds = Common.ValidateContacts(dtTemp);
                         dtContacts = ds.Tables[0].Copy();
                         dtWrongContacts = ds.Tables[1].Copy();
                    }                    
                    
                    #endregion

                    #region "Saving Contacts into Contacts and Address Book Contact"

                    if (dtContacts!=null && dtContacts.Rows.Count > 0)
                    {                       
                        DataTable dtDuplicate = LazySingletonBLL<AddressBookBLL>.Instance.SaveImportContacts(dtContacts, organizationID, departmentID, addressBookID, CurrentUser.LoginID);
                        
                        if (dtDuplicate.Rows.Count > 0 && !dtDuplicate.Columns.Contains("Column1"))
                        {
                            dtWrongContacts.Merge(dtDuplicate);
                            
                        }
                           
                    }

                    #endregion
                    string message = this.FileReadReport(dtContacts, dtWrongContacts);
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "invalidSelction", "toastr.info(" + message + ");", true);

                    
                }
                catch (Exception ex)
                {
                    LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.AddressBook, CurrentUser.GetSessionUserInfo()));
                    if (dtWrongContacts != null && dtWrongContacts.Rows.Count > 0)
                        LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(new Exception("Wrong Contacts" + dtWrongContacts.Rows.Count), "Page_Load", 0, PageNames.AddressBook, CurrentUser.LoginID));
      
                }

            }

            if (!IsPostBack)
            {

                //  DropDownRestriction (CurrentUser.GetSessionUserInfo());

            }
        }

        #region "Web Methods"
        public string  FileReadReport(DataTable dtReadPhoneNos, DataTable dtWronPhoneNos)
        {
            StringBuilder sbMsg = new StringBuilder();
            int wrongPhoneNos=0,readPhonesNos=0;
            

            if (dtWronPhoneNos.Rows.Count > 0 && !dtWronPhoneNos.Columns.Contains("Column1"))
            {
                wrongPhoneNos = dtWronPhoneNos.Rows.Count;
            }

            if (dtReadPhoneNos != null && dtReadPhoneNos.Rows.Count > 0)
            {
                readPhonesNos = dtReadPhoneNos.Rows.Count;
            }
            sbMsg.AppendLine("============================================");
            sbMsg.Append("Total PhoneNos = ");
            sbMsg.AppendLine((wrongPhoneNos + readPhonesNos).ToString());
            sbMsg.Append("Total Successfully Reads PhoneNos = ");
            sbMsg.AppendLine(readPhonesNos.ToString());
            sbMsg.Append("Total Wrong PhoneNos = ");
            sbMsg.AppendLine(dtWronPhoneNos.ToString());
            sbMsg.AppendLine("============================================");
            return sbMsg.ToString();
        }

        /// <summary>
        /// Saving Address Book Information
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static AddressBooksModel SaveRecord(string jsonModel)
        {
            int result = 0;
            AddressBooksModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<AddressBooksModel>(jsonModel);

                result = new AddressBookBLL().Save(model);
                if (result > 0)
                {
                    model.AddressBookID = result;
                    model.NoOfContacts = 0;
                }
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (BusinessException ex)
            {
                model = new AddressBooksModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(new AddressBooksModel(), ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new AddressBooksModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new AddressBooksModel("error|" + ex.Message);
                }
            }

            return model;

        }


        /// <summary>
        /// get Department By Organization ID
        /// </summary>
        /// <returns>Department List</returns>
        [WebMethod]
        public static AddressBookModelView GetDepartments(string organizationID)
        {
            AddressBookModelView addressBooksModelView = new AddressBookModelView();

            List<DepartmentsModel> departments = null;
            try
            {
                //departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                if (departments != null && departments.Count > 0)
                    addressBooksModelView.Departments = departments;
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, ex.Message, 1, PageNames.AddressBook, 0));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(addressBooksModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ex.Message);
                }
            }
            return addressBooksModelView;
        }
        /// <summary>
        /// Getting Contacts Information
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="addressBookID"></param>
        /// <param name="isView"></param>
        /// <returns></returns>
        [WebMethod]
        public static AddressBookModelView GetContacts(string organizationID, string addressBookID, string isView, string pageNo, string pageSize,string departmentID)
        {
            AddressBookModelView addressBooksModelView = new AddressBookModelView();
            
            List<ContactModel> contacts = null;
            List<DepartmentsModel> departments = null;

            try
            {
                bool isViewOnly = Convert.ToBoolean(isView);

                int OrganizationID = Convert.ToInt32(organizationID);
                int AddressbookID = Convert.ToInt32(addressBookID);
                int DepartmentID = departmentID != "undefined" ? Convert.ToInt32(departmentID) : 0;

                int PageNo = Convert.ToInt32(pageNo);
                int PageSize = Convert.ToInt32(pageSize);

                int? departmentID1 = DepartmentID;

                if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID.Value > 0 && departmentID1==0) 
                    departmentID1 = CurrentUser.DepartmentID;

               

                contacts = new List<ContactModel>();
                contacts = new ContactBLL().GetAddressBookContacts(OrganizationID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize);
               // contacts = new ContactBLL().GetAllActiveContacts(OrganizationID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize);

                if (!isViewOnly)
                {
                    if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
                    {
                       
                        //departments = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(OrganizationID).Where(p => p.DepartmentID == CurrentUser.DepartmentID).ToList();
                        departments = LazySingletonBLL<DepartmentsBLL>.Instance.SelectActiveDepartmentsByOrgID(OrganizationID).Where(p => p.DepartmentID == CurrentUser.DepartmentID).ToList();
                    }
                    else
                    {
                        departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                        //departments = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(OrganizationID);
                       // departments = LazySingletonBLL<DepartmentsBLL>.Instance.SelectActiveDepartmentsByOrgID(OrganizationID);
                    }

                    if (departments.Count > 0)

                        addressBooksModelView.Departments = departments;

                    addressBooksModelView.UserDepartmentID = departmentID1;
                }

             

                //if (departmentID != "undefined" && !isViewOnly)
                //{
                        
                //        contacts = new ContactBLL().GetAllActiveContacts(OrganizationID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize);
                //}
                //else if (departmentID != "undefined" && isViewOnly)
                //{
                //        contacts = new ContactBLL().GetAllActiveContacts(OrganizationID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize);
                //}




                if (contacts.Count > 0)
                {
                    addressBooksModelView.Contacts = contacts;
                    //addressBooksModelView.TotalCount = contacts[0].RESULT_COUNT.Value;
                }

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetContacts", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(addressBooksModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetContacts", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ex.Message);
                }
            }
            return addressBooksModelView;
        }

        [WebMethod]
        public static AddressBookModelView GetContactsSearch(string organizationID, string addressBookID, string isView, string pageNo, string pageSize, string searchText, string departmentID)
        {
            AddressBookModelView addressBooksModelView = new AddressBookModelView();
            List<ContactModel> contacts = null;

            try
            {
                bool isViewOnly = Convert.ToBoolean(isView);

                int orgID = Convert.ToInt32(organizationID);
                int AddressbookID = Convert.ToInt32(addressBookID);
                int DepartmentID = departmentID!="undefined"  ?  Convert.ToInt32(departmentID) : 0;

                int PageNo = Convert.ToInt32(pageNo);
                int PageSize = Convert.ToInt32(pageSize);


                int? departmentID1 = DepartmentID;
                if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID.Value > 0) departmentID1 = CurrentUser.DepartmentID;

                contacts = new List<ContactModel>();
                if (!isViewOnly)
                {
                    if (!string.IsNullOrEmpty(searchText))
                    {
                        contacts = LazySingletonBLL<ContactBLL>.Instance.GetAddressBookContactSearch(orgID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize, searchText);

                        //if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
                        //    contacts = new ContactBLL().GetAllActiveContacts(orgID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize, searchText).Where(p => p.DepartmentID == CurrentUser.DepartmentID).ToList();
                        //else
                        //    contacts = new ContactBLL().GetAllActiveContacts(orgID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize, searchText);
                    }
                    else
                    {
                        //if (CurrentUser.DepartmentID.HasValue && CurrentUser.DepartmentID > 0)
                        //    contacts = new ContactBLL().GetAllActiveContacts(orgID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize).Where(p => p.DepartmentID == CurrentUser.DepartmentID).ToList();
                        //else
                        contacts = LazySingletonBLL<ContactBLL>.Instance.GetAddressBookContacts(orgID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize);
                        // contacts = new ContactBLL().GetAllActiveContacts(orgID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize);
                    }
                    addressBooksModelView.UserDepartmentID = departmentID1;

                }
                else if (isViewOnly)
                {
                    if (!string.IsNullOrEmpty(searchText))
                        //contacts = LazySingletonBLL<ContactBLL>.Instance.GetAllActiveContacts(orgID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize, searchText);
                        contacts = LazySingletonBLL<ContactBLL>.Instance.GetAddressBookContactSearch(orgID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize, searchText);
                    else
                        contacts = LazySingletonBLL<ContactBLL>.Instance.GetAddressBookContacts(orgID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize);
                      //  contacts = new ContactBLL().GetAllActiveContacts(OrganizationID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize);
                }

               

                //else if (departmentID != "undefined" && isViewOnly)
                //{
                //    if (!string.IsNullOrEmpty(searchText))
                //        contacts = new ContactBLL().GetAllActiveContacts(OrganizationID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize, searchText);
                //    else
                //        contacts = new ContactBLL().GetAllActiveContacts(OrganizationID, departmentID1, AddressbookID, isViewOnly, PageNo, PageSize);
                //}

                if (contacts.Count > 0)
                {
                    addressBooksModelView.Contacts = contacts;
                    if (isViewOnly)
                        addressBooksModelView.TotalContactsCount = contacts[0].RESULT_COUNT ?? 0;
                    else
                        addressBooksModelView.TotalContactsCount = contacts[0].RESULT_COUNT??0;

                    //addressBooksModelView.TotalCount = contacts[0].RESULT_COUNT.Value;
                }

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetContactsSearch", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(addressBooksModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetContactsSearch", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ex.Message);
                }
            }
            return addressBooksModelView;
        }

        /// <summary>
        /// Getting Records
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static AddressBookModelView GetRecords(string jsonModel)
        {
            AddressBookModelView addressBooksModelView = null;

            UserModel User = new UserModel();
            User.UserID = CurrentUser.LoginID;
            User.OrganizationID = CurrentUser.OrganizationID;
            User.DepartmentID = CurrentUser.DepartmentID;

            try
            {
                #region "Set Page Size"
                int PageSize = ConfigurationHelper.PageSize; //Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    addressBooksModelView = new JavaScriptSerializer().Deserialize<AddressBookModelView>(jsonModel);
                }
                else
                {
                    addressBooksModelView = new AddressBookModelView();
                    addressBooksModelView.PageNo = 1;
                }

                addressBooksModelView.PageSize = PageSize;
                addressBooksModelView.User = User;

                //List<OrganizationModel> listOrganizations = new OrganizationBLL().SelectOrganizationByUserID(CurrentUser.LoginID.Value);
                List<OrganizationModel> listOrganizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(CurrentUser.LoginID.Value);
                if (listOrganizations != null && listOrganizations.Count > 0)
                {
                    addressBooksModelView.Organizations = new List<OrganizationModel>();
                    addressBooksModelView.Organizations = listOrganizations;
                }

                List<AddressBooksModel> listAddressBooks = new List<AddressBooksModel>();
                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    //addressBooksModelView.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    //listAddressBooks = new AddressBookBLL().GetAllAddressBooksByIDs(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID, addressBooksModelView.PageNo, addressBooksModelView.PageSize);
                    addressBooksModelView.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    listAddressBooks = LazySingletonBLL<AddressBookBLL>.Instance.GetAllAddressBooksByIDs(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID, addressBooksModelView.PageNo, addressBooksModelView.PageSize);

                }
                else if (CurrentUser.OrganizationID > 0)
                {
                    //addressBooksModelView.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    //listAddressBooks = new AddressBookBLL().GetAllAddressBooksByIDs(CurrentUser.OrganizationID, null, CurrentUser.LoginID, addressBooksModelView.PageNo, addressBooksModelView.PageSize);
                    addressBooksModelView.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    listAddressBooks = LazySingletonBLL<AddressBookBLL>.Instance.GetAllAddressBooksByIDs(CurrentUser.OrganizationID, null, CurrentUser.LoginID, addressBooksModelView.PageNo, addressBooksModelView.PageSize);

                }
                else
                    listAddressBooks = null;

                    // removed this section not to load records on pageload 
                    //listAddressBooks = new AddressBookBLL().GetAllAddressBooksByIDs(null, null, CurrentUser.LoginID, addressBooksModelView.PageNo, addressBooksModelView.PageSize);

                if (listAddressBooks != null && listAddressBooks.Count > 0)
                {
                    addressBooksModelView.AddressBooks = new List<AddressBooksModel>();
                    addressBooksModelView.AddressBooks = listAddressBooks;
                    addressBooksModelView.TotalCount = listAddressBooks[0].RESULT_COUNT.Value;
                }

                addressBooksModelView.UserGroupID = CurrentUser.OrganizationID.Value;

                //addressBooksModelView.IsEnable = CurrentUser.UserTypeID.Value != UserTypeNames.Admin.GetHashCode() ? false : true;

                if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID > 0)
                    addressBooksModelView.IsEnable = false;
                else
                    addressBooksModelView.IsEnable = true;
            }
            catch (Exception ex)
            {
              //  LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(addressBooksModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ex.Message);
                }
            }

            return addressBooksModelView;
        }

        /// <summary>
        /// Get Records Search
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        [WebMethod]
        public static AddressBookModelView GetRecordSearch(string jsonModel, string searchText, string organizationID, string departmentID)
        {
            AddressBookModelView addressBooksModelView = null;

            UserModel User = new UserModel();
            User.UserID = CurrentUser.LoginID;
            User.OrganizationID = CurrentUser.OrganizationID;
            User.DepartmentID = CurrentUser.DepartmentID;

            searchText = searchText.Length > 0 ? searchText : string.Empty;

            try
            {
                #region "Set Page Size"
                //int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                int PageSize = ConfigurationHelper.PageSize;
                #endregion

                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    addressBooksModelView = new JavaScriptSerializer().Deserialize<AddressBookModelView>(jsonModel);
                }
                else
                {
                    addressBooksModelView = new AddressBookModelView();
                    addressBooksModelView.PageNo = 1;
                }

                addressBooksModelView.PageSize = PageSize;
                addressBooksModelView.User = User;

                if (string.IsNullOrEmpty(organizationID) || organizationID == "null" || organizationID == "undefined")
                {
                    organizationID = "0";
                }
                if (string.IsNullOrEmpty(departmentID) || departmentID == "null" || departmentID == "undefined")
                {
                    departmentID = "0";
                }

                // If logged in user is not a super user
                if (User.OrganizationID > 0 && User.DepartmentID > 0)
                {
                    organizationID = Convert.ToString(User.OrganizationID);
                    departmentID = Convert.ToString(User.DepartmentID);
                }

                if (User.OrganizationID > 0 && User.DepartmentID == 0)
                {
                    organizationID = Convert.ToString(User.OrganizationID);
                }

                //List<OrganizationModel> listOrganizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                List<OrganizationModel> listOrganizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                
                
                if (listOrganizations != null && listOrganizations.Count > 0)
                {
                    addressBooksModelView.Organizations = new List<OrganizationModel>();
                    addressBooksModelView.Organizations = listOrganizations;
                }

                List<AddressBooksModel> listAddressBooks = new List<AddressBooksModel>();
                //if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                if (Convert.ToInt32(organizationID) > 0 && Convert.ToInt32(departmentID) > 0)
                {
                    //addressBooksModelView.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    //listAddressBooks = new AddressBookBLL().GetAllAddressBooksByIDs(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID, addressBooksModelView.PageNo, addressBooksModelView.PageSize, searchText);
                    //addressBooksModelView.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    listAddressBooks = LazySingletonBLL<AddressBookBLL>.Instance.GetAllAddressBooksByIDs(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), CurrentUser.LoginID, addressBooksModelView.PageNo, addressBooksModelView.PageSize, searchText);
                }
                //else if (CurrentUser.OrganizationID > 0)
                else if (Convert.ToInt32(organizationID) > 0)
                {
                    //addressBooksModelView.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    listAddressBooks = LazySingletonBLL<AddressBookBLL>.Instance.GetAllAddressBooksByIDs(Convert.ToInt32(organizationID), null, CurrentUser.LoginID, addressBooksModelView.PageNo, addressBooksModelView.PageSize, searchText);
                }
                else
                    listAddressBooks = LazySingletonBLL<AddressBookBLL>.Instance.GetAllAddressBooksByIDs(null, null, CurrentUser.LoginID, addressBooksModelView.PageNo, addressBooksModelView.PageSize, searchText);

                if (listAddressBooks != null && listAddressBooks.Count > 0)
                {
                    addressBooksModelView.AddressBooks = new List<AddressBooksModel>();
                    addressBooksModelView.AddressBooks = listAddressBooks;
                    addressBooksModelView.TotalCount = listAddressBooks[0].RESULT_COUNT.Value;
                }

                addressBooksModelView.UserGroupID = CurrentUser.OrganizationID.Value;

                //addressBooksModelView.IsEnable = CurrentUser.UserTypeID.Value != UserTypeNames.Admin.GetHashCode() ? false : true;

                if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID > 0)
                    addressBooksModelView.IsEnable = false;
                else
                    addressBooksModelView.IsEnable = true;
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecordSearch", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(addressBooksModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordSearch", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    addressBooksModelView = new AddressBookModelView("error|" + ex.Message);
                }
            }

            return addressBooksModelView;
        }



        /// <summary>
        /// disable existing entry
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static AddressBooksModel RemoveRecord(string jsonModel)
        {
            AddressBooksModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<AddressBooksModel>(jsonModel);

                int savedResult = new AddressBookBLL().Delete(model);
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new AddressBooksModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new AddressBooksModel("error|" + ex.Message);
                }
            }
            return model;

        }

        /// <summary>
        /// Getting asssign contacts
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="addressBookID"></param>
        /// <param name="assigneeContacts"></param>
        /// <returns></returns>
        [WebMethod]
        public static AddressBookModelView AssignContacts(bool? IsCludeAddressBook, int? organizationID, int? addressBookID, List<ContactModel> assigneeContacts, int? departmentID)//AssignContacts(string IsCludeAddressBook,string organizationID, string addressBookID, string assigneeContacts, string departmentID)
        {
            AddressBookModelView model = new AddressBookModelView();
            int result = 0;
           
            try
            {
                
                model.Contacts = assigneeContacts;
                result = new AddressBookBLL().AssignContacts(assigneeContacts, organizationID, addressBookID, departmentID, IsCludeAddressBook);
                if (result > 0)
                {
                    string msg = " Total Phone Number(s): " + result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model,msg+ CutomMessage.ContactAssign);
                }
            }
            catch (Exception ex)
            {              

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "AssignContacts", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new AddressBookModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new AddressBookModelView("error|" + ex.Message);
                }
            }

            return model;

        }
        //Delete Selected Phone Numbers
        [WebMethod]
        public static AddressBookModelView DeleteSeledPhoneNos(int? organizationID, int? addressBookID, int? departmentID, List<ContactModel> assigneeContacts)
        {
            AddressBookModelView model = new AddressBookModelView();
            int result = 0;
           
            try
            {
                
                //model.Contacts = listContacts;
                result = new AddressBookBLL().DeleteAddressBookContact(assigneeContacts, organizationID, addressBookID,departmentID);
                if (result > 0)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.DeletedSuccessfully+" Deleted Total Record: "+Convert.ToString(result));
                }
            }
            catch (Exception ex)
            {                

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "AssignContacts", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new AddressBookModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new AddressBookModelView("error|" + ex.Message);
                }
            }

            return model;

        }
        [WebMethod]
        public static AddressBookModelView DeleteAllPhoneNos(int? organizationID, int? addressBookID, int? departmentID)
        {
            AddressBookModelView model = new AddressBookModelView();
            int result = 0;

            try
            {

                //model.Contacts = listContacts;
                result = new AddressBookBLL().DeleteAddressBookContact(null, organizationID, addressBookID, departmentID,true);
                if (result > 0)
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.DeletedSuccessfully + " Deleted Total Record: " + Convert.ToString(result));
                }
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "AssignContacts", 1, PageNames.AddressBook, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new AddressBookModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new AddressBookModelView("error|" + ex.Message);
                }
            }

            return model;

        }

        #endregion
    }
}