﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.SMSQueue;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.CMP
{
    public partial class BulkSMS : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMesssageInformation.Text = string.Empty;
            //this.lblMesssageInfo.Text = string.Empty;
            if (Page.Request.Files.Count > 0)
            {
                try
                {
                    #region "Fetting ID's from Http"
                    int organizationID = Convert.ToInt32(Page.Request.Form["organizationID"]);
                    int departmentID = Convert.ToInt32(Page.Request.Form["departmentID"]);
                    int campaignID = Convert.ToInt32(Page.Request.Form["CampaignID"]);
                    bool isEncodeOn = Convert.ToBoolean(Page.Request.Form["IsEncodeOn"]);
                    #endregion

                    #region "Getting Contacts from Files"
                    DataTable dtTemp = new Common().UploadBulkContactsFiles(Page.Request);
                    #endregion

                    #region "Validate List of contacts"
                    List<SMSConfigurationModel> smsConfiguration = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetConfiguration();
                    DataSet ds = Common.ValidateBulkSMSContacts(dtTemp, isEncodeOn, smsConfiguration);
                    DataTable dtContacts = ds.Tables[0].Copy();
                    DataTable dtWrongContacts = ds.Tables[1].Copy();
                    #endregion

                      #region "Saving Contacts into Contacts and Address Book Contact"
                    if (dtContacts.Rows.Count > 0)
                    {
                       
                        BulkSMSModel bulkSMS = new BulkSMSModel();
                        bulkSMS.OrganizationID = organizationID;
                        bulkSMS.DepartmentID = departmentID;
                        bulkSMS.CampaignID = campaignID;
                        bulkSMS.BulkSMS = dtContacts;
                        bulkSMS.IsEncodeOn = isEncodeOn;
                        int? noOfRowAffacted = LazySingletonBLL<SMSQueueBLL>.Instance.AddBulkSMS (CurrentUser.LoginID.Value, bulkSMS);
                        lblMesssageInformation.Text = "Total number of contact have been loaded" + dtContacts.Rows.Count;
                        if(dtWrongContacts!=null && dtWrongContacts.Rows.Count>0)
                        {
                            lblMesssageInformation.Text = lblMesssageInformation.Text + " Total Wrong Contact numbers" + dtWrongContacts.Rows.Count;
                        }
                    }
                    else
                    {

                        lblMesssageInformation.Text = "There is no contact numbers found to upload";
                    }
                    #endregion

                }
                catch (Exception ex)
                {
                    LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.Contact, CurrentUser.GetSessionUserInfo()));

                }

            }
        }

        #region "Web Methods"

        /// <summary>
        /// save record information
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static BulkContactModel SaveRecord(string jsonModel)
        {
            int? result = 0;

            BulkContactModel model = null;
            BulkSMSModel bulkSMSModel = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<BulkContactModel>(jsonModel);

                
                bulkSMSModel = new JavaScriptSerializer().Deserialize<BulkSMSModel>(jsonModel);

                if (model.ID.HasValue && model.ID.Value>0)
                {
                   // model.ModifiedBy = CurrentUser.LoginID;
                    bulkSMSModel.ModifiedBy = CurrentUser.LoginID;
                }
                else
                {
                    
                  //  model.CreatedBy = CurrentUser.LoginID;
                    bulkSMSModel.CreatedBy  = CurrentUser.LoginID;
                }
               
               
                LazySingletonBLL<Common>.Instance.ValidateBulkSMSContacts(bulkSMSModel);

                model.Phone = new CommonBLL().ConvertPhoneNO92(model.Phone);
                result = LazySingletonBLL<SMSQueueBLL>.Instance.SaveSMS(bulkSMSModel);

                if (result.HasValue && result.Value  > 0)
                {
                    model.ID = result;
                }

                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.BulkSMS, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new BulkContactModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new BulkContactModel("error|" + ex.Message);
                }
            }

            return model;
        }
        [WebMethod]
        public static BulkSMSModel SendSMS(string jsonModel)
        {
           
            BulkSMSModel bulkSMSModel = null;

            try
            {


                bulkSMSModel = new JavaScriptSerializer().Deserialize<BulkSMSModel>(jsonModel);
                LazySingletonBLL<SMSQueueBLL>.Instance.AddBulkSMSToBuffer(bulkSMSModel);
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(bulkSMSModel, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(bulkSMSModel, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.BulkSMS, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    bulkSMSModel = new BulkSMSModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    bulkSMSModel = new BulkSMSModel("error|" + ex.Message);
                }
            }

            return bulkSMSModel;

        }
        [WebMethod]
        public static ContactModelView GetDepartments(string organizationID)
        {
            ContactModelView contactModelView = new ContactModelView();
            List<DepartmentsModel> listDepartment = new List<DepartmentsModel>();
            listDepartment = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(organizationID),CurrentUser.LoginID,CurrentUser.DepartmentID);

            if (listDepartment != null && listDepartment.Count > 0)
            {
                contactModelView.Departments = new List<DepartmentsModel>();
                contactModelView.Departments = listDepartment;
            }
            return contactModelView;
        }

        //[WebMethod]
        //public static ContactModelView GetDepartmentsWithCampaign(string organizationID,string departmentID)
        //{
        //    ContactModelView contactModelView = new ContactModelView();
        //    List<DepartmentsModel> listDepartment = new List<DepartmentsModel>();
        //    listDepartment = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(organizationID), CurrentUser.LoginID, CurrentUser.DepartmentID);

        //    if (listDepartment != null && listDepartment.Count > 0)
        //    {
        //        contactModelView.Departments = new List<DepartmentsModel>();
        //        contactModelView.Departments = listDepartment;

        //        contactModelView.Campaigns  = new SMSCampaignBLL().GetCampaings(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), null);
        //    }
        //    return contactModelView;
        //}


        [WebMethod]
        public static ContactModelView GetCampaigns(string organizationID ,string departmentID)
        {
            ContactModelView contactModelView = new ContactModelView();
           
            try 
            {
                 List<SMSCampaignModel> campaigns = new SMSCampaignBLL().GetCampaings(Convert.ToInt32(organizationID),Convert.ToInt32(departmentID),null);

            if (campaigns != null && campaigns.Count > 0)
            {
                //contactModelView.Departments = new List<DepartmentsModel>();
                contactModelView.Campaigns  = campaigns;
            }
            
            }
            catch(Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetCampaigns", 1, PageNames.BulkSMS, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(contactModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetCampaigns", 1, PageNames.BulkSMS, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    contactModelView = new ContactModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    contactModelView = new ContactModelView("error|" + ex.Message);
                }
            }
           return contactModelView;
        }

        /// <summary>
        /// Get Records By Search 
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        [WebMethod]
        public static BulkContactModelView GetRecordSearch(string jsonModel, string searchText)
        {
            BulkContactModelView contactModelView = null;
            List<BulkContactModel> listContacts = new List<BulkContactModel>();
            List<OrganizationModel> listOrganization = new List<OrganizationModel>();
            List<DepartmentsModel> listDepartment = new List<DepartmentsModel>();


            searchText = searchText.Length > 0 ? searchText : string.Empty;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion


                if (jsonModel != "null")
                {
                    contactModelView = new JavaScriptSerializer().Deserialize<BulkContactModelView>(jsonModel);
                }
                else
                {
                    contactModelView = new BulkContactModelView();
                    contactModelView.PageNo = 1;
                }
                contactModelView.PageSize = PageSize;

                #region "Filling User Model "
                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                #endregion

                contactModelView.User = User;

                #region "Filling ContactModelView Model "

                listContacts = LazySingletonBLL<SMSQueueBLL>.Instance.GetAllBulkContactWithPagingByText(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID), CurrentUser.OrganizationID, CurrentUser.DepartmentID, searchText);
                listOrganization = new OrganizationBLL().GetOrganization(CurrentUser.LoginID, CurrentUser.OrganizationID);

                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    listDepartment = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(User.OrganizationID));
                }
                
                contactModelView.Contacts = new List<BulkContactModel>();
                if (listContacts != null && listContacts.Count > 0)
                {
                    contactModelView.Contacts = listContacts;
                    contactModelView.TotalCount = listContacts[0].RESULT_COUNT.Value;
                }

                contactModelView.Organizations = new List<OrganizationModel>();
                if (listOrganization != null && listOrganization.Count > 0)
                {
                    contactModelView.Organizations = listOrganization;
                }

                if (listDepartment != null && listDepartment.Count > 0)
                {
                    contactModelView.Departments = listDepartment;
                }

                contactModelView.UserGroupID = CurrentUser.OrganizationID.Value;
                contactModelView.IsEnable = CurrentUser.UserTypeID.Value != UserTypeNames.Admin.GetHashCode() ? false : true;
                #endregion

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecordSearch", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(contactModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordSearch", 1, PageNames.BulkSMS, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    contactModelView = new BulkContactModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    contactModelView = new BulkContactModelView("error|" + ex.Message);
                }
            }

            return contactModelView;

        }

        /// <summary>
        /// Get All Contacts Information
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static BulkContactModelView GetRecord(string jsonModel)
        {
            BulkContactModelView contactModelView = null;
            List<BulkContactModel> listContacts = new List<BulkContactModel>();
            List<OrganizationModel> listOrganization = new List<OrganizationModel>();

            List<DepartmentsModel> listDepartment = new List<DepartmentsModel>();

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion


                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    contactModelView = new JavaScriptSerializer().Deserialize<BulkContactModelView>(jsonModel);
                }
                else
                {
                    contactModelView = new BulkContactModelView();
                    contactModelView.PageNo = 1;
                }
                contactModelView.PageSize = PageSize;

                #region "Filling User Model "
                UserModel User = new UserModel();
                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                #endregion

                contactModelView.User = User;

                #region "Filling ContactModelView Model "

                listContacts = LazySingletonBLL<SMSQueueBLL>.Instance.GetAllBulkContactsWithPaging(contactModelView.PageNo, contactModelView.PageSize, Convert.ToInt32(CurrentUser.LoginID));
                listOrganization = new OrganizationBLL().GetOrganization(CurrentUser.LoginID, CurrentUser.OrganizationID);

                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    listDepartment = new DepartmentsBLL().SelectActiveDepartmentsByOrgID(Convert.ToInt32(User.OrganizationID));
                }
             
                contactModelView.Contacts = new List<BulkContactModel>();
                if (listContacts != null && listContacts.Count > 0)
                {
                    contactModelView.Contacts = listContacts;
                    contactModelView.TotalCount = listContacts[0].RESULT_COUNT.Value;
                }

                contactModelView.Organizations = new List<OrganizationModel>();
                if (listOrganization != null && listOrganization.Count > 0)
                {
                    contactModelView.Organizations = listOrganization;
                }

                if (listDepartment != null && listDepartment.Count > 0)
                {
                    contactModelView.Departments = listDepartment;
                }

                contactModelView.UserGroupID = CurrentUser.OrganizationID.Value;
                contactModelView.IsEnable = CurrentUser.UserTypeID.Value != UserTypeNames.Admin.GetHashCode() ? false : true;
                contactModelView.IsEncodeOn = false;
                #endregion

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(contactModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.BulkSMS, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    contactModelView = new BulkContactModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    contactModelView = new BulkContactModelView("error|" + ex.Message);
                }
            }

            return contactModelView;

        }

        [WebMethod]
        public static ContactModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            ContactModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<BulkContactModel>(jsonModel);
                if (model != null && model.ID.HasValue && model.ID.Value >0)
                result = LazySingletonBLL<SMSQueueBLL>.Instance.DeleteSMS(model.ID.Value);
                //return (result.HasValue && result.Value > -1 ? "true" : "false");
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.DeletedSuccessfully);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Contact, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.BulkSMS, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ContactModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ContactModel("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion
    }
}