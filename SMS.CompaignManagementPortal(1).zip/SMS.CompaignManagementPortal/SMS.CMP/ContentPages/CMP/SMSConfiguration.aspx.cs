﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.CMP.ContentPages.CMP
{
    public partial class SMSConfiguration : System.Web.UI.Page
    {
        /// <summary>
        /// Page Load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        /// <summary>
        /// Save Record
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static SMSConfigurationModel SaveRecord(string jsonModel)
        {
            int result = 0;
            SMSConfigurationModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<SMSConfigurationModel>(jsonModel);
                result = new SMSConfigurationBLL().Save(model);
                if (result > 0)
                {
                    model.ConfigurationID = result;
                   
                }
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SMSConfiguration, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SMSConfiguration, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSConfigurationModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSConfigurationModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get Records Web Method
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static SMSConfigurationModelView GetRecords()
        {
            SMSConfigurationModelView model = new SMSConfigurationModelView();

            List<SMSConfigurationModel> listSMSConfiguration = new SMSConfigurationBLL().GetConfiguration();
            List<NetworksCodeModel> listNetworksCodeModel = new NetworksCodeBLL().GetAllNetWorkCodes();

            try
            {
                if (listSMSConfiguration != null && listSMSConfiguration.Count > 0)
                {
                    model.SMSConfiguration = listSMSConfiguration;
                }

                if (listNetworksCodeModel != null && listNetworksCodeModel.Count > 0)
                {
                    model.NetworksCode = listNetworksCodeModel;
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.SMSConfiguration, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.SMSConfiguration, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSConfigurationModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSConfigurationModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion
    }
}