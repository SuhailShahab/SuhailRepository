﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BE.RightsManager;
using BLL.Common;
using BLL.Lookups;
using BLL.RightsManager;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Lookups;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web.Script.Serialization;
using System.Web.Services;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date:  <19-10-2015 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR:001       Syed Zeeshan Aqil           04-Dec- 2015 05:21 PM       Add Method  GetAllCampaignesSchedule to get the Campaign Schedule list
// CR:002       Muhammad Hamamd Shahid      27-01-2016 05:20:26PM       Impemente No. of SMS with message, add language mode with response message
// CR:003       Sajjad Aslam                20-03-2017 12:10:26PM       Code optimization
// =================================================================================================================================
namespace SMS.CMP.ContentPages.CMP
{
    public partial class SMSCampaign : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //DataTable dt =null;
            //if (Page.Request.Files.Count > 0 &&  Request.Form["CampaignID"] != null)
            //    dt = new Common().UploadContactsFiles(Page.Request);
        }

        #region "Web Methods"

        /// <summary>
        /// Save Campaign
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignModel SaveRecord(string jsonModel)
        {
            SMSCampaignModel model = null;

            try
            {
                int result = 0;
                model = new JavaScriptSerializer().Deserialize<SMSCampaignModel>(jsonModel);

                model.UserID = CurrentUser.LoginID;
                model.CreatedBy = CurrentUser.LoginID;

                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                    model.OrganizationID = CurrentUser.OrganizationID;

                //else if (CurrentUser.OrganizationID > 0  && CurrentUser.DepartmentID == 0)
                //    smsCampaign.CreatedBy =smsCampaign.UserID;
                //else
                //    smsCampaign.CreatedBy = smsCampaign.UserID;

                // calculate total no of sms from message - CR:002
                if (model.TemplateID.HasValue == false)
                {
                    if (model.MessageType == 2)
                        model.NoOfSMS = model.NoOfSMSEng;
                    else
                        model.NoOfSMS = model.NoOfSMSUrd;
                }

                //CR:002
                if (model.ResponseLanguageMode.HasValue)
                {
                    if (Convert.ToBoolean(model.ResponseLanguageMode) == false)         // for english
                        model.ResponseNoOfSMS = model.ResponseNoOfSMSEng;
                    else
                        model.ResponseNoOfSMS = model.ResponseNoOfSMSUrd;
                }


                result = new SMSCampaignBLL().Save(model);

                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSCampaignModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSCampaignModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Send SMS of a Campaign
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignModel SendCampaign(string jsonModel)
        {
            SMSCampaignModel smsCampaign = null;
            bool checkval = false;

            try
            {
                smsCampaign = new JavaScriptSerializer().Deserialize<SMSCampaignModel>(jsonModel);
                checkval = new Common().SendRequest(smsCampaign.OrganizationID.Value, smsCampaign.CampaignID.Value);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SendCampaign", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(smsCampaign, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SendCampaign", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    smsCampaign = new SMSCampaignModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    smsCampaign = new SMSCampaignModel("error|" + ex.Message);
                }
            }

            return smsCampaign;
        }

        #region "Old Code"
        /*
        [WebMethod]
        public static SMSCampaignViewModel GetRecord(string jsonModel)
        {
            SMSCampaignViewModel model = null;// new SMSCampaignViewModel();
            List<SMSCampaignModel> smsCampaigns = null;
            Decimal perSMSRate = 0;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                UserModel User = new UserModel();

                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                User.UserTypeID = CurrentUser.UserTypeID;


                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    model = new JavaScriptSerializer().Deserialize<SMSCampaignViewModel>(jsonModel);
                }
                else
                {
                    model = new SMSCampaignViewModel();
                    model.PageNo = 1;
                }

                model.PageSize = PageSize;
                model.User = User;

                List<OrganizationModel> organizations = new OrganizationBLL().SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                //List<ShortCodeModel> lstShortCode = new ShortCodeBLL().GetShortCodesByOrganizationID(CurrentUser.OrganizationID.Value);
                List<ShortCodeModel> lstShortCode = null;

                List<ProcessingStatusModel> processingStatuses = new SMSCampaignBLL().GetProcessingStatuses();

                if (organizations != null && organizations.Count > 0)
                    model.Organizations = organizations;

                if (processingStatuses != null && processingStatuses.Count > 0)
                    model.ProcessingStatuses = processingStatuses;

                model.AllowUpdate = CurrentUser.AllowUpdate.Value;

                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    lstShortCode = new ShortCodeBLL().GetUserShortCodesByIDs(CurrentUser.LoginID, CurrentUser.OrganizationID);
                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    model.Users = new UserBLL().GetUsersByOrgIDByDeptID(Convert.ToInt32(CurrentUser.OrganizationID), Convert.ToInt32(CurrentUser.DepartmentID));
                    smsCampaigns = new SMSCampaignBLL().GetAllCampaingsInfo(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);
                    model.SMSTemplates = new SMSTemplateBLL().GetAllActiveSMSTemplates(CurrentUser.OrganizationID, CurrentUser.DepartmentID);

                    if (model.Departments != null && (model.Departments.Any(d => d.DepartmentID == CurrentUser.DepartmentID)))
                    {
                        DepartmentsModel departmentsModel = model.Departments.FindLast(d => d.DepartmentID == CurrentUser.DepartmentID);
                        perSMSRate = departmentsModel.PerSMSRate.HasValue ? departmentsModel.PerSMSRate.Value : 0;
                    }
                }
                else if (CurrentUser.OrganizationID > 0)
                {
                    lstShortCode = new ShortCodeBLL().GetUserShortCodesByIDs(CurrentUser.LoginID, CurrentUser.OrganizationID);
                    smsCampaigns = new SMSCampaignBLL().GetAllCampaingsInfo(CurrentUser.OrganizationID, null, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);
                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    model.SMSTemplates = new SMSTemplateBLL().GetAllActiveSMSTemplates(CurrentUser.OrganizationID, null);

                    if (model.Departments != null && (model.Departments.Any(d => d.DepartmentID == CurrentUser.DepartmentID)))
                    {
                        DepartmentsModel departmentsModel = model.Departments.FindLast(d => d.DepartmentID == CurrentUser.DepartmentID);
                        perSMSRate = departmentsModel.PerSMSRate.HasValue ? departmentsModel.PerSMSRate.Value : 0;
                    }
                }
                else
                {
                    smsCampaigns = new SMSCampaignBLL().GetAllCampaingsInfo(null, null, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);
                    //  model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.spGetUserDeptByIDs(CurrentUser.LoginID.Value, null, null);
                    model.SMSTemplates = new SMSTemplateBLL().GetAllActiveSMSTemplates(null, null);
                }


                if (smsCampaigns != null && smsCampaigns.Count > 0)
                {
                    model.SMSCampaign = new SMSCampaignModel();

                    model.SMSCampaign.PerSMSRate = perSMSRate;

                    model.SMSCampaignsLog = smsCampaigns;
                    model.TotalCount = smsCampaigns[0].RESULT_COUNT.Value;
                }

                if (lstShortCode != null && lstShortCode.Count > 0)
                {
                    model.ShortCodes = lstShortCode;
                }
            }
            catch (Exception ex)
            {
                LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

            }

            return model;
        }
         * */
        #endregion

        /// <summary>
        /// Get Campaign Information
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignViewModel GetRecord(string jsonModel, bool isLoad)
        {
            SMSCampaignViewModel model = null;// new SMSCampaignViewModel();
            List<SMSCampaignModel> smsCampaigns = null;
            Decimal perSMSRate = 0;
            int? smsLimit = null;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                UserModel User = new UserModel();

                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                User.UserTypeID = CurrentUser.UserTypeID;
                User.IsEnforceSMSBucked = CurrentUser.GetSessionUserInfo().IsEnforceSMSBucked;
                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    model = new JavaScriptSerializer().Deserialize<SMSCampaignViewModel>(jsonModel);
                }
                else
                {
                    model = new SMSCampaignViewModel();
                    model.PageNo = 1;
                }

                model.PageSize = PageSize;
                model.User = User;
                if (!isLoad)
                {
                    List<OrganizationModel> organizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                    if (organizations != null && organizations.Count > 0)
                        model.Organizations = organizations;
                }
                //else
                //{
                //    //if (model.Organizations.Count == 0)
                //    //{
                //        List<OrganizationModel> organizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                //        if (organizations != null && organizations.Count > 0)
                //            model.Organizations = organizations;
                //    //}

                //}
                //List<ShortCodeModel> lstShortCode = new ShortCodeBLL().GetShortCodesByOrganizationID(CurrentUser.OrganizationID.Value);
                List<ShortCodeModel> lstShortCode = null;

                List<ProcessingStatusModel> processingStatuses = LazySingletonBLL<SMSCampaignBLL>.Instance.GetProcessingStatuses();



                if (processingStatuses != null && processingStatuses.Count > 0)
                    model.ProcessingStatuses = processingStatuses;

                model.AllowUpdate = CurrentUser.AllowUpdate.Value;

                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    lstShortCode = LazySingletonBLL<ShortCodeBLL>.Instance.GetUserShortCodesByIDs(CurrentUser.LoginID, CurrentUser.OrganizationID);
                    model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    model.Users = LazySingletonBLL<UserBLL>.Instance.GetUsersByOrgIDByDeptID(Convert.ToInt32(CurrentUser.OrganizationID), Convert.ToInt32(CurrentUser.DepartmentID));
                    smsCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaingsInfo(CurrentUser.OrganizationID, CurrentUser.DepartmentID, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);
                    model.SMSTemplates = LazySingletonBLL<SMSTemplateBLL>.Instance.GetAllActiveSMSTemplates(CurrentUser.OrganizationID, CurrentUser.DepartmentID);

                    if (model.Departments != null && (model.Departments.Any(d => d.DepartmentID == CurrentUser.DepartmentID)))
                    {
                        DepartmentsModel departmentsModel = model.Departments.FindLast(d => d.DepartmentID == CurrentUser.DepartmentID);
                        perSMSRate = departmentsModel.PerSMSRate.HasValue ? departmentsModel.PerSMSRate.Value : 0;
                        smsLimit = departmentsModel.SMSLimit;
                    }
                }
                else if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID == 0 && isLoad == true)
                {
                    lstShortCode = LazySingletonBLL<ShortCodeBLL>.Instance.GetUserShortCodesByIDs(CurrentUser.LoginID, CurrentUser.OrganizationID);
                    smsCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaingsInfo(CurrentUser.OrganizationID, null, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);
                    model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    model.SMSTemplates = LazySingletonBLL<SMSTemplateBLL>.Instance.GetAllActiveSMSTemplates(CurrentUser.OrganizationID, null);

                    if (model.Departments != null && (model.Departments.Any(d => d.DepartmentID == CurrentUser.DepartmentID)))
                    {
                        DepartmentsModel departmentsModel = model.Departments.FindLast(d => d.DepartmentID == CurrentUser.DepartmentID);
                        perSMSRate = departmentsModel.PerSMSRate.HasValue ? departmentsModel.PerSMSRate.Value : 0;
                        smsLimit = departmentsModel.SMSLimit;
                    }
                }
                else if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID == 0 && isLoad == false)
                {
                    model.Departments = new DepartmentsBLL().GetDepartmentByOrgIDByUserID(Convert.ToInt32(CurrentUser.OrganizationID), CurrentUser.LoginID.Value);
                    model.SMSTemplates = LazySingletonBLL<SMSTemplateBLL>.Instance.GetAllActiveSMSTemplates(CurrentUser.OrganizationID, null);
                    //listSMSTemplate = new SMSTemplateBLL().GetAllSMSTemplates(CurrentUser.OrganizationID, null, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);
                }
                else if (isLoad == true)
                {
                    smsCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaingsInfo(null, null, CurrentUser.LoginID.Value, model.PageNo, model.PageSize);
                    //  model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.spGetUserDeptByIDs(CurrentUser.LoginID.Value, null, null);
                    model.SMSTemplates = LazySingletonBLL<SMSTemplateBLL>.Instance.GetAllActiveSMSTemplates(null, null);
                }


                if (smsCampaigns != null && smsCampaigns.Count > 0)
                {
                    model.SMSCampaign = new SMSCampaignModel();

                    model.SMSCampaign.PerSMSRate = perSMSRate;
                    model.SMSCampaign.TotalAllocatedSMS = smsLimit;
                    model.SMSCampaignsLog = smsCampaigns;
                    model.TotalCount = smsCampaigns[0].RESULT_COUNT.Value;
                }

                if (lstShortCode != null && lstShortCode.Count > 0)
                {
                    model.ShortCodes = lstShortCode;
                }

                //ShowSMSPriority textbox for super.user only
                model.ShowPriorityID = null;
                if (CurrentUser.LoginName.ToLower() == "super.user")
                    model.ShowPriorityID = true;
                else
                    model.ShowPriorityID = false;
                //
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSCampaignViewModel("error|" + ex.Message);
                }

            }

            return model;
        }

        [WebMethod]
        public static SMSCampaignViewModel GetRecordSearch(string organizationID, string departmentID, string jsonModel, string searchText)
        {
            SMSCampaignViewModel model = null;// new SMSCampaignViewModel();
            List<SMSCampaignModel> smsCampaigns = null;

            searchText = searchText.Length > 0 ? searchText : string.Empty;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                UserModel User = new UserModel();

                User.UserID = CurrentUser.LoginID;
                User.OrganizationID = CurrentUser.OrganizationID;
                User.DepartmentID = CurrentUser.DepartmentID;
                User.UserTypeID = CurrentUser.UserTypeID;
                User.IsEnforceSMSBucked = CurrentUser.GetSessionUserInfo().IsEnforceSMSBucked;

                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    model = new JavaScriptSerializer().Deserialize<SMSCampaignViewModel>(jsonModel);
                }
                else
                {
                    model = new SMSCampaignViewModel();
                    model.PageNo = 1;
                }

                model.PageSize = PageSize;
                model.User = User;

                //List<OrganizationModel> organizations = LazySingletonBLL<OrganizationBLL>.Instance.SelectOrganizationByUserID(Convert.ToInt32(CurrentUser.LoginID));
                //if (organizations != null && organizations.Count > 0)
                //    model.Organizations = organizations;

                List<ShortCodeModel> lstShortCode = LazySingletonBLL<ShortCodeBLL>.Instance.GetUserShortCodesByIDs(CurrentUser.LoginID, CurrentUser.OrganizationID);



                model.AllowUpdate = CurrentUser.AllowUpdate.Value;

                if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID > 0)
                {
                    // model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(CurrentUser.OrganizationID.Value, CurrentUser.LoginID.Value);
                    model.Users = LazySingletonBLL<UserBLL>.Instance.GetUsersByOrgIDByDeptID(CurrentUser.OrganizationID.Value, CurrentUser.DepartmentID.Value);
                    smsCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaingsInfo(CurrentUser.OrganizationID.Value, CurrentUser.DepartmentID, CurrentUser.LoginID.Value, model.PageNo, model.PageSize, searchText);
                    model.SMSTemplates = LazySingletonBLL<SMSTemplateBLL>.Instance.GetAllActiveSMSTemplates(CurrentUser.OrganizationID, CurrentUser.DepartmentID);
                }
                else if (CurrentUser.OrganizationID > 0 && CurrentUser.DepartmentID == 0)
                {
                    smsCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaingsInfo(CurrentUser.OrganizationID, Convert.ToInt32(departmentID), CurrentUser.LoginID.Value, model.PageNo, model.PageSize, searchText);
                    //  model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(CurrentUser.OrganizationID.Value, CurrentUser.LoginID.Value);
                    model.SMSTemplates = LazySingletonBLL<SMSTemplateBLL>.Instance.GetAllActiveSMSTemplates(CurrentUser.OrganizationID, Convert.ToInt32(departmentID));
                }
                else
                    smsCampaigns = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaingsInfo(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), CurrentUser.LoginID.Value, model.PageNo, model.PageSize, searchText);

                if (smsCampaigns != null && smsCampaigns.Count > 0)
                {
                    model.SMSCampaign = new SMSCampaignModel();
                    model.SMSCampaignsLog = smsCampaigns;
                    model.TotalCount = smsCampaigns[0].RESULT_COUNT.Value;
                }

                if (lstShortCode != null && lstShortCode.Count > 0)
                {
                    model.ShortCodes = lstShortCode;
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordSearch", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSCampaignViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// get Department  and ShortCode By Organization ID
        /// </summary>
        /// <param name="organizationID"> Selected Organizaiton ID</param>
        /// <returns>Department List and Shortcode List</returns>
        [WebMethod]
        public static SMSCampaignViewModel GetDepartments(string organizationID)
        {
            SMSCampaignViewModel model = new SMSCampaignViewModel();

            try
            {

                //model.ShortCodes = LazySingletonBLL<ShortCodeBLL>.Instance.GetUserShortCodesByIDs(CurrentUser.LoginID, Convert.ToInt32(organizationID));
                if (CurrentUser.OrganizationID.HasValue && CurrentUser.OrganizationID.Value > 0)
                {
                    model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.GetDepartmentByOrgIDByUserID(Convert.ToInt32(organizationID), CurrentUser.LoginID.Value);
                }
                else
                {
                    model.Departments = LazySingletonBLL<DepartmentsBLL>.Instance.spGetUserDeptByIDs(CurrentUser.LoginID.Value, Convert.ToInt32(organizationID), null);
                }

            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDepartments", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartments", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSCampaignViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get Users by Organization and Department base
        /// </summary>
        /// <param name="organizationID">selected Organization Id</param>
        /// <param name="departmentID">Selected Department ID</param>
        /// <returns>User List</returns>
        [WebMethod]
        public static SMSCampaignViewModel GetUsers(string organizationID, string departmentID, string shortcodeID)
        {
            SMSCampaignViewModel model = new SMSCampaignViewModel();

            try
            {
                model.ShortCodes = LazySingletonBLL<ShortCodeBLL>.Instance.GetUserShortCodesByIDs(CurrentUser.LoginID, Convert.ToInt32(organizationID));
                model.SMSTemplates = LazySingletonBLL<SMSTemplateBLL>.Instance.GetAllActiveSMSTemplates(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID));
                model.Users = LazySingletonBLL<UserBLL>.Instance.GetUsersByOrgIDByDeptID(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID));
                if (shortcodeID != "undefined")
                {
                    model.Masks = LazySingletonBLL<MaskBLL>.Instance.GetMasksByShortCodeID(Convert.ToInt32(shortcodeID), Convert.ToInt32(departmentID));
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetUsers", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);


                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetUsers", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSCampaignViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get Contact List
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignViewModel GetContacts(string organizationID, string departmentID, string pageNo, string pageSize, string campaignID)
        {
            SMSCampaignViewModel model = new SMSCampaignViewModel();

            try
            {
                int? campID = null;
                if (!campaignID.Equals("undefined"))
                {
                    campID = Convert.ToInt32(campaignID);
                }
                model.Contacts = LazySingletonBLL<ContactBLL>.Instance.GetAllActiveContacts(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), Convert.ToInt32(pageNo), Convert.ToInt32(pageSize), campID);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetContacts", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetContacts", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSCampaignViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get Address List
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignViewModel GetAddress(string organizationID, string departmentID, string campaignID)
        {
            SMSCampaignViewModel model = new SMSCampaignViewModel();
            int? campID = null;
            try
            {

                if (campaignID != "undefined")
                {
                    campID = Convert.ToInt32(campaignID);
                }


                model.AddressBooks = LazySingletonBLL<AddressBookBLL>.Instance.GetAddressBooksWithContactsByOrgID(Convert.ToInt32(organizationID), Convert.ToInt32(departmentID), campID);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAddress", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAddress", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSCampaignViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get SMS Campaign Addresses and Contacts
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignModel GetSMSCampaignAddressContact(string jsonModel)
        {
            SMSCampaignModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<SMSCampaignModel>(jsonModel);
                model = LazySingletonBLL<SMSCampaignBLL>.Instance.GetSMSCampaignAddressContact(model);
                // new SMSCampaignBLL().GetSMSCampaignAddressContact(model);
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetSMSCampaignAddressContact", 0, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetSMSCampaignAddressContact", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SMSCampaignModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SMSCampaignModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static SMSCampaignViewModel GetContactsSearch(string organizationID, string departmentID, string pageNo, string pageSize, string searchText, string campaignID)
        {
            SMSCampaignViewModel smsCampaignViewModel = new SMSCampaignViewModel();
            List<ContactModel> contacts = null;

            try
            {
                int? campID = null;
                if (!campaignID.Equals("undefined"))
                {
                    campID = Convert.ToInt32(campaignID);
                }
                bool isViewOnly = Convert.ToBoolean(false);

                int OrganizationID = Convert.ToInt32(organizationID);
                int DepartmentID = Convert.ToInt32(departmentID);

                int PageNo = Convert.ToInt32(pageNo);
                int PageSize = Convert.ToInt32(pageSize);

                contacts = LazySingletonBLL<ContactBLL>.Instance.SearchContacts(OrganizationID, DepartmentID, PageNo, PageSize, searchText, campID);
                //if (!string.IsNullOrEmpty(searchText))
                //    contacts = new ContactBLL().SearchContacts(OrganizationID, DepartmentID, PageNo, PageSize, searchText);
                //else
                //    contacts = new ContactBLL().SearchContacts(OrganizationID, DepartmentID, PageNo, PageSize, searchText);

                if (contacts.Count > 0)
                {
                    smsCampaignViewModel.Contacts = contacts;
                    //addressBooksModelView.TotalCount = contacts[0].RESULT_COUNT.Value;
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetContactsSearch", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(smsCampaignViewModel, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetContactsSearch", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    smsCampaignViewModel = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    smsCampaignViewModel = new SMSCampaignViewModel("error|" + ex.Message);
                }
            }

            return smsCampaignViewModel;
        }

        [WebMethod]
        public static SMSCampaignViewModel GetMasksByShortCodeID(string shortCodeID, string departmentID)
        {
            SMSCampaignViewModel smsCampaignModelVeiw = new SMSCampaignViewModel();
            List<MaskModel> listMaskModel = new List<MaskModel>();

            try
            {
                listMaskModel = LazySingletonBLL<MaskBLL>.Instance.GetMasksByShortCodeID(Convert.ToInt32(shortCodeID), Convert.ToInt32(departmentID));

                if (listMaskModel != null && listMaskModel.Count > 0)
                {
                    smsCampaignModelVeiw.Masks = listMaskModel;
                }
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetMasksByShortCodeID", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(smsCampaignModelVeiw, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetMasksByShortCodeID", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    smsCampaignModelVeiw = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    smsCampaignModelVeiw = new SMSCampaignViewModel("error|" + ex.Message);
                }
            }

            return smsCampaignModelVeiw;
        }

        /// <summary>
        /// disable existing entry
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static SMSCampaignModel RemoveRecord(string jsonModel)
        {
            SMSCampaignModel smsCampaignModel = null;

            try
            {
                smsCampaignModel = new JavaScriptSerializer().Deserialize<SMSCampaignModel>(jsonModel);
                SMSCampaignModel model = new SMSCampaignModel();
                model.CampaignID = smsCampaignModel.CampaignID;
                smsCampaignModel.Status = false;
                int savedResult = new SMSCampaignBLL().Delete(model);

                if (savedResult == 2)
                    smsCampaignModel.Notification = "Error | Record cannot be block, Because it is in UnderProcessing";
                else if (savedResult == 3)
                    smsCampaignModel.Notification = "Error | Record cannot be blocked, Because it has been Processed";
                else
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(smsCampaignModel, CutomMessage.BlockSuccessfully);

                //  smsCampaignModel.Status = Convert.ToBoolean(savedResult);
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    smsCampaignModel = new SMSCampaignModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    smsCampaignModel = new SMSCampaignModel("error|" + ex.Message);
                }
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(smsCampaignModel, ex.Message);
            }

            return smsCampaignModel;
        }

        /// <summary>
        /// Get Campaignes Schedule Time Slots
        /// </summary>
        /// <remarks>CR:001</remarks>
        /// <param name="scheduleDate">Selected Date </param>
        /// <returns>Selected Campaignes Time Slot in List</returns>
        [WebMethod]
        public static SMSCampaignViewModel GetAllSchedules(string scheduleDate)
        {
            SMSCampaignViewModel smsCampaignModelVeiw = new SMSCampaignViewModel();
            List<ScheduleModel> model = new List<ScheduleModel>();

            try
            {
                model = LazySingletonBLL<SMSCampaignBLL>.Instance.GetAllCampaignesSchedule(scheduleDate);

                if (model.Count > 0)
                    smsCampaignModelVeiw.MappedCampaignSchedules = model;
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllSchedules", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    smsCampaignModelVeiw = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    smsCampaignModelVeiw = new SMSCampaignViewModel("error|" + ex.Message);
                }
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllSchedules", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(smsCampaignModelVeiw, ex.Message);
            }

            return smsCampaignModelVeiw;
        }

        [WebMethod]
        public static int? SetCampaignProceed(string campaignID)
        {
            SMSCampaignViewModel smsCampaignModelVeiw = new SMSCampaignViewModel();
            int? result = null;
            try
            {
                result = LazySingletonBLL<SMSCampaignBLL>.Instance.SetCampaignStatus(Convert.ToInt32(campaignID));
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SetCampaignProceed", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    smsCampaignModelVeiw = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    smsCampaignModelVeiw = new SMSCampaignViewModel("error|" + ex.Message);
                }
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SetCampaignProceed", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(smsCampaignModelVeiw, ex.Message);
            }

            return result;
        }

        [WebMethod]
        public static int ReInitiateCampaign(string campaignID, string organizationID, string versionNo)
        {
            SMSCampaignViewModel smsCampaignModelVeiw = new SMSCampaignViewModel();
            int? Ret = null;
            try
            {
                Ret = LazySingletonBLL<SMSCampaignBLL>.Instance.ReinitiateCampaign(Convert.ToInt32(campaignID), Convert.ToInt32(organizationID), Convert.ToInt32(versionNo));
            }
            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "StopCampaignProceed", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationMsg(null, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ReInitiateCampaign", 1, PageNames.SMSCampaign, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    smsCampaignModelVeiw = new SMSCampaignViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    smsCampaignModelVeiw = new SMSCampaignViewModel("error|" + ex.Message);
                }
            }

            return Ret.Value;
        }

        #endregion

        #region "Custom Methods"


        #endregion
    }
}