﻿using ApplicationClasses;
using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using BLL.CustomExceptions;
using BLL.Lookups;
using SMS.CMP.BE.CMP;
using SMS.CMP.BLL.CMP;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace SMS.CMP.ContentPages.CMP
{

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date:  <09-11-2015 05:54 PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
    public partial class TelcoPayment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"


        /// <summary>
        /// Add and Edit Telco Payment Information
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static TelcoModel SaveRecord(string jsonModel)
        {
            int? result = null;
            TelcoModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<TelcoModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;
                result = new TelcoBLL().Save(model);
                if (result > 0)
                {
                    model.ID = result;
                    LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, CutomMessage.DuplicateIsOffnet);
                }
            }
            catch (BusinessException ex)
            {
                model = new TelcoModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {   
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.TelcoPayment, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.TelcoPayment, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new TelcoModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new TelcoModel("error|" + ex.Message);
                }
            }
            return model;
        }

        /// <summary>
        /// Get  All Telco Information
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static TelcoModelView GetRecords(string jsonModel)
        {
            TelcoModelView modelView = null;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    modelView = new JavaScriptSerializer().Deserialize<TelcoModelView>(jsonModel);
                }
                else
                {
                    modelView = new TelcoModelView();
                    modelView.PageNo = 1;
                }

                modelView.PageSize = PageSize;
              
                
                // Fill Model
                List<TelcoModel> telcoCompanies = new TelcoBLL().GetctiveTelcoCompanies();
                List<TelcoModel> telcoPayments = new TelcoBLL().GetAllTelcoPayments(modelView.PageNo, modelView.PageSize);

                if (telcoCompanies != null && telcoCompanies.Count > 0)
                {
                    modelView.TelcoCompanies = telcoCompanies;
                }

                if (telcoPayments != null && telcoPayments.Count > 0)
                {
                    modelView.TelcoPayments = telcoPayments;
                    modelView.TotalCount = telcoPayments[0].RESULT_COUNT.Value;
                }

                // return modelView;
            }

            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.TelcoPayment, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(modelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.TelcoPayment, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new TelcoModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new TelcoModelView("error|" + ex.Message);
                }
            }

            return modelView;
        }

        [WebMethod]
        public static TelcoModelView GetRecordSearch(string jsonModel, string searchText)
        {
            TelcoModelView modelView = null;
            searchText = searchText.Length > 0 ? searchText : string.Empty;

            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                if (jsonModel != "null" && jsonModel != "undefined")
                {
                    modelView = new JavaScriptSerializer().Deserialize<TelcoModelView>(jsonModel);
                }
                else
                {
                    modelView = new TelcoModelView();
                    modelView.PageNo = 1;
                }

                modelView.PageSize = PageSize;

                // Fill Model
                List<TelcoModel> telcoCompanies = new TelcoBLL().GetctiveTelcoCompanies();
                List<TelcoModel> telcoPayments = new TelcoBLL().GetAllTelcoPayments(modelView.PageNo, modelView.PageSize, searchText);

                if (telcoCompanies != null && telcoCompanies.Count > 0)
                {
                    modelView.TelcoCompanies = telcoCompanies;
                }

                if (telcoPayments != null && telcoPayments.Count > 0)
                {
                    modelView.TelcoPayments = telcoPayments;

                    modelView.TotalCount = telcoPayments[0].RESULT_COUNT.Value;
                }

                // return modelView;
            }

            catch (Exception ex)
            {
                //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.TelcoPayment, CurrentUser.GetSessionUserInfo()));
                //LazySingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(modelView, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.TelcoPayment, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new TelcoModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new TelcoModelView("error|" + ex.Message);
                }

            }

            return modelView;
        }


        /// <summary>
        /// Remove Payment Information
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static TelcoModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            TelcoModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<TelcoModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;

                result = new TelcoBLL().Delete(model);
                LazySingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.BlockSuccessfully);
            }
            catch (Exception ex)
            {
            
                string errorCode = string.Empty;
                errorCode = LazySingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.TelcoPayment, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new TelcoModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new TelcoModel("error|" + ex.Message);
                }
            }
            return model;
        }


        #endregion
    }
}