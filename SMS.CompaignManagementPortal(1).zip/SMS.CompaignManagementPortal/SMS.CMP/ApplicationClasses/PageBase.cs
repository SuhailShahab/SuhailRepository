﻿

using BLL.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.PFSA.ApplicationClasses
{
    public class PageBase : System.Web.UI.Page
    {
        /// <summary>
        /// CR: 003
        /// CR: 012
        /// check page access rights against selected login
        /// </summary>
        /// <param name="Login"></param>
        /// <param name="Page"></param>
        /// <returns></returns>
        public bool GetPageAccessPermission(int? LoginID, string Page, int Level = 2)
        {
            return new CommonBLL().GetUserPageAccess(LoginID, Page, Level);
        }
    }
}