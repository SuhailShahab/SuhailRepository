﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ApplicationClasses
{
    public class ConfigurationHelper
    {
      

        public static string  DomainName
        {
            get
            {
               return  System.Web.Configuration.WebConfigurationManager.AppSettings["DomainName"];
               
            }
           
        }

        public static bool  IsByPassActiveDiretory
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["ByPassActiveDiretory"]);
               
            }
           
        }

        public static string ActiveDirectoryDC
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["ActiveDirectoryDC"];

            }
        }

        public static string DefaultOU
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["DefaultOU"];

            }
        }

        public static string DefaultRootOU
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["DefaultRootOU"];

            }
        }

        public static string ServiceUser
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["ServiceUser"];

            }
        }

        public static string ServicePassword
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["ServicePassword"];

            }
        }


        public static string HostingCMPServiceIP
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["HostingCMPServiceIP"];

            }
        }

        public static int PageSize
        {
            get
            {
                return Convert.ToInt32( System.Web.Configuration.WebConfigurationManager.AppSettings["PageSize"]);

            }
        }

        public static bool IsShowDownloadFilePath
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["IsShowDownloadFilePath"]);

            }
        }

        public static bool IsShowGeneralMsg
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["IsShowGeneralMsg"]);
            }
        }

        public static string GeneralMsg
        {
            get
            {
                // Random r = new Random();
                return System.Web.Configuration.WebConfigurationManager.AppSettings["GeneralMsg"]; //+ "\n (" + r.Next(5, 1000).ToString() + ")";

            }
        } 
    }
}