﻿
using BE.RightsManager;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace ApplicationClasses
{
    public class CurrentUser
    {


        public static int? LoginID
        {
            get
            {
                if (HttpContext.Current.Session["LoginID"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.UserID;

                }
                else
                {

                    return Convert.ToInt32(HttpContext.Current.Session["LoginID"]);
                }
            }

        }

        public static string UserDisplayName
        {
            get
            {
                if (HttpContext.Current.Session["EmployeeName"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.EmployeeName;


                }
                else
                {

                    return Convert.ToString(HttpContext.Current.Session["EmployeeName"]);
                }
            }

        }

        public static string LoginName
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return "super.op.user";//userModel.UserName;

            }

        }

        public static int? DistrictID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.DistrictID;

            }

        }

        public static UserModel CurrentUserInfo
        {
            get
            {
                return GetSessionUserInfo();
            }

        }

        public static string Url
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.Url;

            }
        }

        public static string DistrictCode
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.DistrictCode;

            }
        }


        public static bool? AllowUpdate
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return false;
                }
                return userModel.AllowUpdate;

            }
        }

        public static UserModel GetSessionUserInfo()
        {
            UserModel model = null;
            if (HttpContext.Current.Session["CurrentUser"] == null)
            {
                if (HttpContext.Current.Request.Cookies["LoginID"] != null)
                {
                   
                    
                        int loingID = Convert.ToInt32(HttpContext.Current.Request.Cookies["LoginID"].Value);
                        model = new UserBLL().GeLoginUserInfoByLogin(loingID);
                        HttpContext.Current.Response.Cookies["LoginID"].Value = model.UserID.ToString();
                        HttpContext.Current.Response.Cookies["LoginID"].Expires = DateTime.Now.AddDays(1);
                        HttpContext.Current.Response.Cookies["UserName"].Value = model.UserName.ToString();
                        HttpContext.Current.Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(1);
                        HttpContext.Current.Session["CurrentUser"] = model;
                        HttpContext.Current.Session["LoginID"] = model.UserID;
                        HttpContext.Current.Session["EmployeeName"] = model.EmployeeName;
                  
                }
                else
                {
                    // get data from data base
                   //HttpContext.Current.Session.SessionID 
                    return null;
                }


            }
            else
            {
                model = (UserModel)(HttpContext.Current.Session["CurrentUser"]);
            }

            return model;
        }

        public static int? OrganizationID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.OrganizationID;

            }
        }

        public static int? DepartmentID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.DepartmentID;

            }
        }

        public static int? UserTypeID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.UserTypeID;

            }
        }

    }
}