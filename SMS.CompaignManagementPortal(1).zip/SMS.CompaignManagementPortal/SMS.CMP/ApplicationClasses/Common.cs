﻿

using BE.CustomEnums;
using BE.Lookups;
using BLL.Common;
using SMS.CMP.BE.CMP;
using SMS.CMP.BE.Common;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.SchedulerInfo;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace ApplicationClasses
{

  public  class Common
    {
          public static string RemoveEscapeCharacters(string msg)
          {
              return Regex.Replace(msg, @"\t|\n|\r", "");
          }
        /// <summary>
        /// Get Contacts From Excel File
        /// </summary>
        /// <param name="FilePath"></param>
        /// <returns></returns>
        public static DataTable GetContactsFromExcel(string filePath)
        {
            DataTable dt;

            try
            {
                string connStr = null;

                connStr = "provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties=Excel 8.0;";
                OleDbConnection MyConnection;
                DataSet ds;
                OleDbDataAdapter MyCommand;
                MyConnection = new OleDbConnection(connStr);
                MyCommand = new OleDbDataAdapter("select * from [Sheet1$]", MyConnection);
                ds = new System.Data.DataSet();
                MyCommand.Fill(ds);
                MyConnection.Close();
                dt = ds.Tables[0].Copy();


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        /// <summary>
        /// Get Contacts Information From CSV File
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="organizationID"></param>
        /// <returns></returns>
        public static DataTable GetContactsFromCSVFile(string filePath)
        {
            DataTable dt = new DataTable ();
            dt.Columns.Add("FirstName", typeof(System.String));
            dt.Columns.Add("LastName", typeof(System.String));
            dt.Columns.Add("Email", typeof(System.String));
            dt.Columns.Add("Phone", typeof(System.String));

            bool FirstRow = true;
            using (CsvReader reader = new CsvReader(filePath))
            {
                foreach (string[] values in reader.RowEnumerator)
                {
                    if (values.Length == 4)
                    {
                        if (!FirstRow)
                        {
                            DataRow dr = dt.NewRow();
                            dr["FirstName"] = values[0].Trim();
                            dr["LastName"] = values[1].Trim();
                            dr["Email"] = values[2].Trim();
                            dr["Phone"] = values[3].Trim();
                            dt.Rows.Add(dr);
                        }
                    }
                    FirstRow = false;

                }
            }

           
            return dt;
        }
        public static DataTable GetBulkContactsFromCSVFile(string filePath)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Phone", typeof(System.String));
            dt.Columns.Add("Message", typeof(System.String));
           

            bool FirstRow = true;
            using (CsvReader reader = new CsvReader(filePath))
            {
                foreach (string[] values in reader.RowEnumerator)
                {
                    if (values.Length == 2)
                    {
                        if (!FirstRow)
                        {
                            DataRow dr = dt.NewRow();
                            dr["Phone"] = values[0].Trim();
                            dr["Message"] = values[1].Trim();
                            
                            dt.Rows.Add(dr);
                        }
                    }
                    FirstRow = false;

                }
            }


            return dt;
        }


        /// <summary>
        /// Save Error Log Info
        /// </summary>
        /// <param name="erroLog"></param>
        /// <returns></returns>
        public  int AddErrorLog(ErrorLogModel erroLog)
        {
            return new CommonBLL().SaveErrorLog(erroLog);
        }
        
       /// <summary>
       /// This method use to Get the Files information and Convert into Datatable
       /// </summary>
       /// <param name="request">Http REquest</param>
       /// <returns></returns>
        public DataTable UploadContactsFiles(HttpRequest request)
        {
            DataTable dt = null;

            try
            {

                HttpPostedFile postFile = request.Files[0];
                string[] arrName = postFile.FileName.Split('.');
                string ct = GetMimeType(arrName[1]);
                string filePath = HttpContext.Current.Server.MapPath("/") + "UploadFiles//" + System.IO.Path.GetFileName(postFile.FileName);
                if (string.IsNullOrEmpty(ct) == false)
                {
                    byte[] FileBytes = GetFileContent(postFile.InputStream);
                    if (File.Exists(filePath))
                    {
                        /// Delete existing file
                        File.Delete(filePath);
                    }

                    System.IO.FileStream _FileStream = new System.IO.FileStream(filePath, System.IO.FileMode.CreateNew, System.IO.FileAccess.Write);
                    // Writes a block of bytes to this stream using data from
                    // a byte array.
                    _FileStream.Write(FileBytes, 0, FileBytes.Length);
                    // close file stream
                    _FileStream.Close();

                }

                if (ct == "text/csv" || ct == "text/plain" || ct == ".txt" || ct == ".csv" || ct == "application/octet-stream")
                    dt = Common.GetContactsFromCSVFile(filePath);
                else if (ct == ".xls" || ct == ".xlsx" || ct == "application/vnd.ms-excel")
                    dt = Common.GetContactsFromExcel(filePath);
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(new Exception(filePath + " Type" + ct), "UploadContactsFiles", 0, PageNames.AddressBook, CurrentUser.LoginID));
                }

                /// Delete existing file test
                File.Delete(filePath);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }
        public DataTable UploadBulkContactsFiles(HttpRequest request)
        {
            DataTable dt = null;

            try
            {

                HttpPostedFile postFile = request.Files[0];
                string[] arrName = postFile.FileName.Split('.');
                string ct = GetMimeType(arrName[1]);
                string filePath = HttpContext.Current.Server.MapPath("/") + "UploadFiles//" + System.IO.Path.GetFileName(postFile.FileName);
                if (string.IsNullOrEmpty(ct) == false)
                {
                    byte[] FileBytes = GetFileContent(postFile.InputStream);
                    if (File.Exists(filePath))
                    {
                        /// Delete existing file
                        File.Delete(filePath);
                    }

                    System.IO.FileStream _FileStream = new System.IO.FileStream(filePath, System.IO.FileMode.CreateNew, System.IO.FileAccess.Write);
                    // Writes a block of bytes to this stream using data from
                    // a byte array.
                    _FileStream.Write(FileBytes, 0, FileBytes.Length);
                    // close file stream
                    _FileStream.Close();

                }

                if (ct == "text/csv" || ct == "text/plain" || ct == ".txt" || ct == ".csv")
                    dt = Common.GetBulkContactsFromCSVFile(filePath);
                else if (ct == ".xls" || ct == ".xlsx" || ct == "application/vnd.ms-excel")
                    dt = Common.GetContactsFromExcel(filePath);
                else
                {
                    LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(new Exception( filePath + " Type" + ct), "UploadContactsFiles", 0, PageNames.AddressBook, CurrentUser.LoginID));
       
                }

                /// Delete existing file
                File.Delete(filePath);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }
       
        /// <summary>
        /// 
        /// <summary>
        /// Get bytes of provided file
        /// </summary>
        /// <param name="inputstm">File Streem</param>
        /// <returns>Return Curernt Bytes</returns>
        public Byte[] GetFileContent(System.IO.Stream inputstm)
        {
            Stream fs = inputstm;
            BinaryReader br = new BinaryReader(fs);
            Int32 lnt = Convert.ToInt32(fs.Length);

            byte[] bytes = br.ReadBytes(lnt);

            return bytes;
        }


        #region Big freaking list of mime types

        private static IDictionary<string, string> _mappings = new Dictionary<string, string>(StringComparer.InvariantCultureIgnoreCase) {
            {".txt", "text/plain"},
            {".csv", "text/csv"},
            {".xls", "application/vnd.ms-excel"},
            {".xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},
            
        };

        public static string GetMimeType(string extension)
        {
            if (extension == null)
            {
                throw new ArgumentNullException("extension");
            }

            if (!extension.StartsWith("."))
            {
                extension = "." + extension;
            }

            string mime;

            return _mappings.TryGetValue(extension, out mime) ? mime : "application/octet-stream";
        }

        #endregion

       
        //private static bool IsValidPhoneNo(string phoneNo)
        //{
        //    if (phoneNo.Length != 11) return false;

        //    if (phoneNo.Substring(0, 1) != "0") return false;

        //    if (IsAlpha(phoneNo)) return false;

        //    if (IsSymbol(phoneNo)) return false;

        //    return true;
        //}
      
        public static bool IsAlpha(string str)
        {
            for (int i = 0; i < str.Length; i++)
            {
                if (char.IsLetter(str[i]))
                    return true;
            }

            return false;

            // return (str.ToCharArray().All(c => Char.IsLetter(c)));
        }
        public static bool IsSymbol(string str)
        {

            for (int i = 0; i < str.Length; i++)
            {
                if (char.IsSymbol(str[i]))
                    return true;
            }
            return false;
            // return (str.ToCharArray().All(c =>  Char.IsSymbol(c)));
        }

      /// <summary>
      /// Validate Import Contact
      /// </summary>
      /// <param name="dt"></param>
      /// <returns></returns>
        public static DataSet ValidateContacts (DataTable dt)
        {
            DataSet ds = new DataSet();


            #region "Table Defination"

            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();

            dt1.Columns.Add("FirstName", typeof(System.String));
            dt1.Columns.Add("LastName", typeof(System.String));
            dt1.Columns.Add("Email", typeof(System.String));
            dt1.Columns.Add("Phone", typeof(System.String));
            dt1.Columns.Add("ContactNo", typeof(System.String));

            dt2.Columns.Add("FirstName", typeof(System.String));
            dt2.Columns.Add("LastName", typeof(System.String));
            dt2.Columns.Add("Email", typeof(System.String));
            dt2.Columns.Add("Phone", typeof(System.String));
            dt2.Columns.Add("Status", typeof(System.String));

            dt1.Rows.Clear();
            dt2.Rows.Clear();

            #endregion

            foreach (DataRow row in dt.Rows)
            {
                string firstName = string.Empty, lastName = string.Empty, email = string.Empty, phone = string.Empty, status = string.Empty;

                firstName = row["FirstName"].ToString();
                lastName = row["LastName"].ToString();
                email = row["Email"].ToString();

                status = "";

                if (!string.IsNullOrEmpty(row["Phone"].ToString()))
                {
                   

                    string phoneNo = row["Phone"].ToString();

                    if (phoneNo.Length == 10 && !phoneNo.StartsWith("0"))
                    {
                        row["Phone"] = "0" + Convert.ToString(row["Phone"]);
                        phoneNo = row["Phone"].ToString () ;
                    }

                    if (phoneNo.Length != 11 && phoneNo.Length != 12) status = "Phone No Length Incorrect.";

                    else if (phoneNo.Length == 11 && phoneNo.Substring(0, 2) != "03") status = "Invalid Phone No.";

                    else if (phoneNo.Length == 12 && phoneNo.Substring(0, 3) != "923") status = "Invalid Phone No.";

                    else if (IsAlpha(phoneNo)) status = "Character found in phone No";

                    else if (IsSymbol(phoneNo)) status = "Symbols found in phone No";

                    if (string.IsNullOrEmpty(status))
                    {
                        DataRow dataRow1 = dt1.NewRow();
                        //DataRow1["Phone"] = phoneNo;
                        dataRow1["FirstName"] = firstName;
                        dataRow1["LastName"] = lastName;
                        dataRow1["Email"] = email;
                        dataRow1["ContactNo"] = phoneNo;

                        if (phoneNo.Length < 12)
                            dataRow1["Phone"] = phoneNo.Replace(phoneNo.Substring(0, phoneNo.Length), PhoneCode.PhoneCode92.GetHashCode().ToString() + phoneNo.Substring(1));
                        else
                            dataRow1["Phone"] = phoneNo;

                        dt1.Rows.Add(dataRow1);
                    }

                    else
                    {
                        DataRow dataRow2 = dt2.NewRow();
                        dataRow2["Phone"] = phoneNo;
                        dataRow2["FirstName"] = firstName;
                        dataRow2["LastName"] = lastName;
                        dataRow2["Email"] = email;
                        dataRow2["Status"] = status;
                        dt2.Rows.Add(dataRow2);
                    }
                   
                }
            }

            //if (dt1.Rows.Count>0) ds.Tables.Add(dt1.Copy());
            //if (dt2.Rows.Count>0) ds.Tables.Add(dt2.Copy());
            ds.Tables.Clear();
            ds.Tables.Add(dt1.Copy());
            ds.Tables.Add(dt2.Copy());


            return ds;
        }
        public static DataSet ValidateBulkSMSContacts(DataTable dt, bool isEnCodeOn, List<SMSConfigurationModel> smsConfiguration)
        {
            DataSet ds = new DataSet();


            #region "Table Defination"

            DataTable dt1 = new DataTable();
            DataTable dt2 = new DataTable();
            
            dt1.Columns.Add("Phone", typeof(System.String));
            dt1.Columns.Add("Message", typeof(System.String));
            //dt1.Columns.Add("NetworkCode", typeof(System.String));
            dt1.Columns.Add("NoOfSMS", typeof(System.Int32));
            dt1.Columns.Add("SMSGateway", typeof(System.String));          
            dt1.Columns.Add("UserName", typeof(System.String));
            dt1.Columns.Add("Password", typeof(System.String));
            dt1.Columns.Add("IsOnNet", typeof(System.Boolean));
            dt1.Columns.Add("TelcoID", typeof(System.Int32));
           
            dt2.Columns.Add("Phone", typeof(System.String));
            dt2.Columns.Add("Message", typeof(System.String));
            dt2.Columns.Add("Status", typeof(System.String));
            

            #endregion
            string message = string.Empty,phone = string.Empty, status = string.Empty;
            string networkTypeCode = string.Empty;
            foreach (DataRow row in dt.Rows)
            {
                message = string.Empty;

                message = row["Message"].ToString();
               

                if (!string.IsNullOrEmpty(row["Phone"].ToString()))
                {
                    status = string.Empty;
                    networkTypeCode = string.Empty;

                    string phoneNo = row["Phone"].ToString();

                    if (phoneNo.Length != 11 && phoneNo.Length != 12) status = "Phone No Length Incorrect.";

                    else if (phoneNo.Length == 11 && phoneNo.Substring(0, 2) != "03") status = "Invalid Phone No.";

                    else if (phoneNo.Length == 12 && phoneNo.Substring(0, 3) != "923") status = "Invalid Phone No.";

                    else if (IsAlpha(phoneNo)) status = "Character found in phone No";

                    else if (IsSymbol(phoneNo)) status = "Symbols found in phone No";

                    if (string.IsNullOrEmpty(status))
                    {
                        DataRow dataRow1 = dt1.NewRow();
                        //DataRow1["Phone"] = phoneNo;
                        dataRow1["Message"] = message;
                        dataRow1["Phone"] = phoneNo;

                        //==============Get the Nework Code==========================

                        if (phoneNo.Length == 11)
                        {
                            networkTypeCode = phoneNo.Substring(0, 3);

                        }
                        else
                        {
                            networkTypeCode = phoneNo.Substring(2, 2);
                            networkTypeCode = "0" + networkTypeCode;
                        }

                        //dataRow1["NetworkCode"] = networkTypeCode;
                        //==================Cout the No of SMS=======================

                        dataRow1["NoOfSMS"] = LazySingletonBLL<ServerInfoBLL>.Instance.GetTotalNoOfSMS(message, isEnCodeOn);

                        //================== Get the SMS Server Configuration =======

                        SMSConfigurationModel sMSConfigurationModel = GetServierCofigInfo(smsConfiguration, networkTypeCode);
                        if (sMSConfigurationModel!=null)
                        {
                            dataRow1["SMSGateway"] = sMSConfigurationModel.SMSGateway;
                            dataRow1["UserName"] = sMSConfigurationModel.UserName;
                            dataRow1["Password"] = sMSConfigurationModel.Password;
                            sMSConfigurationModel.IsOnNet = sMSConfigurationModel.SourceNetworksID.Equals(networkTypeCode) ? true : false;  
                            dataRow1["IsOnNet"] = sMSConfigurationModel.IsOnNet;
                            dataRow1["TelcoID"] = sMSConfigurationModel.TelcoID;
                            
                        }
                        //===========================================================

                        if (phoneNo.Length < 12)
                        {
                            dataRow1["Phone"] = phoneNo.Replace(phoneNo.Substring(0, phoneNo.Length), PhoneCode.PhoneCode92.GetHashCode().ToString() + phoneNo.Substring(1));
                        }                           
                        else
                        {
                            dataRow1["Phone"] = phoneNo;
                        }
                           

                        dt1.Rows.Add(dataRow1);
                    }

                    else
                    {
                        DataRow dataRow2 = dt2.NewRow();
                        dataRow2["Phone"] = phoneNo;
                        dataRow2["Message"] = message;
                        dataRow2["Status"] = status;
                        dt2.Rows.Add(dataRow2);
                    }

                }
            }

            //if (dt1.Rows.Count>0) ds.Tables.Add(dt1.Copy());
            //if (dt2.Rows.Count>0) ds.Tables.Add(dt2.Copy());

            ds.Tables.Add(dt1.Copy());
            ds.Tables.Add(dt2.Copy());


            return ds;
        }
        public void ValidateBulkSMSContacts(BulkSMSModel bulkSMSModel)
        {
            // BulkSMSModel bulkSMSModel =new BulkSMSModel();


            string message = string.Empty, phone = string.Empty, status = string.Empty; string networkTypeCode = string.Empty;


            if (!string.IsNullOrEmpty(bulkSMSModel.Phone))
            {
                status = string.Empty;
                networkTypeCode = string.Empty;

                string phoneNo = bulkSMSModel.Phone;

                if (phoneNo.Length != 11 && phoneNo.Length != 12) status = "Phone No Length Incorrect.";

                else if (phoneNo.Length == 11 && phoneNo.Substring(0, 2) != "03") status = "Invalid Phone No.";

                else if (phoneNo.Length == 12 && phoneNo.Substring(0, 3) != "923") status = "Invalid Phone No.";

                else if (IsAlpha(phoneNo)) status = "Character found in phone No";

                else if (IsSymbol(phoneNo)) status = "Symbols found in phone No";

                if (string.IsNullOrEmpty(status))
                {

                    bulkSMSModel.Phone = phoneNo;

                    //==============Get the Nework Code==========================

                    if (phoneNo.Length == 11)
                    {
                        networkTypeCode = phoneNo.Substring(0, 3);

                    }
                    else
                    {
                        networkTypeCode = phoneNo.Substring(2, 2);
                        networkTypeCode = "0" + networkTypeCode;
                    }


                    //==================Cout the No of SMS=======================

                    bulkSMSModel.NoOfSMS = LazySingletonBLL<ServerInfoBLL>.Instance.GetTotalNoOfSMS(message, bulkSMSModel.IsEncodeOn.Value);

                    //================== Get the SMS Server Configuration =======

                    SMSConfigurationModel sMSConfigurationModel = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetNetworkProvider(networkTypeCode); //GetServierCofigInfo(smsConfiguration, networkTypeCode);
                    if (sMSConfigurationModel != null)
                    {
                        bulkSMSModel.SMSGateway = sMSConfigurationModel.SMSGateway;
                        bulkSMSModel.UserName = sMSConfigurationModel.UserName;
                        bulkSMSModel.Password = sMSConfigurationModel.Password;
                        sMSConfigurationModel.IsOnNet = sMSConfigurationModel.SourceNetworksID.Equals(networkTypeCode) ? true : false;
                        bulkSMSModel.IsOnNet = sMSConfigurationModel.IsOnNet;
                        bulkSMSModel.TelcoID = sMSConfigurationModel.TelcoID;

                    }
                    //===========================================================

                    if (phoneNo.Length < 12)
                    {
                        bulkSMSModel.Phone = phoneNo.Replace(phoneNo.Substring(0, phoneNo.Length), PhoneCode.PhoneCode92.GetHashCode().ToString() + phoneNo.Substring(1));
                    }
                    else
                    {
                        bulkSMSModel.Phone = phoneNo;
                    }



                }

            }


        }
          
        

        public static SMSConfigurationModel GetServierCofigInfo(List<SMSConfigurationModel> smsConfiguration, string networkProviderCode)
        {
            SMSConfigurationModel sMSConfigurationModel = null;
            if(smsConfiguration.Any(s=>s.IsDefault==true))
            {
                sMSConfigurationModel = smsConfiguration.FindLast(s => s.IsDefault == true);
            }
            else if(smsConfiguration.Any(s=>s.SourceNetworksID.Equals(networkProviderCode) && s.IsChecked == true))
            {
                 sMSConfigurationModel = smsConfiguration.FindLast(s=>s.SourceNetworksID.Equals(networkProviderCode) && s.IsChecked == true);
            }
            else if(smsConfiguration.Any(s=>s.IsOffNetChecked == true))
            {
                sMSConfigurationModel = smsConfiguration.FindLast(s => s.IsOffNetChecked == true);
            }
            return sMSConfigurationModel;
        }

        public bool SendSmsToClient(string HostURI)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(HostURI);
            request.Method = "GET";
            String test = String.Empty;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                test = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();
                return true;
            }

        }

        /// <summary>
        /// Convert DateFormate
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public DateTime ConvertDateFormat(string value)
        {
            DateTime Date = new DateTime();

            string[] arrValue = value.Split('/');
            if (arrValue.Length == 3)
            {
                Date = new DateTime(Convert.ToInt32(arrValue[2]), Convert.ToInt32(arrValue[1]), Convert.ToInt32(arrValue[0]));
            }

            return Date;
        }

        /// <summary>
        /// Get Page Access Permission
        /// </summary>
        /// <param name="Login"></param>
        /// <param name="Page"></param>
        /// <param name="Level"></param>
        /// <returns></returns>
        public bool GetPageAccessPermission(string Login, string Page, int Level = 2)
        {
            return new CommonBLL().GetUserPageAccess(Login, Page, Level);
        }

      /// <summary>
      /// Convert List<T> Into a DataTable
      /// </summary>
      /// <typeparam name="T"></typeparam>
      /// <param name="items"></param>
      /// <returns></returns>
        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
          
            return dataTable;
        }


        //public static void ProcessRequest(HttpContext context)
        //{
        //    //if (this.FileName != null)
        //    //{
        //    //    string path = Path.Combine(ConfigurationManager.UploadsDirectory, this.FileName);
        //    string filePath = HttpContext.Current.Server.MapPath("/") + "UploadFiles//Sample.csv";
        //    if (File.Exists(filePath) == true)
        //    {
        //        FileStream file = new FileStream(filePath, FileMode.Open);
        //        byte[] buffer = new byte[(int)file.Length];
        //        file.Read(buffer, 0, (int)file.Length);
        //        file.Close();
        //        context.Response.ContentType = "application/octet-stream";
        //        context.Response.AddHeader("content-disposition", "attachment; filename=\"" + "Sample.csv" + "\"");
        //        context.Response.BinaryWrite(buffer);
        //        context.Response.End();
        //    }
        //    //}
        //}


        /// <summary>
        /// Send SMS Request
        /// </summary>
        /// <param name="organizationID"></param>
        /// <param name="campaignID"></param>
        /// <returns></returns>
        public  bool SendRequest(int organizationID, int campaignID)
        {
            bool result;
            string ServiceURL = string.Empty;
            try
            {
                ServiceURL = GetUrl(organizationID, campaignID);
                result = SendSmsToClient(ServiceURL);
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        /// <summary>
        /// Get URL 
        /// </summary>
        /// <param name="organizationID">Selected Organization ID</param>
        /// <param name="campaignID"> Selected Campaign ID</param>
        /// <returns></returns>
        public  string GetUrl(int organizationID, int campaignID)
        {
            StringBuilder sbUrl = new StringBuilder();
            try
            {
               
                sbUrl.Append("http://" + ConfigurationHelper.HostingCMPServiceIP); // Service URL
                sbUrl.Append("/PortalService.svc"); // Service Page
                sbUrl.Append("/SendSMSFromPortal"); // Service Method
                sbUrl.Append("/" + campaignID); // CampaingID
                sbUrl.Append("/" + organizationID); // Organization ID
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return sbUrl.ToString();

        }

       
    }
}
