﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.API.Response.ApplicationClasses
{
    enum DataType
    {
        RawMRZData = 0,
        LineOne = 1,
        LineTwo = 2,
        LineThree = 3,
        Type = 4,
        DocumentNumber = 5,
        FirstName = 6,
        LastName = 7,
        DateOfBirth = 8,
        DateOfExpiry = 9,
        IssuingState = 10,
        Nationality = 11,
        Gender = 12,
        OptionalDataOne = 13,
        OptionalDataTwo = 14,
        FailureStatus = 15,
    }

}
