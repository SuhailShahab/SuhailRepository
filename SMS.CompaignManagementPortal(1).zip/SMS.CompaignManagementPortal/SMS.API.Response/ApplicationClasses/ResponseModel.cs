﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS.API.Response.ApplicationClasses
{
    [System.Runtime.Serialization.DataContract]
    public class ResponseModel
    {
        [System.Runtime.Serialization.DataMember]
        public string ReplyMessage { get; set; }
        [System.Runtime.Serialization.DataMember]
        public string ReplyPhoneNumber { get; set; }
        [System.Runtime.Serialization.DataMember]
        public string ResponseDate { get; set; }
        [System.Runtime.Serialization.DataMember]
        public string ShortCode { get; set; }
        [System.Runtime.Serialization.DataMember]
        public string ConfirmationCode { get; set; }
        [System.Runtime.Serialization.DataMember]
        public string ResponseMessage { get; set; }
        [System.Runtime.Serialization.DataMember]
        public string ID { get; set; }
        /// <summary>
        /// Send Reply to user. Send message if IsSend=Y and not send is IsSend=N
        /// </summary>
        [System.Runtime.Serialization.DataMember]
        public string IsSend { get; set; }
        [System.Runtime.Serialization.DataMember]
        public string IsEnCodingON { get; set; }
    }

    [System.Runtime.Serialization.DataContract]
    public class SMSModel
    {
        [System.Runtime.Serialization.DataMember]
        public string PhoneNo { get; set; }
        [System.Runtime.Serialization.DataMember]
        public string SMSMessage { get; set; }
    }
}