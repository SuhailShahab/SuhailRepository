﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.API.Response.ApplicationClasses
{
   public  class TestEmailModel
    {
        public string Subject { get; set; }
        public string Body { get; set; }
        public List<string> ToEmailAddresses { get; set; }
        public List<string> CCEamilAddresses { get; set; }
        public List<string> BCEmailAddresses { get; set; }

        #region "Constructors"

        public TestEmailModel()
        {
            this.ToEmailAddresses = new List<string>();
        }

        public TestEmailModel(string Subject, string Body)
        {
            this.Subject = Subject;
            this.Body = Body;
            this.ToEmailAddresses = new List<string>();
        }

        #endregion
    }
}
