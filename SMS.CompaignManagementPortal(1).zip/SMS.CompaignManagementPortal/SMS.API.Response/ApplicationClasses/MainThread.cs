﻿
using SMS.API.Response.ApplicationClasses.Log;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

// =================================================================================================================================
// Create by:	<Suhail Shahab>
// Create date: <21-10-2015 07:47:38>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
//CR:001            SUHAIL SHAHAB                   26-06-2015                  Add Email functionality
// =================================================================================================================================
namespace SMS.API.Response.ApplicationClasses
{
    public class MainThread
    {
        /// <summary>
        ///// Create the Main Thread
        ///// </summary>
        public void StartThread()
        {
            Thread mT = new Thread(Main);
            mT.Start();
        }

        /// <summary>
        /// Main Tread Start the process
        /// </summary>
        public void Main()
        {
            string webForntEnd = ConfigurationHelper.IPSecondWebFornt; //"192.168.10.3";
            WebForntNames currentRunningWebFornt = CommonHelper.GetWebForntEnum(ConfigurationHelper.CurrentRuningWebFront);     // WebForntNames.WEB_FORNT1;
            WebForntNames secodWebFornt = CommonHelper.GetWebForntEnum(ConfigurationHelper.SecondWebFront);     // WebForntNames.WEB_FORNT2;

            try
            {
                while (true)
                {
                    Console.WriteLine("Applciation start version no: 0015....");
                    Thread.Sleep(1000);
                    Console.WriteLine("HostingIP Address"+ConfigurationHelper.HostingIP);
                    //Console.WriteLine("Service Name" + ConfigurationHelper.WCFServiceName);
                    // string applicationName = AppDomain.CurrentDomain.SetupInformation.ApplicationName;
                    // Console.WriteLine(applicationName);
                    bool isPinged = CommonHelper.PingHost(webForntEnd);         // check primary server
                    if (isPinged)
                    {
                        Console.WriteLine("Check Active Web Fornt.");
                        bool isActiveServer = LazySingletonBLL<ServerInfoBLL>.Instance.IsActiveServer(secodWebFornt.GetHashCode());
                        if (!isActiveServer)
                        {
                           // B2BayLogger.Log("Applciation Start");                         

                            if (LazySingletonBLL<ThirdPartyAPIResponseBLL>.Instance.IsExistsRecords())
                            {
                               
                               
                                    int noOfThreads = 1; //ConfigurationHelper.NoOfThreads;

                                    Task[] taskArray = null;
                                    taskArray = new Task[noOfThreads];

                                    for (int j = 0; j < noOfThreads; j++)
                                    {
                                                                         

                                        //taskArray[j] = Task.Factory.StartNew((Object obj) =>
                                        //{
                                        //    SMSQueue smsQueue = new SMSQueue(configModel.SMSThroughput);
                                        //    smsQueue.SendQuesueSMS(configModel.TelcoID, null);

                                        //}, j);
                                        //string threadInfo = "Thread TelcoID " + configModel.TelcoID + " SMSThroughput " + configModel.SMSThroughput;
                                        //Console.WriteLine(threadInfo);
                                        //B2BayLogger.Log(threadInfo);
                                    }

                                    try
                                    {
                                        B2BayLogger.Log("Wait for Completion of task---");
                                        Task.WaitAll(taskArray);
                                        Console.WriteLine("Flushing the Buffere..");
                                        //======================= Purge whole Buffer Data with IS Send is "3" =======================================
                                        LazySingleton<ThirdPartyAPIResponseBLL>.Instance.RemoveRecords();
                                        //=============================================================================================================
                                        // B2BayLogger.Log("Wait after deletion");
                                        //Thread.Sleep(20000);
                                    }
                                    catch
                                    { }

                                    B2BayLogger.Log("Request Send Successfully");
                                    Console.WriteLine("Request Send Successfully");

                                    B2BayLogger.WriteLogsToFile();
                                    Thread.Sleep(1000);
                               
                            }
                            else
                            {                              

                                Console.WriteLine("No Pending SMS Queue Exist");
                                Thread.Sleep(2000);
                            }

                        }
                        else
                        {
                            Console.WriteLine("Another Web Front End server is Active.");
                            B2BayLogger.Log("Another Web Front End server is Active.");
                            B2BayLogger.WriteLogsToFile();
                            int maxDelay = ConfigurationHelper.MaxRequestDelay * 2;
                            Thread.Sleep(maxDelay);
                        }
                    }
                    else //not runing
                    {
                        Console.WriteLine("Check Active Web Fornt.");
                        bool isActiveServer = LazySingletonBLL<ServerInfoBLL>.Instance.IsActiveServer(secodWebFornt.GetHashCode());
                        if (!isActiveServer)
                        {
                          //  Thread.Sleep(ConfigurationHelper.MaxRequestDelay);

                            if (LazySingletonBLL<SMSQueueBLL>.Instance.IsExistPendingSMSQueue())
                            {
                                Console.WriteLine("Send Request for Starting Que Based SMS Send Request ....");
                                B2BayLogger.Log("Send Request for Starting Que Based SMS Send Request ....");

                                Console.WriteLine("Get Active Telcos..");
                                B2BayLogger.Log("Get Active Telcos...");
                                // Initiate Task Based Thread
                                List<SMSConfigurationModel> colTelcos = LazySingletonBLL<SMSConfigurationBLL>.Instance.GetActiveTelcos();
                                if (colTelcos != null && colTelcos.Count > 0)
                                {
                                    int noOfThreads = colTelcos.Count; //ConfigurationHelper.NoOfThreads;

                                    Task[] taskArray = null;
                                    taskArray = new Task[noOfThreads];

                                    for (int j = 0; j < noOfThreads; j++)
                                    {
                                        SMSConfigurationModel configModel = colTelcos[j];
                                       

                                        taskArray[j] = Task.Factory.StartNew((Object obj) =>
                                         {
                                             //SMSQueue.SendQuesueSMS();
                                             SMSQueue smsQueue = new SMSQueue(configModel.SMSThroughput);
                                             smsQueue.SendQuesueSMS(configModel.TelcoID, null);

                                         }, j);
                                    }

                                    try
                                    {
                                        Task.WaitAll(taskArray);
                                        //======================= Purge whole Buffer Data with IS Send is "3" =======================================
                                        LazySingleton<SMSQueueBLL>.Instance.PurgeBufferData();
                                        //=============================================================================================================
                                        B2BayLogger.Log("Wait after deletion");
                                        //Thread.Sleep(20000);
                                    }
                                    catch
                                    { }

                                    B2BayLogger.Log("Request Send Successfully");
                                    Console.WriteLine("Request Send Successfully");

                                    Thread.Sleep(1000);
                                }
                                else
                                {
                                    Console.WriteLine("There is no active telcos exist.");
                                    B2BayLogger.Log("There is no active telcos exist.");
                                    Thread.Sleep(1000);

                                   
                                }
                            }
                            else 
                            {
                                Console.WriteLine("No Pending SMS Queue Exist");
                                Thread.Sleep(2000);
                                
                            }
                        }
                        else if (isActiveServer)
                        {

                            Console.WriteLine("Update Active Server.");
                            B2BayLogger.Log("Update Active Server.");
                            LazySingletonBLL<ServerInfoBLL>.Instance.UpdateServerActive(currentRunningWebFornt.GetHashCode());
                            
                        }
                    }

                    B2BayLogger.WriteLogsToFile();
                }
                //End of While
                //if (ConfigurationHelper.EnableEMailNotification)
                //    CommonHelper.SendNotificationEmail("SMS Queue Schulder have been Stop due to some issue");
               // Environment.Exit(0);
            }
            catch (Exception e)
            {
                B2BayLogger.LogErr("Error:", e);
                Console.WriteLine(e.Message);
                B2BayLogger.WriteLogsToFile();

                // ============================================ Send Email Notification ============================================ //
                if (ConfigurationHelper.EnableEMailNotification)
                    CommonHelper.SendNotificationEmail("SMS Queue Schulder have been Stop due to some issue"+e.Message);
            }
            if (ConfigurationHelper.EnableEMailNotification)
                CommonHelper.SendNotificationEmail(" SMS Queue  Schulder have been Stop due to some issue");
            Environment.Exit(0);
        }

      

      
    }
}
