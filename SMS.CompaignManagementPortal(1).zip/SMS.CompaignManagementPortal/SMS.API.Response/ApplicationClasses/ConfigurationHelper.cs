﻿using System;
using System.Configuration;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <21-10-2015 07:47:38PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.API.Response.ApplicationClasses
{
    public class ConfigurationHelper
    {
        public static string IPSecondWebFornt
        {
            get
            {
                return ConfigurationManager.AppSettings["IPSecondWebFornt"];
            }
        }

        public static string CurrentRuningWebFront
        {
            get
            {
                return ConfigurationManager.AppSettings["CurrentRuningWebFront"];
            }
        }

        public static string SecondWebFront
        {
            get
            {
                return ConfigurationManager.AppSettings["SecondWebFront"];
            }
        }

        public static string LogFilePath
        {
            get
            {
                return ConfigurationManager.AppSettings["LogFilePath"];
            }
        }

        public static bool ShowLog
        {
            get
            {
                return Convert.ToBoolean(ConfigurationManager.AppSettings["ShowLog"]);
            }
        }

        //public static string HostingUrl
        //{
        //    get
        //    {
        //        return Convert.ToString(ConfigurationManager.AppSettings["HostingUrl"]);
        //    }
        //}

        public static string EMailSenderAddress
        {
            get
            {
                return Convert.ToString(ConfigurationManager.AppSettings["EMailSenderAddress"]);
            }
        }

        public static string EMailSenderPassword
        {
            get
            {
                return Convert.ToString(ConfigurationManager.AppSettings["EMailSenderPassword"]);
            }
        }

        public static string SMTPServer
        {
            get
            {
                return Convert.ToString(ConfigurationManager.AppSettings["SMTPServer"]);
            }
        }

        public static int SMTPServerPort
        {
            get
            {
                return Convert.ToInt32(ConfigurationManager.AppSettings["SMTPServerPort"]);
            }
        }

        public static bool SMTPEnableSSL
        {
            get
            {
                return Convert.ToBoolean(ConfigurationManager.AppSettings["SMTPEnableSSL"]);
            }
        }

        public static bool EnableEMailNotification
        {
            get
            {
                return Convert.ToBoolean(ConfigurationManager.AppSettings["EnableEMailNotification"]);
            }
        }

        public static string SendToEmailAddress
        {
            get
            {
                return Convert.ToString(ConfigurationManager.AppSettings["SendToEmailAddress"]);
            }
        }

        public static string TOCC_EmailAddress
        {
            get
            {
                return Convert.ToString(ConfigurationManager.AppSettings["TOCC_EmailAddress"]);
            }
        }

        public static string TOBC_EmailAddress
        {
            get
            {
                return Convert.ToString(ConfigurationManager.AppSettings["TOBC_EmailAddress"]);
            }
        }

        public static int MaxRequestDelay
        {
            get
            {
                return Convert.ToInt32(ConfigurationManager.AppSettings["MaxRequestDelay"]);
            }
        }

        public static string HostingIP
        {
            get
            {
                return ConfigurationManager.AppSettings["HostingIP"] ;
            }
        }

        public static string WCFServiceName
        {
            get
            {
                return ConfigurationManager.AppSettings["WCFServiceName"];
            }
        }



        public static int NoOfThreads
        {
            get
            {
                return Convert.ToInt32(ConfigurationManager.AppSettings["NoOfThreads"]);
            }
        }

        public static string EmailPath
        {
            get
            {
                return ConfigurationManager.AppSettings["EmailPath"];
            }
        }

        
        

    }
}