﻿using SMS.API.Response.ApplicationClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SMS.API.Response.ApplicationClasses
{
    public class ThirdParyResponseModel
    {
        public ResponseModel Response { get; set; }
        public string Result { get; set; }
    }
}