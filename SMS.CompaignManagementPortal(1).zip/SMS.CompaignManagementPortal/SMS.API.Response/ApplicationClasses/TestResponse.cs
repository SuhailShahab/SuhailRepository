﻿using SMS.API.Response.ApplicationClasses.Log;
using SMS.CMP.BE.APIClasses;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using TS.Model.Emails;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
namespace SMS.API.Response.ApplicationClasses
{
    class TestResponse
    {
        public static void SendReponseToThirdPary(CustomerResponseModel customerResponseModel)
        {
            B2BayLogger.Log("Call Method SendReponseToThirdPary");

            string result = string.Empty;
            ResponseModel responseModel = new ResponseModel();
            responseModel.ReplyMessage = customerResponseModel.ReplyMessage;
            responseModel.ReplyPhoneNumber = customerResponseModel.ReplyPhoneNo;
            responseModel.ResponseDate = DateTime.Now.ToString(); //"22-11-2015 13:10:40";
            responseModel.ShortCode = customerResponseModel.ShortCode;
            responseModel.IsEnCodingON = "N";
            responseModel.IsSend = "N";
            responseModel.ID = Convert.ToString(customerResponseModel.ID);
            B2BayLogger.WriteLogsToFile();

            string strDataMoedel = "";
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(ResponseModel));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, responseModel);
                strDataMoedel = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                //WebOperationContext.Current.OutgoingResponse.Headers.Add("data", Data);
            }
            catch (Exception ex)
            {
                throw new Exception("Data contract serializer exception : " + ex.Message);
            }


            // process the request and get response as string
            string ServiceURL = customerResponseModel.ServiceUrl;

            WebClient webClient = new WebClient();

            try
            {
                webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;
                webClient.Headers["datatype"] = "json";
            }
            catch (Exception ex)
            {
                throw new Exception("Web client exception : " + ex.Message);
            }


            try
            {

                Uri address = new Uri(ServiceURL + "/" + customerResponseModel.MethodName);
                result = webClient.UploadString(address, "POST", strDataMoedel);
            }
            catch (Exception ex)
            {

                throw new Exception("Service connectivity exception : " + ex.Message);
            }


            ResponseModel test = JsonDeserialize<ResponseModel>(result);

            string abc = test.ConfirmationCode;
            //ResponseModel resultModel = null;
            //try
            //{

            //    resultModel = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ResponseModel>(result);
            //}
            //catch (Exception ex)
            //{
            //    B2BayLogger.Log("Respone Form ThirdParty" + result);
            //    throw new Exception("Invalid respone Form ThirdParty : " + ex.Message);
            //}

            //return resultModel;
        }
        public static void SendSMS()
        {
            B2BayLogger.Log("Call Method SendReponseToThirdPary");

            string result = string.Empty;
            SMSModel model = new SMSModel();
            model.PhoneNo = "03320754179";
            model.SMSMessage = "Test message form majeed khan";
            B2BayLogger.WriteLogsToFile();

            string strDataMoedel = "";
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(SMSModel));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, model);
                strDataMoedel = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                //WebOperationContext.Current.OutgoingResponse.Headers.Add("data", Data);
            }
            catch (Exception ex)
            {
                throw new Exception("Data contract serializer exception : " + ex.Message);
            }


            // process the request and get response as string
            //string ServiceURL = "http://sms.punjab.gov.pk/api/cmpservice.svc/smssend/NTk3/Mg==/en";
            //https://connect.jazzcmt.com/sendsms_url.html?Username=03070984927&Password=Jazz@1234&From=9100&To=03320754179&Message=صبح بخیر
            //string ServiceURL = "http://localhost:58131/cmpservice.svc/smssend/NTY4/MQ==/en";
            string ServiceURL = "https://connect.jazzcmt.com/sendsms_url.html?Username=03070984927&Password=Jazz@1234&From=9100&To=03320754179&Message=صبح بخیر";
        

            WebClient webClient = new WebClient();

            try
            {
                webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;
                webClient.Headers["datatype"] = "json";
            }
            catch (Exception ex)
            {
                throw new Exception("Web client exception : " + ex.Message);
            }


            try
            {

                Uri address = new Uri(ServiceURL);
                result = webClient.UploadString(address, "POST", strDataMoedel);
            }
            catch (Exception ex)
            {

                throw new Exception("Service connectivity exception : " + ex.Message);
            }

            //ResponseModel resultModel = null;
            //try
            //{

            //    resultModel = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ResponseModel>(result);
            //}
            //catch (Exception ex)
            //{
            //    B2BayLogger.Log("Respone Form ThirdParty" + result);
            //    throw new Exception("Invalid respone Form ThirdParty : " + ex.Message);
            //}

            //return resultModel;
        }


        public static void TestForSendingEmail(EmailModel email)
        {
            B2BayLogger.Log("Call Method SendReponseToThirdPary");

            string result = string.Empty;
            email.Subject = "Test Subject";
            email.Body = "Test Eamil Body";
            email.ToEmailAddresses = new List<string>();
            email.ToEmailAddresses.Add("sohail.shahab@punjab.gov.pk");
            email.ToEmailAddresses.Add("shahabsohail@hotmail.com");
            email.SenderEmail = "support@punjab.gov.pk";// "e-khidmat@punjab.gov.pk";
            //email.CCEamilAddresses = new List<string>();
            //email.CCEamilAddresses.Add("sohail.shahab@pitb.gov.pk.com");
            //email.BCEmailAddresses = new List<string>();
            //email.BCEmailAddresses.Add("sohail.shahab@pitb.gov.pk.com");

            B2BayLogger.WriteLogsToFile();

            string strDataMoedel = "";
            try
            {
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(EmailModel));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, email);
                strDataMoedel = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                //WebOperationContext.Current.OutgoingResponse.Headers.Add("data", Data);
            }
            catch (Exception ex)
            {
                throw new Exception("Data contract serializer exception : " + ex.Message);
            }


            // process the request and get response as string

            //string ServiceURL = "http://localhost:56178/EmailService.svc/SendEmail"; //customerResponseModel.ServiceUrl;
          // string ServiceURL = "http://192.168.10.122:5565/EmailService.svc/SendEmail";
           string ServiceURL = "http://sms.punjab.gov.pk/email/EmailService.svc/SendEmail"; //customerResponseModel.ServiceUrl;
           // string ServiceURL = "http://192.168.10.122:5565/EmailService.svc/TestMethod";
            // string ServiceURL = "http://sms.punjab.gov.pk/email/EmailService.svc/TestMethod"; //customerResponseModel.ServiceUrl;

            WebClient webClient = new WebClient();

            try
            {
                webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;
                webClient.Headers["datatype"] = "json";
            }
            catch (Exception ex)
            {
                throw new Exception("Web client exception : " + ex.Message);
            }


            try
            {

                Uri address = new Uri(ServiceURL);
                result = webClient.UploadString(address, "POST", strDataMoedel);
            }
            catch (Exception ex)
            {

                throw new Exception("Service connectivity exception : " + ex.Message);
            }

            //ResponseModel resultModel = null;
            //try
            //{

            //    resultModel = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ResponseModel>(result);
            //}
            //catch (Exception ex)
            //{
            //    B2BayLogger.Log("Respone Form ThirdParty" + result);
            //    throw new Exception("Invalid respone Form ThirdParty : " + ex.Message);
            //}

            //return resultModel;
        }
        public static void GetTCSStatus()
        {
            UTF8Encoding enc = new UTF8Encoding();

            //30060572391
            //4001731406
            //1234567890
            //400235689
           // var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051956143\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
            //var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051956142\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
           // var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051956141\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
           // var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051218201\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
           // var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051562558\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
           // var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051562556\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
           // var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051562629\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
           // var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051731045\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
           // var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051956210\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
            var data = "{\"controller\":\"todo\",\"action\":\"trackdata\",\"CNSG_NO\":\"40051956095\",\"username\":\"User\",\"userpass\":\"pass\",\"apikey\":\"28e336ac6c9423d946ba02d19c6a2632\"}";
         

            var temp = Convert.ToBase64String(new ASCIIEncoding().GetBytes(data));


            string url = "http://175.107.192.177:8082/bkg_api_net/?app_id=APP001&enc_request=" + temp;

            //Console.Write(temp);

            WebRequest myReq = WebRequest.Create(url);

            myReq.Method = "POST";
            myReq.ContentLength = temp.Length;
            myReq.ContentType = "application/json; charset=UTF-8";




            using (Stream ds = myReq.GetRequestStream())
            {
                ds.Write(enc.GetBytes(temp), 0, temp.Length);
            }


            WebResponse wr = myReq.GetResponse();
            Stream receiveStream = wr.GetResponseStream();
            StreamReader reader = new StreamReader(receiveStream, Encoding.UTF8);
            string content = reader.ReadToEnd();
           // Type objType =  new TCS().GetType();
          //  object  obj = reader.CreateObjRef(objType);
            //Response.Write(content);
           // new System.Web.s.Script.Serialization.JavaScriptSerializer().Deserialize<TCSResponse>(content);
            TCS obj1 = JsonDeserialize<TCS>(content);
            //TCS obj = Deserialize<TCS>(content);
            List<TCSResponse> obj2 = JsonDeserialize<List<TCSResponse>>(obj1.data);
            Console.Write(content);
        }

        public static T JsonDeserialize<T>(string jsonString)
        {
            
            DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(T));
           // MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(jsonString));
            MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(jsonString));
            T obj = (T)ser.ReadObject(ms);
            return obj;
        }

        /// <summary>
        /// Deserializes the specified json string into object of type T.
        /// </summary>
        /// <typeparam name="T">Type of the object to be returned.</typeparam>
        /// <param name="json">The json string of the object.</param>
        /// <returns>The deserialized object from the json string.</returns>
        public static T Deserialize<T>(string json)
        {
           // Utils.ArgumentValidation.EnsureNotNull(json, "json");

            T obj = Activator.CreateInstance<T>();
            using (MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(json)))
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(obj.GetType());
                obj = (T)serializer.ReadObject(ms);
            }

            return obj;
        }

        public bool SendSmsToClient1(string hostURI)
        {
            WebRequest request = WebRequest.Create(hostURI);
            request.Method = "GET";
            //return true;
           
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                string  test = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();

                return true;
            }

        }

        public string  SendGIS(string url)
        {
           // SMSModel sms = new SMSModel(mobileNo, message);
            string Data = "";
            string reutl = null;
            try
            {
                // serailze model object to json string
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(SMSModel));
                MemoryStream mem = new MemoryStream();
               // ser.WriteObject(mem, sms);
              //  Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                // process the request and get response as string
                string ServiceURL = url;// ConfigurationHelper.SMSGatewayURL;

                WebClient webClient = new WebClient();
                webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;

                Uri address = new Uri(ServiceURL);
                reutl =  webClient.UploadString(address, "POST",Data);
               // string newres = reutl;
            }
            catch (Exception ex)
            {
               // LazyBaseSingletonUI<Common>.Instance.AddErrorLog(new ErrorLogModel(ex, "SendSMSAlert", "Common.cs"));
            }
            return reutl;
        }
        public bool SendGISRequest(string hostURI)
        {
            WebRequest request = WebRequest.Create(hostURI);
            request.Method = "POST";
            //return true;

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                string test = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();

                return true;
            }

        }

       

        public async Task<List<string>> SendSmsToClient2(string hostURI)
        {
            var request = await Task.Run(() =>
            {
                // WebRequest.Create freezes??
                return System.Net.WebRequest.Create(hostURI);
            });
            return null;
            //// ...

            //using (var ss = await request.GetRequestStreamAsync())
            //{ 
            //    await ss.WriteAsync(...);
            //}

            //using (var rr = await request.GetResponseAsync())
            //using (var ss = rr.GetResponseStream())
            //{
            //    //read stream and return data
            //}
        }

        public  static async Task<string> SendSmsToClient(string url)
        {
            WebRequest wr = WebRequest.Create(url);
            var response = await wr.GetResponseAsync();
            using (var stm = response.GetResponseStream())
            {
                using (var reader = new StreamReader(stm))
                {
                    var content = await reader.ReadToEndAsync();
                    return content;
                }
            }
        }

       public  async void LoadDataAsync(string url)
        {
            var request = WebRequest.Create(url);
            string _response = string.Empty;
            using (var response = await request.GetResponseAsync())
            {
                var stream = response.GetResponseStream();
                using (var reader = new StreamReader(stream))
                {
                    _response = reader.ReadToEnd();
                }
            }
        }

       public void LoadDataAsync1(string url)
       {
           using (var client = new WebClient())
           {
               client.DownloadStringAsync(new Uri(url));
           }
       }

       public void SendEmailToQueue(TestEmailModel emailModel)
       {
           string Data = "";

           try
           {
               // serailze model object to json string
               DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(TestEmailModel));
               MemoryStream mem = new MemoryStream();
               ser.WriteObject(mem, emailModel);
               Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

               // process the request and get response as string http://sms.punjab.gov.pk/email/EmailService.svc/SendEmail
               //string serviceURL = ConfigurationHelper.EmailPath;// "http://sms.punjab.gov.pk/email/EmailService.svc/SendEmail";
               //string serviceURL = "http://localhost:56178/EmailService.svc/SendEmail";
               string serviceURL = "https://emailapi.punjab.gov.pk/EmailService.svc/SendEmail";
               //string serviceURL = "http://sms.punjab.gov.pk/email/EmailService.svc/SendEmail";
               //string serviceURL = "https://sms.punjab.gov.pk/tsemailapi/api/email/sendemail";
               
               WebClient webClient = new WebClient();
               webClient.Headers["Content-type"] = "application/json";
               //webClient.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
               webClient.Encoding = Encoding.UTF8;

               Uri address = new Uri(serviceURL);
               webClient.UploadString(address, "POST", Data);
               //webClient.UploadString(address, "POST", null);
           }
           catch (Exception ex)
           {
               Console.Write(ex.Message);
               Console.Read();
               //Console.Write(ex.InnerException.Message);
               //Console.Read();
              // LazySingletonBLL<CommonBLL>.Instance.AddApplicationErrorLog(new ErrorLogModel(ex, "SendEmailToQueue", 0, "CommonUI"));
           }
       }

       public void MailSend(TestEmailModel emailModel)
       {
           try
           {

               string Sender = "e-reports.support@pfsa.gop.pk";//"e-reports-pfsa@punjab.gov.pk"; //"support@punjab.gov.pk";
               string SenderPassword = "punjab123"; //"pitb@123";   // ConfigurationManager.AppSettings["EMailSenderPassword"].ToString();
               string MailServer = "103.226.216.248"; //"119.159.229.231";  //     "10.20.24.159";         // ConfigurationManager.AppSettings["SMTPServer"].ToString();
                
               /*
               string Sender = "e-reports.support@pfsa.gop.pk"; //"support@punjab.gov.pk";
               string SenderPassword = "punjab123"; //"pitb@123";   // ConfigurationManager.AppSettings["EMailSenderPassword"].ToString();
               string MailServer = "221.120.210.110"; //"119.159.229.231";  //             // ConfigurationManager.AppSettings["SMTPServer"].ToString();
              */
               int MailServerPort = 25;            // Convert.ToInt16(ConfigurationManager.AppSettings["SMTPServerPort"].ToString());
               bool EnableSSL = false;                 // Convert.ToBoolean(ConfigurationManager.AppSettings["SMTPEnableSSL"].ToString().ToLower());


               MailMessage mM = new MailMessage();

               mM.From = new MailAddress(Sender);  // set email sender
               if (emailModel.ToEmailAddresses != null && emailModel.ToEmailAddresses.Count > 0)
               {
                   foreach (string emailAdd in emailModel.ToEmailAddresses)
                   {
                       mM.To.Add(emailAdd);
                   }

               }

               // set receiver email

               if (emailModel.CCEamilAddresses != null && emailModel.CCEamilAddresses.Count > 0)
               {
                   foreach (string emailAdd in emailModel.CCEamilAddresses)
                   {
                       mM.CC.Add(emailAdd);
                   }

               }

               if (emailModel.BCEmailAddresses != null && emailModel.BCEmailAddresses.Count > 0)
               {
                   foreach (string emailAdd in emailModel.BCEmailAddresses)
                   {
                       mM.Bcc.Add(emailAdd);
                   }

               }




               mM.Subject = emailModel.Subject;   // set email subject
               mM.Body = emailModel.Body;         // set email body
               mM.IsBodyHtml = true;

               // open smtp client 
               SmtpClient Server = new SmtpClient(MailServer, MailServerPort);
               Server.UseDefaultCredentials = true;
               Server.Credentials = new System.Net.NetworkCredential(Sender, SenderPassword);
               Server.Port = MailServerPort;   // set port number
               Server.Host = MailServer;
               Server.EnableSsl = EnableSSL;
               Server.DeliveryMethod = SmtpDeliveryMethod.Network;

               //Added this to bypass the certificate validation
               ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
               Server.Send(mM);    // send email

               mM.Dispose();



           }
           catch (Exception ex)
           {
               Console.WriteLine(ex.Message);
               Console.Read();
               Environment.Exit(0);
               throw ex;
             

           }
       }
       public void MailSend(string Receiver, string Subject, string Body)
       {
           try
           {
               string Sender = "support@punjab.gov.pk";
               string SenderPassword = "pitb@123";
               string MailServer = "10.20.24.159";
               int MailServerPort = 25;
               bool EnableSSL = false;

               MailMessage mM = new MailMessage();

               mM.From = new MailAddress(Sender);  // set email sender
               mM.To.Add(Receiver);    // set receiver email
               mM.Subject = Subject;   // set email subject
               mM.Body = Body;         // set email body
               mM.IsBodyHtml = true;

               // open smtp client 
               SmtpClient Server = new SmtpClient(MailServer, MailServerPort);
               Server.UseDefaultCredentials = true;
               Server.Credentials = new System.Net.NetworkCredential(Sender, SenderPassword);
               Server.Port = MailServerPort;   // set port number
               Server.Host = MailServer;
               Server.EnableSsl = EnableSSL;
               Server.DeliveryMethod = SmtpDeliveryMethod.Network;

               //Added this to bypass the certificate validation
               ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
               Server.Send(mM);    // send email

               mM.Dispose();
           }
           catch (Exception ex)
           {
              
           }
       }
       public void MailSend(string subject, string body)
       {
           Console.WriteLine("Send Email From Webconfig");
          
           try
           {
               string Sender = ConfigurationHelper.EMailSenderAddress;
               string SenderPassword = ConfigurationHelper.EMailSenderPassword;    // ConfigurationManager.AppSettings["EMailSenderPassword"].ToString();
               string MailServer = ConfigurationHelper.SMTPServer;                 // ConfigurationManager.AppSettings["SMTPServer"].ToString();
               int MailServerPort = ConfigurationHelper.SMTPServerPort;            // Convert.ToInt16(ConfigurationManager.AppSettings["SMTPServerPort"].ToString());
               bool EnableSSL = ConfigurationHelper.SMTPEnableSSL;                 // Convert.ToBoolean(ConfigurationManager.AppSettings["SMTPEnableSSL"].ToString().ToLower());
               bool EnableEmail = ConfigurationHelper.EnableEMailNotification;     // Convert.ToBoolean(ConfigurationManager.AppSettings["EnableEMailNotification"].ToString().ToLower());

               if (EnableEmail)
               {
                   MailMessage mM = new MailMessage();

                   mM.From = new MailAddress(Sender);  // set email sender
                   if (!string.IsNullOrEmpty(ConfigurationHelper.SendToEmailAddress))
                   {
                       string[] receiverEmailAddresses = ConfigurationHelper.SendToEmailAddress.Split('^');
                       for (int i = 0; i < receiverEmailAddresses.Length; i++)
                       {
                           mM.To.Add(receiverEmailAddresses[i]);
                       }
                   }

                   // set receiver email
                   if (!string.IsNullOrEmpty(ConfigurationHelper.TOCC_EmailAddress))
                   {
                       string[] emailAddresses = ConfigurationHelper.TOCC_EmailAddress.Split('^');
                       for (int i = 0; i < emailAddresses.Length; i++)
                       {
                           mM.CC.Add(emailAddresses[i]);
                       }
                   }

                   if (!string.IsNullOrEmpty(ConfigurationHelper.TOBC_EmailAddress))
                   {
                       string[] emailAddresses = ConfigurationHelper.TOBC_EmailAddress.Split('^');
                       for (int i = 0; i < emailAddresses.Length; i++)
                       {
                           mM.Bcc.Add(emailAddresses[i]);
                       }
                   }

                   mM.Subject = subject;   // set email subject
                   mM.Body = body;         // set email body
                   mM.IsBodyHtml = true;

                   // open smtp client 
                   SmtpClient Server = new SmtpClient(MailServer, MailServerPort);
                   Server.UseDefaultCredentials = true;
                   Server.Credentials = new System.Net.NetworkCredential(Sender, SenderPassword);
                   Server.Port = MailServerPort;   // set port number
                   Server.Host = MailServer;
                   Server.EnableSsl = EnableSSL;
                   Server.DeliveryMethod = SmtpDeliveryMethod.Network;

                   //Added this to bypass the certificate validation
                   ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                   Server.Send(mM);    // send email

                   mM.Dispose();

                   // TestEmail();
               }
               else
               {
                   Console.WriteLine("Email is not enable");
                   Console.Read();
               }
           }
           catch (Exception ex)
           {
               Console.WriteLine(ex.Message);
               Console.Read();
               Environment.Exit(0);
               throw ex;
              // B2BayLogger.LogErr("Error", ex);
           }
       }
        /*
       private ThirdParyResponseModel SendReponseToThirdPary(CustomerResponseModel customerResponseModel)
       {
           B2BayLogger.Log("Call Method SendReponseToThirdPary");

           string result = string.Empty;
           ThirdParyResponseModel thirdParyResponse = new ThirdParyResponseModel();

           ResponseModel responseModel = new ResponseModel();
           responseModel.ReplyMessage = customerResponseModel.ReplyMessage;
           responseModel.ReplyPhoneNumber = customerResponseModel.ReplyPhoneNo;
           responseModel.ResponseDate = DateTime.Now.ToString(); //"22-11-2015 13:10:40";
           responseModel.ShortCode = customerResponseModel.ShortCode;
           responseModel.ID = Convert.ToString(customerResponseModel.ID);
           B2BayLogger.WriteLogsToFile();

           string strDataMoedel = "";
           try
           {
               DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(ResponseModel));
               MemoryStream mem = new MemoryStream();
               ser.WriteObject(mem, responseModel);
               strDataMoedel = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

               //WebOperationContext.Current.OutgoingResponse.Headers.Add("data", Data);
           }
           catch (Exception ex)
           {
               throw new Exception("Data contract serializer exception : " + ex.Message);
           }


           // process the request and get response as string
           string ServiceURL = customerResponseModel.ServiceUrl;

           WebClient webClient = new WebClient();

           try
           {
               webClient.Headers["Content-type"] = "application/json";
               webClient.Encoding = Encoding.UTF8;
               webClient.Headers["datatype"] = "json";
           }
           catch (Exception ex)
           {
               throw new Exception("Web client exception : " + ex.Message);
           }


           try
           {

               Uri address = new Uri(ServiceURL + "/" + customerResponseModel.MethodName);
               result = webClient.UploadString(address, "POST", strDataMoedel);
           }
           catch (Exception ex)
           {

               throw new Exception("Service connectivity exception : " + ex.Message);
           }

           ResponseModel resultModel = null;
           try
           {

               resultModel = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ResponseModel>(result);
           }
           catch (Exception ex)
           {
               B2BayLogger.Log("Respone Form ThirdParty" + result + "" + ex.Message);
               throw new Exception("Invalid respone Form ThirdParty : " + ex.Message);
           }
           thirdParyResponse.Response = resultModel;
           thirdParyResponse.Result = result;
           return thirdParyResponse;
       }
        */
    }
}
