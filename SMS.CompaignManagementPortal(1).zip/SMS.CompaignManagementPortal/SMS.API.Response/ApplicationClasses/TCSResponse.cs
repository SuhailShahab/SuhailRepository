﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.API.Response.ApplicationClasses
{
    //[System.Runtime.Serialization.DataContract(Namespace = "System.Runtime.Serialization")]
    public class TCSResponse
    {
      [System.Runtime.Serialization.DataMember(Name = "CNSG_NO")]
        public string CNSG_NO { get; set; }
      [System.Runtime.Serialization.DataMember(Name = "DLVRY_DAT")]
      public string DLVRY_DAT { get; set; }
      [System.Runtime.Serialization.DataMember(Name = "DLVRY_TIM")]
       public string  DLVRY_TIM { get; set; }
      [System.Runtime.Serialization.DataMember(Name = "RCVD_BY")]
      public string RCVD_BY { get; set; }
      [System.Runtime.Serialization.DataMember(Name = "DSCRP")]
      public string DSCRP { get; set; }

    }

    // [System.Runtime.Serialization.DataContract(Namespace = "System.Runtime.Serialization")]
   [System.Runtime.Serialization.DataContract(Namespace = "System.Runtime.Serialization")]
   // [System.SerializableAttribute()]
    //[System.Diagnostics.DebuggerStepThroughAttribute()]
   // [System.ComponentModel.DesignerCategoryAttribute("data")]
    //[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    //[System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public class TCS
    {
        [System.Runtime.Serialization.DataMember(Name = "data")]
       public string  data { get; set; }

        [System.Runtime.Serialization.DataMember(Name = "success")]
        public bool success { get; set; }

        //[JsonProperty("data")]
        //public string Data { get; set; }

        //[JsonProperty("success")]
        //public bool Success { get; set; }
         
    }
}
