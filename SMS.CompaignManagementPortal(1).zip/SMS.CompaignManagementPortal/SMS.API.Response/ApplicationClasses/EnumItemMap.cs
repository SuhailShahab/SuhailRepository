﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.API.Response.ApplicationClasses
{
   public  class EnumItemMap
    {
        /*
     * Given an enum, construct a map where the keys are the enum items
     * and the values are string descriptions of each item. Example:
     *
     * {TheFirst, "The First"},
     * {TheSecond, "The Second"},
     * {AndTheLast, "And The Last"},
     *
     * Thus each enum item is converted to text and split at each capital letter.
     */
        public static Dictionary<T, string> Build<T>() where T : struct, IConvertible
        {
            if (!typeof(T).IsEnum)
            {
                throw new ArgumentException
                  ("Error: EnumItemMap.Build<T>() => T must be an enumerated type");
            }

            Dictionary<T, string> map = new Dictionary<T, string>();
            var values = Enum.GetValues(typeof(T));
            foreach (var item in values)
            {
                var r = new System.Text.RegularExpressions.Regex(
                    @"(?<=[^A-Z])(?=[A-Z]) | (?=[A-Z][^A-Z])",
                    System.Text.RegularExpressions.RegexOptions.IgnorePatternWhitespace);

                map[(T)item] = r.Replace(item.ToString(), " ");
            }
            return map;
        }

    }
}
