﻿using SMS.API.Response.ApplicationClasses;
using SMS.API.Response.ApplicationClasses.Log;
using SMS.CMPService.ApplicationClassess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TS.Model.Emails;

namespace SMS.API.Response
{
    class Program
    {
        static void Main(string[] args)
        {
           // SMS.API.Response.ApplicationClasses.TestResponse obj123 = new SMS.API.Response.ApplicationClasses.TestResponse();
           //  obj123.SendGIS("http://web.urbanunit.gov.pk/smdp/DataReceive?username=smdp&password=smdp@uu&gsno=5492&scheme_id=01051700179&scheme_name=Construction of  Building for the office of District Public Prosecutor  Layyah&cost=11842000&district=Layyah&lat=30.983174&long=70.965065&sector=Infrastructure Development&sub_sector=Public Buildings");
            //obj123.LoadDataAsync("http://web.urbanunit.gov.pk/smdp/DataReceive?username=smdp&password=smdp@uu&gsno=5492&scheme_id=01051700179&scheme_name=Construction of  Building for the office of District Public Prosecutor  Layyah&cost=11842000&district=Layyah&lat=30.983174&long=70.965065&sector=Infrastructure Development&sub_sector=Public Buildings");
            //  TestResponse.SendSMS();
            //DayOfWeek
            //string st1 = "2017-10-14 12:01:22.100";
            //DateTime dt1 = Convert.ToDateTime(st1);
            //DateTime dt2 = Convert.ToDateTime("2017-10-14 11:59:03.777");

            //string d1 = dt1.DayOfWeek.ToString();
            //string d2 = dt2.DayOfWeek.ToString();

            //Testing of Third Party Method

            //============= Send SMS==========================

            SMS.CMP.BE.APIClasses.CustomerResponseModel obj = new CMP.BE.APIClasses.CustomerResponseModel();
            obj.ReplyMessage = "6ABFD44B5AE7BB09";
           
           // obj.ReplyMessage = "character";
          //  obj.ReplyMessage = "FCGRW-DL-020816-000006";
           // obj.ReplyMessage = "FCRWP-NIC-080317-000521";//for live



           // obj.ReplyPhoneNo = "03320754179";
           // obj.ShortCode = "9122";
           // obj.ID = 12;
          //  obj.ServiceUrl = "http://103.226.216.170:3000";//http://10.52.80.41/pitb-crm/index.php?entryPoint=CFMPPushIndoorSMS
          //  obj.ServiceUrl = "http://103.226.217.170/referral-system/sms";
          //  obj.ServiceUrl = "http://mlearn.punjab.gov.pk/webservice";
          //  obj.ServiceUrl = "http://10.20.24.151:8090/PITBFacilitationCentreService.svc";
          //  obj.ServiceUrl = "http://localhost:55176/PITBFacilitationCentreService.svc";
           // obj.ServiceUrl = "http://crm.ccc.pitb.gov.pk/pitb-crm";
            // obj.ServiceUrl = "http://fcd.fc.punjab.gov.pk:8090/PITBFacilitationCentreService.svc";
           // obj.ServiceUrl = "http://tracking.punjab.gov.pk/ajax";
            //obj.ServiceUrl = "http://localhost:55176/PITBFacilitationCentreService.svc";
            //obj.ServiceUrl = "http://crm.ccc.pitb.gov.pk/pitb-crm";
           // obj.MethodName = "index.php?entryPoint=TEVTAPushFeedback";

            //obj.MethodName = "post-message";
            //obj.MethodName = "GetCenterLocation";
            //obj.MethodName = "save_gp_sms.js";
            //obj.MethodName = "GetApplicatoinStatusInfo";
            //obj.MethodName = "index.php?entryPoint=ExcisePushIndoorSMS";

            obj.ServiceUrl = "http://103.111.161.97/eStampServices/api/Stamp";
        //http://103.111.161.97/eStampServices/api/Stamp/SendStampSMSKPModel 
            obj.MethodName = "SendStampSMSKPModel";
            TestResponse.SendReponseToThirdPary(obj);
            
            //============= END ==========================

            // TestResponse Test = new TestResponse();
            // Task<string> abc = obj.SendSmsToClient("http://localhost:62161/PortalService.svc/SendBulkSMS");
            //abc= obj.SendSmsToClient("http://localhost:62161/PortalService.svc/SendBulkSMS");
            //Task<string> abc= TestResponse.SendSmsToClient("http://localhost:62161/PortalService.svc/SendBulkSMS");

            // obj.SendSmsToClient1("http://localhost:62161/PortalService.svc/SendBulkSMS");
            // obj.LoadDataAsync("http://localhost:62161/PortalService.svc/SendBulkSMS");
            // obj.LoadDataAsync1("http://localhost:62161/PortalService.svc/SendBulkSMS");
            // Test.LoadDataAsync1("http://10.20.24.70:7078/PortalService.svc/SendBulkSMS");
            // Test.SendSmsToClient1("http://10.20.24.154:7070/PortalService.svc/SendBulkSMS");
            //======================================================
            //TestResponse.GetTCSStatus();
            //Environment.Exit(0);
            //string applicationName = AppDomain.CurrentDomain.SetupInformation.ApplicationName;

            //try
            //{
            //    B2BayLogger.WriteLogsToFile();

            //    bool IsNewApplciationExecute = CommonHelper.IsNewApplciationRunning(applicationName);

            //    if (IsNewApplciationExecute)
            //    {
            //        new MainThread().StartThread();
            //        Console.Read();
            //    }
            //    else
            //    {
            //        B2BayLogger.Log("Applicaton already running.");
            //        Console.WriteLine("Applicaton already running.");
            //        B2BayLogger.WriteLogsToFile();
            //        Environment.Exit(0);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    B2BayLogger.LogErr("There is some error.Please detail.", ex);
            //    B2BayLogger.WriteLogsToFile();

            //    if (ConfigurationHelper.EnableEMailNotification)
            //        CommonHelper.SendNotificationEmail(ex.Message);
            //}
            
            //==== passwork Encription=================
        //http://smsapi.punjab.gov.pk/CMPService.svc/SMSByTelcoCode/NzI0/Mg==/en/
            //string psw = "MTIz";
           // string psw = "Njcw"; 670
            //string psw = "NzA0";
            //string psw = "Mg==";
           // string psw = "NTk1"; //15-CMP-DIGOperationLahore(cmp)
          //  string psw = "89";//"Y21wQDE1";//3-CMP-PunjabPolice(Org);
           // string data1 = CustomSecurity.EncodePasswordToBase64(psw);
            // string data = CustomSecurity.DecodeFrom64(psw);
            /* 
             //Test Email
             EmailModel email = new EmailModel();
             TestResponse.TestForSendingEmail(email);
             */
          //  Console.Read();
           // Environment.Exit(0);
             
            //==== END=================

            //==== passwork Decode=================
             //string psw = "c3VwZXJ1c2VyMQ==";
            //string psw = "MTU=";
            // string psw = "NA==";
            //string psw = "Mg==";
           // string psw = "cmp@15"; //15-CMP-DIGOperationLahore(cmp)
            //string psw = "Mw==";//3-CMP-PunjabPolice(Org);
            //string data = CustomSecurity.DecodeFrom64(psw);
           // string data = CustomSecurity.EncodePasswordToBase64(psw);
            //Console.Read();
            //Environment.Exit(0);

            //==== END=================
            //===========Send Email ==========================
            
          //  TestResponse.TestForSendingEmail(new TS.Model.Emails.EmailModel());
            //Email testing
            
            //string subject = "Test for Shahab";
            //string body = "Testing 300 ";
            //TestEmailModel em = new TestEmailModel(subject, body.ToString());
            //em.ToEmailAddresses.Add("shahabsohail@hotmail.com");
           // em.ToEmailAddresses.Add("sohail.shahab@pitb.gov.pk");
            //em.ToEmailAddresses.Add("muhammad.hammad@punjab.gov.pk");
            //em.ToEmailAddresses.Add("aqeel.zia@punjab.gov.pk");
           


           // TestResponse testObj = new TestResponse();
            // testObj.SendEmailToQueue(em);
             
           // testObj.MailSend(em);
          // testObj.MailSend(subject, body);
           // Console.WriteLine("Email Successfully");
           // Console.Read();
           // Environment.Exit(0);
            
            // testObj.MailSend("sohail.shahab@pitb.gov.pk", "Test 002", "Test 003");
            //===========END ==========================
            
            //Test for dynamic properties
            /*
            var values = new Dictionary<string, object>();
            values.Add("Title", "Hello World!");
            values.Add("Text", "My first post");
            values.Add("Tags", new[] { "hello", "world" });

            var post = new DynamicEntity(values);

            dynamic dynPost = post;
            var text = dynPost.Text;
             * */
            //}

            //Testing of Enumration convert enum to string
            /*
            DataType item = DataType.DateOfBirth;
            var r = new System.Text.RegularExpressions.Regex(@"(?<=[^A-Z])(?=[A-Z]) | 
            (?=[A-Z][^A-Z])", System.Text.RegularExpressions.RegexOptions.IgnorePatternWhitespace);
            string description = r.Replace(item.ToString(), " ");

            Dictionary<DataType, string> mapDataType = EnumItemMap.Build<DataType>();
             description = mapDataType[DataType.FirstName];
             */
            //=================End=============================
            //string values = "{\"BCEmailAddresses\":null,\"Body\":\"Dear Sir\\/Madam, an application for LGCD Residential Building Plan against Tracking ID: FCSGD-RBG-250321-000534 dated: 25-Mar-2021 05:11 PM at Sargodha Center is received. Warm Regards, Manager e-Khidmat ( Sargodha )\",\"CCEamilAddresses\":null,\"Mode\":0,\"SenderEmail\":null,\"Subject\":\"An Application is received at E-Khidmat Markaz for Residential Buildings.\u000a\",\"ToEmailAddresses\":[\"hayat01@gmail.com\"]}";
            //if(!string.IsNullOrEmpty(values) && values.Contains("\u000a"))
            //{
            //string resutl = values.Replace("\u000a", "");
            //Console.Read();
            //if (!resutl.Contains("\u000a"))
            //Console.Write(resutl);
            //Console.Read();
            //}

          //  TestResponse.SendSMS();

        }

    }
}