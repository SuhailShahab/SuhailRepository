﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CustomEnums
{
    /// <summary>
    /// Buffer Status Enumeration
    /// </summary>
   public  enum  BufferStatusNames
    {
       SendToSMSC=17, /// send SMS To SMSC

       AddToBuffer=99, // Add to Buffer
       SelectFromBuffer = 100, // Select sms from Buffer
       SendToCustomer =101, /// Send to Customer
       
       SomeError=102 /// Some error during senging SMS
       

    }
}
