﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CustomEnums
{
  public   enum  RequestSourceName:int
    {
        None=0,
        WebAPI=1,
        Portal=2
    }
}
