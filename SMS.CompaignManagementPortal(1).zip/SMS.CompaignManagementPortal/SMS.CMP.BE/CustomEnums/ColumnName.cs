﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum ColumnName : byte
    {
        Title = 1,
        UserName = 2,
        CityID = 3,
        OrganizationID = 4,
        DepartmentID = 5, 
        MaskID = 6,
        ProvinceID = 7,
        DivisionID = 8,
        Code = 9,
        GroupID = 10,
        MenuName = 11,
        AppFeatureID = 12,
        StaticName = 13,
        AppObjectID = 14,
        SMSTypeID = 15,
        SortCodeID = 16,
        ID = 17,
        TempalteID  = 18,
        StatusID = 19,
        AddressBookID = 20,
        ContactID  =21,
        Phone = 22,
        TelcoPaymentID = 23,
        menuLocation = 24,
        ShortCodeID=25,
    }
}
