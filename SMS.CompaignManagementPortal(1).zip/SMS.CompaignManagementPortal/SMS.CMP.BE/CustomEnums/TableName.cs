﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum TableName : byte
    {
        tblUsers = 1,
        tblOrganizations = 2,
        tblAppFeatures = 3,
        tblDistricts = 4,
        tblDivisions = 5,
        tblEvidenceInformations = 6,
        tblProvinces = 7,
        tblMasks = 8,
        tblAddressBooks = 9,
        tblTelcoPaymentInformations = 10,
        tblStatuses = 11,
        tblDepartments = 12,
        tblGroups = 13,
        tblGroupRights = 14,
        tblAppObjects = 15,
        tblUserDistricts = 16,
        tblSMSTypes = 17,
        tblShortCodes = 18,
        tblSMSTemplates = 19,
        tblAddressBookContacts = 20,
        tblContacts = 21,
        tblDashboardGroupMenu = 22,
        tblBillingDepartment = 23
    }
}
