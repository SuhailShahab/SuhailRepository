﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public class CutomMessage
    {
        public const string InvalidUserRights = "You have not rights on this page.Please contact with administrator.";
        public const string InvalidRegisterUser = "User is not registered.Please contact with administrator.";
        public const string InvalidLogin = "Invalid password or login.";
        public const string InvalidUser = "You have enter invalid user";
        public const string DuplicateTitle = "Title already Exists";
        public const string SavedSuccessfully = "Record has been saved successfully";
        public const string ContactAssign = "Contact(s) assigned successfully";
        public const string DeletedSuccessfully = "Record has been deleted successfully";
        public const string BlockSuccessfully = "Record has been blocked successfully";
        public const string UserDistrictMissing = "User District is missing.";
        public const string MaskDuplication = "Mask already used in other Campaign.";
        public const string DuplicateIsOffnet = "Only one onNet and one offNet can be set against one Company";
        public const string ResentSMS = "SMS is re-sending from Queue";
        public const string InvoiceError = "Only first time Credit Mode can be enter";
    }
}
