﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CustomEnums
{
    public enum SMSDeliveryStatuses : int
    {
        /// ---------------------- SMSC Status   ----------------
        /// 
        DeliverySuccess = 1,
        DeliveryFailure = 2,
        DeliveredAndFailed = 3,
        MessageBuffered = 4,
        SMSCSubmit = 8,
        SMSCReject = 16,
        InValidPhoneNumber = 18,


        /// ---------------------- Buffer Status  ----------------

        AddToBuffer = 99, // Add to Buffer
        SelectFromBuffer = 100, // Select sms from Buffer
        SendToCustomer = 101,
        SendError = 102,
        SendToSMSC = 17,
    }
}
