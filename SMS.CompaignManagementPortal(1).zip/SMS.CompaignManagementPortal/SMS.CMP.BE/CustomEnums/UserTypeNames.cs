﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum UserTypeNames : int
    {
        
        Admin = 1,
        Customer = 2,
        CompetentAuthority = 3
    }
}
