﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public class PageNames
    {
        /// <summary>
        /// Value is MenuName for Table Feature table
        /// Value is StaticName for Table AppObjects
        /// Note Very Important
        ///Use values of MenuName for Feature table 
        ///Use values are StaticName for AppObjects
        /// </summary>
        public const string ApplicationFeature = "ApplicationFeature";
        public const string ApplicationObjects = "ApplicationObjects";
        public const string GroupPermission = "GroupPermission";
        public const string Users = "user";
        public const string EvidenceInformation = "EvidenceSubmision";
        public const string Division = "Division";
        public const string Home = "index";
        public const string Department = "Department";
        public const string Organization = "Organization";
        public const string SMSType = "SMSType";
        public const string Mask = "Mask";
        public const string Invoice = "Invoice";
        public const string FinalInvoice = "FinalInvoice";
        public const string AddressBook = "AddressBook";
        public const string SMS_CMPService = "CMPService";
        public const string SMS_PortalService = "PortalService";
        public const string SMS_QueueScheduler = "SMSQueueScheduler";
        public const string SMSCampaignsLog = "SMSCampaignLogs";
        public const string SMSApiLog = "SMSApiLogs";
        public const string ErrorLog = "ErrorLog";
        public const string Contact = "Contact";
        public const string SMSTemplate = "SMSTemplate";
        public const string Group = "Group";
        public const string Province = "Province";
        public const string ShortCode = "ShortCode";
        public const string Status = "Status";
        public const string Login = "Login";
        public const string SMSCampaign = "SMSCampaign";
        public const string SMSInbox = "SMSInbox";
        public const string SMSBufferLog = "SMSBufferLog";

        public const string SMSConfiguration = "SMSConfiguration";
        public const string PurchasedBucketsHistory = "PurchasedBucketsHistory";
        public const string PaymentReport = "PaymentReport";
        public const string SMSStatSummary = "SMSStatSummary";
        public const string ResetPassword = "ResetPassword";
        public const string SMSCampaignReport = "SMSCampaignReport";
        public const string APICampaignReport = "APICampaignReport";
        public const string SMSResponseReport = "SMSResponseReport";
        public const string TelcoPayment = "TelcoPayment";
        public const string TelcoPaymentInvoiceReport = "TelcoPaymentInvoiceReport";
        public const string SMSTransactionReport = "SMSTransactionReport";

        public const string SMSQueueReport = "SMSQueueReport"; /// Added By Sohail Kamran 30.11.2015
        public const string InvoiceLedgerReport = "InvoiceLedgerReport";  /// Added By Sohail Kamran 07.12.2015     
        public const string BulkSMS = "BulkSMS";  /// Added By Sohail Kamran 07.12.2015      
        public const string CompaignWiseStat = "CompaignWiseStat";  /// Added By sufyan ali 10.5.2017  
        public const string CampaignsPriority = "CampaignsPriority";
        public const string BillingDepartment = "BillingDepartment"; // Added By Shakeel 22-03-2018
    }

    public class ReportNames
    {


        public const string RptQueueReport = "RptQueuReport";
        public const string CampaignsPaymentReport = "RptPaymentReport";
        public const string SMSCampaignReport = "RptSMSCampaignReport";

        public const string APICampaignReport = "RptAPICampaignReport";
        public const string APICampaignReportSMS = "RptAPICampaignReportSMS";

        public const string RptTelcoPaymentInvoice = "RptTelcoPaymentInvoice";
        public const string SMSResponseReportSeriesWise = "RptSMSResponseReportSeriesWise";
        public const string SMSResponseReport = "RptSMSResponseReport";
        public const string TranSMSCampainStandardReport = "RptTranSMSCampainStandard";
        public const string TranAPIStandardReport = "RptTranAPIStandard";

        public const string TranSMSCampainExtentedReport = "RptTranSMSCampainExtented";
        public const string TranAPIExtentedReport = "RptTranAPIExtented";
        public const string TranSMSMatrixReport = "RptSMSTranMatrix";


        public const string PaymentInvoiceLedgerReport = "RptPaymentInvoiceLedger";

        public const string SMSTelcoStatSummary = "RptSMSStatSummary";

        public const string CompaignWiseStat = "RptCompaignWiseStat";
        public const string DepartmentWiseStat = "RptDepartmentWiseStat";
        public const string DepartmentWiseStatDetail = "RptDepartmentWiseStatDetail";
        public const string MonthWiseSMSStat = "RptMonthWiseSMSStat";
        public const string DepartmentWiseMonthlySMSStat = "RptDepartmentWiseMonthlySMSStat";

    }
}
