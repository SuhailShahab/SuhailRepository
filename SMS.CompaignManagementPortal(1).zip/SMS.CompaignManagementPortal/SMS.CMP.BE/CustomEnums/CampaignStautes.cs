﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CustomEnums
{
    /// <summary>
    /// Campaign Statues
    /// </summary>
    public enum CampaignStautes : int
    {
        InitiateCampaign = 1,
        UnderProcessing = 2,
        Processed = 3
    }
}
