﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CustomEnums
{
    public enum TelcoNames
    {
        Jazz = 1,
        Zong = 2,
        Warid = 3,
        Ufone = 4,
        Telenor = 5
    }
}
