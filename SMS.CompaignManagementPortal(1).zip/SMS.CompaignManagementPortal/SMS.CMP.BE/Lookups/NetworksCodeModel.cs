﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.Lookups
{

    [ClassMapping(TableName = "tblNetworksCode", Identifier = "NetworkCode")]
    [Serializable]

    public class NetworksCodeModel
    {
        [MappingInfo(ColumnName = "NetworkCode", IdentitySpecification = true)]
        public string NetworkCode { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "IsActive")]
        public bool? IsActive { get; set; }
        [MappingInfo(ColumnName = "TelcoID")]
        public int? TelcoID { get; set; }
        
    }
}
