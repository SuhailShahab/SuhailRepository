﻿
using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// Create by:	<Sohail Kamran>
// Create date: <12-01-2016 5:29 PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
//   SR#             Modified By            Modified Date/Time      Desription
// CR: 001          Sohail Kamran           12-01-2016 5:30 PM      Add PerSMSRate to existing model

// =================================================================================================================================

namespace BE.Lookups
{
    [ClassMapping(TableName = "tblDepartments", Identifier = "DepartmentID")]
    [Serializable]
    public class DepartmentsModel : BaseModel
    {
        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }
        [MappingInfo(ColumnName = "DepartmentID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int OrganizationID { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }
        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }
        [MappingInfo(ColumnName = "PerSMSRate")]
        public decimal? PerSMSRate { get; set; } //CR: 001
        [MappingInfo(ColumnName = "DistrictID", Transient = true)]
        public int? DistrictID { get; set; }

        public int? DivisionID { get; set; }
        [MappingInfo(ColumnName = "Department")]
        public string Department { get; set; }

        [MappingInfo(ColumnName = "Organization")]
        public string Organization { get; set; }

        [MappingInfo(ColumnName = "SMSLimit")]
        public int? SMSLimit { get; set; }
        [MappingInfo(ColumnName = "IsAllowedCampaingName")]
        public bool? IsAllowedCampaingName { get; set; }

        public DepartmentsModel() { }

        public DepartmentsModel(string Notification)
        {
            this.Notification = Notification;
        }

    }

    public class DepartmentsModelView : BaseModel
    {
        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> AllActiveDepartments { get; set; }
        public List<DepartmentsModel> Departments { get; set; }

        public DepartmentsModelView() { }

        public DepartmentsModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }


}
