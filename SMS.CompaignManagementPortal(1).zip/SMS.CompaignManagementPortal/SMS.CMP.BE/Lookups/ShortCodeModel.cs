﻿using BE.Common;
using BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.Lookups
{

    [ClassMapping(TableName = "tblShortCodes", Identifier = "SortCodeID")]
    [Serializable]

    public class ShortCodeModel : BaseModel
    {
        public ShortCodeModel()
        { 
        }
        public ShortCodeModel(int? ID)
        {
            this.ID = ID;
        }
        public ShortCodeModel(string Notification)
        {
            this.Notification = Notification;
        }

        [MappingInfo(ColumnName = "SortCodeID", IdentitySpecification = false)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }
        [MappingInfo(ColumnName = "IsActive")]
        public bool? IsActive { get; set; }

        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }
        //[MappingInfo(ColumnName = "CreatedBy")]
        //public int? CreatedBy { get; set; }
        //[MappingInfo(ColumnName = "ModifiedBy")]
        //public int? ModifiedBy { get; set; }

        [MappingInfo(ColumnName = "OrganizationTitle")]
        public string OrganizationTitle { get; set; }
        

    }

    public class ShortCodeModelView : BaseModel
    {
        public List<OrganizationModel> Organizations { get; set; }
        public List<ShortCodeModel> ShortCodes { get; set; }

        public ShortCodeModelView()
        { 
        }
        public ShortCodeModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }


}
