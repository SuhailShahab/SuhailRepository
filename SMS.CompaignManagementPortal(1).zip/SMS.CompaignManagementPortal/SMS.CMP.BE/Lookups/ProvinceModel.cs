﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Lookups
{
    public class ProvinceModel:BaseModel
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public bool IsActive { get; set; }

        public ProvinceModel()
        {

        }
        
        public ProvinceModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class ProvinceModelView : BaseModel
    {
        public List<ProvinceModel> Provinces { get; set; }

        public ProvinceModelView()
        {

        }

        public ProvinceModelView(string Notification)
        {
            this.Notification = Notification;
        }

    }
}
