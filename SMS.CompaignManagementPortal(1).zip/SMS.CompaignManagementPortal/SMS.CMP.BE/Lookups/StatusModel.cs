﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.LookUps
{

    // =================================================================================================================================
    // Create by:	<Sabeeh Goheer>
    // Create date: <16-10-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // =================================================================================================================================

    [ClassMapping(TableName = "tblStatuses", Identifier = "ID")]
    [Serializable]
    public class StatusModel:BaseModel
    {
        public StatusModel() { }

        public StatusModel(int? StatusID)
        {
            this.StatusID = StatusID;
        }
        [MappingInfo(ColumnName = "ID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "StatusID")]
        public int? StatusID { get; set; }
        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "IsActive")]
        public bool? IsActive { get; set; }
        [MappingInfo(ColumnName = "CreatedBy")]
        public int? CreatedBy { get; set; }
        [MappingInfo(ColumnName = "ModifiedBy")]
        public int? ModifiedBy { get; set; }

        public StatusModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class StatusModelView : BaseModel
    {
        public List<StatusModel> Statuses { get; set; }

        public StatusModelView()
        {

        }

        public StatusModelView(string Notification)
        {
            this.Notification = Notification;
        }

    }
}
