﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.Lookups
{
    [ClassMapping(TableName = "tblSMSDeliveryStatus", Identifier = "DeliveryStatusID")]
    [Serializable]
    public class SMSDeliveryStatusModel
    {
        public SMSDeliveryStatusModel() { }

        public SMSDeliveryStatusModel(int? DeliveryStatusID)
        {
            this.ID = DeliveryStatusID;
        }

        [MappingInfo(ColumnName = "DeliveryStatusID", IdentitySpecification = true)]
        public int? ID { get; set; }

    
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
    
    }
}
