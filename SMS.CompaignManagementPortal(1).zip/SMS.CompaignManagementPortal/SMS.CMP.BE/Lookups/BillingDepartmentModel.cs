﻿
using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Created by:	<Muhammad Shakeel>
// Created date: <22-03-2018>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
//   SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================

namespace BE.Lookups
{
    [ClassMapping(TableName = "tblBillingDepartment", Identifier = "BillingDptID")]
    [Serializable]
    public class BillingDepartmentModel : BaseModel
    {
        [MappingInfo(ColumnName = "BillingDptID")]
        public int? BillingDptID { get; set; }
        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }

        public BillingDepartmentModel() { }

        public BillingDepartmentModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class BillingDepartmentModelView : BaseModel
    {
        public List<DepartmentsModel> Departments { get; set; }
        public List<DepartmentsModel> DepartmentsByBilling { get; set; }
        //public List<BillingDepartmentModel> BillingDepartments { get; set; }


        public BillingDepartmentModelView() { }

        public BillingDepartmentModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
