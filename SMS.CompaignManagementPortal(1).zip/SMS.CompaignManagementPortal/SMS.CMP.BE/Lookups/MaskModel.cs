﻿using BE.Common;
using BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.Lookups
{

    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <16-10-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // =================================================================================================================================

    [ClassMapping(TableName = "tblMasks", Identifier = "ID")]
    [Serializable]
    public class MaskModel : BaseModel
    {
        [MappingInfo(ColumnName = "MaskID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "SortCodeID")]
        public int? SortCodeID { get; set; }
        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "CreatedBy")]
        public int? CreatedBy { get; set; }
        [MappingInfo(ColumnName = "ModifiedBy")]
        public int? ModifiedBy { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }
        [MappingInfo(ColumnName = "ShortCode")]
        public string ShortCode { get; set; }
        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }
        [MappingInfo(ColumnName = "Department")]
        public string Department { get; set; }
        [MappingInfo(ColumnName = "Organization")]
        public string Organization { get; set; }

        public MaskModel()
        {

        }

        public MaskModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class MaskModelView : BaseModel
    {
        public List<MaskModel> Masks { get; set; }
        public List<OrganizationModel> Organizations { get; set; }
        public List<ShortCodeModel> ShortCodes { get; set; }
        public List<DepartmentsModel> Departments { get; set; }

        public MaskModelView()
        {

        }

        public MaskModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
