﻿
using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:01AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblOrganization", Identifier = "OrganizationID")]
    [Serializable]
    public class OrganizationModel : BaseModel
    {
        [MappingInfo(ColumnName = "OrganizationID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        public OrganizationModel()
        {

        }
        
        public OrganizationModel(string Notification)
        {
            this.Notification = Notification;
        }
       
    }

    public class OrganizationModelView : BaseModel
    {
        public List<OrganizationModel> Organizations { get; set; }

        public OrganizationModelView()
        {

        }

        public OrganizationModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
