﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.Lookups
{
    [ClassMapping(TableName = "tblProcessingStatuses", Identifier = "ProcessingStatusID")]
    [Serializable]
    public class ProcessingStatusModel
    {
        public ProcessingStatusModel() { }


        [MappingInfo(ColumnName = "ProcessingStatusID", IdentitySpecification = true)]
        public int? ProcessingStatusID { get; set; }


        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
    
    }
}
