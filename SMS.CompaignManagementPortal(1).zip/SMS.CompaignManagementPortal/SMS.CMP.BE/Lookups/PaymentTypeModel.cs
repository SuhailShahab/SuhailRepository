﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.Lookups
{
    [ClassMapping(TableName = "PaymentType", Identifier = "ID")]
    [Serializable]
    public class PaymentTypeModel
    {
         public  PaymentTypeModel() { }

         public PaymentTypeModel(int? PaymentTypeID)
        {
            this.ID = PaymentTypeID;
        }

        [MappingInfo(ColumnName = "ID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "PerSMSRate")]
        public decimal PerSMSRate { get; set; }
        [MappingInfo(ColumnName = "IsActive")]
        public bool? IsActive { get; set; }
        [MappingInfo(ColumnName = "CreatedBy")]
        public int? CreatedBy { get; set; }
        [MappingInfo(ColumnName = "ModifiedBy")]
        public int? ModifiedBy { get; set; }
    }
}
