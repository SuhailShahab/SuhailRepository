﻿using BE.Common;
using BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.CMP.BE.CMP;

namespace SMS.CMP.BE.Dashboard
{
    [ClassMapping(TableName = "tblDashboardItems")]
    [Serializable]
    public class DashboardModel
    {

        [MappingInfo(ColumnName = "Counts")]
        public int? Counts { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "URL")]
        public string URL { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }
        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }
        [MappingInfo(ColumnName = "Icon")]
        public string Icon { get; set; }
        [MappingInfo(ColumnName = "Style")]
        public string Style { get; set; }
        [MappingInfo(ColumnName = "RowNo")]
        public int? RowNo { get; set; }
        [MappingInfo(ColumnName = "UserID")]
        public int? UserID { get; set; }
        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }
    }

    public class DashboardViewModel : BaseModel
    {
        public List<DashboardModel> Dashboard { get; set; }
        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<SMSCampaignModel> Campaigns { get; set; }
        public int? UserOrganizationID { get; set; }
        public int? UserDepartmentID { get; set; }
        public DashboardViewModel()
        { 
        }
        public DashboardViewModel(string Notification)
        {
            this.Notification = Notification;
        }
    }
        
}
