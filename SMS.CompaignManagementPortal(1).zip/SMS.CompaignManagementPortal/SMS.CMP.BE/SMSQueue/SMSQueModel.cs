﻿using BE.Common;
using BE.Lookups;
using BE.RightsManager;
using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.SMSQueue
{

    /// <summary>
    /// SMS Que Model
    /// 
    /// </summary>
    /// 
    [ClassMapping(TableName = "tblSMSQueue", Identifier = "SMSQueueID")]
    [Serializable]
    public class SMSQueueModel : BaseModel
    {
        [MappingInfo(ColumnName = "SMSQueueID", IdentitySpecification = false)]
        public int ? ID { get; set; } 

        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }

        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }

        [MappingInfo(ColumnName = "SMSSendingID")]    
        public int ? SMSSendingID{ get; set; }

        [MappingInfo(ColumnName = "Phone")]    
        public string Phone { get; set; }

        [MappingInfo(ColumnName = "ContactNo")]
        public string ContactNo { get; set; }
        
        [MappingInfo(ColumnName = "ShortCode")]    
        public string ShortCode { get; set; }

        [MappingInfo(ColumnName = "SendMessage")]   
        public string SendMessage { get; set; }

        [MappingInfo(ColumnName = "IsSend")]
        public int? IsSend { get; set; }

        [MappingInfo(ColumnName = "Mode")]    
        public int? Mode { get; set; }

        [MappingInfo(ColumnName = "DeliveryStatusID")]
        public int? DeliveryStatusID { get; set; }
        
        /// Added New Model Fields
        [MappingInfo(ColumnName = "SMSGateway")]
        public string SMSGateway { get; set; }

        [MappingInfo(ColumnName = "UserName")]
        public string UserName { get; set; }

        [MappingInfo(ColumnName = "Password")]
        public string Password { get; set; }

        [MappingInfo(ColumnName = "TelcoID")]
        public int? TelcoID { get; set; }

        [MappingInfo(ColumnName = "IsOnNet")]
        public bool? IsOnNet { get; set; }

        //[MappingInfo(ColumnName = "NetworkTypeCode")]
        //public string NetworkTypeCode { get; set; }

        [MappingInfo(ColumnName = "SMSTransactionID")]
        public int? SMSTransactionID { get; set; }

        [MappingInfo(ColumnName = "SMSSendingStatus")]
        public string SMSSendingStatus { get; set; }

        [MappingInfo(ColumnName = "ContactID")]
        public int? ContactID { get; set; }

        [MappingInfo(ColumnName = "ResponseID")]
        public int? ResponseID { get; set; }

        [MappingInfo(ColumnName = "PriorityID")]
        public int? PriorityID { get; set; }

        [MappingInfo(ColumnName = "RESULT_COUNT"), MappingInfo(Transient = true)]
        public int? RESULT_COUNT { get; set; }

        [MappingInfo(ColumnName = "Lang")]
        public string Lang { get; set; }

        [MappingInfo(ColumnName = "NoOfSMS")]
        public int? NoOfSMS { get; set; }
    
    }

     public class SMSQueueViewModel : BaseModel
    {
        public List<SMSCampaignModel> SMSCampaigns { get; set; }
        public List<SMSQueueModel> SMSQueues { get; set; }
        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public UserModel User { get; set; }

        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }
    }
}

