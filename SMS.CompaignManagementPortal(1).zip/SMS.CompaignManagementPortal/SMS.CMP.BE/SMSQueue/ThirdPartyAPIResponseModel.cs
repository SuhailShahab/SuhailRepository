﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// =================================================================================================================================
// Create by:	<sohail Shahab>
// Create date: <10-12-2015 08:59 AM>
// Manage the Third Party API Telnor Reposne
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
namespace SMS.CMP.BE.SMSQueue
{
    [ClassMapping(TableName = "tblThirdPartyAPIResponse", Identifier = "ThirdPartyAPIResponseID")]
    [Serializable]
    public class ThirdPartyAPIResponseModel
    {
        [MappingInfo(ColumnName = "ThirdPartyAPIResponseID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "SMSSendingID")]
        public string SMSSendingID { get; set; }

        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }

        [MappingInfo(ColumnName = "MessageID")]
        public string MessageID { get; set; }

        [MappingInfo(ColumnName = "StatusID")]
        public int? StatusID { get; set; }

        [MappingInfo(ColumnName = "PhoneNo")]
        public string PhoneNo { get; set; }

        [MappingInfo(ColumnName = "XMLResponse")]
        public string XMLResponse { get; set; }

        [MappingInfo(ColumnName = "TelcoID")]
        public int? TelcoID { get; set; }

    }
}
