﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CustomExcetion.APIExcetion
{
    public class InvalidPhoneNo : Exception
    {
        public string  ErrorCode { get; set; }
        public string ErroMessage { get; set; }
        public InvalidPhoneNo(string errorMessage)
        {
            this.ErroMessage = errorMessage;
        }

        public InvalidPhoneNo(string errorMessage,string errorCode)
        {
            this.ErroMessage = errorMessage;
            this.ErrorCode = errorCode;
        }
    }
}
