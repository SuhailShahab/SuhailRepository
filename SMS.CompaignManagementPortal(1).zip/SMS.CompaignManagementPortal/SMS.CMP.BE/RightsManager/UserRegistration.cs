﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time              Desription
//CR:001            SUHAIL SHAHAB                   11-6-2015                       Add Address Fields
//CR:002            Muhammad Usman                  30-6-2015                       Add Officiating User Rights Fields
//CR:003            Mudassir Iqbal                  23-5-2017                       Add UserSMSDeliveryStatus Fields
// =================================================================================================================================
namespace BE.RightsManager
{
    public class UserRegistration : UserRights
    {
        public DataTable UserDashboardMenu { get; set; }
        public DataTable UserDistricts { get; set; }
        public DataTable UserOrganizations { get; set; }
        public DataTable UserDepartments { get; set; }
        public DataTable UserShortCode { get; set; }
        public DateTime? JoinDate { get; set; }
        public DateTime? ResignDate { get; set; }
        public bool? EnforceRight { get; set; }
        public int? DepartmentID { get; set; }
        public string BlockReason { get; set; }
        public int? UserTypeID { get; set; }
        public int? GroupID { get; set; }
        public string CellNumber { get; set; }
        public string EMail { get; set; }
        public string CNIC { get; set; }
        public string EmployeeName { get; set; }
        public string LoginName { get; set; }
        public int? OrganizationID { get; set; }
        public int? GeneralDistrictID { get; set; }

        public int? UserID { get; set; }
        public int? AddressDivisionID { get; set; }
        public int? AddressDistrictID { get; set; }
        public bool? IsEnforceSMSBucked { get; set; }
        public string FullAddress { get; set; }

        public DataTable UserSMSDeliveryStatus { get; set; }

    }
}
