﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace BE.RightsManager
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <7/10/2014 1:04:04 AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class GroupModel : BaseModel
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        //public bool Status { get; set; }
        public GroupModel()
        { 
        }

        public GroupModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class GroupModelModelView : BaseModel
    {
        public List<GroupModel> Groups  { get; set; }
        public GroupModelModelView()
        { 
        }
       
        public GroupModelModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}