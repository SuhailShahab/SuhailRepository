﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <08-01-2015 05:04:07PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BE.RightsManager
{
    [ClassMapping(TableName = "tblUsers", Identifier = "UserID")]
    [Serializable]
    public class UserModel : ManageGroupBaseRight
    {
        [MappingInfo(ColumnName = "UserID", IdentitySpecification = true)]
        public int? UserID { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }
        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }
        [MappingInfo(ColumnName = "DistrictID")]
        public int? DistrictID { get; set; }
        [MappingInfo(ColumnName = "DistrictCode")]
        public string  DistrictCode { get; set; }
        [MappingInfo(ColumnName = "UserName")]
        public string UserName { get; set; }
        [MappingInfo(ColumnName = "EmployeeName")]
        public string EmployeeName { get; set; }
       
        [MappingInfo(ColumnName = "CNIC")]
        public string CNIC { get; set; }
        [MappingInfo(ColumnName = "EMail")]
        public string EMail { get; set; }
        [MappingInfo(ColumnName = "CellNumber")]
        public string CellNumber { get; set; }
        [MappingInfo(ColumnName = "UserTypeID")]
        public int? UserTypeID { get; set; }
        public bool IsActive { get; set; }
        [MappingInfo(ColumnName = "Url")]
        public string  Url { get; set; }
        [MappingInfo(ColumnName = "IsEnforceSMSBucked")]
        public bool? IsEnforceSMSBucked { get; set; } 
    }

    public class UserModelView
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string EmployeeName { get; set; }
        public string CNIC { get; set; }
        public string District { get; set; }
        public string CellNumber { get; set; }
        public string EMail { get; set; }
        public bool IsActive { get; set; }

        public int UserTypeID { get; set; }
    }
}
