﻿using BE.Common;
using BE.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.RightsManager
{
    public class ApplicationObjectsModel : BaseModel
    {
        public int ID { get; set; }
        public int AppFeatureID { get; set; }

        public string StaticName { get; set; }
        public string Name { get; set; }
        public string URL { get; set; }
        public string Description { get; set; }
        public bool HasChild { get; set; }
        public int Sort { get; set; }
        public string Icon { get; set; }
        //public DateTime CreatedDate { get; set; }
        //public DateTime ModificationDate { get; set; }

        public bool IsActive { get; set; }

        public ApplicationObjectsModel()
        {

        }

        public ApplicationObjectsModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    /// <summary>
    /// Application Objects View Model
    /// </summary>
    public class ApplicationObjectsModelView : BaseModel
    {
        public List<FeaturesModel> Features { get; set; }
        public List<ApplicationObjectsModel> ApplicationObjectes { get; set; }
        public bool IsAdmin { get; set; }

        public ApplicationObjectsModelView()
        {

        }

        public ApplicationObjectsModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
