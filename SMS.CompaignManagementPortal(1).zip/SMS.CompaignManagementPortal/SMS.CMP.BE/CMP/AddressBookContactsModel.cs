﻿using BE.Common;
using BE.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblAddressBookContacts", Identifier = "ContactID")]
    [Serializable]
    public class AddressBookContactsModel
    {
        //[MappingInfo(ColumnName = "ContactID", IdentitySpecification = false)]
        //public int? ContactID { get; set; }
        ////[MappingInfo(ColumnName = "AddressBookID")]
        ////public int? AddressBookID { get; set; }
        //[MappingInfo(ColumnName = "FirstName")]
        //public string FirstName { get; set; }
        //[MappingInfo(ColumnName = "LastName")]
        //public string LastName { get; set; }
        //[MappingInfo(ColumnName = "Email")]
        //public string Email { get; set; }
        //[MappingInfo(ColumnName = "Phone")]
        //public string Phone { get; set; }

        //[MappingInfo(ColumnName = "CreatedBy")]
        //public int? CreatedBy { get; set; }

        //[MappingInfo(ColumnName = "ModifiedBy")]
        //public int? ModifiedBy { get; set; }

    }

}
