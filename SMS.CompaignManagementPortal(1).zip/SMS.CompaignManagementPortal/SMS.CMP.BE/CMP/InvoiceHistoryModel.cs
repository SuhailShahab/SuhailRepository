﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblPaymentInvoiceHistory", Identifier = "PaymentInvoiceHistoryID")]
    [Serializable]
    public class InvoiceHistoryModel : BaseModel
    {
        [MappingInfo(ColumnName = "PaymentInvoiceHistoryID", IdentitySpecification = true)]
        public int? PaymentInvoiceHistoryID { get; set; }

        [MappingInfo(ColumnName = "PaymentInvoiceID")]
        public int? PaymentInvoiceID { get; set; }

        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }

        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }
        [MappingInfo(ColumnName = "DateofInvoice")]
        public DateTime DateofInvoice { get; set; }
        [MappingInfo(ColumnName = "Amount")]
        public decimal Amount { get; set; }
        [MappingInfo(ColumnName = "Mode")]
        public int? Mode { get; set; }
        
        [MappingInfo(ColumnName = "Quantity")]
        public int? Quantity { get; set; }
        [MappingInfo(ColumnName = "Rate")]
        public decimal Rate { get; set; }

        [MappingInfo(ColumnName = "OrganizationCode"), MappingInfo(Transient = true)]
        public string OrganizationCode { get; set; }
        [MappingInfo(ColumnName = "Organization"), MappingInfo(Transient = true)]
        public string Organization { get; set; }
        [MappingInfo(ColumnName = "Campaign"), MappingInfo(Transient = true)]
        public string Campaign { get; set; }
        
        [MappingInfo(ColumnName = "ShortCodeOrMask"), MappingInfo(Transient = true)]
        public string ShortCodeOrMask { get; set; }

    }
}
