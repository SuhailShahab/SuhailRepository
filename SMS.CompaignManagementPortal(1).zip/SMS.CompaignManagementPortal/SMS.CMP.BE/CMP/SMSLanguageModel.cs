﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    

    [ClassMapping(TableName = "tblSMSLanguage", Identifier = "SMSLangID")]
    [Serializable]
    public class SMSLanguageModel : BaseModel
    {
        [MappingInfo(ColumnName = "SMSLangID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }

    }
}
