﻿using BE.Common;
using SMS.CMP.BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date:  <19-10-2015 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR:001       Syed Zeeshan Aqil           25-11-2015 11:37 AM         Add by Zeeshan To Given the Inforce Rights to stop the message deliver in case bucket  Zero
// =================================================================================================================================


    [ClassMapping(TableName = "tblPaymentInformations", Identifier = "PaymentID")]
    [Serializable]
    public class PaymentModel : SMSCampaignStates
    {
        [MappingInfo(ColumnName = "PaymentID", IdentitySpecification = false)]
        public int? PaymentID { get; set; }
        [MappingInfo(ColumnName = "PurchaseDate")]
        public DateTime? PurchaseDate { get; set; }
        [MappingInfo(ColumnName = "ExpiryDate")]
        public DateTime? ExpiryDate { get; set; }
        [MappingInfo(ColumnName = "TotalAllocatedSMS")]
        public int? TotalAllocatedSMS { get; set; }
        [MappingInfo(ColumnName = "TotalRemainSMS")]
        public int? TotalRemainSMS { get; set; }
        [MappingInfo(ColumnName = "TotalAmount")]
        public decimal? TotalAmount { get; set; }
        [MappingInfo(ColumnName = "PerSMSRate")]
        public decimal? PerSMSRate { get; set; }

        [MappingInfo(ColumnName = "OrganizationCode"), MappingInfo(Transient = true)]
        public string OrganizationCode { get; set; }
        [MappingInfo(ColumnName = "DepartmentCode"), MappingInfo(Transient = true)]
        public string DepartmentCode { get; set; }
        [MappingInfo(ColumnName = "DepartmentTitle"), MappingInfo(Transient = true)]
        public string DepartmentTitle { get; set; }
        [MappingInfo(ColumnName = "OrganizationTitle"), MappingInfo(Transient = true)]
        public string OrganizationTitle { get; set; }
        [MappingInfo(ColumnName = "CampaignTitle"), MappingInfo(Transient = true)]
        public string CampaignTitle { get; set; }

        [MappingInfo(ColumnName = "MaskOrShortCode"), MappingInfo(Transient = true)]
        public string MaskOrShortCode { get; set; }

        [MappingInfo(ColumnName = "IsResponsive"), MappingInfo(Transient = true)]
        public int? IsResponsive { get; set; }
        
         // CR:001
        [MappingInfo(ColumnName = "InforceBucket")]  
         public bool? InforceBucket { get; set; }

    }

}
