﻿using BE.Common;
using BE.Lookups;
using BE.RightsManager;
using SMS.CMP.BE.Lookups;
using System;
using System.Collections.Generic;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblSMSCampaign", Identifier = "CampaignID")]
    [Serializable]
    public class SMSCampaignModel : CampaignList
    {
        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }
        [MappingInfo(ColumnName = "CampaignID", IdentitySpecification = false)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "SMSTypeID")]
        public int? SMSTypeID { get; set; }

        [MappingInfo(ColumnName = "MaskID")]
        public int? MaskID { get; set; }

        [MappingInfo(ColumnName = "IncomingMaskID")]
        public int? IncomingMaskID { get; set; }

        [MappingInfo(ColumnName = "TemplateID")]
        public int? TemplateID { get; set; }

        [MappingInfo(ColumnName = "ProcessingStatusID")]
        public int? HasRun { get; set; }

        [MappingInfo(ColumnName = "ProcessingStatusTitle")]
        public string ProcessingStatusTitle { get; set; }

        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }

        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }

        [MappingInfo(ColumnName = "UserID")]
        public int? UserID { get; set; }

        [MappingInfo(ColumnName = "StatusID")]
        public int? StatusID { get; set; }

        [MappingInfo(ColumnName = "ShortCodeID")]
        public int? ShortCodeID { get; set; }

        [MappingInfo(ColumnName = "IncomingShortCodeID")]
        public int? IncomingShortCodeID { get; set; }

        [MappingInfo(ColumnName = "MessageEnglish")]
        public string MessageEnglish { get; set; }

        [MappingInfo(ColumnName = "MessageUrdu")]
        public string MessageUrdu { get; set; }

        [MappingInfo(ColumnName = "MessageType")]
        public int? MessageType { get; set; }

        [MappingInfo(ColumnName = "Confirmation")]
        public bool? Confirmation { get; set; }

        [MappingInfo(ColumnName = "Repetition")]
        public bool? ReSchedule { get; set; }

        [MappingInfo(ColumnName = "IsSchedule")]
        public bool? IsSchedule { get; set; }


        [MappingInfo(ColumnName = "CampaignStartDate")]
        public DateTime? CampaignStartDate { get; set; }

        [MappingInfo(ColumnName = "CampaignStartTime")]
        public DateTime? ScheduleTime { get; set; }

        [MappingInfo(ColumnName = "CampaignEndDate")]
        public DateTime? CampaignEndDate { get; set; }

        [MappingInfo(ColumnName = "CampaignName")]
        public string CampaignName { get; set; }

        [MappingInfo(ColumnName = "AddressIDs")]
        public string AddressIDs { get; set; }

        [MappingInfo(ColumnName = "ContactInfo")]
        public string ContactsInfo { get; set; }


        [MappingInfo(ColumnName = "RESULT_COUNT"), MappingInfo(Transient = true)]
        public int? RESULT_COUNT { get; set; }

        [MappingInfo(ColumnName = "ServiceUrl")]
        public string ServiceUrl { get; set; }

        [MappingInfo(ColumnName = "ResponseMessage")]
        public string ResponseMessage { get; set; }

        [MappingInfo(ColumnName = "MethodName")]
        public string MethodName { get; set; }

        // code added by hammad - 27-01-2016 03:37:15PM
        [MappingInfo(ColumnName = "NoOfSMS")]
        public int? NoOfSMS { get; set; }

        public int? NoOfSMSEng { get; set; }
        public int? NoOfSMSUrd { get; set; }

        [MappingInfo(ColumnName = "ResponseLanguageMode")]
        public bool? ResponseLanguageMode { get; set; }

        [MappingInfo(ColumnName = "ResponseMessageUrdu")]
        public string ResponseMessageUrdu { get; set; }

        [MappingInfo(ColumnName = "ResponseNoOfSMS")]
        public int? ResponseNoOfSMS { get; set; }

        [MappingInfo(ColumnName = "PriorityID")]
        public int? PriorityID { get; set; }

        public int? ResponseNoOfSMSEng { get; set; }
        public int? ResponseNoOfSMSUrd { get; set; }
       // public int? TotalAllocatedSMS { get; set; }
        public SMSCampaignModel()
        {
        }
        public SMSCampaignModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class CampaignList : PaymentModel
    {
        public List<ContactModel> Contacts { get; set; }
        public List<ContactModel> UploadContacts { get; set; }
        public List<AddressBooksModel> AddressBooks { get; set; }
        public List<ContactModel> SelectedContact { get; set; }
        public List<AddressBooksModel> SelectedAddressBooks { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<UserModel> Users { get; set; }
        public List<SMSTemplateModel> SMSTemplates { get; set; }
        public List<ShortCodeModel> ShortCodes { get; set; }
        public List<MaskModel> Masks { get; set; }
        public List<MaskModel> IncomingMasks { get; set; }
        public List<ProcessingStatusModel> ProcessingStatuses { get; set; }
        public List<ScheduleModel> MappedCampaignSchedules { get; set; }
        //public PaymentModel PaymentInfo { get; set; }
    }


    public class SMSCampaignLog : SMSCampaignModel
    {



        [MappingInfo(ColumnName = "Status")]
        public string CampaignStatus { get; set; }

        [MappingInfo(ColumnName = "StartDate")]
        public DateTime StartDate { get; set; }

        [MappingInfo(ColumnName = "Mask")]
        public string Mask { get; set; }
    }



    public class SMSCampaignStates : BaseModel
    {

        [MappingInfo(ColumnName = "DailyCampaigns")]
        public int? DailyCampaigns { get; set; }

        [MappingInfo(ColumnName = "MonthlyCampaigns")]
        public int? MonthlyCampaigns { get; set; }

        [MappingInfo(ColumnName = "YearlyCampaigns")]
        public int? YearlyCampaigns { get; set; }

        [MappingInfo(ColumnName = "WeeklyCampaigns")]
        public int? WeeklyCampaigns { get; set; }

    }
    public class StartingCampaign : SMSCampaignModel
    {
        [MappingInfo(ColumnName = "SMSMessage")]
        public string SMSMessage { get; set; }
        [MappingInfo(ColumnName = "ShortCode")]
        public string ShortCode { get; set; }
        [MappingInfo(ColumnName = "Lang")]
        public string Lang { get; set; }

    }

    public class SMSCampaignViewModel : BaseModel
    {
        public SMSCampaignModel SMSCampaign { get; set; }
        public List<SMSTypesModel> SMSTypes { get; set; }
        public List<MaskModel> Masks { get; set; }
        public List<SMSTemplateModel> SMSTemplates { get; set; }
        public List<ShortCodeModel> ShortCodes { get; set; }
        public List<SMSCampaignModel> SMSCampaignsLog { get; set; }
        public List<ContactModel> Contacts { get; set; }
        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<AddressBooksModel> AddressBooks { get; set; }

        public List<ProcessingStatusModel> ProcessingStatuses { get; set; }

        public List<ScheduleModel> MappedCampaignSchedules { get; set; }

        public List<UserModel> Users { get; set; }
        public UserModel User { get; set; }
        public bool AllowUpdate { get; set; }

        //public List<ContactModel> SMSContacts { get; set; }
        //public List<ContactModel> SMSAddressBooks { get; set; }  

        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }
        public bool? ShowPriorityID { get; set; }

        public SMSCampaignViewModel()
        {
        }
        public SMSCampaignViewModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class SMSCampaignLogViewModel : BaseModel
    {

        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<SMSCampaignLog> SMSCampaignLogs { get; set; }
        public List<SMSTransactionModel> Transactions { get; set; }
        public List<CampaignStatus> CampaignStatuses { get; set; }
        public UserModel User { get; set; }
        public string APIUrl { get; set; }
        public string APIUrl2 { get; set; }
        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }

        public int TPageSize { get; set; }
        public int TPageNo { get; set; }
        public int TTotalCount { get; set; }




    }


    public class CampaignStatus
    {
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "count")]
        public int count { get; set; }
    }

}
