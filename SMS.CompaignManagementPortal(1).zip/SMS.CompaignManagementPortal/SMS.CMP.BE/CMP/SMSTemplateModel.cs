﻿using BE.Common;
using BE.Lookups;
using BE.RightsManager;
using System;
using System.Collections.Generic;

// =================================================================================================================================
// Create by:	<Sohail Kamran>
// Create date: <16-10-2015 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR:001       Muhammad Hamamd Shahid      27-01-2016 05:20:26PM       Impemente No. of SMS with message
// =================================================================================================================================
namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblSMSTemplates", Identifier = "TempalteID")]
    [Serializable]
    public class SMSTemplateModel : BaseModel
    {
        public SMSTemplateModel()
        { }

        public SMSTemplateModel(string Notification)
        {
            this.Notification = Notification;
        }
        public SMSTemplateModel(int? ID)
        {
            this.ID = ID;
        }
        [MappingInfo(ColumnName = "TempalteID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "TemplateMessageEng")]
        public string TemplateMessageEng { get; set; }
        [MappingInfo(ColumnName = "TemplateMessageUrdu")]
        public string TemplateMessageUrdu { get; set; }
        [MappingInfo(ColumnName = "IsActive")]
        public bool? IsActive { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }
        [MappingInfo(ColumnName = "Organization")]
        public string Organization { get; set; }
        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }
        [MappingInfo(ColumnName = "RESULT_COUNT"), MappingInfo(Transient = true)]
        public int? RESULT_COUNT { get; set; }
        [MappingInfo(ColumnName = "MessageType")]
        public int? MessageType { get; set; }


        // code added by hammad - CR:001
        [MappingInfo(ColumnName = "NoOfSMS")]
        public int? NoOfSMS { get; set; }

        public int? NoOfSMSEng { get; set; }
        public int? NoOfSMSUrd { get; set; }


    }
    public class SMSTemplateModelView : SMSTemplateModel
    {
        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<SMSTemplateModel> Templates { get; set; }
        public UserModel User { get; set; }

        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }

       public SMSTemplateModelView()
        { 
        }
       public SMSTemplateModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }

}
