﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblSMSMode", Identifier = "SMSModeID")]
    [Serializable]
    public class SMSModeModel : BaseModel
    {
        [MappingInfo(ColumnName = "SMSModeID")]
        public int? ID { get; set; }
        
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        

    }
}
