﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP 
{
    [ClassMapping(TableName = "tblSMSTransactions", Identifier = "SMSTransactionID")]
    [Serializable]
    public class SMSInboxModel
    {
        public SMSInboxModel()
        {

        }
        public SMSInboxModel(int? organizationID,int?campaignID,int?smsSendingID,int? deliveryStatusID,string contactNo)
        {
            this.OrganizationID = organizationID;
            this.CampaignID = campaignID;
            this.SMSSendingID = smsSendingID;
            this.DeliveryStatusID = deliveryStatusID;
            this.ContactNo = contactNo;
        }
        public SMSInboxModel(int? organizationID, int? campaignID, int? smsSendingID, int? deliveryStatusID, string contactNo, string network)
        {
            this.OrganizationID = organizationID;
            this.CampaignID = campaignID;
            this.SMSSendingID = smsSendingID;
            this.DeliveryStatusID = deliveryStatusID;
            this.ContactNo = contactNo;
            this.Network = network;
        }
        [MappingInfo(ColumnName = "SMSTransactionID", IdentitySpecification = true)]
        public int? SMSTransactionID { get; set; }
        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }
        [MappingInfo(ColumnName = "ContactNo")]
        public string ContactNo { get; set; }
        [MappingInfo(ColumnName = "SendMessage")]
        public string SendMessage { get; set; }
        [MappingInfo(ColumnName = "RecieveMessage")]
        public string RecieveMessage { get; set; }
        [MappingInfo(ColumnName = "DeliveryStatusID")] 
        public int? DeliveryStatusID { get; set; } 
        [MappingInfo(ColumnName = "SendingDate")]
        public DateTime? SendingDate { get; set; }
        [MappingInfo(ColumnName = "Mode")]
        public int? Mode { get; set; }
        [MappingInfo(ColumnName = "DeliveredDate")] 
        public DateTime? DeliveredDate { get; set; }
        [MappingInfo(ColumnName = "ContactID")]
        public int? ContactID { get; set; }
        [MappingInfo(ColumnName = "Network")]
        public string Network { get; set; }
        [MappingInfo(ColumnName = "SMSSendingID")]
        public int? SMSSendingID { get; set; }
        [MappingInfo(ColumnName = "TotalAllocatedSMS")]
        public int? TotalAllocatedSMS { get; set; }
        [MappingInfo(ColumnName = "StartDate")]
        public DateTime? StartDate { get; set; }
        [MappingInfo(ColumnName = "EndDate")]
        public DateTime? EndDate { get; set; }
        [MappingInfo(ColumnName = "Mask")]
        public int? Mask { get; set; }

        [MappingInfo(ColumnName = "Status")]
        public string Status { get; set; }
       

    }
}
