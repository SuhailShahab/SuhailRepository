﻿using BE.Common;
using BE.Lookups;
using BE.RightsManager;
using SMS.CMP.BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{

    public class BucketHistory : BaseModel
    {
        public List<PaymentModel> Payments { get; set; }
        public List<OrganizationModel> Organizations { get; set; }

        public List<DepartmentsModel> Departments { get; set; }
        public List<SMSCampaignLog> SMSCampaignLogs { get; set; }
        public UserModel User { get; set; }

        public int selectedOrganizationID { get; set; }

        public BucketHistory()
        { 
        }
         public BucketHistory(string Notification)
        {
            this.Notification = Notification;
        }
    }

}
