﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.CMP.BE.Lookups;
using BE.Lookups;


// =================================================================================================================================
// Create by:	<Muhammad Usman>
// Create date: <23-11-2015 03:37 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR:001       Syed Zeeshan Aqil           04-Feb- 2015 05:21 PM       Add Property  "TotalSMS"

// =================================================================================================================================


namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblPaymentInvoice", Identifier = "PaymentInvoiceID")]
    [Serializable]
    public class InvoiceModel : BaseModel
    {
        [MappingInfo(ColumnName = "PaymentInvoiceID", IdentitySpecification = true)]
        public int? PaymentInvoiceID { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }
        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }
        
        [MappingInfo(ColumnName = "DateofInvoice")]
        public DateTime DateofInvoice { get; set; }

        [MappingInfo(ColumnName = "FinalDateofInvoice")]
        public DateTime? FinalDateofInvoice { get; set; }
        [MappingInfo(ColumnName = "PayableAmount")]
        public decimal PayableAmount { get; set; }
        [MappingInfo(ColumnName = "PaidAmount")]
        public decimal PaidAmount { get; set; }
        [MappingInfo(ColumnName = "Organization"), MappingInfo(Transient = true)]
        public string Organization { get; set; }
        [MappingInfo(ColumnName = "Campaign"), MappingInfo(Transient = true)]
        public string Campaign { get; set; }
        [MappingInfo(ColumnName = "Mode")]
        public int? Mode { get; set; }
        [MappingInfo(ColumnName = "DepartmentID")]
        public int DepartmentID { get; set; }
        [MappingInfo(ColumnName = "Department"), MappingInfo(Transient = true)]
        public string Department { get; set; }
        [MappingInfo(ColumnName = "Quantity")]
        public int? Quantity { get; set; }
        [MappingInfo(ColumnName = "Rate")]
        public decimal Rate { get; set; }
        [MappingInfo(ColumnName = "OrganizationCode"), MappingInfo(Transient = true)]
        public string OrganizationCode { get; set; }
        [MappingInfo(ColumnName = "ShortCodeOrMask"), MappingInfo(Transient = true)]
        public string ShortCodeOrMask { get; set; }
        [MappingInfo(ColumnName = "TotalAmount"), MappingInfo(Transient = true)]
        public decimal TotalAmount { get; set; }
        [MappingInfo(ColumnName = "TotalCount"), MappingInfo(Transient = true)]
        public int TotalCount { get; set; }
        public List<InvoiceModel> Invoices { get; set; }

        [MappingInfo(ColumnName = "NoOfMessage")]// CR:001
        public int NoOfMessage { get; set; }// CR:001


        public List<InvoiceListModel> InvoicesList { get; set; }

         public InvoiceModel()
        { 
        }
         public InvoiceModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class InvoiceModelView
    {
        public List<DepartmentsModel> Departments { get; set; }
        public List<OrganizationModel> Organizations { get; set; }
        public List<SMSCampaignModel> Campaigns { get; set; }
        public List<InvoiceModel> Invoices { get; set; }
        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }
        public string SearchText { get; set; }
        public string Notification { get; set; }
        public InvoiceModelView()
        { 
        }
        public InvoiceModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
