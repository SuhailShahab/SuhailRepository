﻿using BE.Common;
using BE.Lookups;
using BE.RightsManager;
using SMS.CMP.BE.Lookups;
using System;
using System.Collections.Generic;

namespace SMS.CMP.BE.CMP
{
    public class CampaignPriorityModel : BaseModel
    {
        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "PriorityID")]
        public int? PriorityID { get; set; }

        [MappingInfo(ColumnName = "NewPriorityID")]
        public int? NewPriorityID { get; set; }

        [MappingInfo(ColumnName = "TotalSMS")]
        public int? TotalSMS { get; set; }

        public CampaignPriorityModel()
        {
        }
        public CampaignPriorityModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class CampaignPriorityViewModel : BaseModel
    {
        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<CampaignPriorityModel> CampaignsPriority { get; set; }
        public List<SMSCampaignModel> Campaignslist { get; set; }

        public UserModel User { get; set; }

        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }
        public bool? ShowPriorityID { get; set; }

        public CampaignPriorityViewModel()
        {
        }
        public CampaignPriorityViewModel(string Notification)
        {
            this.Notification = Notification;
        }
    }
}