﻿using BE.Common;
using BE.Lookups;
using BE.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblAddressBooks", Identifier = "AddressBookID")]
    [Serializable]
    public class AddressBooksModel:BaseModel
    {
        [MappingInfo(ColumnName = "AddressBookID", IdentitySpecification = false)]
        public int? AddressBookID { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "IsActive")]
        public bool? IsActive { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }

         [MappingInfo(ColumnName = "AddressBookContactsCount")]
        public int? AddressBookContactsCount { get; set; }

        public List<ContactModel> Contacts { get; set; }

        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }

        [MappingInfo(ColumnName = "Assigned",Transient=true)]
        public bool? Assigned { get; set; }

        [MappingInfo(ColumnName = "RESULT_COUNT",Transient=true)]
        public int? RESULT_COUNT { get; set; }


        [MappingInfo(ColumnName = "ContactsCount",Transient=true)]
        public int? NoOfContacts { get; set; }

        [MappingInfo(ColumnName = "RowNumber", Transient = true)]
        public Int64? RowNumber { get; set; }
        public AddressBooksModel()
        { 
        }
      
        public AddressBooksModel(string Notification)
        {
            this.Notification = Notification;
        }

    }

    public class AddressBookModelView:BaseModel
    {
        public List<OrganizationModel> Organizations { get; set; }
        public List<AddressBooksModel> AddressBooks { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<ContactModel> Contacts { get; set; }
        public UserModel User { get; set; }
        
        public int UserGroupID { get; set; }
        public bool IsEnable { get; set; }

        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }

        public int TotalContactsCount { get; set; }
       

        public int? UserDepartmentID { get; set; }
        
        public AddressBookModelView()
        { 
        }

        public AddressBookModelView(string Notification)
        {
            this.Notification = Notification;
        }
      
    }
}

