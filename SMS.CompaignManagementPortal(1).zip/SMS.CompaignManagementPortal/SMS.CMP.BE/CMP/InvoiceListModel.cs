﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// Created BY: Atif Farooq
//  For Checkbox list on Final invoice page
/// Dated: 04 Feb 2016

namespace SMS.CMP.BE.CMP
{
    public class InvoiceListModel
    {
        public bool Checked { get; set; }
        public int? PaymentInvoiceID { get; set; }
        public int? OrganizationID { get; set; }
        public int DepartmentID { get; set; }
        public string Campaign { get; set; }
    }
}
