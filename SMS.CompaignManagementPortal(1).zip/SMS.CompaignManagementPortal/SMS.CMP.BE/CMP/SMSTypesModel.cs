﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblSMSTypes", Identifier = "SMSTypeID")]
    [Serializable]
    public class SMSTypesModel:BaseModel
    {
        [MappingInfo(ColumnName = "SMSTypeID", IdentitySpecification = true)]
        public int? SMSTypeID { get; set; }
        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "IsActive")]
        public bool? IsActive { get; set; }
        [MappingInfo(ColumnName = "CreatedBy")]
        public int? CreatedBy { get; set; }
        [MappingInfo(ColumnName = "ModifiedBy")]
        public int? ModifiedBy { get; set; }

        public SMSTypesModel()
        {

        }
        public SMSTypesModel(string Notification)
        {
            this.Notification = Notification;
        }
    }


    public class SMSTypeModelView : BaseModel
    {
        public List<SMSTypesModel> SMSTypes { get; set; }
        
        public SMSTypeModelView()
        {

        }
        public SMSTypeModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
