﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblCampaigns", Identifier = "CampaignID")]
    [Serializable]
    public class SMSCampaingLogsModel
    {
        [MappingInfo(ColumnName = "CampaignID", IdentitySpecification = true)]
        public int? CampaignID { get; set; }
        [MappingInfo(ColumnName = "CampaignName")]
        public string CampaignName { get; set; }
        [MappingInfo(ColumnName = "Mask")]
        public string Mask { get; set; }
        [MappingInfo(ColumnName = "Status")]
        public string Status { get; set; }
        [MappingInfo(ColumnName = "StartDate")]
        public DateTime StartDate { get; set; }
    }
}
