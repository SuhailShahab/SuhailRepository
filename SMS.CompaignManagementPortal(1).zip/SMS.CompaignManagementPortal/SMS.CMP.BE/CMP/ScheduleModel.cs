﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    
    public class ScheduleModel 
    {
         [MappingInfo(ColumnName = "ScheduleID")]
        public int ScheduleID { get; set; }
         [MappingInfo(ColumnName = "RowIndex")]
        public int RowIndex { get; set; }
         [MappingInfo(ColumnName = "ColIndex")]
        public int ColIndex { get; set; }
         [MappingInfo(ColumnName = "CellCount")]
        public int CellCount { get; set; }
    }

}
