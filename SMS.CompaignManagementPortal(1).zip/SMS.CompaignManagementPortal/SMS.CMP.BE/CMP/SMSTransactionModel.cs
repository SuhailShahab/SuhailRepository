﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP 
{
    [ClassMapping(TableName = "tblSMSTransactions", Identifier = "SMSTransactionID")]
    [Serializable]
    public class SMSTransactionModel :BaseModel
    {
        public SMSTransactionModel()
        {

        }
        public SMSTransactionModel(string Notification)
        {
            this.Notification = Notification;
        }
        public SMSTransactionModel(int? organizationID,int?campaignID,int?smsSendingID,int? deliveryStatusID,string contactNo)
        {
            this.OrganizationID = organizationID;
            this.CampaignID = campaignID;
            this.SMSSendingID = smsSendingID;
            this.DeliveryStatusID = deliveryStatusID;
            this.ContactNo = contactNo;
        }


        public SMSTransactionModel(int? organizationID, int? campaignID, int? smsSendingID, int? deliveryStatusID, string contactNo, string network, int? telcoID, string originalContactNo)
        {
            this.OrganizationID = organizationID;
            this.CampaignID = campaignID;
            this.SMSSendingID = smsSendingID;
            this.DeliveryStatusID = deliveryStatusID;
            this.ContactNo = contactNo;
            this.Network = network;
            this.TelcoID = telcoID;
            this.OriginalContactNo = originalContactNo;
        }
        [MappingInfo(ColumnName = "SMSTransactionID", IdentitySpecification = true)]
        public int? SMSTransactionID { get; set; }
        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }
        [MappingInfo(ColumnName = "ContactNo")]
        public string ContactNo { get; set; }
        [MappingInfo(ColumnName = "OriginalContactNo")]
        public string OriginalContactNo { get; set; }
        [MappingInfo(ColumnName = "SendMessage")]
        public string SendMessage { get; set; }
        [MappingInfo(ColumnName = "RecieveMessage")]
        public string RecieveMessage { get; set; }
        [MappingInfo(ColumnName = "DeliveryStatusID")] 
        public int? DeliveryStatusID { get; set; } 
        [MappingInfo(ColumnName = "SendingDate")]
        public DateTime? SendingDate { get; set; }
        [MappingInfo(ColumnName = "Mode")]
        public int? Mode { get; set; }
        [MappingInfo(ColumnName = "DeliveredDate")] 
        public DateTime? DeliveredDate { get; set; }
        [MappingInfo(ColumnName = "ContactID")]
        public int? ContactID { get; set; }
        [MappingInfo(ColumnName = "Network")]
        public string Network { get; set; }
        [MappingInfo(ColumnName = "SMSSendingID")]
        public int? SMSSendingID { get; set; }
        [MappingInfo(ColumnName = "TotalAllocatedSMS")]
        public int? TotalAllocatedSMS { get; set; }
        [MappingInfo(ColumnName = "StartDate")]
        public DateTime? StartDate { get; set; }
        [MappingInfo(ColumnName = "EndDate")]
        public DateTime? EndDate { get; set; }
        [MappingInfo(ColumnName = "Mask")]
        public string Mask { get; set; }
        [MappingInfo(ColumnName = "ShortCode")]
        public string ShortCode { get; set; }
        [MappingInfo(ColumnName = "Status")]
        public string SMSSendingStatus { get; set; }
        [MappingInfo(ColumnName = "TelcoID")]
        public int? TelcoID { get; set; }
        [MappingInfo(ColumnName = "IsOnNet")]
        public bool? IsOnNet { get; set; }
        [MappingInfo(ColumnName = "ResponseID")]
        public int? ResponseID { get; set; }
        [MappingInfo(ColumnName = "RESULT_COUNT"), MappingInfo(Transient = true)]
        public int? RESULT_COUNT { get; set; }
        [MappingInfo(ColumnName = "Lang")]
        public string Lang { get; set; }
        [MappingInfo(ColumnName = "FirtName"), MappingInfo(Transient = true)]
        public string SenToFirstName { get; set; }
        [MappingInfo(ColumnName = "NoOfSMS")]
        public int? NoOfSMS { get; set; }
        [MappingInfo(ColumnName = "MessageText")]
        public string MessageText { get; set; }

    }
}
