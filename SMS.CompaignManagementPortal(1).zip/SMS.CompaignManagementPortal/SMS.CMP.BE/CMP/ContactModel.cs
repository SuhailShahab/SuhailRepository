﻿using BE.Common;
using BE.Lookups;
using BE.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblContacts", Identifier = "ContactID")]
    [Serializable]
    public class ContactModel : BaseModel
    {
        public ContactModel(int? ID)
        {
            this.ID = ID;
        }

        public ContactModel()
        {
            
        }
        public ContactModel(string Notification)
        {
            this.Notification = Notification;
        }
        [MappingInfo(ColumnName = "ContactID", IdentitySpecification = false)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "FirstName")]
        public string FirstName { get; set; }
        [MappingInfo(ColumnName = "LastName")]
        public string LastName { get; set; }
        [MappingInfo(ColumnName = "Email")]
        public string Email { get; set; }
        [MappingInfo(ColumnName = "Phone")]
        public string Phone { get; set; }
        [MappingInfo(ColumnName = "ContactNo")]
        public string ContactNo { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }

        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; } 

        [MappingInfo(ColumnName = "Assigned", Transient=true)]
        public bool? Assigned { get; set; }


        [MappingInfo(ColumnName = "OrganizationTitle", Transient = true)]
        public string OrganizationTitle { get; set; }

        [MappingInfo(ColumnName = "DepartmentTitle", Transient = true)]
        public string DepartmentTitle { get; set; }


        [MappingInfo(ColumnName = "RESULT_COUNT",Transient =true)]
        public int? RESULT_COUNT { get; set; }

        [MappingInfo(ColumnName = "RowNumber", Transient = true)]
        public Int64? RowNumber { get; set; }
        //public bool? IsEncodeOn { get; set; }
    }

    

    public class ContactModelView : ContactModel
    {
        public List<ContactModel> Contacts { get; set; }
        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<SMSCampaignModel> Campaigns { get; set; } 
        public UserModel User { get; set; }
        public int UserGroupID { get; set; }
        public bool IsEnable { get; set; }
        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }
        public ContactModelView()
        { 
        }
        public ContactModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class BulkContactModel : ContactModel
    {

        [MappingInfo(ColumnName = "MessageEnglish"), MappingInfo(Transient = true)]
        public string MessageEnglish { get; set; }
        [MappingInfo(ColumnName = "MessageUrdu"), MappingInfo(Transient = true)]
        public string MessageUrdu { get; set; }
        [MappingInfo(ColumnName = "CampaignTitle"), MappingInfo(Transient = true)]
        public string CampaignTitle { get; set; }
        [MappingInfo(ColumnName = "CampaignID"), MappingInfo(Transient = true)]
        public int? CampaignID { get; set; }
        [MappingInfo(ColumnName = "IsEncodeOn"), MappingInfo(Transient = true)]
        public bool? IsEncodeOn { get; set; }
        [MappingInfo(ColumnName = "RowNumber"), MappingInfo(Transient = true)]
        public Int64? RowNumber { get; set; }
        [MappingInfo(ColumnName = "StatusTitle"), MappingInfo(Transient = true)]
        public string StatusTitle { get; set; }

        public BulkContactModel()
        { 
        }
        public BulkContactModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class BulkContactModelView : BulkContactModel
    {
        public List<BulkContactModel> Contacts { get; set; }
        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<SMSCampaignModel> Campaigns { get; set; }
        public UserModel User { get; set; }
        public int UserGroupID { get; set; }
        public bool IsEnable { get; set; }
        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }

         public BulkContactModelView()
        { 
        }
         public BulkContactModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }

}
