﻿using BE.Common;
using SMS.CMP.BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblTelcoPaymentInformations", Identifier = "TelcoPaymnetID")]
    [Serializable]
    public class TelcoModel : BaseModel
    {

        public TelcoModel()
        {
            
        }
        public TelcoModel(string Notification)
        {
            this.Notification = Notification;
        }
        public TelcoModel(int? ID)
        {
            this.ID = ID;
        }

        [MappingInfo(ColumnName = "TelcoPaymentID", IdentitySpecification = false)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "PerSMSRate")]
        public decimal? PerSMSRate { get; set; }

        [MappingInfo(ColumnName = "TotalBalance")]
        public decimal? TotalBalance { get; set; }

        [MappingInfo(ColumnName = "RemainedBalance")]
        public decimal? RemainBalance { get; set; }

        [MappingInfo(ColumnName = "UsedBalance")]
        public decimal? UsedBalance { get; set; }
        
        [MappingInfo(ColumnName = "TotalSMS")]
        public double? TotalSMS { get; set; }

        [MappingInfo(ColumnName = "RemainingSMS")]
        public double? RemainingSMS { get; set; }

        [MappingInfo(ColumnName = "UsedSMS")]
        public double? UsedSMS { get; set; }

        [MappingInfo(ColumnName = "PurchaseDate")]
        public DateTime? PurchaseDate { get; set; }

        [MappingInfo(ColumnName = "ExpiryDate")]
        public DateTime? ExpiryDate { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "TelcoID")]
        public int? TelcoID { get; set; }

        [MappingInfo(ColumnName = "IsOnNet")]
        public bool? IsOnNet { get; set; }

        [MappingInfo(ColumnName = "TelcoName"), MappingInfo(Transient = true)]
        public string TelcoName { get; set; }
        [MappingInfo(ColumnName = "NetworkCode"), MappingInfo(Transient = true)]
        public string TelcoCode { get; set; }
        

        [MappingInfo(ColumnName = "RESULT_COUNT"), MappingInfo(Transient = true)]
        public int? RESULT_COUNT { get; set; }

    }



    public class TelcoModelView : BaseModel
    {
        public List<TelcoModel> TelcoPayments { get; set; }
        public List<TelcoModel> TelcoCompanies { get; set; }
        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }

        public TelcoModelView()
        { 
        }
        public TelcoModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
