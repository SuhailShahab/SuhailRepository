﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblBulkSMS", Identifier = "SMSID")]
    [Serializable]
    public class BulkSMSModel : BaseModel
    {
        [MappingInfo(ColumnName = "SMSID")]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }
        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }
        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }
        public DataTable BulkSMS { get; set; }
        [MappingInfo(ColumnName = "IsEncodeOn")]
        public bool? IsEncodeOn { get; set; }
        [MappingInfo(ColumnName = "CellNo")]
        public string Phone { get; set; }
        [MappingInfo(ColumnName = "MessageUrdu")]
        public string MessageUrdu { get; set; }
        [MappingInfo(ColumnName = "MessageEnglish")]
        public string MessageEnglish { get; set; }

        //[MappingInfo(ColumnName = "MessageEnglish"), MappingInfo(Transient = true)]
        //public string MessageEnglish { get; set; }
        //[MappingInfo(ColumnName = "MessageUrdu"), MappingInfo(Transient = true)]
        //public string MessageEngUrdu { get; set; }

        [MappingInfo(ColumnName = "NoOfSMS")]
        public int? NoOfSMS { get; set; }
        [MappingInfo(ColumnName = "SMSGateway")]
        public string SMSGateway { get; set; }
        [MappingInfo(ColumnName = "UserName")]
        public string UserName { get; set; }
        [MappingInfo(ColumnName = "Password")]
        public string Password { get; set; }
        [MappingInfo(ColumnName = "IsOnNet")]
        public bool? IsOnNet { get; set; }
        [MappingInfo(ColumnName = "TelcoID")]
        public int? TelcoID { get; set; }
        public BulkSMSModel()
        { 
        }
        public BulkSMSModel(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
