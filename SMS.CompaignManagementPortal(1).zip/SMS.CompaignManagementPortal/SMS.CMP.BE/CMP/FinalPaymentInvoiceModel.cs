﻿using BE.Common;
using BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblFinalPaymentInvoice", Identifier = "FinalPaymentInvoiceID")]
    [Serializable]
    public class FinalPaymentInvoiceModel : BaseModel
    {
        [MappingInfo(ColumnName = "FinalPaymentInvoiceID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "FinalPaymentInvoiceNo")]
        public string FinalPaymentInvoiceNo { get; set; }

        [MappingInfo(ColumnName = "PaymentInvoiceID")]
        public int? PaymentInvoiceID { get; set; }

        [MappingInfo(ColumnName = "DateofInvoice")]
        public DateTime? DateofInvoice { get; set; }

        [MappingInfo(ColumnName = "CampaignID"), MappingInfo(Transient = true)]
        public int? CampaignID { get; set; }

        [MappingInfo(ColumnName = "CampaignName")]
        public string CampaignName { get; set; }

        [MappingInfo(ColumnName = "DepartmentName")]
        public string DepartmentName { get; set; }

        [MappingInfo(ColumnName = "OrganizationName")]
        public string OrganizationName { get; set; }

        [MappingInfo(ColumnName = "PaymentInvoiceTitle"), MappingInfo(Transient = true)]
        public string PaymentInvoiceTitle { get; set; }

    }
    public class FinalPaymentInvoiceModelView 
    {
        public List<DepartmentsModel> Departments { get; set; }
        public List<OrganizationModel> Organizations { get; set; }
        public List<SMSCampaignModel> Campaigns { get; set; }
        public List<InvoiceModel> Invoices { get; set; }
        public List<FinalPaymentInvoiceModel> lstFinalPaymentInvoices { get; set; }
        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }
        public string SearchText { get; set; }
        public string Notification { get; set; }

         public FinalPaymentInvoiceModelView()
        { 
        }
         public FinalPaymentInvoiceModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
