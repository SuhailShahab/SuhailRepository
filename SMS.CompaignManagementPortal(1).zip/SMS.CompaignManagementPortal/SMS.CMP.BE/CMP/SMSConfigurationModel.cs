﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SMS.CMP.BE.Lookups;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP
{
    [ClassMapping(TableName = "tblSMSConfigurations", Identifier = "ConfigurationID")]
    [Serializable]
    public class SMSConfigurationModel:BaseModel
    {
        [MappingInfo(ColumnName = "ConfigurationID", IdentitySpecification = true)]
        public int? ConfigurationID { get; set; }
        [MappingInfo(ColumnName = "SMSGateway")]
        public string SMSGateway { get; set; }
        [MappingInfo(ColumnName = "UserName")]
        public string UserName { get; set; }
        [MappingInfo(ColumnName = "Password")]
        public string Password { get; set; }
        [MappingInfo(ColumnName = "SourceNetworksID")]
        public string SourceNetworksID { get; set; }
        [MappingInfo(ColumnName = "IsDefault")]
        public bool IsDefault { get; set; }
        [MappingInfo(ColumnName = "IsOffNetChecked")]
        public bool IsOffNetChecked { get; set; }
        [MappingInfo(ColumnName = "IsChecked")]
        public bool IsChecked { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "TelcoID")]
        public int? TelcoID { get; set; }
        [MappingInfo(ColumnName = "SMSThroughput")]
        public int? SMSThroughput { get; set; }
        public string SendPhoneNo { get; set; }
        public bool? IsOnNet { get; set; }
        public string OriginalContactNo { get; set; }

         public SMSConfigurationModel()
        { 
        }
         public SMSConfigurationModel(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class SMSConfigurationModelView:BaseModel
    {
        public List<SMSConfigurationModel> SMSConfiguration { get; set; }
        public List<NetworksCodeModel> NetworksCode { get; set; }

         public SMSConfigurationModelView()
        { 
        }
         public SMSConfigurationModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }


}
