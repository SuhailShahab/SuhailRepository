﻿using BE.Common;
using BE.Lookups;
using BE.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.CMP 
{
    [ClassMapping(TableName = "tblCustomerRespnses", Identifier = "ResponseID")]
    [Serializable]
    public class SMSResponseModel :BaseModel
    {
        public SMSResponseModel()
        {

        }
        public SMSResponseModel(string Notification)
        {
            this.Notification = Notification;
        }
        [MappingInfo(ColumnName = "ResponseID", IdentitySpecification = true)]
        public int? ResponseID { get; set; }
        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }

       


        [MappingInfo(ColumnName = "ReplyKeyword")]
        public string ReplyKeyword { get; set; }
        [MappingInfo(ColumnName = "ReplyPhoneNo")]
        public string ReplyPhoneNo { get; set; }
        [MappingInfo(ColumnName = "ReplyMessage")]
        public string ReplyMessage { get; set; }
        [MappingInfo(ColumnName = "ShortCode")]
        public string ShortCode { get; set; }

        [MappingInfo(ColumnName = "Mask")]
        public string Mask { get; set; }

        [MappingInfo(ColumnName = "ReceivingDate")]
        public DateTime? ReceivingDate { get; set; }

        [MappingInfo(ColumnName = "ResponseDate")]
        public DateTime? ResponseDate { get; set; }

        [MappingInfo(ColumnName = "ConfirmationDate")]
        public DateTime? ConfirmationDate { get; set; }

        [MappingInfo(ColumnName = "ConfirmationCode")]
        public string ConfirmationCode { get; set; }


        [MappingInfo(ColumnName = "OrganizationID")]
        public int? OrganizationID { get; set; }

        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }

        [MappingInfo(ColumnName = "UserID")]
        public int? UserID { get; set; }

        [MappingInfo(ColumnName = "RecordID")]
        public int? RecordID { get; set; }


        [MappingInfo(ColumnName = "RESULT_COUNT"), MappingInfo(Transient = true)]
        public int? RESULT_COUNT { get; set; }

    }

    public class SMSResponseViewModel : BaseModel
    {
        public List<SMSCampaignModel> SMSCampaigns { get; set; }
        public List<SMSResponseModel> SMSResponse { get; set; }
        public List<OrganizationModel> Organizations { get; set; }
        public List<DepartmentsModel> Departments { get; set; }
        public List<SMSTransactionModel> SMSTransactions { get; set; }
        public UserModel User { get; set; }

        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }

         public SMSResponseViewModel()
        { 
        }
         public SMSResponseViewModel(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
