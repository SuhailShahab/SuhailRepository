﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Common
{
   public  class BaseModel
    {
        [MappingInfo(ColumnName = "VersionNo")]
        public int? VersionNo { get; set; }

        [MappingInfo(ColumnName = "CreatedBy")]
        public int? CreatedBy { get; set; }

        [MappingInfo(ColumnName = "ModifiedBy")]
        public int? ModifiedBy { get; set; }

        [MappingInfo(ColumnName = "CreatedDate", Transient = true)]
        public DateTime? CreatedDate { get; set; }

        [MappingInfo(ColumnName = "ModifiedDate")]
        public DateTime? ModifiedDate { get; set; }

        [MappingInfo(ColumnName = "IsActive")]
        public bool? Status { get; set; }

        public string Notification { get; set; }
        public bool? IsEdit { get; set; }

        //[MappingInfo(ColumnName = "IsActive")]
        //public bool? IsActive { get; set; } 
      

       
    }
}
