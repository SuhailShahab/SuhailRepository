﻿using SMS.CMP.BE.CMP;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.Common
{
    public static class CommonMethod
    {

        public static DateTime ConvertDateFormat(string value)
        {
            DateTime Date = new DateTime();

            string[] arrValue = value.Split('/');
            if (arrValue.Length == 3)
            {
                Date = new DateTime(Convert.ToInt32(arrValue[2]), Convert.ToInt32(arrValue[1]), Convert.ToInt32(arrValue[0]));
            }

            return Date;
        }

        public static string  ReplaceSpecilChar(string data)
        {
            if(!string.IsNullOrEmpty(data) && data.Contains("+"))
            {
                data= data.Replace("+","%2B");
            }

            if (!string.IsNullOrEmpty(data) && data.Contains("&"))
            {
                data = data.Replace("&", "%26");
            }

            if (!string.IsNullOrEmpty(data) && data.Contains("#"))
            {
                data = data.Replace("#", "%23");
            }
            return data;
        }

    }
}
