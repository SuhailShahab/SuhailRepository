﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.Common
{
    public class VerificationResult
    {
        public int SMS_SendingID { get; set; }
        public string ShortCode { get; set; }
        public string SMSMessage { get; set; }
        public int? VersionNo { get; set; }
        public int? PriorityID { get; set; }

    }
}
