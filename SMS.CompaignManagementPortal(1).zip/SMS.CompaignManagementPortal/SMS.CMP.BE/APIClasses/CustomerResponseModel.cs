﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Create date: <05-11-2015 11:05AM>
// =================================================================================================================================
// SR#              Created By                 Modified Date/Time          Desription
// 000              Suhail Shahab                                          This class is using in Web API (Inter API). This class 
//                                                                         save the customer response form mobile
// ===================================================== Modification History ======================================================
// SR#              Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
namespace SMS.CMP.BE.APIClasses
{

    [ClassMapping(TableName = "tblCustomerRespnses", Identifier = "ResponseID")]
    [Serializable]
   public  class CustomerResponseModel
    {
        public CustomerResponseModel()
        {

        }

        public CustomerResponseModel(string confirmationCode, int? Id,int? camapignID,string phoneNumber)
        {
            this.ConfirmationCode = confirmationCode;
            this.ID = Id;
            this.CampaignID = camapignID;
            this.ReplyPhoneNo = phoneNumber;
        }
        public CustomerResponseModel(string confirmationCode, int? Id,int?recordID, int? camapignID, string phoneNumber)
        {
            this.ConfirmationCode = confirmationCode;
            this.ID = Id;
            this.RecordID = recordID;
            this.CampaignID = camapignID;
            this.ReplyPhoneNo = phoneNumber;
        }

        public CustomerResponseModel(string confirmationCode,int?Id)
        {
            this.ConfirmationCode = confirmationCode;
            this.ID = Id;
        }
        public CustomerResponseModel(string replyKeyworld,string replyPhone,string replyMessage,string shortCode,int campaignID)
        {
            this.ReplyKeyword = replyKeyworld;
            this.ReplyPhoneNo = replyPhone;
            this.ReplyMessage = replyMessage;
            this.ShortCode = shortCode;
            this.CampaignID = campaignID;
        }
        [MappingInfo(ColumnName = "ResponseID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "CampaignID")]
        public int? CampaignID { get; set; }
        [MappingInfo(ColumnName = "RecordID")]
        public int? RecordID { get; set; }
        [MappingInfo(ColumnName = "ReplyKeyword")]
        public string ReplyKeyword { get; set; }
        [MappingInfo(ColumnName = "ReplyPhoneNo")]
        public string ReplyPhoneNo { get; set; }
        [MappingInfo(ColumnName = "ReplyMessage")]
        public string ReplyMessage { get; set; }
        [MappingInfo(ColumnName = "ShortCode")]
        public string ShortCode { get; set; }
        [MappingInfo(ColumnName = "ConfirmationCode")]
        public string ConfirmationCode { get; set; }
        public string ServiceUrl { get; set; }
        public string MethodName { get; set; }
        [MappingInfo(ColumnName = "OriginalContactNo")]
        public string OriginalContactNo { get; set; }
        [MappingInfo(ColumnName = "ThirtParyResult")]
        public string ThirtParyResult { get; set; }
    }

    public class CustomerResponseViewModel:BaseModel 
    {
        public List<CustomerResponseModel> CustomerResponces { get; set; }
        
        
    }
}
