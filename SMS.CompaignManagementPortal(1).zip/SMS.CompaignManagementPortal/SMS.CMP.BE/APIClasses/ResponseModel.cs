﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.APIClasses
{
    [Serializable]
   public  class ResponseModel
    {
        public string ReplyMessage{get;set;}
        public string ReplyPhoneNumber { get; set; }
        public string ResponseDate { get; set; }
        public string ShortCode { get; set; }
        public string ResponseMessage { get; set; }
        public string ID { get; set; }
        public string ConfirmationCode { get; set; }

    }
}
