﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.APIClasses
{

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <30-11-2015 12:00 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription

// =================================================================================================================================
    public class SearchModel
    {

        public int? OrganizaitonID  { get; set; }
        public int? DepartmentID { get; set; }
        public int? UserID { get; set; }
        public int? CampaignID { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
        public string FromDate  { get; set; }
        public string Todate  { get; set; }
        public string SearchText  { get; set; }
    }
}
