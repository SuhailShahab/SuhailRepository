﻿using SMS.CMP.BE.CustomExcetion.APIExcetion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.CMP.BE.APIClasses
{
   public  class SMSValidation
    {
       public void CheckValidSMS(string phoneNumber)
       {

           if (!string.IsNullOrEmpty(phoneNumber) && phoneNumber.Length > 13)
               {
                   throw new InvalidPhoneNo("Phone digit exceed form 12 digits","ExcessDitigs");
               }
           else if (!string.IsNullOrEmpty(phoneNumber) && phoneNumber.Length < 11)
               {
                   throw new InvalidPhoneNo("Phone digit less than form 11 digits", "LessDigits");
               }
           else if (!string.IsNullOrEmpty(phoneNumber))
               {
                   foreach (char c in phoneNumber)
                   {
                       if (c < '0' || c > '9')
                           throw new InvalidPhoneNo("Phone number is not a valid number.Phone number should be only digit." + phoneNumber, "IsAlphaNumber");
                   }

               }

       }
    }
}
