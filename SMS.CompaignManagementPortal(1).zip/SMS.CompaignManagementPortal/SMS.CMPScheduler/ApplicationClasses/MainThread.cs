﻿using BLL.Common;
using SMS.CMP.BLL.CMP;
using SMS.CMP.BLL.SchedulerInfo;
using SMS.CMPScheduler.ApplicationClassess;
using SMS.CMPScheduler.ApplicationClassess.Log;
using System;
using System.IO;
using System.Net;
using System.Threading;

// =================================================================================================================================
// Create by:	<Suhail Shahab>
// Create date: <21-10-2015 07:47:38>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time          Desription
//CR:001            SUHAIL SHAHAB                   26-06-2015                  Add Email functionality
// =================================================================================================================================
namespace SMS.CMPScheduler.ApplicationClasses
{
    public class MainThread
    {

        int reTrytoSendSms = 0;
        /// <summary>
        /// Create the Main Thread
        /// </summary>
        public void StartThread()
        {
            Thread mT = new Thread(ExecuteMain);
            mT.Start();
        }

        /// <summary>
        /// Main Tread Start the process
        /// </summary>
        //public void Main()
        //{
        //    string webForntEnd = ConfigurationHelper.IPSecondWebFornt; //"192.168.10.3";
        //    WebForntNames currentRunningWebFornt = CommonHelper.GetWebForntEnum(ConfigurationHelper.CurrentRuningWebFront);     // WebForntNames.WEB_FORNT1;
        //    WebForntNames secodWebFornt = CommonHelper.GetWebForntEnum(ConfigurationHelper.SecondWebFront);     // WebForntNames.WEB_FORNT2;
        //    bool? isTransportError =null;
        //    try
        //    {
        //        Console.WriteLine("Start Application...");
        //        B2BayLogger.WriteLogsToFile();
        //        while (true)
        //        {
        //            Console.WriteLine("Applciation start version no: 018....");
        //            B2BayLogger.Log("Applciation start version no: 018....");
        //            Thread.Sleep(2000);

        //            // string applicationName = AppDomain.CurrentDomain.SetupInformation.ApplicationName;
        //            // Console.WriteLine(applicationName);
        //            bool isPinged = CommonHelper.PingHost(webForntEnd);         // check primary server
        //            if (isPinged)
        //            {
        //                Console.WriteLine("Check Active Web Fornt.");
        //                bool isActiveServer = LazySingletonBLL<ServerInfoBLL>.Instance.IsActiveServer(secodWebFornt.GetHashCode());
                      
        //               // throw new Exception("A transport-level error");
        //                if (!isActiveServer)
        //                {
        //                    B2BayLogger.Log("Applciation Start");
        //                    Thread.Sleep(ConfigurationHelper.MaxRequestDelay);

        //                    if (LazySingletonBLL<SMSCampaignBLL>.Instance.IsExistStartCampaignInfo())
        //                    {
        //                        Console.WriteLine("Send Request for Starting Campaign.");
        //                        Thread.Sleep(1000);

        //                        B2BayLogger.Log("Send Request for Starting Campaign.");
        //                        this.SendSmsToClient(ConfigurationHelper.HostingUrl);       //Call web service method

        //                        B2BayLogger.Log("Request Send Successfully");
        //                        Console.WriteLine("Request Send Successfully");

        //                        B2BayLogger.WriteLogsToFile();
        //                        Thread.Sleep(1000);
        //                    }
        //                    else
        //                    {
        //                        Console.WriteLine("No Campgin Exist");
        //                        Thread.Sleep(6000);
        //                    }

        //                }
        //                else
        //                {
        //                    Console.WriteLine("Another Web Front End server is Active.");
        //                    B2BayLogger.Log("Another Web Front End server is Active.");
        //                    B2BayLogger.WriteLogsToFile();
        //                    int maxDelay = ConfigurationHelper.MaxRequestDelay * 2;
        //                    Thread.Sleep(maxDelay);
        //                }

        //                //Reset Try 
        //                reTrytoSendSms = 0;
        //            }
        //            else //not runing
        //            {
        //                Console.WriteLine("Check Active Web Fornt.");
        //                bool isActiveServer = LazySingletonBLL<ServerInfoBLL>.Instance.IsActiveServer(secodWebFornt.GetHashCode());
        //                if (!isActiveServer)
        //                {
        //                    Thread.Sleep(ConfigurationHelper.MaxRequestDelay);

        //                    if (LazySingletonBLL<SMSCampaignBLL>.Instance.IsExistStartCampaignInfo())
        //                    {
        //                        Console.WriteLine("Send Request for Starting Campaign.");
        //                        B2BayLogger.Log("Send Request for Starting Campaign.");

        //                        this.SendSmsToClient(ConfigurationHelper.HostingUrl);       //==Call web service method
        //                        B2BayLogger.WriteLogsToFile();

        //                        B2BayLogger.Log("Request Send Successfully");
        //                        Console.WriteLine("Request Send Successfully");

        //                        Thread.Sleep(1000);
        //                    }
        //                    else
        //                    {
        //                        Console.WriteLine("No Campaign Exist....");
        //                        Thread.Sleep(6000);
        //                    }
        //                }
        //                else if (isActiveServer)
        //                {
        //                    Console.WriteLine("Update Active Server");
        //                    LazySingletonBLL<ServerInfoBLL>.Instance.UpdateServerActive(currentRunningWebFornt.GetHashCode());
        //                }

        //                //Reset Try 
        //                if (reTrytoSendSms>0)
        //                {
        //                    reTrytoSendSms = 0;
        //                    WirteLogAndConsole("Reset Try to zeor");
                           
        //                }
                       
        //            }

        //            B2BayLogger.WriteLogsToFile();
        //        }
        //        //End of While
        //        //if (ConfigurationHelper.EnableEMailNotification)
        //        //    CommonHelper.SendNotificationEmail("Schulder have been Stop due to some issue");
        //        //Environment.Exit(0);
        //    }
        //    catch (Exception e)
        //    {

        //        if (e.Message.Contains("A transport-level error") || e.Message.Contains("network-related or instance-specific error"))
        //        {
        //            reTrytoSendSms++;
        //            isTransportError = true;
        //        }
        //        else
        //        {
        //            isTransportError = false;
        //        }
        //        B2BayLogger.LogErr("Error:", e);
        //        Console.WriteLine(e.Message);
        //        B2BayLogger.WriteLogsToFile();

        //        // ============================================ Send Email Notification ============================================ //
        //        if (isTransportError.HasValue && !isTransportError.Value && ConfigurationHelper.EnableEMailNotification)
        //        {
        //            CommonHelper.SendNotificationEmail(e.Message);
        //        }
                    
        //    }
        //    finally
        //    {
        //        //==============Retry to send SMS==============

        //        if (isTransportError.HasValue && isTransportError.Value)
        //        {
        //            if (reTrytoSendSms > 3)
        //            {

        //                if (ConfigurationHelper.EnableEMailNotification)
        //                    CommonHelper.SendNotificationEmail(" CMP Schulder have been Deleay 5 min due to Tranport Error");
        //                this.LogAndMessage("Deleay 5 min due to Tranport Error");
        //                B2BayLogger.WriteLogsToFile();
        //                Thread.Sleep(300000);
        //                this.Main();
        //            }
        //            else
        //            {
                       
        //                WirteLogAndConsole("Re Try to run (" + reTrytoSendSms.ToString() + ")");
        //                Thread.Sleep(2000);                     
        //                this.Main();
                       
        //            }

        //        }
        //        else
        //        {
        //            if (ConfigurationHelper.EnableEMailNotification)
        //                CommonHelper.SendNotificationEmail(" CMP  Schulder have been Stop due to some issue. Will be restart after 5 min");
        //            // Environment.Exit(0);
        //            this.LogAndMessage("Deleay 5 min due to unknow Error");
        //            B2BayLogger.WriteLogsToFile();
        //            Thread.Sleep(300000);
        //            this.Main();
        //        }
        //        //==============END Retry to send SMS==============
        //    }
        //    //if (ConfigurationHelper.EnableEMailNotification)
        //    //    CommonHelper.SendNotificationEmail("Schulder have been Stop due to some issue");
        //    //Environment.Exit(0);
        //}
        public void ExecuteMain()
        {
            bool? isTransportError = null;
            try
            {
                Console.WriteLine("Start Application...");
               
                while (true)
                {
                    Console.WriteLine("Applciation start version no: 020....");
                    B2BayLogger.Log("Applciation start version no: 020...");
                    Thread.Sleep(2000);



                    // throw new Exception("A transport-level error");

                    B2BayLogger.Log("Applciation Start (Campaign Scheduler)");
                    Thread.Sleep(ConfigurationHelper.MaxRequestDelay);

                    if (LazySingletonBLL<SMSCampaignBLL>.Instance.IsExistStartCampaignInfo())
                    {
                        Console.WriteLine("Send Request for Starting Campaign.");
                        Thread.Sleep(1000);

                        B2BayLogger.Log("Send Request for Starting Campaign.");
                        this.SendSmsToClient(ConfigurationHelper.HostingUrl);       //Call web service method

                        B2BayLogger.Log("Request Send Successfully");
                        Console.WriteLine("Request Send Successfully");

                       // B2BayLogger.WriteLogsToFile();
                        Thread.Sleep(1000);
                    }
                    else
                    {
                        Console.WriteLine("No Campgin Exist");
                        B2BayLogger.Log("No Campgin Exist");
                        Thread.Sleep(6000);
                    }


                    reTrytoSendSms = 0;


                    B2BayLogger.WriteLogsToFile();
                }

            }
            catch (Exception e)
            {

                if (e.Message.Contains("A transport-level error") || e.Message.Contains("network-related or instance-specific error"))
                {
                    reTrytoSendSms++;
                    isTransportError = true;
                }
                else
                {
                    isTransportError = false;
                }
                B2BayLogger.LogErr("Error:", e);
                B2BayLogger.Log(e.Message);
                Console.WriteLine(e.Message);
                B2BayLogger.WriteLogsToFile();
                // ============================================ Send Email Notification ============================================ //
                CommonHelper.SendNotificationEmail(e.Message);

            }
            finally
            {
                //==============Retry to send SMS==============

                if (isTransportError.HasValue && isTransportError.Value)
                {
                    if (reTrytoSendSms > 3)
                    {

                        if (ConfigurationHelper.EnableEMailNotification)
                            CommonHelper.SendNotificationEmail(" CMP Schulder have been Deleay 5 min due to Tranport Error");
                        this.LogAndMessage("Deleay 5 min due to Tranport Error");
                        B2BayLogger.WriteLogsToFile();
                        Thread.Sleep(300000);
                        this.ExecuteMain();
                    }
                    else
                    {

                        WirteLogAndConsole("Re Try to run (" + reTrytoSendSms.ToString() + ")");
                        CommonHelper.SendNotificationEmail(" CMP  Schulder have been Stop due to some issue. Will be restart after 5 min");
                        B2BayLogger.WriteLogsToFile();
                        Thread.Sleep(2000);
                        this.ExecuteMain();

                    }

                }
                else
                {
                    if (ConfigurationHelper.EnableEMailNotification)
                        CommonHelper.SendNotificationEmail(" CMP  Schulder have been Stop due to some issue. Will be restart after 5 min");
                    // Environment.Exit(0);
                    this.LogAndMessage("Deleay 5 min due to unknow Error");
                    B2BayLogger.WriteLogsToFile();
                    Thread.Sleep(300000);
                    this.ExecuteMain();
                }
                //==============END Retry to send SMS==============
            }
           
        }
      

        #region Custom Methods
        public void LogAndMessage(string message)
        {
            Console.WriteLine(message);
            B2BayLogger.Log(message);
        }
        private static void WirteLogAndConsole(string message)
        {
            Console.WriteLine(message);
            B2BayLogger.Log(message);
            B2BayLogger.WriteLogsToFile();
        }
        private static void SetLogAndConsole(string message)
        {
            Console.WriteLine(message);
            B2BayLogger.Log(message);

        }
        private bool SendSmsToClient(string hostURI)
        {
            if (ConfigurationHelper.LoadDataAsync)
            {
                
                Console.WriteLine("LoadDataAsync");
                 return LoadDataAsync(hostURI);
            }               
            else
            {
                Console.WriteLine("SendWebReq");
                return SendWebReq(hostURI);
               
            }
              
        }

        private static bool SendWebReq(string hostURI)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(hostURI);
            request.Method = "GET";
            String test = String.Empty;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                test = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();

                return true;
            }
        }

        public static bool LoadDataAsync(string url)
        {
            using (var client = new WebClient())
            {
               
                client.DownloadStringAsync(new Uri(url));
            }
            return true;
        }

        #endregion

      
    }
}
