﻿using System;
using System.Text;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <21-10-2015 07:47:38PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPScheduler.ApplicationClasses.SMSRequest
{
    public class SMSSendRequest
    {
        public int? CampaignID { get; set; }
        public int? OrganizationID { get; set; }
        public int? ShortCode { get; set; }

        public bool SendSMS()
        {
            return true;
        }
    }
}
