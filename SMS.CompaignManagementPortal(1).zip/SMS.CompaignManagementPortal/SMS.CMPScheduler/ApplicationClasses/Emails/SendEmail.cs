﻿using SMS.CMPScheduler.ApplicationClassess;
using SMS.CMPScheduler.ApplicationClassess.Log;
using System;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <21-10-2015 07:47:38PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPScheduler.ApplicationClasses.Emails
{
    public class SendEmail
    {
        /// <summary>
        /// E-Mail send to user
        /// </summary>
        /// <param name="receiver"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        public void MailSend(string subject, string body)
        {
            try
            {
                string Sender = ConfigurationHelper.EMailSenderAddress;
                string SenderPassword = ConfigurationHelper.EMailSenderPassword;    // ConfigurationManager.AppSettings["EMailSenderPassword"].ToString();
                string MailServer = ConfigurationHelper.SMTPServer;                 // ConfigurationManager.AppSettings["SMTPServer"].ToString();
                int MailServerPort = ConfigurationHelper.SMTPServerPort;            // Convert.ToInt16(ConfigurationManager.AppSettings["SMTPServerPort"].ToString());
                bool EnableSSL = ConfigurationHelper.SMTPEnableSSL;                 // Convert.ToBoolean(ConfigurationManager.AppSettings["SMTPEnableSSL"].ToString().ToLower());
                bool EnableEmail = ConfigurationHelper.EnableEMailNotification;     // Convert.ToBoolean(ConfigurationManager.AppSettings["EnableEMailNotification"].ToString().ToLower());

                if (EnableEmail)
                {
                    MailMessage mM = new MailMessage();

                    mM.From = new MailAddress(Sender);  // set email sender
                    if (!string.IsNullOrEmpty(ConfigurationHelper.SendToEmailAddress))
                    {
                        string[] receiverEmailAddresses = ConfigurationHelper.SendToEmailAddress.Split('^');
                        for (int i = 0; i < receiverEmailAddresses.Length; i++)
                        {
                            mM.To.Add(receiverEmailAddresses[i]);
                        }
                    }

                    // set receiver email
                    if (!string.IsNullOrEmpty(ConfigurationHelper.TOCC_EmailAddress))
                    {
                        string[] emailAddresses = ConfigurationHelper.TOCC_EmailAddress.Split('^');
                        for (int i = 0; i < emailAddresses.Length; i++)
                        {
                            mM.CC.Add(emailAddresses[i]);
                        }
                    }

                    if (!string.IsNullOrEmpty(ConfigurationHelper.TOBC_EmailAddress))
                    {
                        string[] emailAddresses = ConfigurationHelper.TOBC_EmailAddress.Split('^');
                        for (int i = 0; i < emailAddresses.Length; i++)
                        {
                            mM.Bcc.Add(emailAddresses[i]);
                        }
                    }

                    mM.Subject = subject;   // set email subject
                    mM.Body = body;         // set email body
                    mM.IsBodyHtml = true;

                    // open smtp client 
                    SmtpClient Server = new SmtpClient(MailServer, MailServerPort);
                    Server.UseDefaultCredentials = true;
                    Server.Credentials = new System.Net.NetworkCredential(Sender, SenderPassword);
                    Server.Port = MailServerPort;   // set port number
                    Server.Host = MailServer;
                    Server.EnableSsl = EnableSSL;
                    Server.DeliveryMethod = SmtpDeliveryMethod.Network;

                    //Added this to bypass the certificate validation
                    ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                    Server.Send(mM);    // send email

                    mM.Dispose();

                    // TestEmail();
                }
            }
            catch (Exception ex)
            {
                B2BayLogger.LogErr("Error", ex);
            }
        }

        #region "Private Methods"

        private static void TestEmail()
        {
            MailMessage mail = new MailMessage();
            mail.To.Add("shahabsohail@hotmail.com");
            mail.From = new MailAddress("suhailshahab7@gmail.com");
            mail.Subject = "test";
            mail.Body = "test";
            mail.IsBodyHtml = true;

            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address//smtp.Port = 465;//smtp.UseDefaultCredentials = true;
            smtp.Credentials = new System.Net.NetworkCredential("suhailshahab7@gmail.com", "ssfarhan");
            //smtp.EnableSsl = true;
            smtp.Timeout = 30000000;
            //smtp.//smtp.ServicePoint.MaxIdleTime = System.Threading.Timeout.Infinite;//1;//Or your Smtp Email ID and Password
            smtp.EnableSsl = true;
            smtp.Send(mail);
        }

        #endregion
    }
}
