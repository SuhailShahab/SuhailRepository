﻿using SMS.CMPScheduler.ApplicationClasses;
using SMS.CMPScheduler.ApplicationClassess;
using SMS.CMPScheduler.ApplicationClassess.Log;
using System;

// =================================================================================================================================
// Create by:	<Sohail Sahab>
// Create date: <21-10-2015 07:47:38PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                     Modified Date/Time              Desription
// =================================================================================================================================
namespace SMS.CMPScheduler
{
    class Program
    {
        static void Main(string[] args)
        {
            string applicationName = AppDomain.CurrentDomain.SetupInformation.ApplicationName;

            try
            {
               // AppDomain.CurrentDomain.ProcessExit += ProcessExitHandler;
               // B2BayLogger.WriteLogsToFile();

                bool IsNewApplciationExecute = CommonHelper.IsNewApplciationRunning(applicationName);

                if (IsNewApplciationExecute)
                {
                    new MainThread().StartThread();
                    Console.Read();
                }
                else
                {
                    B2BayLogger.Log("Applicaton already running.");
                    Console.WriteLine("Applicaton already running.");
                    B2BayLogger.WriteLogsToFile();
                    //B2BayLogger.WriteLogsToFileCheckExe();
                    Environment.Exit(0);
                }
            }
            catch (Exception ex)
            {
                B2BayLogger.LogErr("There is some error.Please detail.", ex);
                B2BayLogger.WriteLogsToFile();

                if (ConfigurationHelper.EnableEMailNotification)
                    CommonHelper.SendNotificationEmail(ex.Message);
            }
        }
        static void ProcessExitHandler(object sender, EventArgs e)
        {
            CommonHelper.SendNotificationEmail("Application stop due to some issue.IP Address 10.52.98.218 ");
        }
    }
}
