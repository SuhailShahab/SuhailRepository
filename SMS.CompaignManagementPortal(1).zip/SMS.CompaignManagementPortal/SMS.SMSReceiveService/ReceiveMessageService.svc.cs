﻿using SMS.SMSReceiveService.ApplicationClasses.Log;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace SMS.SMSReceiveService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ReceiveMessageService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select ReceiveMessageService.svc or ReceiveMessageService.svc.cs at the Solution Explorer and start debugging.
    public class ReceiveMessageService : IReceiveMessageService
    {
        public void DoWork()
        {
            B2BayLogger.Log("Test Send Response");
            B2BayLogger.WriteLogsToFile();
        }
        //public string SendRespone()
        //{
        //    //WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
        //    B2BayLogger.Log("Send Response");
        //    B2BayLogger.WriteLogsToFile();
        //    //B2BayLogger.Log("ReplyPhoneNumber" + model.ReplyPhoneNumber);
        //    //B2BayLogger.WriteLogsToFile();
        //    //B2BayLogger.Log("ReplyMessage" + model.ReplyMessage);
        //    //B2BayLogger.WriteLogsToFile();
        //    //B2BayLogger.Log("ReponseDate" + model.ResponseDate);
        //    B2BayLogger.WriteLogsToFile();
        //    return "Received";
        //}

        public string SendRespone(CMP.BE.APIClasses.ResponseModel model)
        {
            WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
            B2BayLogger.Log("Send Response");
            B2BayLogger.WriteLogsToFile();
            B2BayLogger.Log("ReplyPhoneNumber" + model.ReplyPhoneNumber);
            B2BayLogger.WriteLogsToFile();
            B2BayLogger.Log("ReplyMessage" + model.ReplyMessage);
            B2BayLogger.WriteLogsToFile();
            B2BayLogger.Log("ReponseDate" + model.ResponseDate);
            B2BayLogger.WriteLogsToFile();
            return "Received";
        }
    }
}
