﻿using SMS.CMP.BE.APIClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace SMS.SMSReceiveService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IReceiveMessageService" in both code and config file together.
    [ServiceContract]
    public interface IReceiveMessageService
    {
        [OperationContract]
        [WebGet(UriTemplate = "DoWork")]
        void DoWork();
        //[OperationContract]
        //[WebInvoke(
        //    ResponseFormat = WebMessageFormat.Json,
        //    RequestFormat = WebMessageFormat.Json,
        //    BodyStyle = WebMessageBodyStyle.Bare,
        //    Method = "POST",
        //    UriTemplate = "SendSMSData/{campaignID}/{organizationgID}")]
        //void SendSMSData(string campaignID, string organizationgID, SMSMessageModel message);
        [OperationContract]
        [WebInvoke(
            ResponseFormat = WebMessageFormat.Xml,
            RequestFormat = WebMessageFormat.Json,
            BodyStyle = WebMessageBodyStyle.Bare,
            Method = "POST",
            UriTemplate = "SendRespone")]
        //string SendRespone();
        string SendRespone(ResponseModel model);
    }   

}
