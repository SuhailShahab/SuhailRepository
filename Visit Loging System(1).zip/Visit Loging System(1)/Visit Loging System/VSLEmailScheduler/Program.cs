﻿using BE.LogManager;
using BLL.CommonUtility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VSLEmailScheduler.ApplicationClasses;
using VSLEmailScheduler.ApplicationClasses.Log;

namespace VSLEmailScheduler
{
    class Program
    {
        static void Main(string[] args)
        {
            string codeBase = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
            string applicationName = System.IO.Path.GetFileNameWithoutExtension(codeBase);


            try
            {
                B2BayLogger.WriteLogsToFile();

                bool IsNewApplciationExecute = LazySingleton<CommonUtil>.Instance.IsNewApplciationRunning(applicationName);

                if (IsNewApplciationExecute)
                {
                    new MainThread().StartThread();
                    Console.Read();
                }
                else
                {
                    B2BayLogger.Log("Applicaton already running.");
                    Console.WriteLine("Applicaton already running.");
                    B2BayLogger.WriteLogsToFile();
                    Environment.Exit(0);
                }
            }
            catch (Exception ex)
            {
                B2BayLogger.LogErr("There is some error.Please detail.", ex);
                B2BayLogger.WriteLogsToFile();

                if (ConfigurationHelper.EnableEMailNotification)
                    LazySingleton<CommonUtil>.Instance.MailSend("Notification of Stoppoing VLS Email Schduler", ConfigurationHelper.Location + " Email Queue Schulder have been Stop due to some issue" + ex.Message);
                LazySingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Save", "FVMS Email Scheduler"));
                
            }
        }
    }
}
