﻿using BE.EmailQueue;
using BE.EmailScheduler;
using BLL.CommonUtility;
using BLL.EmailScheduler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using VSLEmailScheduler.ApplicationClasses.Log;

namespace VSLEmailScheduler.ApplicationClasses
{
    public class MainThread
    {
        /// <summary>
        /// Create the Main Thread
        /// </summary>
        public void StartThread()
        {
            Thread mT = new Thread(Main);
            mT.Start();
        }

        public void Main()
        {

            try
            {
                while (true)
                {
                    Console.WriteLine("Applciation start version no: 0001....");
                    Thread.Sleep(1000);
                    // Console.WriteLine("HostingIP Address" + ConfigurationHelper.HostingIP);


                    Console.WriteLine("=============Get New Not Visit Logs ============================");

                    int? results = LazyBaseSingletonBLL<NotVisitLogBLL>.Instance.AddNotVistLog(ConfigurationHelper.NoOfDays);
                    Thread.Sleep(200);
                    List<NotVisitLogModel> notVisitLogs = LazyBaseSingletonBLL<NotVisitLogBLL>.Instance.GetAllNewNotVisitLogs(1000);

                    if (notVisitLogs != null && notVisitLogs.Count > 0)
                    {

                        //=========Get Email & SMS Template =========================

                      EmailSMSTemplateModel emailSMSTemplateModel = LazyBaseSingletonBLL<EmailSMSTemplateBLL>.Instance.GetEmailSMSTemplateByID(EmailSMSTemplateName.NotVistSecrityTemplate.GetHashCode());
                      if (emailSMSTemplateModel != null)
                      {
                          
                          LogAndConsoleWriteLine("=======================Template Information ============================");

                          Console.WriteLine("Templat Name" + EmailSMSTemplateName.NotVistSecrityTemplate.ToString());
                          B2BayLogger.Log("Templat Name" + EmailSMSTemplateName.NotVistSecrityTemplate.ToString());

                          Console.WriteLine("Templat Subject" + emailSMSTemplateModel.EmailSubject);
                          B2BayLogger.Log("Templat Subject" + emailSMSTemplateModel.EmailSubject);

                          Console.WriteLine("Templat Subject" + emailSMSTemplateModel.EmailSubject);
                          B2BayLogger.Log("Templat Subject" + emailSMSTemplateModel.EmailSubject);

                          LogAndConsoleWriteLine("Templat SMS" + emailSMSTemplateModel.SMSMessage);

                          LogAndConsoleWriteLine("=======================End Template Information ============================");
                          //============================================================
                          string strEmail = string.Empty;
                          string totalEmail = "=================Total New  Not visit log for Emaills: " + notVisitLogs.Count + "======================";
                          Console.WriteLine(totalEmail);
                          B2BayLogger.Log(totalEmail);
                          Console.WriteLine("==Start Sending To Email Queue....==========================");
                          StringBuilder sbInfo = new StringBuilder();
                          foreach (NotVisitLogModel item in notVisitLogs)
                          {

                              sbInfo.AppendLine("===================================================");
                              sbInfo.AppendLine("==Log ID:" + item.ID + "=========================");
                              sbInfo.AppendLine("==CNIC:" + item.CNIC + "=========================");
                              sbInfo.AppendLine("==Employee Name:" + item.EmployeeName + "=========================");
                              sbInfo.AppendLine("==Employee Email:" + item.Email + "=========================");
                              Console.WriteLine(sbInfo.ToString());
                              Console.WriteLine(sbInfo.ToString());
                              B2BayLogger.Log(sbInfo.ToString());

                              sbInfo.Clear();
                              try
                              {

                                  Console.WriteLine("=======Send Email to SMS Queue========================= ");
                                  B2BayLogger.Log("=======Send Email to SMS Queue=========================== ");
                                  EmailModel emailModel = new EmailModel(emailSMSTemplateModel.EmailSubject, emailSMSTemplateModel.EmailBoday);
                                  emailModel.ToEmailAddresses = new List<string>();
                                  emailModel.ToEmailAddresses.Add(item.Email);
                                  Thread.Sleep(200);
                                  if (ConfigurationHelper.SendEmailFormQueue)
                                  {
                                      //Send email from Queue
                                      LazyBaseSingletonBLL<CommonUtil>.Instance.SendEmailToQueue(emailModel);
                                  }
                                  else
                                  {
                                      //Send Direct email 
                                      LazySingleton<CommonUtil>.Instance.MailSend(emailModel);
                                  }

                                  Console.WriteLine("=======Send Successfully Email to SMS Queue============ ");
                                  B2BayLogger.Log("=======Send Successfully Email to SMS Queue============== ");

                                  //================Send SMS Altert ===========================================

                                  try
                                  {
                                      if (!string.IsNullOrEmpty(item.CellNumber))
                                      {
                                          LogAndConsoleWriteLine("========Sending SMS At No==" + item.CellNumber);
                                          LazySingleton<CommonUtil>.Instance.SendSMSAlert(item.CellNumber, emailSMSTemplateModel.SMSMessage);
                                          LogAndConsoleWriteLine("========Sending SMS Successfully");
                                      }
                                  }
                                  catch (Exception ex)
                                  {
                                      B2BayLogger.Log("=======SMS not Send============== ");
                                      B2BayLogger.Log("Error SMS sending:" + ex.Message);
                                  }
                                 

                                  NotVisitLogModel notVisitLogModel = new NotVisitLogModel();
                                  notVisitLogModel.StatusID = StatusNames.SendSuccessfully.GetHashCode();
                                  notVisitLogModel.ID = item.ID;
                                  notVisitLogModel.Message = "Send Successfully";
                                  LazyBaseSingletonBLL<NotVisitLogBLL>.Instance.UpdateStatus(notVisitLogModel);
                              }
                              catch (Exception ex)
                              {
                                  Console.WriteLine("==================Error: " + ex.Message + "===");
                                  B2BayLogger.LogErr("=================Error: " + ex.Message + "===", ex);
                                  B2BayLogger.WriteLogsToFile();
                                  NotVisitLogModel notVisitLogModel = new NotVisitLogModel();
                                  notVisitLogModel.StatusID = StatusNames.SomeError.GetHashCode();
                                  notVisitLogModel.ID = item.ID;
                                  notVisitLogModel.Message = "Fail to Send" + ex.Message;
                                  LazyBaseSingletonBLL<NotVisitLogBLL>.Instance.UpdateStatus(notVisitLogModel);

                              }

                          }
                      }
                      else
                      {
                          //Email and SMS Template is Missing
                          LogAndConsoleWriteLine("========Email and SMS Template is Missing=================");

                      }

                    }


                    //=======================Check New Email is Exist============================================
                    Console.WriteLine("=======Check New Log is Exists============ ");
                    B2BayLogger.Log("=======Check New Log is Exists============ ");
                    bool? isNewLogExist = LazyBaseSingletonBLL<NotVisitLogBLL>.Instance.IsNewNotVistLogExist();

                    if (isNewLogExist.HasValue && !isNewLogExist.Value)
                    {
                        int? noOfRowsDelted = LazyBaseSingletonBLL<NotVisitLogBLL>.Instance.DeleteAllSendEmail(ConfigurationHelper.NoOfDays);
                        Console.WriteLine("=======Not Log Exist for sending email...============ ");
                        B2BayLogger.Log("=======Not Log Exist for sending email...============ ");
                        Thread.Sleep(200);
                       //Exsit form Application 
                        B2BayLogger.WriteLogsToFile();
                        Environment.Exit(0);
                    }
                    else
                    {
                        Console.WriteLine("================New Email Exist==================================");
                        B2BayLogger.Log("================New Email Exist==================================");
                    }


                    B2BayLogger.WriteLogsToFile();
                }
                //End of While
                //if (ConfigurationHelper.EnableEMailNotification)
                //    CommonHelper.SendNotificationEmail("SMS Queue Schulder have been Stop due to some issue");
                // Environment.Exit(0);
            }
            catch (Exception e)
            {
                B2BayLogger.LogErr("Error:", e);
                Console.WriteLine(e.Message);
                B2BayLogger.WriteLogsToFile();

                // ============================================ Send Email Notification ============================================ //
                if (ConfigurationHelper.EnableEMailNotification)
                    LazySingleton<CommonUtil>.Instance.MailSend("Notification of Stoppoing VLS Email Schduler",ConfigurationHelper.Location + " Email Queue Schulder have been Stop due to some issue" + e.Message);
            }
            
            Environment.Exit(0);
        }

        private static void LogAndConsoleWriteLine(string message)
        {
            B2BayLogger.Log(message);
            Console.WriteLine(message);
        }
    }
}
