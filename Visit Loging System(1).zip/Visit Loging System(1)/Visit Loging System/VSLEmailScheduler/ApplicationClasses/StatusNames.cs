﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSLEmailScheduler.ApplicationClasses
{
   public enum  StatusNames:int
    {
       None=0,
       NewNotVisitLog =1,
       UnderProcess =2,
       SendSuccessfully=3,
       SomeError=4,
       ReadyToResend =5
    }
}
