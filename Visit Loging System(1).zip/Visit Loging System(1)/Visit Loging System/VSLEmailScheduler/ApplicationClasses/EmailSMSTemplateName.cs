﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSLEmailScheduler.ApplicationClasses
{
    public enum  EmailSMSTemplateName:int
    {
        None=0,
        NotVistSecrityTemplate =1
    }
}
