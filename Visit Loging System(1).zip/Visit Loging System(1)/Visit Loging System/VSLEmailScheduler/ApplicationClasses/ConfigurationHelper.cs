﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VSLEmailScheduler.ApplicationClasses
{
  public   class ConfigurationHelper
    {


      public static bool  SendEmailFormQueue
      {
          get
          {
              return Convert.ToBoolean(ConfigurationManager.AppSettings["SendEmailFormQueue"]);
          }
      }



      public static string EmailQueueURL
      {
          get
          {
              return ConfigurationManager.AppSettings["EmailQueueURL"];
          }
      }

      public static string LogFilePath
      {
          get
          {
              return ConfigurationManager.AppSettings["LogFilePath"];
          }
      }

      //public static string NoVisitEmailSubject
      //{
      //    get
      //    {
      //        return ConfigurationManager.AppSettings["NoVisitEmailSubject"];
      //    }
      //}

      //public static string NoVisitEmailBody
      //{
      //    get
      //    {
      //        return ConfigurationManager.AppSettings["NoVisitEmailBody"];
      //    }
      //}

      public static bool ShowLog
      {
          get
          {
              return Convert.ToBoolean(ConfigurationManager.AppSettings["ShowLog"]);
          }
      }

      public static int? NoOfDays
      {
          get
          {
              if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["NoOfDays"]))
              {
                  return null;
              }
              else
              {
                  return Convert.ToInt32(ConfigurationManager.AppSettings["NoOfDays"]);
              }
            
          }
      }

      public static bool EnableEMailNotification
      {
          get
          {
              return Convert.ToBoolean(ConfigurationManager.AppSettings["EnableEMailNotification"]);
          }
      }

      public static string SendToEmailAddress
      {
          get
          {
              return Convert.ToString(ConfigurationManager.AppSettings["SendToEmailAddress"]);
          }
      }

      public static string TOCC_EmailAddress
      {
          get
          {
              return Convert.ToString(ConfigurationManager.AppSettings["TOCC_EmailAddress"]);
          }
      }

      public static string TOBC_EmailAddress
      {
          get
          {
              return Convert.ToString(ConfigurationManager.AppSettings["TOBC_EmailAddress"]);
          }
      }

      public static string Location
      {
          get
          {
              return Convert.ToString(ConfigurationManager.AppSettings["Location"]);
          }
      }

      public static int? TopRecord
      {
          get
          {
              if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["TopRecord"]))
                  return Convert.ToInt32(ConfigurationManager.AppSettings["TopRecord"]);
              else
                  return null;
          }
      }



      public static string EMailSenderAddress
      {
          get
          {
              return Convert.ToString(ConfigurationManager.AppSettings["EMailSenderAddress"]);
          }
      }

      public static string EMailSenderPassword
      {
          get
          {
              return Convert.ToString(ConfigurationManager.AppSettings["EMailSenderPassword"]);
          }
      }

      public static string SMTPServer
      {
          get
          {
              return Convert.ToString(ConfigurationManager.AppSettings["SMTPServer"]);
          }
      }

      public static int SMTPServerPort
      {
          get
          {
              return Convert.ToInt32(ConfigurationManager.AppSettings["SMTPServerPort"]);
          }
      }

      public static bool SMTPEnableSSL
      {
          get
          {
              return Convert.ToBoolean(ConfigurationManager.AppSettings["SMTPEnableSSL"]);
          }
      }

      public static string  SMSGatewayURL
      {
          get
          {
              return Convert.ToString(ConfigurationManager.AppSettings["SMSGatewayURL"]);
          }
      }

      
      
    }
}
