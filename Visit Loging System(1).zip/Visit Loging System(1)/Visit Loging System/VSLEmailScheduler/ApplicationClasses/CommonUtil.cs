﻿using BE;
using BE.EmailQueue;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using VSLEmailScheduler.ApplicationClasses.Log;

namespace VSLEmailScheduler.ApplicationClasses
{
   public  class CommonUtil
    {
       public void SendEmailToQueue(EmailModel emailModel)
       {
           
           string Data = "";

           try
           {
               // serailze model object to json string
               DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(EmailModel));
               MemoryStream mem = new MemoryStream();
               ser.WriteObject(mem, emailModel);
               Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

               // process the request and get response as string
               string serviceURL = ConfigurationHelper.EmailQueueURL;

               WebClient webClient = new WebClient();
               webClient.Headers["Content-type"] = "application/json";
               webClient.Encoding = Encoding.UTF8;

               Uri address = new Uri(serviceURL);
               webClient.UploadString(address, "POST", Data);
           }
           catch (Exception ex)
           {
               throw new Exception("SMS alert fail. " + ex.Message);
           }
       }

       public void MailSend(string subject, string body)
       {
           try
           {
               string Sender = ConfigurationHelper.EMailSenderAddress;
               string SenderPassword = ConfigurationHelper.EMailSenderPassword;
               string MailServer = ConfigurationHelper.SMTPServer;
               int MailServerPort = ConfigurationHelper.SMTPServerPort;
               bool EnableSSL = ConfigurationHelper.SMTPEnableSSL;
               bool EnableEmail = ConfigurationHelper.EnableEMailNotification;

               if (EnableEmail)
               {
                   MailMessage mM = new MailMessage();

                   mM.From = new MailAddress(Sender);  // set email sender
                   if (!string.IsNullOrEmpty(ConfigurationHelper.SendToEmailAddress))
                   {
                       string[] receiverEmailAddresses = ConfigurationHelper.SendToEmailAddress.Split('^');
                       for (int i = 0; i < receiverEmailAddresses.Length; i++)
                       {
                           mM.To.Add(receiverEmailAddresses[i]);
                       }
                   }

                   // set receiver email
                   if (!string.IsNullOrEmpty(ConfigurationHelper.TOCC_EmailAddress))
                   {
                       string[] emailAddresses = ConfigurationHelper.TOCC_EmailAddress.Split('^');
                       for (int i = 0; i < emailAddresses.Length; i++)
                       {
                           mM.CC.Add(emailAddresses[i]);
                       }
                   }

                   if (!string.IsNullOrEmpty(ConfigurationHelper.TOBC_EmailAddress))
                   {
                       string[] emailAddresses = ConfigurationHelper.TOBC_EmailAddress.Split('^');
                       for (int i = 0; i < emailAddresses.Length; i++)
                       {
                           mM.Bcc.Add(emailAddresses[i]);
                       }
                   }

                   mM.Subject = subject;   // set email subject
                   mM.Body = body;         // set email body
                   mM.IsBodyHtml = true;

                   // open smtp client 
                   SmtpClient Server = new SmtpClient(MailServer, MailServerPort);
                   Server.UseDefaultCredentials = true;
                   Server.Credentials = new System.Net.NetworkCredential(Sender, SenderPassword);
                   Server.Port = MailServerPort;   // set port number
                   Server.Host = MailServer;
                   Server.EnableSsl = EnableSSL;
                   Server.DeliveryMethod = SmtpDeliveryMethod.Network;

                   //Added this to bypass the certificate validation
                   ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                   Server.Send(mM);    // send email

                   mM.Dispose();


               }
           }
           catch (Exception ex)
           {
               B2BayLogger.LogErr("Error", ex);
           }
       }
       public void MailSend(EmailModel emailModel)
       {
           try
           {
               string Sender = string.IsNullOrEmpty(emailModel.SenderEmail) ? ConfigurationHelper.EMailSenderAddress : emailModel.SenderEmail;
               string SenderPassword = ConfigurationHelper.EMailSenderPassword;    // ConfigurationManager.AppSettings["EMailSenderPassword"].ToString();
               string MailServer = ConfigurationHelper.SMTPServer;                 // ConfigurationManager.AppSettings["SMTPServer"].ToString();
               int MailServerPort = ConfigurationHelper.SMTPServerPort;            // Convert.ToInt16(ConfigurationManager.AppSettings["SMTPServerPort"].ToString());
               bool EnableSSL = ConfigurationHelper.SMTPEnableSSL;                 // Convert.ToBoolean(ConfigurationManager.AppSettings["SMTPEnableSSL"].ToString().ToLower());


               MailMessage mM = new MailMessage();

               mM.From = new MailAddress(Sender);  // set email sender
               if (emailModel.ToEmailAddresses != null && emailModel.ToEmailAddresses.Count > 0)
               {
                   foreach (string emailAdd in emailModel.ToEmailAddresses)
                   {
                       mM.To.Add(emailAdd);
                   }

               }

               // set receiver email

               if (emailModel.CCEamilAddresses != null && emailModel.CCEamilAddresses.Count > 0)
               {
                   foreach (string emailAdd in emailModel.CCEamilAddresses)
                   {
                       mM.CC.Add(emailAdd);
                   }

               }

               if (emailModel.BCEmailAddresses != null && emailModel.BCEmailAddresses.Count > 0)
               {
                   foreach (string emailAdd in emailModel.BCEmailAddresses)
                   {
                       mM.Bcc.Add(emailAdd);
                   }

               }




               mM.Subject = emailModel.Subject;   // set email subject
               mM.Body = emailModel.Body;         // set email body
               mM.IsBodyHtml = true;

               // open smtp client 
               SmtpClient Server = new SmtpClient(MailServer, MailServerPort);
               Server.UseDefaultCredentials = true;
               Server.Credentials = new System.Net.NetworkCredential(Sender, SenderPassword);
               Server.Port = MailServerPort;   // set port number
               Server.Host = MailServer;
               Server.EnableSsl = EnableSSL;
               Server.DeliveryMethod = SmtpDeliveryMethod.Network;

               //Added this to bypass the certificate validation
               ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
               Server.Send(mM);    // send email

               mM.Dispose();



           }
           catch (Exception ex)
           {

               B2BayLogger.LogErr("Error", ex);

               throw ex;

           }
       }

       public  bool IsNewApplciationRunning(string appName)
       {


           Process currentProcess = Process.GetCurrentProcess();
           Process[] processlist = Process.GetProcesses();
           int cout = processlist.Where(a => a.ProcessName.Equals(appName)).Count();
           //int cout = processlist.Where(a => a.ProcessName.Equals("TS.EmailQueue")).Count();
           if (cout > 1)
               return false;
           else
               return true;
       }
       /// <summary>
       /// Send a sms alert
       /// </summary>
       /// <param name="mobileNo"></param>
       /// <param name="Message"></param>
       public void SendSMSAlert(string mobileNo, string message)
       {
           SMSSendModel sms = new SMSSendModel(mobileNo, message);
           string Data = "";

           try
           {
               // serailze model object to json string
               DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(SMSSendModel));
               MemoryStream mem = new MemoryStream();
               ser.WriteObject(mem, sms);
               Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

               // process the request and get response as string
               string ServiceURL = ConfigurationHelper.SMSGatewayURL;

               WebClient webClient = new WebClient();
               webClient.Headers["Content-type"] = "application/json";
               webClient.Encoding = Encoding.UTF8;

               Uri address = new Uri(ServiceURL);
               webClient.UploadString(address, "POST", Data);
           }
           catch (Exception ex)
           {
               throw new Exception("SMS alert fail. " + ex.Message);
           }
       }
    }
}
