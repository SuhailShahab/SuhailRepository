﻿using System;
using System.Collections.Generic;
using System.Linq;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <09-05-2016 06:24:12PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace MultipartDataMediaFormatter.Infrastructure.Logger
{
    public class FormDataConverterLogger : IFormDataConverterLogger
    {
        private Dictionary<string, List<LogErrorInfo>> Errors { get; set; }

        public FormDataConverterLogger()
        {
            Errors = new Dictionary<string, List<LogErrorInfo>>();
        }

        public void LogError(string errorPath, Exception exception)
        {
            AddError(errorPath, new LogErrorInfo(exception));
        }

        public void LogError(string errorPath, string errorMessage)
        {
            AddError(errorPath, new LogErrorInfo(errorMessage));
        }

        public List<LogItem> GetErrors()
        {
            return Errors.Select(m => new LogItem()
            {
                ErrorPath = m.Key,
                Errors = m.Value.Select(t => t).ToList()
            }).ToList();
        }

        public void EnsureNoErrors()
        {
            if (Errors.Any())
            {
                var errors = Errors
                    .SelectMany(m => m.Value)
                    .Select(m => (m.ErrorMessage ?? (m.Exception != null ? m.Exception.Message : "")))
                    .ToList();

                string errorMessage = String.Join(" ", errors);

                throw new Exception(errorMessage);
            }
        }

        private void AddError(string errorPath, LogErrorInfo info)
        {
            List<LogErrorInfo> listErrors;
            if (!Errors.TryGetValue(errorPath, out listErrors))
            {
                listErrors = new List<LogErrorInfo>();
                Errors.Add(errorPath, listErrors);
            }
            listErrors.Add(info);
        }

        public class LogItem
        {
            public string ErrorPath { get; set; }
            public List<LogErrorInfo> Errors { get; set; }
        }

        public class LogErrorInfo
        {
            public string ErrorMessage { get; private set; }
            public Exception Exception { get; private set; }
            public bool IsException { get; private set; }

            public LogErrorInfo(string errorMessage)
            {
                ErrorMessage = errorMessage;
                IsException = false;
            }

            public LogErrorInfo(Exception exception)
            {
                Exception = exception;
                IsException = true;
            }
        }
    }
}
