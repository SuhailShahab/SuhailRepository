﻿using System;
using System.ComponentModel;
using System.Globalization;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <09-05-2016 06:24:12PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace MultipartDataMediaFormatter.Infrastructure
{
    internal class DateTimeConverterISO8601 : DateTimeConverter
    {
        public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            if (value != null && value is DateTime && destinationType == typeof(string))
            {
                return ((DateTime)value).ToString("O"); // ISO 8601
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
    }
}
