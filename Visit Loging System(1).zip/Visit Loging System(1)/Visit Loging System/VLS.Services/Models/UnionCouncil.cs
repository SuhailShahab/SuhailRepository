﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VLS.Services.Models
{
    public class UnionCouncil
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public int TehsilID { get; set; }
    }
}