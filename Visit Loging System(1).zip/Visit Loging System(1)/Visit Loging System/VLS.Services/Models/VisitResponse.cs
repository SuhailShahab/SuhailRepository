﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <02-05-2016 11:11:27AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.Services.Models
{
    public class VisitResponse
    {
        public bool Status { get; set; }
        public string Message { get; set; }

        #region "Constructors"

        public VisitResponse()
        {
            this.Status = false;
        }

        public VisitResponse(bool Status, string Message)
        {
            this.Status = Status;
            this.Message = Message;
        }

        #endregion
    }
}