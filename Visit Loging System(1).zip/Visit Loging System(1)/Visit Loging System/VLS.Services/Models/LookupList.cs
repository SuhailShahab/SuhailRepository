﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

// =================================================================================================================================
// Create by:	<Sohail Shahab>
// Create date: <29-04-2016 05:30:01PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.Services.Models
{
    public class LookupList
    {
        public List<Province> Provinces { get; set; }
        public List<Division> Divisions { get; set; }
        public List<District> Districts { get; set; }
        public List<Tehsil> Tehsils { get; set; }
        public List<UnionCouncil> UnionCouncils { get; set; }
        public List<Constituency> Constituencies { get; set; }
        public List<Constituency> NAConstituencies { get; set; }
        public List<Model> Departments { get; set; }
        public List<Model> Ratings { get; set; }
        public List<Model> HospitalTypes { get; set; }
        public List<Model> Doctors { get; set; }
        public List<Model> DoctorPosts { get; set; }
        public List<Model> MedicineTypes { get; set; }
        public List<Model> HospitalEquipments { get; set; }
    }
}