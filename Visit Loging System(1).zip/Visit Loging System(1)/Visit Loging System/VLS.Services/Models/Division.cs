﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <19-04-2016 03:03:56PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.Services.Models
{
    public class Division
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public int ProvinceID { get; set; }
    }
}