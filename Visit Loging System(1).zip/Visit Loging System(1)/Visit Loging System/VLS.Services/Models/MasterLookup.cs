﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using VLS.Services.Services;

// =================================================================================================================================
// Create by:	<Sohail Shahab>
// Create date: <29-04-2016 05:30:01PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.Services.Models
{
    public class MasterLookup
    {
        public bool? Status { get; set; } 
        public string  ErrorMessge { get; set; }
        public LookupList Records { get; set; }

        #region "Constructors"

        public MasterLookup()
        {
            this.Status = true;
            this.ErrorMessge = "";
        }

        #endregion
    }
}