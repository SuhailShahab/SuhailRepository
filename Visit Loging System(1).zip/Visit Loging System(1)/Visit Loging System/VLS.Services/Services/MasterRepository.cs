﻿using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using VLS.Services.Models;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <19-04-2016 03:03:56PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.Services.Services
{
    public class MasterRepository
    {
        public List<Province> GetProvinces()
        {
            List<Province> colProvinces = new List<Province>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<ProvinceDAL>.Instance.GetAllActiveProvinces();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Province model = new Province();

                        if (dt.Columns.Contains("ProvinceID") && !Convert.IsDBNull(dr["ProvinceID"]))
                            model.ID = Convert.ToInt32(dr["ProvinceID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        colProvinces.Add(model);
                    }

                    colProvinces.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return colProvinces;
        }

        public List<Division> GetDivisions()
        {
            List<Division> colDivision = new List<Division>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<DivisionDAL>.Instance.GetAll();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Division model = new Division();

                        if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                            model.ID = Convert.ToInt32(dr["DivisionID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        if (dt.Columns.Contains("ProvinceID") && !Convert.IsDBNull(dr["ProvinceID"]))
                            model.ProvinceID = Convert.ToInt32(dr["ProvinceID"]);

                        colDivision.Add(model);
                    }

                    colDivision.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colDivision;
        }

        public List<District> GetDistricts()
        {
            List<District> colDistricts = new List<District>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<DistrictDAL>.Instance.SelectAllActive();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        District model = new District();

                        if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                            model.ID = Convert.ToInt32(dr["DistrictID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                            model.DivisionID = Convert.ToInt32(dr["DivisionID"]);

                        colDistricts.Add(model);
                    }

                    colDistricts.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colDistricts;
        }

        public List<Tehsil> GetTehsils()
        {
            List<Tehsil> colTehsils = new List<Tehsil>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<TehsilDAL>.Instance.SelectAllActive();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Tehsil model = new Tehsil();

                        if (dt.Columns.Contains("TehsilID") && !Convert.IsDBNull(dr["TehsilID"]))
                            model.ID = Convert.ToInt32(dr["TehsilID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                            model.DistrictID = Convert.ToInt32(dr["DistrictID"]);

                        colTehsils.Add(model);
                    }

                    colTehsils.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colTehsils;
        }

        public List<UnionCouncil> GetUnionCouncils()
        {
            List<UnionCouncil> colUnionCouncils = new List<UnionCouncil>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<UnionCouncilDAL>.Instance.GetAll();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        UnionCouncil model = new UnionCouncil();

                        if (dt.Columns.Contains("UnionCouncilID") && !Convert.IsDBNull(dr["UnionCouncilID"]))
                            model.ID = Convert.ToInt32(dr["UnionCouncilID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        if (dt.Columns.Contains("TehsilID") && !Convert.IsDBNull(dr["TehsilID"]))
                            model.TehsilID = Convert.ToInt32(dr["TehsilID"]);

                        colUnionCouncils.Add(model);
                    }

                    colUnionCouncils.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colUnionCouncils;
        }

        public List<Constituency> GetConstituencies()
        {
            List<Constituency> colConstituencies = new List<Constituency>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<ConstituencyDAL>.Instance.GetConstituency();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Constituency model = new Constituency();

                        if (dt.Columns.Contains("ConstituencyID") && !Convert.IsDBNull(dr["ConstituencyID"]))
                            model.ID = Convert.ToInt32(dr["ConstituencyID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                            model.DistrictID = Convert.ToInt32(dr["DistrictID"]);

                        colConstituencies.Add(model);
                    }

                    colConstituencies.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colConstituencies;
        }

        public List<Constituency> GetNAConstituencies()
        {
            List<Constituency> colConstituencies = new List<Constituency>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<NAConstituencyDAL>.Instance.GetNAConstituency();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Constituency model = new Constituency();

                        if (dt.Columns.Contains("NAConstituencyID") && !Convert.IsDBNull(dr["NAConstituencyID"]))
                            model.ID = Convert.ToInt32(dr["NAConstituencyID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                            model.DistrictID = Convert.ToInt32(dr["DistrictID"]);

                        colConstituencies.Add(model);
                    }

                    colConstituencies.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colConstituencies;
        }

        public List<Model> GetDepartments()
        {
            List<Model> colDepartments = new List<Model>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<DepartmentDAL>.Instance.GetAll();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Model model = new Model();

                        if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                            model.ID = Convert.ToInt32(dr["DepartmentID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        colDepartments.Add(model);
                    }

                    colDepartments.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colDepartments;
        }

        public List<Model> GetRatings()
        {
            List<Model> colRating = new List<Model>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<RatingDAL>.Instance.GetAllRatings();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Model model = new Model();

                        if (dt.Columns.Contains("RateID") && !Convert.IsDBNull(dr["RateID"]))
                            model.ID = Convert.ToInt32(dr["RateID"]);

                        if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                            model.Title = Convert.ToString(dr["Name"]);

                        colRating.Add(model);
                    }

                    colRating.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colRating;
        }

        public List<Model> GetHospitalTypes()
        {
            List<Model> colHospitalTypes = new List<Model>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<HospitalTypeDAL>.Instance.GetHospitalTypes();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Model model = new Model();

                        if (dt.Columns.Contains("HospitalTypeID") && !Convert.IsDBNull(dr["HospitalTypeID"]))
                            model.ID = Convert.ToInt32(dr["HospitalTypeID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        colHospitalTypes.Add(model);
                    }

                    colHospitalTypes.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colHospitalTypes;
        }

        public List<Model> GetDoctors()
        {
            List<Model> colDoctors = new List<Model>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<DoctorPostDAL>.Instance.GetDoctorPosts();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Model model = new Model();

                        if (dt.Columns.Contains("DoctorPostID") && !Convert.IsDBNull(dr["DoctorPostID"]))
                            model.ID = Convert.ToInt32(dr["DoctorPostID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        colDoctors.Add(model);
                    }

                    colDoctors.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colDoctors;
        }

        public List<Model> GetDoctorPosts()
        {
            List<Model> colDoctorPosts = new List<Model>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<DoctorPostDAL>.Instance.GetDoctorPosts();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Model model = new Model();

                        if (dt.Columns.Contains("DoctorPostID") && !Convert.IsDBNull(dr["DoctorPostID"]))
                            model.ID = Convert.ToInt32(dr["DoctorPostID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        colDoctorPosts.Add(model);
                    }

                    colDoctorPosts.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colDoctorPosts;
        }

        public List<Model> GetMedicineType()
        {
            List<Model> colMedicineTypes = new List<Model>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<MedicineTypeDAL>.Instance.GetMedicineTypes();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Model model = new Model();

                        if (dt.Columns.Contains("MedicinesTypeID") && !Convert.IsDBNull(dr["MedicinesTypeID"]))
                            model.ID = Convert.ToInt32(dr["MedicinesTypeID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        colMedicineTypes.Add(model);
                    }

                    colMedicineTypes.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colMedicineTypes;
        }

        public List<Model> GetHopitalEquipments()
        {
            List<Model> colHopitalEquipments = new List<Model>();

            try
            {
                DataTable dt = LazyBaseSingletonDAL<HospitalEquipmentDAL>.Instance.GetHospitalEquipments();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        Model model = new Model();

                        if (dt.Columns.Contains("EquipmentID") && !Convert.IsDBNull(dr["EquipmentID"]))
                            model.ID = Convert.ToInt32(dr["EquipmentID"]);

                        if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                            model.Title = Convert.ToString(dr["Title"]);

                        colHopitalEquipments.Add(model);
                    }

                    colHopitalEquipments.TrimExcess();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return colHopitalEquipments;
        }

        public MasterLookup GetMasterLookpus()
        {
            MasterLookup masterLookup = new MasterLookup();

            try
            {
                LookupList lookupList = new LookupList();
                
                lookupList.Provinces = GetProvinces();
                lookupList.Divisions = GetDivisions();
                lookupList.Districts = GetDistricts();
                lookupList.Tehsils = GetTehsils();
                lookupList.UnionCouncils = GetUnionCouncils();
                lookupList.Constituencies = GetConstituencies();
                lookupList.NAConstituencies = GetNAConstituencies();
                lookupList.Departments = GetDepartments();
                lookupList.Ratings = GetRatings();
                lookupList.HospitalTypes = GetHospitalTypes();
                lookupList.Doctors = GetDoctors();
                lookupList.DoctorPosts = GetDoctorPosts();
                lookupList.MedicineTypes = GetMedicineType();
                lookupList.HospitalEquipments = GetHopitalEquipments();

                masterLookup.Records = lookupList;
            }
            catch (Exception ex)
            {
                masterLookup = new MasterLookup();
                masterLookup.Status = false;
                masterLookup.ErrorMessge = ex.Message;
            }

            return masterLookup;
        }
    }
}