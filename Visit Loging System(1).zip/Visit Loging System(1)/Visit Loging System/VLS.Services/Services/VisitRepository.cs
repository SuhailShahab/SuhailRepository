﻿using BE;
using BE.EmailQueue;
using BE.Visit;
using DAL.Generic;
using DAL.Lookups;
using DAL.RightsManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using VLS.Services.Codes;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <19-04-2016 03:03:56PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.Services.Services
{
    public class VisitRepository
    {
        public Visit AddVisitLog(Visit visit)
        {
            try
            {
                ValidateRequired(visit);

                // ======================================================================================================= //
                // ======================================== Validate IMENo =============================================== //
                if (string.IsNullOrEmpty(visit.IMENo) == false)
                {
                    DataTable dtUser = LazyBaseSingletonDAL<UserDAL>.Instance.GetUserByIMENo(visit.IMENo);
                    if (dtUser.Rows.Count > 0)
                    {
                        visit.CreatedBy = Convert.ToInt32(dtUser.Rows[0]["UserID"].ToString());
                        visit.IsUnauthorizedEntry = false;
                    }
                    else
                    {
                        visit.CreatedBy = 0;
                        visit.IsUnauthorizedEntry = true;
                    }
                }
                else
                {
                    visit.CreatedBy = 0;
                    visit.IsUnauthorizedEntry = true;
                }

                // ======================================================================================================= //
                // ===================================== Set Lat & Long Values =========================================== //
                if (string.IsNullOrEmpty(visit.LatLong) == false)
                {
                    string[] arrLatLong = visit.LatLong.Split(',');         // 0 = Latitude, 1 = Longitude
                    visit.Latitude = Convert.ToDecimal(arrLatLong[0]);
                    visit.Longitude = Convert.ToDecimal(arrLatLong[1]);
                }

                int VisitLogID = 0;

                if (visit.Hospital != null)
                {
                    VisitLogID = LazyBaseSingletonDAL<VisitorLogDAL>.Instance.Save(visit, BuildImageDataTable(visit.Images), BuildIDsCollectionDataTable(visit.Hospital.DoctorIDs),
                        BuildIDsCollectionDataTable(visit.Hospital.DoctorPostIDs), BuildIDsCollectionDataTable(visit.Hospital.HospitalEquipmentIDs), BuildIDsCollectionDataTable(visit.Hospital.MedicineTypeIDs));
                }
                else
                {
                    VisitLogID = LazyBaseSingletonDAL<VisitorLogDAL>.Instance.Save(visit, BuildImageDataTable(visit.Images), BuildIDsCollectionDataTable(),
                        BuildIDsCollectionDataTable(), BuildIDsCollectionDataTable(), BuildIDsCollectionDataTable());
                }

                if (VisitLogID > 0)
                {
                    visit.VisitorLogID = VisitLogID;

                    // ================================================================================================================================ //
                    // ================================================== Sending Visit Log Emails ==================================================== //
                    if (visit.CreatedBy != 0)
                    {
                        DataTable tblRating = LazyBaseSingletonDAL<RatingDAL>.Instance.GetRateByRateID(Convert.ToInt32(visit.Rating));

                        // Get users information to send sms & email
                        DataSet dsUsers = LazyBaseSingletonDAL<UserDAL>.Instance.GetUsersToSendEmailAndSMS(visit.CreatedBy,visit.DistrictID,visit.DivisionID, visit.DepartmentID);

                        #region "Email & SMS to Visit Performer Officical"

                        // ============================================================================================================================ //
                        // =============================================== Send Email to Offical =================================================== //
                        if (string.IsNullOrEmpty(tblRating.Rows[0]["VisitEmailForOffical"].ToString()) == false && string.IsNullOrEmpty(dsUsers.Tables[0].Rows[0]["EMail"].ToString()) == false)
                        {
                            try
                            {
                                DataTable tblDepartment = LazyBaseSingletonDAL<DepartmentDAL>.Instance.GetDepartmentByID(visit.DepartmentID);

                                string Subject = "Visit Performed At " + tblDepartment.Rows[0]["Title"].ToString() + " department on " + visit.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");


                                if (string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL) == false)       // send email to email schedule
                                {
                                    EmailModel em = new EmailModel();
                                    em.Body = tblRating.Rows[0]["VisitEmailForOffical"].ToString();
                                    em.Subject = Subject;
                                    em.ToEmailAddresses = new List<string>();
                                    em.ToEmailAddresses.Add(dsUsers.Tables[0].Rows[0]["EMail"].ToString());

                                    SendEmailToQueue(em);
                                }
                                else
                                    MailSend(dsUsers.Tables[0].Rows[0]["EMail"].ToString(), Subject, tblRating.Rows[0]["VisitEmailForOffical"].ToString());
                            }
                            catch { }
                        }

                        // ============================================================================================================================ //
                        // =============================================== Send SMS to Offical ======================================================== //
                        if (string.IsNullOrEmpty(tblRating.Rows[0]["VisitSMSForOffical"].ToString()) == false && string.IsNullOrEmpty(dsUsers.Tables[0].Rows[0]["CellNumber"].ToString()) == false)
                        {
                            try
                            {
                                SendSMSAlert(dsUsers.Tables[0].Rows[0]["CellNumber"].ToString(), tblRating.Rows[0]["VisitSMSForOffical"].ToString());
                            }
                            catch { }
                        }

                        #endregion

                        #region "Email & SMS to Observation Officical"

                        try
                        {
                            // ============================================================================================================================ //
                            // =============================================== Send Email to Offical ====================================================== //
                            if (string.IsNullOrEmpty(tblRating.Rows[0]["ObservationEMailForOfficial"].ToString()) == false && string.IsNullOrEmpty(dsUsers.Tables[1].Rows[0]["EMail"].ToString()) == false)
                            {
                                string Subject = "Visit Observation added by " + dsUsers.Tables[0].Rows[0]["EmployeeName"].ToString() + " on " + visit.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");

                                if (string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL) == false)       // send email to email schedule
                                {
                                    EmailModel em = new EmailModel();
                                    em.Body = tblRating.Rows[0]["ObservationEMailForOfficial"].ToString();
                                    em.Subject = Subject;
                                    em.ToEmailAddresses = new List<string>();
                                    em.ToEmailAddresses.Add(dsUsers.Tables[1].Rows[0]["EMail"].ToString());

                                    SendEmailToQueue(em);
                                }
                                else
                                    MailSend(dsUsers.Tables[1].Rows[0]["EMail"].ToString(), Subject, tblRating.Rows[0]["ObservationEMailForOfficial"].ToString());
                            }

                            // ============================================================================================================================ //
                            // =============================================== Send Email to DCO of that location obervation log ====================================================== //
                            if (string.IsNullOrEmpty(tblRating.Rows[0]["ObservationEMailForOfficial"].ToString()) == false && string.IsNullOrEmpty(dsUsers.Tables[3].Rows[0]["EMail"].ToString()) == false)
                            {
                                string Subject = "Visit Observation added by " + dsUsers.Tables[0].Rows[0]["EmployeeName"].ToString() + " on " + visit.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");

                                if (string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL) == false)       // send email to email schedule
                                {
                                    EmailModel em = new EmailModel();
                                    em.Body = tblRating.Rows[0]["ObservationEMailForOfficial"].ToString();
                                    em.Subject = Subject;
                                    em.ToEmailAddresses = new List<string>();
                                    em.ToEmailAddresses.Add(dsUsers.Tables[3].Rows[0]["EMail"].ToString());

                                    SendEmailToQueue(em);
                                }
                                else
                                    MailSend(dsUsers.Tables[3].Rows[0]["EMail"].ToString(), Subject, tblRating.Rows[0]["ObservationEMailForOfficial"].ToString());
                            }

                            // ============================================================================================================================ //
                            // =============================================== Send Email to Commissioner of that location obervation log ====================================================== //
                            if (string.IsNullOrEmpty(tblRating.Rows[0]["ObservationEMailForOfficial"].ToString()) == false && string.IsNullOrEmpty(dsUsers.Tables[4].Rows[0]["EMail"].ToString()) == false)
                            {
                                string Subject = "Visit Observation added by " + dsUsers.Tables[0].Rows[0]["EmployeeName"].ToString() + " on " + visit.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");

                                if (string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL) == false)       // send email to email schedule
                                {
                                    EmailModel em = new EmailModel();
                                    em.Body = tblRating.Rows[0]["ObservationEMailForOfficial"].ToString();
                                    em.Subject = Subject;
                                    em.ToEmailAddresses = new List<string>();
                                    em.ToEmailAddresses.Add(dsUsers.Tables[4].Rows[0]["EMail"].ToString());

                                    SendEmailToQueue(em);
                                }
                                else
                                    MailSend(dsUsers.Tables[4].Rows[0]["EMail"].ToString(), Subject, tblRating.Rows[0]["ObservationEMailForOfficial"].ToString());
                            }

                            // ============================================================================================================================ //
                            // ============================================= Send Email to SubOrdinates =================================================== //
                            if (string.IsNullOrEmpty(tblRating.Rows[0]["ObservationEamilForSubOrdinates"].ToString()) == false && dsUsers.Tables[2].Rows.Count > 0)
                            {
                                string Subject = "Visit Observation added by " + dsUsers.Tables[0].Rows[0]["EmployeeName"].ToString() + " on " + visit.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");

                                if (string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL) == false)       // send email to email schedule
                                {
                                    List<string> EmailAddress = new List<string>();
                                    foreach (DataRow dr in dsUsers.Tables[2].Rows)
                                    {
                                        if (string.IsNullOrEmpty(dr["EMail"].ToString())) continue;

                                        EmailAddress.Add(dr["EMail"].ToString());
                                    }

                                    EmailModel em = new EmailModel();
                                    em.Body = tblRating.Rows[0]["ObservationEamilForSubOrdinates"].ToString();
                                    em.Subject = Subject;
                                    em.ToEmailAddresses = EmailAddress;

                                    SendEmailToQueue(em);
                                }
                                else
                                {
                                    foreach (DataRow dr in dsUsers.Tables[2].Rows)
                                    {
                                        if (string.IsNullOrEmpty(dr["EMail"].ToString())) continue;

                                        MailSend(dr["EMail"].ToString(), Subject, tblRating.Rows[0]["ObservationEamilForSubOrdinates"].ToString());
                                    }
                                }
                            }
                        }
                        catch { }

                        try
                        {
                            // ============================================================================================================================ //
                            // ================================================ Send SMS to Offical ======================================================= //
                            if (string.IsNullOrEmpty(tblRating.Rows[0]["ObservationSMSForOfficial"].ToString()) == false && string.IsNullOrEmpty(dsUsers.Tables[1].Rows[0]["CellNumber"].ToString()) == false)
                            {
                                SendSMSAlert(dsUsers.Tables[1].Rows[0]["CellNumber"].ToString(), tblRating.Rows[0]["ObservationSMSForOfficial"].ToString());
                            }

                            // ============================================================================================================================ //
                            // ================================================ Send SMS to DCO of that location obervation log ======================================================= //
                            if (string.IsNullOrEmpty(tblRating.Rows[0]["ObservationSMSForOfficial"].ToString()) == false && string.IsNullOrEmpty(dsUsers.Tables[3].Rows[0]["CellNumber"].ToString()) == false)
                            {
                                SendSMSAlert(dsUsers.Tables[3].Rows[0]["CellNumber"].ToString(), tblRating.Rows[0]["ObservationSMSForOfficial"].ToString());
                            }

                            // ============================================================================================================================ //
                            // ================================================ Send SMS to Commissioner of that location obervation log ======================================================= //
                            if (string.IsNullOrEmpty(tblRating.Rows[0]["ObservationSMSForOfficial"].ToString()) == false && string.IsNullOrEmpty(dsUsers.Tables[4].Rows[0]["CellNumber"].ToString()) == false)
                            {
                                SendSMSAlert(dsUsers.Tables[4].Rows[0]["CellNumber"].ToString(), tblRating.Rows[0]["ObservationSMSForOfficial"].ToString());
                            }

                            // ============================================================================================================================ //
                            // =============================================== Send SMS to Subordinctes =================================================== //
                            if (string.IsNullOrEmpty(tblRating.Rows[0]["ObservationSMSForSubOrdinates"].ToString()) == false && dsUsers.Tables[2].Rows.Count > 0)
                            {
                                foreach (DataRow dr in dsUsers.Tables[2].Rows)
                                {
                                    if (string.IsNullOrEmpty(dr["CellNumber"].ToString())) continue;

                                    SendSMSAlert(dr["CellNumber"].ToString(), tblRating.Rows[0]["ObservationSMSForSubOrdinates"].ToString());
                                }
                            }
                        }
                        catch { }


                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return visit;
        }

        #region "Private Methods"

        ///// <summary>
        ///// Convert Base64 image string to bytes array
        ///// </summary>
        ///// <param name="str"></param>
        ///// <returns></returns>
        //private byte[] GetBytes(string str)
        //{
        //    byte[] bytes = new byte[str.Length * sizeof(char)];
        //    System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
        //    return bytes;
        //}

        private void ValidateRequired(Visit v)
        {
            try
            {
                if (v.ProvinceID == 0)
                    throw new Exception("Provice is required");

                if (v.DivisionID == 0)
                    throw new Exception("Division is required");

                if (v.DistrictID == 0)
                    throw new Exception("District is required");

                if (v.TehsilID == 0)
                    throw new Exception("Tehsil is required");

                if (v.DepartmentID == 0)
                    throw new Exception("Department is required");

                if (v.VisitStartDate == null || v.VisitStartTime == null)
                    throw new Exception("Start Date/Time is required");

                if (v.VisitEndDate == null || v.VisitEndTime == null)
                    throw new Exception("End Date/Time is required");

                if (v.Rating == null || v.Rating.Value == 0)
                    throw new Exception("Rating is required");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Convert images collection to DataTable structure
        /// </summary>
        /// <param name="colImages"></param>
        /// <returns></returns>
        private DataTable BuildImageDataTable(List<VisitImage> colImages)
        {
            DataRow dr = null;
            DataTable dt = new DataTable();
            dt.Columns.Add("ImageID", typeof(System.Int32));
            dt.Columns.Add("VisitorLogID", typeof(System.Int32));
            dt.Columns.Add("ImageTitle", typeof(System.String));
            dt.Columns.Add("ImageDescription", typeof(System.String));
            dt.Columns.Add("VisitorLogImage", typeof(byte[]));
            dt.Columns.Add("ContentType", typeof(System.String));

            if (colImages != null)
            {
                foreach (VisitImage item in colImages)
                {
                    dr = dt.NewRow();
                    dr["ImageID"] = 0;
                    dr["VisitorLogID"] = 0;
                    dr["ImageTitle"] = item.Title;
                    dr["ImageDescription"] = "";
                    //dr["VisitorLogImage"] = GetBytes(item.VisitLogImage);
                    dr["VisitorLogImage"] = item.FileBinary;
                    dr["ContentType"] = item.ContentType;
                    dt.Rows.Add(dr);
                }
            }

            return dt;
        }

        /// <summary>
        /// Convert IDs collection to DataTable structure
        /// </summary>
        /// <param name="colIDs"></param>
        /// <returns></returns>
        private DataTable BuildIDsCollectionDataTable(List<Model> colIDs)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(System.Int32));

            if (colIDs != null)
            {
                foreach (var itm in colIDs)
                {
                    DataRow dr = dt.NewRow();
                    dr["ID"] = itm.ID;

                    dt.Rows.Add(dr);
                }
            }

            return dt;
        }

        /// <summary>
        /// Convert IDs collection to empty DataTable structure
        /// </summary>
        /// <returns></returns>
        private DataTable BuildIDsCollectionDataTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(System.Int32));

            return dt;
        }

        /// <summary>
        /// Send an email notification
        /// </summary>
        /// <param name="Receiver"></param>
        /// <param name="Subject"></param>
        /// <param name="Body"></param>
        private void MailSend(string Receiver, string Subject, string Body)
        {
            try
            {
                string Sender = ConfigurationHelper.EMailSenderAddress;
                string SenderPassword = ConfigurationHelper.EMailSenderPassword;
                string MailServer = ConfigurationHelper.SMTPServer;
                int MailServerPort = ConfigurationHelper.SMTPServerPort;
                bool EnableSSL = ConfigurationHelper.SMTPEnableSSL;

                MailMessage mM = new MailMessage();

                mM.From = new MailAddress(Sender);  // set email sender
                mM.To.Add(Receiver);    // set receiver email
                mM.Subject = Subject;   // set email subject
                mM.Body = Body;         // set email body
                mM.IsBodyHtml = true;

                // open smtp client 
                SmtpClient Server = new SmtpClient(MailServer, MailServerPort);
                Server.UseDefaultCredentials = true;
                Server.Credentials = new System.Net.NetworkCredential(Sender, SenderPassword);
                Server.Port = MailServerPort;   // set port number
                Server.Host = MailServer;
                Server.EnableSsl = EnableSSL;
                Server.DeliveryMethod = SmtpDeliveryMethod.Network;

                //Added this to bypass the certificate validation
                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                Server.Send(mM);    // send email

                mM.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Send a sms alert
        /// </summary>
        /// <param name="MobileNo"></param>
        /// <param name="Message"></param>
        private void SendSMSAlert(string MobileNo, string Message)
        {
            SMSSendModel sms = new SMSSendModel(MobileNo, Message);
            string Data = "";

            try
            {
                // serailze model object to json string
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(SMSSendModel));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, sms);
                Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                // process the request and get response as string
                string ServiceURL = ConfigurationHelper.SMSGatewayURL;

                WebClient webClient = new WebClient();
                webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;

                Uri address = new Uri(ServiceURL);
                webClient.UploadString(address, "POST", Data);
            }
            catch (Exception ex)
            {
                throw new Exception("SMS alert fail. " + ex.Message);
            }
        }

        /// <summary>
        /// Send email to queue
        /// </summary>
        /// <param name="emailModel"></param>
        private void SendEmailToQueue(EmailModel emailModel)
        {
            string Data = "";

            try
            {
                // serailze model object to json string
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(EmailModel));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, emailModel);
                Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                // process the request and get response as string
                string serviceURL = ConfigurationHelper.EmailQueueURL;

                WebClient webClient = new WebClient();
                webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;

                Uri address = new Uri(serviceURL);
                webClient.UploadString(address, "POST", Data);
            }
            catch
            { }
        }

        #endregion
    }
}