﻿using BE.Visit;
using MultipartDataMediaFormatter.Converters;
using MultipartDataMediaFormatter.Infrastructure;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Script.Serialization;
using VLS.Services.Models;
using VLS.Services.Services;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <19-04-2016 03:03:56PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.Services.Controllers
{
    [RoutePrefix("api/visit")]
    public class VisitController : ApiController
    {
        private VisitRepository vr;

        #region "Constructors"

        public VisitController()
        {
            vr = new VisitRepository();
        }

        #endregion

        [HttpPost]
        public async Task<VisitResponse> Add()
        {
            VisitResponse objVR = new VisitResponse();

            // Check if the request contains multipart/form-data.
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }            

            try
            {
                var httpContentToFormDataConverter = new HttpContentToFormDataConverter();
                FormData multipartFormData = await httpContentToFormDataConverter.Convert(Request.Content);

                Visit v = BuildModel(multipartFormData);    // convert data to model

                v = vr.AddVisitLog(v);
                objVR.Status = true;
                objVR.Message = "{'VisitID': " + v.VisitorLogID.ToString() + "}";
            }
            catch (System.Exception e)
            {
                objVR = new VisitResponse();
                objVR.Status = false;
                objVR.Message = e.Message;
            }

            return objVR;
        }

        private Visit BuildModel(FormData fd)
        {
            Visit visit = new JavaScriptSerializer().Deserialize<Visit>(fd.Fields[0].Value);       // convert data paramenter value to model excepted json string of model

            // =========================================================================================================================== //
            // ================================================= Build Image Collection ================================================== //
            List<VisitImage> colImages = new List<VisitImage>();
            if (fd.Files != null)
            {
                foreach (MultipartDataMediaFormatter.Infrastructure.FormData.ValueFile file in fd.Files)
                {
                    VisitImage vi = new VisitImage();
                    vi.Title = file.Value.FileName;
                    vi.FileBinary = file.Value.Buffer;
                    vi.ContentType = file.Value.MediaType;

                    colImages.Add(vi);

                    // code for right file to file system
                    //MemoryStream ms = new MemoryStream(file.Value.Buffer, 0, file.Value.Buffer.Length);

                    //// Convert byte[] to Image
                    //ms.Write(file.Value.Buffer, 0, file.Value.Buffer.Length);
                    //System.Drawing.Image image = System.Drawing.Image.FromStream(ms, true);
                    //image.Save(root + "/" + file.Value.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                }

                colImages.TrimExcess();
            }

            visit.Images = colImages;

            return visit;
        }


        #region "Commentend Code"

        //public async Task<VisitResponse> Add()
        //{
        //    // Check if the request contains multipart/form-data.
        //    if (!Request.Content.IsMimeMultipartContent())
        //    {
        //        throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
        //    }

        //    //string root = HttpContext.Current.Server.MapPath("~/App_Data");
        //    //var provider = new MultipartFormDataStreamProvider(root);

        //    try
        //    {
        //        var httpContentToFormDataConverter = new HttpContentToFormDataConverter();
        //        FormData multipartFormData = await httpContentToFormDataConverter.Convert(Request.Content);

        //        Visit v = new JavaScriptSerializer().Deserialize<Visit>(multipartFormData.Fields[0].Value);

        //        //Visit v = BuildModel(multipartFormData);

        //        //StringBuilder sb = new StringBuilder(); // Holds the response body

        //        //// Read the form data and return an async task.
        //        //await Request.Content.ReadAsMultipartAsync(provider);
        //        //foreach (var file in provider.Contents.Where(c => IsFile(c.Headers.ContentDisposition)))
        //        //{
        //        //    var filename = file.Headers.ContentDisposition.FileName.Trim('\"');
        //        //    var buffer = await file.ReadAsByteArrayAsync();
        //        //    //Do whatever you want with filename and its binaray data.
        //        //}

        //        //// This illustrates how to get the form data.
        //        //foreach (var key in provider.FormData.AllKeys)
        //        //{
        //        //    foreach (var val in provider.FormData.GetValues(key))
        //        //    {
        //        //        sb.Append(string.Format("{0}: {1}\n", key, val));
        //        //    }
        //        //}



        //        //////var filesReadToProvider = await Request.Content.ReadAsMultipartAsync(provider);

        //        ////foreach (var stream in filesReadToProvider.Contents)
        //        ////{
        //        ////    var fileBytes = await stream.ReadAsByteArrayAsync();
        //        ////}

        //        //// This illustrates how to get the file names for uploaded files.
        //        //foreach (var file in provider.FileData)
        //        //{
        //        //    FileInfo fileInfo = new FileInfo(file.LocalFileName);

        //        //    sb.Append(string.Format("Uploaded file: {0} ({1} bytes)\n", fileInfo.Name, fileInfo.Length));
        //        //}


        //        //return new HttpResponseMessage()
        //        //{
        //        //    Content = new StringContent(sb.ToString())
        //        //};

        //        return new VisitResponse(true, "");
        //    }
        //    catch (System.Exception e)
        //    {
        //        return new VisitResponse(false, e.Message);
        //    }
        //}

        //[HttpPost]
        //public VisitResponse Add(Visit visit)
        //{
        //    VisitResponse objVR = new VisitResponse();

        //    try
        //    {
        //        visit = vr.AddVisitLog(visit);
        //        objVR.Status = true;
        //        objVR.Message = visit.VisitorLogID.ToString();
        //    }
        //    catch (Exception ex)
        //    {
        //        objVR = new VisitResponse();
        //        objVR.Status = false;
        //        objVR.Message = ex.Message;
        //    }

        //    return objVR;
        //}

        //private Visit BuildModel(FormData fd)
        //{
        //    Visit v = new Visit();

        //    foreach (PropertyInfo propertyInfo in v.GetType().GetProperties())
        //    {
        //        foreach (Object obj in propertyInfo.GetCustomAttributes(true))
        //        {
        //            MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;

        //            MultipartDataMediaFormatter.Infrastructure.FormData.ValueString data = fd.Fields.Where(f => f.Name == mappingInfoAttribute.ColumnName).FirstOrDefault();
        //            if (data != null)
        //                propertyInfo.SetValue(v, data.Value);
        //        }
        //    }

        //    List<VisitImage> colImages = new List<VisitImage>();
        //    if (fd.Files != null)
        //    {
        //        foreach (MultipartDataMediaFormatter.Infrastructure.FormData.ValueFile file in fd.Files)
        //        {
        //            VisitImage vi = new VisitImage();
        //            vi.Title = file.Value.FileName;
        //            vi.FileBinary = file.Value.Buffer;
        //            vi.ContentType = file.Value.MediaType;

        //            //MemoryStream ms = new MemoryStream(file.Value.Buffer, 0, file.Value.Buffer.Length);

        //            //// Convert byte[] to Image
        //            //ms.Write(file.Value.Buffer, 0, file.Value.Buffer.Length);
        //            //System.Drawing.Image image = System.Drawing.Image.FromStream(ms, true);
        //            //image.Save(root + "/" + file.Value.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);
        //        }

        //        colImages.TrimExcess();
        //    }

        //    v.Images = colImages;

        //    return v;
        //}

        #endregion
    }
}