﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using VLS.Services.Models;
using VLS.Services.Services;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <19-04-2016 03:03:56PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.Services.Controllers
{
    [RoutePrefix("api/master")]
    public class MasterController : ApiController
    {
        private MasterRepository mr;
       

        #region "Constructors"

        public MasterController()
        {
            mr = new MasterRepository();
        }

        #endregion


        [HttpGet]
        [Route("AllMasterRecords/{IMENo}")]
        public MasterLookup GetAllMasterLookups(string IMENo)
        {
            return mr.GetMasterLookpus();
        }

        [HttpGet]
        [Route("Provinces")]
        public List<Province> GetAllProvinces()
        {
            return mr.GetProvinces();
        }

        [HttpGet]
        [Route("Divisions")]
        public List<Division> GetDivisions()
        {
            return mr.GetDivisions();
        }

        [HttpGet]
        [Route("Districts")]
        public List<District> GetDistricts()
        {
            return mr.GetDistricts();
        }

        [HttpGet]
        [Route("Tehsils")]
        public List<Tehsil> GetTehsils()
        {
            return mr.GetTehsils();
        }

        [HttpGet]
        [Route("UnionCouncils")]
        public List<UnionCouncil> GetUnionCouncils()
        {
            return mr.GetUnionCouncils();
        }

        [HttpGet]
        [Route("Constituencies")]
        public List<Constituency> GetConstituencies()
        {
            return mr.GetConstituencies();
        }

        [HttpGet]
        [Route("Departments")]
        public List<Model> GetDepartments()
        {
            return mr.GetDepartments();
        }

        [HttpGet]
        [Route("Rating")]
        public List<Model> GetRatings()
        {
            return mr.GetRatings();
        }

        [HttpGet]
        [Route("HospitalTypes")]
        public List<Model> GetHospitalTypes()
        {
            return mr.GetHospitalTypes();
        }

        [HttpGet]
        [Route("Doctors")]
        public List<Model> GetDoctors()
        {
            return mr.GetDoctors();
        }

        [HttpGet]
        [Route("DoctorPosts")]
        public List<Model> GetDoctorPosts()
        {
            return mr.GetDoctorPosts();
        }

        [HttpGet]
        [Route("MedicineTypes")]
        public List<Model> GetMedicineType()
        {
            return mr.GetMedicineType();
        }

        [HttpGet]
        [Route("HospitalEquipments")]
        public List<Model> GetHopitalEquipments()
        {
            return mr.GetHopitalEquipments();
        }
    }
}