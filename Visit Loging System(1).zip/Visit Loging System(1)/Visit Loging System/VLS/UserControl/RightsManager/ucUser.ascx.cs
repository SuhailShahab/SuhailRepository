﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.Lookups;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.RightsManager
{
    public partial class ucUser : System.Web.UI.UserControl
    {
        #region "Paging Variable and Paging Properties"

        int PageSize = 4;
        int PagingSize = 7;
        int TotalRecords = 0;

        public int PageNumber
        {
            get
            {
                int val = 0;
                if (ViewState["PageNumber"] != null)
                    val = Convert.ToInt32(ViewState["PageNumber"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageNumber"] = value;
                else
                    ViewState["PageNumber"] = null;
            }
        }
        public int PageStart
        {
            get
            {
                int val = 1;
                if (ViewState["PageStart"] != null)
                    val = Convert.ToInt32(ViewState["PageStart"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageStart"] = value;
                else
                    ViewState["PageStart"] = null;
            }
        }
        public int PageCount
        {
            get
            {
                int val = 1;
                if (this.hidPageCount.Value != string.Empty)
                    val = Convert.ToInt32(this.hidPageCount.Value);
                return val;
            }
            set
            {
                if (value >= 1)
                {
                    this.hidPageCount.Value = value.ToString();
                }
            }
        }

        #endregion

        #region "Private Data Members"
        //private int? DistrictID;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            pnlError.Visible = false;

            if (!IsPostBack)
            {
                try
                {


                    ddlReportingUsers.Items.Clear();
                    ddlReportingUsers.Items.Insert(0, new ListItem("Choose...", "0"));

                    ddlTehsil.Items.Clear();
                    ddlTehsil.Items.Insert(0, new ListItem("Choose...", "0"));

                    ddlDistrict.Items.Clear();
                    ddlDistrict.Items.Insert(0, new ListItem("Choose...", "0"));

                    ddlDivision.Items.Clear();
                    ddlDivision.Items.Insert(0, new ListItem("Choose...", "0"));

                    dtpJoined.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    this.GetAddressDivision();
                    GetDepartment();
                    GetDesignation();
                    GetDistrict(null);
                    this.GetProvince();
                    this.GetAllDepartmentFacility();
                   
                    this.GetAddressDistricts(0);
                    GetGroups();
                    PopulateUsers();
                    this.GetUsertypes();
                    this.dtpResigned.Disabled = true;
                    this.GetAllDivisions();
                    this.GetAllDistris();
                    this.BindUserRights();
                    this.SetVisibilityOfControls();
                    this.PopulateFeaturesMngtMenus();
                }
                catch (Exception ex)
                {
                    new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }

                ViewState["UserID"] = "";
                ViewState["Edit"] = "No";

            }
        }

        #region "Methods"

        private void GetAllDepartmentFacility()
        {
            List<DepartmentFacilityModel> departmentFacilities = null;
            departmentFacilities = LazyBaseSingletonBLL<DepartmentFacilityBLL>.Instance.GetActiveDepartmentFacilities();           

            this.chkDepartmentFacilities.DataSource = departmentFacilities;
            this.chkDepartmentFacilities.DataValueField = "ID";
            this.chkDepartmentFacilities.DataTextField = "Title";
            this.chkDepartmentFacilities.DataBind();
            this.chkDepartmentFacilities.Items.Insert(0, new ListItem("Select All", "0"));
        }

        private void GetAddressDivision()
        {
            this.ddlAddressDivisions.DataSource = new DivisionBLL().GetDivisions();
            this.ddlAddressDivisions.DataValueField = "ID";
            this.ddlAddressDivisions.DataTextField = "Title";
            this.ddlAddressDivisions.DataBind();
            this.ddlAddressDivisions.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        private void GetDepartment()
        {
            List<DepartmentModel> departments =new DepartmentBLL().GetDepartments();
            ddlDepartment.DataSource = departments;
            ddlDepartment.DataValueField = "ID";
            ddlDepartment.DataTextField = "Title";
            ddlDepartment.DataBind();
            ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));

            this.FillAllDepartmentCheckList(departments);
        }

        private void GetDesignation()
        {
            List<DesignationModel> designation = null;
            designation = LazyBaseSingletonBLL<DesignationBLL>.Instance.GetAllDesignations();
            this.ddlDesignation.DataSource = designation;

            //ddlDesignation.DataSource = new DesignationBLL().GetDesignation();
            ddlDesignation.DataValueField = "ID";
            ddlDesignation.DataTextField = "Title";
            ddlDesignation.DataBind();
            ddlDesignation.Items.Insert(0, new ListItem("Choose...", "0"));

            this.FillAllDesignationCheckList(designation);
        }

        private void GetReportingUsers(int?userID,int? departmentID)
        {
            List<UserModel> users = LazyBaseSingletonBLL<UserBLL>.Instance.GetReportingUsers(userID, departmentID);
            
            this.ddlReportingUsers.DataSource = users;
            this.ddlReportingUsers.DataValueField = "UserID";
            this.ddlReportingUsers.DataTextField = "EmployeeName";
            this.ddlReportingUsers.DataBind();
            this.ddlReportingUsers.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        public void ClearddlItems(DropDownList ddl)
        {
            if(ddl.Items !=null && ddl.Items.Count>0)
            {
                ddl.Items.Clear();
               // ddlReportingUsers.Items.Clear();
                ddl.Items.Insert(0, new ListItem("Choose...", "0"));

            }
        }

        //private void GetDistrict()
        //{
        //    List<DistrictModel> genralDisticts = null;


        //    // genralDisticts = new GeneralDistrictBLL().GetDistricts (null);
        //    genralDisticts = new DistrictBLL().SelectAllActive();
        //    ddlDistrict.DataSource = genralDisticts;
        //    ddlDistrict.DataValueField = "ID";
        //    ddlDistrict.DataTextField = "Title";
        //    ddlDistrict.DataBind();
        //    ddlDistrict.Items.Insert(0, new ListItem("Choose...", "0"));
        //}

        private void GetDistrict(int? divisionID)
        {
            List<DistrictModel> genralDisticts = null;


            if (divisionID.HasValue && divisionID.Value >0)
            {
                genralDisticts = new DistrictBLL().GetAllDistrictsByDivisionID(divisionID);
                ddlDistrict.DataSource = genralDisticts;
                ddlDistrict.DataValueField = "ID";
                ddlDistrict.DataTextField = "Title";
                ddlDistrict.DataBind();
                ddlDistrict.Items.Insert(0, new ListItem("Choose...", "0"));

                this.GetAllDistris(genralDisticts);
                List<string> districtIDs = this.GetAllIDsFromCheckList(this.cblAllDistricts);
                if (districtIDs != null && districtIDs.Count > 0)
                {
                    this.GetTehsilsByCSV(districtIDs);
                }
            }
            else
            {
                if (this.ddlDistrict.Items != null && this.ddlDistrict.Items.Count > 0)
                {
                    this.ddlDistrict.Items.Clear();
                    this.ddlDistrict.Items.Insert(0, new ListItem("Choose...", "0"));

                    this.ddlTehsil.Items.Clear();
                    this.ddlTehsil.Items.Insert(0, new ListItem("Choose...", "0"));

                    this.GetAllDistris();

                }
            }
           
        }

        public void GetDivisionByID(int? provisionID)
        {
            List<DivisionModel> divisions = null;

            if(provisionID.HasValue && provisionID.Value>0)
            {
                divisions = new DivisionBLL().GetDivisions().Where( p=> p.ProvinceID == provisionID.Value).ToList ();
                this.ddlDivision.DataSource = divisions;
                this.ddlDivision.DataValueField = "ID";
                this.ddlDivision.DataTextField = "Title";
                this.ddlDivision.DataBind();
                this.ddlDivision.Items.Insert(0, new ListItem("Choose...", "0"));
            }
            else
            {
                if(this.ddlDivision.Items !=null && this.ddlDivision.Items.Count>0)
                {
                    this.ddlDivision.Items.Clear();
                    this.ddlDivision.Items.Insert(0, new ListItem("Choose...", "0"));
                }
            }
            
        }
        public void GetProvince()
        {
            List<ProvinceModel> provinces = new ProvinceBLL().GetAllActiveProvinces();
            this.ddlProvince.DataSource = provinces;
            this.ddlProvince.DataValueField = "ID";
            this.ddlProvince.DataTextField = "Title";
            this.ddlProvince.DataBind();
            this.ddlProvince.Items.Insert(0, new ListItem("Choose...", "0"));
        }
       

        public void GetTehsilsByCSV(List<string> selctorIDs)
        {

            List<TehsilModel> tehsilModel = null;
            tehsilModel = LazyBaseSingletonBLL<TehsilBLL>.Instance.GetTehsilByCSV(selctorIDs);
            this.chkTehsils.DataSource = tehsilModel;
            this.chkTehsils.DataValueField = "ID";
            this.chkTehsils.DataTextField = "Title";
            this.chkTehsils.DataBind();
            this.chkTehsils.Items.Insert(0, new ListItem("Select All", "0"));

        }

        /// <summary>
        /// Get All Districts 
        /// </summary>
        private void GetAllDistris()
        {
            List<DistrictModel> allDistricts = null;
            if (string.IsNullOrEmpty(this.ddlDivision.SelectedValue) || Convert.ToInt32(this.ddlDivision.SelectedValue) == 0)
            {
                allDistricts = new DistrictBLL().SelectAllActive();
            }
            else
            {
                allDistricts = new DistrictBLL().GetAllDistrictsByDivisionID(Convert.ToInt32(this.ddlDivision.SelectedValue));
            }
            this.cblAllDistricts.DataSource = allDistricts;
            this.cblAllDistricts.DataValueField = "ID";
            this.cblAllDistricts.DataTextField = "Title";
            this.cblAllDistricts.DataBind();
            this.cblAllDistricts.Items.Insert(0, new ListItem("Select All", "0"));


        }


        /// <summary>
        /// Get All divisions checks box
        /// </summary>
        private void GetAllDivisions()
        {
            List<DivisionModel> allDivisionss = null;
            if (string.IsNullOrEmpty(this.ddlProvince.SelectedValue) || Convert.ToInt32(this.ddlProvince.SelectedValue) == 0)
            {
                allDivisionss = new DivisionBLL().GetDivisions();
            }
            else
            {
                allDivisionss = new DivisionBLL().GetDivisions().Where(p => p.ProvinceID == Convert.ToInt32(ddlProvince.SelectedValue)).ToList();
            }
            this.cblAllDivisions.DataSource = allDivisionss;
            this.cblAllDivisions.DataValueField = "ID";
            this.cblAllDivisions.DataTextField = "Title";
            this.cblAllDivisions.DataBind();
            this.cblAllDivisions.Items.Insert(0, new ListItem("Select All", "0"));


        }
        private void GetAllDistris( List<DistrictModel> allDistrict)
        {
            if(this.cblAllDistricts.Items !=null && this.cblAllDistricts.Items.Count>0)
            {
                this.cblAllDistricts.Items.Clear();
            }

            this.cblAllDistricts.DataSource = allDistrict;
            this.cblAllDistricts.DataValueField = "ID";
            this.cblAllDistricts.DataTextField = "Title";
            this.cblAllDistricts.DataBind();
            this.cblAllDistricts.Items.Insert(0, new ListItem("Select All", "0"));
        }

        public void GetTehsilByID(int? districtID)
        {
            if (districtID.HasValue)
            {
                if (this.ddlTehsil.Items != null && this.ddlTehsil.Items.Count > 0)
                {
                    this.ddlTehsil.Items.Clear();
                }

                List<TehsilModel> thesils = new TehsilBLL().GetTehsilByDistrictID(districtID.Value);
                this.ddlTehsil.DataSource = thesils;
                this.ddlTehsil.DataValueField = "ID";
                this.ddlTehsil.DataTextField = "Title";
                this.ddlTehsil.DataBind();
                this.ddlTehsil.Items.Insert(0, new ListItem("Choose...", "0"));

                this.FillTehsilCheckList(thesils);
            }
            else
            {
                if (this.ddlTehsil.Items != null && this.ddlTehsil.Items.Count > 0)
                {
                    this.ddlTehsil.Items.Clear();
                }
            }
            

        }
        
        public void FillTehsilCheckList(List<TehsilModel> tehsilModel)
        {

            this.chkTehsils.DataSource = tehsilModel;
            this.chkTehsils.DataValueField = "ID";
            this.chkTehsils.DataTextField = "Title";
            this.chkTehsils.DataBind();
            this.chkTehsils.Items.Insert(0, new ListItem("Select All", "0"));
        }

      

        private void FillAllDesignationCheckList(List<DesignationModel> designation)
        {
            if (this.chkDesignations.Items != null && this.chkDesignations.Items.Count > 0)
            {
                this.chkDesignations.Items.Clear();
            }

            if (designation != null && designation.Count > 0)
            {
                this.chkDesignations.DataSource = designation;
                this.chkDesignations.DataValueField = "ID";
                this.chkDesignations.DataTextField = "Title";
                this.chkDesignations.DataBind();
                this.chkDesignations.Items.Insert(0, new ListItem("Select All", "0"));
            }

        }

        private void FillAllDepartmentCheckList(List<DepartmentModel> departemtns)
        {
            if (this.chkDepartments.Items != null && this.chkDepartments.Items.Count > 0)
            {
                this.chkDepartments.Items.Clear();
            }

            if (departemtns != null && departemtns.Count > 0)
            {
                this.chkDepartments.DataSource = departemtns;
                this.chkDepartments.DataValueField = "ID";
                this.chkDepartments.DataTextField = "Title";
                this.chkDepartments.DataBind();
                this.chkDepartments.Items.Insert(0, new ListItem("Select All", "0"));
            }

        }



        private void GetAddressDistricts(int divisionID)
        {
            if (this.ddlAddressDistiricts.Items != null && this.ddlAddressDistiricts.Items.Count > 0)
            {
                this.ddlAddressDistiricts.Items.Clear();
            }
            if (divisionID > 0)
            {
                this.ddlAddressDistiricts.DataSource = new DistrictBLL().GetAllDistrictsByDivisionID(divisionID);
                this.ddlAddressDistiricts.DataValueField = "ID";
                this.ddlAddressDistiricts.DataTextField = "Title";
                this.ddlAddressDistiricts.DataBind();
            }
            this.ddlAddressDistiricts.Items.Insert(0, new ListItem("Choose...", "0"));
        }



        private void GetGroups()
        {
            ddlGroup.Items.Clear();
            List<GroupModel> groups = null;

            groups = new GroupBLL().GetAllGroups();

            if (groups != null && groups.Count > 0)
            {
                ddlGroup.DataSource = groups.Where(p => p.Status.Value == true).OrderBy(p => p.Title).ToList();
                ddlGroup.DataValueField = "ID";
                ddlGroup.DataTextField = "Title";
                ddlGroup.DataBind();
                ddlGroup.Items.Insert(0, new ListItem("Choose...", "0"));
            }

        }








        private void GetUsertypes()
        {
            this.ddlUserType.DataSource = new UserTypeBLL().GetAllUsersType();
            this.ddlUserType.DataTextField = "Title";
            this.ddlUserType.DataValueField = "ID";
            this.ddlUserType.DataBind();
        }


        private void PopulateFeaturesMngtMenus()
        {
            this.chkFeatures.DataSource = new MenuBLL().GetAppFeatures(2); ;
            this.chkFeatures.DataTextField = "Name";
            this.chkFeatures.DataValueField = "ID";
            this.chkFeatures.DataBind();
            // this.chkFeatures.Items.Insert(0, new ListItem("Select All", "0"));
        }


        private void PopulateUsers()
        {
            List<UserModelView> Users = null;
            try
            {
                if (!string.IsNullOrEmpty(ddlDistrict.SelectedValue))
                {
                    Users = new UserBLL().GetUsers(Convert.ToInt32(ddlDistrict.SelectedValue), PageNumber, PageSize, out TotalRecords, ddlSearchBy.SelectedValue, txtSearch.Text.Trim());

                }
                else
                {
                    Users = new UserBLL().GetUsers(0, PageNumber, PageSize, out TotalRecords, ddlSearchBy.SelectedValue, txtSearch.Text.Trim());

                }
         
                //                TotalRecords = Record;
                PageCount = Convert.ToInt32(Math.Ceiling((decimal)TotalRecords / PageSize));
                ViewState["PageCount"] = PageCount;

                if (Users != null)
                {
                    rptUsers.DataSource = Users;
                    rptUsers.DataBind();

                    pnlUserNoFound.Visible = false;
                }
                else
                {
                    if (PageNumber > 0)
                    {
                        PageNumber = PageNumber - 1;
                        PopulateUsers();
                    }
                    else
                    {
                        rptUsers.DataSource = null;
                        rptUsers.DataBind();
                        pnlUserNoFound.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "PopulateUsers", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                lblError.Text = ex.Message;
                pnlError.Visible = true;
            }
        }

        /// <summary>
        /// Get provide login claim information
        /// </summary>
        /// <param name="login"></param>
        /// <returns></returns>
        private static string GetLoginClaim(string login)
        {
            string userName = login;
            /*  SPClaimProviderManager mgr = SPClaimProviderManager.Local;
              if (mgr == null) return userName;

              // comment by hammad => use to claim against window user
              //SPClaim claim = new SPClaim(SPClaimTypes.IdentityProvider, login, "http://www.w3.org/2001/XMLSchema#string", SPOriginalIssuers.Format(SPOriginalIssuerType.Windows));

              string FBAMembershipProvider = ConfigurationManager.AppSettings["FBAMembership"];
              SPClaim claim = new SPClaim(SPClaimTypes.UserLogonName, login, "http://www.w3.org/2001/XMLSchema#string", SPOriginalIssuers.Format(SPOriginalIssuerType.Forms, FBAMembershipProvider));
              userName = mgr.EncodeClaim(claim);
             */
            return userName;
        }

        private void PopulateEditPanel(int UserID)
        {
            try
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();

                ViewState["UserID"] = UserID;

                ds = new UserBLL().GetRegisterUserInfoByUserID(UserID);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt = ds.Tables[TableName.tblUser.ToString()];
                    dtpResigned.Disabled = false;
                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dt.Rows[0]["DepartmentID"]))
                    {
                        ddlDepartment.SelectedValue = dt.Rows[0]["DepartmentID"].ToString();

                        if(!string.IsNullOrEmpty(ddlDepartment.SelectedValue))
                        {
                            this.GetReportingUsers(UserID, Convert.ToInt32(ddlDepartment.SelectedValue));
                        }
                        else
                        {
                            this.ClearddlItems(this.ddlReportingUsers);
                        }


                        if (dt.Columns.Contains("ReportingUserID") && !Convert.IsDBNull(dt.Rows[0]["ReportingUserID"]) && this.ddlReportingUsers.Items != null && this.ddlReportingUsers.Items.Count >0)
                        {
                            int ID = Convert.ToInt32(dt.Rows[0]["ReportingUserID"]);
                            this.ddlReportingUsers.SelectedValue = ID.ToString();
                            // this.GetAddressTehsil(ID);
                        }
                    }

                    if (this.ddlDesignation.Items != null && dt.Columns.Contains("DesignationID") && !Convert.IsDBNull(dt.Rows[0]["DesignationID"]))
                    {
                        ListItem item = this.ddlDesignation.Items.FindByValue(dt.Rows[0]["DesignationID"].ToString());
                        if (item != null && Convert.ToInt32(item.Value) > 0)
                        {
                            this.ddlDesignation.SelectedValue = item.Value;
                           
                        }                           
                        
                    }

                    if (this.ddlProvince.Items != null && dt.Columns.Contains("ProvinceID") && !Convert.IsDBNull(dt.Rows[0]["ProvinceID"]))
                    {
                        ListItem item = this.ddlProvince.Items.FindByValue(dt.Rows[0]["ProvinceID"].ToString());
                        if (item != null && Convert.ToInt32(item.Value) > 0)
                        {
                            this.ddlProvince.SelectedValue = item.Value;
                            this.GetDivisionByID(Convert.ToInt32(this.ddlProvince.SelectedValue));
                        }
                            

                    }


                    if (this.ddlDivision.Items != null && dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dt.Rows[0]["DivisionID"]))
                    {
                        ListItem item = this.ddlDivision.Items.FindByValue(dt.Rows[0]["DivisionID"].ToString());
                        if (item != null && Convert.ToInt32(item.Value) > 0)
                        {
                            this.ddlDivision.SelectedValue = item.Value;
                            this.GetDistrict(Convert.ToInt32(item.Value));
                        }
                        else
                        {
                            this.GetDistrict(null);
                        }
                            
                      
                    }
                    else
                    {
                        this.GetDistrict(null);
                    }
                   


                    if (ddlDistrict.Items != null && dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dt.Rows[0]["DistrictID"]))
                    {
                        ListItem item = ddlDistrict.Items.FindByValue(dt.Rows[0]["DistrictID"].ToString());
                        if (item != null && Convert.ToInt32(item.Value) > 0)
                            ddlDistrict.SelectedValue = item.Value;
                        this.GetTehsilByID(Convert.ToInt32(dt.Rows[0]["DistrictID"]));
                    }
                    else
                    {
                        if (this.cblAllDistricts.Items != null)
                        {
                            this.cblAllDistricts.SelectedIndex = 0;
                        }
                        
                        this.GetTehsilByID(null);
                    }

                    
                    if (this.ddlTehsil.Items != null)
                    {
                        ListItem item = this.ddlTehsil.Items.FindByValue(dt.Rows[0]["TehsilID"].ToString());
                        if (item != null && Convert.ToInt32(item.Value) > 0)
                            this.ddlTehsil.SelectedValue = item.Value;
                    }

                  


                    txtCNIC.Text = dt.Rows[0]["CNIC"].ToString();
                    txtEmployeeName.Text = dt.Rows[0]["EmployeeName"].ToString();

                    //Address Information

                    if (dt.Columns.Contains("AddressDivisionID") && !Convert.IsDBNull(dt.Rows[0]["AddressDivisionID"]))
                    {
                        int ID = Convert.ToInt32(dt.Rows[0]["AddressDivisionID"]);
                        this.ddlAddressDivisions.SelectedValue = ID.ToString();
                        this.GetAddressDistricts(ID);
                    }

                    if (dt.Columns.Contains("AddressDistrictID") && !Convert.IsDBNull(dt.Rows[0]["AddressDistrictID"]))
                    {
                        int ID = Convert.ToInt32(dt.Rows[0]["AddressDistrictID"]);
                        this.ddlAddressDistiricts.SelectedValue = ID.ToString();
                        // this.GetAddressTehsil(ID);
                    }

                    




                    if (dt.Columns.Contains("FullAddress") && !Convert.IsDBNull(dt.Rows[0]["FullAddress"]))
                    {
                        this.txtFullAddress.Text = Convert.ToString(dt.Rows[0]["FullAddress"]);
                    }


                    // added against CR:007
                    txtEmail.Text = dt.Rows[0]["EMail"].ToString();
                    txtCell.Text = dt.Rows[0]["CellNumber"].ToString();

                    txtImeNo.Text = dt.Rows[0]["IMENo"].ToString();

                    ddlGroup.SelectedValue = dt.Rows[0]["PermitGroupID"].ToString();
                    ddlUserType.SelectedValue = dt.Rows[0]["UserTypeID"].ToString();


                    cbxStatus.Checked = Convert.ToBoolean(dt.Rows[0]["IsActive"].ToString());
                    chkIsVisitLog.Checked = Convert.ToBoolean(dt.Rows[0]["IsVisitLog"].ToString());


                    txtBlockReason.Text = dt.Rows[0]["InActiveReason"].ToString();
                    if (!Convert.IsDBNull(dt.Rows[0]["JoiningDate"]))
                        this.dtpJoined.Value = Convert.ToDateTime(dt.Rows[0]["JoiningDate"]).ToString("dd/MM/yyyy");
                    if (!Convert.IsDBNull(dt.Rows[0]["ResignedDate"]))
                        this.dtpResigned.Value = Convert.ToDateTime(dt.Rows[0]["ResignedDate"]).ToString("dd/MM/yyyy");
                    this.chkEnforceRight.Checked = Convert.ToBoolean(dt.Rows[0]["IsEnforceRight"].ToString());
                    txtLoginName.Text = dt.Rows[0]["UserName"].ToString();
                    //// set user login name
                    //txtLoginName.Text = dt.Rows[0]["UserName"].ToString();
                    //cppLogin.Visible = false;
                    //txtLoginName.Visible = true;

                    // set serice rights

                    this.cblUserRights.Items[UserRightName.FileAdd.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileAdd"]);
                    this.cblUserRights.Items[UserRightName.FileView.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileView"]);
                    this.cblUserRights.Items[UserRightName.FileRemove.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileRemove"]);
                    this.cblUserRights.Items[UserRightName.FileDownload.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileDownload"]);
                    this.cblUserRights.Items[UserRightName.ActionTaken.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["ActionTaken"]);
                    this.cblUserRights.Items[UserRightName.IsAllowedToEditRecord.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["IsAllowedToEdit"]);
                    

                    if (!Convert.IsDBNull(dt.Rows[0]["Signature"]))
                    {
                        byte[] Signature = (byte[])(dt.Rows[0]["Signature"]);
                        hdnSignatureBase64.Value = new UserBLL().ConvertBytesToBase64(Signature);
                        //hdnSignatureBase64.Value = model.Signature;
                        imgSignature.ImageUrl = new UserBLL().ConvertBytesToBase64(Signature);
                        //Signature = hdnSignatureBase64.Value;
                    }

                    this.FillUserDistricts(UserID);
                    DataTable userDT = null;
                   
                    DataTable userDTDesignation = ds.Tables[TableName.tblUserDesignation.ToString()];
                    //this.FillUserDesignation(userDTDesignation);
                    this.FillUserCheckList(userDTDesignation,this.chkDesignations);
                    
                    userDT = ds.Tables[TableName.tblUserTehsil.ToString()];
                    ViewState[TableName.tblUserTehsil.ToString()] = userDT;
                    this.FillUserTehsils(userDT);

                    //===========Fill User Departments=========================
                    userDT = ds.Tables[TableName.tblUserDepartment.ToString()];
                    ViewState[TableName.tblUserDepartment.ToString()] = userDT;
                    this.FillCheckList(userDT, this.chkDepartments);

                    //==========Fill Department Facility ======================
                    userDT = ds.Tables[TableName.tblUserDepartmentFacility.ToString()];
                    ViewState[TableName.tblUserDepartmentFacility.ToString()] = userDT;
                    this.FillCheckList(userDT, this.chkDepartmentFacilities );

                    //==========Fill user division ======================
                    userDT = ds.Tables[TableName.tblUserDivision.ToString()];
                    //ViewState[TableName.tblUserDivision.ToString()] = userDT;
                    //this.FillCheckList(userDT, this.chkDepartmentFacilities);

                    this.ClearChecked(this.cblAllDivisions);
                    foreach (DataRow dr in userDT.Rows)
                    {
                        foreach (ListItem item in this.cblAllDivisions.Items)
                        {
                            if (item.Value == dr["DivisionID"].ToString())
                            {
                                item.Selected = true;
                                break;
                            }
                        }
                    }



                    if (ds.Tables[TableName.tblPermitUserMgtMenu.ToString()].Rows.Count > 0)
                    {
                        foreach (DataRow dr1 in ds.Tables[1].Rows)
                        {
                            chkFeatures.Items.FindByValue(dr1["FeatureID"].ToString()).Selected = true;
                        }
                    }


                    this.SetVisibilityOfControls();

                    try
                    {
                        //  string _userName = GetLoginClaim(dt.Rows[0]["UserName"].ToString());
                        //  SPUser user = SPContext.Current.Web.EnsureUser(_userName);

                        //  peUserLogin.CommaSeparatedAccounts = user.LoginName;
                        //  peUserLogin.Enabled = false;
                    }
                    catch (Exception ex)
                    {
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('user name not found in active directory server. Please contact your administrator.');", true);
                    }
                }
            }
            catch (Exception ex)
            {

                new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "PopulateEditPanel", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                lblError.Text = ex.Message;
                pnlError.Visible = true;
            }
        }

        private void FillUserDistricts(int userID)
        {
            DataTable dtUserDistrict = new DataTable();
            dtUserDistrict = new UserBLL().GetDistirctByUserID(userID);

            this.ClearChecked(this.cblAllDistricts);
            foreach (DataRow dr in dtUserDistrict.Rows)
            {
                foreach (ListItem item in this.cblAllDistricts.Items)
                {
                    if (item.Value == dr["DistrictID"].ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }


       

        private void FillUserDesignation(DataTable dtUserDesignations)
        {
            this.ClearChecked(this.chkDesignations);
           

            if (dtUserDesignations != null && dtUserDesignations.Rows.Count > 0)
            {
                foreach (DataRow dr1 in dtUserDesignations.Rows)
                {
                    if (this.chkDesignations.Items != null && this.chkDesignations.Items.Count > 0)
                        this.chkDesignations.Items.FindByValue(dr1["DesignationID"].ToString()).Selected = true;
                }
            }


        }

        private void FillUserCheckList(DataTable dtItems,CheckBoxList chkList)
        {
            this.ClearChecked(chkList);


            if (dtItems != null && dtItems.Rows.Count > 0)
            {
                foreach (DataRow dr1 in dtItems.Rows)
                {
                    if (chkList.Items != null && chkList.Items.Count > 0)
                    {
                        ListItem itm = chkList.Items.FindByValue(dr1["DesignationID"].ToString());
                        if (itm!=null)
                         itm.Selected = true;
                    }
                       
                }
            }


        }

        private void FillCheckList(DataTable dtItems, CheckBoxList chkList)
        {
            this.ClearChecked(chkList);


            if (dtItems != null && dtItems.Rows.Count > 0)
            {
                foreach (DataRow dr1 in dtItems.Rows)
                {
                    if (chkList.Items != null && chkList.Items.Count > 0)
                    {
                        ListItem itm = chkList.Items.FindByValue(dr1["ID"].ToString());
                        if (itm != null)
                            itm.Selected = true;
                    }

                }
            }

        }

       

        private void FillUserTehsils(DataTable dtUserTehsils)
        {
            this.ClearChecked(this.chkTehsils);
            if (string.IsNullOrEmpty(this.ddlTehsil.SelectedValue) || Convert.ToInt32(this.ddlTehsil.SelectedValue) == 0)
            {
                if (string.IsNullOrEmpty(this.ddlDistrict.SelectedValue) || Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0)
                {
                    List<string> tehsilIDs = this.GetIDsFromCheckList(this.cblAllDistricts);
                    if (tehsilIDs != null && tehsilIDs.Count > 0)
                    {
                        this.GetTehsilsByCSV(tehsilIDs);

                    }
                }
                else if (Convert.ToInt32(this.ddlDistrict.SelectedValue) > 0)
                {
                    List<TehsilModel> thesils = new TehsilBLL().GetTehsilByDistrictID(Convert.ToInt32(this.ddlDistrict.SelectedValue));
                    this.FillTehsilCheckList(thesils);
                }


                if (dtUserTehsils != null && dtUserTehsils.Rows.Count > 0 && this.chkTehsils.Items != null && this.chkTehsils.Items.Count > 0)
                {
                    foreach (DataRow dr1 in dtUserTehsils.Rows)
                    {                      
                        ListItem itm = this.chkTehsils.Items.FindByValue(dr1["TehsilID"].ToString());
                        if (itm != null)
                            itm.Selected = true;
                    }
                }
            }

        }




        private void SetSeltectedCSRManagement(DataTable dtStatuses, CheckBoxList chklStatues)
        {
            this.ClearChecked(chklStatues);
            foreach (DataRow dr in dtStatuses.Rows)
            {
                foreach (ListItem item in chklStatues.Items)
                {
                    if (item.Value == dr["AppFeatureID"].ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }




        /// <summary>
        /// Verify login name is selects in people picker
        /// </summary>
        /// <returns></returns>
        private bool ValidatePeoplePicker()
        {
            /*
            if (Page.IsValid)
            {
                if (peUserLogin.CommaSeparatedAccounts == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Select user login name');", true);
                    peUserLogin.Focus();
                    return false;
                }
                else
                {
                    if (peUserLogin.CommaSeparatedAccounts.Contains("\\"))
                    {
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Invalid user selection');", true);
                    }
                }
            }
             */


            return true;
        }

        /// <summary>
        /// check select login Name transactions
        /// </summary>
        /// <param name="LoginName"></param>
        /// <returns></returns>
        private bool ValidateDependanceReocrd(string LoginName)
        {
            //// check data existing against user in sharepoint library
            //using (SPSite site = new SPSite(SPContext.Current.Site.ID))
            //{
            //    using (SPWeb web = site.OpenWeb(SPContext.Current.Web.ID))
            //    {
            //        DataTable dt = new UserBLL().GetUserByLogin(LoginName, Convert.ToInt32(cultureID));
            //        if (dt.Rows.Count > 0)
            //        {
            //            SPList lstTrack = web.Lists[dt.Rows[0]["DepartmentName"].ToString() + " Tasks Track"];
            //            SPQuery query = new SPQuery();
            //            SPUser user = web.EnsureUser(LoginName);

            //            query.Query = "<Where>" +
            //                            "<Eq><FieldRef Name='AssignedFrom' /><Value Type='User'>" + user.Name + "</Value></Eq>" +
            //                        "</Where>";
            //            query.RowLimit = 1;
            //            SPListItemCollection lstItems = lstTrack.GetItems(query);
            //            if (lstItems.Count > 0)
            //            {
            //                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.warning('" + new Common().GetResourceString("RecodDependance", cultureID) + "');", true);
            //                return false;
            //            }

            //            query = new SPQuery();
            //            query.Query = "<Where>" +
            //                            "<Eq><FieldRef Name='AssignedTo' /><Value Type='User'>" + user.Name + "</Value></Eq>" +
            //                        "</Where>";
            //            query.RowLimit = 1;

            //            lstItems = lstTrack.GetItems(query);
            //            if (lstItems.Count > 0)
            //            {
            //                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.warning('" + new Common().GetResourceString("RecodDependance", cultureID) + "');", true);
            //                return false;
            //            }
            //        }
            //    }
            //}

            return true;
        }

        private void ResetControls()
        {
            if (this.ddlDepartment.Items != null && this.ddlDepartment.Items.Count>0)
            ddlDepartment.SelectedIndex = 0;
            if (this.ddlDesignation.Items != null && this.ddlDepartment.Items.Count > 0)
            ddlDesignation.SelectedIndex = 0;
            if (this.ddlDistrict.Items != null && this.ddlDistrict.Items.Count > 0)
            ddlDistrict.SelectedIndex = 0;

            ddlUserType.SelectedIndex = 0;
            txtCNIC.Text = "";
            txtEmployeeName.Text = "";
            txtEmail.Text = "";
            txtCell.Text = "";
            ddlGroup.SelectedIndex = 0;
            txtLoginName.Text = string.Empty;
            cbxStatus.Checked = true;
            chkIsVisitLog.Checked = true;
            txtBlockReason.Text = "";
            ddlDepartment.Focus();
            ViewState["UserID"] = "";
            ViewState["Edit"] = "No";
            this.dtpJoined.Value = null;
            this.dtpResigned.Value = null;
            dtpResigned.Disabled = true;
            this.chkEnforceRight.Checked = false;           
            this.ddlAddressDivisions.SelectedIndex = 0;
            this.ddlAddressDistiricts.SelectedIndex = 0;
            this.txtFullAddress.Text = string.Empty;
            this.ClearChecked(this.cblAllDistricts);
            this.ClearChecked(this.cblUserRights);
            this.txtPassword.Text = string.Empty;
            this.txtConfirmPassword.Text = string.Empty;
            this.ddlUserType.SelectedIndex = 0;           
           
            this.ClearChecked(this.chkTehsils);
            this.ClearChecked(this.chkDesignations);
            this.ClearChecked(this.chkDepartments);
            this.ClearChecked(this.chkDepartmentFacilities);
            this.SetVisibilityOfControls();
            this.ddlDistrict_SelectedIndexChanged(null, null);
            this.ddlProvince.SelectedIndex = 0;
            this.GetDivisionByID(null);
            this.ClearddlItems(this.ddlReportingUsers);
            ViewState.Remove("UserID");
            ViewState.Remove(TableName.tblUserTehsil.ToString());
            this.txtImeNo.Text = string.Empty;
        }








        protected void ClearChecked(CheckBoxList chklStatues)
        {

            foreach (ListItem item in chklStatues.Items)
            {
                item.Selected = false;
            }

        }

        /// <summary>
        /// Get selected login window base login claim
        /// </summary>
        /// <remarks>CR:010</remarks>
        /// <returns></returns>
        private string GetLoginWindowsBaseClaim()
        {
            /*
            string login = peUserLogin.CommaSeparatedAccounts;
            if (ConfigurationManager.AppSettings["SignInMethod"].ToString() == "Form")
                login = login.Split('|')[2].ToString();
            else
                login = login.ToString().Substring(login.ToString().LastIndexOf(@"\") + 1, login.ToString().Length - (login.ToString().LastIndexOf(@"\") + 1));

            string userName = login;
            SPClaimProviderManager mgr = SPClaimProviderManager.Local;
            if (mgr == null) return userName;

            SPClaim claim = new SPClaim(SPClaimTypes.UserLogonName, login, "http://www.w3.org/2001/XMLSchema#string", SPOriginalIssuers.Format(SPOriginalIssuerType.Windows));
            userName = mgr.EncodeClaim(claim);

            return userName;
             */
            return null;
        }



        #endregion

        #region "Dropdown Events"

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {

            PopulateUsers();
            ddlDistrict.Focus();
            if (string.IsNullOrEmpty(this.ddlDistrict.SelectedValue) || Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0)
            {
                this.GetAllDistris();
                this.GetTehsilByID(null);
            }
            else
            {
                this.GetTehsilByID(Convert.ToInt32(this.ddlDistrict.SelectedValue));
            }
            this.SetVisibilityOfControls();
        }

        protected void ddlDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                if (!string.IsNullOrEmpty(this.ddlDepartment.SelectedValue) && Convert.ToInt32(this.ddlDepartment.SelectedValue) > 0)
                {
                   // ViewState["UserID"]
                    if(!string.IsNullOrEmpty(Convert.ToString(ViewState["UserID"])) )
                    {
                        GetReportingUsers(Convert.ToInt32(ViewState["UserID"]), Convert.ToInt32(this.ddlDepartment.SelectedValue));
                    }
                    else
                    {
                        GetReportingUsers(null, Convert.ToInt32(this.ddlDepartment.SelectedValue));
                    }
                    
                }
                else
                {
                    this.ClearddlItems(this.ddlReportingUsers);
                }

                this.SetVisibilityOfControls();
                
            }
            catch(Exception ex)
            {
                new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "ddlDepartment_SelectedIndexChanged", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                lblError.Text = ex.Message;
                pnlError.Visible = true;
            }

           
          
        }
        protected void ddlTehsil_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            this.SetVisibilityOfControls();
        }
        
        protected void ddlProvince_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                if (this.ddlProvince.SelectedValue != null && Convert.ToInt32(this.ddlProvince.SelectedValue) > 0)
                {
                    this.GetDivisionByID(Convert.ToInt32(this.ddlProvince.SelectedValue));

                }
                else
                {
                    this.GetDivisionByID(null);
                }

                this.GetAllDivisions();
            }
            catch (Exception ex)
            {

            }

        }

        protected void ddlDivision_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                if (!string.IsNullOrEmpty(this.ddlDivision.SelectedValue) && Convert.ToInt32(this.ddlDivision.SelectedValue) > 0)
                {
                    this.GetDistrict(Convert.ToInt32(this.ddlDivision.SelectedValue));

                }
                else
                {
                    this.GetDistrict(null);
                }

                this.SetVisibilityOfControls();
            }
            catch (Exception ex)
            {

            }

        }
      
        private void SetVisibilityOfControls()
        {
            this.divAllDivisions.Visible = ((string.IsNullOrEmpty(this.ddlDivision.SelectedValue) || Convert.ToInt32(this.ddlDivision.SelectedValue) == 0)) ? true : false;
            this.divAllDistricts.Visible = ((string.IsNullOrEmpty(this.ddlDistrict.SelectedValue ) || Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0)) ? true : false;
            this.divAllTehsils.Visible = ((string.IsNullOrEmpty(this.ddlTehsil.SelectedValue) || Convert.ToInt32(this.ddlTehsil.SelectedValue) == 0)) ? true : false;
            this.divAllDepartments.Visible = ((string.IsNullOrEmpty(this.ddlDepartment.SelectedValue) || Convert.ToInt32(this.ddlDepartment.SelectedValue) == 0)) ? true : false;
        }
        protected void ddlUserType_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.SetVisibilityOfControls();
        }



        /// <summary>
        /// dropdown Change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>


        protected void ddlAddressDivisions_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.GetAddressDistricts(Convert.ToInt32(this.ddlAddressDivisions.SelectedValue));
            this.ddlAddressDivisions.Focus();

        }



        #endregion

        #region "CheckBox Events"

        protected void cbxStatus_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxStatus.Checked == true)
                pnlBlockReason.Visible = false;
            else
                pnlBlockReason.Visible = true;
        }

        #endregion

        #region "Set Paging Method"

        private void SetPagingControl(RepeaterItemEventArgs e)
        {
            try
            {
                DataRowView rptRow = (DataRowView)e.Item.DataItem;
                DataTable dt = new DataTable();
                dt.Columns.Add("Value");

                //Display only PageNumber upto PagingSize            
                if ((PageStart + (PagingSize - 1)) <= PageCount)
                {
                    for (int i = PageStart; i <= PageStart + (PagingSize - 1); i++)
                        dt.Rows.Add(i);
                }
                else
                {
                    for (int i = PageStart; i <= PageCount; i++)
                        dt.Rows.Add(i);
                }

                Repeater rptPaging = (Repeater)e.Item.FindControl("rptPaging");
                rptPaging.DataSource = dt;
                rptPaging.DataBind();

                if (PageNumber == 0 || PageStart == 1)
                    ((LinkButton)e.Item.FindControl("lbtnPrevious")).Enabled = false;


                if (PageNumber == PageCount - 1 || (PageStart + PagingSize - 1) > PageCount)
                    ((LinkButton)e.Item.FindControl("lbtnNext")).Enabled = false;

                Label lbl = (Label)e.Item.FindControl("lblDisplayingRecords");
                if (TotalRecords != 0)
                {
                    if (TotalRecords > (PageNumber * PageSize + PageSize))
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + (PageNumber * PageSize + PageSize) + " of " + TotalRecords + " records";
                    else
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + TotalRecords + " of " + TotalRecords + " records";
                }
                else
                {
                    lbl.Text = "Showing 0 to 0 of 0 records";
                }
            }
            catch (Exception ex)
            {
                //new Common().AddErrorLog(ex, "SetPagingControl", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.Users);
                new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "SetPagingControl", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                lblError.Text = ex.Message;
                pnlError.Visible = true;
            }
        }

        #endregion

        #region "Repeator Events"

        protected void rptUsers_ItemCreated(object sender, RepeaterItemEventArgs e)
        {

            try
            {
                if (e.Item.ItemType == ListItemType.Footer)
                {
                    Repeater rptPaging = (Repeater)e.Item.FindControl("rptPaging");
                    rptPaging.ItemCommand += new RepeaterCommandEventHandler(rptPaging_ItemCommand);
                    rptPaging.ItemDataBound += new RepeaterItemEventHandler(rptPaging_ItemDataBound);
                }
            }
            catch (Exception ex)
            {

                new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "rptUsers_ItemCreated", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));

                lblError.Text = ex.Message;
                pnlError.Visible = true;
            }
        }

        protected void rptUsers_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                try
                {
                    UserModelView model = (UserModelView)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnUserID")).Value = model.UserID.ToString();
                    ((Label)e.Item.FindControl("lblLoginName")).Text = model.UserName;
                    ((Label)e.Item.FindControl("lblLoginID")).Text = model.UserID.ToString ();

                    ((Label)e.Item.FindControl("lblEmployeeName")).Text = model.EmployeeName;
                    ((Label)e.Item.FindControl("lblCNIC")).Text = model.CNIC;
                    ((Label)e.Item.FindControl("lblDistrict")).Text = model.District;

                    if (model.IsActive)
                    {
                        ((Label)e.Item.FindControl("lblActive")).CssClass = "label label-success label-mini";
                        ((Label)e.Item.FindControl("lblActive")).Text = "<i class='fa fa-check'></i>";
                        ((Label)e.Item.FindControl("lblActive")).ToolTip = "Active";
                    }
                    else
                    {
                        ((Label)e.Item.FindControl("lblActive")).CssClass = "label label-important label-mini";
                        ((Label)e.Item.FindControl("lblActive")).Text = "<i class='fa fa-times'></i>";
                        ((Label)e.Item.FindControl("lblActive")).ToolTip = "Block";
                    }

                    LinkButton lbtnDelete = (LinkButton)e.Item.FindControl("lbtnDelete");
                    lbtnDelete.Attributes.Add("onclick", "if ( ! confirm('Do you want to Block this record?')) return false;");
                }
                catch (Exception ex)
                {
                    //new Common().AddErrorLog(ex, "rptUsers_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.Users);
                    new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "rptUsers_ItemDataBound", 0, PageNames.Users, CurrentUser.LoginID));
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
            }
            else if (e.Item.ItemType == ListItemType.Footer)
            {
                this.SetPagingControl(e);
            }
        }

        protected void rptUsers_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                txtPassword.CssClass = txtPassword.CssClass.Replace("validate[required]", "");
                txtConfirmPassword.CssClass = txtConfirmPassword.CssClass.Replace("validate[required]", "");
                string strUserID = ((HiddenField)e.Item.FindControl("hdnUserID")).Value;
                ViewState["UserID"] = strUserID;
                ViewState["Edit"] = "Yes";
                //lbtnSave.Text = "<i class='fa fa-check'></i>&nbsp;Update";

                this.PopulateEditPanel(Convert.ToInt32(strUserID));

            }
            else if (e.CommandName == "Delete")
            {
                try
                {
                    string strUserID = ((HiddenField)e.Item.FindControl("hdnUserID")).Value;
                    string LoginName = ((Label)e.Item.FindControl("lblLoginName")).Text;
                    ViewState["UserID"] = strUserID;

                    //verify record depanded records
                    if (ValidateDependanceReocrd(LoginName))
                    {
                        //  string currentUserlogin = SPContext.Current.Web.CurrentUser.LoginName;
                        // currentUserlogin = currentUserlogin.ToString().Substring(currentUserlogin.ToString().LastIndexOf(@"\") + 1, currentUserlogin.ToString().Length - (currentUserlogin.ToString().LastIndexOf(@"\") + 1));

                        int result = new UserBLL().Delete(Convert.ToInt32(ViewState["UserID"]));
                        if (result > 0)
                        {
                            ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Record blocked successfully');", true);
                            ResetControls();
                            PopulateUsers();
                        }
                    }
                }
                catch (Exception ex)
                {
                    new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "rptUsers_DeleteCommand", 1, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
            }
            else if (e.CommandName == "Next")
            {
                if ((PageStart + PagingSize) <= PageCount)
                {
                    PageStart += PagingSize;
                    PageNumber = PageStart - 1;
                    //PageNumber = PageStart;
                }

                PopulateUsers();
            }

            else if (e.CommandName == "Previous")
            {
                if ((PageStart - PagingSize) >= 1)
                {
                    PageStart -= PagingSize;
                    PageNumber = PageStart - 1;
                    //PageNumber = PageStart;
                }

                PopulateUsers();
            }
        }



        #endregion

        #region "Paging Repeator Events"

        protected void rptPaging_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            LinkButton lbtnPageNumber = null;
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                lbtnPageNumber = (LinkButton)e.Item.FindControl("lbtnPageNumber");

                if (e.Item.ItemIndex == (PageNumber % PagingSize))
                {
                    ((HtmlGenericControl)e.Item.FindControl("liPageNo")).Attributes.Add("class", "active");
                }
                else
                {
                    ((HtmlGenericControl)e.Item.FindControl("liPageNo")).Attributes.Add("class", "");
                }

                lbtnPageNumber.Text = lbtnPageNumber.Text;
            }
            else if (e.Item.ItemType == ListItemType.Header)
            {
                if (PageNumber == 0 || PageStart == 1)
                {
                    ((LinkButton)e.Item.FindControl("lbtnPrevious")).Enabled = false;
                }
            }
            else if (e.Item.ItemType == ListItemType.Footer)
            {
                if (PageNumber == PageCount - 1 || (PageStart + PagingSize - 1) > PageCount)
                {
                    ((LinkButton)e.Item.FindControl("IbtnNext")).Enabled = false;
                }
            }
        }

        protected void rptPaging_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            if (e.CommandName == "PageNumber")
            {
                PageNumber = Convert.ToInt32(((LinkButton)e.Item.FindControl("lbtnPageNumber")).Text) - 1;
                PopulateUsers();
            }
        }

        #endregion

        #region "Button Click Events"

        private DataTable GetFeaturesMngntPermittedMenu(CheckBoxList chklst)
        {
            DataRow dr;
            DataTable dt = new DataTable();
            dt.Columns.Add("GroupID", typeof(string));
            dt.Columns.Add("AppFeatureID", typeof(string));
            dt.Columns.Add("AppObjectID", typeof(string));

            foreach (ListItem litem in chklst.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dt.NewRow();
                    dr["GroupID"] = 0;
                    dr["AppFeatureID"] = litem.Value;
                    dr["AppObjectID"] = 0;
                    dt.Rows.Add(dr);
                }
            }

            return dt;

        }

        protected void lbtnSave_Click(object sender, EventArgs e)
        {
            // model.Signature = hdnSignatureBase64.Value;

            //DAL
            //if (string.IsNullOrEmpty(model.Signature) == false)
            //{
            //    _sqlCmd.Parameters.Add(new SqlParameter("@Signature", SqlDbType.Binary));
            //    _sqlCmd.Parameters["@Signature"].Value = new CommonDAL().ConvertBase64ToBytes(model.Signature);
            //}

            //     public byte[] ConvertBase64ToBytes(string content)
            //{
            //    byte[] bytes = new byte[content.Length * sizeof(char)];
            //    System.Buffer.BlockCopy(content.ToCharArray(), 0, bytes, 0, bytes.Length);
            //    return bytes;
            //}

            //BAL
            //if (ds.Tables[0].Columns.Contains("Signature") && !Convert.IsDBNull(dr["Signature"]))
            //{
            //    byte[] Signature = (byte[])(dr["Signature"]);
            //    model.Signature = new CommonBLL().ConvertBytesToBase64(Signature);
            //}

            //            public string ConvertBytesToBase64(byte[] content)
            //{
            //    string Base64Content = "";
            //    using (MemoryStream memoryStream = new MemoryStream(content))
            //    {
            //        StreamReader streamReader = new StreamReader(memoryStream, Encoding.Unicode);
            //        Base64Content = streamReader.ReadToEnd();

            //        streamReader.Close();
            //    }

            //    return Base64Content;
            //}

            //GETMethod
            //hdnSignatureBase64.Value = model.Signature;
            //imgSignature.ImageUrl = model.Signature;

            try
            {
                // validate user input
                if (!ValidatePeoplePicker()) return;
                if (ViewState["Edit"].ToString() != "Yes")  // add new record
                {
                    string login = txtLoginName.Text;// peUserLogin.CommaSeparatedAccounts;
                    // login = login.Split('|')[2].ToString();

                    if (string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtConfirmPassword.Text))
                    {
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('You can not enter blank password. Please try again.');", true);
                        return;
                    }
                    //else if (!string.IsNullOrEmpty(txtPassword.Text) && !string.IsNullOrEmpty(txtConfirmPassword.Text) &&  string.Compare(txtConfirmPassword.Text.ToUpper(),txtPassword.Text.ToUpper())>0)
                    //{
                    //    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('Password does not match to confirm password. Please try again.');", true);
                    //    return;
                    //}

                    //varify user name exist in database
                    if (new CommonBLL().SelectRecordVerification(TableName.tblUser.ToString(), ColumnName.UserName.ToString(), login, ""))
                    {

                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('Login Name already register');", true);
                        return;
                    }

                    DateTime? dtJoine = null;
                    if (!string.IsNullOrEmpty(this.dtpJoined.Value))
                    {
                        string[] dateInfo = this.dtpJoined.Value.Split('/');
                        dtJoine = Convert.ToDateTime(dateInfo[1] + "/" + dateInfo[0] + "/" + dateInfo[2]);
                    }


                    UserRegistration user = new UserRegistration();
                    user.EnforceRight = this.chkEnforceRight.Checked;

                    user.JoinDate = dtJoine;


                    user.BlockReason = txtBlockReason.Text;

                    user.Status = cbxStatus.Checked;
                    user.IsVisitLog = chkIsVisitLog.Checked;

                    user.UserTypeID = Convert.ToInt32(ddlUserType.SelectedValue);
                    user.GroupID = Convert.ToInt32(ddlGroup.SelectedValue);
                    user.CellNumber = txtCell.Text;
                    user.IMENo = txtImeNo.Text;
                    user.EMail = txtEmail.Text;
                    user.CNIC = txtCNIC.Text;
                    user.EmployeeName = txtEmployeeName.Text;
                    user.LoginName = login;
                    if (!string.IsNullOrEmpty(this.ddlDistrict.SelectedValue))
                    user.GeneralDistrictID = Convert.ToInt32(this.ddlDistrict.SelectedValue);
                    if (Convert.ToInt32(ddlDepartment.SelectedValue) > 0)
                        user.DepartmentID = Convert.ToInt32(ddlDepartment.SelectedValue);
                    user.DesignationID = Convert.ToInt32(ddlDesignation.SelectedValue);
                    user.UserDistricts = this.FillUserDistricts(this.cblAllDistricts);
                    user.UserDivisions = this.FillUserDivisions(this.cblAllDivisions);
                    user.Signature = hdnSignatureBase64.Value;
                    //_sqlCmd.Parameters["@Signature"].Value = new CommonDAL().ConvertBase64ToBytes(model.Signature);


                    FillUserInfo(user);
                    if (IsValidUserData(user))
                    {
                        // this.SaveToSharePointCollection();
                        int result = new UserBLL().Save(user);      // CR: 009 END
                        if (result > 0)
                        {
                           // ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.success('Record saved successfully.');", true);
                           
                            ResetControls();
                            PopulateUsers();
                            ClearChecked(chkFeatures);
                            string script = "toastr.info('Record saved successfully.');";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        }
                    }

                } // end add new record
                else
                {

                    DateTime? dtJoine = null;
                    DateTime? dtResign = null;
                    if (!string.IsNullOrEmpty(this.dtpJoined.Value))
                    {
                        string[] dateInfo = this.dtpJoined.Value.Split('/');
                        dtJoine = Convert.ToDateTime(dateInfo[1] + "/" + dateInfo[0] + "/" + dateInfo[2]);
                    }
                    if (!string.IsNullOrEmpty(this.dtpResigned.Value))
                    {
                        string[] dateInfo = this.dtpResigned.Value.Split('/');
                        dtResign = Convert.ToDateTime(dateInfo[1] + "/" + dateInfo[0] + "/" + dateInfo[2]);
                    }

                    UserRegistration user = new UserRegistration();
                    user.EnforceRight = this.chkEnforceRight.Checked;

                    user.ResignDate = dtResign;
                    user.JoinDate = dtJoine;

                    user.BlockReason = txtBlockReason.Text;
                    user.Status = cbxStatus.Checked;
                    user.IsVisitLog = chkIsVisitLog.Checked;
                    user.UserTypeID = Convert.ToInt32(ddlUserType.SelectedValue);
                    user.GroupID = Convert.ToInt32(ddlGroup.SelectedValue);
                    user.CellNumber = txtCell.Text;
                    user.IMENo = txtImeNo.Text;
                    user.EMail = txtEmail.Text;
                    user.CNIC = txtCNIC.Text;
                    user.EmployeeName = txtEmployeeName.Text;
                    user.LoginName = txtLoginName.Text;
                    if (!string.IsNullOrEmpty(this.ddlDistrict.SelectedValue))
                        user.GeneralDistrictID = Convert.ToInt32(this.ddlDistrict.SelectedValue);
                    if (!string.IsNullOrEmpty(this.ddlDepartment.SelectedValue))
                    user.DepartmentID = Convert.ToInt32(ddlDepartment.SelectedValue);

                    user.DesignationID = Convert.ToInt32(ddlDesignation.SelectedValue);
                    user.Signature = hdnSignatureBase64.Value;
                    user.UserID = Convert.ToInt32(ViewState["UserID"]);
                    FillUserInfo(user);
                    user.UserDistricts = this.FillUserDistricts(this.cblAllDistricts);
                    user.UserDivisions = this.FillUserDivisions(this.cblAllDivisions);

                    if (IsValidUserData(user))
                    {
                        //this.SaveToSharePointCollection();
                        int result = new UserBLL().Update(user);
                        if (result > 0)
                        {
                            txtPassword.CssClass = "validate[required]";
                            txtConfirmPassword.CssClass = "validate[required]";
                           // ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.success('Record updated successfully.');", true);
                            ResetControls();
                            PopulateUsers();
                            ClearChecked(chkFeatures);
                            string script = "toastr.info('Record updated successfully.');";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LazyBaseSingletonBLL<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "lbtnSave_Click", 1, PageNames.Users, CurrentUser.GetSessionUserInfo()));

                lblError.Text = ex.Message;
                pnlError.Visible = true;
            }
        }
       
        protected void lbkbtnShowTehsil_Click(object sender, EventArgs e)
        {
            try
            {
                List<string> districtIDs = this.GetIDsFromCheckList(this.cblAllDistricts);
                if (districtIDs != null && districtIDs.Count > 0)
                {
                    this.GetTehsilsByCSV(districtIDs);
                    if (!string.IsNullOrEmpty(Convert.ToString(ViewState["UserID"])))
                    {
                       
                        DataTable dtUserTehsils = (DataTable)ViewState[TableName.tblUserTehsil.ToString()];
                        if (dtUserTehsils != null && dtUserTehsils.Rows.Count > 0 && this.chkTehsils.Items != null && this.chkTehsils.Items.Count > 0)
                        {

                            foreach (DataRow dr1 in dtUserTehsils.Rows)
                            {
                                ListItem lstItem = this.chkTehsils.Items.FindByValue(dr1["TehsilID"].ToString());
                                if (lstItem != null)
                                    lstItem.Selected = true;
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {

            }
        }

        internal void FillUserInfo(UserRegistration user)
        {
            user.CreatedBy  = CurrentUser.LoginID ?? 0;
            user.AddressDivisionID = Convert.ToInt32(this.ddlAddressDivisions.SelectedValue);
            user.AddressDistrictID = Convert.ToInt32(this.ddlAddressDistiricts.SelectedValue);
            user.FullAddress = this.txtFullAddress.Text;
            user.FileAdd = this.cblUserRights.Items[0].Selected;
            user.FileView = this.cblUserRights.Items[1].Selected;
            user.FileRemove = this.cblUserRights.Items[2].Selected;
            user.FileDownload = this.cblUserRights.Items[3].Selected;
            user.ActionTaken = this.cblUserRights.Items[4].Selected;
            user.IsAllowedToEdit = this.cblUserRights.Items[UserRightName.IsAllowedToEditRecord.GetHashCode()].Selected;
            
           
            user.Password = txtPassword.Text;

            // Add Featur Table
            DataTable featureMngtRights = this.GetFeaturesMngntPermittedMenu(this.chkFeatures);
            featureMngtRights.TableName = TableName.tblAppFeatures.ToString();
            user.UserFeaturs = featureMngtRights;


            //Sector and Sub Sectors
           
            
            user.UserTehsils = this.GetIDsTableFromCheckList(this.chkTehsils, this.ddlTehsil);
            user.UserDesignations = this.GetIDsTableFromCheckList(this.chkDesignations);
            user.UserDepartments  = this.GetIDsTableFromCheckList(this.chkDepartments);
            user.UserDepartmentFacility = this.GetIDsTableFromCheckList(this.chkDepartmentFacilities);
            //Multiple Tehsil
            if (!string.IsNullOrEmpty(this.ddlTehsil.SelectedValue) && Convert.ToInt32(this.ddlTehsil.SelectedValue) > 0)
                user.TehsilID = Convert.ToInt32(ddlTehsil.SelectedValue);

            if (!string.IsNullOrEmpty(this.ddlProvince.SelectedValue) && Convert.ToInt32(this.ddlProvince.SelectedValue) > 0)
                user.ProvinceID  = Convert.ToInt32(this.ddlProvince.SelectedValue);

            if (!string.IsNullOrEmpty(this.ddlDistrict.SelectedValue) && Convert.ToInt32(this.ddlDistrict.SelectedValue) > 0)
                user.GeneralDistrictID  = Convert.ToInt32(ddlDistrict.SelectedValue);

            if (!string.IsNullOrEmpty(this.ddlDivision.SelectedValue) && Convert.ToInt32(this.ddlDivision.SelectedValue) > 0)
                user.DivisionID  = Convert.ToInt32(ddlDivision.SelectedValue);

            if (!string.IsNullOrEmpty(this.ddlReportingUsers.SelectedValue) && Convert.ToInt32(this.ddlReportingUsers.SelectedValue) > 0)
                user.ReportingUserID = Convert.ToInt32(ddlReportingUsers.SelectedValue);

        }

        protected void lbtnCancel_Click(object sender, EventArgs e)
        {
            ResetControls();
            ViewState["PageNumber"] = null;
            PopulateUsers();
        }

        protected void lbtnSearch_Click(object sender, EventArgs e)
        {
            ViewState["PageNumber"] = null;
            PopulateUsers();
        }

        protected void lbtnReload_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            ddlSearchBy.SelectedIndex = 0;
            ViewState["PageNumber"] = null;
            PopulateUsers();
        }



        #endregion

        //protected void ddlUserType_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //    DropDownList ddl = sender as DropDownList;
        //    RepeaterItem ri = ddl.NamingContainer as RepeaterItem;

        //    if (ri != null)
        //    {
        //        DataRowView dataRowView = (DataRowView)ri.DataItem;
        //        DropDownList ddlUsers = (DropDownList)ri.FindControl("ddlUsers");
        //        DropDownList ddlDistricts = (DropDownList)ri.FindControl("ddlDistricts");
        //        string ddlUserTypeID = ((DropDownList)ri.FindControl("ddlUserType")).SelectedValue;

        //        ddlUsers.Items.Clear();

        //        ddlUsers.DataSource = new UserBLL().SelectUserByTypeID(Convert.ToInt32(ddlDistricts.SelectedValue), Convert.ToInt32(ddlUserTypeID));
        //        ddlUsers.DataTextField = "EmployeeName";
        //        ddlUsers.DataValueField = "UserID";
        //        ddlUsers.DataBind();
        //        ddlUsers.Items.Insert(0, new ListItem("Choose...", "0"));

        //    }
        //}


        #region Custom Methods
        private DataTable FillUserDistricts(CheckBoxList chklStatues)
        {
            DataRow dr;
            DataTable dtUserDistricts = new DataTable();
            dtUserDistricts.Columns.Add("ID", typeof(string));
            if (string.IsNullOrEmpty(this.ddlDistrict.SelectedValue) || Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0)
                foreach (ListItem litem in chklStatues.Items)
                {
                    if (litem.Selected && litem.Value != "0")
                    {
                        dr = dtUserDistricts.NewRow();
                        dr["ID"] = litem.Value;
                        dtUserDistricts.Rows.Add(dr);
                    }
                }

            return dtUserDistricts;

        }

        private DataTable FillUserDivisions(CheckBoxList chklist)
        {
            DataRow dr;
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(string));
            if (string.IsNullOrEmpty(this.ddlDivision.SelectedValue) || Convert.ToInt32(this.ddlDivision.SelectedValue) == 0)
                foreach (ListItem litem in chklist.Items)
                {
                    if (litem.Selected && litem.Value != "0")
                    {
                        dr = dt.NewRow();
                        dr["ID"] = litem.Value;
                        dt.Rows.Add(dr);
                    }
                }

            return dt;

        }

      
        //private DataTable GetUserSectorTable(CheckBoxList chklStatues)
        //{
        //    DataRow dr;
        //    DataTable dtUserSector = new DataTable();
        //    dtUserSector.Columns.Add("ID", typeof(string));
        //    if (string.IsNullOrEmpty(this.ddlSubSector.SelectedValue) || Convert.ToInt32(this.ddlSubSector.SelectedValue) == 0)
        //        foreach (ListItem litem in chklStatues.Items)
        //        {
        //            if (litem.Selected && litem.Value != "0")
        //            {
        //                dr = dtUserSector.NewRow();
        //                dr["ID"] = litem.Value;
        //                dtUserSector.Rows.Add(dr);
        //            }
        //        }

        //    return dtUserSector;

        //}
        //private DataTable GetUserSubSectorTable(CheckBoxList chklStatues)
        //{
        //    DataRow dr;
        //    DataTable dtUserSubSector = new DataTable();
        //    dtUserSubSector.Columns.Add("ID", typeof(string));
        //    if (string.IsNullOrEmpty(this.ddlSubSector.SelectedValue) || Convert.ToInt32(this.ddlSubSector.SelectedValue) == 0)
        //        foreach (ListItem litem in chklStatues.Items)
        //        {
        //            if (litem.Selected && litem.Value != "0")
        //            {
        //                dr = dtUserSubSector.NewRow();
        //                dr["ID"] = litem.Value;
        //                dtUserSubSector.Rows.Add(dr);
        //            }
        //        }

        //    return dtUserSubSector;

        //}

        private DataTable GetIDsTableFromCheckList(CheckBoxList chkList, DropDownList ddl)
        {
            DataRow dr;
            DataTable dtUserSubSector = new DataTable();
            dtUserSubSector.Columns.Add("ID", typeof(string));
            if (string.IsNullOrEmpty(ddl.SelectedValue) || Convert.ToInt32(ddl.SelectedValue) == 0)
                foreach (ListItem litem in chkList.Items)
                {
                    if (litem.Selected && litem.Value != "0")
                    {
                        dr = dtUserSubSector.NewRow();
                        dr["ID"] = litem.Value;
                        dtUserSubSector.Rows.Add(dr);
                    }
                }

            return dtUserSubSector;

        }

        private DataTable GetIDsTableFromCheckList(CheckBoxList chkList)
        {
            DataRow dr;
            DataTable dtIDs = new DataTable();
            dtIDs.Columns.Add("ID", typeof(string));

            foreach (ListItem litem in chkList.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dtIDs.NewRow();
                    dr["ID"] = litem.Value;
                    dtIDs.Rows.Add(dr);
                }
            }

            return dtIDs;

        }


        private bool IsValidUserData(UserRegistration user)
        {
            if ((string.IsNullOrEmpty(this.ddlDistrict.SelectedValue ) || Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0) && (user.UserDistricts == null || user.UserDistricts.Rows.Count == 0))
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Please select at least on district.');", true);
                this.ddlDistrict.Focus();
                return false;
            }
            return true;
        }
        private void BindUserRights()
        {
            this.cblUserRights.Items.Insert(0, new ListItem("File Add", "1"));
            this.cblUserRights.Items.Insert(1, new ListItem("File View", "2"));
            this.cblUserRights.Items.Insert(2, new ListItem("File Remove", "3"));
            this.cblUserRights.Items.Insert(3, new ListItem("File Download", "4"));
            this.cblUserRights.Items.Insert(4, new ListItem("Action Taken", "5"));
            this.cblUserRights.Items.Insert(5, new ListItem("Is Allowed Edit Record", "6"));
        }


        /// <summary>
        /// Add provided user login to sharepoint  Document Center collections
        /// 
        /// </summary>
        private bool SaveToSharePointCollection()
        {
            //try
            //{
            //    SPGroup groups;

            //    SPSecurity.RunWithElevatedPrivileges(delegate()
            //    {
            //        #region "Common Documents"

            //        using (SPSite site = new SPSite(ConfigurationManager.AppSettings["DocumentDownloadURL"].ToString()))
            //        {
            //            site.AllowUnsafeUpdates = true;

            //            using (SPWeb web = site.OpenWeb())
            //            {
            //                web.AllowUnsafeUpdates = true;
            //                groups = web.Groups[ConfigurationManager.AppSettings["DocumentCenterGroup"].ToString()];

            //                SPUser user = null;
            //                //string LoginName = GetLoginWindowsBaseClaim();             // get sharepoint claim token
            //                string LoginName = txtLoginName.Text;
            //                LoginName = web.EnsureUser(LoginName).LoginName;

            //                try
            //                {
            //                    user = groups.Users[LoginName];
            //                }
            //                catch
            //                { }

            //                if (user == null)       //Add user into user site collection
            //                {
            //                    //add user to group
            //                    groups.Users.Add(LoginName, string.Empty, txtEmployeeName.Text, string.Empty);
            //                    groups.Update();
            //                }
            //                else
            //                {
            //                    SPUser profile = web.SiteUsers[user.LoginName];
            //                    profile.Name = txtEmployeeName.Text;
            //                    profile.Update();
            //                }

            //                web.AllowUnsafeUpdates = false;

            //            }

            //            site.AllowUnsafeUpdates = false;
            //        }

            //        #endregion
            //    });
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}

            return true;
        }

        
        private List<string> GetIDsFromCheckList(CheckBoxList chkList)
        {
            List<string> sectorIDs = null;
            if (chkList.Items != null && chkList.Items.Count > 0)
            {
                sectorIDs = new List<string>();
                foreach (ListItem item in chkList.Items)
                {
                    if (item.Selected)
                    {
                        sectorIDs.Add(item.Value);
                    }
                }
            }

            return sectorIDs;

        }
        private List<string> GetAllIDsFromCheckList(CheckBoxList chkList)
        {
            List<string> sectorIDs = null;
            if (chkList.Items != null && chkList.Items.Count > 0)
            {
                sectorIDs = new List<string>();
                foreach (ListItem item in chkList.Items)
                {                    
                        sectorIDs.Add(item.Value);                  
                }
            }

            return sectorIDs;

        }
        #endregion
    }
}