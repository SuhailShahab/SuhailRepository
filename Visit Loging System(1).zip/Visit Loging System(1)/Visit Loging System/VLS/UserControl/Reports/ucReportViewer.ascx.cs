﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;

namespace VLS.UserControl.Reports
{
    public partial class ucReportViewer : System.Web.UI.UserControl
    {
        #region Custom Properties

        public string ReportName { get; set; }

        public List<Microsoft.Reporting.WebForms.ReportParameter> ParamList { get; set; }

        public List<Microsoft.Reporting.WebForms.ReportDataSource> DataSourceList { get; set; }

        private string testProperty;

        public string TestProperty
        {
            get { return testProperty; }
            set { testProperty = value; }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        #region Custom Methods

        public void LoadLocalReport()
        {
            try
            {
                cRptViewer.Width = Unit.Pixel(950);
                cRptViewer.Height = Unit.Pixel(700);

                // Update report and refresh
                string ReportPath = HttpContext.Current.Server.MapPath("/") + "ContentPages//Reports//Reports//" + this.GetReportPath() + ".rdlc";
                cRptViewer.LocalReport.ReportPath = ReportPath;

                if (this.ParamList != null && this.ParamList.Count > 0)
                {
                    cRptViewer.LocalReport.SetParameters(this.ParamList);
                }

                cRptViewer.LocalReport.DataSources.Clear();

                if (this.DataSourceList != null && this.DataSourceList.Count > 0)
                {
                    for (int i = 0; i < this.DataSourceList.Count; i++)
                    {
                        cRptViewer.LocalReport.DataSources.Add(this.DataSourceList[i]);
                    }
                }

                cRptViewer.LocalReport.Refresh();
            }
            catch (Exception ex)
            {
                //   Common.AddErrorLog(new ErrorLogModel(ex, "LoadReport in ReportViewer COntrol", 0, ServiceCodes.none, PageNames.ReportView));
            }
        }

        public string GetReportPath()
        {
            StringBuilder sbReprotPath = new StringBuilder();
            // sbReprotPath.Append(RptConfig.ReportPath);

            sbReprotPath.Append(this.ReportName);
            // sbReprotPath.Append(".rdl");
            return sbReprotPath.ToString();
        }

        #endregion
    }
}