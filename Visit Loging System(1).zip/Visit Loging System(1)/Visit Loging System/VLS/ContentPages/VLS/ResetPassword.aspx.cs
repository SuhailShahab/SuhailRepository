﻿using BE.CustomEnums;
using BE.RigthManager;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.VLS
{
    public partial class ResetPassword : System.Web.UI.Page
    {

        //protected override void OnPreInit(EventArgs e)
        //{
        //    base.OnPreInit(e);

        //    if (Session["UserTable"] != null)
        //    {
        //        DataTable dtUser = (DataTable)Session["UserTable"];
        //        SPWeb myWeb = SPControl.GetContextSite(Context).OpenWeb();
        //        this.MasterPageFile = myWeb.ServerRelativeUrl + dtUser.Rows[0]["MasterPageUrl"].ToString();
        //    }
        //    else
        //        Response.Redirect(SPContext.Current.Site.Url + "/_layouts/15/SignOut.aspx", true);
        //}
        protected void Page_Load(object sender, EventArgs e)
        {

            if (
                    CurrentUser.DepartmentID == null &&
                    CurrentUser.DistrictID == null &&
                    CurrentUser.SectorID == null &&
                    CurrentUser.SubSectorID == null &&
                    CurrentUser.TehsilID == null &&
                    CurrentUser.UserTypeID == UserTypeNames.Admin.GetHashCode()
               )
            {
                txtLogin.Enabled = true;
                oldpassword.Enabled = false;
                GetUserLogins();
            }
            else
                txtLogin.Text = CurrentUser.LoginName;

        }

        protected void resetpassword_Click(object sender, EventArgs e)
        {
            bool IsAdminUser = false;
            string loginName, oldPassword;

            if (CurrentUser.DepartmentID == null && CurrentUser.DistrictID == null &&
                    CurrentUser.SectorID == null && CurrentUser.SubSectorID == null && CurrentUser.TehsilID == null &&
                    CurrentUser.UserTypeID == UserTypeNames.Admin.GetHashCode())
            {
                IsAdminUser = true;
                loginName = txtLogin.Text;
                oldPassword = "";
            }
            else
            {
                loginName = CurrentUser.LoginName;
                oldPassword = oldpassword.Text;
            }

            if (string.IsNullOrEmpty(oldpassword.Text) && CurrentUser.UserTypeID != UserTypeNames.Admin.GetHashCode())
            {
                string script = "toastr.info('Please enter old passowrd...');";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            }
            //if (oldpassword.Text != oldpassword.Text)
            //{
            //    string script = "toastr.info('New password mismatch.');";
            //    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            //}
            else if (string.IsNullOrEmpty(retypePassword.Text) || string.IsNullOrEmpty(retypePassword.Text))
            {
                string script = "toastr.info('Please enter new password ...');";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            }

            else if ((retypePassword.Text == newpassword.Text) && (newpassword.Text != oldPassword))
            {
                int ret = new UserBLL().ResetPassword(loginName, oldPassword, newpassword.Text, CurrentUser.LoginID, IsAdminUser);
                if (ret > 0)
                {
                    if (!IsAdminUser)
                    {
                        HttpCookie aCookie;
                        string cookieName;
                        int limit = HttpContext.Current.Request.Cookies.Count;
                        for (int i = 0; i < limit; i++)
                        {
                            cookieName = HttpContext.Current.Request.Cookies[i].Name;
                            aCookie = new HttpCookie(cookieName);
                            aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                            HttpContext.Current.Response.Cookies.Add(aCookie); // overwrite it
                        }

                        //string script = "toastr.success('Password changed successfully.');";
                        //ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);

                        HttpContext.Current.Session.Abandon();
                        string url = "~/Login.aspx";
                        Response.Redirect(url, false);
                    }
                    else
                    {
                        string script = "toastr.success('Password changed successfully.');";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    }

                }
                else
                {
                    string script = "toastr.info('Password not changed. Try again.');";
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                }
            }
            else
            {
                string script = "toastr.info('Password mismatch. Try again.');";
                ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            }

        }

        protected void cancelReset_Click(object sender, EventArgs e)
        {
            oldpassword.Text = "";
            newpassword.Text = "";
            retypePassword.Text = "";

            string url = "~/ContentPages/RightsManager/ResetPassword.aspx";
            Response.Redirect(url, false);
        }

        private void GetUserLogins()
        {
            List<UserModelView> Users = new List<UserModelView>();
            Users = new UserBLL().GetUsersLoginNameInfo();
            /// TO DO: Set users login info in drop down///

        }
    }
}