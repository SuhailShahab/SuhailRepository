﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.VLS
{
    public partial class NewsDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #region "Web Methods"

        [WebMethod]
        public static NewsModel GetRecordByID(string ID)
        {

            NewsModel model = new NewsModel();

            try
            {
                if (!string.IsNullOrEmpty(ID))
                {
                    int NewsID = Convert.ToInt16(ID);
                    model = new NewsBLL().GetNewsByID(NewsID);
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordByID", 1, PageNames.NewsDetail, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new NewsModel("error|" + ex.Message);
                }
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecordByID", 1, PageNames.NewsDetail, CurrentUser.GetSessionUserInfo()));
            }

            return model;
        }

        #endregion
    }
}