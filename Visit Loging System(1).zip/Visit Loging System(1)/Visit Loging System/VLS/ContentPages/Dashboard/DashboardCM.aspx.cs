﻿using BE.Content;
using BE.CustomEnums;
using BE.Dashboard;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Dashboard;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Web.Services;
using VLS.ApplicationClasses;
using VLS.BLL.Dashboard;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <25-Mar-2016 02:50:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR:001       Syed Zeeshan Aqil           08-May-2016 5:11 PM             Add Method "GetVisitsLogPictures" to  get visit log the Picture List
// CR:002       Muhammad Hammad Shahid      20-06-2016 12:24:26             Get department facility collection
// =================================================================================================================================

namespace VLS.ContentPages.Dashboard
{
    public partial class DashboardCM : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"


        [WebMethod]
        public static DashboardCMModelView GetRecords(string jsonModel)
        {
            DashboardCMModelView model = new DashboardCMModelView();

            try
            {
                model.DashboardModel = new JavaScriptSerializer().Deserialize<DashboardCMModel>(jsonModel);
                model.Districts = LazyBaseSingletonBLL<DistrictBLL>.Instance.SelectAllActive();
                model.DepartmentFacilities = LazyBaseSingletonBLL<DepartmentFacilityBLL>.Instance.GetActiveDepartmentFacilities();


                // array for legneds counts - currently not in use , commented by hammad
                //model.Markers = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetFieldVisitsByDistrict(model.DashboardModel.DistrictID == 0 ? null : model.DashboardModel.DistrictID, 
                //    model.DashboardModel.FromDate, model.DashboardModel.ToDate);

                // comment by hammad, becuase data collect by selected desingations
                //model.Officials = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetVisitCountByAdministrativeSecretaries(model.DashboardModel.DistrictID == 0 ? null : model.DashboardModel.DistrictID, 
                //    model.DashboardModel.FromDate, model.DashboardModel.ToDate);       // array for officals visit counts - comment by hamamd: calculate on designation selection

                // Total visit count by dpt count
                //model.TotalDepartmentVisitCount = model.Officials.Select(p => p.VisitsCount).Sum();

                // =============================================================================================================================== //
                // ========================================== Collection of assigned designation ================================================= //
                if (model.DashboardModel.Designations.Count == 0)
                {
                    //model.DashboardModel.Designations.Add(new DesignationModel(0, "All"));
                    model.DashboardModel.Designations = LazyBaseSingletonBLL<DesignationBLL>.Instance.GetUsersDesignations(CurrentUser.CurrentUserInfo.UserID.Value);//.OrderBy(d => d.ID).ToList();

                }

                // =============================================================================================================================== //
                // ========================================== Collection of Visit by designation ================================================= //
                model.DesignationVisits = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetVisitCountByDesignation(model.DashboardModel.DistrictID == 0 ? null : model.DashboardModel.DistrictID,
                    model.DashboardModel.FromDate, model.DashboardModel.ToDate, model.DashboardModel.Designations, CurrentUser.CurrentUserInfo.UserID.Value, model.DashboardModel.FacilityID == 0 ? null : model.DashboardModel.FacilityID);

                // =============================================================================================================================== //
                // ====================================== Collection of Visit by district counts ================================================= //
                model.Legends = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetVisitCountByDistrict(model.DashboardModel.DistrictID == 0 ? null : model.DashboardModel.DistrictID,
                    model.DashboardModel.FromDate, model.DashboardModel.ToDate, model.DashboardModel.Designations, CurrentUser.CurrentUserInfo.UserID.Value, model.DashboardModel.FacilityID == 0 ? null : model.DashboardModel.FacilityID);

                // Total visit count by district count
                model.TotalDistrictVisitCount = model.Legends.Select(p => p.VisitsCount).Sum();

                model.IsAllowedToEdit = CurrentUser.GetSessionUserInfo().IsAllowedToEdit;
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetRecords", PageNames.DashboardCM));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message, typeof(DashboardCMModelView));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DashboardCMModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DashboardCMModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static string SendSMSToSecretary(string departmentID, string sms)
        {
            int deptID;
            string cellNumber;
            string result = "";
            if (departmentID != "undefined")
            {
                deptID = Convert.ToInt16(departmentID);
                cellNumber = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetSectaryCellNumberByID(deptID);
                if (!string.IsNullOrEmpty(cellNumber))
                {
                    if (CurrentUser.GetSessionUserInfo().UserTypeID == 3)
                        sms = sms + "\n \nFrom CM's Office.";
                    else
                        sms = sms + "\n \nFrom Chief Secretary's Office.";

                    try
                    {
                        LazyBaseSingletonUI<CommonUtility>.Instance.SendSMSAlert(cellNumber, sms);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
                else
                {
                    result = "1";
                }

            }
            return result;
        }

        [WebMethod]
        public static DashboardRatingModelView GetDepartmentsWiseVisitsPerformedBreakdownNew(string departmentID, string districtID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {

                int? divID = null;
                int? disID = null;

                if (districtID != "undefined")
                    disID = Convert.ToInt32(districtID);

                int? deptID = null;
                if (departmentID != "undefined")
                    deptID = Convert.ToInt16(departmentID);

                int? AssignToID = null;
                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                modelview = new DashboardReportBLL().GetDepartmentVisitsRatingPerformedBreakdownExt(AssignToID, divID, disID, deptID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartmentsWiseVisitsPerformedBreakdown", 1, PageNames.DashboardCM, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardRatingModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardRatingModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        [WebMethod]
        public static LogDetailView GetDashBoardMostRecentVisitRatingInfo()
        {
            //List<LogDetail> logDetail = new List<LogDetail>();
            LogDetailView logDetailvm = new LogDetailView();

            try
            {
                logDetailvm.LogDetail = LazyBaseSingletonBLL<DashboardReportBLL>.Instance.GetDashBoardMostRecentVisitRatingInfo();
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetDashBoardMostRecentVisitRatingInfo", 1, PageNames.DashboardCM, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetailvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetailvm.Notification = "error|" + ex.Message;
                }
            }

            return logDetailvm;
        }

        [WebMethod]
        public static LogDetailView GetDepartmentRatingLogDetailNew(string departmentID, string ratingID, string districtID)
        {
            LogDetailView logDetailvm = new LogDetailView();

            try
            {
                int? deptID = null;
                int? rateID = null;
                int? distID = null;
                if (districtID != "undefined")
                    distID = Convert.ToInt32(districtID);

                if (!string.IsNullOrEmpty(departmentID))
                    deptID = Convert.ToInt32(departmentID);
                if (ratingID != "0")
                    rateID = Convert.ToInt32(ratingID);
                int? userID = null;
                if (CurrentUser.DepartmentID.HasValue)
                    userID = CurrentUser.LoginID.Value;

                logDetailvm.LogDetail = new DashboardReportBLL().GetDepartmentRatingLogDetailNew(userID, deptID, rateID, distID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictRatingLogDetail", 1, PageNames.DashboardCM, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetailvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetailvm.Notification = "error|" + ex.Message;
                }
            }

            return logDetailvm;
        }

        /// <summary>
        /// // CR:001
        /// Get Visits Log Pictures data
        /// </summary>
        /// <param name="visitorLogID">Visitor Log ID</param>
        /// <returns></returns>
        [WebMethod]
        public static ActionImageModelView GetVisitsLogPictures(string visitorLogID)
        {
            ActionImageModelView modelView = new ActionImageModelView();

            try
            {
                modelView.ActionImageModel = LazyBaseSingletonBLL<DashboardReportBLL>.Instance.GetVisitsLogPictures(string.IsNullOrEmpty(visitorLogID) ? 0 : Convert.ToInt32(visitorLogID));
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetVisitsLogPictures", 1, PageNames.DashboardCM, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    modelView.Notification = "error|" + ex.Message;
                }
            }

            return modelView;
        }

        /// <summary>
        /// Get visits log rating breakdown by user (Grid rating) left panel
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="DistrictID"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <returns></returns>
        [WebMethod]
        public static DashboardRatingModelView GetVisitsPerformedBreakdownByUser(string UserID, string DistrictID, string FromDate, string ToDate, string FacilityID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {
                int? districtID = null;
                DateTime? fromDate = null;
                DateTime? toDate = null;
                int? facilityID = null;

                if (DistrictID != "undefined")
                    districtID = Convert.ToInt32(DistrictID);

                if (FromDate != "undefined" && ToDate != "undefined")
                {
                    fromDate = Convert.ToDateTime(FromDate);
                    toDate = Convert.ToDateTime(ToDate);
                }

                if (FacilityID != "undefined")
                    facilityID = Convert.ToInt32(FacilityID);

                modelview = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetRatingPerformedBreakdownByUserID(Convert.ToInt32(UserID), districtID, fromDate, toDate, facilityID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetVisitsPerformedBreakdownByUser", 1, PageNames.DashboardCM, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    modelview.Notification = "error|" + ex.Message;
                }
            }

            return modelview;
        }

        /// <summary>
        /// Get visit rating detail aginst provided user and rate
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="DistrictID"></param>
        /// <param name="RateID"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <returns></returns>
        [WebMethod]
        public static LogDetailView GetVisitRatingDetailByUser(string UserID, string DistrictID, string RateID, string FromDate, string ToDate, string FacilityID)
        {
            LogDetailView logDetailvm = new LogDetailView();

            try
            {
                int? districtID = null;
                int? rateID = null;
                DateTime? fromDate = null;
                DateTime? toDate = null;
                int? facilityID = null;

                if (DistrictID != "undefined")
                    districtID = Convert.ToInt32(DistrictID);

                if (RateID != "0")
                    rateID = Convert.ToInt32(RateID);

                if (FromDate != "undefined" && ToDate != "undefined")
                {
                    fromDate = Convert.ToDateTime(FromDate);
                    toDate = Convert.ToDateTime(ToDate);
                }

                if (FacilityID != "undefined")
                    facilityID = Convert.ToInt32(FacilityID);

                logDetailvm.LogDetail = LazyBaseSingletonUI<DashboardCMBLL>.Instance.GetVisitRatingDetailByUserID(Convert.ToInt32(UserID), districtID, rateID, fromDate, toDate, facilityID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetVisitRatingDetailByUser", 1, PageNames.DashboardCM, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetailvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetailvm.Notification = "error|" + ex.Message;
                }
            }

            return logDetailvm;
        }

        /// <summary>
        /// Get visits log rating breakdown by district (Grid rating)
        /// </summary>
        /// <param name="DistrictID"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <returns></returns>
        [WebMethod]
        public static DashboardRatingModelView GetVisitsPerformedBreakdownByDistrict(string DistrictID, string FromDate, string ToDate, string Designations, string FacilityID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {
                int? districtID = null;
                DateTime? fromDate = null;
                DateTime? toDate = null;
                int? facilityID = null;

                if (DistrictID != "undefined")
                    districtID = Convert.ToInt16(DistrictID);

                if (FromDate != "undefined" && ToDate != "undefined")
                {
                    fromDate = Convert.ToDateTime(FromDate);
                    toDate = Convert.ToDateTime(ToDate);
                }

                if (FacilityID != "undefined")
                    facilityID = Convert.ToInt32(FacilityID);

                List<DesignationModel> colDesignationIDs = new JavaScriptSerializer().Deserialize<List<DesignationModel>>(Designations);

                modelview = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetRatingPerformedBreakdownByDistrictID(districtID.Value, fromDate, toDate, colDesignationIDs, CurrentUser.CurrentUserInfo.UserID.Value, facilityID);
                modelview.Divisions = new DivisionBLL().GetDivisions();
                modelview.Districts = new DistrictBLL().SelectAllActive();
                modelview.Departments = new DepartmentBLL().GetDepartments();
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictsWiseVisitsPerformedBreakdown", 1, PageNames.VisitLog, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    modelview.Notification = "error|" + ex.Message;
                }
            }

            return modelview;
        }

        /// <summary>
        /// Get visit rationg detail against district and rate
        /// </summary>
        /// <param name="DivisionID"></param>
        /// <param name="DistrictID"></param>
        /// <param name="RatingID"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <returns></returns>
        [WebMethod]
        public static LogDetailView GetDistrictRatingLogDetail(string DistrictID, string RatingID, string FromDate, string ToDate, string Designations, string FacilityID)
        {
            LogDetailView logDetailvm = new LogDetailView();

            try
            {
                int? districtID = null;
                int? rateID = null;
                DateTime? fromDate = null;
                DateTime? toDate = null;
                int? facilityID = null;

                if (!string.IsNullOrEmpty(DistrictID))
                    districtID = Convert.ToInt32(DistrictID);

                if (RatingID != "0")
                    rateID = Convert.ToInt32(RatingID);

                if (FromDate != "undefined" && ToDate != "undefined")
                {
                    fromDate = Convert.ToDateTime(FromDate);
                    toDate = Convert.ToDateTime(ToDate);
                }

                if (FacilityID != "undefined")
                    facilityID = Convert.ToInt32(FacilityID);

                List<DesignationModel> colDesignationIDs = new JavaScriptSerializer().Deserialize<List<DesignationModel>>(Designations);

                logDetailvm.LogDetail = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetDistrictRatingLogDetail(districtID.Value, rateID, fromDate, toDate, colDesignationIDs, CurrentUser.CurrentUserInfo.UserID.Value, facilityID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictRatingLogDetail", 1, PageNames.DashboardCM, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetailvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetailvm.Notification = "error|" + ex.Message;
                }
            }

            return logDetailvm;
        }

        /// <summary>
        /// Get designations against provided facility
        /// </summary>
        /// <param name="FacilityID"></param>
        /// <returns></returns>
        [WebMethod]
        public static DesignationModelView GetDesignationByFacility(string FacilityID)
        {
            DesignationModelView DesignationModelvm = new DesignationModelView();

            try
            {
                if (FacilityID != "undefined")
                    DesignationModelvm.colDesingations = LazyBaseSingletonBLL<DesignationBLL>.Instance.GetDesignationsByFacilityID(Convert.ToInt32(FacilityID));
                else
                    DesignationModelvm.colDesingations = LazyBaseSingletonBLL<DesignationBLL>.Instance.GetUsersDesignations(CurrentUser.CurrentUserInfo.UserID.Value);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDesignationByFacility", 1, PageNames.DashboardCM, CurrentUser.GetSessionUserInfo()));
                //colDesingations = new List<DesignationModel>();
                //colDesingations.Add(new DesignationModel(ex.Message));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardCM));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    DesignationModelvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    DesignationModelvm.Notification = "error|" + ex.Message;
                }
            }

            return DesignationModelvm;
        }

        #endregion
    }
}


#region "Commented"
//[WebMethod]
//public static List<DistrictVisistsModel> GetFieldVisitsByDistrict()
//{
//    List<DistrictVisistsModel> colVisits = new List<DistrictVisistsModel>();

//    try
//    {
//        colVisits = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetFieldVisitsByDistrict(null, null);
//    }
//    catch (Exception ex)
//    {
//        new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetFieldVisitsByDistrict", PageNames.DashboardCM));
//    }

//    return colVisits;
//}

//[WebMethod]
//public static List<DistrictVisitsCountModel> GetVisitsCountsByDistrict()
//{
//    List<DistrictVisitsCountModel> colVisits = new List<DistrictVisitsCountModel>();

//    try
//    {
//        colVisits = LazyBaseSingletonBLL<DashboardCMBLL>.Instance.GetVisitCountByDistrict(null, null);
//    }
//    catch (Exception ex)
//    {
//        new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetVisitsCountsByDistrict", PageNames.DashboardCM));
//    }

//    return colVisits;
//}

#endregion