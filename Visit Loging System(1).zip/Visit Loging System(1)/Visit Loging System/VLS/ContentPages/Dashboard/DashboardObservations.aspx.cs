﻿using BE.Content;
using BE.CustomEnums;
using BE.Dashboard;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Dashboard;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web.Services;
using VLS.ApplicationClasses;
using VLS.BLL.Dashboard;
// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <25-Mar-2016 02:50:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR:001       Syed Zeeshan Aqil           08-May-2016 5:11 PM             Add Method "GetVisitsLogPictures" to  get visit log the Picture List
// =================================================================================================================================
namespace VLS.ContentPages.Dashboard
{
    public partial class DashboardObservations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        /// <summary>
        /// Get Assign Task on Designation Base
        /// </summary>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="designationID">Selected Designation ID</param>
        /// <returns>DashBoard Model View</returns>
        [WebMethod]
        public static DashBoardModelView GetDashBoardAssignTaskForDesignation(string pageNo, string pageSize, string designationID, string rateID, string SortColumn, string SortDirection)
        {
            DashBoardModelView model = new DashBoardModelView();
            try
            {

                //Sorting Apply -Zeeshan
                string sortColumn = null;
                int? sortDirection = null;

                if (SortColumn != "")
                    sortColumn = SortColumn;
                if (SortDirection != "0")
                    sortDirection = Convert.ToInt32(SortDirection);

                List<DesignationModel> designations = LazyBaseSingletonBLL<DesignationBLL>.Instance.GetDashboardDesignations(CurrentUser.LoginID.Value);

                // collection observation records against current user
                model = LazyBaseSingletonBLL<DashboardObservationsBLL>.Instance.GetDashBoardAssignTaskForDesignation(
                                    CurrentUser.LoginID.Value, Convert.ToInt32(pageNo), Convert.ToInt32(pageSize),
                                    designationID == "0" ? designations[0].ID.Value : Convert.ToInt32(designationID),
                    Convert.ToInt32(rateID), sortColumn, sortDirection, CurrentUser.DivisionID, CurrentUser.DistrictID);

                //model.Counts.RemoveAt(0);       // remove visit perfomed counts - set by hammmad
                model.DashboardTitle = CurrentUser.DashboardTitle;
                model.UserDesignation = CurrentUser.UserDesignationName;
                model.UserDepartment = CurrentUser.UserDepartmentName;
                model.Designations = designations;
                model.UserDesignationID = CurrentUser.CurrentUserInfo.DesignationID.Value;
                model.IsActionTaken = CurrentUser.CurrentUserInfo.AllowActionTaken.Value;

                model.DesignationID = designationID == "0" ? designations[0].ID.Value : Convert.ToInt32(designationID);
                model.PageNo = Convert.ToInt32(pageNo);
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetDashBoardAssignTaskForDesignation", PageNames.DashboardObservation));
                //model = new DashBoardModelView("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardObservation));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DashBoardModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DashBoardModelView("error|" + ex.Message);
                }
            }

            return model;
        }


        /// <summary>
        /// // CR:001
        /// Get Visits Log Pictures data
        /// </summary>
        /// <param name="visitorLogID">Visitor Log ID</param>
        /// <returns></returns>
        [WebMethod]
        public static ActionImageModelView GetVisitsLogPictures(string visitorLogID)
        {
            ActionImageModelView models = new ActionImageModelView();
            try
            {
                models.ActionImageModel = LazyBaseSingletonBLL<DashboardReportBLL>.Instance.GetVisitsLogPictures(string.IsNullOrEmpty(visitorLogID) ? 0 : Convert.ToInt32(visitorLogID));
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetVisitsLogPictures", 1, PageNames.DashboardObservation, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardObservation));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    models.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    models.Notification = "error|" + ex.Message;
                }
            }

            return models;
        }

        #endregion
    }
}