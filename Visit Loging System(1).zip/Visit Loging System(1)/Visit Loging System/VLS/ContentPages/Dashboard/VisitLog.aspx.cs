﻿using BE.Content;
using BE.CustomEnums;
using BE.Dashboard;
using BE.LogManager;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Services;
using VLS.ApplicationClasses;
using VLS.BLL.Dashboard;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <10-May-2016 02:50:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR:001       Syed Zeeshan Aqil           08-May-2016 5:11 PM             Add Method "GetVisitsLogPictures" to  get visit log the Picture List
// CR:002       Muhammad Hammad Shahid      22-06-2016 12:29:46PM           Add facility id drop down and pass FacilityID parameters pass in all web methods
// =================================================================================================================================
namespace VLS.ContentPages.Dashboard
{
    public partial class VisitLog : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "WebMethod"

        /// <summary>
        /// Get the Rating info on District and Department Base
        /// </summary>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="DistrictID">selected District ID</param>
        /// <param name="DepartmentID">selected Department ID</param>
        /// <returns></returns>
        [WebMethod]
        public static DashboardRatingModelView GetAllVisitsPerformedBreakdown(string DivisionID, string DistrictID, string DepartmentID, string FacilityID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {
                int? divisionID = null;
                int? districtID = null;
                int? departmentID = null;
                int? facilityID = null;

                if (DivisionID != "undefined")
                    divisionID = Convert.ToInt32(DivisionID);

                if (DistrictID != "undefined")
                    districtID = Convert.ToInt32(DistrictID);

                if (DepartmentID != "undefined")
                    departmentID = Convert.ToInt32(DepartmentID);

                if (FacilityID != "undefined")      //CR:002
                    facilityID = Convert.ToInt32(FacilityID);

                int? AssignToID = null;

                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                modelview = LazyBaseSingletonBLL<DashboardReportBLL>.Instance.GetVisitsRatingPerformedBreakdown(AssignToID, divisionID, districtID, departmentID, facilityID);

                modelview.Divisions = LazyBaseSingletonBLL<DivisionBLL>.Instance.GetDivisions();
                modelview.Districts = LazyBaseSingletonBLL<DistrictBLL>.Instance.SelectAllActive();
                modelview.Departments = LazyBaseSingletonBLL<DepartmentBLL>.Instance.GetDepartments();
                modelview.Designations = LazyBaseSingletonBLL<DesignationBLL>.Instance.GetUsersDesignations(CurrentUser.CurrentUserInfo.UserID.Value).OrderBy(d => d.ID).ToList();
                modelview.DepartmentFacilities = LazyBaseSingletonBLL<DepartmentFacilityBLL>.Instance.GetActiveDepartmentFacilities(); // CR:002
                modelview.IsAllowedToEdit = CurrentUser.GetSessionUserInfo().IsAllowedToEdit;

            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetAllVisitsPerformedBreakdown", 1, PageNames.VisitLog, CurrentUser.GetSessionUserInfo()));
                //modelview.Notification = ex.Message;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.VisitLog));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardRatingModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardRatingModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        /// <summary>
        /// Get the rating info on Department base
        /// </summary>
        /// <param name="departmentID">selected department ID</param>
        /// <returns></returns>
        [WebMethod]
        public static DashboardRatingModelView GetDepartmentsWiseVisitsPerformedBreakdown(string departmentID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {

                int? divID = null;
                int? disID = null;
                int? deptID = null;
                if (departmentID != "undefined")
                    deptID = Convert.ToInt16(departmentID);

                int? AssignToID = null;
                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                modelview = new DashboardReportBLL().GetDepartmentVisitsRatingPerformedBreakdown(AssignToID, divID, disID, deptID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartmentsWiseVisitsPerformedBreakdown", 1, PageNames.VisitLog, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.VisitLog));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardRatingModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardRatingModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        /// <summary>
        /// Get the Rating on department base
        /// </summary>
        /// <param name="DepartmentID">selected department id</param>
        /// <param name="RatingID">selected rating ID</param>
        /// <returns></returns>
        [WebMethod]
        public static LogDetailView GetDepartmentRatingLogDetail(string DepartmentID, string RatingID)
        {
            LogDetailView logDetail = new LogDetailView();

            try
            {
                int? deptID = null;
                int? rateID = null;

                if (!string.IsNullOrEmpty(DepartmentID))
                    deptID = Convert.ToInt32(DepartmentID);
                if (RatingID != "0")
                    rateID = Convert.ToInt32(RatingID);
                int? UserID = null;
                if (CurrentUser.DepartmentID.HasValue)
                    UserID = CurrentUser.LoginID.Value;

                logDetail.LogDetail = new DashboardReportBLL().GetDepartmentRatingLogDetail(UserID, deptID, rateID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictRatingLogDetail", 1, PageNames.VisitLog, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.VisitLog));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetail.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetail.Notification = "error|" + ex.Message;
                }
            }

            return logDetail;
        }

        /// <summary>
        /// // CR:001
        /// Get Visits Log Pictures data
        /// </summary>
        /// <param name="visitorLogID">Visitor Log ID</param>
        /// <returns></returns>
        [WebMethod]
        public static ActionImageModelView GetVisitsLogPictures(string visitorLogID)
        {
            ActionImageModelView models = new ActionImageModelView();
            try
            {
                models.ActionImageModel = LazyBaseSingletonBLL<DashboardReportBLL>.Instance.GetVisitsLogPictures(string.IsNullOrEmpty(visitorLogID) ? 0 : Convert.ToInt32(visitorLogID));
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetVisitsLogPictures", 1, PageNames.VisitLog, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.VisitLog));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    models.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    models.Notification = "error|" + ex.Message;
                }
            }

            return models;
        }

        #endregion

        #region "Web Methods (District)"

        /// <summary>
        /// Get the Rating info on district Base
        /// </summary>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="DistrictID">slected district ID</param>
        /// <returns></returns>
        [WebMethod]
        public static DashboardRatingModelView GetDistrictsWiseVisitsPerformedBreakdown(string DivisionID, string DistrictID, string FacilityID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {
                int? divisionID = null;
                int? districtID = null;
                int? departmentID = null;
                int? AssignToID = null;
                int? facilityID = null;

                if (DivisionID != "undefined")
                    divisionID = Convert.ToInt16(DivisionID);

                if (DistrictID != "undefined")
                    districtID = Convert.ToInt16(DistrictID);

                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                if (FacilityID != "undefined")
                    facilityID = Convert.ToInt32(FacilityID);

                modelview = new DashboardReportBLL().GetDistrictVisitsRatingPerformedBreakdown(AssignToID, divisionID, districtID, departmentID, facilityID);

                modelview.Divisions = new DivisionBLL().GetDivisions();
                modelview.Districts = new DistrictBLL().SelectAllActive();
                modelview.Departments = new DepartmentBLL().GetDepartments();
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictsWiseVisitsPerformedBreakdown", 1, PageNames.VisitLog, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.VisitLog));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardRatingModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardRatingModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        /// <summary>
        /// Get the Rating State on District base
        /// </summary>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="DistrictID">selected district ID</param>
        /// <param name="RatingID">selceted rating ID</param>
        /// <returns></returns>
        [WebMethod]
        public static LogDetailView GetDistrictRatingLogDetail(string DivisionID, string DistrictID, string RatingID, string FacilityID)
        {
            LogDetailView logDetailvm = new LogDetailView();
            try
            {
                int? divisionID = null;
                int? districtID = null;
                int? rateID = null;
                int? UserID = null;
                int? facilityID = null;


                if (!string.IsNullOrEmpty(DivisionID))
                    divisionID = Convert.ToInt32(DivisionID);

                if (!string.IsNullOrEmpty(DistrictID))
                    districtID = Convert.ToInt32(DistrictID);

                if (RatingID != "0")
                    rateID = Convert.ToInt32(RatingID);

                if (FacilityID != "undefined")      //CR:002
                    facilityID = Convert.ToInt32(FacilityID);

                if (CurrentUser.DepartmentID.HasValue)
                    UserID = CurrentUser.LoginID.Value;

                logDetailvm.LogDetail = new DashboardReportBLL().GetDistrictRatingLogDetail(UserID, divisionID, districtID, rateID, facilityID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictRatingLogDetail", 1, PageNames.VisitLog, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.VisitLog));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetailvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetailvm.Notification = "error|" + ex.Message;
                }
            }

            return logDetailvm;
        }

        #endregion

        #region "Web Methods (Desingation)"

        /// <summary>
        /// Get the rating info on Department base wrt Designation
        /// </summary>
        /// <param name="departmentID">selected department ID, Designation ID</param>
        /// <returns></returns>
        [WebMethod]
        public static DashboardRatingModelView GetDesignationWiseVisitsPerformedBreakdown(string DesignationID, string FacilityID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {
                int? designationID = null;
                int? facilityID = null;

                if (DesignationID != "undefined")
                    designationID = Convert.ToInt16(DesignationID);

                if (FacilityID != "undefined")
                    facilityID = Convert.ToInt32(FacilityID);

                modelview = new DashboardReportBLL().GetDesignationsWiseVisitsPerformedBreakdown(designationID, facilityID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDesignationWiseVisitsPerformedBreakdown", 1, PageNames.VisitLog, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.VisitLog));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardRatingModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardRatingModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        #endregion

    }
}