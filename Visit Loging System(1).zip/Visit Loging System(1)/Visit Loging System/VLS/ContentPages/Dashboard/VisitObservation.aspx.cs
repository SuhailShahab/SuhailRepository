﻿using BE.Content;
using BE.CustomEnums;
using BE.Dashboard;
using BE.LogManager;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;
using VLS.BLL.Dashboard;



// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <10-May-2016 02:50:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR:001       Syed Zeeshan Aqil           08-May-2016 5:11 PM             Add Method "GetVisitsLogPictures" to  get visit log the Picture List
// =================================================================================================================================

namespace VLS.ContentPages.Dashboard
{
    public partial class VisitObservation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "WebMethod"

        /// <summary>
        /// Get the Rating info on District and Department Base
        /// </summary>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="DistrictID">selected District ID</param>
        /// <param name="DepartmentID">selected Department ID</param>
        /// <returns></returns>
        [WebMethod]
        public static DashboardRatingModelView GetAllVisitsObservedBreakdown(string DivisionID, string DistrictID, string DepartmentID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {
                int? divID = null;
                int? disID = null;
                int? deptID = null;

                if (DivisionID != "undefined")
                    divID = Convert.ToInt16(DivisionID);
                if (DistrictID != "undefined")
                    disID = Convert.ToInt16(DistrictID);
                if (DepartmentID != "undefined")
                    deptID = Convert.ToInt16(DepartmentID);


                int? AssignToID = null;

                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                modelview = new DashboardReportBLL().GetVisitsRatingObservationBreakdown(AssignToID, divID, disID, deptID);
                modelview.Divisions = new DivisionBLL().GetDivisions();
                modelview.Districts = new DistrictBLL().SelectAllActive();
                modelview.Departments = new DepartmentBLL().GetDepartments();

            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllVisitsPerformedBreakdown", 1, PageNames.VisitObservation, CurrentUser.GetSessionUserInfo()));
                // LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationMsg(new DashboardRatingModelView(), ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.VisitObservation));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardRatingModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardRatingModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }


        /// <summary>
        /// Get the Rating info on district Base
        /// </summary>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="DistrictID">slected district ID</param>
        /// <returns></returns>
        [WebMethod]
        public static DashboardRatingModelView GetDistrictsWiseVisitsObservedBreakdown(string DivisionID, string DistrictID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {
                int? divID = null;
                int? disID = null;
                int? deptID = null;

                if (DivisionID != "undefined")
                    divID = Convert.ToInt16(DivisionID);
                if (DistrictID != "undefined")
                    disID = Convert.ToInt16(DistrictID);

                int? AssignToID = null;

                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                modelview = new DashboardReportBLL().GetDistrictVisitsRatingObservationBreakdown(AssignToID, divID, disID, deptID);
                modelview.Divisions = new DivisionBLL().GetDivisions();
                modelview.Districts = new DistrictBLL().SelectAllActive();
                modelview.Departments = new DepartmentBLL().GetDepartments();


            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictsWiseVisitsPerformedBreakdown", 1, PageNames.VisitObservation, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardRatingModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardRatingModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        /// <summary>
        /// Get the rating info on Department base
        /// </summary>
        /// <param name="departmentID">selected department ID</param>
        /// <returns></returns>
        [WebMethod]
        public static DashboardRatingModelView GetDepartmentsWiseVisitsObservedBreakdown(string departmentID)
        {
            DashboardRatingModelView modelview = new DashboardRatingModelView();

            try
            {

                int? divID = null;
                int? disID = null;
                int? deptID = null;
                if (departmentID != "undefined")
                    deptID = Convert.ToInt16(departmentID);

                int? AssignToID = null;
                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                modelview = new DashboardReportBLL().GetVisitsRatingObservationBreakdown(AssignToID, divID, disID, deptID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDepartmentsWiseVisitsPerformedBreakdown", 1, PageNames.VisitObservation, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardRatingModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardRatingModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        /// <summary>
        /// Get the Rating State on District base
        /// </summary>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="DistrictID">selected district ID</param>
        /// <param name="RatingID">selceted rating ID</param>
        /// <returns></returns>
        [WebMethod]
        public static LogDetailView GetDistrictRatingLogDetail(string DivisionID, string DistrictID, string RatingID)
        {
            LogDetailView logDetailvm = new LogDetailView();
            try
            {
                int? divisionID = null;
                int? districtID = null;
                int? rateID = null;


                if (!string.IsNullOrEmpty(DivisionID))
                    divisionID = Convert.ToInt32(DivisionID);
                if (!string.IsNullOrEmpty(DistrictID))
                    districtID = Convert.ToInt32(DistrictID);
                if (RatingID != "0")
                    rateID = Convert.ToInt32(RatingID);
                int? UserID = null;

                if (CurrentUser.DepartmentID.HasValue)
                    UserID = CurrentUser.LoginID.Value;

                logDetailvm.LogDetail = new DashboardReportBLL().GetDistrictRatingLogDetail(UserID, divisionID, districtID, rateID, null);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictRatingLogDetail", 1, PageNames.VisitObservation, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetailvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetailvm.Notification = "error|" + ex.Message;
                }
            }

            return logDetailvm;
        }

        /// <summary>
        /// Get the Rating on department base
        /// </summary>
        /// <param name="DepartmentID">selected department id</param>
        /// <param name="RatingID">selected rating ID</param>
        /// <returns></returns>
        [WebMethod]
        public static LogDetailView GetDepartmentRatingLogDetail(string DepartmentID, string RatingID)
        {
            LogDetailView logDetailvm = new LogDetailView();

            try
            {
                int? deptID = null;
                int? rateID = null;

                if (!string.IsNullOrEmpty(DepartmentID))
                    deptID = Convert.ToInt32(DepartmentID);
                if (RatingID != "0")
                    rateID = Convert.ToInt32(RatingID);
                int? UserID = null;
                if (CurrentUser.DepartmentID.HasValue)
                    UserID = CurrentUser.LoginID.Value;

                logDetailvm.LogDetail = new DashboardReportBLL().GetDepartmentRatingObservedLogDetail(UserID, deptID, rateID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictRatingLogDetail", 1, PageNames.VisitObservation, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetailvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetailvm.Notification = "error|" + ex.Message;
                }
            }

            return logDetailvm;
        }


        /// <summary>
        /// // CR:001
        /// Get Visits Log Pictures data
        /// </summary>
        /// <param name="visitorLogID">Visitor Log ID</param>
        /// <returns></returns>
        [WebMethod]
        public static ActionImageModelView GetVisitsLogPictures(string visitorLogID)
        {
            ActionImageModelView models = new ActionImageModelView();
            try
            {
                models.ActionImageModel = LazyBaseSingletonBLL<DashboardReportBLL>.Instance.GetVisitsLogPictures(string.IsNullOrEmpty(visitorLogID) ? 0 : Convert.ToInt32(visitorLogID));
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetVisitsLogPictures", 1, PageNames.VisitObservation, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    models.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    models.Notification = "error|" + ex.Message;
                }
            }

            return models;
        }
        #endregion
    }
}