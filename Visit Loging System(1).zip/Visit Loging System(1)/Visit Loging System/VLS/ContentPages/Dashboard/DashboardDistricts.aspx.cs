﻿using BE.CustomEnums;
using BE.Dashboard;
using BE.LogManager;
using BLL.CommonUtility;
using BLL.Lookups;
using DAL.Enums;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Web.Services;
using VLS.ApplicationClasses;
using VLS.BE.Dashboard;
using VLS.BLL.Dashboard;

namespace VLS.ContentPages.Dashboard
{
    public partial class DashboardDistricts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        #region "Web Methods"

        [WebMethod]
        public static ChartModelView GetDepartmentVisitsByDistrict(int? DistrictID)
        {
            ChartModelView collection = new ChartModelView();

            try
            {
                collection.ChartModel = LazyBaseSingletonBLL<DashboardDistrictsBLL>.Instance.GetDepartmentVisitsByDistrict(DistrictID);
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetDepartmentVisitsByDistrict", PageNames.DashboardDistrict));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardDistrict));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    collection.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    collection.Notification = "error|" + ex.Message;
                }
            }

            return collection;
        }

        [WebMethod]
        public static ChartModelView GetVisitsStatusByDistrict(int? DistrictID)
        {
            ChartModelView collection = new ChartModelView();

            try
            {
                collection.ChartModel = LazyBaseSingletonBLL<DashboardDistrictsBLL>.Instance.GetVisitsStatusByDistrict(DistrictID);
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetVisitsStatusByDistrict", PageNames.DashboardDistrict));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardDistrict));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    collection.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    collection.Notification = "error|" + ex.Message;
                }
            }

            return collection;
        }

        [WebMethod]
        public static DashBoardModelView GetVisitsLogsDashboardDistrict(int? DistrictID, string PageNo, string PageSize)
        {
            DashBoardModelView collection = new DashBoardModelView();

            try
            {
                collection.TasksCommissioner = LazyBaseSingletonBLL<DashboardDistrictsBLL>.Instance.GetVisitsLogsDashboardDistrict(DistrictID, Convert.ToInt32(PageNo), Convert.ToInt32(PageSize));
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLogs(new ErrorLogModel(ex, "GetVisitsLogsDashboardDistrict", PageNames.DashboardDistrict));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardDistrict));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    collection.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    collection.Notification = "error|" + ex.Message;
                }
            }

            return collection;
        }


        [WebMethod]
        public static DashboardDistrictModel GetRecords()
        {
            DashboardDistrictModel model = new DashboardDistrictModel();

            try
            {
                model.Districts = LazyBaseSingletonBLL<DistrictBLL>.Instance.SelectAllActive();
                model.Tehsils = LazyBaseSingletonBLL<TehsilBLL>.Instance.SelectAllActive();
                model.UnionCouncils = LazyBaseSingletonBLL<UnionCouncilBLL>.Instance.GetUnionCouncils();
                model.Constituencies = LazyBaseSingletonBLL<ConstituencyBLL>.Instance.GetConstituency();
                model.Departments = LazyBaseSingletonBLL<DepartmentBLL>.Instance.GetDepartments();
                model.Ratings = LazyBaseSingletonBLL<RatingBLL>.Instance.GetAllRatings();
                model.colVisits = LazyBaseSingletonBLL<DashboardDistrictsBLL>.Instance.GetVisitsLogsDashboardDistrict(null, Convert.ToInt32(1), Convert.ToInt32(model.PageSize));
            }
            catch (Exception ex)
            {
                //new CommonBLL().AddErrorLog(new ErrorLogModel(ex, "GetRecords", PageNames.Index));
                //model = new DashboardDistrictModel(ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardDistrict));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DashboardDistrictModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DashboardDistrictModel("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion
    }
}