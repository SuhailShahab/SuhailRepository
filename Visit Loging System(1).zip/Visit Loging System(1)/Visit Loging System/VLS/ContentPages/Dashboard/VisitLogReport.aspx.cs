﻿using BE.CustomEnums;
using BE.Dashboard;
using BE.LogManager;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web.Services;
using VLS.ApplicationClasses;
using VLS.BLL.Dashboard;

namespace VLS.ContentPages.Dashboard
{
    public partial class DashboardReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "WebMethod"

        [WebMethod]
        public static DashboardReportModelView GetAllVisitsPerformedBreakdown(string DivisionID, string DistrictID, string DepartmentID)
        {
            DashboardReportModelView modelview = new DashboardReportModelView();

            try
            {
                int? divID = null;
                int? disID = null;
                int? deptID = null;

                if (DivisionID != "undefined")
                    divID = Convert.ToInt16(DivisionID);
                if (DistrictID != "undefined")
                    disID = Convert.ToInt16(DistrictID);
                if (DepartmentID != "undefined")
                    deptID = Convert.ToInt16(DepartmentID);


                int? AssignToID = null;

                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                modelview = new DashboardReportBLL().GetAllVisitsPerformedBreakdown(AssignToID, divID, disID, deptID);
                modelview.Divisions = new DivisionBLL().GetDivisions();
                modelview.Districts = new DistrictBLL().SelectAllActive();
                modelview.Departments = new DepartmentBLL().GetDepartments();

                if (modelview.DistrictLogs.Count > 0)
                {
                    modelview.AllDistrictCounts = new List<DistrictCountModel>();

                    var data = from row in modelview.DistrictLogs
                               group row by row.DivisionID into Div
                               orderby Div.Key
                               select new
                               {
                                   DivID = Div.Key,
                                   Count = Div.Count()
                               };

                    foreach (var e in data)
                    {
                        DistrictCountModel dcm = new DistrictCountModel();
                        dcm.DivisionID = e.DivID;
                        dcm.DistrictCount = e.Count;

                        modelview.AllDistrictCounts.Add(dcm);
                    }
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetVisitsPerformedBreakdown", 1, PageNames.DashboardReport, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardReportModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardReportModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        [WebMethod]
        public static DashboardReportModelView GetDistrictsWiseVisitsPerformedBreakdown(string DivisionID, string DistrictID)
        {
            DashboardReportModelView modelview = new DashboardReportModelView();

            try
            {
                int? divID = null;
                int? disID = null;

                if (DivisionID != "undefined")
                    divID = Convert.ToInt16(DivisionID);
                if (DistrictID != "undefined")
                    disID = Convert.ToInt16(DistrictID);

                int? AssignToID = null;

                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                modelview = new DashboardReportBLL().GetDistrictsWiseVisitsPerformedBreakdown(AssignToID, divID, disID);
                modelview.Divisions = new DivisionBLL().GetDivisions();
                modelview.Districts = new DistrictBLL().SelectAllActive();
                modelview.Departments = new DepartmentBLL().GetDepartments();

                if (modelview.DistrictLogs.Count > 0)
                {
                    modelview.AllDistrictCounts = new List<DistrictCountModel>();

                    var data = from row in modelview.DistrictLogs
                               group row by row.DivisionID into Div
                               orderby Div.Key
                               select new
                               {
                                   DivID = Div.Key,
                                   Count = Div.Count()
                               };

                    foreach (var e in data)
                    {
                        DistrictCountModel dcm = new DistrictCountModel();
                        dcm.DivisionID = e.DivID;
                        dcm.DistrictCount = e.Count;

                        modelview.AllDistrictCounts.Add(dcm);
                    }
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetVisitsPerformedBreakdown", 1, PageNames.DashboardReport, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardReportModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardReportModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        [WebMethod]
        public static DashboardReportModelView GetDepartmentsWiseVisitsPerformedBreakdown(string DepartmentID)
        {
            DashboardReportModelView modelview = new DashboardReportModelView();

            try
            {
                int? deptID = null;
                if (DepartmentID != "undefined")
                    deptID = Convert.ToInt16(DepartmentID);

                int? AssignToID = null;
                if (CurrentUser.DepartmentID.HasValue)
                    AssignToID = CurrentUser.LoginID.Value;

                modelview = new DashboardReportBLL().GetDepartmentsWiseVisitsPerformedBreakdown(AssignToID, deptID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetVisitsPerformedBreakdown", 1, PageNames.DashboardReport, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelview = new DashboardReportModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelview = new DashboardReportModelView("error|" + ex.Message);
                }
            }

            return modelview;
        }

        [WebMethod]
        public static LogDetailView GetDistrictRatingLogDetail(string DivisionID, string DistrictID, string RatingID)
        {
            LogDetailView logDetailvm = new LogDetailView();
            try
            {
                int? divisionID = null;
                int? districtID = null;
                int? rateID = null;
                int? UserID = null;

                if (!string.IsNullOrEmpty(DivisionID))
                    divisionID = Convert.ToInt32(DivisionID);

                if (!string.IsNullOrEmpty(DistrictID))
                    districtID = Convert.ToInt32(DistrictID);

                if (RatingID != "0")
                    rateID = Convert.ToInt32(RatingID);

                //if (!string.IsNullOrEmpty(FacilityID))
                //    facilityID = Convert.ToInt32(FacilityID);

                if (CurrentUser.DepartmentID.HasValue)
                    UserID = CurrentUser.LoginID.Value;

                logDetailvm.LogDetail = new DashboardReportBLL().GetDistrictRatingLogDetail(UserID, divisionID, districtID, rateID, null);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictRatingLogDetail", 1, PageNames.DashboardReport, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetailvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetailvm.Notification = "error|" + ex.Message;
                }
            }

            return logDetailvm;
        }

        [WebMethod]
        public static LogDetailView GetDepartmentRatingLogDetail(string DepartmentID, string RatingID)
        {
            LogDetailView logDetailvm = new LogDetailView();

            try
            {
                int? deptID = null;
                int? rateID = null;

                if (!string.IsNullOrEmpty(DepartmentID))
                    deptID = Convert.ToInt32(DepartmentID);
                if (RatingID != "0")
                    rateID = Convert.ToInt32(RatingID);
                int? UserID = null;
                if (CurrentUser.DepartmentID.HasValue)
                    UserID = CurrentUser.LoginID.Value;

                logDetailvm.LogDetail = new DashboardReportBLL().GetDepartmentRatingLogDetail(UserID, deptID, rateID);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDistrictRatingLogDetail", 1, PageNames.DashboardReport, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, Convert.ToString(MethodBase.GetCurrentMethod()), PageNames.DashboardReport));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    logDetailvm.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    logDetailvm.Notification = "error|" + ex.Message;
                }
            }

            return logDetailvm;
        }

        #endregion
    }
}