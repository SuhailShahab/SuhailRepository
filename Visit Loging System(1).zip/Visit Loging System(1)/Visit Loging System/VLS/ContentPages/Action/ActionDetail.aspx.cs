﻿using BE.Content;
using BE.CustomEnums;
using BE.EmailQueue;
using BE.LogManager;
using BE.Lookups;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.Lookups;
using BLL.RamzanBazar;
using BLL.RightsManager;
using System;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using VLS.ApplicationClasses;
using VLS.BLL.Content;
using System.Linq;
using System.Collections.Generic;
// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <25-Mar-2016 02:50:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.ContentPages.Action
{
    public partial class ActionDetail : System.Web.UI.Page
    {

        public int? VisitorLogID
        {
            get
            {
                int? id = Convert.ToInt32(ViewState["visitorLogID"]);
                return id;

            }
            set
            {
                ViewState["visitorLogID"] = value;

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                this.VisitorLogID = Request.QueryString["ID"] != null ? Convert.ToInt32(Request.QueryString["ID"].ToString()) : 0;

                #region "Restrict unauthorised action taken access"

                if (!LazyBaseSingletonBLL<ActionDetailBLL>.Instance.IsValidActionTakenUser(this.VisitorLogID.Value, CurrentUser.LoginID.Value))
                {
                    Response.Redirect("~/Error.aspx?errorMessage=" + CutomMessage.NotAuthorizedToPage, false);
                }

                #endregion



            }
            
            if (Request.Files.Count > 0)
                UpdateFiles();
        }

        #region "Methods"

        private void UpdateFiles()
        {
            try
            {
                
                

                HttpRequest request = Page.Request;
                for (int i = 0; i < request.Files.Count; i++)
                {
                    HttpPostedFile postFile = request.Files[i];
                    byte[] FileBytes = LazyBaseSingletonBLL<CommonUtility>.Instance.GetFileContent(postFile.InputStream);

                    int result = LazyBaseSingletonBLL<ActionDetailBLL>.Instance.UploadAttachment(this.VisitorLogID.Value,CurrentUser.GetSessionUserInfo().DesignationID, FileBytes, postFile.ContentType);
                }
            }
            catch (Exception ex)
            {
                LazyBaseSingletonUI<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "UploadImages", PageNames.ActionDetail));
                //new CommonBLL().AddErrorLog(new ErrorLogModel(ex, "UploadImages", PageNames.ActionDetail));
            }
        }

        #endregion

        #region "Web Methods"

        /// <summary>
        /// Get assign task  Detail
        /// </summary>
        /// <param name="taskID">selected taskID</param>
        /// <returns>Assign Model</returns>
        [WebMethod]
        public static ActionDetailModel GetAssignTaskDetail(int visitorLogID)
        {
            ActionDetailModel model = new ActionDetailModel();
            try
            {
                // get visit log and action information 
                model = LazyBaseSingletonBLL<ActionDetailBLL>.Instance.GetAssignTaskDetail(visitorLogID);
                model.DashboardTitle = CurrentUser.DashboardTitle;
                model.UserDesignation = CurrentUser.UserDesignationName;
                model.UserDepartment = CurrentUser.UserDepartmentName;
                //Ramzan Bazar
                model.RamzanBazarModel = LazyBaseSingletonBLL<RamzanBazarMonitoringBLL>.Instance.GetRamzanBazarMonitoringByID(visitorLogID);
                model.Conditions = LazyBaseSingletonBLL<ConditionBLL>.Instance.GetConditions(null).ToList();

            }
            catch (Exception ex)
            {
               // new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetAssignTaskDetail", PageNames.ActionDetail));
                //model = new ActionDetailModel("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAssignTaskDetail", 1, PageNames.ActionDetail, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ActionDetailModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ActionDetailModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Save Action Detail Data
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static ActionDetailModel Save(string jsonModel, string visitorLogID)
        {
            int? result = 0;
            ActionDetailModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<ActionDetailModel>(jsonModel);
                model.ModifiedBy = CurrentUser.LoginID ?? 0;          //TODO set user information form current login
                result = LazyBaseSingletonBLL<ActionDetailBLL>.Instance.Save(model, Convert.ToInt32(visitorLogID),CurrentUser.GetSessionUserInfo().DesignationID);

                #region  Send SMS & Emaill To visitor on taking actions

                RatingModel rating =null;
                UserModel userInfo = null;
                if (model.CreatedBy.HasValue && model.CreatedBy.Value > 0)
                {

                    userInfo = LazyBaseSingletonBLL<UserBLL>.Instance.GetUserInfoForSendingSMSansEmail(model.CreatedBy);
                    rating = LazyBaseSingletonBLL<RatingBLL>.Instance.GetRatingByID(Convert.ToInt32(model.Rating));

                    if (ConfigurationHelper.SendEmailToVisitorOfficialOnTakeActions.HasValue && ConfigurationHelper.SendEmailToVisitorOfficialOnTakeActions.Value && userInfo != null && !string.IsNullOrEmpty(userInfo.EMail))
                    {
                        

                        if (rating != null && !string.IsNullOrEmpty(rating.ActionTakenOfficialEmail))
                        {
                            try
                            {
                                // DepartmentModel dm = LazyBaseSingletonBLL<DepartmentBLL>.Instance.GetDepartmentByID(model.DepartmentID);
                                string subject = "Action Performed against the visit Logged in FVMS  ";
                                StringBuilder Body = new StringBuilder();

                                Body.AppendLine(rating.ActionTakenOfficialEmail);
                                EmailModel emailModel = new EmailModel();
                                emailModel.Body = Body.ToString();
                                emailModel.Subject = subject;
                                emailModel.ToEmailAddresses = new System.Collections.Generic.List<string>();
                                emailModel.ToEmailAddresses.Add(userInfo.EMail);
                                if (!string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL))
                                LazyBaseSingletonUI<CommonUtility>.Instance.SendEmailToQueue(emailModel);
                                else 
                                LazyBaseSingletonUI<CommonUtility>.Instance.MailSend(userInfo.EMail, subject, Body.ToString());
                            }
                            catch { }
                           
                        }

                    }


                    if (ConfigurationHelper.SendSMSToVisitorOfficialOnTakeActions.HasValue && ConfigurationHelper.SendSMSToVisitorOfficialOnTakeActions.Value && userInfo != null && !string.IsNullOrEmpty(userInfo.CellNumber))
                    {
                       // rating = LazyBaseSingletonBLL<RatingBLL>.Instance.GetRatingByID(Convert.ToInt32(model.Rating));

                        if (rating != null && !string.IsNullOrEmpty(rating.ActionTakenOfficialSMS))
                        {

                            try
                            {
                                LazyBaseSingletonUI<CommonUtility>.Instance.SendSMSAlert(userInfo.CellNumber, rating.ActionTakenOfficialSMS);
                            }
                            catch { }


                        }

                    }


                }

                #endregion 

            }
            catch (Exception ex)
            {
                //new CommonBLL().AddErrorLog(new ErrorLogModel(ex, "Save", PageNames.ActionDetail));
                //model = new ActionDetailModel("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Save", 1, PageNames.ActionDetail, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ActionDetailModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ActionDetailModel("error|" + ex.Message);
                }
            }

            return model;
        }
        #endregion
    }
}
