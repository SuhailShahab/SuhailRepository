﻿using BE.CustomEnums;
using BE.LogManager;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;
using VLS.BE.CustomEnums;

namespace VLS.ContentPages.RightsManager
{
    public partial class ApplicationObjects : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #region "Web Methods"

        [WebMethod]
        public static ApplicationObjectModel SaveRecord(string jsonModel)
        {

            int result = 0;
            ApplicationObjectModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<ApplicationObjectModel>(jsonModel);

                model.CreatedBy = CurrentUser.LoginID;

                result = new ApplicationObjectsBLL().Save(model);
                if (model.ID == 0)
                {
                    model.ID = result;
                }
                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {

                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ApplicationObjectModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ApplicationObjectModel("error|" + ex.Message);
                }
            }

            return model;
        }


        [WebMethod]
        public static ApplicationObjectsModelView GetRecords()
        {
            List<ApplicationObjectModel> applicationObjectes = null;
            List<ApplicationFeatureModel> features = null;
            ApplicationObjectsModelView applicationObjectsModelView = new ApplicationObjectsModelView();

            try
            {
                applicationObjectes = new ApplicationObjectsBLL().GetAppObject();
                features = new ApplicationFeaturesBLL().GetFeatures();

                features = features.Where(p => p.menuLocation == MenuTypeNames.MainMenu.GetHashCode()).ToList();

                if (applicationObjectes != null && applicationObjectes.Count > 0)
                    applicationObjectsModelView.ApplicationObjectes = applicationObjectes;

                if (features != null && features.Count > 0)

                    //features.GetEnumerator().
                    applicationObjectsModelView.Features = features;
                applicationObjectsModelView.IsAdmin = false;

                return applicationObjectsModelView;
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(applicationObjectsModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    applicationObjectsModelView = new ApplicationObjectsModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    applicationObjectsModelView = new ApplicationObjectsModelView("error|" + ex.Message);
                }
            }

            return applicationObjectsModelView;
        }

        #endregion
       
        
    }
}