﻿using BE.CustomEnums;
using BE.LogManager;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.RightsManager
{
    public partial class ApplicationFeatures : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static ApplicationFeatureModel SaveRecord(string jsonModel)
        {
            int result = 0;
            ApplicationFeatureModel featuresModel = null;
            try
            {
                featuresModel = new JavaScriptSerializer().Deserialize<ApplicationFeatureModel>(jsonModel);

                featuresModel.CreatedBy = CurrentUser.LoginID ?? 0;

                result = new ApplicationFeaturesBLL().Save(featuresModel);
                if (featuresModel.ID == 0)
                {
                    featuresModel.ID = result;

                }

                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationSuccess(featuresModel, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 0, PageNames.ApplicationFeature, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationMsg(featuresModel ,ex.Message, typeof(ApplicationFeatureModel));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationFeature, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    featuresModel = new ApplicationFeatureModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    featuresModel = new ApplicationFeatureModel("error|" + ex.Message);
                }
            }

            return featuresModel;
        }

        [WebMethod]
        public static ApplicationFeatureModel[] GetRecords()
        {
            List<ApplicationFeatureModel> Lists = null;

            try
            {
                Lists = new ApplicationFeaturesBLL().GetFeature();
                if (Lists != null && Lists.Count > 0)
                    return Lists.ToArray();
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 0, PageNames.ApplicationFeature, CurrentUser.GetSessionUserInfo()));
               
            }

            return null;
        }

        #endregion
    }
}