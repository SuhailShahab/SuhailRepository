﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Lookups
{
    public partial class Constituency : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static ConstituencyModel SaveRecord(string jsonModel)
        {

            int result = 0;
            ConstituencyModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<ConstituencyModel>(jsonModel);

                result =LazyBaseSingletonBLL<ConstituencyBLL>.Instance.Save(model, CurrentUser.LoginID);

                if (model.ID==null || model.ID == 0) model.ID = result;

                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {

                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Constituency, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Constituency, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ConstituencyModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ConstituencyModel("error|" + ex.Message);
                }
            }

            return model;
        }


        [WebMethod]
        public static ConstituencyModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            ConstituencyModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<ConstituencyModel>(jsonModel);
                result = LazyBaseSingletonBLL<ConstituencyBLL>.Instance.Delete(model, CurrentUser.LoginID);

                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationInfo(model, CutomMessage.blockSuccessfully);

            }
            catch (Exception ex)
            {

                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Constituency, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Constituency, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ConstituencyModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ConstituencyModel("error|" + ex.Message);
                }

            }
            return model;

        }


        [WebMethod]
        public static ConstituencyModelView GetRecords()
        {
            List<ConstituencyModel> Constituencyies = null;
            List<DistrictModel> Districts = null;
            ConstituencyModelView ListconstituencyModelView = new ConstituencyModelView();

            try
            {
                /*======================== Constituency================================== */

                Constituencyies = LazyBaseSingletonBLL<ConstituencyBLL>.Instance.GetAllConstituencyies(); // new ConstituencyBLL().GetAllConstituencyies();
                if (Constituencyies != null && Constituencyies.Count > 0)  
                    ListconstituencyModelView.Constituencyies = Constituencyies;
                /*======================================================== */

                /*======================== Districts================================== */
                Districts = LazyBaseSingletonBLL<DistrictBLL>.Instance.SelectAllActive();

                if (Districts != null && Districts.Count > 0)

                    //features.GetEnumerator().
                    ListconstituencyModelView.Districts = Districts;
                /*======================== Districts================================== */


                return ListconstituencyModelView;
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Constituency, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(ListconstituencyModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Constituency, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ListconstituencyModelView = new ConstituencyModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ListconstituencyModelView = new ConstituencyModelView("error|" + ex.Message);
                }
            
            }

            return ListconstituencyModelView;
        }

        #endregion
    }
}