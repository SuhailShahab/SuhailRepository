﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.Lookups;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Lookups
{
    public partial class DoctorPost : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #region "Web Methods"

        /// <summary>
        /// Save group information
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns>Added GroupID as integer</returns>
        [WebMethod]
        public static DoctorPostModel SaveRecord(string jsonModel)
        {
            int result = 0;
            DoctorPostModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<DoctorPostModel>(jsonModel);

                model.CreatedBy = CurrentUser.LoginID;

                result = new DoctorPostBLL().Save(model);

                if (result > 0)
                {
                    if (model.ID == 0)
                        model.ID = result;
                    LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }

            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecords", 0, "DoctorPost", CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message, typeof(DoctorPostModel));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecords", 1, "DoctorPost", CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DoctorPostModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DoctorPostModel("error|" + ex.Message);
                }
           
            }

            return model;
        }

        /// <summary>
        /// Get all groups
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static DoctorPostModelView GetRecords()
        {
            DoctorPostModelView model = new DoctorPostModelView();

            List<DoctorPostModel> MedicineTypes = null;

            try
            {
                MedicineTypes = new DoctorPostBLL().GetAllDoctorPosts().OrderBy(i => i.ID).ToList();
                if (MedicineTypes != null && MedicineTypes.Count > 0)
                    model.DoctorPosts = MedicineTypes;
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 0, "DoctorPost", CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message, typeof(DoctorPostModelView));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, "DoctorPost", CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DoctorPostModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DoctorPostModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Delete existing group against provider group
        /// </summary>
        /// <param name="jsonModel"></param>
        [WebMethod]
        public static DoctorPostModel RemoveRecord(string jsonModel)
        {
            int result = 0;
            DoctorPostModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<DoctorPostModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;
                result = new DoctorPostBLL().Delete(model.ID, model.CreatedBy.Value);

                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationInfo(model, CutomMessage.blockSuccessfully);


            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 0, "DoctorPost", CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message, typeof(DoctorPostModel));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, "DoctorPost", CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DoctorPostModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DoctorPostModel("error|" + ex.Message);
                }
            }
            return model;
        }

        #endregion
    }
}