﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;
using VLS.BE.Lookups;
using VLS.BLL.Lookups;


namespace VLS.ContentPages.Lookups
{
    public partial class AssigneeRecord : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region WebMethods
         [WebMethod]
        public static AssigneeRecordView GetRecord()
        {
            AssigneeRecordView assigneeRecordView = new AssigneeRecordView();

            try
            {
                assigneeRecordView.Departments = new DepartmentBLL().GetDepartments();
                assigneeRecordView.Designations = new DesignationBLL().GetAllDesignations();

            }
            catch(Exception ex)
            {
                //assigneeRecordView.Notification = "error" + ex.Message;
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 0, PageNames.AssigneeRecord, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordByDepartmentID", 1, PageNames.AssigneeRecord, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    assigneeRecordView = new AssigneeRecordView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    assigneeRecordView = new AssigneeRecordView("error|" + ex.Message);
                }
            }
            return assigneeRecordView;
        }

         [WebMethod]
         public static AssigneeRecordView GetRecordByDepartmentID(string departmentID)
         {
             AssigneeRecordView assigneeRecordView = new AssigneeRecordView();

             try
             {
                 if(!string.IsNullOrEmpty(departmentID))
                 {
                     int? deptID = Convert.ToInt32(departmentID);
                     assigneeRecordView.AssigneeRecords = LazyBaseSingletonBLL<AssigneeRecordBLL>.Instance.GetbyDepartmentID(deptID);
                 }
                
                 //assigneeRecordView.Departments = new DepartmentBLL().GetDepartments();
                 //assigneeRecordView.Designations = new DesignationBLL().GetAllDesignations();

             }
             catch (Exception ex)
             {
                 //assigneeRecordView.Notification = "error" + ex.Message;
                 //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecordByDepartmentID", 0, PageNames.AssigneeRecord, CurrentUser.GetSessionUserInfo()));
                 string errorCode = string.Empty;
                 errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecordByDepartmentID", 1, PageNames.AssigneeRecord, CurrentUser.GetSessionUserInfo()));
                 if (ConfigurationHelper.IsShowGeneralMsg)
                 {
                     assigneeRecordView = new AssigneeRecordView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                 }
                 else
                 {
                     assigneeRecordView = new AssigneeRecordView("error|" + ex.Message);
                 }
             
             }
             return assigneeRecordView;
         }

         [WebMethod]
         public static string  RemoveRecord(string removeItem)
         {
             string result = string.Empty;

             try
             {
                 if(!string.IsNullOrEmpty(removeItem))
                 {
                   
                    int? rowAffected = LazyBaseSingletonBLL<AssigneeRecordBLL>.Instance.Delete(Convert.ToInt32(removeItem));
                     result=  LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationDeleteSuccessuly(CutomMessage.deleteSuccessfully);
                 }
                

             }
             catch (Exception ex)
             {
                 string errorCode = string.Empty;
                 errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.AssigneeRecord, CurrentUser.GetSessionUserInfo()));
                 if (ConfigurationHelper.IsShowGeneralMsg)
                 {
                     result = LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);

                 }
                 else
                 {
                     result = LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(ex.Message);
                 }

                 //result = LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg (ex.Message);
                 //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 0, PageNames.AssigneeRecord, CurrentUser.GetSessionUserInfo()));
             }
             return result;
         }

          [WebMethod]
         public static AssigneeRecordView SaveRecord(string jsonModel)
         {
             AssigneeRecordView assigneeRecordView = null;
             int? result = null;
             try
             {
                 assigneeRecordView = new JavaScriptSerializer().Deserialize<AssigneeRecordView>(jsonModel);
                 result =  LazyBaseSingletonBLL<AssigneeRecordBLL>.Instance.Save(assigneeRecordView);
             }
             catch (Exception ex)
             {
                 //assigneeRecordView.Notification = "error" + ex.Message;
                 //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 0, PageNames.AssigneeRecord, CurrentUser.GetSessionUserInfo()));
                 string errorCode = string.Empty;
                 errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.AssigneeRecord, CurrentUser.GetSessionUserInfo()));
                 if (ConfigurationHelper.IsShowGeneralMsg)
                 {
                     assigneeRecordView = new AssigneeRecordView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                 }
                 else
                 {
                     assigneeRecordView = new AssigneeRecordView("error|" + ex.Message);
                 }
             }
             return assigneeRecordView;
         }

        
        #endregion 
    }
}