﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Web.Script.Serialization;
using System.Web.Services;
using VLS.ApplicationClasses;
using System.Linq;

namespace VLS.ContentPages.Lookups
{
    public partial class Province : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static ProvinceModelView GetRecord()
        {
            ProvinceModelView model = new ProvinceModelView();

            try
            {
                model.Provinces = LazyBaseSingletonBLL<ProvinceBLL>.Instance.GetAllProvinces().OrderByDescending(x => x.ID).ToList ();
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetRecords", PageNames.Provinces));
                //model = new ProvinceModelView("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Provinces, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ProvinceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ProvinceModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static ProvinceModel SaveRecord(string jsonModel)
        {
            int result = 0;
            ProvinceModel model = new ProvinceModel();

            try
            {   
                if (string.IsNullOrEmpty(jsonModel) == false)
                    model = new JavaScriptSerializer().Deserialize<ProvinceModel>(jsonModel);

                if (model.ID > 0)
                    model.ModifiedBy = CurrentUser.CurrentUserInfo.UserID;
                else
                    model.CreatedBy = CurrentUser.CurrentUserInfo.UserID;

                result = LazyBaseSingletonBLL<ProvinceBLL>.Instance.Save(model);
                if (result > 0)
                {
                    model.ID = result;
                }
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "SaveRecord", PageNames.Provinces));
                //model = new ProvinceModel("error|" + ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Provinces, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ProvinceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ProvinceModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static ProvinceModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            ProvinceModel model = null;

            try
            {
                if (string.IsNullOrEmpty(jsonModel) == false)
                    model = new JavaScriptSerializer().Deserialize<ProvinceModel>(jsonModel);

                result = LazyBaseSingletonBLL<ProvinceBLL>.Instance.Delete(model.ID);
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", PageNames.Provinces));
                //model = new ProvinceModel("error|" + ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Provinces, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ProvinceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ProvinceModel("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion
    }
}