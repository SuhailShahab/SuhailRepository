﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Lookups
{
    public partial class SiteInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static SiteInformationView GetRecord()
        {
            SiteInformationView model = new SiteInformationView();

            try
            {
                model.SiteInformations = LazyBaseSingletonBLL<SiteInfoBLL>.Instance.GetSiteInfo().OrderByDescending(x => x.ID).ToList();
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetRecords", PageNames.SiteInfo));
                //model = new SiteInformationView("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.SiteInfo, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SiteInformationView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SiteInformationView("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static SiteInformationModel SaveRecord(string jsonModel)
        {
            int result = 0;
            SiteInformationModel model = new SiteInformationModel();

            try
            {
                if (string.IsNullOrEmpty(jsonModel) == false)
                    model = new JavaScriptSerializer().Deserialize<SiteInformationModel>(jsonModel);

                if (model.ID > 0)
                    model.ModifiedBy = CurrentUser.CurrentUserInfo.UserID;
                else
                    model.CreatedBy = CurrentUser.CurrentUserInfo.UserID;

                result = LazyBaseSingletonBLL<SiteInfoBLL>.Instance.Save(model, CurrentUser.LoginID);
                if (result > 0)
                {
                    model.ID = result;
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SiteInfo, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SiteInformationModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SiteInformationModel("error|" + ex.Message);
                }
               // new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "SaveRecord", PageNames.SiteInfo));
              //  model = new SiteInformationModel("error|" + ex.Message);
            }

            return model;
        }

        [WebMethod]
        public static SiteInformationModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            SiteInformationModel model = null;

            try
            {
                if (string.IsNullOrEmpty(jsonModel) == false)
                    model = new JavaScriptSerializer().Deserialize<SiteInformationModel>(jsonModel);

                result = LazyBaseSingletonBLL<SiteInfoBLL>.Instance.Delete(model, CurrentUser.LoginID);
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.SiteInfo, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new SiteInformationModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new SiteInformationModel("error|" + ex.Message);
                }
               // new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", PageNames.SiteInfo));
              ///  model = new SiteInformationModel("error|" + ex.Message);
            }

            return model;
        }

        #endregion
    }
}