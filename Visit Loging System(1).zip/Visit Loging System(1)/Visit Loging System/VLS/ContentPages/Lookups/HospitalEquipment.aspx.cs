﻿
using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Lookups
{
    public partial class HospitalEquipment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        /// <summary>
        /// Save Record
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static HospitalEquipmentModel SaveRecord(string jsonModel)
        {

            int result = 0;
            HospitalEquipmentModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<HospitalEquipmentModel>(jsonModel);

                result = LazyBaseSingletonBLL<HospitalEquipmentBLL>.Instance.Save(model, CurrentUser.LoginID);

                if (model.ID == null || model.ID == 0) model.ID = result;

                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {

                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.HospitalEquipment, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.HospitalEquipment, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new HospitalEquipmentModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new HospitalEquipmentModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static HospitalEquipmentModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            HospitalEquipmentModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<HospitalEquipmentModel>(jsonModel);
                result = LazyBaseSingletonBLL<HospitalEquipmentBLL>.Instance.Delete(model, CurrentUser.LoginID);

                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationInfo(model, CutomMessage.blockSuccessfully);

            }
            catch (Exception ex)
            {

                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.HospitalEquipment, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.HospitalEquipment, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new HospitalEquipmentModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new HospitalEquipmentModel("error|" + ex.Message);
                }

            }
            return model;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static HospitalEquipmentModelView GetRecords()
        {
            List<HospitalEquipmentModel> hospitalEquipments = null;
            HospitalEquipmentModelView ListHospitalEquipmentModelView = new HospitalEquipmentModelView();

            try
            {
                /*========================   HospitalEquipments  ================================== */

                hospitalEquipments = LazyBaseSingletonBLL<HospitalEquipmentBLL>.Instance.GetHospitalEquipments(); // new HospitalEquipmentBLL().GetAllConstituencyies();
                
                if (hospitalEquipments != null && hospitalEquipments.Count > 0)
                    
                    ListHospitalEquipmentModelView.HospitalEquipments = hospitalEquipments;

                /*================================================================================= */

                return ListHospitalEquipmentModelView;
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.HospitalEquipment, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(ListHospitalEquipmentModelView, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.HospitalEquipment, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ListHospitalEquipmentModelView = new HospitalEquipmentModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ListHospitalEquipmentModelView = new HospitalEquipmentModelView("error|" + ex.Message);
                }
            }

            return ListHospitalEquipmentModelView;
        }

        #endregion
    }
}