﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Lookups
{
    public partial class News : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static NewsModel SaveRecord(string jsonModel)
        {
            int result = 0;
            NewsModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<NewsModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID ?? 0;
                result = new NewsBLL().Save(model);
                if (result > 0)
                {
                    if (!model.ID.HasValue)
                        model.ID = result;
                    LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.News, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new NewsModel("error|" + ex.Message);
                }
                // LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.News, CurrentUser.GetSessionUserInfo()));
            }

            return model;
        }

        [WebMethod]
        public static NewsModelView GetRecord()
        {

            NewsModelView modelView = new NewsModelView();

            try
            {
                modelView.allRecords = new NewsBLL().GetAllNews().OrderBy(x => x.ID).ToList();
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.News, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new NewsModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new NewsModelView("error|" + ex.Message);
                }
               // LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.News, CurrentUser.GetSessionUserInfo()));
            }

            return modelView;
        }

        [WebMethod]
        public static NewsModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            NewsModel model = null;
            try
            {

                model = new JavaScriptSerializer().Deserialize<NewsModel>(jsonModel);
                result = new NewsBLL().Delete(model, CurrentUser.LoginID);
                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationInfo(model, CutomMessage.blockSuccessfully);

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.News, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new NewsModel("error|" + ex.Message);
                }
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.News, CurrentUser.GetSessionUserInfo()));
            }

            return model;

        }

        #endregion
    }
}