﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <01-04-2016 04:23:23PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
//   SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace VLS.ContentPages.Lookups
{
    public partial class District : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static DistrictModelView GetRecords()
        {
            DistrictModelView model = new DistrictModelView();

            try
            {
                model.Provinces = LazyBaseSingletonBLL<ProvinceBLL>.Instance.GetAllActiveProvinces();
                model.Divisions = LazyBaseSingletonBLL<DivisionBLL>.Instance.GetDivisions();
                model.Districts = LazyBaseSingletonBLL<DistrictBLL>.Instance.SelectAll().OrderByDescending(x => x.ID).ToList();
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetRecords", PageNames.District));
                //model = new DistrictModelView("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.District, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DistrictModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DistrictModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static DistrictModel SaveRecord(string jsonModel)
        {
            int? result = null;
            DistrictModel model = new DistrictModel();

            try
            {
                model = new JavaScriptSerializer().Deserialize<DistrictModel>(jsonModel);
                if (model.ID.HasValue)
                    model.ModifiedBy = CurrentUser.CurrentUserInfo.UserID;
                else
                    model.CreatedBy = CurrentUser.CurrentUserInfo.UserID;

                result = LazyBaseSingletonBLL<DistrictBLL>.Instance.Save(model);
                if (result.HasValue)
                {
                    model.ID = model.ID.HasValue ? model.ID : result;
                }
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "SaveRecord", PageNames.District));
                //model = new DistrictModel("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.District, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DistrictModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DistrictModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static DistrictModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            DistrictModel model = new DistrictModel();

            try
            {
                model = new JavaScriptSerializer().Deserialize<DistrictModel>(jsonModel);
                model.ModifiedBy = CurrentUser.CurrentUserInfo.UserID;

                result = LazyBaseSingletonBLL<DistrictBLL>.Instance.Delete(model);
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", PageNames.Division));
                //model = new DistrictModel("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.District, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DistrictModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DistrictModel("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion
    }
}