﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Lookups
{
    public partial class Rating : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static RatingModelView GetRecord()
        {
            RatingModelView model = new RatingModelView();

            try
            {
                model.Ratings = LazyBaseSingletonBLL<RatingBLL>.Instance.GetAllRatings().OrderByDescending (x=>x.ID ).ToList ();
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetRecords", PageNames.Rating));
                //model = new RatingModelView("error|" + ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Rating, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new RatingModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new RatingModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static RatingModel SaveRecord(string jsonModel)
        {
            int result = 0;
            RatingModel model = new RatingModel();

            try
            {
                if (string.IsNullOrEmpty(jsonModel) == false)
                    model = new JavaScriptSerializer().Deserialize<RatingModel>(jsonModel);

                //if (model.IsEdit)
                //{
                //    model.ModifiedBy = CurrentUser.CurrentUserInfo.UserID;
                //    model.ModifiedDate = DateTime.Now;
                //}
                //else
                //{
                //    model.CreatedBy = CurrentUser.CurrentUserInfo.UserID;
                //    model.CreatedDate = DateTime.Now;
                //}

                result = LazyBaseSingletonBLL<RatingBLL>.Instance.Save(model, CurrentUser.LoginID);
                if (result > 0)
                {
                    model.ID = result;
                }
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "SaveRecord", PageNames.Rating));
                //model = new RatingModel("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Rating, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new RatingModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new RatingModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static RatingModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            RatingModel model = null;

            try
            {

                model = new JavaScriptSerializer().Deserialize<RatingModel>(jsonModel);
                result = new RatingBLL().Delete(model, CurrentUser.LoginID);

                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.blockSuccessfully);

                if (string.IsNullOrEmpty(jsonModel) == false)
                    model = new JavaScriptSerializer().Deserialize<RatingModel>(jsonModel);

                result = LazyBaseSingletonBLL<RatingBLL>.Instance.Delete(model, CurrentUser.LoginID );
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", PageNames.Rating));
                //model = new RatingModel("error|" + ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Rating, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new RatingModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new RatingModel("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion
    }
}