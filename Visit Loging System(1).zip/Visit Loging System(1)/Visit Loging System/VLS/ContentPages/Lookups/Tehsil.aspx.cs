﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Web.Script.Serialization;
using System.Web.Services;
using VLS.ApplicationClasses;
using System.Linq;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <01-04-2016 04:23:23PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
//   SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace VLS.ContentPages.Lookups
{
    public partial class Tehsil : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static TehsilModelView GetRecords()
        {
            TehsilModelView model = new TehsilModelView();

            try
            {
                model.Provinces = LazyBaseSingletonBLL<ProvinceBLL>.Instance.GetAllActiveProvinces();
                model.Divisions = LazyBaseSingletonBLL<DivisionBLL>.Instance.GetDivisions();
                model.Districts = LazyBaseSingletonBLL<DistrictBLL>.Instance.SelectAllActive();
                model.Tehsils = LazyBaseSingletonBLL<TehsilBLL>.Instance.SelectAll().OrderByDescending(x => x.ID).ToList();
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetRecords", PageNames.Tehsil));
                //model = new TehsilModelView("error|" + ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Tehsil, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new TehsilModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new TehsilModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static TehsilModel SaveRecord(string jsonModel)
        {
            int? result = null;
            TehsilModel model = new TehsilModel();

            try
            {
                model = new JavaScriptSerializer().Deserialize<TehsilModel>(jsonModel);
                if (model.ID.HasValue)
                    model.ModifiedBy = CurrentUser.CurrentUserInfo.UserID;
                else
                    model.CreatedBy = CurrentUser.CurrentUserInfo.UserID;

                result = LazyBaseSingletonBLL<TehsilBLL>.Instance.Save(model);
                if (result.HasValue)
                {
                    model.ID = model.ID.HasValue ? model.ID : result;
                }
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "SaveRecord", PageNames.Tehsil));
                //model = new TehsilModel("error|" + ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Tehsil, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new TehsilModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new TehsilModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static TehsilModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            TehsilModel model = new TehsilModel();

            try
            {
                model = new JavaScriptSerializer().Deserialize<TehsilModel>(jsonModel);
                model.ModifiedBy = CurrentUser.CurrentUserInfo.UserID;

                result = LazyBaseSingletonBLL<TehsilBLL>.Instance.Delete(model);
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", PageNames.Tehsil));
                //model = new TehsilModel("error|" + ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Tehsil, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new TehsilModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new TehsilModel("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion
    }
}