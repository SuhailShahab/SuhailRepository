﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Lookups
{
    public partial class Designations : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"
        [WebMethod]
        public static DesignationModel SaveRecord(string jsonModel)
        {
            int result = 0;
            DesignationModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<DesignationModel>(jsonModel);

                result = LazyBaseSingletonBLL<DesignationBLL>.Instance.Save(model, CurrentUser.LoginID);

                if (model.ID == null || model.ID == 0)
                {
                    model.ID = result;
                }

                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            }
            catch (Exception ex)
            {

              //  new BE.Common().AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 0, PageNames.Designation, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 0, PageNames.Designations, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Designations, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DesignationModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DesignationModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static DesignationModel[] GetRecords()
        {
            List<DesignationModel> list = null;

            try
            {
                list = new DesignationBLL().GetDesignation().OrderByDescending(p => p.ID).ToList();
                if (list != null && list.Count > 0)
                    return list.ToArray();
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 0, PageNames.Designations, CurrentUser.GetSessionUserInfo()));
            }

            return null;
        }

        [WebMethod]
        public static DesignationModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            DesignationModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<DesignationModel>(jsonModel);

                result = new DesignationBLL().Delete(model, CurrentUser.LoginID);

                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationInfo(model, CutomMessage.blockSuccessfully);
            }
            catch (Exception ex)
            {
               // new Common().AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 0, PageNames.Designation, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 0, PageNames.Designations, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Designations, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DesignationModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DesignationModel("error|" + ex.Message);
                }
            }
            return model;

        }


        #endregion
    }
}