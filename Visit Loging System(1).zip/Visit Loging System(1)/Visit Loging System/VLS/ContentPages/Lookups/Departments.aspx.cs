﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Lookups
{
    public partial class Departments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static DepartmentModel SaveRecord(string jsonModel)
        {
            int result = 0;
            DepartmentModel departmentModel = null;
            try
            {
                departmentModel = new JavaScriptSerializer().Deserialize<DepartmentModel>(jsonModel);

                result =LazyBaseSingletonBLL<DepartmentBLL>.Instance.Save(departmentModel, CurrentUser.LoginID);               

                if (departmentModel.ID == null || departmentModel.ID == 0)
                {
                    departmentModel.ID = result;
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Department, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    departmentModel = new DepartmentModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    departmentModel = new DepartmentModel("error|" + ex.Message);
                }
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 0, PageNames.Department, CurrentUser.GetSessionUserInfo()));
            }

            return departmentModel;
        }

        /// <summary>
        /// Get Records
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static DepartmentModel[] GetRecords()
        {
            List<DepartmentModel> departments = null;

            try
            {
                departments = LazyBaseSingletonBLL<DepartmentBLL>.Instance.GetDepartment();
                if (departments != null && departments.Count > 0)
                    return departments.ToArray();
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
            }

            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns></returns>
        [WebMethod]
        public static DepartmentModel RemoveRecord(string jsonModel)
        {
            int result = 0;
            DepartmentModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<DepartmentModel>(jsonModel);
                result = LazyBaseSingletonBLL<DepartmentBLL>.Instance.Delete(model, CurrentUser.LoginID);

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Department, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DepartmentModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DepartmentModel("error|" + ex.Message);
                }
               // LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 0, PageNames.Department, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationMsg(model, ex.Message);
            }
            return model;

        }


        #endregion
    }
}