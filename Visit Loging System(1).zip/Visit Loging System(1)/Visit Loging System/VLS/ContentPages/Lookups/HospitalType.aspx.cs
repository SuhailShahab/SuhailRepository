﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.Lookups;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Lookups
{
    public partial class HospitalType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        #region "Web Methods"

        /// <summary>
        /// Save group information
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns>Added GroupID as integer</returns>
        [WebMethod]
        public static HospitalTypeModel SaveRecord(string jsonModel)
        {
            int result = 0;
            HospitalTypeModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<HospitalTypeModel>(jsonModel);

                model.CreatedBy = CurrentUser.LoginID;

                result = new HospitalTypeBLL().Save(model);

                if (result > 0)
                {
                    if (model.ID == 0)
                        model.ID = result;
                    LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }

            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, "HospitalType", CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.HospitalType, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new HospitalTypeModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new HospitalTypeModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Get all groups
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static HospitalTypeModelView GetRecords()
        {
            HospitalTypeModelView model = new HospitalTypeModelView();

            List<HospitalTypeModel> HospitalType = null;

            try
            {
                HospitalType = new HospitalTypeBLL().GetAllHospitalType().OrderBy(i => i.ID).ToList();
                if (HospitalType != null && HospitalType.Count > 0)
                    model.HospitalType = HospitalType;
            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Group, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.HospitalType, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new HospitalTypeModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new HospitalTypeModelView("error|" + ex.Message);
                }

            }

            return model;
        }

        /// <summary>
        /// Delete existing group against provider group
        /// </summary>
        /// <param name="jsonModel"></param>
        [WebMethod]
        public static HospitalTypeModel RemoveRecord(string jsonModel)
        {
            int result = 0;
            HospitalTypeModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<HospitalTypeModel>(jsonModel);
                model.CreatedBy = CurrentUser.LoginID;
                result = new HospitalTypeBLL().Delete(model.ID, model.CreatedBy.Value);

                LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationInfo(model, CutomMessage.blockSuccessfully);


            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Group, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingletonBLL<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.HospitalType, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new HospitalTypeModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new HospitalTypeModel("error|" + ex.Message);
                }
            }
            return model;
        }

        #endregion
    }
}