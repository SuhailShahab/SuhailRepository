﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using System;
using System.Web.Script.Serialization;
using System.Web.Services;
using VLS.ApplicationClasses;

// =================================================================================================================================
// Create by:	<Atif Farooq>
// Create date: <24-03-2016 10:03:08AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
//   SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace VLS.ContentPages.Lookups
{
    public partial class Division : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static DivisionModelView GetRecords()
        {
            DivisionModelView model = new DivisionModelView();

            try
            {
                model.Divisions = LazyBaseSingletonBLL<DivisionBLL>.Instance.GetDivision();
                model.Provinces = LazyBaseSingletonBLL<ProvinceBLL>.Instance.GetAllActiveProvinces();
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetRecords", PageNames.Division));
                //model = new DivisionModelView("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Division, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DivisionModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DivisionModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static DivisionModel SaveRecord(string jsonModel)
        {
            int? result = null;
            DivisionModel model = new DivisionModel();

            try
            {
                model = new JavaScriptSerializer().Deserialize<DivisionModel>(jsonModel);
                if (model.ID.HasValue)
                    model.ModifiedBy = CurrentUser.CurrentUserInfo.UserID;
                else
                    model.CreatedBy = CurrentUser.CurrentUserInfo.UserID;

                result = LazyBaseSingletonBLL<DivisionBLL>.Instance.Save(model);
                if (result.HasValue)
                {
                    model.ID = model.ID.HasValue ? model.ID : result;
                }
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "SaveRecord", PageNames.Division));
                //model = new DivisionModel("error|" + ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Division, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DivisionModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DivisionModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static DivisionModel RemoveRecord(string jsonModel)
        {
            int? result = null;
            DivisionModel model = new DivisionModel();

            try
            {
                model = new JavaScriptSerializer().Deserialize<DivisionModel>(jsonModel);

                result = LazyBaseSingletonBLL<DivisionBLL>.Instance.Delete(model.ID.Value, Convert.ToInt32(CurrentUser.CurrentUserInfo.UserID));
            }
            catch (Exception ex)
            {
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", PageNames.Division));
                //model = new DivisionModel("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Division, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DivisionModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DivisionModel("error|" + ex.Message);
                }
            }

            return model;
        }

        #endregion
    }
}