﻿using BE.CustomEnums;
using BE.LogManager;
using BLL.CommonUtility;
using BLL.Reports;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Reports
{
    public partial class DisplayRamzanBazarMonitoringReport : System.Web.UI.Page
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {
            int visitorID;
            try
            {

                if (!IsPostBack)
                {
                    visitorID = string.IsNullOrEmpty(Request.QueryString["visitorlogID"]) ? 0 : Convert.ToInt32(Request.QueryString["visitorlogID"]);
                    ShowReport(visitorID);
                }
            }

            catch (Exception ex)
            {
                new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "Page_Load", PageNames.DisplayRamzanBazarMonitoring));
            }
        }


        #region "Cutom Method"



        private void ShowReport(int visitorID)
        {
            try
            {
              
                    UserControl.Reports.ucReportViewer viewer = (UserControl.Reports.ucReportViewer)this.ucReportViewer1;
                    viewer.ReportName = ReportNames.RptRamzanBazarMonitoring;
                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();
                    parameters.Add(new ReportParameter("UserName", CurrentUser.UserDisplayName));
                    
                    #endregion
                    DataSet ds = GetReportDataTable(parameters, visitorID);

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsVisitorLogInfo", ds.Tables["VisitorLogInfo"]));
                    datasources.Add(new ReportDataSource("dsRamzanBazarMonitoring", ds.Tables["RamzanBazarMonitoring"]));
                    datasources.Add(new ReportDataSource("dsRamzanBazarMonitoringItems", ds.Tables["RamzanBazarMonitoringItems"]));

                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;
                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                    ///ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('Specified Date Criteria is invalid, Please try again..');", true);

              
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ShowReport", 1, PageNames.DisplayRamzanBazarMonitoring, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);

                }
               // new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "ShowReport", PageNames.DisplayRamzanBazarMonitoring));
            }
        }

        private DataSet GetReportDataTable(List<ReportParameter> parameters, int visitorID)
        {
            // create Generic Table
            DataSet ds = new DataSet();

            try
            {
                #region "Selection Criteria"

                ds = LazyBaseSingletonBLL<ReportsBLL>.Instance.GetRamzanBazarMonitoringDetail(visitorID);
                ds.Tables[0].TableName = "VisitorLogInfo";
                ds.Tables[1].TableName = "RamzanBazarMonitoring";
                ds.Tables[2].TableName = "RamzanBazarMonitoringItems";



                if (ds.Tables["RamzanBazarMonitoring"].Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

                #endregion
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetReportDataTable", 1, PageNames.DisplayRamzanBazarMonitoring, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);

                }
              //  new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetReportDataTable", PageNames.DisplayRamzanBazarMonitoring));
            }
            return ds;
        }

        #endregion

       
    }
}