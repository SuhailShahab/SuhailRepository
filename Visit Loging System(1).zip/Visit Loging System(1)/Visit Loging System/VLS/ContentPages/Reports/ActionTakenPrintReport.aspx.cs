﻿using BE.Content;
using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using BLL.Reports;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;
using VLS.BLL.Content;
using VLS.UserControl.Reports;

namespace VLS.ContentPages.Reports
{
    public partial class ActionTakenPrintReport : System.Web.UI.Page
    {
        #region "Page Event Methods"

        public int? ID
        {
            get
            {
                int? id = Convert.ToInt32(ViewState["visitorLogID"]);
                return id;

            }
            set
            {
                ViewState["visitorLogID"] = value;

            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            DataSet dsActionDetail = null;
            int departmentID ;

            if (!IsPostBack)
            {
                try
                {

                    this.ID  = string.IsNullOrEmpty(Request.QueryString["ID"]) ? 0 : Convert.ToInt32(Request.QueryString["ID"]);

                    #region "Restrict unauthorised action taken access"

                    if (!LazyBaseSingletonBLL<ActionDetailBLL>.Instance.IsValidUserPrintActionReport(this.ID.Value, CurrentUser.LoginID.Value))
                    {
                        Response.Redirect("~/Error.aspx?errorMessage=" + CutomMessage.NotAuthorizedToPage, false);
                    }

                    #endregion

                    
                    string url = string.Empty;
                    dsActionDetail = FillDataSet();

                    rptAttachment.DataSource = dsActionDetail.Tables["tblVisitActions"];
                    rptAttachment.DataBind();

                    #region "Showing Ramzan Bazar report link"
                    departmentID = Convert.ToInt32(dsActionDetail.Tables["ActionDetail"].Rows[0]["DepartmentID"]);
                    #endregion

                    if (departmentID == DepartmentName.IndustriesCommerceAndInvestment.GetHashCode())
                    {
                        divShowRptRamzan.Visible = true;
                        url = "DisplayRamzanBazarMonitoringReport.aspx?visitorlogID=" + this.ID;
                        lnkRptRamzanMonitoring.Attributes.Add("href", url);
                        lnkRptRamzanMonitoring.Attributes.Add("target", "_blank");
                        
                    }
                    else
                        divShowRptRamzan.Visible = false;

                    //if (dsActionDetail.Tables[0].Rows[0]["Attachment"].ToString() != "")
                    //{
                    //    url = "../../downloadFile.aspx?TaskID=" + taskID + "&ContentType=" + dsActionDetail.Tables[0].Rows[0]["ContentType"];
                    //    lblDownload.Visible = true;
                    //    lnkDownload.Attributes.Add("href", url);
                    //    lnkDownload.Visible = true;
                    //}
                    //else
                    //{
                    //    lblDownload.Visible = false;
                    //    lnkDownload.Attributes.Add("href", "#");
                    //    lnkDownload.Visible = false;
                    //    //lnkDownload.Attributes.Add("Enable", "false");
                    //}
                   

                }
                catch 
                {
                    
                }


                ShowReport(dsActionDetail);
            }
          
        }

        private DataSet FillDataSet()
        {
            DataSet dsActionDetail = null;


            dsActionDetail = new ReportsBLL().GetRptAssignTaskDetail(this.ID.Value);

            //ds.Tables[0].TableName = "tblVisitLog";
            //ds.Tables[5].TableName = "tblVisitLogImages";
            //dsActionDetail.Tables[0].TableName = "tblVisitLog";
            dsActionDetail.Tables[0].TableName = "ActionDetail";
            dsActionDetail.Tables[1].TableName = "HospitalEquipment";
            dsActionDetail.Tables[2].TableName = "DoctorAbsense";
            dsActionDetail.Tables[3].TableName = "MedicineType";
            dsActionDetail.Tables[4].TableName = "VacantDoctorPost";
            dsActionDetail.Tables[5].TableName = "tblVisitLogImages";
            dsActionDetail.Tables[6].TableName = "tblVisitActions";
            return dsActionDetail;
        }
        #endregion


        #region "Custom Methods"

     

        private void ShowReport(DataSet dsActionDetail)
        {
            try
            {
                ucReportViewer viewer = (ucReportViewer)this.ucReportViewer1;

                if (!rbNormal.Checked)
                    viewer.ReportName = ReportNames.ActionTakenImageReport;
                else
                    viewer.ReportName = ReportNames.ActionTakenReport;
                   
                // add the data sources
                List<ReportDataSource> datasources = null;
                datasources = new List<ReportDataSource>();

                datasources.Add(new ReportDataSource("dsActionLog", dsActionDetail.Tables[0]));
                datasources.Add(new ReportDataSource("dsAbsentDoctors", BuildAbsentDoctors(dsActionDetail.Tables["DoctorAbsense"])));
                datasources.Add(new ReportDataSource("dsVacantDoctors", BuildVacantDoctors(dsActionDetail.Tables["VacantDoctorPost"])));
                datasources.Add(new ReportDataSource("dsHospitalEquipments", BuildHospitalEquipments(dsActionDetail.Tables["HospitalEquipment"])));
                datasources.Add(new ReportDataSource("dsMedicineType", BuildMedicineType(dsActionDetail.Tables["MedicineType"])));
                datasources.Add(new ReportDataSource("dsVisitActions", dsActionDetail.Tables["tblVisitActions"]));
                

                if (!rbNormal.Checked)
                {
                    List<ActionImageModel> Imagess = LazyBaseSingletonBLL<ActionDetailBLL>.Instance.BindImageList(dsActionDetail.Tables[5]);
                    if (Imagess!=null)
                        datasources.Add(new ReportDataSource("DataSet2", Imagess));
                    else
                        datasources.Add(new ReportDataSource("DataSet2",new DataTable ()));

                }

                viewer.DataSourceList = datasources;

                // load the local report (RDLC)
                viewer.LoadLocalReport();




            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "ShowReport", 0, PageNames.ActionTakenPrintReport, CurrentUser.GetSessionUserInfo()));
                //ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ex.Message + "')", true);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ShowReport", 1, PageNames.ActionTakenPrintReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                     ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);  
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);  

                }
            }
        }

        private DataTable BuildAbsentDoctors(DataTable dtDoctors)
        {
            List<DoctorPostModel> Doctors = LazyBaseSingletonBLL<DoctorPostBLL>.Instance.GetActiveDoctorPosts();
            foreach (DoctorPostModel dp in Doctors)
            {
                DataRow[] Rows = dtDoctors.Select("DoctorID = " + dp.ID);
                if (Rows.Length == 0)
                {
                    DataRow dr = dtDoctors.NewRow();
                    dr["DoctorID"] = dp.ID;
                    dr["Title"] = dp.Title;
                    dr["Checked"] = false;

                    dtDoctors.Rows.Add(dr);
                }
            }

            dtDoctors.DefaultView.Sort = "DoctorID";

            return dtDoctors;
        }

        private DataTable BuildVacantDoctors(DataTable dtDoctorPosts)
        {
            List<DoctorPostModel> VacantDoctors = LazyBaseSingletonBLL<DoctorPostBLL>.Instance.GetActiveDoctorPosts();

            foreach (DoctorPostModel dp in VacantDoctors)
            {
                DataRow[] Rows = dtDoctorPosts.Select("DoctorPostID = " + dp.ID);
                if (Rows.Length == 0)
                {
                    DataRow dr = dtDoctorPosts.NewRow();
                    dr["DoctorPostID"] = dp.ID;
                    dr["Title"] = dp.Title;
                    dr["Checked"] = false;

                    dtDoctorPosts.Rows.Add(dr);
                }
            }

            dtDoctorPosts.DefaultView.Sort = "DoctorPostID";

            return dtDoctorPosts;
        }

        private DataTable BuildHospitalEquipments(DataTable dtEquipments)
        {
            List<HospitalEquipmentModel> HospitalEquipments = LazyBaseSingletonBLL<HospitalEquipmentBLL>.Instance.GetActiveHospitalEquipments();

            foreach (HospitalEquipmentModel he in HospitalEquipments)
            {
                DataRow[] Rows = dtEquipments.Select("EquipmentID = " + he.ID);
                if (Rows.Length == 0)
                {
                    DataRow dr = dtEquipments.NewRow();
                    dr["EquipmentID"] = he.ID;
                    dr["Title"] = he.Title;
                    dr["Checked"] = false;

                    dtEquipments.Rows.Add(dr);
                }
            }

            dtEquipments.DefaultView.Sort = "EquipmentID";

            return dtEquipments;
        }

        private DataTable BuildMedicineType(DataTable dtMedicine)
        {
            List<MedicineTypeModel> MedicineTypes = LazyBaseSingletonBLL<MedicineTypeBLL>.Instance.GetActiveMedicineTypes();

            foreach (MedicineTypeModel mt in MedicineTypes)
            {
                DataRow[] Rows = dtMedicine.Select("MedicineTypeID = " + mt.ID);
                if (Rows.Length == 0)
                {
                    DataRow dr = dtMedicine.NewRow();
                    dr["MedicineTypeID"] = mt.ID;
                    dr["Title"] = mt.Title;
                    dr["Checked"] = false;

                    dtMedicine.Rows.Add(dr);
                }
            }

            dtMedicine.DefaultView.Sort = "MedicineTypeID";

            return dtMedicine;
        }

        #endregion

        #region "Radio Button Click Events"

        protected void rbNormal_CheckedChanged(object sender, EventArgs e)
        {
            if (rbNormal.Checked)
            {
                try
                {
                    DataSet dsActionDetail =FillDataSet();

                    ShowReport(dsActionDetail);
                }
                catch (Exception ex)
                {
                    new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", PageNames.VisitActionByDepartmentReport));
                }
            }

        }

        protected void rbNormalExt_CheckedChanged(object sender, EventArgs e)
        {
            if (rbNormalExt.Checked)
            {
                try
                {
                    DataSet dsActionDetail = FillDataSet();
                    ShowReport(dsActionDetail);
                }
                catch (Exception ex)
                {
                    new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", PageNames.VisitActionByDepartmentReport));
                }
            }
        }

        #endregion

       

        protected void rptAttachment_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                int i = Convert.ToInt16(DataBinder.Eval(e.Item.DataItem, "IsActionTakenAttachment"));
                Label lblID = e.Item.FindControl("lblID") as Label;
                LinkButton lbtnDownload = e.Item.FindControl("lbtnDownload") as LinkButton;


                if (i == 0)
                {
                    lblID.Visible = false;
                    lbtnDownload.Visible = false;
                }
                else
                {
                    string url = string.Empty;
                    url = "../../downloadFile.aspx?TaskID=" + Convert.ToInt16(DataBinder.Eval(e.Item.DataItem, "TaskID")) + "&ContentType=" + DataBinder.Eval(e.Item.DataItem, "ContentType");
                    lbtnDownload.Visible = true;
                    lbtnDownload.Attributes.Add("href", url);
                }


            }
        }

      

       

    }
}