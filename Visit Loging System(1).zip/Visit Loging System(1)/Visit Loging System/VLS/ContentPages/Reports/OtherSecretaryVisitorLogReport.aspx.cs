﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.Lookups;
using BLL.Reports;
using BLL.RightsManager;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Reports
{
    public partial class OtherSecretaryVisitorLogReport : System.Web.UI.Page
    {
        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            try
            {
                #region "Comment Out"
                //if (Session["UserTable"] != null)
                //{
                //    DataTable dtUser = (DataTable)Session["UserTable"];
                //    SPWeb myWeb = SPControl.GetContextSite(Context).OpenWeb();
                //    this.MasterPageFile = myWeb.ServerRelativeUrl + dtUser.Rows[0]["MasterPageUrl"].ToString();
                //}
                //else
                //    Response.Redirect(SPContext.Current.Site.Url + "/_layouts/15/SignOut.aspx", true);
                #endregion "Comment Out"
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "OnPreInit", 1, PageNames.OtherSecretaryVisitorLogReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);

                }
               // new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "OnPreInit", PageNames.OtherSecretaryVisitorLogReport));
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {

                    for (int i = DateTime.Now.Year; i <= DateTime.Now.Year+4; i++)
                    {
                        ddlYearFrom.Items.Add(new ListItem(i.ToString(), i.ToString()));
                        ddlYearTo.Items.Add(new ListItem(i.ToString(), i.ToString()));
                    }

                    ddlYearFrom.SelectedValue = DateTime.Now.Year.ToString();
                    ddlYearTo.SelectedValue = DateTime.Now.Year.ToString();

                    ddlMonthFrom.SelectedValue = "2";
                    ddlMonthTo.SelectedValue = System.DateTime.Now.Month.ToString();


                    BindDepartments();

                    //this.ddlUsers.Items.Clear();
                    //this.ddlUsers.Items.Insert(0, new ListItem("Choose...", "0"));

                    #region "Comment Out"

                    // check the current user have rights to access to the page
                    //if (new Common().GetPageAccessPermission(LoingName, PageNames.SMSQueueReport, 1) == false)
                    //{
                    //    // check the current user have rights to access to the page
                    //    if (new Common().GetPageAccessPermission(LoingName, PageNames.SMSQueueReport) == false)
                    //    {
                    //        Response.Redirect("../Dashboard/Error/Error.aspx?Key=PageRightsDenied", true);
                    //    }
                    //}

                    #endregion

                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 1, PageNames.OtherSecretaryVisitorLogReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "Page_Load", PageNames.OtherSecretaryVisitorLogReport));
            }
        }

        #region "Dropdown Events"

      



        #endregion

        #region "Bind Dropdowns"

     

        /// <summary>
        /// Bind Departments
        /// </summary>
        public void BindDepartments()
        {
            List<DepartmentModel> departments = null;

            if (CurrentUser.DepartmentID != null && CurrentUser.DepartmentID > 0)
            {
                lblDepartment.Visible = false;
                ddlDepartments.Visible = false;
                DivDepartment.Visible = false;
            }
            //  departments = new DepartmentBLL().GetDepartments().Where ( p=>p.ID ==CurrentUser.UserTypeID).ToList ();
            else
                departments = new DepartmentBLL().GetDepartments();

            this.ddlDepartments.Items.Clear();

            this.ddlDepartments.DataSource = departments;
            this.ddlDepartments.DataTextField = "Title";
            this.ddlDepartments.DataValueField = "ID";
            this.ddlDepartments.DataBind();
            ddlDepartments.Items.Insert(0, new ListItem("Choose...", "0"));
        }
        #endregion

        #region "Cutom Method"

        /// <summary>
        /// Show the  report on the basis of filter Criteria
        /// </summary>
        private void ShowReport()
        {
            int DepID;

            int StartMonth, StartYear, EndMonth, EndYear = 0;

            StartMonth = Convert.ToInt32(ddlMonthFrom.SelectedValue);
            StartYear = Convert.ToInt32(ddlYearFrom.SelectedValue);
            EndMonth = Convert.ToInt32(ddlMonthTo.SelectedValue);
            EndYear = Convert.ToInt32(ddlYearTo.SelectedValue);

            try
            {

                if (CommonBLL.ValidateDateControl(StartMonth, StartYear, EndMonth, EndYear))
                {

                    UserControl.Reports.ucReportViewer viewer = (UserControl.Reports.ucReportViewer)this.ucReportViewer1;
                    viewer.ReportName = ReportNames.RptVisitByOtherSecretary;

                    if (CurrentUser.DepartmentID != null && CurrentUser.DepartmentID > 0)
                        DepID = CurrentUser.DepartmentID.Value;
                    else
                        DepID = Convert.ToInt32(ddlDepartments.SelectedValue);

                    UserModel userModel = new UserBLL().GetUsersByDepartmentID(DepID).FirstOrDefault();

                    #region "add the parameters"

                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();
                    parameters.Add(new ReportParameter("UserName", CurrentUser.CurrentUserInfo.EmployeeName));
                    parameters.Add(new ReportParameter("ReportTitle", "Visit Against: " + userModel.EmployeeName.ToUpper()));

                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    DataSet ds = GetReportDataTable(parameters, userModel.UserID.Value, DepID, StartMonth, StartYear, EndMonth, EndYear);

                    if (ds.Tables[1].Rows.Count > 0)
                        parameters.Add(new ReportParameter("CheckRecord", ""));
                    else
                        parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));


                    datasources.Add(new ReportDataSource("dsVisitLog", ds.Tables[1].Copy()));
                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                    // }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('Specified Date Criteria is invalid, Please try again..');", true);

                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ShowReport", 1, PageNames.OtherSecretaryVisitorLogReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "ShowReport", PageNames.OtherSecretaryVisitorLogReport));
            }
        }

        /// <summary>
        /// Getting Service DataTable Da
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataSet GetReportDataTable(List<ReportParameter> parameters, int userID, int depID, int startMonth, int startYear, int endMonth, int endYear)
        {
            // create Generic Table
            DataSet ds = new DataSet();

            try
            {
                #region "Selection Criteria"

              
                //DateTime StartDate = new CommonBLL().ConvertDateFormat(dtpFrom.Value);
                //DateTime EndDate = new CommonBLL().ConvertDateFormat(dtpTo.Value);
                //int StartMonth, StartYear, EndMonth, EndYear = 0;

                //StartMonth = Convert.ToInt32(ddlMonthFrom.SelectedValue);
                //StartYear = Convert.ToInt32(ddlYearFrom.SelectedValue);
                //EndMonth = Convert.ToInt32(ddlMonthTo.SelectedValue);
                //EndYear = Convert.ToInt32(ddlYearTo.SelectedValue);

                ds = new ReportsBLL().GetRptSecretaryVisitingLog(depID, userID, startMonth, startYear, endMonth, endYear);

                if (ds.Tables["tblSecretaryVisitingLog"].Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else if (ds.Tables["tblSecretary2VisitingLog"].Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

                parameters.Add(new ReportParameter("DateRange", ddlMonthFrom.SelectedItem.Text + ", " + ddlYearFrom.SelectedValue.ToUpper() + " to " + ddlMonthTo.SelectedItem.Text.ToUpper() + ", " + ddlYearTo.SelectedValue));

                #endregion
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetReportDataTable", 1, PageNames.OtherSecretaryVisitorLogReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }

                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetReportDataTable", PageNames.OtherSecretaryVisitorLogReport));
            }
            return ds;
        }

        #endregion

        #region "Button Click Events"

        /// <summary>
        /// Show Report Method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
                //pnlError.Visible = false;
            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnShowReport_Click", 1, PageNames.OtherSecretaryVisitorLogReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", PageNames.OtherSecretaryVisitorLogReport));
            }
        }

        #endregion
    }
}