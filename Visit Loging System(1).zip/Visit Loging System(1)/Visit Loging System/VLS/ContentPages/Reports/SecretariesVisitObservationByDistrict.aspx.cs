﻿using BE.CustomEnums;
using BE.LogManager;
using BLL.CommonUtility;
using BLL.Reports;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using VLS.ApplicationClasses;
using VLS.UserControl.Reports;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <22-04-2016 05:00:24PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.ContentPages.Reports
{
    public partial class SecretariesVisitObservationByDistrict : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            pnlError.Visible = false;
            ShowReport();
        }

        #region "Methods"

        private void ShowReport()
        {
            try
            {
                string DistrictID = Request.QueryString["DistrictID"].ToString();
                string FromDate = Request.QueryString["FromDate"].ToString();
                string ToDate = Request.QueryString["ToDate"].ToString();

                ucReportViewer viewer = (ucReportViewer)this.ucReportViewer1;
                viewer.ReportName = ReportNames.RptOfficialsVisitsObservationByDistrict;

                #region "Set Report Parameters"

                List<ReportParameter> parameters = new List<ReportParameter>();
                parameters.Add(new ReportParameter("UserName", CurrentUser.UserDisplayName));

                if (FromDate != "null" && ToDate != "null")
                    parameters.Add(new ReportParameter("DateRange", "From " + FromDate + " To " + ToDate));

                #endregion

                #region "Set DataSource"

                List<ReportDataSource> datasources = new List<ReportDataSource>();

                if (FromDate != "null" && ToDate != "null")
                    datasources.Add(new ReportDataSource("ds", LazyBaseSingletonBLL<ReportsBLL>.Instance.GetOfficialsVisitsObservationByDistrict(Convert.ToInt32(DistrictID),
                        Convert.ToDateTime(FromDate), Convert.ToDateTime(ToDate))));
                else
                    datasources.Add(new ReportDataSource("ds", LazyBaseSingletonBLL<ReportsBLL>.Instance.GetOfficialsVisitsObservationByDistrict(Convert.ToInt32(DistrictID),
                        null, null)));

                #endregion

                viewer.DataSourceList = datasources;

                // add the parameters
                viewer.ParamList = parameters;

                // load the local report (RDLC)
                viewer.LoadLocalReport();
            }
            catch (Exception ex)
            {
                //lblError.Text = ex.Message;
                //pnlError.Visible = true;
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnShowReport_Click", 1, PageNames.SecretaryVisitorObservationByDistrict, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }
            }
        }

        #endregion
    }
}