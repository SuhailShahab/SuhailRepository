﻿using BE.CustomEnums;
using BE.LogManager;
using BLL.CommonUtility;
using BLL.Reports;
using DAL.Enums;
using Microsoft.Reporting.WebForms;
using System;

using System.Web.UI;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;
using VLS.UserControl.Reports;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <30-03-2016 03:16:00PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.ContentPages.Reports
{
    public partial class OfficialsVisitsObservationByDistrict : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                for (int i = DateTime.Now.Year; i <= DateTime.Now.Year + 4; i++)
                {
                    ddlYearFrom.Items.Add(new ListItem(i.ToString(), i.ToString()));
                    ddlYearTo.Items.Add(new ListItem(i.ToString(), i.ToString()));
                }

                ddlYearFrom.SelectedValue = DateTime.Now.Year.ToString();
                ddlYearTo.SelectedValue = DateTime.Now.Year.ToString();


                ddlMonthFrom.SelectedValue = "2";
                ddlMonthTo.SelectedValue = System.DateTime.Now.Month.ToString();
            }
        }

        #region "Methods"

        private void ShowReport()
        {
            int startMonth, startYear, endMonth, endYear = 0;
            startMonth = Convert.ToInt32(ddlMonthFrom.SelectedValue);
            startYear = Convert.ToInt32(ddlYearFrom.SelectedValue);
            endMonth = Convert.ToInt32(ddlMonthTo.SelectedValue);
            endYear = Convert.ToInt32(ddlYearTo.SelectedValue);


            if (CommonBLL.ValidateDateControl(startMonth, startYear, endMonth, endYear))
            {
                ucReportViewer viewer = (ucReportViewer)this.ucReportViewer1;
                viewer.ReportName = ReportNames.RptOfficialsVisitsObservationByDistrict;


                #region "Set Report Parameters"

                List<ReportParameter> parameters = new List<ReportParameter>();
                parameters.Add(new ReportParameter("UserName", CurrentUser.UserDisplayName));
                parameters.Add(new ReportParameter("DateRange", ddlMonthFrom.SelectedItem.Text.ToUpper() + ", " + ddlYearFrom.SelectedValue + " to " + ddlMonthTo.SelectedItem.Text.ToUpper() + ", " + ddlYearTo.SelectedValue));

                #endregion

                #region "Set DataSource"

                List<ReportDataSource> datasources = new List<ReportDataSource>();

                datasources.Add(new ReportDataSource("ds", LazyBaseSingletonBLL<ReportsBLL>.Instance.GetOfficialsVisitsObservationByDistrict(CurrentUser.DepartmentID, CurrentUser.DistrictID, CurrentUser.DivisionID, startMonth, startYear, endMonth, endYear)));

                #endregion

                viewer.DataSourceList = datasources;

                // add the parameters
                viewer.ParamList = parameters;

                // load the local report (RDLC)
                viewer.LoadLocalReport();
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('Specified Date Criteria is invalid, Please try again..');", true);

            }
        }

        #endregion

        #region "Button Click Events"

        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnShowReport_Click", 1, PageNames.OfficialsVisitsObservationByDistrict, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);

                }
              //  new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", PageNames.OfficialsVisitsObservationByDistrict));
            }
        }

        #endregion
    }
}