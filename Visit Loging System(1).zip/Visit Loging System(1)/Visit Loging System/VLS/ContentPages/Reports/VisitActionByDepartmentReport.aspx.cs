﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using BLL.Reports;
using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;


namespace VLS.ContentPages.Reports
{
    public partial class VisitActionByDepartmentReport : System.Web.UI.Page
    {
        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
            try
            {

            //    #region "Comment Out"
            //    //if (Session["UserTable"] != null)
            //    //{
            //    //    DataTable dtUser = (DataTable)Session["UserTable"];
            //    //    SPWeb myWeb = SPControl.GetContextSite(Context).OpenWeb();
            //    //    this.MasterPageFile = myWeb.ServerRelativeUrl + dtUser.Rows[0]["MasterPageUrl"].ToString();
            //    //}
            //    //else
            //    //    Response.Redirect(SPContext.Current.Site.Url + "/_layouts/15/SignOut.aspx", true);
            //    #endregion 

            }
            catch (Exception ex)
            {
                new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "OnPreInit", PageNames.VisitActionByDepartmentReport));
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    for (int i = DateTime.Now.Year; i <= DateTime.Now.Year + 4; i++)
                    {
                        ddlYearFrom.Items.Add(new ListItem(i.ToString(), i.ToString()));
                        ddlYearTo.Items.Add(new ListItem(i.ToString(), i.ToString()));
                    }

                    ddlYearFrom.SelectedValue = DateTime.Now.Year.ToString();
                    ddlYearTo.SelectedValue = DateTime.Now.Year.ToString();

                    ddlMonthFrom.SelectedValue = "2";
                    ddlMonthTo.SelectedValue = System.DateTime.Now.Month.ToString();

                    BindDistricts();

                }
            }

            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 1, PageNames.VisitActionByDepartmentReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }
               // new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "Page_Load", PageNames.VisitActionByDepartmentReport));
            }
        }

        #region "Dropdown Events"

        #endregion

        #region "Bind Dropdowns"

        public void BindDistricts()
        {
            List<DepartmentModel> departments = null;

            if (CurrentUser.DepartmentID != null || CurrentUser.DepartmentID > 0)
            {
                lblDepartment.Visible = false;
                ddlDepartment.Visible = false;
                DivDepartment.Visible = false;
            }
            //  departments = new DepartmentBLL().GetDepartments().Where ( p=>p.ID ==CurrentUser.UserTypeID).ToList ();
            else
                departments = new DepartmentBLL().GetDepartments();


            this.ddlDepartment.Items.Clear();
            this.ddlDepartment.DataSource = departments;
            this.ddlDepartment.DataTextField = "Title";
            this.ddlDepartment.DataValueField = "ID";
            this.ddlDepartment.DataBind();
            this.ddlDepartment.Items.Insert(0, new ListItem("Select All", "0"));
        }
        #endregion

        #region "Cutom Method"


        private void ShowReport()
        {
            try
            {

                int? DepID=null;
                
                // int StartMonth, StartYear, EndMonth, EndYear = 0;

                int StartMonth = Convert.ToInt32(ddlMonthFrom.SelectedValue);
                int StartYear = Convert.ToInt32(ddlYearFrom.SelectedValue);
                int EndMonth = Convert.ToInt32(ddlMonthTo.SelectedValue);
                int EndYear = Convert.ToInt32(ddlYearTo.SelectedValue);

                if (CommonBLL.ValidateDateControl(StartMonth, StartYear, EndMonth, EndYear))
                {
                    UserControl.Reports.ucReportViewer viewer = (UserControl.Reports.ucReportViewer)this.ucReportViewer1;

                    viewer.ReportName = ReportNames.RptVisitActionByDepartment;

                    if (CurrentUser.DepartmentID != null && CurrentUser.DepartmentID > 0) 
                            
                        DepID = CurrentUser.DepartmentID;

                    else
                    {
                        if (ddlDepartment.SelectedIndex > 0) 

                            DepID = Convert.ToInt32(ddlDepartment.SelectedValue);

                        /// ddlDepartment.SelectedIndex > 0 ?? DepID = Convert.ToInt32(ddlDepartment.SelectedValue);
                    }


                    #region "add the parameters"
                    List<ReportParameter> parameters = null;
                    parameters = new List<ReportParameter>();

                    //parameters.Add(new ReportParameter("UserName", "Admin"));
                    parameters.Add(new ReportParameter("UserName", CurrentUser.UserDisplayName));
                    parameters.Add(new ReportParameter("DateRange", ddlMonthFrom.SelectedItem.Text.ToUpper() + ", " + ddlYearFrom.SelectedValue + " to " + ddlMonthTo.SelectedItem.Text.ToUpper() + ", " + ddlYearTo.SelectedValue));
                    //parameters.Add(new ReportParameter("FromDate", new Common().ConvertDateFormat(DateTime.Now.ToString("dd/MM/yyyy")).ToString()));
                    //parameters.Add(new ReportParameter("ToDate", new Common().ConvertDateFormat(DateTime.Now.ToString("dd/MM/yyyy")).ToString()));

                    #endregion

                    // add the data sources
                    List<ReportDataSource> datasources = null;
                    datasources = new List<ReportDataSource>();
                    datasources.Add(new ReportDataSource("dsVisitActionByDepartment", GetReportDataTable(parameters, DepID, CurrentUser.DivisionID,StartMonth, StartYear, EndMonth, EndYear,CurrentUser.DistrictID)));
                    viewer.DataSourceList = datasources;

                    // add the parameters
                    viewer.ParamList = parameters;

                    // load the local report (RDLC)
                    viewer.LoadLocalReport();
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('Specified Date Criteria is invalid, Please try again..');", true);

                }
                //}
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "ShowReport", 1, PageNames.VisitActionByDepartmentReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }
               // new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "ShowReport", PageNames.VisitActionByDepartmentReport));
            }
        }

        /// <summary>
        /// Getting Service DataTable Data
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private DataTable GetReportDataTable(List<ReportParameter> parameters, int? deptID, int? divisionID, int startMonth, int startYear, int endMonth, int endYear,int ? districtID)
        {
            // create Generic Table
            DataTable dt = new DataTable();

            try
            {
                #region "Selection Criteria"

                //int? DepartmentID = null;
                //if (ddlDepartment.SelectedIndex > 0) DepartmentID = Convert.ToInt32(ddlDepartment.SelectedValue);

                //DateTime StartDate = new CommonBLL().ConvertDateFormat(dtpFrom.Value);
                //DateTime EndDate = new CommonBLL().ConvertDateFormat(dtpTo.Value);

                //int StartMonth, StartYear, EndMonth, EndYear = 0;

                //StartMonth = Convert.ToInt32(ddlMonthFrom.SelectedValue);
                //StartYear = Convert.ToInt32(ddlYearFrom.SelectedValue);
                //EndMonth = Convert.ToInt32(ddlMonthTo.SelectedValue);
                //EndYear = Convert.ToInt32(ddlYearTo.SelectedValue);

                dt = LazyBaseSingletonBLL<ReportsBLL>.Instance.GetRptOfficialVisitActionByDepartment(startMonth, startYear, endMonth, endYear, deptID, divisionID, districtID,CurrentUser.LoginID.Value);

                if (dt.Rows.Count > 0)
                    parameters.Add(new ReportParameter("CheckRecord", ""));
                else
                    parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));

                #endregion
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetReportDataTable", 1, PageNames.VisitActionByDepartmentReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }
                //new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "GetReportDataTable", PageNames.VisitActionByDepartmentReport));
            }
            return dt;
        }

        #endregion

        #region "Button Click Events"
        /// <summary>
        /// Show Report Method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowReport_Click(object sender, EventArgs e)
        {
            try
            {
                ShowReport();
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnShowReport_Click", 1, PageNames.VisitActionByDepartmentReport, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    //model = new NewsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }
               // new CommonUtility().AddErrorLog(new ErrorLogModel(ex, "btnShowReport_Click", PageNames.VisitActionByDepartmentReport));
            }
        }
        #endregion
    }
}