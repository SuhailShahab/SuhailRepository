﻿using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Dashboard;
using BLL.Lookups;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS.ContentPages.Site
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (CurrentUser.LoginID.HasValue && CurrentUser.LoginID.Value > 0)
                {
                    if (CurrentUser.GetSessionUserInfo().DesignationID == DesignationNames.CMChiefMinisterPunjab.GetHashCode() || CurrentUser.GetSessionUserInfo().DesignationID == DesignationNames.CMChiefSecretaryPunjab.GetHashCode())
                    {

                        lnkDashboardLog.NavigateUrl = "../Dashboard/VisitLog.aspx";
                        lnkDashboardObservations.NavigateUrl = "../Dashboard/VisitObservation.aspx";
                        lnkCMDashboard.NavigateUrl = "../Dashboard/DashboardCM.aspx";
                        lnkCMDashboard.Text = "FIELD VISITS <br /> MAP - VIEW";

                    }
                    else if (CurrentUser.GetSessionUserInfo().DesignationID == DesignationNames.Secretary.GetHashCode())
                    {
                        if (CurrentUser.GetSessionUserInfo().IsVisitLog.Value)
                        {
                            lnkDashboardLog.NavigateUrl = "../Dashboard/DashboardLogs.aspx";
                            lnkCMDashboard.NavigateUrl = "../../index.aspx";
                        }

                        lnkDashboardObservations.NavigateUrl = "../Dashboard/DashboardObservations.aspx";
                        lnkCMDashboard.Text = "ENTER VISIT REPORT";

                    }
                    else
                    {
                        if (CurrentUser.GetSessionUserInfo().IsVisitLog.Value)
                        {
                            lnkDashboardLog.NavigateUrl = "../Dashboard/DashboardLogs.aspx";
                            lnkCMDashboard.NavigateUrl = "../../index.aspx";
                        }

                        lnkDashboardObservations.NavigateUrl = "../Dashboard/DashboardObservations.aspx";
                        lnkCMDashboard.Text = "ENTER VISIT REPORT";
                    }
                    if (CurrentUser.GetSessionUserInfo().DesignationID == DesignationNames.CMChiefMinisterPunjab.GetHashCode() || CurrentUser.GetSessionUserInfo().DesignationID ==DesignationNames.CMChiefSecretaryPunjab.GetHashCode())
                        lnkSMS.Visible = true;
                    else
                        lnkSMS.Visible = false;
                }
                else
                {
                    Response.Redirect("~/Login.aspx", false);
                }
               
            }
            catch(Exception ex)
            {
                LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 1, PageNames.Home, CurrentUser.GetSessionUserInfo()));
                Response.Redirect("~/Error.aspx?errorMessage="+ex.Message , false);
            }
            
        }

        [WebMethod]
        public static NewsModelView GetRecord()
        {

            NewsModelView modelView = new NewsModelView();
            SiteInformationModel siteInformationModel = null;

            try
            {
                modelView.allRecords = new NewsBLL().GetNews().OrderBy(x => x.ID).ToList();
                modelView.Reports = LazyBaseSingletonBLL<MenuBLL>.Instance.GetUserReportsByLoginID(CurrentUser.LoginID);

                //Set Site Information
                siteInformationModel = LazyBaseSingletonBLL<NewsBLL>.Instance.GetFVMSSiteInfo();
                if (siteInformationModel != null)
                {
                    modelView.Vision = siteInformationModel.Vision;
                    modelView.Mission = siteInformationModel.Mission;
                    modelView.Governance = siteInformationModel.Governance;
                }

            }
            catch (Exception ex)
            {
               // LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Home, CurrentUser.GetSessionUserInfo()));

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Home, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new NewsModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new NewsModelView("error|" + ex.Message);
                }
            }

            return modelView;
        }

        [WebMethod]
        public static List<SecretaryContactModel> GetSecretariesContactList()
        {

            List<SecretaryContactModel> ContactList = new List<SecretaryContactModel>();

            try
            {
                ContactList = new DashboardCMBLL().GetSecretariesContactList();

            }
            catch (Exception ex)
            {
                LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetSecretariesContactList", 1, PageNames.Home, CurrentUser.GetSessionUserInfo()));
            }

            return ContactList;
        }

        [WebMethod]
        public static string SendSMS(string jsonModel)
        {
            SecretaryContactModelView ContactModel = new SecretaryContactModelView();
            ContactModel = new JavaScriptSerializer().Deserialize<SecretaryContactModelView>(jsonModel);
            if(CurrentUser.GetSessionUserInfo().UserTypeID== 3)
                ContactModel.SMS = ContactModel.SMS + "\n \nFrom CM's Office.";
            else
                ContactModel.SMS = ContactModel.SMS + "\n \nFrom Chief Secretary's Office.";

            foreach (SecretaryContactModel contact in ContactModel.Contacts)
            {
                if (contact.Checked && (!string.IsNullOrEmpty(contact.CellNumber)))
                {
                    try
                    {
                        LazyBaseSingletonUI<CommonUtility>.Instance.SendSMSAlert(contact.CellNumber, ContactModel.SMS);

                    }
                    catch
                    {
                    
                    }

                }
            }
            return "SMS sent successfully.";
        }
    }
}