﻿using BE.Common;
using BE.Content;
using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.Content;
using BLL.Lookups;
using BLL.RightsManager;
using BLL.SessionState;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using VLS.ApplicationClasses;
using System.Linq;
using BE.EmailQueue;
using BLL.RamzanBazar;
using VLS.BLL.Content;
using VLS.BLL.Dashboard;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace VLS
{
    public partial class index : System.Web.UI.Page
    {

        
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (CurrentUser.LoginID.HasValue && CurrentUser.LoginID.Value > 0)
                {
                    lnkUserName.Text = "<i class='fa fa-user'></i> " + CurrentUser.LoginName + " <i class='fa fa-caret-down'></i>";
                }
                else
                    Response.Redirect("~/Login.aspx", false);


                if (Request.Form["VisitLogID"] != null)
                    UpdateFiles();

               
            }
            catch (Exception ex)
            {
                //new CommonBLL().AddErrorLog(new ErrorLogModel(ex, "UploadImages", PageNames.Index));
                //Response.Redirect("~/Error.aspx?errorMessage="+ex.Message, false);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 1, PageNames.Index, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);  
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errorMessage="+ex.Message, false);
                }
            }
        }

        #region "Methods"

        private void UpdateFiles()
        {
            List<ImageModel> colImages = new List<ImageModel>();
            ImageModel img = null;

            HttpRequest request = Page.Request;
            string VisitLogID = request.Form["VisitLogID"].ToString();
            string FileCount = request.Form["ImageCount"].ToString();

            for (int i = 0; i < Convert.ToInt32(FileCount); i++)
            {
                img = new ImageModel();
              
                img.ImageTitle = request.Form["Title" + i].ToString();
                img.ImageDescription = request.Form["ImageDescription" + i].ToString();
                img.VisitorLogImage = request.Form["VisitorLogImage" + i].ToString();
                img.ContentType = request.Form["ContentType" + i].ToString();

                colImages.Add(img);
            }

            int result = LazyBaseSingletonBLL<VisitorLogBLL>.Instance.SaveImages(Convert.ToInt32(VisitLogID), colImages);

        }

        #endregion

        #region "Web Methods"

        /// <summary>
        /// Get Project Information
        /// </summary>
        /// <returns>Project Information</returns>
        [WebMethod]
        public static VisitorLogModelView GetRecords(string visitorLogID)
        {
            VisitorLogModelView model = new VisitorLogModelView();

            try
            {
                CommonListModel commonListModel = LazyBaseSingletonUI<CommonUtility>.Instance.GetCommonLookups();

                model.Provinces = new ProvinceBLL().GetAllActiveProvinces();
                model.Divisions = new DivisionBLL().GetDivisions();
                model.Districts = commonListModel.Districts;

                model.Cities = new CityBLL().GetAllCities();
                model.Tehsils = commonListModel.Tehsils;
                model.UnionCouncils = new UnionCouncilBLL().GetUnionCouncils();

                model.Constituencies = new ConstituencyBLL().GetConstituency();
                model.NAConstituencies = new NAConstituencyBLL().GetAllNAconstituencies().OrderBy(p=>p.Title).ToList();

                model.Departments = new DepartmentBLL().GetDepartments();
                model.HospitalTypes = new HospitalTypeBLL().GetActiveHospitalTypes();

                VisitorLogModel logModel = new VisitorLogModel();





                if (string.IsNullOrEmpty(visitorLogID) || visitorLogID == "null")
                {
                    logModel.Doctors = new DoctorBLL().GetActiveDoctors();
                    logModel.DoctorPosts = new DoctorPostBLL().GetActiveDoctorPosts();
                    logModel.HospitalEquipments = new HospitalEquipmentBLL().GetActiveHospitalEquipments();
                    logModel.MedicineTypes = new MedicineTypeBLL().GetActiveMedicineTypes();

                    logModel.RamzanBazarModel = LazyBaseSingletonBLL<RamzanBazarMonitoringBLL>.Instance.GetRamzanBazarMonitoring();
                    model.visit = logModel;

                }
                else
                {

                    int id = Convert.ToInt32(visitorLogID);
                    //if (!LazyBaseSingletonBLL<ActionDetailBLL>.Instance.IsValidVistorUser(id, CurrentUser.LoginID.Value))
                    if (!LazyBaseSingletonBLL<ActionDetailBLL>.Instance.IsValidUserPrintActionReport(id, CurrentUser.LoginID.Value))
                    {

                        throw new Exception(CutomMessage.NotAuthorizedToViewRecord);
                        //Response.Redirect("~/Error.aspx?errorMessage=" + CutomMessage.NotAuthorizedToViewRecord, false);
                    }
                    else if (CurrentUser.GetSessionUserInfo().IsAllowedToEdit.HasValue && (CurrentUser.GetSessionUserInfo().IsAllowedToEdit.Value))
                    {
                        //TODO Get Data to edit Record
                        model.visit = LazyBaseSingletonBLL<VisitorLogBLL>.Instance.GetVsitorLogInformation(id);
                        model.VisitoryImages = LazyBaseSingletonBLL<DashboardReportBLL>.Instance.GetVisitsLogPictures(id);


                    }
                    else
                    {
                        throw new Exception(CutomMessage.NotAuthorizedToViewRecord);
                    }

                }

                model.DashboardTitle = CurrentUser.DashboardTitle;
                model.UserDesignation = CurrentUser.UserDesignationName;
                model.UserDepartment = CurrentUser.UserDepartmentName;

                //Ramzan Bazar
                model.Conditions = LazyBaseSingletonBLL<ConditionBLL>.Instance.GetConditions(null).ToList();

                


            }
            catch (Exception ex)
            {
                //new CommonBLL().AddErrorLog(new ErrorLogModel(ex, "GetRecords", PageNames.Index));
                //model = new VisitorLogModelView("error|" + ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Index, CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new VisitorLogModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new VisitorLogModelView("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// save Visit log Info
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static VisitorLogModel Save(string jsonModel)
        {
            int? result = 0;
            VisitorLogModel model = null;

            try
            {
                model = new JavaScriptSerializer().Deserialize<VisitorLogModel>(jsonModel);

                if (model.VisitorLogID == 0)
                    model.CreatedBy = CurrentUser.LoginID ?? 0;           //TODO set user information form current login
                else
                    model.ModifiedBy = CurrentUser.LoginID ?? 0;          //TODO set user information form current login

                result = LazyBaseSingletonBLL<VisitorLogBLL>.Instance.SaveVisit(model); //.Save(model);

                if (model.VisitorLogID == 0)
                {
                    model.VisitorLogID = result.Value;

                    RatingModel rating = LazyBaseSingletonBLL<RatingBLL>.Instance.GetRatingByID(Convert.ToInt32(model.Rating));

                    // Get users information to send sms & email
                    VisitConcernUser objVCU = LazyBaseSingletonBLL<UserBLL>.Instance.GetUsersToSendEmailAndSMS(CurrentUser.LoginID, model.DistrictID, model.DivisionID, model.DepartmentID);

                    #region "Email & SMS to Visit Performer Officical"

                    if (ConfigurationHelper.SendEmailToVisitByOfficial && string.IsNullOrEmpty(rating.VisitEmailForOffical) == false && string.IsNullOrEmpty(objVCU.Visiter.EMail) == false)
                    {
                        try
                        {
                            DepartmentModel dm = LazyBaseSingletonBLL<DepartmentBLL>.Instance.GetDepartmentByID(model.DepartmentID);

                            string subject = "Visit Performed At " + dm.Title + " department on " + model.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");
                            StringBuilder body = new StringBuilder();

                            body.AppendLine(rating.VisitEmailForOffical);

                            EmailModel emailModel = new EmailModel(subject,body.ToString());
                            emailModel.ToEmailAddresses = new List<string>();
                            emailModel.ToEmailAddresses.Add(objVCU.Visiter.EMail);

                            if(!string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL))
                            LazyBaseSingletonUI<CommonUtility>.Instance.SendEmailToQueue(emailModel);
                            else 
                            LazyBaseSingletonUI<CommonUtility>.Instance.MailSend(objVCU.Visiter.EMail, subject, body.ToString());
                        }
                        catch { }
                    }

                    if (ConfigurationHelper.SendSMSToVisitByOfficial && string.IsNullOrEmpty(rating.VisitSMSForOffical) == false && string.IsNullOrEmpty(objVCU.Visiter.CellNumber) == false)
                    {
                        try
                        {
                            LazyBaseSingletonUI<CommonUtility>.Instance.SendSMSAlert(objVCU.Visiter.CellNumber, rating.VisitSMSForOffical);
                        }
                        catch { }
                    }

                    #endregion

                    #region "Email & SMS to Observation Officical"

                    if (ConfigurationHelper.SendEmailToObservationOfficial)
                    {
                        try
                        {
                            if (string.IsNullOrEmpty(rating.ObservationEMailForOfficial) == false && string.IsNullOrEmpty(objVCU.Secretary.EMail) == false)
                            {
                                //DepartmentModel dm = LazyBaseSingletonBLL<DepartmentBLL>.Instance.GetDepartmentByID(model.DepartmentID);

                                string subject = "Visit Observation added by " + CurrentUser.CurrentUserInfo.EmployeeName + " on " + model.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");
                                StringBuilder body = new StringBuilder();

                                body.AppendLine(rating.ObservationEMailForOfficial);

                               
                                EmailModel emailModel = new EmailModel(subject, body.ToString());
                                emailModel.ToEmailAddresses = new List<string>();
                                emailModel.ToEmailAddresses.Add(objVCU.Secretary.EMail);

                                if (!string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL))
                                    LazyBaseSingletonUI<CommonUtility>.Instance.SendEmailToQueue(emailModel);
                                else
                                    LazyBaseSingletonUI<CommonUtility>.Instance.MailSend(objVCU.Secretary.EMail, subject, body.ToString());
                            }

                            // Send Email to DCO of Related Location where Observation Marked
                            if (string.IsNullOrEmpty(rating.ObservationEMailForOfficial) == false && string.IsNullOrEmpty(objVCU.DCO.EMail) == false)
                            {

                                string subject = "Visit Observation added by " + CurrentUser.CurrentUserInfo.EmployeeName + " on " + model.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");
                                StringBuilder body = new StringBuilder();

                                body.AppendLine(rating.ObservationEMailForOfficial);


                                EmailModel emailModel = new EmailModel(subject, body.ToString());
                                emailModel.ToEmailAddresses = new List<string>();
                                emailModel.ToEmailAddresses.Add(objVCU.DCO.EMail);

                                if (!string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL))
                                    LazyBaseSingletonUI<CommonUtility>.Instance.SendEmailToQueue(emailModel);
                                else
                                    LazyBaseSingletonUI<CommonUtility>.Instance.MailSend(objVCU.DCO.EMail, subject, body.ToString());
                            }

                            // Send Email to Commissioner of Related Location where Observation Marked
                            if (string.IsNullOrEmpty(rating.ObservationEMailForOfficial) == false && string.IsNullOrEmpty(objVCU.Commissioner.EMail) == false)
                            {

                                string subject = "Visit Observation added by " + CurrentUser.CurrentUserInfo.EmployeeName + " on " + model.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");
                                StringBuilder body = new StringBuilder();

                                body.AppendLine(rating.ObservationEMailForOfficial);


                                EmailModel emailModel = new EmailModel(subject, body.ToString());
                                emailModel.ToEmailAddresses = new List<string>();
                                emailModel.ToEmailAddresses.Add(objVCU.Commissioner.EMail);

                                if (!string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL))
                                    LazyBaseSingletonUI<CommonUtility>.Instance.SendEmailToQueue(emailModel);
                                else
                                    LazyBaseSingletonUI<CommonUtility>.Instance.MailSend(objVCU.Commissioner.EMail, subject, body.ToString());
                            }


                            if (string.IsNullOrEmpty(rating.ObservationEamilForSubOrdinates) == false && objVCU.SecretaryReportingUsers != null)
                            {
                                foreach (UserModel um in objVCU.SecretaryReportingUsers)
                                {
                                    if (string.IsNullOrEmpty(um.EMail)) continue;

                                    string subject = "Visit Observation added by " + CurrentUser.CurrentUserInfo.EmployeeName + " on " + model.VisitStartDate.Value.Date.ToString("dd-MMM-yyyy");
                                    StringBuilder body = new StringBuilder();

                                    body.AppendLine(rating.ObservationEamilForSubOrdinates);

                                    EmailModel emailModel = new EmailModel(subject, body.ToString());
                                    emailModel.ToEmailAddresses = new List<string>();
                                    emailModel.ToEmailAddresses.Add(um.EMail);
                                   
                                    if (!string.IsNullOrEmpty(ConfigurationHelper.EmailQueueURL))
                                        LazyBaseSingletonUI<CommonUtility>.Instance.SendEmailToQueue(emailModel);
                                    else
                                       LazyBaseSingletonUI<CommonUtility>.Instance.MailSend(um.EMail, subject, body.ToString());
                                }
                            }

                        }
                        catch { }
                    }

                    if (ConfigurationHelper.SendSMSToObservationOfficial)
                    {
                        try
                        {
                            if (string.IsNullOrEmpty(rating.ObservationSMSForOfficial) == false && string.IsNullOrEmpty(objVCU.Secretary.CellNumber) == false)
                            {
                                LazyBaseSingletonUI<CommonUtility>.Instance.SendSMSAlert(objVCU.Secretary.CellNumber, rating.ObservationSMSForOfficial);
                            }

                            // Send SMS to DCO of Related Location where Observation Marked
                            if (string.IsNullOrEmpty(rating.ObservationSMSForOfficial) == false && string.IsNullOrEmpty(objVCU.DCO.CellNumber) == false)
                            {
                                LazyBaseSingletonUI<CommonUtility>.Instance.SendSMSAlert(objVCU.DCO.CellNumber, rating.ObservationSMSForOfficial);
                            }

                            // Send SMS to Commissioner of Related Location where Observation Marked
                            if (string.IsNullOrEmpty(rating.ObservationSMSForOfficial) == false && string.IsNullOrEmpty(objVCU.Commissioner.CellNumber) == false)
                            {
                                LazyBaseSingletonUI<CommonUtility>.Instance.SendSMSAlert(objVCU.Commissioner.CellNumber, rating.ObservationSMSForOfficial);
                            }

                            if (string.IsNullOrEmpty(rating.ObservationSMSForSubOrdinates) == false && objVCU.SecretaryReportingUsers != null)
                            {
                                foreach (UserModel um in objVCU.SecretaryReportingUsers)
                                {
                                    if (string.IsNullOrEmpty(um.CellNumber)) continue;

                                    LazyBaseSingletonUI<CommonUtility>.Instance.SendSMSAlert(um.CellNumber, rating.ObservationSMSForSubOrdinates);
                                }
                            }
                        }
                        catch { }
                    }

                    #endregion
                }

             

                model.Notification = "success|Visit has been loged successfully.";
             
            }
            catch (Exception ex)
            {
                new CommonBLL().AddErrorLog(new ErrorLogModel(ex, "Save", PageNames.Index));
                model = new VisitorLogModel("error|" + ex.Message);
            }

            return model;
        }

        [WebMethod]
        public static string RemoveImage(string imageID)
        {
            string result= string.Empty ;
            try
            {
                if(!string.IsNullOrEmpty(imageID))
                {
                    int noOfRowsAffected = LazyBaseSingletonBLL<VisitorLogBLL>.Instance.DeleteVistorLogImage(Convert.ToInt32(imageID));
                    if (noOfRowsAffected > 0)
                    result = "success|Image Remove successfully.";
                    else
                        result = "error|Image not Remove.";
                }
                
            }
            catch(Exception ex)
            {
                 result = "error|" + ex.Message;
            }
            return result;
        }
        #endregion


        #region "Button Events"

        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            try
            {
                HttpCookie aCookie;
                string cookieName;
                int limit = Request.Cookies.Count;
                for (int i = 0; i < limit; i++)
                {
                    cookieName = Request.Cookies[i].Name;
                    aCookie = new HttpCookie(cookieName);
                    aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                    Response.Cookies.Add(aCookie); // overwrite it
                }

                if (ConfigurationHelper.SQLServer.HasValue && ConfigurationHelper.SQLServer.Value)
                    LazyBaseSingletonBLL<SessionStateBLL>.Instance.DeleteSessionByID(Session.SessionID);
                Session.Clear();
                Session.Abandon();
                Response.Redirect("~/Login.aspx", false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion
    }
}