﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace SMS.CMP
{
    public partial class Error : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //this.errorMessage.InnerText = "Test Message";
        }

      
        protected void HomeButton_Click(object sender, EventArgs e)
        {
            string url = string.Empty;
            if (CurrentUser.LoginID.HasValue)
            {
                url = "~/ContentPages/Site/Home.aspxpx";
            }
            else
            {
                url = "~/Login.aspx";
                // Response.Redirect("~/Login.aspx", false);
            }
            Response.Redirect(url, false);
        }
    }
}