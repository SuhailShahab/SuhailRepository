﻿using BE.CustomEnums;
using BE.LogManager;
using BLL;
using BLL.CommonUtility;
using BLL.RightsManager;
using BLL.SessionState;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS
{
    public partial class VLS : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                if (!IsPostBack)
                {


                    if (CurrentUser.LoginID.HasValue && CurrentUser.LoginID.Value > 0)
                    {
                        string staticPageName = System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath);

                        bool isValidPageAccess = false;
                        if (staticPageName.Contains("Dashboard"))
                        {
                            isValidPageAccess = LazyBaseSingletonBLL<CommonBLL>.Instance.GetUserPageAccess(CurrentUser.LoginID, staticPageName, 1);
                        }
                        else
                        {
                            isValidPageAccess = LazyBaseSingletonBLL<CommonBLL>.Instance.GetUserPageAccess(CurrentUser.LoginID, staticPageName);
                        }

                        if (!isValidPageAccess)
                        {
                            Response.Redirect("~/Error.aspx?errorMessage=" + CutomMessage.NotAuthorizedToPage, false);
                        }
                        else if (CurrentUser.LoginID.HasValue)
                        {
                            lnkUser.Text = CurrentUser.UserDisplayName;
                            BuildMenu(CurrentUser.LoginID);
                        }
                    }
                    else
                        Response.Redirect("~/Login.aspx", false);

                }
                   


            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "PageLoad", 1, System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath), CurrentUser.GetSessionUserInfo()));
                //Response.Redirect("../../Layouts/Error.aspx?errorMessage="+ex.Message, false);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "PageLoad", 1, System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath), CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    // featuresModel = new ApplicationFeatureModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    Response.Redirect("../../Layouts/Error.aspx?errorMessage="+ex.Message, false);
                }
            }
        }


        #region "Private Methods"

        private void BuildMenu(int? loginID)
        {
            Panel pnlMenu = (Panel)this.FindControl("pnlMenu");
            StringBuilder menu = new StringBuilder();

            try
            {
                DataSet ds = LazyBaseSingletonBLL<MenuBLL>.Instance.GetMenuByUser(loginID.Value); 
                DataTable dt = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    dt.DefaultView.Sort = "Sort";

                    menu.AppendLine("<ul>");
                    foreach (DataRow dr in dt.Rows)     //loop for Features
                    {
                        menu.AppendLine("<li>");
                        if (Convert.ToBoolean(dr["HasChild"].ToString()) == true)
                        {
                            menu.AppendLine("<a href='#'><i class='" + dr["Icon"] + "'></i>&nbsp;&nbsp;" + dr["Name"] + "</a>");
                            menu.AppendLine("<ul>");

                            DataRow[] drObjects = ds.Tables[1].Select("AppFeatureID=" + dr["FeatureID"].ToString());
                            foreach (DataRow odr in drObjects)   // loop for Objects
                            {
                                menu.AppendLine("<li>");
                                menu.AppendLine("<a href='" + odr["URL"] + "'>" + odr["Name"] + "</a></li>");

                            }   //end objects loop

                            menu.AppendLine("</ul></li>");
                        }
                        else
                            menu.AppendLine("<a href='" + dr["URL"] + "'><i class='" + dr["Icon"] + "'></i>&nbsp;&nbsp;" + dr["Name"] + "</a></li>");

                    }   //end features loop

                    menu.AppendLine("</ul>");

                    pnlMenu.Controls.Add(new LiteralControl(menu.ToString()));
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //private void BuildMenu(int? loginID)
        //{
        //    Panel pnlMenu = (Panel)this.FindControl("pnlMenu");
        //    StringBuilder menu = new StringBuilder();

        //    try
        //    {
        //        //DataSet ds = new MenuBLL()..GetMenuByUserName("super.user");
        //        DataSet ds = LazyBaseSingletonBLL<MenuBLL>.Instance.GetMenuByUser(loginID.Value);

        //        Cache[loginID.ToString()] = ds;

        //        DataTable dt = ds.Tables[0];

        //        if (dt.Rows.Count > 0)
        //        {
        //            dt.DefaultView.Sort = "Sort";

        //            menu.AppendLine("<ul>");
        //            foreach (DataRow dr in dt.Rows)     //loop for Features
        //            {
        //                menu.AppendLine("<li>");
        //                if (Convert.ToBoolean(dr["HasChild"].ToString()) == true)
        //                {
        //                    menu.AppendLine("<a href='#'><i class='" + dr["ImageClass"] + "'></i>&nbsp;&nbsp;" + dr["Name"] + "</a>");
        //                    menu.AppendLine("<ul>");

        //                    DataRow[] drObjects = ds.Tables[1].Select("AppFeatureID=" + dr["FeatureID"].ToString());
        //                    foreach (DataRow odr in drObjects)   // loop for Objects
        //                    {
        //                        menu.AppendLine("<li>");
        //                        menu.AppendLine("<a href='" + odr["URL"] + "'>" + odr["Name"] + "</a></li>");

        //                    }   //end objects loop

        //                    menu.AppendLine("</ul></li>");
        //                }
        //                else
        //                    menu.AppendLine("<a href='" + dr["URL"] + "'><i class='" + dr["ImageClass"] + "'></i>&nbsp;&nbsp;" + dr["Name"] + "</a></li>");

        //            }   //end features loop

        //            menu.AppendLine("</ul>");

        //            pnlMenu.Controls.Add(new LiteralControl(menu.ToString()));
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //private void BuildMenu(DataSet ds)
        //{
        //    Panel pnlMenu = (Panel)this.FindControl("pnlMenu");
        //    StringBuilder menu = new StringBuilder();

        //    try
        //    {

        //        DataTable dt = ds.Tables[0];

        //        if (dt.Rows.Count > 0)
        //        {
        //            dt.DefaultView.Sort = "Sort";

        //            menu.AppendLine("<ul>");
        //            foreach (DataRow dr in dt.Rows)     //loop for Features
        //            {
        //                menu.AppendLine("<li>");
        //                if (Convert.ToBoolean(dr["HasChild"].ToString()) == true)
        //                {
        //                    menu.AppendLine("<a href='#'><i class='" + dr["ImageClass"] + "'></i>&nbsp;&nbsp;" + dr["Name"] + "</a>");
        //                    menu.AppendLine("<ul>");

        //                    DataRow[] drObjects = ds.Tables[1].Select("AppFeatureID=" + dr["FeatureID"].ToString());
        //                    foreach (DataRow odr in drObjects)   // loop for Objects
        //                    {
        //                        menu.AppendLine("<li>");
        //                        menu.AppendLine("<a href='" + odr["URL"] + "'>" + odr["Name"] + "</a></li>");

        //                    }   //end objects loop

        //                    menu.AppendLine("</ul></li>");
        //                }
        //                else
        //                    menu.AppendLine("<a href='" + dr["URL"] + "'><i class='" + dr["ImageClass"] + "'></i>&nbsp;&nbsp;" + dr["Name"] + "</a></li>");

        //            }   //end features loop

        //            menu.AppendLine("</ul>");

        //            pnlMenu.Controls.Add(new LiteralControl(menu.ToString()));
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        #endregion

        #region "Button Events"

        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            try
            {
                HttpCookie aCookie;
                string cookieName;
                int limit = Request.Cookies.Count;
                for (int i = 0; i < limit; i++)
                {
                    cookieName = Request.Cookies[i].Name;
                    aCookie = new HttpCookie(cookieName);
                    aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                    Response.Cookies.Add(aCookie); // overwrite it
                }
                
                if (ConfigurationHelper.SQLServer.HasValue && ConfigurationHelper.SQLServer.Value)
                LazyBaseSingletonBLL<SessionStateBLL>.Instance.DeleteSessionByID(Session.SessionID);
                Session.Clear();
                Session.Abandon();
                Response.Redirect("~/Login.aspx", false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion
    }
}