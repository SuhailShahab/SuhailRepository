﻿using BLL.CommonUtility;
using BLL.SessionState;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS
{
    public partial class Site : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                lnkUser.Text = CurrentUser.UserDisplayName;
            }
            catch (Exception)
            {
                
                throw;
            }
        }

        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            try
            {
                HttpCookie aCookie;
                string cookieName;
                int limit = Request.Cookies.Count;
                for (int i = 0; i < limit; i++)
                {
                    cookieName = Request.Cookies[i].Name;
                    aCookie = new HttpCookie(cookieName);
                    aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                    Response.Cookies.Add(aCookie); // overwrite it
                }

                if (ConfigurationHelper.SQLServer.HasValue && ConfigurationHelper.SQLServer.Value)
                    LazyBaseSingletonBLL<SessionStateBLL>.Instance.DeleteSessionByID(Session.SessionID);
                Session.Clear();
                Session.Abandon();
                Response.Redirect("~/Login.aspx", false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}