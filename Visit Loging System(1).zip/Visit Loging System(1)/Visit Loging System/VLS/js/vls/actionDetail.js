﻿
var TentageStatuses = [{ Title: 'Purchased', Value: 1 }, { Title: 'Rental', Value: 2 }];
var apostrophyRegx = new RegExp("'", "g");
var doubleQoutesRegx = new RegExp("\"", "g");
var commentRegex = new RegExp(
    '<!--[\\s\\S]*?(?:-->)?'
    + '<!---+>?'  // A comment with no body
    + '|<!(?![dD][oO][cC][tT][yY][pP][eE]|\\[CDATA\\[)[^>]*>?'
    + '|<[?][^>]*>?',  // A pseudo-comment
    'g');
var YesNo = [{ Title: 'Yes', Value: true }, { Title: 'No', Value: false }];
var ref_provinces = [];
var ref_districts = [];
var ref_divisions = [];
var ref_tehsils = [];
var ref_unioncouncils = [];
var ref_constituencies = [];


/* INIT: All plugins initialization(s) */
var ratings = [{ 'Title': 'Very Poor', 'Value': 1 },
              { 'Title': 'Poor', 'Value': 2 },
              { 'Title': 'Un-satisfactory', 'Value': 3 },
              { 'Title': 'Average', 'Value': 4 },
              { 'Title': 'Satisfactory', 'Value': 5 },
              { 'Title': 'Good', 'Value': 6 },
              { 'Title': 'Excellent', 'Value': 7 }];

/* END INIT: All plugins initialization(s) */

var viewModel = new ViewModel();


ko.bindingHandlers.nicedit = {
    init: function (element, valueAccessor) {
        var value = valueAccessor();
        var area = new nicEditor({ fullPanel: true }).panelInstance(element.id, { hasPanel: true });
        $(element).text(ko.utils.unwrapObservable(value));

        // function for updating the right element whenever something changes
        var textAreaContentElement = $($(element).prev()[0].childNodes[0]);
        var areachangefc = function () {
            value(textAreaContentElement.html());
        };

        // Make sure we update on both a text change, and when some HTML has been added/removed
        // (like for example a text being set to "bold")
        $(element).prev().keyup(areachangefc);
        $(element).prev().bind('DOMNodeInserted DOMNodeRemoved', areachangefc);
    },
    update: function (element, valueAccessor) {
        var value = valueAccessor();
        var textAreaContentElement = $($(element).prev()[0].childNodes[0]);
        textAreaContentElement.html(value());
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {},
            $el = $(element);

        $el.datepicker(options);

        //handle the field changing by registering datepicker's changeDate event
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });

        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });

    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
            $el = $(element);

        //handle date data coming via json from Microsoft
        if (String(value).indexOf('/Date(') == 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }

        var current = $el.datepicker("getDate");

        if (value - current !== 0) {
            $el.datepicker("setDate", value);
        }
    }
};


//** TimePicker Custom binding **\\
ko.bindingHandlers.timeValue = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
        var tpicker = $(element).timepicker();
        tpicker.on('changeTime.timepicker', function (e) {

            //Asignar la hora y los minutos
            var value = valueAccessor();
            if (!value) {
                throw new Error('timeValue binding observable not found');
            }
            var date = ko.unwrap(value);
            var mdate = moment(date || new Date());
            var hours24;
            if (e.time.meridian == "AM") {
                if (e.time.hours == 12)
                    hours24 = 0;
                else
                    hours24 = e.time.hours;
            }
            else {
                if (e.time.hours == 12) {
                    hours24 = 12;
                }
                else {
                    hours24 = e.time.hours + 12;
                }
            }

            mdate.hours(hours24)
            mdate.minutes(e.time.minutes);
            $(element).data('updating', true);
            value(mdate.toDate());
            $(element).data('updating', false);


        })
    },
    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
        //Avoid recursive calls
        if ($(element).data('updating')) {
            return;
        }
        var date = ko.unwrap(valueAccessor()) || new Date();

        if (date) {
            var time = moment(date).format("hh:mmA");
            //var matches = time.match(/(\d{1,2}):(\d{2})/);
            //var zone = parseInt(matches[0]) >= 12 ? 'PM' : 'AM';
            //time = matches[1] + ':' + matches[2] + ' ' + zone;
            $(element).timepicker('setTime', time);
        }
        else {
            // $(element).timepicker('clear');
        }
    }
};


ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};


function VisitDetailModel(visit) {
    var self = this;
    if (visit != null) {
        self.ProvinceName = ko.observable(visit.ProvinceName);
        self.DivisionName = ko.observable(visit.DivisionName);
        self.DistrictName = ko.observable(visit.DistrictName);
        self.CityName = ko.observable(visit.CityID);
        self.TehsilName = ko.observable(visit.TehsilName);
        self.UnionCouncilName = ko.observable(visit.UnionCouncilName);
        self.ConstituencyName = ko.observable(visit.ConstituencyName);
        self.ConstituencyNAName = ko.observable(visit.ConstituencyNAName);
        self.DepartmentName = ko.observable(visit.DepartmentName);
        self.DepartmentID = ko.observable(visit.DepartmentID);
        self.MarkedTo = ko.observable(visit.MarkedTo);
        self.PlaceCategoryName = ko.observable(visit.PlaceCategoryName);
        self.Place = ko.observable(visit.Place);
        self.VisitStartDate = ko.observable(ko.utils.unwrapObservable(visit.StartDate).toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(visit.StartDate).substring(6, 19)))).format('DD-MMM-YYYY') : ko.utils.unwrapObservable(visit.StartDate));
        self.VisitStartTime = ko.observable(ko.utils.unwrapObservable(visit.StartTime).toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(visit.StartTime).substring(6, 19)))).format('hh:mm A') : ko.utils.unwrapObservable(visit.StartTime));
        self.VisitEndTime = ko.observable(ko.utils.unwrapObservable(visit.EndTime).toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(visit.EndTime).substring(6, 19)))).format('hh:mm A') : ko.utils.unwrapObservable(visit.EndTime));
        self.VisitEndDate = ko.observable(ko.utils.unwrapObservable(visit.EndDate).toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(visit.EndDate).substring(6, 19)))).format('DD-MMM-YYYY') : ko.utils.unwrapObservable(visit.EndDate));
        self.Department = ko.observable(visit.Department);
        self.VisitAgenda = ko.observable(visit.VisitAgenda);
        self.Feedback = ko.observable(visit.Feedback);
        self.RatingName = ko.observable(visit.RatingName);
        self.Latitude = ko.observable(visit.Latitude);
        self.Longitude = ko.observable(visit.Longitude);
        self.ActionRemarks = ko.observable(visit.ActionRemarks || '');
        self.Images = ko.observableArray();
        self.ActionImages = ko.observableArray();
        if (visit.Images != null) {
            ko.utils.arrayForEach(visit.Images, function (img) {
                self.Images.push(new ImageModel(img));
            });
        }

        self.HospitalTypeID = ko.observable(visit.HospitalTypeID);
        self.HospitalCleanliness = ko.observable(visit.HospitalCleanliness.toString());
        self.HospitalType = ko.observable(visit.HospitalType || '');

        self.Rating = ko.observable(visit.Rating);
        self.AbsentTecherPercentage = ko.observable(visit.AbsentTecherPercentage);
        self.AbsentStudentPercentage = ko.observable(visit.AbsentStudentPercentage);
        self.WashroomCleanliness = ko.observable(visit.WashroomCleanliness.toString());
        self.GeneralCleanliness = ko.observable(visit.GeneralCleanliness.toString());
        self.DrinkWaterAvailable = ko.observable(visit.DrinkWaterAvailable.toString());
        self.ElectricityAvailable = ko.observable(visit.ElectricityAvailable.toString());
        self.SecurityArrangementAvailable = ko.observable(visit.SecurityArrangementAvailable.toString());
        //self.IsBoundaryWallIntact = ko.observable(visit.IsBoundaryWallIntact.toString());
        self.IsBoundaryWallIntact = ko.observable(visit.IsBoundaryWallIntact || false);

        self.CreatedBy = ko.observable(visit.CreatedBy);
        self.Doctors = ko.observableArray();
        self.DoctorPosts = ko.observableArray();
        self.HospitalEquipments = ko.observableArray();
        self.MedicineTypes = ko.observableArray();

        self.Conditions = ko.observableArray();

        self.RamzanBazarModel = ko.observable(new RamzanBazarMonitoringModel(null));
        if (visit.RamzanBazarModel != null && visit.DepartmentID == 19) {

            self.RamzanBazarModel(new RamzanBazarMonitoringModel(visit.RamzanBazarModel));
        }

        if (visit.Conditions != null) {
            ko.utils.arrayForEach(visit.Conditions, function (prov) {
                self.Conditions.push(new CommonModel(prov));
            });
        }

        if (visit.Doctors != null) {
            ko.utils.arrayForEach(visit.Doctors, function (img) {
                self.Doctors.push(new CommonModel(img));
            });
        }

        if (visit.DoctorPosts != null) {
            ko.utils.arrayForEach(visit.DoctorPosts, function (img) {
                self.DoctorPosts.push(new CommonModel(img));
            });
        }

        if (visit.HospitalEquipments != null) {
            ko.utils.arrayForEach(visit.HospitalEquipments, function (img) {
                self.HospitalEquipments.push(new CommonModel(img));
            });
        }

        if (visit.MedicineTypes != null) {
            ko.utils.arrayForEach(visit.MedicineTypes, function (img) {
                self.MedicineTypes.push(new CommonModel(img));
            });
        }
    }
    else {

        self.Rating = ko.observable();
        self.ProvinceName = ko.observable('');
        self.DivisionName = ko.observable('');
        self.DistrictName = ko.observable('');
        self.CityName = ko.observable('');
        self.TehsilName = ko.observable('');
        self.UnionCouncilName = ko.observable('');
        self.ConstituencyName = ko.observable('');
        self.ConstituencyNAName = ko.observable('');
        self.MarkedTo = ko.observable('');
        self.PlaceCategoryName = ko.observable('');
        self.DepartmentName = ko.observable('');
        self.DepartmentID = ko.observable(0);
        self.Place = ko.observable('');
        self.VisitStartDate = ko.observable('');
        self.VisitStartTime = ko.observable('');
        self.VisitEndTime = ko.observable('');
        self.VisitEndDate = ko.observable('');
        self.Department = ko.observable('');
        self.VisitAgenda = ko.observable('');
        self.Feedback = ko.observable('');
        self.RatingName = ko.observable('');
        self.Latitude = ko.observable(0.0);
        self.Longitude = ko.observable(0.0);
        self.ActionRemarks = ko.observable('');
        self.Images = ko.observableArray();
        self.ActionImages = ko.observableArray();

        self.HospitalTypeID = ko.observable(0);
        self.HospitalCleanliness = ko.observable();
        self.HospitalType = ko.observable();
        self.AbsentTecherPercentage = ko.observable('');
        self.AbsentStudentPercentage = ko.observable('');
        self.WashroomCleanliness = ko.observable();
        self.GeneralCleanliness = ko.observable();
        self.DrinkWaterAvailable = ko.observable();
        self.ElectricityAvailable = ko.observable();
        self.SecurityArrangementAvailable = ko.observable();
        self.IsBoundaryWallIntact = ko.observable();

        self.Doctors = ko.observableArray();
        self.DoctorPosts = ko.observableArray();
        self.HospitalEquipments = ko.observableArray();
        self.MedicineTypes = ko.observableArray();
        self.CreatedBy = ko.observable(0);

        self.RamzanBazarModel = ko.observable(new RamzanBazarMonitoringModel(null));
    }

    self.uploadImage = function () {
        $("#fileUpload").click();
    };

    self.fileUploadChange = function () {
        var fr = new FileReader
        // when image is loaded, set the src of the image where you want to display it
        fr.onload = function (e) {
            var mod = {
                ImageTitle: $(".caption-input > h5").text(),
                ImageDescription: $(".caption-input > h5").text(),
                VisitorLogImage: this.result
            }
            self.Images.unshift(new ImageModel(mod));
            //self.Image(this.result);
        }

        fr.readAsDataURL($("#fileUpload").get(0).files[0]);

    };

    self.Apply = function () {
        var imgSrc = $("#webcam-image").attr('src');
        var title = $(".caption-input > h5").text();
        var mod = {
            ImageTitle: $(".caption-input > h5").text(),
            ImageDescription: $(".caption-input > h5").text(),
            VisitorLogImage: $("#webcam-image").attr('src')
        }
        self.ActionImages.unshift(new ImageModel(mod));

        $("#webcam-image").attr('src', '');
        $("#webcam-image").hide();
        $(".webcam-container").fadeIn("slow");
    };

    self.removeImage = function (mod) {
        self.ActionImages.remove(mod);
    };

    self.clearImage = function () {
        $("#webcam-image").attr('src', '');

        $("#webcam-image").hide();
        $(".webcam-container").fadeIn("slow");
        //// reload();
    }


    self.printLog = function (mod) {
        window.open('../Reports/ActionTakenPrintReport.aspx?taskID=' + GetQueryString("taskID"));
      
    };

    self.saveLog = function (mod) {
        if (confirm("Form shall now be upload on database by clicking OK, you may also edit by clicking CANCEL.")) {

            var contentHtml = $(".nicEdit-main").html().replace(doubleQoutesRegx, "");
            contentHtml = contentHtml.replace(commentRegex, "");
            contentHtml = contentHtml.replace(apostrophyRegx, "");
            mod.ActionRemarks(contentHtml);
            mod.Images([]);
            var taskID = GetQueryString("ID") || 0;

            $.ajax({
                url: "ActionDetail.aspx/Save",
                type: 'POST',
                dataType: "json",
                data: "{jsonModel : '" + ko.toJSON(mod) + "',visitorLogID :'" + taskID + "'}",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    toastr.success("Your action has been locked/uploaded successfully.");
                    $(".nicEdit-main").empty();
                    var taskid = taskID;

                    $.ajax({
                        url: "ActionDetail.aspx?ID=" + taskID + "",
                        type: "POST",
                        contentType: false,
                        processData: false,
                        data: function () {
                            // bind the control values to access in the server side
                            var data = new FormData();
                            data.append("TaskID", taskid);

                            var Item = $(".attach")[0].files[0];
                            data.append("chosenFile", Item);

                            return data;
                        }(),
                        error: function (_, textStatus, errorThrown) {
                        },
                        success: function (response, textStatus) {
                            toastr.success("Attachment uploaded successfully.");
                            window.location.href = "../../ContentPages/Dashboard/DashboardObservations.aspx";
                        }
                    });

                   
                    
                },
                error: function (request) {
                    console.log(request.responseText);
                }
            });
        }
    };
}

function CommonModel(data) {
    var self = this;
    self.ID = ko.observable(data.ID);
    self.Title = ko.observable(data.Title);
    self.Checked = ko.observable(data.Checked);
}

function ImageModel(img) {
    var self = this;
    self.ImageID = ko.observable(img.ImageID || 0);
    self.ImageTitle = ko.observable(img.ImageTitle);
    self.ImageDescription = ko.observable(img.ImageDescription);
    self.VisitorLogImage = ko.observable(img.VisitorLogImage);
}

function RamzanBazarMonitoringModel(item) {
    var self = this;
    if (item != null) {
        self.AttaQualityAvailablity = ko.observable(item.AttaQualityAvailablity != null ? item.AttaQualityAvailablity.toString() : null);
        self.AttaGreenColorBags = ko.observable(item.AttaGreenColorBags != null ? item.AttaGreenColorBags.toString() : null);
        self.MonitoringArrangements = ko.observable(item.MonitoringArrangements != null ? item.MonitoringArrangements.toString() : null);
        self.QueueManagement = ko.observable(item.QueueManagement != null ? item.QueueManagement.toString() : null);
        self.AttaRate = ko.observable(item.AttaRate != null ? item.AttaRate.toString() : null);
        self.SugarAvailablity = ko.observable(item.SugarAvailablity != null ? item.SugarAvailablity.toString() : null);
        self.SugarRate = ko.observable(item.SugarRate != null ? item.SugarRate.toString() : null);
        self.SugarPrintedBags = ko.observable(item.SugarPrintedBags != null ? item.SugarPrintedBags.toString() : null);
        self.SugarQueueManagement = ko.observable(item.SugarQueueManagement != null ? item.SugarQueueManagement.toString() : null);
        self.OilGheeAvailablity = ko.observable(item.OilGheeAvailablity != null ? item.OilGheeAvailablity.toString() : null);
        self.OilGheeDiscount = ko.observable(item.OilGheeDiscount != null ? item.OilGheeDiscount.toString() : null);
        self.OilGheeCategory = ko.observable(item.OilGheeCategory != null ? item.OilGheeCategory.toString() : null);
        self.PoultryChickenMeatAvailablity = ko.observable(item.PoultryChickenMeatAvailablity != null ? item.PoultryChickenMeatAvailablity.toString() : null);
        self.PoultryChickenEggsAvailablity = ko.observable(item.PoultryChickenEggsAvailablity != null ? item.PoultryChickenEggsAvailablity.toString() : null);
        self.PoultryChickenRateDiscount = ko.observable(item.PoultryChickenRateDiscount != null ? item.PoultryChickenRateDiscount.toString() : null);
        self.PoultryQueueManagement = ko.observable(item.PoultryQueueManagement != null ? item.PoultryQueueManagement.toString() : null);
        self.PoultryEggRateDiscount = ko.observable(item.PoultryEggRateDiscount != null ? item.PoultryEggRateDiscount.toString() : null);
        self.AgricultureFairPriceShop = ko.observable(item.AgricultureFairPriceShop != null ? item.AgricultureFairPriceShop.toString() : null);
        self.DisplayWholesalePrice = ko.observable(item.DisplayWholesalePrice != null ? item.DisplayWholesalePrice.toString() : null);

        self.SubsidizedItemsRates = ko.observableArray();
        self.WholeSaleItemsRates = ko.observableArray();

        self.ItemAvailablityNotifiedRates = ko.observable(item.ItemAvailablityNotifiedRates != null ? item.ItemAvailablityNotifiedRates.toString() : null);
        self.CheckingWeightAndMeasures = ko.observable(item.CheckingWeightAndMeasures != null ? item.CheckingWeightAndMeasures.toString() : null);
        self.TentageAvailability = ko.observable(item.TentageAvailability != null ? item.TentageAvailability.toString() : null);
        self.TentageCondition = ko.observable(item.TentageCondition != null ? item.TentageCondition.toString() : null);
        self.TentageStatusID = ko.observable(item.TentageStatusID != null ? item.TentageStatusID.toString() : null);
        self.FacilitaionSeatingArrangement = ko.observable(item.FacilitaionSeatingArrangement != null ? item.FacilitaionSeatingArrangement.toString() : null);
        self.FacilitaionOfFans = ko.observable(item.FacilitaionOfFans != null ? item.FacilitaionOfFans.toString() : null);
        self.FacilitaionOfToilets = ko.observable(item.FacilitaionOfToilets != null ? item.FacilitaionOfToilets.toString() : null);
        self.FacilitaionOfFirstAidService = ko.observable(item.FacilitaionOfFirstAidService != null ? item.FacilitaionOfFirstAidService.toString() : null);
        self.FacilitaionOfGuideTags = ko.observable(item.FacilitaionOfGuideTags != null ? item.FacilitaionOfGuideTags.toString() : null);
        self.LoudspeakerArrangements = ko.observable(item.LoudspeakerArrangements != null ? item.LoudspeakerArrangements.toString() : null);
        self.RevenueStaff = ko.observable(item.RevenueStaff != null ? item.RevenueStaff.toString() : null);
        self.AgriculturStaff = ko.observable(item.AgriculturStaff != null ? item.AgriculturStaff.toString() : null);
        self.HealthStaff = ko.observable(item.HealthStaff != null ? item.HealthStaff.toString() : null);
        self.LiveStockStaff = ko.observable(item.LiveStockStaff != null ? item.LiveStockStaff.toString() : null);
        self.WeightAndMeasureStaff = ko.observable(item.WeightAndMeasureStaff != null ? item.WeightAndMeasureStaff.toString() : null);
        self.AvailabilityFoodAuthority = ko.observable(item.AvailabilityFoodAuthority != null ? item.AvailabilityFoodAuthority.toString() : null);
        self.AvailabilityTMA = ko.observable(item.AvailabilityTMA != null ? item.AvailabilityTMA.toString() : null);
        self.AvailabilityCivilDefence = ko.observable(item.AvailabilityCivilDefence != null ? item.AvailabilityCivilDefence.toString() : null);
        self.DisplayRateList = ko.observable(item.DisplayRateList != null ? item.DisplayRateList.toString() : null);
        self.CleanlinessSanitaryStaff = ko.observable(item.CleanlinessSanitaryStaff != null ? item.CleanlinessSanitaryStaff.toString() : null);
        self.CleanlinessCondition = ko.observable(item.CleanlinessCondition != null ? item.CleanlinessCondition.toString() : null);
        self.CleanlinessWASA = ko.observable(item.CleanlinessWASA != null ? item.CleanlinessWASA.toString() : null);
        self.CompliantBanner = ko.observable(item.CompliantBanner != null ? item.CompliantBanner.toString() : null);
        self.CompliantRegister = ko.observable(item.CompliantRegister != null ? item.CompliantRegister.toString() : null);
        self.SecurityCondition = ko.observable(item.SecurityCondition != null ? item.SecurityCondition.toString() : null);
        self.SecurityPersonnel = ko.observable(item.SecurityPersonnel != null ? item.SecurityPersonnel.toString() : null);
        self.SecurityMetalDetectors = ko.observable(item.SecurityMetalDetectors != null ? item.SecurityMetalDetectors.toString() : null);
        self.SecurityTrafficControlStaff = ko.observable(item.SecurityTrafficControlStaff != null ? item.SecurityTrafficControlStaff.toString() : null);
        self.SecurityofWomen = ko.observable(item.SecurityofWomen != null ? item.SecurityofWomen.toString() : null);
        self.AdequateParkingArrangements = ko.observable(item.AdequateParkingArrangements != null ? item.AdequateParkingArrangements.toString() : null);
        self.AgricultureMarketingStaff = ko.observable(item.AgricultureMarketingStaff != null ? item.AgricultureMarketingStaff.toString() : null);
        self.VideoLinks = ko.observable(item.VideoLinks != null ? item.VideoLinks.toString() : null);
        self.DCOsVisitersRamzanBaar = ko.observable(item.DCOsVisitersRamzanBaar != null ? item.DCOsVisitersRamzanBaar.toString() : null);
        self.ParlianmentariansVisiters = ko.observable(item.ParlianmentariansVisiters != null ? item.ParlianmentariansVisiters.toString() : null);
        self.DistrictCommiteeMembersVisisters = ko.observable(item.DistrictCommiteeMembersVisisters != null ? item.DistrictCommiteeMembersVisisters.toString() : null);
        self.UtilityStoresCorporation = ko.observable(item.UtilityStoresCorporation != null ? item.UtilityStoresCorporation.toString() : null);
        self.AnyOter = ko.observable(item.AnyOter);

        if (item.SubsidizedItemsRates != null && item.SubsidizedItemsRates.length > 0) {
            ko.utils.arrayForEach(item.SubsidizedItemsRates, function (prov) {
                self.SubsidizedItemsRates.push(new RamzanBazarMonitoringItemModel(prov));
            });
        }

        if (item.WholeSaleItemsRates != null && item.WholeSaleItemsRates.length > 0) {
            ko.utils.arrayForEach(item.WholeSaleItemsRates, function (prov) {
                self.WholeSaleItemsRates.push(new RamzanBazarMonitoringItemModel(prov));
            });
        }
    }
    else {
        self.AttaQualityAvailablity = ko.observable();
        self.AttaGreenColorBags = ko.observable();
        self.MonitoringArrangements = ko.observable();
        self.QueueManagement = ko.observable();
        self.AttaRate = ko.observable();
        self.SugarAvailablity = ko.observable();
        self.SugarRate = ko.observable();
        self.SugarPrintedBags = ko.observable();
        self.SugarQueueManagement = ko.observable();
        self.OilGheeAvailablity = ko.observable();
        self.OilGheeDiscount = ko.observable();
        self.OilGheeCategory = ko.observable();
        self.PoultryChickenMeatAvailablity = ko.observable();
        self.PoultryChickenEggsAvailablity = ko.observable();
        self.PoultryChickenRateDiscount = ko.observable();
        self.PoultryQueueManagement = ko.observable();
        self.PoultryEggRateDiscount = ko.observable();
        self.AgricultureFairPriceShop = ko.observable();
        self.DisplayWholesalePrice = ko.observable();

        self.SubsidizedItemsRates = ko.observableArray();
        self.WholeSaleItemsRates = ko.observableArray();

        self.ItemAvailablityNotifiedRates = ko.observable();
        self.CheckingWeightAndMeasures = ko.observable();
        self.TentageAvailability = ko.observable();
        self.TentageCondition = ko.observable();
        self.TentageStatusID = ko.observable();
        self.FacilitaionSeatingArrangement = ko.observable();
        self.FacilitaionOfFans = ko.observable();
        self.FacilitaionOfToilets = ko.observable();
        self.FacilitaionOfFirstAidService = ko.observable();
        self.FacilitaionOfGuideTags = ko.observable();
        self.LoudspeakerArrangements = ko.observable();
        self.RevenueStaff = ko.observable();
        self.AgriculturStaff = ko.observable();
        self.HealthStaff = ko.observable();
        self.LiveStockStaff = ko.observable();
        self.WeightAndMeasureStaff = ko.observable();
        self.AvailabilityFoodAuthority = ko.observable();
        self.AvailabilityTMA = ko.observable();
        self.AvailabilityCivilDefence = ko.observable();
        self.DisplayRateList = ko.observable();
        self.CleanlinessSanitaryStaff = ko.observable();
        self.CleanlinessCondition = ko.observable();
        self.CleanlinessWASA = ko.observable();
        self.CompliantBanner = ko.observable();
        self.CompliantRegister = ko.observable();
        self.SecurityCondition = ko.observable();
        self.SecurityPersonnel = ko.observable();
        self.SecurityMetalDetectors = ko.observable();
        self.SecurityTrafficControlStaff = ko.observable();
        self.SecurityofWomen = ko.observable();
        self.AdequateParkingArrangements = ko.observable();
        self.AgricultureMarketingStaff = ko.observable();
        self.VideoLinks = ko.observable();
        self.DCOsVisitersRamzanBaar = ko.observable();
        self.ParlianmentariansVisiters = ko.observable();
        self.DistrictCommiteeMembersVisisters = ko.observable();
        self.UtilityStoresCorporation = ko.observable();
        self.AnyOter = ko.observable();
    }

}

function RamzanBazarMonitoringItemModel(item) {
    var self = this;
    if (item != null) {
        self.Availabitliy = ko.observable(item.Availabitliy != null ? item.Availabitliy.toString() : null);
        self.ConditionID = ko.observable(item.ConditionID != null ? item.ConditionID.toString() : null);
        self.Rates = ko.observable(item.Rates != null ? item.Rates.toString() : null);
        self.Remarks = ko.observable(item.Remarks != null ? item.Remarks.toString() : null);
        self.ItemTitle = ko.observable(item.ItemTitle != null ? item.ItemTitle.toString() : null);
    }
    else {
        self.Availabitliy = ko.observable();
        self.ConditionID = ko.observable();
        self.Rates = ko.observable();
        self.Remarks = ko.observable();
        self.ItemTitle = ko.observable();
    }

}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
   // $('#rootwizard').bootstrapWizard();
    
    var nicEditConfig = {
        buttonList: ['save', 'bold', 'italic', 'underline', 'left', 'center', 'right', 'justify', 'ol', 'ul', 'fontSize', 'fontFamily', 'fontFormat', 'forecolor'], iconsPath: '../../images/nicEditorIcons.gif'
    };

    bkLib.onDomLoaded(function () { new nicEditor(nicEditConfig).panelInstance('area2'); });

    var taskID = GetQueryString("ID");
    LoadRecord(taskID);
    ko.applyBindings(viewModel);

});

    function LoadRecord(taskID) {
        $.ajax({
            url: "ActionDetail.aspx/GetAssignTaskDetail",
            type: 'POST',
            dataType: "json",
            data: "{visitorLogID : '" + taskID + "'}",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                viewModel.main(new VisitDetailModel(data.d));
            },
            error: function (request) {
                console.log(request.responseText);
            }
        });
    }


    function GetQueryString(key) {
        var value = "";
        var PageURL = decodeURIComponent(window.location.search.substring(1));
        var sURLVariables = PageURL.split('&');

        for (var i = 0; i < sURLVariables.length; i++) {
            var sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0].toLowerCase() == key.toLowerCase()) {
                value = sParameterName[1];
            }
        }
        return value;
    }


