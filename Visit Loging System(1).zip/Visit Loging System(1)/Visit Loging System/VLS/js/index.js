﻿
var google;
var apostrophyRegx = new RegExp("'", "g");
var doubleQoutesRegx = new RegExp("\"", "g");
var commentRegex = new RegExp(
    '<!--[\\s\\S]*?(?:-->)?'
    + '<!---+>?'  // A comment with no body
    + '|<!(?![dD][oO][cC][tT][yY][pP][eE]|\\[CDATA\\[)[^>]*>?'
    + '|<[?][^>]*>?',  // A pseudo-comment
    'g');
var ref_provinces = [];
var ref_districts = [];
var ref_divisions = [];
var ref_tehsils = [];
var ref_unioncouncils = []; 
var ref_constituencies = [];
var ref_constituenciesNA = [];
var ref_SubsidizedItemsRates = [];
var ref_WholeSaleItemsRates = [];
var geomod = {};
var YesNo = [{ Title: 'Yes', Value: true }, { Title: 'No', Value: false }];
var TentageStatuses = [{ Title: 'Purchased', Value: 1 }, { Title: 'Rental', Value: 2 }];
/* INIT: All plugins initialization(s) */
var ratings = [{ 'Title': 'Very Poor', 'Value': 1 },
              { 'Title': 'Poor', 'Value': 2 },
              { 'Title': 'Un-satisfactory', 'Value': 3 },
              { 'Title': 'Average', 'Value': 4 },
              { 'Title': 'Satisfactory', 'Value': 5 },
              { 'Title': 'Good', 'Value': 6 },
              { 'Title': 'Excellent', 'Value': 7 }];

(function () {
    if (google != undefined && !!navigator.geolocation) {
        var map;
        var mapOptions = {
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        map = new google.maps.Map(document.getElementById('map'), mapOptions);

        var infowindow = new google.maps.InfoWindow({
            content: '<b>Now i am here</b>'
        });

        navigator.geolocation.getCurrentPosition(function (position) {
            var geolocate = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
            geomod.Latitude = position.coords.latitude;
            geomod.Longitude = position.coords.longitude;
            var myMarker = new google.maps.Marker({
                position: { lat: position.coords.latitude, lng: position.coords.longitude },
                draggable: false
            });
            map.setCenter(geolocate);
            myMarker.setMap(map);
            infowindow.open(map, myMarker);

        });

    } else {
        document.getElementById('map').innerHTML = 'No Geolocation Support.';
    }
})();

$(document).ready(function () {

    $('#rootwizard').bootstrapWizard();
    $("#webcam-image").hide();


    var nicEditConfig = {
        buttonList: ['save', 'bold', 'italic', 'underline', 'left', 'center', 'right', 'justify', 'ol', 'ul', 'fontSize', 'fontFamily', 'fontFormat', 'forecolor']
    };

    bkLib.onDomLoaded(function () { new nicEditor(nicEditConfig).panelInstance('area1'); });



    /*Camera init*/
    initCam();

    ////$(".btn-file-upload").click(function () {
    ////    $("#fileUpload").click();
    ////});

    ////$("#fileUpload").change(function () {
    ////    var fr = new FileReader
    ////    // when image is loaded, set the src of the image where you want to display it
    ////    fr.onload = function (e) {
    ////        $(".webcam-container").hide();
    ////        $("#webcam-image").fadeIn("slow");
    ////        $("#webcam-image").attr('src', this.result);
    ////    }

    ////    fr.readAsDataURL($("#fileUpload").get(0).files[0]);
    ////});

    ////$(".btn-apply").click(function () {
    ////    var imgSrc = $("#webcam-image").attr('src');
    ////    var title = $(".caption-input > h5").text();
    ////    var html = "<li class=\"col-lg-4 col-sm-6 col-md-4\">" +
    ////               "<div class=\"thumbnail\">" +
    ////               "<img alt=\"100%x200\" data-src=\"holder.js/100%x200\" style=\"height: 200px; width: 100%; display: block;\" src=\"" + imgSrc + "\" data-holder-rendered=\"true\">" +
    ////               "<div class=\"caption\"> <h5>" + title + "</h5> <p>There is no description entered agianst this post.</p>" +
    ////               "<p><div class=\"btn-group\" role=\"group\">" +
    ////               "<a role=\"button\" class=\"btn btn-xs btn-info\" href=\"#\"><i class=\"fa fa-search\"></i>&nbsp;View</a>" +
    ////               "<a role=\"button\" class=\"btn btn-xs btn-danger btn-remove-image\" href=\"#\"><i class=\"fa fa-times\"></i>&nbsp;Delete</a></div></p></div></div></li>";
    ////    $(".image-gallery > ul").append(html);

    ////    $("#webcam-image").attr('src', '');
    ////    $("#webcam-image").hide();
    ////    $(".webcam-container").fadeIn("slow");
    ////});

    ////$(document).on('click', '.btn-remove-image', function () {
    ////    $(this).parent().parent().parent().parent().remove();
    ////});

    $('form').validationEngine({ promptPostion: 'bottomLeft' });
    $('.btn-prev, .btn-next').on('click', function () {

        return $('form').validationEngine('validate');
    });

    LoadRecord();
    ko.applyBindings(viewModel);



});

function initCam() {
    $("#webcam").webcam({
        swffile: "js/camify/sAS3Cam.swf?v=" + Math.random(),

        previewWidth: 240,
        previewHeight: 200,

        resolutionWidth: 320,
        resolutionHeight: 240,

        /**
         * Determine if we need to stretch or scale the captured stream
         *
         * @see http://help.ado com/en_US/FlashPlatform/reference/actionscript/3/flash/display/Stage.html#scaleMode
         * @see http://help.ado com/en_US/FlashPlatform/reference/actionscript/3/flash/display/StageScaleMode.html
         */
        StageScaleMode: 'noScale', //

        /**
         * Aligns video output on stage
         *
         * @see http://help.ado com/en_US/FlashPlatform/reference/actionscript/3/flash/display/StageAlign.html
         * @see http://help.ado com/en_US/FlashPlatform/reference/actionscript/3/flash/display/Stage.html#align
         * Empty value defaults to "centered" option
         */
        StageAlign: 'TL',

        noCameraFound: function () {
            this.debug('error', 'Web camera is not available');
        },

        swfApiFail: function (e) {
            this.debug('error', 'Internal camera plugin error');
        },

        cameraDisabled: function () {
            this.debug('error', 'Please allow access to your camera');
        },

        debug: function (type, string) {
            if (type == 'error') {
                $(".webcam-error").html(string);
            } else {
                $(".webcam-error").html('');
            }
        },

        cameraEnabled: function () {
            this.debug('notice', 'Camera enabled');
            var cameraApi = this;
            if (cameraApi.isCameraEnabled) {
                return;
            } else {
                cameraApi.isCameraEnabled = true;
            }
            var cams = cameraApi.getCameraList();

            for (var i in cams) {
                $("#popup-webcam-cams").append("<option value='" + i + "'>" + cams[i] + "</option>");
            }

            setTimeout(function () {
                $("#popup-webcam-take-photo").removeAttr('disabled');
                $("#popup-webcam-take-photo").show();
                cameraApi.setCamera('0');
            }, 750);

            $("#popup-webcam-cams").change(function () {
                var success = cameraApi.setCamera($(this).val());
                if (!success) {
                    cameraApi.debug('error', 'Unable to select camera');
                } else {
                    cameraApi.debug('notice', 'Camera changed');
                }
            });

            $('#popup-webcam-take-photo').click(function () {
                var result = cameraApi.save();
                if (result && result.length) {
                    var actualShotResolution = cameraApi.getResolution();

                    // var img = new Image();
                    //img.src = 'data:image/jpeg;base64,' + result;
                    var src = 'data:image/jpeg;base64,' + result;
                    $("#webcam-image").attr('src', src);


                    $(".webcam-container").hide();
                    $("#webcam-image").fadeIn("slow");

                    // alert('base64encoded jpeg (' + actualShotResolution[0] + 'x' + actualShotResolution[1] + '): ' + result.length + 'chars');

                    /* resume camera capture */
                    //// cameraApi.setCamera($("#popup-webcam-cams").val());
                } else {
                    cameraApi.debug('error', 'Broken camera');
                }
            });


            var reload = function () {
                $('#popup-webcam-take-photo').show();
            };

            $('#popup-webcam-save').click(function () {
                reload();
            });

            $('#popup-webcam-clear').click(function () {
                $("#webcam-image").attr('src', '');

                $("#webcam-image").hide();
                $(".webcam-container").fadeIn("slow");
                reload();
            });
        }
    });
}
/* END INIT: All plugins initialization(s) */

var viewModel = new ViewModel();


ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        //ko.utils.registerEventHandler(element, "blur", function () {
        //    $(element).validationEngine('validate');
        //});

        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

ko.bindingHandlers.nicedit = {
    init: function (element, valueAccessor) {
        var value = valueAccessor();
        var area = new nicEditor({ fullPanel: true }).panelInstance(element.id, { hasPanel: true });
        $(element).text(ko.utils.unwrapObservable(value));

        // function for updating the right element whenever something changes
        var textAreaContentElement = $($(element).prev()[0].childNodes[0]);
        var areachangefc = function () {
            value(textAreaContentElement.html());
        };

        // Make sure we update on both a text change, and when some HTML has been added/removed
        // (like for example a text being set to "bold")
        $(element).prev().keyup(areachangefc);
        $(element).prev().bind('DOMNodeInserted DOMNodeRemoved', areachangefc);
    },
    update: function (element, valueAccessor) {
        var value = valueAccessor();
        var textAreaContentElement = $($(element).prev()[0].childNodes[0]);
        textAreaContentElement.html(value());
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {},
            $el = $(element);

        $el.datepicker(options);

        //handle the field changing by registering datepicker's changeDate event
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });

        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });

    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
            $el = $(element);

        //handle date data coming via json from Microsoft
        if (String(value).indexOf('/Date(') == 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }

        var current = $el.datepicker("getDate");

        if (value - current !== 0) {
            $el.datepicker("setDate", value);
        }
    }
};


//** TimePicker Custom binding **\\
ko.bindingHandlers.timeValue = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel, bindingContext) {
        var tpicker = $(element).timepicker();
        tpicker.on('changeTime.timepicker', function (e) {

            //Asignar la hora y los minutos
            var value = valueAccessor();
            if (!value) {
                throw new Error('timeValue binding observable not found');
            }
            var date = ko.unwrap(value);
            var mdate = moment(date || new Date());
            var hours24;
            if (e.time.meridian == "AM") {
                if (e.time.hours == 12)
                    hours24 = 0;
                else
                    hours24 = e.time.hours;
            }
            else {
                if (e.time.hours == 12) {
                    hours24 = 12;
                }
                else {
                    hours24 = e.time.hours + 12;
                }
            }

            mdate.hours(hours24)
            mdate.minutes(e.time.minutes);
            $(element).data('updating', true);
            value(mdate.toDate());
            $(element).data('updating', false);


        })
    },
    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
        //Avoid recursive calls
        if ($(element).data('updating')) {
            return;
        }
        var date = ko.unwrap(valueAccessor()) || new Date();

        if (date) {
            var time = moment(date).format("hh:mmA");
            //var matches = time.match(/(\d{1,2}):(\d{2})/);
            //var zone = parseInt(matches[0]) >= 12 ? 'PM' : 'AM';
            //time = matches[1] + ':' + matches[2] + ' ' + zone;
            $(element).timepicker('setTime', time);
        }
        else {
            // $(element).timepicker('clear');
        }
    }
};


ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};


function WrapperModel(items) {
    var self = this;


    self.editModel = ko.observable(new VisitDetailModel(null));

    self.Provinces = ko.observableArray();
    self.Divisions = ko.observableArray();
    self.Districts = ko.observableArray();
    self.Tehsils = ko.observableArray();
    self.UnionCouncils = ko.observableArray();
    self.Cities = ko.observableArray();
    self.Constituencies = ko.observableArray();
    self.NAConstituencies = ko.observableArray();
    self.PlaceCategories = ko.observableArray();
    self.Departments = ko.observableArray();
    self.HospitalTypes = ko.observableArray();

    self.Conditions = ko.observableArray();

    self.Images = ko.observableArray();

    if (items != null) {
        if (items.visit != null)
            self.editModel = ko.observable(new VisitDetailModel(items.visit));


        if (items.Conditions != null) {
            ko.utils.arrayForEach(items.Conditions, function (prov) {
                self.Conditions.push(new CommonModel(prov));
            });
        }

        if (items.VisitoryImages != null) {
            ko.utils.arrayForEach(items.VisitoryImages, function (prov) {
                self.Images.push(new ImageModel(prov));
            });
        }

        if (items.visit.RamzanBazarModel.SubsidizedItemsRates != null) {
            ref_SubsidizedItemsRates = [];
            self.editModel().RamzanBazarModel().SubsidizedItemsRates([]);
            ko.utils.arrayForEach(items.visit.RamzanBazarModel.SubsidizedItemsRates, function (prov) {
                self.editModel().RamzanBazarModel().SubsidizedItemsRates.push(new RamzanBazarMonitoringItemModel(prov));
                ref_SubsidizedItemsRates.push(new RamzanBazarMonitoringItemModel(prov));
            });
        }

        if (items.visit.RamzanBazarModel.WholeSaleItemsRates != null) {
            ref_WholeSaleItemsRates = [];
            self.editModel().RamzanBazarModel().WholeSaleItemsRates([]);
            ko.utils.arrayForEach(items.visit.RamzanBazarModel.WholeSaleItemsRates, function (prov) {
                self.editModel().RamzanBazarModel().WholeSaleItemsRates.push(new RamzanBazarMonitoringItemModel(prov));
                ref_WholeSaleItemsRates.push(new RamzanBazarMonitoringItemModel(prov));
            });
        }


        if (items.visit.DoctorPosts != null) {
            ko.utils.arrayForEach(items.visit.DoctorPosts, function (prov) {
                self.editModel().Doctors.push(new ChecklistModel(prov));
            });
        }

        if (items.visit.DoctorPosts != null) {
            ko.utils.arrayForEach(items.visit.DoctorPosts, function (prov) {
                self.editModel().DoctorPosts.push(new ChecklistModel(prov));
            });
        }

        if (items.visit.HospitalEquipments != null) {
            ko.utils.arrayForEach(items.visit.HospitalEquipments, function (prov) {
                self.editModel().HospitalEquipments.push(new ChecklistModel(prov));
            });
        }

        if (items.visit.MedicineTypes != null) {
            ko.utils.arrayForEach(items.visit.MedicineTypes, function (prov) {
                self.editModel().MedicineTypes.push(new ChecklistModel(prov));
            });
        }

        if (items.HospitalTypes != null) {
            ko.utils.arrayForEach(items.HospitalTypes, function (prov) {
                self.HospitalTypes.push(new CommonModel(prov));
            });
        }

        if (items.Provinces != null) {
            ko.utils.arrayForEach(items.Provinces, function (prov) {
                self.Provinces.push(new CommonModel(prov));
                ref_provinces.push(new CommonModel(prov));
            });
        }
        if (items.Divisions != null) {
            ko.utils.arrayForEach(items.Divisions, function (prov) {
                self.Divisions.push(new DivisionModel(prov));

            });
        }
        if (items.Districts != null) {
            ko.utils.arrayForEach(items.Districts, function (prov) {
                ref_districts.push(new CommonModel(prov));
            });
        }
        if (items.Tehsils != null) {
            ko.utils.arrayForEach(items.Tehsils, function (prov) {
                ref_tehsils.push(new CommonModel(prov));
            });
        }
        if (items.UnionCouncils != null) {
            ko.utils.arrayForEach(items.UnionCouncils, function (prov) {
                ref_unioncouncils.push(new CommonModel(prov));
            });
        }
        if (items.Constituencies != null) {
            ko.utils.arrayForEach(items.Constituencies, function (prov) {
                ref_constituencies.push(new CommonModel(prov));
                // self.Constituencies.push(new CommonModel(prov));
            });
        }
        if (items.NAConstituencies != null) {
            ko.utils.arrayForEach(items.NAConstituencies, function (prov) {
                ref_constituenciesNA.push(new CommonModel(prov));
                // self.Constituencies.push(new CommonModel(prov));
            });
        }
        if (items.PlaceCategories != null) {
            ko.utils.arrayForEach(items.PlaceCategories, function (prov) {
                self.PlaceCategories.push(new CommonModel(prov));
            });
        }
        if (items.Departments != null) {
            ko.utils.arrayForEach(items.Departments, function (prov) {
                self.Departments.push(new CommonModel(prov));
            });
        }

        //var geomod = {};
        //navigator.geolocation.getCurrentPosition(function (position) {
        //    geomod.Latitude = position.coords.latitude;
        //    geomod.Longitude = position.coords.longitude;
        //});
        if (geomod != null) {
            self.editModel().Latitude(geomod.Latitude || 0.0);
            self.editModel().Longitude(geomod.Longitude || 0.0);
        }
        //self.editModel().Rating(13.37);
        
    }
    else {
        self.Divisions(ref_divisions);
        self.Provinces(ref_provinces);
    }


    self.closeEducationPop = function () {
        if (validateEducationPopup()) {
            $("#modalEducation").modal('hide');
        }
    }

    self.closeHospitalPop = function () {

        if (validateHealthPopup()) {
            $("#modalHospital").modal('hide');
        }
    };

    self.cancelEducationPop = function () {
        clearEducationFeilds(self);
        $("#modalEducation").modal('hide');
    };

    self.cancelHospitalPop = function () {
        clearHealthFeilds(self);
        $("#modalHospital").modal('hide');
    };

    self.clearEducationPop = function () {
        clearEducationFeilds(self);
    };

    self.clearHospitalPop = function () {
        clearHealthFeilds(self);
    };

    self.clearRamzanPop = function () {
        clearRamzanFeilds(self);
    };

    self.cancelRamzanPop = function () {
        $("#modalRamzan").modal('hide');
        clearRamzanFeilds(self);
    };

    self.closeRamzanPop = function () {
        // if (validateRamzanPopup()) {
        $("#modalRamzan").modal('hide');
        // }
    };
}

function validatePopupFeilds(self) {
    ret = true;
    if (self.DepartmentID() == 15 || self.DepartmentID() == 32 || self.DepartmentID() == 35) {
        ret = validateEducationPopup();
    }
    else if (self.DepartmentID() == 14 || self.DepartmentID() == 41) {
        ret = validateHealthPopup();
    }
    return ret;
}

function validateHealthPopup() {
    if (viewModel.main().editModel().HospitalTypeID() != undefined &&
            $("#modalHospital input[type=checkbox]:checked").length > 0) {
        return true;
    }
    else {
        $("#modalHospital").modal('show');
        toastr.error('Please enter some feedback');
        return false;
    }
}

function validateEducationPopup() {
    if (viewModel.main().editModel().WashroomCleanliness() != undefined &&
             viewModel.main().editModel().GeneralCleanliness() != undefined &&
             viewModel.main().editModel().DrinkWaterAvailable() != undefined &&
             viewModel.main().editModel().ElectricityAvailable() != undefined &&
             viewModel.main().editModel().SecurityArrangementAvailable() != undefined &&
             viewModel.main().editModel().IsBoundaryWallIntact() != undefined) {
        return true;
    }
    else {
        $("#modalEducation").modal('show');
        toastr.error('Please enter some feedback');
        return false;
    }
}

function clearHealthFeilds(self) {
    self.editModel().HospitalCleanliness(null);
    self.editModel().HospitalTypeID(null);

    if (self.editModel().Doctors() != undefined && self.editModel().Doctors() != null && self.editModel().Doctors() != '') {
        ko.utils.arrayForEach(self.editModel().Doctors(), function (itm) {
            itm.Checked(false);
        });
    }
    if (self.editModel().DoctorPosts() != undefined && self.editModel().DoctorPosts() != null && self.editModel().DoctorPosts() != '') {
        ko.utils.arrayForEach(self.editModel().DoctorPosts(), function (itm) {
            itm.Checked(false);
        });
    }
    if (self.editModel().MedicineTypes() != undefined && self.editModel().MedicineTypes() != null && self.editModel().MedicineTypes() != '') {
        ko.utils.arrayForEach(self.editModel().MedicineTypes(), function (itm) {
            itm.Checked(false);
        });
    }
    if (self.editModel().HospitalEquipments() != undefined && self.editModel().HospitalEquipments() != null && self.editModel().HospitalEquipments() != '') {
        ko.utils.arrayForEach(self.editModel().HospitalEquipments(), function (itm) {
            itm.Checked(false);
        });
    }
}

function clearEducationFeilds(self) {
    self.editModel().AbsentTecherPercentage(null);
    self.editModel().AbsentStudentPercentage(null);
    self.editModel().WashroomCleanliness(null);
    self.editModel().GeneralCleanliness(null);
    self.editModel().DrinkWaterAvailable(null);
    self.editModel().ElectricityAvailable(null);
    self.editModel().SecurityArrangementAvailable(null);
    self.editModel().IsBoundaryWallIntact(null);
}

function clearRamzanFeilds(self) {
    var mod = new RamzanBazarMonitoringModel(null);
    mod.SubsidizedItemsRates(ref_SubsidizedItemsRates);
    mod.WholeSaleItemsRates(ref_WholeSaleItemsRates);
    self.editModel().RamzanBazarModel(mod);
}

function VisitDetailModel(visit) {
    var self = this;
    if (visit != null) {
        self.VisitorLogID = ko.observable(visit.VisitorLogID);
        self.ProvinceID = ko.observable(visit.ProvinceID);
        self.DivisionID = ko.observable(visit.DivisionID);
        self.DistrictID = ko.observable(visit.DistrictID);
        self.CityID = ko.observable(visit.CityID);
        self.TehsilID = ko.observable(visit.TehsilID);
        self.UnionCouncilID = ko.observable(visit.UnionCouncilID);
        self.ConstituencyID = ko.observable(visit.ConstituencyID);
        self.NAConstituencyID = ko.observable(visit.NAConstituencyID);
        self.DepartmentID = ko.observable(visit.DepartmentID);
        self.MarkedTo = ko.observable(visit.MarkedTo);
        self.PlaceCategoryID = ko.observable(visit.PlaceCategoryID);
        self.Place = ko.observable(visit.Place);
        self.VisitStartDate = ko.observable(ko.utils.unwrapObservable(visit.VisitStartDate) != null ? parseInt(ko.utils.unwrapObservable(visit.VisitStartDate).toString().substring(6, 19)) > 0 ? new Date(parseInt(ko.utils.unwrapObservable(visit.VisitStartDate).toString().substring(6, 19))) : '' : '');
        self.VisitStartTime = ko.observable(visit.VisitStartTime);
        self.VisitEndTime = ko.observable(visit.VisitEndTime);
        self.VisitEndDate = ko.observable(ko.utils.unwrapObservable(visit.VisitEndDate) != null ? parseInt(ko.utils.unwrapObservable(visit.VisitEndDate).toString().substring(6, 19)) > 0 ? new Date(parseInt(ko.utils.unwrapObservable(visit.VisitEndDate).toString().substring(6, 19))) : '' : '');
        self.Department = ko.observable(visit.Department);
        self.VisitAgenda = ko.observable(visit.VisitAgenda);
        self.Feedback = ko.observable(visit.Feedback);
        self.Rating = ko.observable(visit.Rating);
        self.Latitude = ko.observable(visit.Latitude);
        self.Longitude = ko.observable(visit.Longitude);

        self.HospitalTypeID = ko.observable(visit.HospitalTypeID);
        self.HospitalCleanliness = ko.observable(visit.HospitalCleanliness != null ? visit.HospitalCleanliness.toString() : visit.HospitalCleanliness);

        self.AbsentTecherPercentage = ko.observable(visit.AbsentTecherPercentage);
        self.AbsentStudentPercentage = ko.observable(visit.AbsentStudentPercentage);
        self.WashroomCleanliness = ko.observable(visit.WashroomCleanliness != null ? visit.WashroomCleanliness.toString() : visit.WashroomCleanliness);
        self.GeneralCleanliness = ko.observable(visit.GeneralCleanliness != null ? visit.GeneralCleanliness.toString() : visit.GeneralCleanliness);
        self.DrinkWaterAvailable = ko.observable(visit.DrinkWaterAvailable != null ? visit.DrinkWaterAvailable.toString() : visit.DrinkWaterAvailable);
        self.ElectricityAvailable = ko.observable(visit.ElectricityAvailable != null ? visit.ElectricityAvailable.toString() : visit.ElectricityAvailable);
        self.SecurityArrangementAvailable = ko.observable(visit.SecurityArrangementAvailable != null ? visit.SecurityArrangementAvailable.toString() : visit.SecurityArrangementAvailable);
        self.IsBoundaryWallIntact = ko.observable(visit.IsBoundaryWallIntact != null ? visit.IsBoundaryWallIntact.toString() : visit.IsBoundaryWallIntact);


        self.Doctors = ko.observableArray();
        self.DoctorPosts = ko.observableArray();
        self.HospitalEquipments = ko.observableArray();
        self.MedicineTypes = ko.observableArray();

        self.RamzanBazarModel = ko.observable(new RamzanBazarMonitoringModel(visit.RamzanBazarModel));


    }
    else {
        self.VisitorLogID = ko.observable();
        self.ProvinceID = ko.observable(0);
        self.DivisionID = ko.observable(0);
        self.DistrictID = ko.observable(0);
        self.CityID = ko.observable(0);
        self.TehsilID = ko.observable(0);
        self.UnionCouncilID = ko.observable(0);
        self.ConstituencyID = ko.observable(0);
        self.NAConstituencyID = ko.observable(0);
        self.MarkedTo = ko.observable(0);
        self.PlaceCategoryID = ko.observable(0);
        self.DepartmentID = ko.observable(0);
        self.Place = ko.observable();
        self.VisitStartDate = ko.observable(new Date());
        self.VisitStartTime = ko.observable('');
        self.VisitEndTime = ko.observable('');
        self.VisitEndDate = ko.observable(new Date());
        self.Department = ko.observable('');
        self.VisitAgenda = ko.observable();
        self.Feedback = ko.observable('');
        self.Rating = ko.observable('');
        self.Latitude = ko.observable(0.0);
        self.Longitude = ko.observable(0.0);

        self.HospitalTypeID = ko.observable(0);
        self.HospitalCleanliness = ko.observable();

        self.AbsentTecherPercentage = ko.observable(null);
        self.AbsentStudentPercentage = ko.observable(null);
        self.WashroomCleanliness = ko.observable();
        self.GeneralCleanliness = ko.observable();
        self.DrinkWaterAvailable = ko.observable();
        self.ElectricityAvailable = ko.observable();
        self.SecurityArrangementAvailable = ko.observable();
        self.IsBoundaryWallIntact = ko.observable();

        self.Doctors = ko.observableArray();
        self.DoctorPosts = ko.observableArray();
        self.HospitalEquipments = ko.observableArray();
        self.MedicineTypes = ko.observableArray();

        self.RamzanBazarModel = ko.observable(new RamzanBazarMonitoringModel(null));
    }

    self.uploadImage = function () {
        $("#fileUpload").click();
    };

    self.fileUploadChange = function () {
        var fr = new FileReader
        // when image is loaded, set the src of the image where you want to display it
        fr.onload = function (e) {
            $(".webcam-container").hide();
            $("#webcam-image").fadeIn("slow");
            $("#webcam-image").attr('src', this.result);
            //self.Image(this.result);
        }

        fr.readAsDataURL($("#fileUpload").get(0).files[0]);

    };

    self.Apply = function () {
        if ($("#webcam-image").attr('src') != '') {
            var imgSrc = $("#webcam-image").attr('src');
            var title = $(".caption-input > .title").text();


            var png = $("#webcam-image").attr('src').split(',')[1];
            //var the_file = new Blob([window.atob(png)], { type: 'image/png', encoding: 'utf-8' });

            var mod = {
                ImageTitle: $(".caption-input > .title").val(),
                ImageDescription: $(".caption-input > .desc").val(),
                VisitorLogImage: $("#webcam-image").attr('src'),
                ContentType: $("#fileUpload").get(0).files[0] != null ? $("#fileUpload").get(0).files[0].type : 'image/jpeg'
                //ImageObject: $("#fileUpload").get(0).files[0]
            }
            viewModel.main().Images.unshift(new ImageModel(mod));

            $(".caption-input > .title").val('');
            $(".caption-input > .desc").val('');
            $("#webcam-image").attr('src', '');
            $("#webcam-image").hide();
            $(".webcam-container").fadeIn("slow");
            $("#fileUpload").replaceWith($("#fileUpload").val('').clone(true));
            initCam();
        }
    };

    self.removeImage = function (mod) {
        if (mod.ImageID() != null && mod.ImageID() != '' && mod.ImageID() != undefined) {
            $.ajax({
                url: "index.aspx/RemoveImage",
                type: 'POST',
                data: "{imageID : '" + mod.ImageID() + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    toastr.success('Image has been removed successfully.');
                    viewModel.main().Images.remove(mod);
                },
                error: function () {
                }
            });
        
        }
        else {
            viewModel.main().Images.remove(mod);
        }
    };

    self.clearImage = function (e) {
        $("#webcam-image").attr('src', '');

        $("#webcam-image").hide();
        $(".webcam-container").fadeIn("slow");
        $("#fileUpload").replaceWith($("#fileUpload").val('').clone(true));
        initCam();
    }

    self.saveLog = function (mod) {
        if (geomod != null) {
            mod.Latitude(geomod.Latitude || 0.0);
            mod.Longitude(geomod.Longitude || 0.0);
        }

        if ($('form').validationEngine('validate') && validatePopupFeilds(mod)) {
            if ($(".nicEdit-main").text().length > 0) {
                if (confirm("Form shall now be upload database, you may edit by clicking cancel.")) {
                    $('#overlay').show();
                    var contentHtml = $(".nicEdit-main").html().replace(doubleQoutesRegx, "");
                    contentHtml = contentHtml.replace(commentRegex, "");
                    contentHtml = contentHtml.replace(apostrophyRegx, "");
                    mod.Feedback(contentHtml);

                    $.ajax({
                        url: "index.aspx/Save",
                        type: 'POST',
                        dataType: "json",
                        data: "{jsonModel : '" + ko.toJSON(mod) + "'}",
                        contentType: "application/json; charset=utf-8",
                        success: function (data) {
                            if (data.d.Notification.indexOf("error") < 0) {
                                var visitLogID = data.d.VisitorLogID || 0;
                                $.ajax({
                                    url: "index.aspx",
                                    type: "POST",
                                    contentType: false,
                                    processData: false,
                                    data: function () {
                                        // bind the control values to access in the server side
                                        var data = new FormData();
                                        var index = 0;
                                        data.append("VisitLogID", visitLogID);
                                        data.append("ImageCount", viewModel.main().Images().length);
                                        for (var i = 0; i < viewModel.main().Images().length; i++) {
                                            if (viewModel.main().Images()[i].ImageID() == null || viewModel.main().Images()[i].ImageID() == '' || viewModel.main().Images()[i].ImageID() == undefined || viewModel.main().Images()[i].ImageID() == 0) {


                                                data.append("Title" + index, viewModel.main().Images()[i].ImageTitle());
                                                data.append("ImageDescription" + index, viewModel.main().Images()[i].ImageDescription());
                                                data.append("VisitorLogImage" + index, viewModel.main().Images()[i].VisitorLogImage());
                                                data.append("ContentType" + index, viewModel.main().Images()[i].ContentType());
                                                //var Item = viewModel.main().Images()[i].ImageObject();
                                                //    data.append("chosenFile", Item);
                                                index++;
                                            }
                                        }
                                        return data;
                                    }(),
                                    error: function (_, textStatus, errorThrown) {
                                    },
                                    success: function (response, textStatus) {
                                        toastr.success("Your field visit has been locked/uploaded successfully.");
                                        $(".nicEdit-main").empty();
                                        viewModel.main(new WrapperModel(null));
                                        $('.nav-tabs a[href="#tab1"]').tab('show');
                                        viewModel.main().editModel().ProvinceID(1);
                                        //LoadRecord();
                                        $('#overlay').hide();
                                        window.location.href = "../ContentPages/Site/Home.aspx";
                                    }
                                });
                            }
                            else {
                                toastr.error(data.d.Notification);
                                $('#overlay').hide();
                            }
                        },
                        error: function (request) {
                            alert(request.responseText);
                        }
                    });
                }
            }
            else {
                toastr.error("Please enter Feedback / Observations.");
            }
        }
    };


    self.getDistricts = function () {
        viewModel.main().Districts([]);
        viewModel.main().Tehsils([]);
        viewModel.main().UnionCouncils([]);
        viewModel.main().Constituencies([]);
        var filter_district = ko.utils.arrayFilter(ref_districts, function (div) {
            return ko.utils.unwrapObservable(div.DivisionID()) == ko.utils.unwrapObservable(self.DivisionID);
        });
        viewModel.main().Districts(filter_district);
    };

    self.getTehsils = function () {
        viewModel.main().Tehsils([]);
        viewModel.main().UnionCouncils([]);
        var filter_tehsils = ko.utils.arrayFilter(ref_tehsils, function (teh) {
            return ko.utils.unwrapObservable(teh.DistrictID()) == ko.utils.unwrapObservable(self.DistrictID);
        });
        viewModel.main().Tehsils(filter_tehsils);

        var filter_constituencies = ko.utils.arrayFilter(ref_constituencies, function (con) {
            return ko.utils.unwrapObservable(con.DistrictID()) == ko.utils.unwrapObservable(self.DistrictID);
        });
        viewModel.main().Constituencies(filter_constituencies);

        var filter_constituenciesNA = ko.utils.arrayFilter(ref_constituenciesNA, function (con) {
            return ko.utils.unwrapObservable(con.DistrictID()) == ko.utils.unwrapObservable(self.DistrictID);
        });
        viewModel.main().NAConstituencies(filter_constituenciesNA);
    };

    self.getUnionCouncils = function () {
        var filter_ucs = ko.utils.arrayFilter(ref_unioncouncils, function (uc) {
            return ko.utils.unwrapObservable(uc.TehsilID()) == ko.utils.unwrapObservable(self.TehsilID);
        });
        viewModel.main().UnionCouncils(filter_ucs);
    };

    self.showSpecificContent = function () {
        if (self.DepartmentID() == 15 || self.DepartmentID() == 32 || self.DepartmentID() == 35) {
            $("#modalHospital").modal('hide');
            $("#modalEducation").modal('show');
        }
        else if (self.DepartmentID() == 14 || self.DepartmentID() == 41) {
            $("#modalEducation").modal('hide');
            $("#modalHospital").modal('show');
        }
        else if (self.DepartmentID() == 19) {
            $("#modalEducation").modal('hide');
            $("#modalHospital").modal('hide');
            $("#modalRamzan").modal('show');
        }
        else {
            $("#modalEducation").modal('hide');
            $("#modalHospital").modal('hide');
            $("#modalRamzan").modal('hide');
        }
    };

    self.validateKey = function (data, event) {
        var code = (event.keyCode) ? event.keyCode : event.which;
        if ($.inArray(code, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Numeric
            (code >= 48 && code <= 57) ||
            (code >= 96 && code <= 105) ||
            // Allow: home, end, left, right
            (code >= 35 && code <= 39)) {
            // let it happen, don't do anything
            return true;
        }
        if ((event.shiftKey || (code < 48 || code > 57)) && (code < 96 || code > 105)) {
            event.preventDefault();
            return false;
        }
    }
}

function ImageModel(img) {
    var self = this;
    //self.Title = ko.observable(img.Title);
    //self.Description = ko.observable(img.Description);
    //self.Image = ko.observable(img.Image);

    self.ImageID = ko.observable(img.ImageID || 0);
    self.ImageTitle = ko.observable(img.ImageTitle);
    self.ImageDescription = ko.observable(img.ImageDescription);
    self.VisitorLogImage = ko.observable(img.VisitorLogImage);
    self.ContentType = ko.observable(img.ContentType);
    //self.ImageObject = ko.observable(img.ImageObject);
}

function ChecklistModel(data) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(data.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(data.Title));
    self.Checked = ko.observable(ko.utils.unwrapObservable(data.Checked || false));
}

function CommonModel(data) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(data.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(data.Title));
    self.DivisionID = ko.observable(ko.utils.unwrapObservable(data.DivisionID || 0));
    self.DistrictID = ko.observable(ko.utils.unwrapObservable(data.DistrictID || 0));
    self.TehsilID = ko.observable(ko.utils.unwrapObservable(data.TehsilID || 0));
}

function DivisionModel(data) {
    var self = this;
    self.ID = ko.observable(data.ID);
    self.Title = ko.observable(data.Title);
    // self.DistrictID = ko.observable(data.DistrictID || 0);
}

function DistrictModel(data) {
    var self = this;
    self.ID = ko.observable(data.ID);
    self.Title = ko.observable(data.Title);
    self.TehsilID = ko.observable(data.TehsilID || 0);
}

function TehsilModel(data) {
    var self = this;
    self.ID = ko.observable(data.ID);
    self.Title = ko.observable(data.Title);
    self.UnionCouncilID = ko.observable(data.UnionCouncilID || 0);
}

function UnionCouncilModel(data) {
    var self = this;
    self.ID = ko.observable(data.ID);
    self.Title = ko.observable(data.Title);
}

function RamzanBazarMonitoringModel(item) {
    var self = this;
    if (item != null) {
        self.AttaQualityAvailablity = ko.observable(item.AttaQualityAvailablity != null ? item.AttaQualityAvailablity.toString() : null);
        self.AttaGreenColorBags = ko.observable(item.AttaGreenColorBags != null ? item.AttaGreenColorBags.toString() : null);
        self.MonitoringArrangements = ko.observable(item.MonitoringArrangements != null ? item.MonitoringArrangements.toString() : null);
        self.QueueManagement = ko.observable(item.QueueManagement != null ? item.QueueManagement.toString() : null);
        self.AttaRate = ko.observable(item.AttaRate != null ? item.AttaRate.toString() : null);
        self.SugarAvailablity = ko.observable(item.SugarAvailablity != null ? item.SugarAvailablity.toString() : null);
        self.SugarRate = ko.observable(item.SugarRate != null ? item.SugarRate.toString() : null);
        self.SugarPrintedBags = ko.observable(item.SugarPrintedBags != null ? item.SugarPrintedBags.toString() : null);
        self.SugarQueueManagement = ko.observable(item.SugarQueueManagement != null ? item.SugarQueueManagement.toString() : null);
        self.OilGheeAvailablity = ko.observable(item.OilGheeAvailablity != null ? item.OilGheeAvailablity.toString() : null);
        self.OilGheeDiscount = ko.observable(item.OilGheeDiscount != null ? item.OilGheeDiscount.toString() : null);
        self.OilGheeCategory = ko.observable(item.OilGheeCategory != null ? item.OilGheeCategory.toString() : null);
        self.PoultryChickenMeatAvailablity = ko.observable(item.PoultryChickenMeatAvailablity != null ? item.PoultryChickenMeatAvailablity.toString() : null);
        self.PoultryChickenEggsAvailablity = ko.observable(item.PoultryChickenEggsAvailablity != null ? item.PoultryChickenEggsAvailablity.toString() : null);
        self.PoultryChickenRateDiscount = ko.observable(item.PoultryChickenRateDiscount != null ? item.PoultryChickenRateDiscount.toString() : null);
        self.PoultryQueueManagement = ko.observable(item.PoultryQueueManagement != null ? item.PoultryQueueManagement.toString() : null);
        self.PoultryEggRateDiscount = ko.observable(item.PoultryEggRateDiscount != null ? item.PoultryEggRateDiscount.toString() : null);
        self.AgricultureFairPriceShop = ko.observable(item.AgricultureFairPriceShop != null ? item.AgricultureFairPriceShop.toString() : null);
        self.DisplayWholesalePrice = ko.observable(item.DisplayWholesalePrice != null ? item.DisplayWholesalePrice.toString() : null);

        self.SubsidizedItemsRates = ko.observableArray();
        self.WholeSaleItemsRates = ko.observableArray();

        self.ItemAvailablityNotifiedRates = ko.observable(item.ItemAvailablityNotifiedRates != null ? item.ItemAvailablityNotifiedRates.toString() : null);
        self.CheckingWeightAndMeasures = ko.observable(item.CheckingWeightAndMeasures != null ? item.CheckingWeightAndMeasures.toString() : null);
        self.TentageAvailability = ko.observable(item.TentageAvailability != null ? item.TentageAvailability.toString() : null);
        self.TentageCondition = ko.observable(item.TentageCondition != null ? item.TentageCondition.toString() : null);
        self.TentageStatusID = ko.observable(item.TentageStatusID != null ? item.TentageStatusID.toString() : null);
        self.FacilitaionSeatingArrangement = ko.observable(item.FacilitaionSeatingArrangement != null ? item.FacilitaionSeatingArrangement.toString() : null);
        self.FacilitaionOfFans = ko.observable(item.FacilitaionOfFans != null ? item.FacilitaionOfFans.toString() : null);
        self.FacilitaionOfToilets = ko.observable(item.FacilitaionOfToilets != null ? item.FacilitaionOfToilets.toString() : null);
        self.FacilitaionOfFirstAidService = ko.observable(item.FacilitaionOfFirstAidService != null ? item.FacilitaionOfFirstAidService.toString() : null);
        self.FacilitaionOfGuideTags = ko.observable(item.FacilitaionOfGuideTags != null ? item.FacilitaionOfGuideTags.toString() : null);
        self.LoudspeakerArrangements = ko.observable(item.LoudspeakerArrangements != null ? item.LoudspeakerArrangements.toString() : null);
        self.RevenueStaff = ko.observable(item.RevenueStaff != null ? item.RevenueStaff.toString() : null);
        self.AgriculturStaff = ko.observable(item.AgriculturStaff != null ? item.AgriculturStaff.toString() : null);
        self.HealthStaff = ko.observable(item.HealthStaff != null ? item.HealthStaff.toString() : null);
        self.LiveStockStaff = ko.observable(item.LiveStockStaff != null ? item.LiveStockStaff.toString() : null);
        self.WeightAndMeasureStaff = ko.observable(item.WeightAndMeasureStaff != null ? item.WeightAndMeasureStaff.toString() : null);
        self.AvailabilityFoodAuthority = ko.observable(item.AvailabilityFoodAuthority != null ? item.AvailabilityFoodAuthority.toString() : null);
        self.AvailabilityTMA = ko.observable(item.AvailabilityTMA != null ? item.AvailabilityTMA.toString() : null);
        self.AvailabilityCivilDefence = ko.observable(item.AvailabilityCivilDefence != null ? item.AvailabilityCivilDefence.toString() : null);
        self.DisplayRateList = ko.observable(item.DisplayRateList != null ? item.DisplayRateList.toString() : null);
        self.CleanlinessSanitaryStaff = ko.observable(item.CleanlinessSanitaryStaff != null ? item.CleanlinessSanitaryStaff.toString() : null);
        self.CleanlinessCondition = ko.observable(item.CleanlinessCondition != null ? item.CleanlinessCondition.toString() : null);
        self.CleanlinessWASA = ko.observable(item.CleanlinessWASA != null ? item.CleanlinessWASA.toString() : null);
        self.CompliantBanner = ko.observable(item.CompliantBanner != null ? item.CompliantBanner.toString() : null);
        self.CompliantRegister = ko.observable(item.CompliantRegister != null ? item.CompliantRegister.toString() : null);
        self.SecurityCondition = ko.observable(item.SecurityCondition != null ? item.SecurityCondition.toString() : null);
        self.SecurityPersonnel = ko.observable(item.SecurityPersonnel != null ? item.SecurityPersonnel.toString() : null);
        self.SecurityMetalDetectors = ko.observable(item.SecurityMetalDetectors != null ? item.SecurityMetalDetectors.toString() : null);
        self.SecurityTrafficControlStaff = ko.observable(item.SecurityTrafficControlStaff != null ? item.SecurityTrafficControlStaff.toString() : null);
        self.SecurityofWomen = ko.observable(item.SecurityofWomen != null ? item.SecurityofWomen.toString() : null);
        self.AdequateParkingArrangements = ko.observable(item.AdequateParkingArrangements != null ? item.AdequateParkingArrangements.toString() : null);
        self.AgricultureMarketingStaff = ko.observable(item.AgricultureMarketingStaff != null ? item.AgricultureMarketingStaff.toString() : null);
        self.VideoLinks = ko.observable(item.VideoLinks != null ? item.VideoLinks.toString() : null);
        self.DCOsVisitersRamzanBaar = ko.observable(item.DCOsVisitersRamzanBaar != null ? item.DCOsVisitersRamzanBaar.toString() : null);
        self.ParlianmentariansVisiters = ko.observable(item.ParlianmentariansVisiters != null ? item.ParlianmentariansVisiters.toString() : null);
        self.DistrictCommiteeMembersVisisters = ko.observable(item.DistrictCommiteeMembersVisisters != null ? item.DistrictCommiteeMembersVisisters.toString() : null);
        self.UtilityStoresCorporation = ko.observable(item.UtilityStoresCorporation != null ? item.UtilityStoresCorporation.toString() : null);
        self.AnyOter = ko.observable(item.AnyOter);

        if (item.SubsidizedItemsRates != null && item.SubsidizedItemsRates.length > 0) {
            ko.utils.arrayForEach(item.SubsidizedItemsRates, function (prov) {
                self.SubsidizedItemsRates.push(new RamzanBazarMonitoringItemModel(prov));
            });
        }

        if (item.WholeSaleItemsRates != null && item.WholeSaleItemsRates.length > 0) {
            
            ko.utils.arrayForEach(item.WholeSaleItemsRates, function (prov) {
                self.WholeSaleItemsRates.push(new RamzanBazarMonitoringItemModel(prov));
            });
        }
    }
    else {
        self.AttaQualityAvailablity = ko.observable();
        self.AttaGreenColorBags = ko.observable();
        self.MonitoringArrangements = ko.observable();
        self.QueueManagement = ko.observable();
        self.AttaRate = ko.observable();
        self.SugarAvailablity = ko.observable();
        self.SugarRate = ko.observable();
        self.SugarPrintedBags = ko.observable();
        self.SugarQueueManagement = ko.observable();
        self.OilGheeAvailablity = ko.observable();
        self.OilGheeDiscount = ko.observable();
        self.OilGheeCategory = ko.observable();
        self.PoultryChickenMeatAvailablity = ko.observable();
        self.PoultryChickenEggsAvailablity = ko.observable();
        self.PoultryChickenRateDiscount = ko.observable();
        self.PoultryQueueManagement = ko.observable();
        self.PoultryEggRateDiscount = ko.observable();
        self.AgricultureFairPriceShop = ko.observable();
        self.DisplayWholesalePrice = ko.observable();

        self.SubsidizedItemsRates = ko.observableArray();
        self.WholeSaleItemsRates = ko.observableArray();

        self.ItemAvailablityNotifiedRates = ko.observable();
        self.CheckingWeightAndMeasures = ko.observable();
        self.TentageAvailability = ko.observable();
        self.TentageCondition = ko.observable();
        self.TentageStatusID = ko.observable();
        self.FacilitaionSeatingArrangement = ko.observable();
        self.FacilitaionOfFans = ko.observable();
        self.FacilitaionOfToilets = ko.observable();
        self.FacilitaionOfFirstAidService = ko.observable();
        self.FacilitaionOfGuideTags = ko.observable();
        self.LoudspeakerArrangements = ko.observable();
        self.RevenueStaff = ko.observable();
        self.AgriculturStaff = ko.observable();
        self.HealthStaff = ko.observable();
        self.LiveStockStaff = ko.observable();
        self.WeightAndMeasureStaff = ko.observable();
        self.AvailabilityFoodAuthority = ko.observable();
        self.AvailabilityTMA = ko.observable();
        self.AvailabilityCivilDefence = ko.observable();
        self.DisplayRateList = ko.observable();
        self.CleanlinessSanitaryStaff = ko.observable();
        self.CleanlinessCondition = ko.observable();
        self.CleanlinessWASA = ko.observable();
        self.CompliantBanner = ko.observable();
        self.CompliantRegister = ko.observable();
        self.SecurityCondition = ko.observable();
        self.SecurityPersonnel = ko.observable();
        self.SecurityMetalDetectors = ko.observable();
        self.SecurityTrafficControlStaff = ko.observable();
        self.SecurityofWomen = ko.observable();
        self.AdequateParkingArrangements = ko.observable();
        self.AgricultureMarketingStaff = ko.observable();
        self.VideoLinks = ko.observable();
        self.DCOsVisitersRamzanBaar = ko.observable();
        self.ParlianmentariansVisiters = ko.observable();
        self.DistrictCommiteeMembersVisisters = ko.observable();
        self.UtilityStoresCorporation = ko.observable();
        self.AnyOter = ko.observable();
    }

    self.wholesaleItemChecked = ko.observable(false);

    self.wholesaleitemClick = function (mod) {
        if (mod.wholesaleItemChecked()) {
            if (self.WholeSaleItemsRates() != null) {
                ko.utils.arrayForEach(self.WholeSaleItemsRates(), function (prov) {
                    prov.Availabitliy("true");
                    prov.ConditionID(1);
                });
            }
        }
        else {
            if (self.WholeSaleItemsRates() != null) {
                ko.utils.arrayForEach(self.WholeSaleItemsRates(), function (prov) {
                    prov.Availabitliy("false");
                    prov.ConditionID(2);
                });
            }
        }
        return true;
    };

    self.subsidizedItemChecked = ko.observable(false);

    self.subsidizeditemClick = function (mod) {
        if (mod.subsidizedItemChecked()) {
            if (self.SubsidizedItemsRates() != null) {
                ko.utils.arrayForEach(self.SubsidizedItemsRates(), function (prov) {
                    prov.Availabitliy("true");
                    prov.ConditionID(1);
                });
            }
        }
        else {
            if (self.SubsidizedItemsRates() != null) {
                ko.utils.arrayForEach(self.SubsidizedItemsRates(), function (prov) {
                    prov.Availabitliy("false");
                    prov.ConditionID(2);
                });
            }
        }
        return true;
    };

    self.selectAllAttaItems = function (model) {

        var checkAll = document.getElementById('selectAllAttaInfo').checked;
        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.AttaQualityAvailablity(checkAll.toString());
            model.AttaRate(checkAll.toString());
            model.AttaGreenColorBags(checkAll.toString());
            model.MonitoringArrangements(checkAll.toString());
            model.QueueManagement(checkAll.toString());

        });


    }

    // Select All Sugar Items
    self.selectAllSugarItems = function (model) {
        var checkAll = document.getElementById('selectAllSugarItems').checked;
        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.SugarAvailablity(checkAll.toString());
            model.SugarRate(checkAll.toString());
            model.SugarPrintedBags(checkAll.toString());
            model.SugarQueueManagement(checkAll.toString());

        });

    }

    // Select All Oild And Ghee Items
    self.selectAllOildAndGheeItems = function (model) {

        var checkAll = document.getElementById('selectAllOildAndGheeItems').checked;
        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.OilGheeAvailablity(checkAll.toString());
            model.OilGheeDiscount(checkAll.toString());
            model.OilGheeCategory(checkAll.toString());


        });

    }

    // Select All Poultry Items
    self.selectAllPoultryItems = function (model) {
        var checkAll = document.getElementById('selectAllPoultryItems').checked;

        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.PoultryChickenMeatAvailablity(checkAll.toString());
            model.PoultryChickenEggsAvailablity(checkAll.toString());
            model.PoultryChickenRateDiscount(checkAll.toString());
            model.PoultryEggRateDiscount(checkAll.toString());
            model.PoultryQueueManagement(checkAll.toString());

        });

    }

    // Select All Tentage Items
    self.selectAllTentageItems = function (model) {

        var checkAll = document.getElementById('selectAllTentageItems').checked;

        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.TentageAvailability(checkAll.toString());
            if (checkAll) {
                model.TentageCondition(1);
            }
            else {

                model.TentageCondition(2);
            }

        });
        model.TentageStatusID(checkAll ? "1" : "2");

    }

    // Select All Facilitation Items
    self.selectAllFacilitationItems = function (model) {

        var checkAll = document.getElementById('selectAllFacilitationItems').checked;

        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.FacilitaionSeatingArrangement(checkAll.toString());
            model.FacilitaionOfFans(checkAll.toString());
            model.FacilitaionOfToilets(checkAll.toString());
            model.LoudspeakerArrangements(checkAll.toString());
            model.FacilitaionOfFirstAidService(checkAll.toString());
            model.FacilitaionOfGuideTags(checkAll.toString());

        });

    }

    // Select All Availability Staff Items
    self.selectAllAvailabilityStaffItems = function (model) {

        var checkAll = document.getElementById('selectAllAvailabilityStaffItems').checked;

        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.RevenueStaff(checkAll.toString());
            model.AgriculturStaff(checkAll.toString());
            model.HealthStaff(checkAll.toString());
            model.LiveStockStaff(checkAll.toString());
            model.WeightAndMeasureStaff(checkAll.toString());
            model.AvailabilityTMA(checkAll.toString());
            model.AvailabilityFoodAuthority(checkAll.toString());
            model.AvailabilityCivilDefence(checkAll.toString());
            model.DisplayRateList(checkAll.toString());

        });


    }

    //Select All Complaint System Items
    self.selectAllComplaintSystemItems = function (model) {

        var checkAll = document.getElementById('selectAllComplaintSystemItems').checked;

        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.CompliantBanner(checkAll.toString());
            model.CompliantRegister(checkAll.toString());


        });

    }

    //Select All Parking Items
    self.selectAllParkingItems = function (model) {

        var checkAll = document.getElementById('selectAllParkingItems').checked;
        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.SecurityPersonnel(checkAll.toString());
            model.SecurityMetalDetectors(checkAll.toString());
            model.SecurityofWomen(checkAll.toString());
            model.AdequateParkingArrangements(checkAll.toString());
            model.SecurityTrafficControlStaff(checkAll.toString());


        });

        model.SecurityCondition(checkAll ? "1" : "2");

    }

    //Select All Cleanliness Items
    self.selectAllCleanlinessItems = function (model) {


        var checkAll = document.getElementById('selectAllCleanlinessItems').checked;

        ko.utils.arrayForEach(YesNo, function (prov) {
            prov.Value = true;
            model.CleanlinessSanitaryStaff(checkAll.toString());
            model.CleanlinessWASA(checkAll.toString());

        });

        model.CleanlinessCondition(checkAll ? "1" : "2");
    }

}

function RamzanBazarMonitoringItemModel(item) {
    var self = this;
    if (item != null) {
        self.ID = ko.observable(item.ID);
        self.ItemID = ko.observable(item.ItemID);
        self.CategoryID = ko.observable(item.CategoryID);
        self.MonitoringID = ko.observable(item.MonitoringID);
        self.Availabitliy = ko.observable(item.Availabitliy != null ? item.Availabitliy.toString() : null);
        self.ConditionID = ko.observable(item.ConditionID);
        self.Rates = ko.observable(item.Rates);
        self.Remarks = ko.observable(item.Remarks);
        self.ItemTitle = ko.observable(item.ItemTitle);
    }
    else {
        self.ID = ko.observable();
        self.ItemID = ko.observable();
        self.CategoryID = ko.observable();
        self.MonitoringID = ko.observable();
        self.Availabitliy = ko.observable();
        self.ConditionID = ko.observable();
        self.Rates = ko.observable();
        self.Remarks = ko.observable();
        self.ItemTitle = ko.observable();
    }

    self.validateKey = function (data, event) {
        var code = (event.keyCode) ? event.keyCode : event.which;
        if ($.inArray(code, [46, 8, 9, 27, 13]) !== -1 ||
            //    // Allow: Ctrl+A
            //    (event.keyCode == 65 && event.ctrlKey === true) ||
            //    // Allow: Ctrl+C
            //    (event.keyCode == 67 && event.ctrlKey === true) ||
            //    // Allow: Ctrl+X
            //    (event.keyCode == 88 && event.ctrlKey === true) ||
            //    // Allow: Ctrl+V
            //    (event.keyCode == 86 && event.ctrlKey === true) ||
            // Allow: Numeric
        (code >= 48 && code <= 57) ||
        (code >= 96 && code <= 105) ||
            // Allow: home, end, left, right
        (code >= 35 && code <= 39) || (code == 110 || code == 190)) {
            // let it happen, don't do anything
            return true;
        }
        if ((event.shiftKey || (code < 48 || code > 57)) && (code < 96 || code > 105)) {
            event.preventDefault();
            return false;
        }
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function LoadRecord() {

    var IsEditRecord = GetQueryString('IsEditRecord');
    var visitorLogID = null;
    if (IsEditRecord) {
        visitorLogID = GetQueryString('ID');
    }

    $.ajax({
        url: "index.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        data: "{visitorLogID : '" + visitorLogID + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new WrapperModel(data.d));
                viewModel.main().editModel().ProvinceID(1);

                $('.nav-tabs a[href="#tab1"]').tab('show');
                if (IsEditRecord) {
                    if (ref_districts != null) {
                        ko.utils.arrayForEach(ref_districts, function (prov) {
                            if (prov.DivisionID() == viewModel.main().editModel().DivisionID())
                                viewModel.main().Districts.push(new CommonModel(prov));
                        });
                    }
                    viewModel.main().editModel().DistrictID(data.d.visit.DistrictID);

                    if (ref_tehsils != null) {
                        ko.utils.arrayForEach(ref_tehsils, function (prov) {
                            if (prov.DistrictID() == viewModel.main().editModel().DistrictID())
                                viewModel.main().Tehsils.push(new CommonModel(prov));
                        });
                    }

                    viewModel.main().editModel().TehsilID(data.d.visit.TehsilID);


                    if (ref_unioncouncils != null) {
                        ko.utils.arrayForEach(ref_unioncouncils, function (prov) {
                            if (prov.TehsilID() == viewModel.main().editModel().TehsilID())
                                viewModel.main().UnionCouncils.push(new CommonModel(prov));
                        });
                    }
                    viewModel.main().editModel().UnionCouncilID(data.d.visit.UnionCouncilID);

                    if (ref_constituencies != null) {
                        ko.utils.arrayForEach(ref_constituencies, function (prov) {
                            if (prov.DistrictID() == viewModel.main().editModel().DistrictID())
                                viewModel.main().Constituencies.push(new CommonModel(prov));
                        });
                    }
                    viewModel.main().editModel().ConstituencyID(data.d.visit.ConstituencyID);

                    if (ref_constituenciesNA != null) {
                        ko.utils.arrayForEach(ref_constituenciesNA, function (prov) {
                            if (prov.DistrictID() == viewModel.main().editModel().DistrictID())
                                viewModel.main().NAConstituencies.push(new CommonModel(prov));
                        });
                    }
                    viewModel.main().editModel().NAConstituencyID(data.d.visit.NAConstituencyID);
                    $(".nicEdit-main").html(data.d.visit.FeedBack);

                    //viewModel.main().editModel().UnionCouncilID(viewModel.main().editModel().UnionCouncilID());
                }
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });

}


function attachvalidateTabs() {
    //for (i = 1; i <= 3; i++) {
    //    setCurrentTab(i);
    //    var formId = "#tab" + i;
    //    $(formId).validationEngine('attach');
    //}

}

function validateTabs() {
    var ret = true;
    for (i = 1; i <= 3; i++) {
        setCurrentTab(i);
        var formId = "#tab" + i;
        if (!$(formId).validationEngine('validate')) {
            ret = false;
            return false;
        }
    }

    return ret;;
}

function setCurrentTab(id) {
    $('.nav-tabs a[href=#tab' + id + ']').tab('show');
    setTimeout(100);
}



function GetQueryString(key) {
    var value = "";
    var PageURL = decodeURIComponent(window.location.search.substring(1));
    var sURLVariables = PageURL.split('&');

    for (var i = 0; i < sURLVariables.length; i++) {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0].toLowerCase() == key.toLowerCase()) {
            value = sParameterName[1];
        }
    }
    return value;
}




