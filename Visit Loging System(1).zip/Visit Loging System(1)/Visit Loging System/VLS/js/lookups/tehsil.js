﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var ref_all_Provicnes = [];
var ref_all_Divisions = [];
var ref_all_District = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.IsEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    self.Provinces = ko.observableArray();
    self.Divisions = ko.observableArray();
    self.Districts = ko.observableArray();

    ref_all_Provicnes = [];
    ref_all_Divisions = [];
    ref_all_District = [];
    ref_all_rec = [];

    if (items != null) {
        if (ko.utils.unwrapObservable(items.Provinces) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Provinces), function (rec) {
                self.Provinces.push(new ProvinceModel(rec));
                ref_all_Provicnes.push(new ProvinceModel(rec));
            });
        }

        if (ko.utils.unwrapObservable(items.Divisions) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Divisions), function (rec) {
                self.Divisions.push(new DivisionModel(rec));
                ref_all_Divisions.push(new DivisionModel(rec));
            });
        }

        if (ko.utils.unwrapObservable(items.Districts) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Districts), function (rec) {
                self.Districts.push(new DistrictModel(rec));
                ref_all_District.push(new DistrictModel(rec));
            });
        }

        if (ko.utils.unwrapObservable(items.Tehsils) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Tehsils), function (item) {
                self.allRecords.push(new TehsilModel(item));
                ref_all_rec.push(new TehsilModel(item));
            });
        }

        self.PageSize(25);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new TehsilModel(item);
        self.editModel(new TehsilModel(item));
        self.allRecords.remove(item);
        self.IsEdit(true);
    };

    self.cancelRecord = function () {
        self.editModel(new TehsilModel(null));
        self.allRecords.push(refModel);
        self.IsEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        if (confirm("Do you want to block record?")) {
            $.ajax({
                url: "Tehsil.aspx/RemoveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(item) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        item.Status(false);
                        LoadRecord();
                        NotifyMe("delete_success");
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "Tehsil.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.ID > 0) {
                            var mod = new TehsilModel(data.d);
                            self.allRecords.unshift(mod);
                            self.editModel(new TehsilModel(null));
                            self.IsEdit(false);
                            NotifyMe("success");
                            //LoadRecord();
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                if (item.Description != "") {
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                        item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                }
                else
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });

            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }

        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }
}

function TehsilModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.ProvinceID = ko.observable(ko.utils.unwrapObservable(item.ProvinceID));
        self.DivisionID = ko.observable(ko.utils.unwrapObservable(item.DivisionID));
        self.DistrictID = ko.observable(ko.utils.unwrapObservable(item.DistrictID));
        self.DistrictName = ko.observable(ko.utils.unwrapObservable(item.DistrictName));
    }
    else {
        self.ID = ko.observable(null);
        self.Code = ko.observable('');
        self.Title = ko.observable();
        self.Description = ko.observable('');
        self.Status = ko.observable(true);
        self.ProvinceID = ko.observable();
        self.DivisionID = ko.observable();
        self.DistrictID = ko.observable();
        self.DistrictName = ko.observable('');
    }

    self.getDivision = function () {
        viewModel.main().Divisions([]);

        var filter_divisions = ko.utils.arrayFilter(ref_all_Divisions, function (dv) {
            return ko.utils.unwrapObservable(dv.ProvinceID()) == ko.utils.unwrapObservable(self.ProvinceID());
        });

        viewModel.main().Divisions(filter_divisions);
    };

    self.getDistrict = function () {
        viewModel.main().Districts([]);
        var filter_districts = ko.utils.arrayFilter(ref_all_District, function (d) {
            return ko.utils.unwrapObservable(d.DivisionID()) == ko.utils.unwrapObservable(self.DivisionID());
        });

        viewModel.main().Districts(filter_districts);
    };
}

function ProvinceModel(rec) {
    var self = this;
    self.ID = ko.observable(rec.ID);
    self.Title = ko.observable(rec.Title);
}

function DivisionModel(data) {
    var self = this;
    self.ID = ko.observable(data.ID);
    self.Title = ko.observable(data.Title);
    self.ProvinceID = ko.observable(data.ProvinceID);
}

function DistrictModel(data) {
    var self = this;
    self.ID = ko.observable(data.ID);
    self.Title = ko.observable(data.Title);
    self.DivisionID = ko.observable(data.DivisionID);
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Tehsil.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new TehsilModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new TehsilModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}