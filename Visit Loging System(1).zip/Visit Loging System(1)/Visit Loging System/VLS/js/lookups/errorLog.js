﻿var viewModel = new ViewModel();
var refModel = null;
var all_Districts = [];
var ref_allrecord = [];
var allsearchCreatria = [{ 'ID': 1, 'Title': 'Search By ID' }, { 'ID': 2, 'Title': 'Search By Message' }];

ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};
//** Validation Engine Custom binding **\\
ko.bindingHandlers.valid = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($("#main"))) {
            $(element).validationEngine('validate');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()) || new Date(),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};

function ErrorLogModel(item) {

    var self = this;

    self.SearchCreatria = ko.observable(0);
    self.PageSize = ko.observable(15);


    if (item != null) {
        self.logID = ko.observable(ko.utils.unwrapObservable(item.logID));

        self.DistrictID = ko.observable(ko.utils.unwrapObservable(item.DistrictID));
        self.DistrictTitle = ko.observable(ko.utils.unwrapObservable(item.DistrictTitle));

        self.PageName = ko.observable(ko.utils.unwrapObservable(item.PageName));
        self.PageStaticName = ko.observable(ko.utils.unwrapObservable(item.PageStaticName));

        self.Method = ko.observable(ko.utils.unwrapObservable(item.Method));
        self.Message = ko.observable(ko.utils.unwrapObservable(item.Message));
        self.StackTrace = ko.observable(ko.utils.unwrapObservable(item.StackTrace));
        self.Source = ko.observable(ko.utils.unwrapObservable(item.Source));
        self.IsWebMethod = ko.observable(ko.utils.unwrapObservable(item.IsWebMethod));

        self.FromDate = ko.observable(ko.utils.unwrapObservable(item.FromDate));
        self.ToDate = ko.observable(ko.utils.unwrapObservable(item.FromDate));

        //self.Created = ko.observable(ko.utils.unwrapObservable(item.Created));
        self.Created = ko.observable(item.Created != null ? new Date(parseInt(item.Created.substring(6, 19))).format("dd/M/yy") : '');
        /// observableArray
        self.allPageNames = ko.observableArray();

        self.allServices = ko.observableArray();
        self.allDivisions = ko.observableArray();

        self.allErrorLogs = ko.observableArray();
        if (ko.utils.unwrapObservable(item.allErrorLogs) != null && ko.utils.unwrapObservable(item.allErrorLogs) != '') {
            ref_allrecord = [];
            ko.utils.arrayForEach(ko.utils.unwrapObservable(item.allErrorLogs), function (list) {
                self.allErrorLogs.push(new ErrorLogModel(list));
                ref_allrecord.push(new ErrorLogModel(list));
            });
        }

        //self.allDistricts = ko.observableArray();
        //if (item.allDistricts != null) {
        //    ko.utils.arrayForEach(all_Districts, function (district) {
        //        self.allDistricts.push(new DistrictModel(district));
        //    });
        //}

    }
    else {

        self.logID = ko.observable(-1);
        self.DistrictID = ko.observable(-1);
        self.DistrictCode = ko.observable('');
        self.PageName = ko.observable('');
        self.PageStaticName = ko.observable('');
        self.Method = ko.observable('');
        self.Message = ko.observable('');
        self.StackTrace = ko.observable('');
        self.Source = ko.observable('');
        self.IsWebMethod = ko.observable(true);
        self.Created = ko.observable(new Date());
        self.allPageNames = ko.observableArray();
        self.allDistricts = ko.observableArray();
        self.allErrorLogs = ko.observableArray();
        self.FromDate = ko.observable(new Date());
        self.ToDate = ko.observable(new Date());
        self.allsearchCreatria = ko.observableArray();
    }


    self.PageSize(30);
    var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allErrorLogs(), null, self.PageSize());

    self.LoadErrorLogs = function () {

        LoadRecord(this);
    }

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_allrecord, function (item) {

                return item.Source().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                        item.Method().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                        item.Message().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                        item.PageName().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;

            });
            self.allErrorLogs(rList);
        }
        else {
            self.allErrorLogs(ref_allrecord);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }

}

function DistrictModel(item) {
    var self = this;
    self.DistrictID = ko.observable(item.ID);
    self.DistrictTitle = ko.observable(item.Title);
}
function PageNameModel(item) {
    var self = this;
    self.PageName = ko.observable(item.pageName);
    self.PageStaticName = ko.observable(item.StaticName);
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine({ promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {
    if (mod != undefined) {
        var stateModel = {
           // districtID: ko.utils.unwrapObservable(mod.DistrictID || -1),
            pageStaticName: ko.utils.unwrapObservable(mod.PageStaticName || ''),
            fromDate: ko.utils.unwrapObservable(mod.FromDate || ''),
            toDate: ko.utils.unwrapObservable(mod.ToDate || ''),
        };
    }


    var jsonModel = null;
    if (mod != undefined) {
        mod.allErrorLogs([]);
        jsonModel = ko.toJSON(mod);
    }
    else {
        jsonModel = ko.toJSON(mod);
    }

    $.ajax({
        url: "ErrorLog.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        data: "{ErrorLogModel : '" + jsonModel + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data.d != null)
                viewModel.main(new ErrorLogModel(data.d));
            else
                viewModel.main(new ErrorLogModel(null));

            //all_Districts = [];
            //if (data.d.Districts != null) {
            //    ko.utils.arrayForEach(data.d.Districts, function (District) {
            //        viewModel.main().allDistricts.push(new DistrictModel(District));
            //        all_Districts.push(new DistrictModel(District));
            //    });
            //}

            /// PageNameModel
            if (data.d.PageNames != null) {
                ko.utils.arrayForEach(data.d.PageNames, function (PageName) {
                    viewModel.main().allPageNames.push(new PageNameModel(PageName));
                });
            }
            if (data.d.ErrorLogs != null) {
                ref_allrecord = [];
                ko.utils.arrayForEach(data.d.ErrorLogs, function (ErrorLog) {
                    viewModel.main().allErrorLogs.push(new ErrorLogModel(ErrorLog));
                    ref_allrecord.push(new ErrorLogModel(ErrorLog));
                });
            }

            if (mod != undefined) {
               // viewModel.main().DistrictID(stateModel.districtID);
                viewModel.main().PageStaticName(stateModel.pageStaticName);
                viewModel.main().FromDate(stateModel.fromDate);
                viewModel.main().ToDate(stateModel.toDate);
            }
        },
        error: function (request) {
        }
    });
}
function filterArray(self, newDivisionValue) {
    if (newDivisionValue != undefined) {
        var filter_districts = ko.utils.arrayFilter(all_Districts, function (district) {
            return ko.utils.unwrapObservable(district.DistrictDivisionID()) == newDivisionValue;
        });
        self.allDistricts([]);
        self.allDistricts(filter_districts);
    }

}


self.getSearchPrj = function () {
    var srcText = $('.search').val().trim();
    var SrchCrtra = viewModel.main().SearchCreatria();

    var vParameters = "{jsonModel : '" + ko.toJSON(this) + "',searchByID:'" + SrchCrtra + "',searchByMessage : '" + srcText + "'}";
    $.ajax({
        url: "ErrorLog.aspx/GetRecordsBySearchCreiteria",
        type: 'POST',
        dataType: "json",
        data: vParameters,
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                if (data.d != null)
                    viewModel.main(new ErrorLogModel(data.d));

                else
                    viewModel.main(new ErrorLogModel(null));

                if (data.d.PageNames != null) {
                    ko.utils.arrayForEach(data.d.PageNames, function (PageName) {
                        viewModel.main().allPageNames.push(new PageNameModel(PageName));
                    });
                }
                if (data.d.ErrorLogs != null) {
                    ref_allrecord = [];
                    ko.utils.arrayForEach(data.d.ErrorLogs, function (ErrorLog) {
                        viewModel.main().allErrorLogs.push(new ErrorLogModel(ErrorLog));
                        ref_allrecord.push(new ErrorLogModel(ErrorLog));
                    });
                }
            }
            else {
                viewModel.main(new ErrorLogModel(null));
            }
        },
        error: function (request) {
            console.log(request.responseText);
        }
    });
};