﻿var viewModel = new ViewModel();
var all_Districts = [];

var refModel = null;
var ref_all_rec = [];


ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);

    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    if (items != null) {
        ref_all_rec = [];
        if (items.Constituencyies != null) {
            ko.utils.arrayForEach(items.Constituencyies, function (item) {
                self.allRecords.push(new ConstituencyModel(item));
                ref_all_rec.push(new ConstituencyModel(item));
            });

        }

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new ConstituencyModel(item);
        var mod = new ConstituencyModel(item);
        mod.allDistricts(all_Districts);

        self.editModel(mod);
        self.allRecords.remove(item);
        self.isEdit(true);
    }

    self.cancelRecord = function () {
        var mod = new ConstituencyModel(null);
        mod.allDistricts(all_Districts);

        self.editModel(mod);
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    }

    self.removeRecord = function (item) {
        // if (getConfirmation()) {
        if (confirm("Are you sure you want to inactive?")) {
            $.ajax({
                url: "Constituency.aspx/RemoveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(item) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {

                    if (NotifyMe(data.d.Notification)) {
                        // if (data.d == "true") {
                        item.Status(false);
                        LoadRecord();
                        // NotifyMe("inactivesuccess");
                        // }
                        //else if (data.d != "true" && data.d != "false") {
                        //   // NotifyMe(data.d);
                        //}
                    }
                },
                error: function (request) {
                    alert(Error);
                }
            });
        }
    }

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "Constituency.aspx/SaveRecord", //../../../../Layouts/PITB.FC/Lookups/Relation.aspx/SaveRelation
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d.ID > 0) {
                            var mod = new ConstituencyModel(data.d);
                            // mod.DocumentNatureName(getdocumentNatureTitlebyID(mod));
                            self.allRecords.unshift(mod);
                            mod = new ConstituencyModel(null);

                            mod.allDistricts(all_Districts);

                            self.editModel(mod);
                            self.isEdit(false);
                            LoadRecord();
                            //NotifyMe("saverecordSuccess");
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                    item.District().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0
                ;

            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    }

    self.Reload = function () {
        LoadRecord();
    }


}

function ConstituencyModel(item) {
    var self = this;
    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.DistrictID = ko.observable(ko.utils.unwrapObservable(item.DistrictID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.District = ko.observable(ko.utils.unwrapObservable(item.District));
    }
    else {

        self.ID = ko.observable();
        self.DistrictID = ko.observable(null);
        self.Title = ko.observable();
        self.Description = ko.observable('');
        self.Status = ko.observable(true);
        self.District = ko.observable('')
    }

    self.allDistricts = ko.observableArray();
}

function commonModel(model) {
    var self = this;
    self.ID = ko.observable(model.ID);
    self.Title = ko.observable(model.Title);

}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Constituency.aspx/GetRecords", //../../../../Layouts/PITB.FC/Lookups/Religion.aspx/GetAllReligions
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new ConstituencyModel(null));

                if (data.d.Districts != null) {
                    ko.utils.arrayForEach(data.d.Districts, function (mI) {
                        viewModel.main().editModel().allDistricts.push(new commonModel(mI));
                    });
                    all_Districts = viewModel.main().editModel().allDistricts();
                }
                //viewModel.main().IsAdmin(data.d.IsAdmin || false);
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new ConstituencyModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

//function getdocumentNatureTitlebyID(mod) {
//    var ret = ko.utils.arrayFilter(all_Districts, function (item) {
//        return item.ID() == mod.AppFeatureID();
//    });
//    return ret[0] != undefined ? ret[0].Name() : '-';
//}