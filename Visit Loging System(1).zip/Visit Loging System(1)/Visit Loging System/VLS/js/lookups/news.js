﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var doubleQoutesRegx = new RegExp("\"", "g");
ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {},
            $el = $(element);

        $el.datepicker(options);

        //handle the field changing by registering datepicker's changeDate event
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });

        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });

    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
            $el = $(element);

        //handle date data coming via json from Microsoft
        if (String(value).indexOf('/Date(') == 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }

        var current = $el.datepicker("getDate");

        if (value - current !== 0) {
            $el.datepicker("setDate", value);
        }
    }
};

ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};



function wrapperModel(item) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    if (item != null) {
        ref_all_rec = [];
        if (item.allRecords != null) {
            ko.utils.arrayForEach(item.allRecords, function (News) {
                self.allRecords.push(new NewsModel(News));
                ref_all_rec.push(new NewsModel(News));
            });
        }

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {



        refModel = new NewsModel(item);
        self.editModel(new NewsModel(item));
        self.allRecords.remove(item);
        self.isEdit(true);
        $(".signature")[0].src = item.Image();
        $(".nicEdit-main").html(item.Description());
    };

    self.cancelRecord = function () {
        //self.editModel(new NewsModel(null));
        //self.allRecords.push(refModel);
        $(".nicEdit-main").html("");
      
        self.isEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        if (confirm("Are you sure you want to inactive?")) {
            $.ajax({
                url: "News.aspx/RemoveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(item) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        item.Status(false);
                        LoadRecord();
                        //NotifyMe("inactivesuccess");
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    self.saveRecord = function () {
        var content = $(".nicEdit-main").html().replace(doubleQoutesRegx, "");
        viewModel.main().editModel().Description(content);

       
        if ($('form').validationEngine('validate') && viewModel.main().editModel().Image() != undefined && viewModel.main().editModel().Image != "") {
                $.ajax({
                    url: "News.aspx/SaveRecord",
                    type: 'POST',
                    data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        if (NotifyMe(data.d.Notification)) {
                            $(".nicEdit-main").html('');
                            var mod = new NewsModel(data.d);
                            self.allRecords.unshift(mod);
                            self.editModel(new NewsModel(null));
                            self.isEdit(false);
                            LoadRecord();

                        }
                    },
                    error: function (er, _rr) {
                        toastr.error("error|" + er.statusText);
                    }
                });
           
        }
        else {
            NotifyMe("error| Image should be attached before saving.");
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                if (item.Description != "") {
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                }
                else
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }
}

function NewsModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.Image = ko.observable(ko.utils.unwrapObservable(item.Image));
        self.NewsDate = ko.observable(ko.utils.unwrapObservable(item.NewsDate) != null ? ko.utils.unwrapObservable(item.NewsDate).toString().indexOf('/Date(') > -1 ? parseInt(ko.utils.unwrapObservable(item.NewsDate).toString().substring(6, 19)) > 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.NewsDate).toString().substring(6, 19))) : '' : ko.utils.unwrapObservable(item.NewsDate) : '');
    }
    else {
        self.ID = ko.observable();
        self.Title = ko.observable();
        self.Description = ko.observable('');
        self.Status = ko.observable(true);
        self.Image = ko.observable(ko.utils.unwrapObservable());
        self.NewsDate = ko.observable();
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    var nicEditConfig = {
        buttonList: ['save', 'bold', 'italic', 'underline', 'left', 'center', 'right', 'justify', 'ol', 'ul', 'indent', 'outdent']
    };
    bkLib.onDomLoaded(function () {
        new nicEditor(nicEditConfig).panelInstance('area1');
    });

    LoadRecord();
    ko.applyBindings(viewModel);


});

function LoadRecord() {
    $.ajax({
        url: "News.aspx/GetRecord",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {

            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new NewsModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new NewsModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}

function SetImage() {
    var fr = new FileReader
    // when image is loaded, set the src of the image where you want to display it
    fr.onload = function (e) {
        $(".signature")[0].src = this.result;
        viewModel.main().editModel().Image(this.result);
    }
    fr.readAsDataURL($(".signuploder").get(0).files[0]);
}

