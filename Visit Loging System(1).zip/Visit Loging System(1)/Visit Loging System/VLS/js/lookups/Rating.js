﻿var viewModel = new ViewModel();
var maxLength = 200;
var refModel = null;
var ref_all_rec = [];

var apostrophyRegx = new RegExp("'", "g");
var doubleQoutesRegx = new RegExp("\"", "g");
var commentRegex = new RegExp(
    '<!--[\\s\\S]*?(?:-->)?'
    + '<!---+>?'  // A comment with no body
    + '|<!(?![dD][oO][cC][tT][yY][pP][eE]|\\[CDATA\\[)[^>]*>?'
    + '|<[?][^>]*>?',  // A pseudo-comment
    'g');

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(item) {
    var self = this;
    self.IsEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    if (item != null) {
        ref_all_rec = [];
        if (item.Ratings != null) {
            ko.utils.arrayForEach(item.Ratings, function (m) {
                self.allRecords.push(new RatingModel(m));
                ref_all_rec.push(new RatingModel(m));
            });
        }

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new RatingModel(item);
        self.editModel(new RatingModel(item));
        self.allRecords.remove(item);
        self.IsEdit(true);


        setTextareasValues(self.editModel());
    };

    self.cancelRecord = function () {
        clearTextareasValues();
        self.editModel(new RatingModel(null));
        self.allRecords.push(refModel);
        self.IsEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        $.ajax({
            url: "Rating.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.Status(false);
                    LoadRecord();
                    NotifyMe("delete_success");
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        //}
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            if (getTextareasValues(viewModel.main())) {
                var jsonStr = ko.toJSON(viewModel.main().editModel()).replace(commentRegex, "");
                jsonStr = jsonStr.replace(apostrophyRegx, "");
               $.ajax({
                    url: "Rating.aspx/SaveRecord",
                    type: 'POST',
                    data: "{jsonModel : '" + jsonStr + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        if (NotifyMe(data.d.Notification)) {
                            if (data.d.ID > 0) {
                                var mod = new RatingModel(data.d);
                                self.allRecords.unshift(mod);
                                self.editModel(new RatingModel(null));
                                self.IsEdit(false);
                                NotifyMe("success");
                                clearTextareasValues();
                            }
                        }
                    },
                    error: function (er, _rr) {
                        NotifyMe("error|" + er.statusText);
                    }
                });
            }
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                //if (item.Description() != null ) {
                //    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                //        item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                //}
                //else
                //   
                return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }
}

function RatingModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));

        self.ObservationSMSForOfficial = ko.observable(ko.utils.unwrapObservable(item.ObservationSMSForOfficial));
        self.ObservationEMailForOfficial = ko.observable(ko.utils.unwrapObservable(item.ObservationEMailForOfficial));
        self.ObservationSMSForSubOrdinates = ko.observable(ko.utils.unwrapObservable(item.ObservationSMSForSubOrdinates));
        self.ObservationEamilForSubOrdinates = ko.observable(ko.utils.unwrapObservable(item.ObservationEamilForSubOrdinates));
        self.VisitSMSForOffical = ko.observable(ko.utils.unwrapObservable(item.VisitSMSForOffical));
        self.VisitEmailForOffical = ko.observable(ko.utils.unwrapObservable(item.VisitEmailForOffical));
        self.Category = ko.observable(ko.utils.unwrapObservable(item.Category));
        self.Sort = ko.observable(ko.utils.unwrapObservable(item.Sort));
        self.ActionTakenOfficialEmail = ko.observable(ko.utils.unwrapObservable(item.ActionTakenOfficialEmail));
        self.ActionTakenOfficialSMS = ko.observable(ko.utils.unwrapObservable(item.ActionTakenOfficialSMS));

    }
    else {

        self.ActionTakenOfficialEmail = ko.observable('');
        self.ActionTakenOfficialSMS = ko.observable('');
        self.ID = ko.observable();
        self.Title = ko.observable();
        self.Description = ko.observable('');
        self.Status = ko.observable(true);

        self.ObservationSMSForOfficial = ko.observable('');
        self.ObservationEMailForOfficial = ko.observable('');
        self.ObservationSMSForSubOrdinates = ko.observable('');
        self.ObservationEamilForSubOrdinates = ko.observable('');
        self.VisitSMSForOffical = ko.observable('');
        self.VisitEmailForOffical = ko.observable('');
        self.Category = ko.observable();
        self.Sort = ko.observable(null);

    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function getTextareasValues(mainModel) {
    var ret = "";
    var contentHtml;
    if ($(".nicEdit-main.ObservationEMailForOfficial").text().length > maxLength)
        ret += "Observation EMail For Official,<br />";
    else {
        contentHtml = $(".nicEdit-main.ObservationEMailForOfficial").html().replace(doubleQoutesRegx, "");
        contentHtml = contentHtml.replace(commentRegex, "");
        contentHtml = contentHtml.replace(apostrophyRegx, "");
        mainModel.editModel().ObservationEMailForOfficial(contentHtml);
    }
    if ($(".nicEdit-main.ObservationEamilForSubOrdinates").text().length > maxLength)
        ret += "Observation Eamil For Sub Ordinates,<br />";
    else {
        contentHtml = $(".nicEdit-main.ObservationEamilForSubOrdinates").html().replace(doubleQoutesRegx, "");
        contentHtml = contentHtml.replace(commentRegex, "");
        contentHtml = contentHtml.replace(apostrophyRegx, "");
        mainModel.editModel().ObservationEamilForSubOrdinates(contentHtml);
    }
    if ($(".nicEdit-main.VisitEmailForOffical").text().length > maxLength)
        ret += "Observation Eamil For Sub Ordinates,<br />";
    else {
        contentHtml = $(".nicEdit-main.VisitEmailForOffical").html().replace(doubleQoutesRegx, "");
        contentHtml = contentHtml.replace(commentRegex, "");
        contentHtml = contentHtml.replace(apostrophyRegx, "");
        mainModel.editModel().VisitEmailForOffical(contentHtml);
    }

    if ($(".nicEdit-main.ActionTakenOfficialEmail").text().length > maxLength)
        ret += "Observation Eamil For Sub Ordinates,<br />";
    else {
        contentHtml = $(".nicEdit-main.ActionTakenOfficialEmail").html().replace(doubleQoutesRegx, "");
        contentHtml = contentHtml.replace(commentRegex, "");
        contentHtml = contentHtml.replace(apostrophyRegx, "");
        mainModel.editModel().ActionTakenOfficialEmail(contentHtml);
    }


    if (ret != "") {
        toastr.error(ret + " should be " + maxLength + " character at max.");
        return false;
    }
    else
        return true;
}

function setTextareasValues(mainModel) {
    $(".nicEdit-main.ObservationEMailForOfficial").html(mainModel.ObservationEMailForOfficial());
    $(".nicEdit-main.ObservationEamilForSubOrdinates").html(mainModel.ObservationEamilForSubOrdinates());
    $(".nicEdit-main.VisitEmailForOffical").html(mainModel.VisitEmailForOffical());
    $(".nicEdit-main.ActionTakenOfficialEmail").html(mainModel.ActionTakenOfficialEmail());
}

function clearTextareasValues() {
    $(".nicEdit-main.ObservationEMailForOfficial").html('');
    $(".nicEdit-main.ObservationEamilForSubOrdinates").html('');
    $(".nicEdit-main.VisitEmailForOffical").html('');
    $(".nicEdit-main.ActionTakenOfficialEmail").html('');
}

$(document).ready(function () {
    $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });

    var nicEditConfig = {
        buttonList: ['save', 'bold', 'italic', 'underline', 'left', 'center', 'right', 'justify', 'ol', 'ul', 'fontSize', 'fontFamily', 'fontFormat', 'forecolor']
    };

    bkLib.onDomLoaded(function () { new nicEditor(nicEditConfig).panelInstance('area1'); });
    bkLib.onDomLoaded(function () { new nicEditor(nicEditConfig).panelInstance('area2'); });
    bkLib.onDomLoaded(function () { new nicEditor(nicEditConfig).panelInstance('area3'); });
    bkLib.onDomLoaded(function () { new nicEditor(nicEditConfig).panelInstance('area4'); });

    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Rating.aspx/GetRecord",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new RatingModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new RatingModel(null));
            }
            clearTextareasValues();
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}