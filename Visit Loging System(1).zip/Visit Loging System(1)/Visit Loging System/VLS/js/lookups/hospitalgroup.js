﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        //ko.utils.registerEventHandler(element, "blur", function () {
        //    $(element).validationEngine('validate');
        //});

        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

//Model to Set the Variable for Object model
function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    if (items != null) {
        ref_all_rec = [];
        // Filling of array for grid
        if (items.HospitalType != null) {
            ko.utils.arrayForEach(items.HospitalType, function (item) {
                self.allRecords.push(new HospitalTypeModel(item));
                ref_all_rec.push(new HospitalTypeModel(item));
            });

        }

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new HospitalTypeModel(item);
        self.editModel(new HospitalTypeModel(item));
        self.allRecords.remove(item);
        self.isEdit(true);
    };

    // Cancel the Edit  Record  And Cancel the Fields
    self.cancelRecord = function () {
        self.editModel(new HospitalTypeModel(null));
        self.allRecords.push(refModel);
        self.isEdit(false);
        LoadRecord();
    };

    self.removeRecord = function (item) {
        //if (getConfirmation()) {
        $.ajax({
            url: "HospitalType.aspx/RemoveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    item.Status(false);
                    LoadRecord();
                    //NotifyMe("inactivesuccess");
                }
            },
            error: function (er, _rr) {
                NotifyMe("error|" + er.statusText);
            }
        });
        //}
    };

    // Save Record in DB
    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "HospitalType.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d != null) {
                            var mod = new HospitalTypeModel(data.d);
                            self.allRecords.unshift(mod);
                            self.editModel(new HospitalTypeModel(null));
                            self.isEdit(false);
                            LoadRecord();
                            //NotifyMe("saverecordSuccess");
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    // Filter the Record from Title and Description
    self.Filter = function () {

        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {
                
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }
}

// Object Model class 
function HospitalTypeModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Code = ko.observable(ko.utils.unwrapObservable(item.Code));
        self.TitleUrdu = ko.observable(ko.utils.unwrapObservable(item.TitleUrdu));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
    }
    else {
        self.ID = ko.observable();
        self.Title = ko.observable();
        self.Code = ko.observable();
        self.TitleUrdu = ko.observable();
        self.Description = ko.observable();
        self.Status = ko.observable(true);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
 //   $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

//Load Record form DB
function LoadRecord() {
    $.ajax({
        url: "HospitalType.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new HospitalTypeModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new HospitalTypeModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}