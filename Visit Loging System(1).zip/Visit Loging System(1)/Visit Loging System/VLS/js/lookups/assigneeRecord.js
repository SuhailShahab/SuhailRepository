﻿var viewModel = new ViewModel();
var ref_all_Designations = [];
var ref_all_Departments = [];

function wrapperModel(item) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.DepartmentID = ko.observable(0);
    self.Departments = ko.observableArray();    
    self.AssigneeRecords = ko.observableArray();
    self.editModel = ko.observable();
    if (item != null) {
       
        if (item.Departments != null) {
            ko.utils.arrayForEach(item.Departments, function (itm) {
                self.Departments.push(new CommonModel(itm));
                ref_all_Departments.push(new CommonModel(itm));
            });
        }

        if (item.Designations != null) {
            ko.utils.arrayForEach(item.Designations, function (itm) {
                ref_all_Designations.push(new CommonModel(itm));

            });
        }

        self.DepartmentID = ko.observable(item.DepartmentID||0);
        self.AssigneeRecords.push(new AssigneeRecordModel(null));
       
    }


    self.DepartmentID.subscribe(function (newValue) {

        if (newValue > 0) {


            $.ajax({
                url: "AssigneeRecord.aspx/GetRecordByDepartmentID",
                type: 'POST',
                data: "{departmentID : '" + newValue + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    self.AssigneeRecords([]);
                    if (data.d.AssigneeRecords != null) {
                        ko.utils.arrayForEach(data.d.AssigneeRecords, function (itm) {
                            self.AssigneeRecords.push(new AssigneeRecordModel(itm));

                        });
                    }

                    else {
                        self.AssigneeRecords([]);
                        self.AssigneeRecords.push(new AssigneeRecordModel(null));
                    }


                },
                error: function (request) {
                }
            });
        }

    });

    self.addItem = function () {
        self.AssigneeRecords.push(new AssigneeRecordModel(null));
    }

    

    self.removeItem = function (item) {
        if (this.RecordID() > 0)
        {
            if (confirm('Are you sure you want to delete this item?')) {

                
                $.ajax({
                    url: "AssigneeRecord.aspx/RemoveRecord",
                    type: 'POST',
                    data: "{removeItem : '" + this.RecordID() + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {

                        if(NotifyMe(data.d))
                        {
                            self.AssigneeRecords.remove(item);
                        }
                        
                    },
                    error: function (request) {
                        alert(Error);
                    }
                });

            }
        }
        else
        {
            self.AssigneeRecords.remove(this);
        }

       
    }
    
    self.saveRecord = function () {

        self.editModel = ko.observable(new SaveRecordModel(self));
    

        $.ajax({
            url: "AssigneeRecord.aspx/SaveRecord",
            type: 'POST',
            data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {

                if (NotifyMe(data.d.Notification)) {

                    NotifyMe("success|Save Successfully.");
                    LoadRecord();
                }
            },
            error: function (request) {
            }
        });
    }

    self.getRecordByDepartID = function () {

        if (viewModel.main().DepartmentID() > 0) {


            $.ajax({
                url: "AssigneeRecord.aspx/GetRecordByDepartmentID",
                type: 'POST',
                data: "{departmentID : '" + ko.toJSON(viewModel.main().DepartmentID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    self.AssigneeRecords([]);
                    if (data.d.AssigneeRecords != null) {
                        ko.utils.arrayForEach(data.d.AssigneeRecords, function (itm) {
                            self.AssigneeRecords.push(new AssigneeRecordModel(itm));

                        });
                    }

                   
                },
                error: function (request) {
                }
            });
        }
    }

    self.cancelRecord = function () {
        self.AssigneeRecords([]);
        self.Departments([])
        self.DepartmentID(0);
        self.AssigneeRecords.push(new AssigneeRecordModel(null));
        self.Departments(ref_all_Departments);
        LoadRecord();
    }


}


function CommonModel(item) {
    var self = this;
    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));

    }
    else {
        self.ID = ko.observable();
        self.Title = ko.observable();

    }
}

function AssigneeRecordModel(item) {
    var self = this;
    self.Designations = ko.observable(ref_all_Designations);
  
    if (item != null) {
        self.DesignationID = ko.observable(ko.utils.unwrapObservable(item.DesignationID));
        self.RecordID = ko.observable(ko.utils.unwrapObservable(item.RecordID) || 0);
        self.SortOrder = ko.observable(ko.utils.unwrapObservable(item.SortOrder) || 0);
    }
    else {

        self.DesignationID = ko.observable(0);
        self.RecordID = ko.observable(0);
        self.SortOrder = ko.observable(0);
    
    }
    
}

function SaveRecordModel(item)
{
    var self = this;
    self.AssigneeRecords = ko.observableArray();
    self.DepartmentID = ko.observable(0);

    if (item != null) {
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.AssigneeRecords = ko.observable(ko.utils.unwrapObservable(item.AssigneeRecords));        
    }
  

}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
  //  $('form').validationEngine('attach', { promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "AssigneeRecord.aspx/GetRecord", 
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new SaveRecordModel(null));
            }
            else {
                viewModel.main(new wrapperModel(null));
                viewModel.main().editModel(new SaveRecordModel(null));
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}


