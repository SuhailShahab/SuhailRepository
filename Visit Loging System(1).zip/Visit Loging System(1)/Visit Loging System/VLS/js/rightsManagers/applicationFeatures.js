﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var hasChildes = [{ 'Title': 'Yes', 'ID': true }, { 'Title': 'No', 'ID': false }];
var menuLocations = [{ 'Title': 'Main Menu', 'ID': '1' }, { 'Title': 'Operational Menu', 'ID': '2' }];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();

    if (items != null) {
        ref_all_rec = [];
        ko.utils.arrayForEach(items, function (item) {
            self.allRecords.push(new FeaturesModel(item));
            ref_all_rec.push(new FeaturesModel(item))
        });

        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new FeaturesModel(item);
        self.editModel(new FeaturesModel(item));
        self.allRecords.remove(item);
        self.isEdit(true);
    };

    self.cancelRecord = function () {
        self.editModel(new FeaturesModel(null));
        self.allRecords.push(refModel);
        self.isEdit(false);
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "ApplicationFeatures.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                    if (data.d.ID > 0) {
                        var mod = new FeaturesModel(data.d);
                        self.allRecords.unshift(mod);
                        self.editModel(new FeaturesModel(null));
                        self.isEdit(false);
                        LoadRecord();
                        //NotifyMe("saverecordSuccess");
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    };

    //self.removeRecord = function (item) {
    //    if (getConfirmation()) {
    //        $.ajax({
    //            url: "ApplicationFeature.aspx/RemoveRecord",
    //            type: 'POST',
    //            data: "{jsonModel : '" + ko.toJSON(item) + "'}",
    //            dataType: "json",
    //            contentType: "application/json; charset=utf-8",
    //            success: function (data) {
    //                if (data.d == "true") {
    //                    item.IsActive(false);
    //                    NotifyMe("inactivesuccess");
    //                }
    //                else if (data.d != "true" && data.d != "false") {
    //                    NotifyMe(data.d);
    //                }
    //            },
    //            error: function (request) {
    //                alert(Error);
    //            }
    //        });
    //    }
    //};

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                return item.MenuName().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Name().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;

            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    };

}

function FeaturesModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.MenuName = ko.observable(ko.utils.unwrapObservable(item.MenuName));
        self.Name = ko.observable(ko.utils.unwrapObservable(item.Name));
        self.URL = ko.observable(ko.utils.unwrapObservable(item.URL));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.HasChild = ko.observable(ko.utils.unwrapObservable(item.HasChild));

        self.menuLocation = ko.observable(ko.utils.unwrapObservable(item.menuLocation));
        self.Sort = ko.observable(ko.utils.unwrapObservable(item.Sort));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));

        self.arrHasChildes = ko.observableArray(hasChildes);
        self.arrMenuLocations = ko.observableArray(menuLocations);
        self.Icon = ko.observable(ko.utils.unwrapObservable(item.Icon));

    }
    else {
        self.ID = ko.observable();
        self.MenuName = ko.observable();
        self.Name = ko.observable();
        self.URL = ko.observable('');
        self.Description = ko.observable('');
        self.HasChild = ko.observable();
        self.Icon = ko.observable('');

        self.menuLocation = ko.observable();
        self.Sort = ko.observable(0);
        self.Status = ko.observable(true);

        self.arrHasChildes = ko.observableArray(hasChildes);
        self.arrMenuLocations = ko.observableArray(menuLocations);
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine({ promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "ApplicationFeatures.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new wrapperModel(data.d));
            viewModel.main().editModel(new FeaturesModel(null));
        },
        error: function (request) {
        }
    });
}