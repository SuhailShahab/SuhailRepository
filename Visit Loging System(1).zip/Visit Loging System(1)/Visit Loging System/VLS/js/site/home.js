﻿
var apostrophyRegx = new RegExp("'", "g");
var viewModel = new ViewModel();

function WrapperModel(items) {
    var self = this;
    self.Contacts = ko.observableArray();
    self.SMS = ko.observable('');
    self.CheckedAll = ko.observable(false);

    if (items != null) {
        ko.utils.arrayForEach(items, function (itm) {
            self.Contacts.push(new ContactModel(itm));
        });
    }

    self.CheckedAll.subscribe(function (newValue) {
        if (newValue) {
            ko.utils.arrayForEach(self.Contacts(), function (itm) {
                itm.Checked(true);
            });
        }
        else {
            ko.utils.arrayForEach(self.Contacts(), function (itm) {
                itm.Checked(false);
            });
        }
    });

    self.CharacterCount = ko.computed(function () {
        return (300 - parseInt(self.SMS().length)) < 0 ? 'Limit Exceeded' : 300 - parseInt(self.SMS().length);
    });

    self.validateMaxLength = function (data, event) {
        var code = (event.keyCode) ? event.keyCode : event.which;
        if ((code == 65 && event.ctrlKey === true) ||
                // Allow: Ctrl+C
                (code == 67 && event.ctrlKey === true) ||
                // Allow: Ctrl+X
                (code == 88 && event.ctrlKey === true) ||
                // Allow: Ctrl+V
                (code == 86 && event.ctrlKey === true)) {
            // let it happen, don't do anything
           return false;
        }
        else {
            return self.SMS().length > 299 && code != 8 && code != 46 ? false : true;
        }

    }

    self.sendSMS = function () {
        if ($(".chkSMS:checked").length > 0) {
            $('#overlay').show();
            var jsonSr = ko.toJSON(viewModel.main()).replace(apostrophyRegx, "");
            $.ajax({
                url: "Home.aspx/SendSMS",
                type: 'POST',
                dataType: "json",
                data: "{jsonModel : '" + jsonSr + "'}",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    viewModel.main(new WrapperModel(null));
                    $("#modalSMS").modal('hide');
                    toastr.success(data.d);
                    $('#overlay').hide();
                },
                error: function (request) {
                    console.log(request.responseText);
                }
            });
        }
        else {
            toastr.error("Please select secretary to send SMS.");
        }
    }
}

function ContactModel(contact) {
    var self = this;
    self.ID = ko.observable(contact.ID);
    self.Name = ko.observable(contact.Name);
    self.Department = ko.observable(contact.Department);
    self.CellNumber = ko.observable(contact.CellNumber);
    self.Checked = ko.observable(contact.Checked || false);
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}


var html = "";
$(function () {
    $.ajax({
        url: "Home.aspx/GetRecord",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                if (data.d.allRecords != null) {
                    $.each(data.d.allRecords, function (idx, itm) {
                        var title = itm.Title.toString().length > 71 ? itm.Title.toString().substr(0, 71) + '...' : itm.Title;
                        html += '<li>' +
                             '<section class="news-thumb">' +
                        '<img src=' + itm.Image + ' width="50" height="50" />' +
                   '</section>' +
                   '<section class="news-title">' +
                        '<p>' + title + '</p>' +
                        '<label class="news-date">' + moment(new Date(parseInt(itm.NewsDate.substring(6, 19)))).format('DD MMM, YYYY') + '</label>' +
                        '<a href="../../ContentPages/VLS/NewsDetail.aspx?newsID=' + itm.ID + '">Read more...</a></section></li>';
                    });
                    $('.news-ticker > ul').append(html);
                    $('.news-ticker').vTicker();
                }

                if (data.d.Reports != null) {
                    html = '';
                    $.each(data.d.Reports, function (idx, itm) {
                        html += '<li><a target="_blank" href=' + itm.URL + '>' + itm.Name + '</a></li>';
                    });
                    $('.reports-link > ul').append(html);
                }
                else {
                    $('.reports-link').hide();
                }

                if (data.d != null) {
                    $("#vision").text(data.d.Vision || '');
                    $("#mission").text(data.d.Mission || '');
                    $("#governance").text(data.d.Governance || '');
                }
            }
        },
        error: function (er, _rr) {
            console.log("error|" + er.statusText);
        }
    });

    $(".btn-sms").on('click', function () {
        LoadRecord();
        return false;
    });


    $('body').on('click', 'a.btnResize', function (event) {
        var modalID = "#" + $(this).attr("aria-label");
        if ($(this).attr("data-resize") == "restore") {
            $(modalID).removeClass("bs-example-modal-lg").addClass("bs-example-modal-xlg");
            $(modalID + " > .modal-dialog").removeClass("modal-lg").addClass("modal-xlg");
            $(this).attr("data-resize", "maximize").find("i").removeClass("fa fa-expand").addClass("fa fa-compress");
        }
        else {
            $(modalID).removeClass("bs-example-modal-xlg").addClass("bs-example-modal-lg");
            $(modalID + " > .modal-dialog.modal-xlg").removeClass("modal-xlg");
            $(this).attr("data-resize", "restore").find("i").removeClass("fa fa-compress").addClass("fa fa-expand");
        }
    });

    viewModel.main(new WrapperModel(null));
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Home.aspx/GetSecretariesContactList",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new WrapperModel(data.d));
            $("#modalSMS").modal('show');
        },
        error: function (request) {
            console.log(request.responseText);
        }
    });

}