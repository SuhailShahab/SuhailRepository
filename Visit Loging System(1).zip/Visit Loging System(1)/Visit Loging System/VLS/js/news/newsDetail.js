﻿var viewModel = new ViewModel();

function NewsModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.Image = ko.observable(ko.utils.unwrapObservable(item.Image));
        self.NewsDate = ko.observable(ko.utils.unwrapObservable(item.NewsDate) != null ? parseInt(ko.utils.unwrapObservable(item.NewsDate).toString().substring(6, 19)) > 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(item.NewsDate).toString().substring(6, 19)))).format('DD MMM, YYYY') : '' : '');
    }
    else {
        self.ID = ko.observable();
        self.Title = ko.observable();
        self.Description = ko.observable('');
        self.Status = ko.observable(true);
        self.Image = ko.observable('');
        self.NewsDate = ko.observable();
    }
}


function ViewModel() {
    var self = this;
    self.main = ko.observable();
}


$(document).ready(function () {
    var newsID = 0;
    newsID = GetQueryString("newsID") || 0;
    LoadRecord(newsID);
    ko.applyBindings(viewModel);

});

function LoadRecord(newsID) {
    newsID = newsID || 0;
    $.ajax({
        url: "NewsDetail.aspx/GetRecordByID",
        type: 'POST',
        dataType: "json",
        data: "{ ID: '" + newsID + "' }",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                if (data.d != null) {
                    viewModel.main(new NewsModel(data.d));
                }
            }
        },
        error: function (er, _rr) {
            NotifyMe("error|" + er.statusText);
        }
    });
}


function GetQueryString(key) {
    var value = "";
    var PageURL = decodeURIComponent(window.location.search.substring(1));
    var sURLVariables = PageURL.split('&');

    for (var i = 0; i < sURLVariables.length; i++) {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0].toLowerCase() == key.toLowerCase()) {
            value = sParameterName[1];
        }
    }
    return value;
}