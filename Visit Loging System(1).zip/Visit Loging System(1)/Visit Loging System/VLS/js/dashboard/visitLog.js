﻿

var ref_districts = [];
var viewModel = new ViewModel();

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function wrapperModel(items) {
    var self = this;

    self.IsAllowedToEdit = ko.observable(false);
    self.isExpand = ko.observable(false);
    self.filterDistrict = ko.observable();
    self.filterDesignation = ko.observable();

    self.Divisions = ko.observableArray();
    self.Districts = ko.observableArray();
    self.Departments = ko.observableArray();
    self.Designations = ko.observableArray();
    self.Facilities = ko.observableArray();

    self.DistrictLogs = ko.observableArray();
    self.AllDistrictCounts = ko.observableArray();

    //self.DepartmentLogs = ko.observableArray();
    self.RatingHeader = ko.observableArray();
    self.Images = ko.observableArray();
    self.DivisionID = ko.observable();
    self.DistrictID = ko.observable();
    self.DepartmentID = ko.observable();
    self.DesignationID = ko.observable();
    self.FacilityID = ko.observable();
    self.DesignationFacilityID = ko.observable();

    self.SelectedDesignation = ko.observable();

    self.PageSize = ko.observable(100);

    if (items != null) {

        self.IsAllowedToEdit = items.IsAllowedToEdit;

        if (items.RatingHeader != null) {
            self.RatingHeader([]);
            ko.utils.arrayForEach(items.RatingHeader, function (itm) {
                self.RatingHeader.push(new RatingModel(itm));
            });
        }

        if (items.DepartmentFacilities != null) {
            ko.utils.arrayForEach(items.DepartmentFacilities, function (itm) {
                self.Facilities.push(new CommonModel(itm));
            });
        }

        if (items.Designations != null) {
            ko.utils.arrayForEach(items.Designations, function (itm) {
                self.Designations.push(new DesignationModel(itm));
            });
        }

        if (items.DistrictLogs != null) {
            ko.utils.arrayForEach(items.DistrictLogs, function (itm) {
                self.DistrictLogs.push(new DistrictLogModel(itm));
            });
        }

        //if (items.DepartmentLogs != null) {
        //    ko.utils.arrayForEach(items.DepartmentLogs, function (itm) {
        //        self.DepartmentLogs.push(new DepartmentLogModel(itm));
        //    });
        //}

        if (items.Divisions != null) {
            ko.utils.arrayForEach(items.Divisions, function (itm) {
                self.Divisions.push(new DivisionModel(itm));
            });
        }

        if (items.Districts != null) {
            ref_districts = [];
            ko.utils.arrayForEach(items.Districts, function (itm) {
                self.Districts.push(new DistrictModel(itm));
                ref_districts.push(new DistrictModel(itm));
            });
        }

        if (items.Departments != null) {
            ko.utils.arrayForEach(items.Departments, function (itm) {
                self.Departments.push(new DepartmentModel(itm));
            });
        }



        self.PageSize(100);
        //var clientpagerDepartmentLogs = new ko.bindingHandlers.pagedForeach.ClientPager(self.DepartmentLogs(), null, self.PageSize());
        var clientpagerDistrictLogs = new ko.bindingHandlers.pagedForeach.ClientPager(self.DistrictLogs(), null, self.PageSize());
    }


    self.DivisionID.subscribe(function (newValue) {
        if (newValue != undefined) {
            var filterDist = ko.utils.arrayFilter(ref_districts, function (dist) {
                return ko.utils.unwrapObservable(dist.DivisionID) == ko.utils.unwrapObservable(newValue);
            });
            self.Districts(filterDist);
        }
        else {
            self.Districts(ref_districts);
        }
    });

    self.getRateDetail = function (name, rate, mod) {
        var rateID = getIDbyName(name);

        $.ajax({
            url: "VisitLog.aspx/GetDistrictRatingLogDetail",
            type: 'POST',
            dataType: "json",
            data: "{DivisionID: '" + mod.DivisionID() + "', DistrictID: '" + mod.DistrictID() + "', RatingID: '" + rateID + "', FacilityID: '" + viewModel.main().FacilityID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && NotifyMe(data.d.Notification) && data.d.LogDetail != null) {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d.LogDetail, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                    self.isExpand(true);
                }
            },
            error: function (request) {
            }
        });
    }

    self.getCompleteRateDetail = function (idx, mod) {
        $.ajax({
            url: "VisitLog.aspx/GetDistrictRatingLogDetail",
            type: 'POST',
            dataType: "json",
            data: "{DivisionID: '" + mod.DivisionID() + "', DistrictID: '" + mod.DistrictID() + "', RatingID: '" + 0 + "', FacilityID: '" + viewModel.main().FacilityID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d != '') {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                    self.isExpand(true);
                }
            },
            error: function (request) {
            }
        });

        //ko.utils.arrayForEach(logDetail, function (detail) {
        //    mod.RatingDetails.push(new RatingDetailModel(detail));
        //});

        //log.DistrictCount(parseInt(parseInt(log.DistrictCount()) + 1));
    }

    self.hideRateDetail = function (idx, mod) {
        mod.RatingDetails([]);
        self.filterDistrict('');
        self.isExpand(false);
    }

    //self.getDepartmentRateDetail = function (name, rate, mod) {
    //    var rateID = getIDbyName(name);
    //    $.ajax({
    //        url: "VisitLog.aspx/GetDepartmentRatingLogDetail",
    //        type: 'POST',
    //        dataType: "json",
    //        data: "{DepartmentID: '" + mod.DepartmentID() + "', RatingID: '" + rateID + "' }",
    //        contentType: "application/json; charset=utf-8",
    //        success: function (data) {
    //            if (data.d != null && data.d != '') {
    //                mod.RatingDetails([]);
    //                ko.utils.arrayForEach(data.d, function (detail) {
    //                    mod.RatingDetails.push(new RatingDetailModel(detail));
    //                });
    //            }
    //        },
    //        error: function (request) {
    //        }
    //    });
    //}

    //self.getDepartmentCompleteRateDetail = function (idx, mod) {
    //    $.ajax({
    //        url: "VisitLog.aspx/GetDepartmentRatingLogDetail",
    //        type: 'POST',
    //        dataType: "json",
    //        data: "{DepartmentID: '" + mod.DepartmentID() + "', RatingID: '" + 0 + "' }",
    //        contentType: "application/json; charset=utf-8",
    //        success: function (data) {
    //            if (data.d != null && data.d != '') {
    //                mod.RatingDetails([]);
    //                ko.utils.arrayForEach(data.d, function (detail) {
    //                    mod.RatingDetails.push(new RatingDetailModel(detail));
    //                });
    //            }
    //        },
    //        error: function (request) {
    //        }
    //    });
    //}

    //self.hideDepartmentRateDetail = function (idx, mod) {
    //    mod.RatingDetails([]);
    //    mod.DepartmentCount(parseInt(parseInt(mod.DepartmentCount()) - 1));
    //}

    self.TotalDistrictVisits = ko.computed(function () {
        var ret = 0;
        ko.utils.arrayForEach(self.DistrictLogs(), function (itm) {
            ret = ret + parseInt(itm.TotalVisits());
        });
        return ret;
    });

    self.getfilterDistrictRecord = function (mod) {
        $.ajax({
            url: "VisitLog.aspx/GetDistrictsWiseVisitsPerformedBreakdown",
            type: 'POST',
            dataType: "json",
            data: "{DivisionID: '" + mod.DivisionID() + "', DistrictID: '" + mod.DistrictID() + "', FacilityID: '" + mod.FacilityID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                self.DistrictLogs([]);
                if (data.d.DistrictLogs != null && NotifyMe(data.d.Notification)) {
                    ko.utils.arrayForEach(data.d.DistrictLogs, function (itm) {
                        self.DistrictLogs.push(new DistrictLogModel(itm));
                    });
                }
                self.isExpand(false);
            },
            error: function (request) {
            }
        });
    }

    self.getfilterDepartmentRecord = function (mod) {
        $.ajax({
            url: "VisitLog.aspx/GetDepartmentsWiseVisitsPerformedBreakdown",
            type: 'POST',
            dataType: "json",
            data: "{departmentID: '" + mod.DepartmentID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                self.DepartmentLogs([]);
                if (data.d.DepartmentLogs != null && NotifyMe(data.d.Notification)) {
                    ko.utils.arrayForEach(data.d.DepartmentLogs, function (itm) {
                        self.DepartmentLogs.push(new DepartmentLogModel(itm));
                    });
                }
                self.isExpand(false);
            },
            error: function (request) {
            }
        });
    }

    self.getDesignationFacilityData = function (mod) {
        $.ajax({
            url: "DashboardCM.aspx/GetDesignationByFacility",
            type: 'POST',
            dataType: "json",
            data: "{FacilityID : '" + ko.toJSON(mod.DesignationFacilityID()) + "'}",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d != '') {
                    self.Designations([]);
                    ko.utils.arrayForEach(data.d, function (itm) {
                        self.Designations.push(new DesignationModel(itm));
                    });
                }
                self.isExpand(false);
            },
            error: function (er, _rr) {
                console.log("error|" + er.statusText);
            }
        });
    }
}

function ImageModel(img) {
    var self = this;
    self.ImageID = ko.observable(img.ImageID);
    self.ImageTitle = ko.observable(img.ImageTitle);
    self.ImageDescription = ko.observable(img.ImageDescription);
    self.VisitorLogImage = ko.observable(img.VisitorLogImage);

    self.VisitedDate = ko.observable(img.VisitedDate != null ? parseInt(img.VisitedDate.toString().substring(6, 19)) > 0 ? moment(new Date(parseInt(img.VisitedDate.toString().substring(6, 19)))).format('DD-MMM-YYYY hh:mm A') : '-' : '-');
    self.VistedDepartmentName = ko.observable(img.VistedDepartmentName);
    self.Place = ko.observable(img.Place);
    self.VisitedBy = ko.observable(img.VisitedBy);
}

function DesignationModel(desg) {
    var self = this;
    self.ID = ko.observable(desg.ID);
    self.Title = ko.observable(desg.Title);
    self.Checked = ko.observable(desg.Checked);

    self.DesignationLogs = ko.observableArray();

    self.getDesignationWiseLog = function (mod) {
        if (!$("#collapse" + mod.ID()).hasClass("in")) {
            $.ajax({
                url: "VisitLog.aspx/GetDesignationWiseVisitsPerformedBreakdown",
                type: 'POST',
                dataType: "json",
                data: "{DesignationID: '" + mod.ID() + "', FacilityID: '" + viewModel.main().DesignationFacilityID() + "'}",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    self.DesignationLogs([]);
                    if (data.d.DesignationLogs != null && NotifyMe(data.d.Notification)) {
                        ko.utils.arrayForEach(data.d.DesignationLogs, function (itm) {
                            self.DesignationLogs.push(new DesignationLogModel(itm));
                        });
                    }
                    viewModel.main().SelectedDesignation(mod.ID());
                },
                error: function (request) {
                }
            });
        }
        else {
            viewModel.main().SelectedDesignation(null);
        }
        return false;
    };

    self.getDepartmentRateDetail = function (name, rate, mod) {
        var rateID = getIDbyName(name);
        $.ajax({
            url: "DashboardCM.aspx/GetVisitRatingDetailByUser",
            type: 'POST',
            dataType: "json",
            data: "{UserID: '" + mod.UserID() + "', DistrictID: '" + undefined + "', RateID: '" + rateID + "', FromDate: '" + undefined + "', ToDate: '" + undefined + "', FacilityID: '" + viewModel.main().DesignationFacilityID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d != '') {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                    viewModel.main().isExpand(true);
                }
            },
            error: function (request) {
            }
        });
    }

    self.getDepartmentCompleteRateDetail = function (idx, mod) {
        $.ajax({
            url: "DashboardCM.aspx/GetVisitRatingDetailByUser",
            type: 'POST',
            dataType: "json",
            data: "{UserID: '" + mod.UserID() + "', DistrictID: '" + undefined + "', RateID: '" + 0 + "', FromDate: '" + undefined + "', ToDate: '" + undefined + "', FacilityID: '" + viewModel.main().DesignationFacilityID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d != '') {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                    viewModel.main().isExpand(true);
                }
            },
            error: function (request) {
            }
        });
    };

    self.hideDepartmentRateDetail = function (idx, mod) {
        mod.RatingDetails([]);
        mod.DepartmentCount(parseInt(parseInt(mod.DepartmentCount()) - 1));
        viewModel.main().filterDesignation('');
        viewModel.main().isExpand(false);
    };
}

function DistrictLogModel(log) {
    var self = this;

    self.Division = ko.observable(log.Division);
    self.DivisionID = ko.observable(log.DivisionID);
    self.District = ko.observable(log.District);
    self.DistrictID = ko.observable(log.DistrictID);
    self.TotalVisits = ko.observable(log.TotalVisits);
    self.VeryPoor = ko.observable(log.VeryPoor);
    self.Poor = ko.observable(log.Poor);
    self.Unsatisfactory = ko.observable(log.Unsatisfactory);
    self.Average = ko.observable(log.Average);
    self.Satisfactory = ko.observable(log.Satisfactory);
    self.Good = ko.observable(log.Good);
    self.Excellent = ko.observable(log.Excellent);

    self.RatingDetails = ko.observableArray();

    self.filteredItems = ko.computed(function () {
        var filter = viewModel.main() != undefined ? viewModel.main().filterDistrict() != undefined ? viewModel.main().filterDistrict().toLowerCase() : '' : true;
        if (!filter) {
            return self.RatingDetails();
        } else {
            return ko.utils.arrayFilter(self.RatingDetails(), function (item) {
                return item.Place().toLowerCase().indexOf(filter) !== -1 ||
                       item.Department().toLowerCase().indexOf(filter) !== -1 ||
                       item.StartDate().toLowerCase().indexOf(filter) !== -1 ||
                       item.Rated().toLowerCase().indexOf(filter) !== -1;
            });
        }
    }, this);
}

function DepartmentLogModel(log) {
    var self = this;

    self.Department = ko.observable(log.Department);
    self.DepartmentID = ko.observable(log.DepartmentID);
    self.TotalVisits = ko.observable(log.TotalVisits);
    self.VeryPoor = ko.observable(log.VeryPoor);
    self.Poor = ko.observable(log.Poor);
    self.Unsatisfactory = ko.observable(log.Unsatisfactory);
    self.Average = ko.observable(log.Average);
    self.Satisfactory = ko.observable(log.Satisfactory);
    self.Good = ko.observable(log.Good);
    self.Excellent = ko.observable(log.Excellent);
    self.RatingDetails = ko.observableArray();

    self.DepartmentCount = ko.observable(1);


}

function DesignationLogModel(desig) {
    var self = this;
    self.UserID = ko.observable(desig.UserID);
    self.EmployeeName = ko.observable(desig.EmployeeName);
    self.DesignationID = ko.observable(desig.DesignationID);
    self.TotalVisits = ko.observable(desig.TotalVisits);
    self.VeryPoor = ko.observable(desig.VeryPoor);
    self.Poor = ko.observable(desig.Poor);
    self.Unsatisfactory = ko.observable(desig.Unsatisfactory);
    self.Average = ko.observable(desig.Average);
    self.Satisfactory = ko.observable(desig.Satisfactory);
    self.Good = ko.observable(desig.Good);
    self.Excellent = ko.observable(desig.Excellent);
    self.RatingDetails = ko.observableArray();

    self.DepartmentCount = ko.observable(1);

    self.filteredItems = ko.computed(function () {
        var filter = viewModel.main() != undefined ? viewModel.main().filterDesignation() != undefined ? viewModel.main().filterDesignation().toLowerCase() : '' : true;
        if (!filter) {
            return self.RatingDetails();
        } else {
            return ko.utils.arrayFilter(self.RatingDetails(), function (item) {
                return item.Place().toLowerCase().indexOf(filter) !== -1 ||
                       item.Department().toLowerCase().indexOf(filter) !== -1 ||
                       item.StartDate().toLowerCase().indexOf(filter) !== -1 ||
                       item.Rated().toLowerCase().indexOf(filter) !== -1;
            });
        }
    }, this);

}

function RatingDetailModel(detail) {
    var self = this;
    self.VisitorLogID = ko.observable(detail.VisitorLogID);
    self.TaskID = ko.observable(detail.TaskID);
    self.Place = ko.observable(detail.Place);
    self.Department = ko.observable(detail.Department);
    self.Rated = ko.observable(detail.Rated);
    self.RateID = ko.observable(detail.RateID || 0);
    self.StartDate = ko.observable(detail.StartDate != null ? parseInt(detail.StartDate.toString().substring(6, 19)) > 0 ? moment(new Date(parseInt(detail.StartDate.toString().substring(6, 19)))).format('DD-MMM-YYYY hh:mm A') : '-' : '-');
    self.HasImage = ko.observable(detail.HasImage || false);
    self.HasActionTaken = ko.observable(detail.HasActionTaken || false);

    self.getImages = function (mod) {
        $.ajax({
            url: "DashboardCM.aspx/GetVisitsLogPictures",
            type: 'POST',
            dataType: "json",
            data: "{visitorLogID : '" + mod.VisitorLogID() + "'}",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                viewModel.main().Images([]);
                if (data.d != null && NotifyMe(data.d.Notification) && data.d.ActionImageModel != null) {
                    ko.utils.arrayForEach(data.d.ActionImageModel, function (itm) {
                        viewModel.main().Images.push(new ImageModel(itm));
                    });
                }
                $('#modalImages').modal('show');
            },
            error: function (er, _rr) {
                console.log("error|" + er.statusText);
            }
        });
        // $('#modalImages').modal('show');
    }
}

function RatingModel(rate) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(rate.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(rate.Title));
    self.VisitCount = ko.observable(ko.utils.unwrapObservable(rate.VisitCount) || 0);
}

function DistrictCountModel(dist) {
    var self = this;
    self.DivisionID = ko.observable(dist.DivisionID);
    self.Count = ko.observable(dist.Count);
}

function DivisionModel(div) {
    var self = this;
    self.ID = ko.observable(div.ID);
    self.Title = ko.observable(div.Title);
}

function CommonModel(itm) {
    var self = this;
    self.ID = ko.observable(itm.ID);
    self.Title = ko.observable(itm.Title);
}

function DistrictModel(dist) {
    var self = this;
    self.ID = ko.observable(dist.ID);
    self.DivisionID = ko.observable(dist.DivisionID);
    self.Title = ko.observable(dist.Title);
}

function DepartmentModel(dept) {
    var self = this;
    self.ID = ko.observable(dept.ID);
    self.Title = ko.observable(dept.Title);
}

$(document).ready(function () {
    LoadRecord(new wrapperModel(null));
    ko.applyBindings(viewModel);
});


function getIDbyName(name) {
    return ko.utils.arrayFilter(viewModel.main().RatingHeader(), function (rat) {
        return rat.Title().toString().toLowerCase() === name.toLowerCase();
    })[0].ID();
}

function LoadRecord(mod) {
    $.ajax({
        url: "VisitLog.aspx/GetAllVisitsPerformedBreakdown",
        type: 'POST',
        dataType: "json",
        data: "{ DivisionID: '" + mod.DivisionID() + "', DistrictID: '" + mod.DistrictID() + "', DepartmentID: '" + mod.DepartmentID() + "', FacilityID: '" + mod.FacilityID() + "' }",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
            }
        },
        error: function (request) {
        }
    });
}