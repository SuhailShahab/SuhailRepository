﻿////var jsondata = [
////  {
////      "division": "lahore",
////      "id": 1,
////      "count": 2,
////      "district": [
////        {
////            "title": "lahore-1",
////            "id": 1,
////            "total": 2,
////            "rating": [
////              {
////                  "title": "bad",
////                  "total": 2
////              },
////              {
////                  "title": "good",
////                  "total": 1
////              }
////            ]
////        },
////        {
////            "title": "lahore-2",
////            "id": 2,
////            "total": 4,
////            "rating": [
////              {
////                  "title": "bad",
////                  "total": 3
////              },
////              {
////                  "title": "good",
////                  "total": 1
////              }
////            ]
////        }
////      ]
////  },
////  {
////      "division": "rawalpindi",
////      "id": 2,
////      "count": 2,
////      "district": [
////        {
////            "title": "rawalpindi-1",
////            "id": 1,
////            "total": 2,
////            "rating": [
////              {
////                  "title": "bad",
////                  "total": 2
////              },
////              {
////                  "title": "good",
////                  "total": 1
////              }
////            ]
////        },
////        {
////            "title": "rawalpindi-2",
////            "id": 2,
////            "total": 4,
////            "rating": [
////              {
////                  "title": "bad",
////                  "total": 3
////              },
////              {
////                  "title": "good",
////                  "total": 1
////              }
////            ]
////        }
////      ]
////  }
////];

var jsonData = {
    "AllDistrictCounts":
        [
            { "DivisionID": 1, "Count": 2 }, { "DivisionID": 2, "Count": 2 }, { "DivisionID": 3, "Count": 2 }
        ],
    "RatingHeader":
        [
            { "Title": "Good" }, { "Title": "Poor" }, { "Title": "Bad" }
        ],
    "DistrictLogs": [
                {
                    "Division": "Lahore",
                    "DivisionID": 1,
                    "District": "Lahore City",
                    "DistrictID": 1,
                    "TotalVisits": 20,
                    "Rating": [
                        {
                            "Title": "Good",
                            "Value": 3
                        },
                        {
                            "Title": "Poor",
                            "Value": 4
                        },
                        {
                            "Title": "Bad",
                            "Value": 1
                        }
                    ]
                },
            {
                "Division": "Lahore",
                "DivisionID": 1,
                "District": "Gulberg",
                "DistrictID": 2,
                "TotalVisits": 12,
                "Rating": [
            {
                "Title": "Good",
                "Value": 3
            },
            {
                "Title": "Poor",
                "Value": 4
            },
            {
                "Title": "Bad",
                "Value": 1
            }
                ]
            },
            {
                "Division": "Lahore",
                "DivisionID": 1,
                "District": "Defence",
                "DistrictID": 3,
                "TotalVisits": 6,
                "Rating": [
                            {
                                "Title": "Good",
                                "Value": 3
                            },
                            {
                                "Title": "Poor",
                                "Value": 4
                            },
                            {
                                "Title": "Bad",
                                "Value": 1
                            }
                ]
            },
            {
                "Division": "Faisalabad",
                "DivisionID": 2,
                "District": "Madina Town",
                "DistrictID": 4,
                "TotalVisits": 6,
                "Rating": [
            {
                "Title": "Good",
                "Value": 3
            },
            {
                "Title": "Poor",
                "Value": 4
            },
            {
                "Title": "Bad",
                "Value": 1
            }
                ]
            },
            {
                "Division": "Faisalabad",
                "DivisionID": 2,
                "District": "People Colony",
                "DistrictID": 5,
                "TotalVisits": 16,
                "Rating": [
            {
                "Title": "Good",
                "Value": 3
            },
            {
                "Title": "Poor",
                "Value": 12
            },
            {
                "Title": "Bad",
                "Value": 1
            }
                ]
            }
    ]
};

var logDetail = [{ "Place": "Arfa Software Technology Board", "Department": "Finance", "Rate": "Poor" },
                 { "Place": "Metro Bus Station", "Department": "Ticketing", "Rate": "Bad" }];
var ref_districts = [];
var viewModel = new ViewModel();

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function wrapperModel(items) {
    var self = this;

    self.Divisions = ko.observableArray();
    self.Districts = ko.observableArray();
    self.Departments = ko.observableArray();
    self.RatingHeader = ko.observableArray();

    self.DistrictLogs = ko.observableArray();
    self.AllDistrictCounts = ko.observableArray();

    self.DepartmentLogs = ko.observableArray();

    self.DivisionID = ko.observable();
    self.DistrictID = ko.observable();
    self.DepartmentID = ko.observable();

    self.PageSize = ko.observable(10);

    if (items != null) {

        if (items.RatingHeader != null) {
            ref_ratingHeader = [];
            ko.utils.arrayForEach(items.RatingHeader, function (itm) {
                self.RatingHeader.push(new RatingModel(itm));
                ref_ratingHeader.push(new RatingModel(itm));
            });
        }

        if (items.DistrictLogs != null) {
            ko.utils.arrayForEach(items.DistrictLogs, function (itm) {
                self.DistrictLogs.push(new DistrictLogModel(itm));
            });
        }

        if (items.DepartmentLogs != null) {
            ko.utils.arrayForEach(items.DepartmentLogs, function (itm) {
                self.DepartmentLogs.push(new DepartmentLogModel(itm));
            });
        }

        if (items.Divisions != null) {
            ko.utils.arrayForEach(items.Divisions, function (itm) {
                self.Divisions.push(new DivisionModel(itm));
            });
        }

        if (items.Districts != null) {
            ref_districts = [];
            ko.utils.arrayForEach(items.Districts, function (itm) {
                self.Districts.push(new DistrictModel(itm));
                ref_districts.push(new DistrictModel(itm));
            });
        }

        if (items.Departments != null) {
            ko.utils.arrayForEach(items.Departments, function (itm) {
                self.Departments.push(new DepartmentModel(itm));
            });
        }

        if (items.AllDistrictCounts != null) {
            ko.utils.arrayForEach(items.AllDistrictCounts, function (itm) {
                self.AllDistrictCounts.push(new DistrictCountModel(itm));
            });
        }

        self.PageSize(10);
        var clientpagerDepartmentLogs = new ko.bindingHandlers.pagedForeach.ClientPager(self.DepartmentLogs(), null, self.PageSize());
    }

    self.RatingsTotal = ko.observableArray();
    setDistrictCount(self);

    self.DivisionID.subscribe(function (newValue) {
        if (newValue != undefined) {
            var filterDist = ko.utils.arrayFilter(ref_districts, function (dist) {
                return ko.utils.unwrapObservable(dist.DivisionID) == ko.utils.unwrapObservable(newValue);
            });
            self.Districts(filterDist);
        }
        else {
            self.Districts(ref_districts);
        }
    });

    self.getRateDetail = function (mod, idx, rate) {
        var log = getDivisionFirstIndex(self, idx);

        $.ajax({
            url: "VisitReportObservation.aspx/GetDistrictRatingLogDetail",
            type: 'POST',
            dataType: "json",
            data: "{DivisionID: '" + mod.DivisionID() + "', DistrictID: '" + mod.DistrictID() + "', RatingID: '" + rate.ID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d != '') {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                    log.DistrictCount(parseInt(parseInt(log.DistrictCount()) + 1));
                }
            },
            error: function (request) {
            }
        });

        //ko.utils.arrayForEach(logDetail, function (detail) {
        //    mod.RatingDetails.push(new RatingDetailModel(detail));
        //});

        //log.DistrictCount(parseInt(parseInt(log.DistrictCount()) + 1));
    }

    self.getCompleteRateDetail = function (idx, mod) {
        var log = getDivisionFirstIndex(self, idx);
        $.ajax({
            url: "VisitReportObservation.aspx/GetDistrictRatingLogDetail",
            type: 'POST',
            dataType: "json",
            data: "{DivisionID: '" + mod.DivisionID() + "', DistrictID: '" + mod.DistrictID() + "', RatingID: '" + 0 + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && NotifyMe(data.d.Notification) && data.d.LogDetail != null) {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d.LogDetail, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                    log.DistrictCount(parseInt(parseInt(log.DistrictCount()) + 1));
                }
            },
            error: function (request) {
            }
        });

        //ko.utils.arrayForEach(logDetail, function (detail) {
        //    mod.RatingDetails.push(new RatingDetailModel(detail));
        //});

        //log.DistrictCount(parseInt(parseInt(log.DistrictCount()) + 1));
    }

    self.hideRateDetail = function (idx, mod) {
        mod.RatingDetails([]);
        var log = getDivisionFirstIndex(self, idx);
        log.DistrictCount(parseInt(parseInt(log.DistrictCount()) - 1));
    }

    self.getDepartmentRateDetail = function (mod, idx, rate) {

        $.ajax({
            url: "VisitReportObservation.aspx/GetDepartmentRatingLogDetail",
            type: 'POST',
            dataType: "json",
            data: "{DepartmentID: '" + mod.DepartmentID() + "', RatingID: '" + rate.ID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && NotifyMe(data.d.Notification) && data.d.LogDetail != null) {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });

                    mod.DepartmentCount(parseInt(parseInt(mod.DepartmentCount()) + 1));
                }
            },
            error: function (request) {
            }
        });
    }

    self.getDepartmentCompleteRateDetail = function (idx, mod) {
        $.ajax({
            url: "VisitReportObservation.aspx/GetDepartmentRatingLogDetail",
            type: 'POST',
            dataType: "json",
            data: "{DepartmentID: '" + mod.DepartmentID() + "', RatingID: '" + 0 + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && NotifyMe(data.d.Notification) && data.d.LogDetail != null) {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });

                    mod.DepartmentCount(parseInt(parseInt(mod.DepartmentCount()) + 1));
                }
            },
            error: function (request) {
            }
        });
    }

    self.hideDepartmentRateDetail = function (idx, mod) {
        mod.RatingDetails([]);
        mod.DepartmentCount(parseInt(parseInt(mod.DepartmentCount()) - 1));
    }

    self.TotalDistrictVisits = ko.computed(function () {
        var ret = 0;
        ko.utils.arrayForEach(self.DistrictLogs(), function (itm) {
            ret = ret + parseInt(itm.TotalVisits());
        });
        return ret;
    });

    self.getfilterDistrictRecord = function (mod) {
        $.ajax({
            url: "VisitReportObservation.aspx/GetDistrictsWiseVisitsObservedBreakdown",
            type: 'POST',
            dataType: "json",
            data: "{DivisionID: '" + mod.DivisionID() + "', DistrictID: '" + mod.DistrictID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                self.DistrictLogs([]);
                if (data.d.DistrictLogs != null && NotifyMe(data.d.Notification)) {
                    ko.utils.arrayForEach(data.d.DistrictLogs, function (itm) {
                        self.DistrictLogs.push(new DistrictLogModel(itm));
                    });
                }

                self.AllDistrictCounts([]);
                if (data.d.AllDistrictCounts != null) {
                    ko.utils.arrayForEach(data.d.AllDistrictCounts, function (itm) {
                        self.AllDistrictCounts.push(new DistrictCountModel(itm));
                    });
                }

                setDistrictCount(self);
            },
            error: function (request) {
            }
        });
    }

    self.getfilterDepartmentRecord = function (mod) {
        $.ajax({
            url: "VisitReportObservation.aspx/GetDepartmentsWiseVisitsObservedBreakdown",
            type: 'POST',
            dataType: "json",
            data: "{DepartmentID: '" + mod.DepartmentID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                self.DepartmentLogs([]);
                if (data.d.DepartmentLogs != null && NotifyMe(data.d.Notification)) {
                    ko.utils.arrayForEach(data.d.DepartmentLogs, function (itm) {
                        self.DepartmentLogs.push(new DepartmentLogModel(itm));
                    });
                }
            },
            error: function (request) {
            }
        });
    }
}

function DistrictLogModel(log) {
    var self = this;

    self.Division = ko.observable(log.Division);
    self.DivisionID = ko.observable(log.DivisionID);

    self.District = ko.observable(log.District);
    self.DistrictID = ko.observable(log.DistrictID);

    self.DistrictCount = ko.observable(0);

    self.TotalVisits = ko.observable(log.TotalVisits);
    self.Rating = ko.observableArray();
    self.RatingDetails = ko.observableArray();

    if (log.Rating != null) {
        ko.utils.arrayForEach(log.Rating, function (itm) {
            self.Rating.push(new RatingModel(itm));
        });
    }
}

function DepartmentLogModel(log) {
    var self = this;

    self.Department = ko.observable(log.Department);
    self.DepartmentID = ko.observable(log.DepartmentID);
    self.TotalVisits = ko.observable(log.TotalVisits);
    self.Rating = ko.observableArray();
    self.RatingDetails = ko.observableArray();

    self.DepartmentCount = ko.observable(1);

    if (log.Rating != null) {
        ko.utils.arrayForEach(log.Rating, function (itm) {
            self.Rating.push(new RatingModel(itm));
        });
    }
}

function RatingDetailModel(detail) {
    var self = this;
    self.TaskID = ko.observable(detail.TaskID);
    self.Place = ko.observable(detail.Place);
    self.Department = ko.observable(detail.Department);
    self.Rated = ko.observable(detail.Rated);
    self.RateID = ko.observable(detail.RateID || 0);
    self.StartDate = ko.observable(detail.StartDate != null ? parseInt(detail.StartDate.toString().substring(6, 19)) > 0 ? moment(new Date(parseInt(detail.StartDate.toString().substring(6, 19)))).format('DD/M/YY hh:mm A') : '-' : '-');
}

function RatingModel(rate) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(rate.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(rate.Title));
    self.VisitCount = ko.observable(ko.utils.unwrapObservable(rate.VisitCount) || 0);
}

function DistrictCountModel(dist) {
    var self = this;
    self.DivisionID = ko.observable(dist.DivisionID);
    self.Count = ko.observable(dist.Count);
}

function DivisionModel(div) {
    var self = this;
    self.ID = ko.observable(div.ID);
    self.Title = ko.observable(div.Title);
}

function DistrictModel(dist) {
    var self = this;
    self.ID = ko.observable(dist.ID);
    self.DivisionID = ko.observable(dist.DivisionID);
    self.Title = ko.observable(dist.Title);
}

function DepartmentModel(dept) {
    var self = this;
    self.ID = ko.observable(dept.ID);
    self.Title = ko.observable(dept.Title);
}

function setDistrictCount(self) {
    ko.utils.arrayForEach(self.AllDistrictCounts(), function (dist) {
        var filter_logs = ko.utils.arrayFilter(self.DistrictLogs(), function (log) {
            return ko.utils.unwrapObservable(log.DivisionID) == ko.utils.unwrapObservable(dist.DivisionID) || 0;
        });
        filter_logs.length > 0 ? filter_logs[0].DistrictCount(filter_logs.length) : '';
    });
}

function getDivisionFirstIndex(self, divisionID) {
    var filter_logs = ko.utils.arrayFilter(self.DistrictLogs(), function (log) {
        return ko.utils.unwrapObservable(log.DivisionID) == ko.utils.unwrapObservable(divisionID) || 0;
    });
    return filter_logs.length > 0 ? filter_logs[0] : null;
}

$(document).ready(function () {
    LoadRecord(new wrapperModel(null));
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {
    $.ajax({
        url: "VisitReportObservation.aspx/GetAllVisitsObservedBreakdown",
        type: 'POST',
        dataType: "json",
        data: "{ DivisionID: '" + mod.DivisionID() + "', DistrictID: '" + mod.DistrictID() + "' }",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
            }
        },
        error: function (request) {
        }
    });
}