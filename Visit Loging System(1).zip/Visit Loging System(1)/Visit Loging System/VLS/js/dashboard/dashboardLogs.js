﻿var tabsList = [{ 'Title': 'Self', 'ID': 1, 'TargetID': '#own', 'IsActive': true },
{ 'Title': 'DCO', 'ID': 2, 'TargetID': '#dg', 'IsActive': false },
{ 'Title': 'Commissioner', 'ID': 3, 'TargetID': '#so1', 'IsActive': false }];


var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var ref_all_rec = [];
var ref_allDepartments = [];
var refSearchText = '';
var headers = [
      { title: 'Sr No', sortKey: 'SrNO', order: 0, css: '' },
      { title: 'Department\'s Name', sortKey: 'Department', order: 0, css: '' },
      { title: 'Division', sortKey: 'Division', order: 0, css: '' },
      { title: 'District', sortKey: 'District', order: 0, css: '' },
      { title: 'Place of Visit', sortKey: 'Place', order: 0, css: '' },
      { title: 'Start Date', sortKey: 'StartDate', order: 0, css: '' },
      { title: 'End Date', sortKey: 'EndDate', order: 0, css: '' },
      { title: 'Agenda/Purpose', sortKey: 'Agenda', order: 0, css: '' },
      { title: 'Rating', sortKey: 'Rating', order: 0, css: 'text-center' },
      { title: 'View Report', sortKey: '', order: 0, css: 'text-center wide-head' },
      { title: 'View Images', sortKey: '', order: 0, css: 'text-center wide-head' }
];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($("#main"))) {
            $(element).validationEngine('validate');
        }
    }
};


function wrapperModel(items) {
    var self = this;

    //self.headers = [
    //  { title: 'Sr No', sortKey: 'SrNO', order: 0, css: '' },
    //  { title: 'Department\'s Name', sortKey: 'Department', order: 0, css: '' },
    //  { title: 'Division', sortKey: 'Division', order: 0, css: '' },
    //  { title: 'District', sortKey: 'District', order: 0, css: '' },
    //  { title: 'Place of Visit', sortKey: 'Place', order: 0, css: '' },
    //  { title: 'Start Date', sortKey: 'StartDate', order: 0, css: '' },
    //  { title: 'End Date', sortKey: 'EndDate', order: 0, css: '' },
    //  { title: 'Agenda/Purpose', sortKey: 'Agenda', order: 0, css: '' },
    //  { title: 'Rating', sortKey: 'Rating', order: 0, css: 'text-center' },
    //  { title: 'Action', sortKey: '', order: 0, css: 'text-center wide-head' }
    //];
    self.IsAllowedToEdit = ko.observable(false);
    self.SortOrder = ko.observable(0);
    self.SortColumn = ko.observable('');

    self.MehtodName = ko.observable('GetDashBoardVisitedForDesignation');
    self.DesignationID = ko.observable(0);
    self.UserDesignationID = ko.observable(0);
    self.RateID = ko.observable(0);

    self.UserDesignation = ko.observable('');
    self.UserDepartment = ko.observable('');

    self.VisitLogs = ko.observableArray();

    self.PageSize = ko.observable(20);
    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);

    self.SearchText = ko.observable(refSearchText);
    self.Counts = ko.observableArray();
    self.RatingCounts = ko.observableArray();

    self.Top = ko.observableArray();
    self.Middle = ko.observableArray();
    self.Lower = ko.observableArray();

    self.ActionCounts = ko.observableArray();
    self.Images = ko.observableArray();

    if (items != null) {

        self.IsAllowedToEdit = (items.IsAllowedToEdit || false);

        self.UserDesignation(items.UserDesignation || '');
        self.UserDepartment(items.UserDepartment || '');


        self.DesignationID(items.DesignationID || 0);
        self.UserDesignationID(items.UserDesignationID || 0);

        if (items.Tasks != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(items.Tasks, function (item) {
                self.VisitLogs.push(new VisitLogModel(item));
            });
        }

        if (items.ActionCounts != null) {
            self.ActionCounts([]);
            ko.utils.arrayForEach(items.ActionCounts, function (item) {
                self.ActionCounts.push(new ActionCountModel(item));
            });
        }

        if (items.RatingCounts != null) {
            self.RatingCounts([]);
            self.Top([]);
            self.Middle([]);
            self.Lower([]);
            ko.utils.arrayForEach(items.RatingCounts, function (item) {
                switch (item.Category.toString().toLowerCase()) {
                    case 'top':
                        self.Top.push(new CountModel(item));
                        break;
                    case 'middle':
                        self.Middle.push(new CountModel(item));
                        break;
                    case 'lower':
                        self.Lower.push(new CountModel(item));
                        break;
                    default:
                        self.RatingCounts.push(new CountModel(item));

                }
                self.RatingCounts.push(new CountModel(item));
            });
        }

        if (items.Counts != null) {
            self.Counts([]);
            ko.utils.arrayForEach(items.Counts, function (item) {
                self.Counts.push(new CountModel(item));
            });
        }

        self.PageSize(20);
        self.PageNo(items.PageNo == 0 ? 1 : items.PageNo);
        self.TotalResults(items.RESULT_COUNT || 0);
        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());
    }

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        LoadRecord(viewModel.main());
    };

    self.SearchVisit = function () {
        LoadRecordSearch(self);
    };

    self.Reload = function () {
        self.SearchText('');
        LoadRecordSearch(self);
    };

    self.getTasks = function (obj, dat) {
        clearAll();
        var mehtodName = obj.MethodName();
        self.MehtodName(mehtodName);
        self.RateID(0);
        $(".panel-action").removeClass("hidden").addClass("hidden");
        $.ajax({
            url: "DashboardLogs.aspx/" + mehtodName,
            type: 'POST',
            dataType: "json",
            data: "{pageNo : '" + self.PageNo() + "',pageSize : '" + self.PageSize() + "',designationID : '" + 0 + "',rateID : '" + self.RateID() + "',SortColumn : '" + self.SortColumn() + "',SortDirection : '" + self.SortOrder() + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().MehtodName(mehtodName);
                viewModel.main().UserDepartment(data.d.UserDepartment || '');
                viewModel.main().RateID(0);

                ko.utils.arrayForEach(viewModel.main().Counts(), function (itm) {
                    if (itm.MethodName() == mehtodName) {
                        itm.isActive(true);
                    }
                    else {
                        itm.isActive(false);
                    }
                });
                // $(".tab-panel").removeClass("hidden");

                ko.utils.arrayForEach(viewModel.main().Top(), function (tb) {
                    tb.isActive(false);
                });

                ko.utils.arrayForEach(viewModel.main().Middle(), function (tb) {
                    tb.isActive(false);
                });

                ko.utils.arrayForEach(viewModel.main().Lower(), function (tb) {
                    tb.isActive(false);
                });
            },
            error: function (er, _rr) {
                console.log("error|" + er.statusText);
            }
        });
    };


    self.getRatedData = function (mod) {
        clearAll();
        self.RateID(mod.RateID());
        self.PageNo(1);
        LoadRecord(self);
    }

    self.clearRating = function () {
        clearAll();
        self.RateID(0);
        self.PageNo(1);
        LoadRecord(self);
    }

    self.sort = function (header, event) {
        clearPrevious(header.sortKey);
        header.order = header.order == 1 ? 2 : header.order == 2 ? 1 : header.order == 0 ? 1 : header.order;
        header.css = header.order == 1 ? 'asc' : header.order == 2 ? 'desc' : '';
        self.SortOrder(header.order);
        self.SortColumn(header.sortKey);
        self.PageNo(1);
        LoadRecord(self);
    };

}

function ImageModel(img) {
    var self = this;
    self.ImageID = ko.observable(img.ImageID);
    self.ImageTitle = ko.observable(img.ImageTitle);
    self.ImageDescription = ko.observable(img.ImageDescription);
    self.VisitorLogImage = ko.observable(img.VisitorLogImage);

    self.VisitedDate = ko.observable(img.VisitedDate != null ? parseInt(img.VisitedDate.toString().substring(6, 19)) > 0 ? moment(new Date(parseInt(img.VisitedDate.toString().substring(6, 19)))).format('DD-MMM-YYYY hh:mm A') : '-' : '-');
    self.VistedDepartmentName = ko.observable(img.VistedDepartmentName);
    self.Place = ko.observable(img.Place);
    self.VisitedBy = ko.observable(img.VisitedBy);
}


function clearPrevious(key) {
    $.each(headers, function (idx, itm) {
        if (itm.sortKey != key) { itm.css = ''; itm.order = 0; }
    });
}

function clearAll() {
    $.each(headers, function (idx, itm) {
        itm.css = ''; itm.order = 0;
    });

    viewModel.main().SortColumn('');
    viewModel.main().SortOrder(0);
}

function VisitLogModel(visit) {
    var self = this;
    if (visit != null) {
        self.VisitorLogID = ko.observable(visit.VisitorLogID);
        self.TaskID = ko.observable(visit.TaskID);
        self.DistrictName = ko.observable(visit.DistrictName);
        self.TehsilName = ko.observable(visit.TehsilName);
        self.ProvinceName = ko.observable(visit.ProvinceName);
        self.DivisionName = ko.observable(visit.DivisionName);
        self.DepartmentName = ko.observable(visit.DepartmentName);
        self.UnionCouncilName = ko.observable(visit.UnionCouncilName);
        self.DesignationName = ko.observable(visit.DesignationName);
        self.Place = ko.observable(visit.Place);
        self.StartDate = ko.observable(ko.utils.unwrapObservable(visit.StartDate).toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(visit.StartDate).substring(6, 19)))).format('DD-MMM-YYYY') : ko.utils.unwrapObservable(visit.StartDate));
        self.EndDate = ko.observable(ko.utils.unwrapObservable(visit.EndDate).toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(visit.EndDate).substring(6, 19)))).format('DD-MMM-YYYY') : ko.utils.unwrapObservable(visit.EndDate));
        self.StartTime = ko.observable(visit.StartTime);
        self.EndTime = ko.observable(visit.EndTime);
        self.VisitAgenda = ko.observable(visit.VisitAgenda);
        self.Rating = ko.observable(visit.Rating);
        self.AssignPersonName = ko.observable(visit.AssignPersonName);
        self.AssignedDate = ko.observable(visit.AssignedDate);
        self.DueDate = ko.observable(visit.DueDate);
        self.RowNumber = ko.observable(visit.RowNumber);
        self.RatingName = ko.observable(visit.RatingName);
        self.ActionTaken = ko.observable(visit.ActionTaken || false);
        self.HasImage = ko.observable(visit.HasImage || false);
        self.HasActionTaken = ko.observable(visit.HasActionTaken || false);
    }
    else {
        self.VisitorLogID = ko.observable('');
        self.TaskID = ko.observable('');
        self.DistrictName = ko.observable('');
        self.TehsilName = ko.observable('');
        self.ProvinceName = ko.observable('');
        self.DivisionName = ko.observable('');
        self.DepartmentName = ko.observable('');
        self.UnionCouncilName = ko.observable('');
        self.DesignationName = ko.observable('');
        self.Place = ko.observable('');
        self.StartDate = ko.observable('');
        self.EndDate = ko.observable('');
        self.StartTime = ko.observable('');
        self.EndTime = ko.observable('');
        self.VisitAgenda = ko.observable('');
        self.Rating = ko.observable('');
        self.AssignPersonName = ko.observable('');
        self.AssignedDate = ko.observable('');
        self.DueDate = ko.observable('');
        self.RowNumber = ko.observable('');
        self.RatingName = ko.observable('');
        self.ActionTaken = ko.observable(false);
        self.HasImage = ko.observable(false);
        self.HasActionTaken = ko.observable(false);
    }

    self.getImages = function (mod) {
        $.ajax({
            url: "DashboardCM.aspx/GetVisitsLogPictures",
            type: 'POST',
            dataType: "json",
            data: "{visitorLogID : '" + mod.VisitorLogID() + "'}",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                viewModel.main().Images([]);
                if (data.d != null && NotifyMe(data.d.Notification) && data.d.ActionImageModel != null) {
                    ko.utils.arrayForEach(data.d.ActionImageModel, function (itm) {
                        viewModel.main().Images.push(new ImageModel(itm));
                    });
                }
                $('#modalImages').modal('show');
            },
            error: function (er, _rr) {
                console.log("error|" + er.statusText);
            }
        });
    }
}

function ActionCountModel(cnt) {
    var self = this;
    if (cnt != null) {
        self.Count = ko.observable(cnt.Count || 0);
        self.Title = ko.observable(cnt.Title || '');
    }
    else {
        self.Count = ko.observable(0);
        self.Title = ko.observable('');
    }
}


function CountModel(cnt) {
    var self = this;
    if (cnt != null) {
        self.RateID = ko.observable(cnt.RateID || 0);
        self.Count = ko.observable(cnt.Count || 0);
        self.Title = ko.observable(cnt.Title || '');
        self.MethodName = ko.observable(cnt.MethodName || '');
        self.Category = ko.observable(cnt.Category || '');
        self.Sort = ko.observable(cnt.Sort || 0);
    }
    else {
        self.RateID = ko.observable(0);
        self.Count = ko.observable(0);
        self.Title = ko.observable('');
        self.MethodName = ko.observable('');
        self.Category = ko.observable('');
        self.Sort = ko.observable(0);
    }
    self.isActive = ko.observable(false);
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    //$('form').validationEngine('attach', { promptPostion: 'bottomLeft' });

    LoadRecord(new wrapperModel(null));
    ko.applyBindings(viewModel);
});

function LoadRecord(mod) {
    var sortColumn = mod.SortColumn() || '';
    var sortDirection = mod.SortOrder() || 0;
    $.ajax({
        url: "DashboardLogs.aspx/GetDashBoardVisitedForDesignation",
        type: 'POST',
        data: "{pageNo : '" + mod.PageNo() + "',pageSize : '" + mod.PageSize() + "',designationID : '" + mod.DesignationID() + "',rateID : '" + mod.RateID() + "',SortColumn : '" + sortColumn + "',SortDirection : '" + sortDirection + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().RateID(mod.RateID());
                ko.utils.arrayForEach(viewModel.main().Counts(), function (itm) {
                    if (mod.DesignationID() == 0) {
                        itm.isActive(true);
                    }
                    else if (itm.MethodName() == 'GetDashBoardVisitedForDesignation') {
                        itm.isActive(true);
                    }
                    else {
                        itm.isActive(false);
                    }
                });

                ko.utils.arrayForEach(viewModel.main().Top(), function (tb) {
                    tb.RateID() == mod.RateID() ? tb.isActive(true) : tb.isActive(false);
                });

                ko.utils.arrayForEach(viewModel.main().Middle(), function (tb) {
                    tb.RateID() == mod.RateID() ? tb.isActive(true) : tb.isActive(false);
                });

                ko.utils.arrayForEach(viewModel.main().Lower(), function (tb) {
                    tb.RateID() == mod.RateID() ? tb.isActive(true) : tb.isActive(false);
                });

                viewModel.main().SortColumn(sortColumn);
                viewModel.main().SortOrder(sortDirection);
            }
        },
        error: function (er, _rr) {
            console.log("error|" + er.statusText);
        }
    });
}


function LoadRecordSearch(mod) {
    $.ajax({
        url: "DashboardLogs.aspx/" + mod.MehtodName(),
        type: 'POST',
        dataType: "json",
        data: "{pageNo : '" + mod.PageNo() + "',pageSize : '" + mod.PageSize() + "',designationID : '" + mod.DesignationID() + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new wrapperModel(data.d));
            viewModel.main().MehtodName(mod.MehtodName());

            ko.utils.arrayForEach(viewModel.main().Counts(), function (itm) {
                if (itm.MethodName() == mod.MehtodName()) {
                    itm.isActive(true);
                }
                else {
                    itm.isActive(false);
                }
            });

            ko.utils.arrayForEach(viewModel.main().TabList(), function (tb) {
                if (tb.ID() == mod.DesignationID()) {
                    tb.IsActive(true);
                    viewModel.main().DesignationID(tb.ID());
                }
                else {
                    tb.IsActive(false);
                }
            });
            //$(".tab-panel").removeClass("hidden");

            if (mod.MehtodName() == 'GetDashBoardAssignTaskForDesignation') {
                $('.table, .tab-content, .nav-tabs').addClass('red');
            }
            else {
                $('.table, .tab-content, .nav-tabs').removeClass('red');
            }
        },
        error: function (er, _rr) {
            console.log("error|" + er.statusText);
        }
    });
}
