﻿

var apostrophyRegx = new RegExp("'", "g");
var ref_districts = [];
var viewModel = new ViewModel();
var map;
var JsonData;
var poly;
var infowindow;
var polyPath = [];
var ref_districtID;

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {},
            $el = $(element);

        $el.datepicker(options);

        //handle the field changing by registering datepicker's changeDate event
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });

        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });

    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
            $el = $(element);

        //handle date data coming via json from Microsoft
        if (String(value).indexOf('/Date(') == 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }

        var current = $el.datepicker("getDate");

        if (value - current !== 0) {
            $el.datepicker("setDate", value);
        }
    }
};


ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};

function wrapperModel(item) {
    var self = this;


    self.filterDepartment = ko.observable();
    self.filterDistrict = ko.observable();

    self.Districts = ko.observableArray();
    self.Officials = ko.observableArray();
    self.Legends = ko.observableArray();
    self.Markers = ko.observableArray();
    self.DesignationVisits = ko.observableArray();

    self.filterModel = ko.observable(new FilterModel(null));

    self.DepartmentLogs = ko.observableArray();
    self.DistrictLogs = ko.observableArray();
    self.Facilities = ko.observableArray();

    self.SMS = ko.observable('');
    self.DistrictID = ko.observable(0);
    self.DepartmentID = ko.observable(0);
    self.DepartmentName = ko.observable('');
    self.DesignationName = ko.observable('');
    self.TotalDepartmentVisitCount = ko.observable(0);
    self.TotalDistrictVisitCount = ko.observable(0);

    self.RatingHeader = ko.observableArray();
    self.JustEnteredLogs = ko.observableArray();
    self.Images = ko.observableArray();

    if (item != null) {


        self.filterModel(new FilterModel(item.DashboardModel));

        self.TotalDepartmentVisitCount(item.TotalDepartmentVisitCount || 0);
        self.TotalDistrictVisitCount(item.TotalDistrictVisitCount || 0);

        if (item.DashboardModel.Designations != null) {
            self.filterModel().Designations([]);
            ko.utils.arrayForEach(item.DashboardModel.Designations, function (itm) {
                self.filterModel().Designations.push(new DesignationModel(itm));
            });
        }

        if (item.DesignationVisits != null) {
            self.DesignationVisits([]);
            ko.utils.arrayForEach(item.DesignationVisits, function (itm) {
                self.DesignationVisits.push(new DesignationVisitModel(itm));
            });
        }

        if (item.DepartmentFacilities != null) {
            ko.utils.arrayForEach(item.DepartmentFacilities, function (itm) {
                self.Facilities.push(new DistrictModel(itm));
            });
        }

        if (item.Districts != null) {
            ref_districts = [];
            ko.utils.arrayForEach(item.Districts, function (itm) {
                self.Districts.push(new DistrictModel(itm));
                ref_districts.push(new DistrictModel(itm));
            });
        }

        if (item.Officials != null) {
            ko.utils.arrayForEach(item.Officials, function (itm) {
                self.Officials.push(new LegendModel(itm));
            });
        }

        if (item.Legends != null) {
            ko.utils.arrayForEach(item.Legends, function (itm) {
                self.Legends.push(new LegendModel(itm));
            });
        }

        if (item.Markers != null) {
            ko.utils.arrayForEach(item.Markers, function (itm) {
                self.Markers.push(new MarkerModel(itm));
            });
        }
    }
    self.CharacterCount = ko.computed(function () {
        return (300 - parseInt(self.SMS().length)) < 0 ? 'Limit Exceeded' : 300 - parseInt(self.SMS().length);
    });


    self.validateMaxLength = function (data, event) {
        var code = (event.keyCode) ? event.keyCode : event.which;
        if ((code == 65 && event.ctrlKey === true) ||
            // Allow: Ctrl+C
                (code == 67 && event.ctrlKey === true) ||
            // Allow: Ctrl+X
                (code == 88 && event.ctrlKey === true) ||
            // Allow: Ctrl+V
                (code == 86 && event.ctrlKey === true)) {
            // let it happen, don't do anything
            return false;
        }
        else {
            return self.SMS().length > 299 && code != 8 && code != 46 ? false : true;
        }

    }

    self.showPopUp = function (idx, mod) {
        self.DepartmentID(mod.DepartmentID());
        $("#modalSMS").modal('show');
    }

    self.sendSMS = function () {
        $('#overlay').show();
        var jsonSr = viewModel.main().SMS().replace(apostrophyRegx, "");
        $.ajax({
            url: "DashboardCM.aspx/SendSMSToSecretary",
            type: 'POST',
            dataType: "json",
            data: "{DepartmentID: '" + ko.utils.unwrapObservable(self.DepartmentID) + "', SMS: '" + jsonSr + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d == '')
                    toastr.success('SMS has been sent successfully.');
                else
                    toastr.error('Recipient phone number is not valid.');

                viewModel.main().SMS('');
                $("#modalSMS").modal('hide');
                $('#overlay').hide();
            },
            error: function (request) {
                console.log(request.responseText);
            }
        });
    }

    self.viewMap = function () {
        if ($(".chkDesignations:checked").length > 0) {
            ViewSelectedMap(self);
            ref_districtID = undefined;
        }
        else {
            toastr.info('Designation must be selected.');
        }
    }

    self.viewJustEntered = function () {
        $.ajax({
            url: "DashboardCM.aspx/GetDashBoardMostRecentVisitRatingInfo",
            type: 'POST',
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                self.JustEnteredLogs([]);
                if (data.d != null && data.d != '' && data.d.LogDetail != null && NotifyMe(data.d.Notification)) {
                    ko.utils.arrayForEach(data.d.LogDetail, function (detail) {
                        self.JustEnteredLogs.push(new RatingDetailModel(detail));
                    });
                }
                $("#modalJustEntered").modal('show');
            },
            error: function (request) {
            }
        });
    }
    ;
    self.hideRateDetail = function (idx, mod) {
        mod.RatingDetails([]);
        self.filterDistrict('');
    }

    // get user wise rating breakdown by rate id
    self.getDepartmentRateDetail = function (name, rate, mod) {
        var rateID = getIDbyName(name);
        $.ajax({
            url: "DashboardCM.aspx/GetVisitRatingDetailByUser",
            type: 'POST',
            dataType: "json",
            data: "{UserID: '" + mod.DepartmentID() + "', DistrictID: '" + viewModel.main().filterModel().DistrictID() + "', RateID: '" + rateID + "', FromDate: '" + moment(new Date(viewModel.main().filterModel().FromDate())).format('MM/DD/YYYY') + "', ToDate: '" + moment(new Date(viewModel.main().filterModel().ToDate())).format('MM/DD/YYYY') + "', FacilityID: '" + viewModel.main().filterModel().FacilityID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && NotifyMe(data.d.Notification) && data.d.LogDetail != null) {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d.LogDetail, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                }
            },
            error: function (request) {
            }
        });
    }

    // get user wise breakdown
    self.getDepartmentCompleteRateDetail = function (idx, mod) {
        $.ajax({
            url: "DashboardCM.aspx/GetVisitRatingDetailByUser",
            type: 'POST',
            dataType: "json",
            data: "{UserID: '" + mod.DepartmentID() + "', DistrictID: '" + viewModel.main().filterModel().DistrictID() + "', RateID: '" + 0 + "', FromDate: '" + moment(new Date(viewModel.main().filterModel().FromDate())).format('MM/DD/YYYY') + "', ToDate: '" + moment(new Date(viewModel.main().filterModel().ToDate())).format('MM/DD/YYYY') + "', FacilityID: '" + viewModel.main().filterModel().FacilityID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d != '') {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                }
            },
            error: function (request) {
            }
        });
    }

    self.getDashBoardMostRecentVisitRatingInfo = function (idx, mod) {
        $.ajax({
            url: "DashboardCM.aspx/GetDashBoardMostRecentVisitRatingInfo",
            type: 'POST',
            dataType: "json",

            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d != '') {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                }
            },
            error: function (request) {
            }
        });
    }

    self.hideDepartmentRateDetail = function (idx, mod) {
        mod.RatingDetails([]);
        mod.DepartmentCount(parseInt(parseInt(mod.DepartmentCount()) - 1));
        self.filterDepartment('');
    }

    self.getRateDetail = function (name, rate, mod) {
        var rateID = getIDbyName(name);
        $.ajax({
            url: "DashboardCM.aspx/GetDistrictRatingLogDetail",
            type: 'POST',
            dataType: "json",
            data: "{DistrictID: '" + mod.DistrictID() + "', RatingID: '" + rateID + "', FromDate: '" + moment(new Date(viewModel.main().filterModel().FromDate())).format('MM/DD/YYYY') + "', ToDate: '" + moment(new Date(viewModel.main().filterModel().ToDate())).format('MM/DD/YYYY') + "', Designations: '" + ko.toJSON(viewModel.main().filterModel().Designations()) + "', FacilityID: '" + viewModel.main().filterModel().FacilityID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && NotifyMe(data.d.Notification) && data.d.LogDetail != null) {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d.LogDetail, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                }
            },
            error: function (request) {
            }
        });
    }

    self.getCompleteRateDetail = function (idx, mod) {
        $.ajax({
            url: "DashboardCM.aspx/GetDistrictRatingLogDetail",
            type: 'POST',
            dataType: "json",
            data: "{DistrictID: '" + mod.DistrictID() + "', RatingID: '" + 0 + "', FromDate: '" + moment(new Date(viewModel.main().filterModel().FromDate())).format('MM/DD/YYYY') + "', ToDate: '" + moment(new Date(viewModel.main().filterModel().ToDate())).format('MM/DD/YYYY') + "', Designations: '" + ko.toJSON(viewModel.main().filterModel().Designations()) + "', FacilityID: '" + viewModel.main().filterModel().FacilityID() + "' }",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d != '') {
                    mod.RatingDetails([]);
                    ko.utils.arrayForEach(data.d, function (detail) {
                        mod.RatingDetails.push(new RatingDetailModel(detail));
                    });
                }
            },
            error: function (request) {
            }
        });

        //ko.utils.arrayForEach(logDetail, function (detail) {
        //    mod.RatingDetails.push(new RatingDetailModel(detail));
        //});

        //log.DistrictCount(parseInt(parseInt(log.DistrictCount()) + 1));
    }

    self.hideSMSModal = function () {
        viewModel.main().SMS('');
        $("#modalSMS").modal('hide');
    };

    self.facilityIDChange = function (mod) {
        $.ajax({
            url: "DashboardCM.aspx/GetDesignationByFacility",
            type: 'POST',
            dataType: "json",
            data: "{FacilityID : '" + ko.toJSON(mod.FacilityID()) + "'}",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.d != null && data.d != '' && NotifyMe(data.d.Notification)) {

                    self.filterModel().Designations([]);
                    ko.utils.arrayForEach(data.d, function (itm) {
                        self.filterModel().Designations.push(new DesignationModel(itm));
                    });
                }
            },
            error: function (er, _rr) {
                console.log("error|" + er.statusText);
            }
        });
    }
}

function ViewSelectedMap(self) {
    var jsonUrl = "../../js/geoJSON/All.json";
    if (self.filterModel().DistrictID() != undefined) {
        var filter_dist = ko.utils.arrayFilter(viewModel.main().Districts(), function (dist) {
            // alert(self.filterModel().DistrictID());

            ref_districtID = self.filterModel().DistrictID();


            return dist.ID() == self.filterModel().DistrictID();
        });

        if (filter_dist != null && filter_dist.length > 0 && filter_dist != '') {
            jsonUrl = "../../js/geoJSON/" + filter_dist[0].Title() + ".json";
        }

    }


    LoadRecord(self, jsonUrl);
    //  viewModel.main().DistrictID(ref_districtID);
}

function FilterModel(filter) {
    var self = this;
    if (filter != null) {
        self.DistrictID = ko.observable(filter.DistrictID);
        self.FacilityID = ko.observable(filter.FacilityID);
        self.FromDate = ko.observable(ko.utils.unwrapObservable(filter.FromDate || '').toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(filter.FromDate).substring(6, 19))) : ko.utils.unwrapObservable(filter.FromDate));
        self.ToDate = ko.observable(ko.utils.unwrapObservable(filter.ToDate || '').toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(filter.ToDate).substring(6, 19))) : ko.utils.unwrapObservable(filter.ToDate));
    }
    else {
        self.DistrictID = ko.observable(0);
        self.FacilityID = ko.observable(0);
        self.FromDate = ko.observable(new Date('02/01/2016'));
        self.ToDate = ko.observable(new Date());
    }

    self.Designations = ko.observableArray();
    self.allChecked = ko.observable(false);

    self.viewDesignationVise = function (mod) {
        if (mod.allChecked()) {
            ko.utils.arrayForEach(self.Designations(), function (itm) {
                itm.Checked(true);
            });
        }
        else {
            ko.utils.arrayForEach(self.Designations(), function (itm) {
                itm.Checked(false);
            });
        }
        return true;
    }

    //Call on district dropdownchange
    self.getGeoJson = function () {
        var jsonUrl = "../../js/geoJSON/All.json";
        if (self.DistrictID() != undefined) {
            var filter_dist = ko.utils.arrayFilter(viewModel.main().Districts(), function (dist) {
                return dist.ID() == self.DistrictID();
            });

            if (filter_dist != null && filter_dist.length > 0 && filter_dist != '') {
                jsonUrl = "../../js/geoJSON/" + filter_dist[0].Title() + ".json";
            }

        }
        MakeGeoJSON(jsonUrl);
    };
}

function DesignationVisitModel(desig) {
    var self = this;
    self.DesignationID = ko.observable(desig.DesignationID);
    self.Title = ko.observable(desig.Title);
    self.Count = ko.observable(desig.Count);
    self.PanelID = ko.observable('designation_' + desig.DesignationID);
    self.Visits = ko.observableArray();

    if (desig.Visits != null) {
        self.Visits([]);
        ko.utils.arrayForEach(desig.Visits, function (itm) {
            self.Visits.push(new LegendModel(itm, desig.Title));
        });
    }
}

function CommonModel(mod) {
    var self = this;
    self.ID = ko.observable(mod.ID);
    self.Title = ko.observable(mod.Title);
}

function LegendModel(legend, desig) {
    var self = this;
    if (legend != null) {
        self.DistrictID = ko.observable(legend.DistrictID);
        self.DistrictName = ko.observable(legend.DistrictName);
        self.DesignationName = ko.observable(desig || '');
        self.VisitsCount = ko.observable(legend.VisitsCount);
        self.Color = ko.observable(legend.Color);
        self.IsVisitLog = ko.observable(legend.IsVisitLog);
    }
    else {
        self.DistrictID = ko.observable(0);
        self.DistrictName = ko.observable('');
        self.DesignationName = ko.observable('');
        self.VisitsCount = ko.observable('');
        self.Color = ko.observable('');
        self.IsVisitLog = ko.observable(true);
    }
}

function MarkerModel(marker) {
    var self = this;
    self.Latitude = ko.observable(marker.Latitude);
    self.Longitude = ko.observable(marker.Longitude);
    self.Place = ko.observable(marker.Place || '-');
    self.DistrictName = ko.observable(marker.DistrictName);
    self.Department = ko.observable(marker.Department);
    self.EmployeeName = ko.observable(marker.EmployeeName);
    self.Designation = ko.observable(marker.Designation);
    self.StartDate = ko.observable(ko.utils.unwrapObservable(marker.StartDate || '').toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(marker.StartDate).substring(6, 19)))).format('DD/MM/YYYY') : ko.utils.unwrapObservable(marker.StartDate));
    self.StartTime = ko.observable(ko.utils.unwrapObservable(marker.StartTime || '').toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(marker.StartTime).substring(6, 19)))).format('hh:mm') : ko.utils.unwrapObservable(marker.StartTime));
    self.EndDate = ko.observable(ko.utils.unwrapObservable(marker.EndDate || '').toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(marker.EndDate).substring(6, 19)))).format('DD/MM/YYYY') : ko.utils.unwrapObservable(marker.EndDate));
    self.EndTime = ko.observable(ko.utils.unwrapObservable(marker.EndTime || '').toString().indexOf('/Date(') == 0 ? moment(new Date(parseInt(ko.utils.unwrapObservable(marker.EndTime).substring(6, 19)))).format('hh:mm') : ko.utils.unwrapObservable(marker.EndTime));
    self.Rating = ko.observable(marker.Rating);
}

function DistrictModel(dist) {
    var self = this;
    self.ID = ko.observable(dist.ID);
    self.Title = ko.observable(dist.Title);
    self.VisitsCount = ko.observable(dist.VisitsCount);
    self.Color = ko.observable(dist.Color);
}

function DesignationModel(dept) {
    var self = this;
    self.ID = ko.observable(dept.ID);
    self.Title = ko.observable(dept.Title);
    self.Checked = ko.observable(dept.Checked);
    self.PanelID = ko.observable('designation_' + dept.ID);
}
/* Obsevation modal */

function DepartmentLogModel(log) {
    var self = this;

    self.Department = ko.observable(log.Department);
    self.DepartmentID = ko.observable(log.DepartmentID);
    self.TotalVisits = ko.observable(log.TotalVisits);
    self.VeryPoor = ko.observable(log.VeryPoor);
    self.Poor = ko.observable(log.Poor);
    self.Unsatisfactory = ko.observable(log.Unsatisfactory);
    self.Average = ko.observable(log.Average);
    self.Satisfactory = ko.observable(log.Satisfactory);
    self.Good = ko.observable(log.Good);
    self.Excellent = ko.observable(log.Excellent);
    self.RatingDetails = ko.observableArray();

    self.DepartmentCount = ko.observable(1);

    self.filteredItems = ko.computed(function () {
        var filter = viewModel.main() != undefined ? viewModel.main().filterDepartment() != undefined ? viewModel.main().filterDepartment().toLowerCase() : '' : true;
        if (!filter) {
            return self.RatingDetails();
        } else {
            return ko.utils.arrayFilter(self.RatingDetails(), function (item) {
                return item.Place().toLowerCase().indexOf(filter) !== -1 ||
                       item.Department().toLowerCase().indexOf(filter) !== -1 ||
                       item.StartDate().toLowerCase().indexOf(filter) !== -1 ||
                       item.Rated().toLowerCase().indexOf(filter) !== -1;
            });
        }
    }, this);
}

function DistrictLogModel(log) {
    var self = this;

    self.Division = ko.observable(log.Division);
    self.DivisionID = ko.observable(log.DivisionID);
    self.District = ko.observable(log.District);
    self.DistrictID = ko.observable(log.DistrictID);
    self.TotalVisits = ko.observable(log.TotalVisits);
    self.VeryPoor = ko.observable(log.VeryPoor);
    self.Poor = ko.observable(log.Poor);
    self.Unsatisfactory = ko.observable(log.Unsatisfactory);
    self.Average = ko.observable(log.Average);
    self.Satisfactory = ko.observable(log.Satisfactory);
    self.Good = ko.observable(log.Good);
    self.Excellent = ko.observable(log.Excellent);

    self.RatingDetails = ko.observableArray();

    self.filteredItems = ko.computed(function () {
        var filter = viewModel.main() != undefined ? viewModel.main().filterDistrict() != undefined ? viewModel.main().filterDistrict().toLowerCase() : '' : true;
        if (!filter) {
            return self.RatingDetails();
        } else {
            return ko.utils.arrayFilter(self.RatingDetails(), function (item) {
                return item.Place().toLowerCase().indexOf(filter) !== -1 ||
                       item.Department().toLowerCase().indexOf(filter) !== -1 ||
                       item.StartDate().toLowerCase().indexOf(filter) !== -1 ||
                       item.Rated().toLowerCase().indexOf(filter) !== -1;
            });
        }
    }, this);
}

function RatingDetailModel(detail) {
    var self = this;
    self.VisitorLogID = ko.observable(detail.VisitorLogID);
    //--self.DepartmentID = ko.observable(detail.DepartmentID);
    self.TaskID = ko.observable(detail.TaskID);
    self.Place = ko.observable(detail.Place);
    self.Department = ko.observable(detail.Department);
    self.Rated = ko.observable(detail.Rated);
    self.RateID = ko.observable(detail.RateID || 0);
    self.StartDate = ko.observable(detail.StartDate != null ? parseInt(detail.StartDate.toString().substring(6, 19)) > 0 ? moment(new Date(parseInt(detail.StartDate.toString().substring(6, 19)))).format('DD-MMM-YYYY hh:mm A') : '-' : '-');
    self.HasImage = ko.observable(detail.HasImage || false);
    self.HasActionTaken = ko.observable(detail.HasActionTaken || false);

    self.getImages = function (mod) {
        $.ajax({
            url: "DashboardCM.aspx/GetVisitsLogPictures",
            type: 'POST',
            dataType: "json",
            data: "{visitorLogID : '" + mod.VisitorLogID() + "'}",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                viewModel.main().Images([]);
                if (data.d != null && NotifyMe(data.d.Notification) && data.d.ActionImageModel != null) {
                    ko.utils.arrayForEach(data.d.ActionImageModel, function (itm) {
                        viewModel.main().Images.push(new ImageModel(itm));
                    });
                }
                $('#modalImages').modal('show');
            },
            error: function (er, _rr) {
                console.log("error|" + er.statusText);
            }
        });
    }
}

function ImageModel(img) {
    var self = this;
    self.ImageID = ko.observable(img.ImageID);
    self.ImageTitle = ko.observable(img.ImageTitle);
    self.ImageDescription = ko.observable(img.ImageDescription);
    self.VisitorLogImage = ko.observable(img.VisitorLogImage);

    self.VisitedDate = ko.observable(img.VisitedDate != null ? parseInt(img.VisitedDate.toString().substring(6, 19)) > 0 ? moment(new Date(parseInt(img.VisitedDate.toString().substring(6, 19)))).format('DD-MMM-YYYY hh:mm A') : '-' : '-');
    self.VistedDepartmentName = ko.observable(img.VistedDepartmentName);
    self.Place = ko.observable(img.Place);
    self.VisitedBy = ko.observable(img.VisitedBy);
}

function RatingModel(rate) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(rate.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(rate.Title));
    self.VisitCount = ko.observable(ko.utils.unwrapObservable(rate.VisitCount) || 0);
}
/* end */

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function LoadRecord(mod, jsonURL) {

    $.ajax({
        url: "DashboardCM.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        data: "{jsonModel : '" + ko.toJSON(mod.filterModel()) + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (data.d != null && NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().filterModel().allChecked(mod.filterModel().allChecked() || false);
                InitMap(jsonURL);
                $('#overlay').hide();
            }

        },
        error: function (er, _rr) {
            console.log("error|" + er.statusText);
        }
    });
}

function LoadDepartmentDetail(departmentID) {
    // departmentID = event.srcElement.id;
    // alert(departmentID);
    $.ajax({
        url: "VisitLog.aspx/GetDepartmentsWiseVisitsPerformedBreakdown",
        type: 'POST',
        dataType: "json",
        data: "{ departmentID: '" + departmentID + "' }",
        contentType: "application/json; charset=utf-8",
        success: function (data) {

            viewModel.main().DepartmentLogs([]);
            if (data != null && data.d.DepartmentLogs != null) {
                ko.utils.arrayForEach(data.d.DepartmentLogs, function (itm) {
                    viewModel.main().DepartmentLogs.push(new DepartmentLogModel(itm));
                });

                //  viewModel.main().DepartmentID(departmentID);
            }
            if (data != null) {
                if (data.d.RatingHeader != null) {
                    viewModel.main().RatingHeader([]);
                    ko.utils.arrayForEach(data.d.RatingHeader, function (itm) {
                        viewModel.main().RatingHeader.push(new RatingModel(itm));
                    });
                }
            }

            viewModel.main().filterDistrict('');
            viewModel.main().filterDepartment('');
            $("#modalDepartment").modal('show');
        },
        error: function (request) {
        }
    });
}

function LoadDepartmentDetailNew(departmentID, districtID) {
    // departmentID = event.srcElement.id;
    //alert(departmentID);
    $.ajax({
        url: "DashboardCM.aspx/GetDepartmentsWiseVisitsPerformedBreakdownNew",
        type: 'POST',
        dataType: "json",
        data: "{ departmentID: '" + departmentID + "', districtID: '" + districtID + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main().DepartmentLogs([]);
            if (data != null && data.d.DepartmentLogs != null && NotifyMe(data.d.Notification)) {
                ko.utils.arrayForEach(data.d.DepartmentLogs, function (itm) {
                    viewModel.main().DepartmentLogs.push(new DepartmentLogModel(itm));
                });
            }
            if (data != null) {
                if (data.d.RatingHeader != null) {
                    viewModel.main().RatingHeader([]);
                    ko.utils.arrayForEach(data.d.RatingHeader, function (itm) {
                        viewModel.main().RatingHeader.push(new RatingModel(itm));
                    });
                }
            }

            viewModel.main().filterDistrict('');
            viewModel.main().filterDepartment('');
            $("#modalDepartment").modal('show');
        },
        error: function (request) {
        }
    });
}

function LoadVisitLogBreakdownDetails(userID, districtID) {
    $.ajax({
        url: "DashboardCM.aspx/GetVisitsPerformedBreakdownByUser",
        type: 'POST',
        dataType: "json",
        data: "{ UserID: '" + userID + "', DistrictID: '" + viewModel.main().filterModel().DistrictID() + "', FromDate: '" + moment(new Date(viewModel.main().filterModel().FromDate())).format('MM/DD/YYYY') + "', ToDate: '" + moment(new Date(viewModel.main().filterModel().ToDate())).format('MM/DD/YYYY') + "', FacilityID: '" + viewModel.main().filterModel().FacilityID() + "'}",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main().DepartmentLogs([]);
            if (data != null && NotifyMe(data.d.Notification) && data.d.DepartmentLogs != null) {
                ko.utils.arrayForEach(data.d.DepartmentLogs, function (itm) {
                    viewModel.main().DepartmentLogs.push(new DepartmentLogModel(itm));
                });
            }
            if (data != null) {
                if (data.d.RatingHeader != null) {
                    viewModel.main().RatingHeader([]);
                    ko.utils.arrayForEach(data.d.RatingHeader, function (itm) {
                        viewModel.main().RatingHeader.push(new RatingModel(itm));
                    });
                }
            }

            viewModel.main().filterDistrict('');
            viewModel.main().filterDepartment('');
            $("#modalDepartment").modal('show');
        },
        error: function (request) {
        }
    });
}

function LoadDistrictDetail(districtID) {
    $.ajax({
        url: "DashboardCM.aspx/GetVisitsPerformedBreakdownByDistrict",
        type: 'POST',
        dataType: "json",
        data: "{ DistrictID: '" + districtID + "', FromDate: '" + moment(new Date(viewModel.main().filterModel().FromDate())).format('MM/DD/YYYY') + "', ToDate: '" + moment(new Date(viewModel.main().filterModel().ToDate())).format('MM/DD/YYYY') + "', Designations: '" + ko.toJSON(viewModel.main().filterModel().Designations()) + "', FacilityID: '" + viewModel.main().filterModel().FacilityID() + "' }",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main().DistrictLogs([]);
            if (data != null && data.d.DistrictLogs != null) {
                ko.utils.arrayForEach(data.d.DistrictLogs, function (itm) {
                    viewModel.main().DistrictLogs.push(new DistrictLogModel(itm));
                });
            }
            if (data != null) {
                if (data.d.RatingHeader != null) {
                    viewModel.main().RatingHeader([]);
                    ko.utils.arrayForEach(data.d.RatingHeader, function (itm) {
                        viewModel.main().RatingHeader.push(new RatingModel(itm));
                    });
                }
            }
            viewModel.main().filterDistrict('');
            viewModel.main().filterDepartment('');
            $("#modalDistrict").modal('show');

        },
        error: function (request) {
        }
    });
}

$(document).ready(function () {
    $('#overlay').show();

    LoadRecord(new wrapperModel(null), "../../js/geoJSON/All.json");

    $('body').on('click', 'a.btnResize', function (event) {
        var modalID = "#" + $(this).attr("aria-label");
        if ($(this).attr("data-resize") == "restore") {
            $(modalID).removeClass("bs-example-modal-lg").addClass("bs-example-modal-xlg");
            $(modalID + " > .modal-dialog.modal-lg").removeClass("modal-lg").addClass("modal-xlg");
            $(this).attr("data-resize", "maximize").find("i").removeClass("fa fa-expand").addClass("fa fa-compress");
        }
        else {
            $(modalID).removeClass("bs-example-modal-xlg").addClass("bs-example-modal-lg");
            $(modalID + " > .modal-dialog.modal-xlg").removeClass("modal-xlg").addClass("modal-lg");
            $(this).attr("data-resize", "restore").find("i").removeClass("fa fa-compress").addClass("fa fa-expand");
        }
    });

    ko.applyBindings(viewModel);

});

$(window).load(function () {
    $('#overlay').hide();
    //$("#designation_2 > div").slideToggle();
    // $(".inner-content, .inner-content-sectry").niceScroll({ styler: "fb", cursorcolor: "#5cb85c", cursorwidth: '8', cursorborderradius: '0px', autohidemode: false, background: '#404040', cursorborder: '', zindex: '1000' });
});
/* Utility Functions */
function ClearAll() {
    $('#overlay').show();
    viewModel.main().filterModel().DistrictID(null);
    LoadRecord(viewModel.main(), "../../js/geoJSON/All.json");
    ref_districtID = undefined;
}

function InitMap(jsonURL) {

    var mapCenter = new google.maps.LatLng(31.1704, 72.7097);

    map = new google.maps.Map(document.getElementById('map'), {
        center: mapCenter,
        zoom: 7,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    });

    var layer = new google.maps.FusionTablesLayer({
        query: {
            select: 'Location',
            from: '1NIVOZxrr-uoXhpWSQH2YJzY5aWhkRZW0bWhfZw'
        },
        map: map
    });

    MakeLegend();
    MakeGeoJSON(jsonURL);   //"../../js/geoJSON/All.json"
    // MakeMarkers();
    var infowindow;

    map.data.addListener('click', function (event) {
        //window.open("../../ContentPages/Reports/SecretariesVisitObservationByDistrict.aspx?districtID=" + event.feature.getProperty('id') + "&fromDate=" + viewModel.main().filterModel().FromDate() + "&toDate=" + viewModel.main().filterModel().ToDate(), '_blank');
        viewModel.main().filterModel().DistrictID(parseInt(event.feature.getProperty('id')));
        ViewSelectedMap(viewModel.main());
    });

    map.data.addListener('mouseover', function (event) {
        infowindow = new google.maps.InfoWindow({
            content: event.feature.getProperty('name'),
            map: map,
            position: new google.maps.LatLng(event.latLng.lat(), event.latLng.lng())
        });

        infowindow.open(map, this);

    });

    map.data.addListener('mouseout', function (event) {
        infowindow.setContent('');
        infowindow.close();
    });

    google.maps.event.addListenerOnce(map, 'idle', function () {
        bindEvents();
        // do something only the first time the map is loaded
    });

    $(".inner-content, .inner-content-sectry").niceScroll({ styler: "fb", cursorcolor: "#5cb85c", cursorwidth: '8', cursorborderradius: '0px', autohidemode: false, background: '#404040', cursorborder: '', zindex: '1000' });

    //if ($(".check-list input[type=checekbox]:checked").length == 1) {
    //    var chk = parseInt($(".check-list input[type=checkbox]:checked").val());
    //    $("#designation_" + chk +"> div").slideToggle();
    //}
}

function hideShow() {
    $('#legend > div').slideToggle('slow');
}

function hideShowOfficial() {
    //$('#legend-officials > div').slideToggle('slow');
}

function MakeOfficialsLegendsContainer(obj, makeOfficialsLegends) {
    var onlyOne = viewModel.main().DesignationVisits().length == 1 ? true : false;
    var legend = document.createElement('div');
    legend.id = obj.PanelID();
    legend.className = "legends";
    var content = [];
    content.push('<h3 style="font-size: 17px; font-weight: 600; display: inline-block;">' + obj.Title() + ' (' + obj.Count() + ')</h3><a onclick="hideShowOfficial();" class="btn btn-xs btn-success btn-collapseExpand-legendsOfficials pull-right">Hide/Show</a>');
    if (!onlyOne)
        content.push('<div class="inner-content-sectry" style="display: none; padding: 5px; margin: 5px 0; border: 1px solid #e5e5e5; border-radius: 3px; background: #f5f5f5; height: auto; overflow-y: auto !important;">');
    else
        content.push('<div class="inner-content-sectry" style="padding: 5px; margin: 5px 0; border: 1px solid #e5e5e5; border-radius: 3px; background: #f5f5f5; height: auto; overflow-y: auto !important; max-height: 466px !important;">');
    makeOfficialsLegends(obj, content, legend);
}

function makeOfficialsLegends(obj, content, legend) {

    obj.Visits().forEach(function (visit) {
        if (visit.IsVisitLog())
            content.push('<p><a class=btnDepartment data-designation=' + visit.DesignationName() + ' id=' + visit.DistrictID() + '>' + visit.DistrictName() + ' : (' + visit.VisitsCount() + ')</a></p>');
        else
            content.push('<p><a data-designation=' + visit.DesignationName() + ' id=' + visit.DistrictID() + '>' + visit.DistrictName() + ' : (' + visit.VisitsCount() + ')</a><span class="label label-success" style="margin-left: 10px;">Exempted</span></p>');
    });

    content.push('</div>');
    legend.innerHTML = content.join('');
    legend.index = 1;
    map.controls[google.maps.ControlPosition.LEFT_TOP].push(legend);

}

function MakeLegend() {
    // Create the legend and display on the map
    var legend = document.createElement('div');
    legend.id = 'legend';
    var content = [];
    content.push('<h3 style="font-size: 17px; font-weight: 600; display: inline-block;">District Wise Visits (' + viewModel.main().TotalDistrictVisitCount() + ')</h3><a onclick="hideShow();" class="btn btn-xs btn-success btn-collapseExpand-legends pull-right">Hide/Show</a>');

    var frmDate = viewModel.main().filterModel().FromDate();
    var toDate = viewModel.main().filterModel().ToDate();
    content.push('<div style="padding: 5px; margin: 5px 0; border: 1px solid #e5e5e5; border-radius: 3px; background: #f5f5f5;">' +
                 '<h5><div style="width: 15px; height: 15px; border: 1px solid #c5c5c5; background: #AAA8A5; display: inline-block;"></div>&nbsp;<span>0-4 visits</span></h5>' +
                 '<h5><div style="width: 15px; height: 15px; border: 1px solid #c5c5c5; background: #D65554; display: inline-block;"></div>&nbsp;<span>5-9 visits</span></h5>' +
                 '<h5><div style="width: 15px; height: 15px; border: 1px solid #c5c5c5; background: #D6A754; display: inline-block;"></div>&nbsp;<span>10-14 visits</span></h5>' +
                 '<h5><div style="width: 15px; height: 15px; border: 1px solid #c5c5c5; background: #569554; display: inline-block;"></div>&nbsp;<span>15 and above visits</span></h5></div>');


    content.push('<div class="inner-content" style="padding: 5px; margin: 3px 0; border: 1px solid #e5e5e5; border-radius: 3px; background: #f5f5f5;height: 435px; overflow-y: auto !important;">');
    content.push('<a class="btn-clear-district" onclick="ClearAll()"><i class="fa fa-times"></i>&nbsp;Clear</a>');

    for (i = 0; i < viewModel.main().Legends().length; i++) {
        content.push('<p><div class="color ' + viewModel.main().Legends()[i].Color().toLowerCase() + '"></div>&nbsp;<a class=btnDistrict id=' + viewModel.main().Legends()[i].DistrictID() + '>' + viewModel.main().Legends()[i].DistrictName() + ' : (' + viewModel.main().Legends()[i].VisitsCount() + ')</a></p>');

    }
    content.push('</div>');
    legend.innerHTML = content.join('');
    legend.index = 1;
    map.controls[google.maps.ControlPosition.RIGHT_TOP].push(legend);

    /**/
    ////var legend = document.createElement('div');
    ////legend.id = 'legend-officials';
    ////var content = [];
    ////content.push('<h3 style="font-size: 17px; font-weight: 600; display: inline-block;">Visits by Secretaries (' + viewModel.main().TotalDepartmentVisitCount() + ')</h3><a onclick="hideShowOfficial();" class="btn btn-xs btn-success btn-collapseExpand-legendsOfficials pull-right">Hide/Show</a>');

    ////content.push('<div class="inner-content-sectry" style="padding: 5px; margin: 5px 0; border: 1px solid #e5e5e5; border-radius: 3px; background: #f5f5f5; height: 465px; overflow-y: auto !important;">');
    ////for (i = 0; i < viewModel.main().Officials().length; i++) {
    ////    content.push('<p><a class=btnDepartment id=' + viewModel.main().Officials()[i].DistrictID() + '>' + viewModel.main().Officials()[i].DistrictName() + ' : (' + viewModel.main().Officials()[i].VisitsCount() + ')</a></p>');
    ////}
    ////content.push('</div>');
    ////legend.innerHTML = content.join('');
    ////legend.index = 1;
    ////map.controls[google.maps.ControlPosition.LEFT_TOP].push(legend);

    //for (var obj in viewModel.main().DesignationVisits()) {
    //    MakeOfficialsLegendsContainer(obj, makeOfficialsLegends);
    //}

    viewModel.main().DesignationVisits().forEach(function (obj) {
        MakeOfficialsLegendsContainer(obj, makeOfficialsLegends);
    });

}

function bindEvents() {
    $('body').on('click', 'a.btnDepartment', function (event) {
        //if (ref_districtID != undefined)
        //    LoadDepartmentDetailNew($(this).attr('id'), ref_districtID)
        //else
        //    LoadDepartmentDetail($(this).attr('id'));

        LoadVisitLogBreakdownDetails($(this).attr('id'), ref_districtID)

        viewModel.main().DepartmentID($(this).attr('id'));
        viewModel.main().DesignationName($(this).attr('data-designation'));
        viewModel.main().DepartmentName($(this).text().split(':')[0]);

    });


    $('body').on('click', 'a.btnDistrict', function (event) {
        LoadDistrictDetail($(this).attr('id'));
    });


    $('body').off('click', 'a.btn-collapseExpand-legendsOfficials').on('click', 'a.btn-collapseExpand-legendsOfficials', function (event) {
        $(this).parent().find('div').slideToggle('slow');
        event.preventDefault();
    });
}

function MakeMarkers() {
    for (i = 0; i < viewModel.main().Markers().length; i++) {
        var position = new google.maps.LatLng(viewModel.main().Markers()[i].Latitude(), viewModel.main().Markers()[i].Longitude());
        marker = new google.maps.Marker({
            position: position,
            map: map,
            animation: google.maps.Animation.DROP,
            title: viewModel.main().Markers()[i].Latitude() + ' , ' + viewModel.main().Markers()[i].Longitude()
        });

        var contentString = '<div class="infowindow-wrapper">' +
                                '<h5><b>Visited By:</b>&nbsp;' + viewModel.main().Markers()[i].EmployeeName() + ', ' + viewModel.main().Markers()[i].Designation() + '</h5>' +
                                '<h5><b>Place:</b>&nbsp;' + viewModel.main().Markers()[i].Place() + '</h5>' +
                                '<h5><b>Department:</b>&nbsp;' + viewModel.main().Markers()[i].Department() + '</h5>' +
                                '<h5><b>From:</b>&nbsp;' + viewModel.main().Markers()[i].StartDate() + ' ' + viewModel.main().Markers()[i].StartTime() + '</h5>' +
                                '<h5><b>To:</b>&nbsp;' + viewModel.main().Markers()[i].EndDate() + ' ' + viewModel.main().Markers()[i].EndTime() + '</h5>' +
                                '<h5><b>Rating:</b>&nbsp;' + viewModel.main().Markers()[i].Rating() + '</h5>' +
                            '</div>';
        var infoWindow = new google.maps.InfoWindow();


        google.maps.event.addListener(marker, 'click', (function (marker, contentString, infoWindow) {
            return function () {
                infoWindow.setContent(contentString);
                infoWindow.open(map, marker);
            };
        })(marker, contentString, infoWindow));
    }


}

function MakeInfoWindow() {

}

function MakeGeoJSON(url) {
    JsonData = {};

    //$.getJSON(url, function (json) {
    //    JsonData = json;
    //    map.data.addGeoJson(JsonData);
    //    Highligh();
    //});

    map.data.loadGeoJson(url);

    map.data.setStyle(function (feature) {
        var color = getColorName(feature.getProperty('name'));

        return /** @type {google.maps.Data.StyleOptions} */{
            fillColor: color,
            strokeColor: "#FFFF00",
            strokeWeight: 2,
            fillOpacity: 0.5
        };
    });
}

/*Multi Color*/
function Highligh() {
    if (poly != undefined)
        poly.setMap(null);

    for (i = 0; i < JsonData.features.length; i++) {
        //if (JsonData.features[i].properties.name == 'Lahore') {
        //    ColorMe(JsonData.features[i], 'blue')
        //}
        //if (JsonData.features[i].properties.name == 'Faisalabad') {
        //    ColorMe(JsonData.features[i], 'green')
        //}
        ko.utils.arrayForEach(viewModel.main().Legends(), function (dist) {
            if (dist.DistrictName().toLowerCase() == JsonData.features[i].properties.name.toLowerCase()) {
                ColorMe(JsonData.features[i], dist.Color().toLowerCase());
            }
        });
    }

    setPolyGone();
}

function ColorMe(JsonData, fillcolor) {
    // collect polygon points
    polyPath = [];
    if (JsonData.geometry.geometries) {
        for (var i = 0; i < JsonData.geometry.length; i++) {
            for (var j = 0; j < JsonData.geometry[i].geometries.length; j++) {
                for (var p = 0; p < JsonData.geometry[i].geometries[j].coordinates[0].length; p++) {
                    polyPath.push(new google.maps.LatLng(JsonData.geometry[i].geometries[j].coordinates[0][p][1], JsonData.geometry[i].geometries[j].coordinates[0][p][0]));
                }
            }
        }
    }
    else {
        for (var p = 0; p < JsonData.geometry.coordinates[0].length; p++) {
            polyPath.push(new google.maps.LatLng(JsonData.geometry.coordinates[0][p][1], JsonData.geometry.coordinates[0][p][0]));
        }
    }

}


function setPolyGone() {
    poly = new google.maps.Polygon({
        paths: polyPath,
        clickable: true
    });

    poly.setMap(map);
}

function getColorName(distName) {
    if (viewModel.main().Legends() != null && viewModel.main().Legends() != '' && viewModel.main().Legends().length > 0) {
        for (var i = 0; i < viewModel.main().Legends().length; i++) {
            if (viewModel.main().Legends()[i].DistrictName().toString().toLowerCase() == distName.toString().toLowerCase()) {
                return viewModel.main().Legends()[i].Color();
            }
        }
    }
}

function getIDbyName(name) {
    return ko.utils.arrayFilter(viewModel.main().RatingHeader(), function (rat) {
        return rat.Title().toString().toLowerCase() === name.toLowerCase();
    })[0].ID();
}