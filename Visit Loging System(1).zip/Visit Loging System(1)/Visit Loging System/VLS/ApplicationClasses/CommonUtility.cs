﻿using BE;
using BE.Common;
using BE.EmailQueue;
using BE.LogManager;
using BLL;
using BLL.CommonUtility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace VLS.ApplicationClasses
{
    public class CommonUtility
    {
        public CommonListModel GetCommonLookups()
        {
            CommonListModel commonListModel = null;
            try
            {
                LookupModel model =new LookupModel();
                //model.SectorID = CurrentUser.SectorID ;
                //model.SubSectorID =  CurrentUser.SubSectorID ;
                //model.DistrictID = CurrentUser.DistrictID ;
                //model.TehsilID = CurrentUser.TehsilID ;
                 commonListModel = LazyBaseSingletonBLL<CommonBLL>.Instance.GetCommonUserLookups(model);
                return commonListModel;
            }
            catch(Exception ex)
            {

            }
            return commonListModel;

        }

        public CommonListModel GetDashBoardCommonUserLookups()
        {
            CommonListModel commonListModel = null;
            try
            {
                LookupModel model = new LookupModel();
                model.SectorID = CurrentUser.SectorID;
                model.SubSectorID = CurrentUser.SubSectorID;
                commonListModel = LazyBaseSingletonBLL<CommonBLL>.Instance.GetDashBoardCommonUserLookups(model, CurrentUser.LoginID);
                return commonListModel;
            }
            catch (Exception ex)
            {

            }
            return commonListModel;

        }

        /// <summary>
        /// Add application exeception information
        /// </summary>
        /// <param name="model"></param>
        public void AddErrorLog(ErrorLogModel model)
        {
            new ErrorLogBLL().Save(model);
        }

        public List<DateTime> GetWeekDays(int Month, int Year)
        {
            DateTime date = DateTime.Today;

            // first generate all dates in the month of 'date'
            var dates = Enumerable.Range(1, DateTime.DaysInMonth(date.Year, date.Month)).Select(n => new DateTime(date.Year, date.Month, n));
            // then filter the only the start of weeks
            var weekends = from d in dates
                           where d.DayOfWeek == DayOfWeek.Monday
                           select d;

            return weekends.ToList();
        }

        /// <summary>
        /// Convert MM/dd/yyyy format to dd/MM/yyyy format
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public DateTime ConvertDateFormat(string value)
        {
            DateTime Date = new DateTime();

            string[] arrValue = value.Split('/');
            if (arrValue.Length == 3)
            {
                Date = new DateTime(Convert.ToInt16(arrValue[2]), Convert.ToInt16(arrValue[1]), Convert.ToInt16(arrValue[0]));
            }

            return Date;
        }

        /// <summary>
        /// Send an email notification
        /// </summary>
        /// <param name="Receiver"></param>
        /// <param name="Subject"></param>
        /// <param name="Body"></param>
        public void MailSend(string Receiver, string Subject, string Body)
        {
            try
            {
                string Sender = ConfigurationHelper.EMailSenderAddress;
                string SenderPassword = ConfigurationHelper.EMailSenderPassword;
                string MailServer = ConfigurationHelper.SMTPServer;
                int MailServerPort = ConfigurationHelper.SMTPServerPort;
                bool EnableSSL = ConfigurationHelper.SMTPEnableSSL;

                MailMessage mM = new MailMessage();

                mM.From = new MailAddress(Sender);  // set email sender
                mM.To.Add(Receiver);    // set receiver email
                mM.Subject = Subject;   // set email subject
                mM.Body = Body;         // set email body
                mM.IsBodyHtml = true;

                // open smtp client 
                SmtpClient Server = new SmtpClient(MailServer, MailServerPort);
                Server.UseDefaultCredentials = true;
                Server.Credentials = new System.Net.NetworkCredential(Sender, SenderPassword);
                Server.Port = MailServerPort;   // set port number
                Server.Host = MailServer;
                Server.EnableSsl = EnableSSL;
                Server.DeliveryMethod = SmtpDeliveryMethod.Network;

                //Added this to bypass the certificate validation
                ServicePointManager.ServerCertificateValidationCallback = delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                Server.Send(mM);    // send email

                mM.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Send a sms alert
        /// </summary>
        /// <param name="MobileNo"></param>
        /// <param name="Message"></param>
        public void SendSMSAlert(string MobileNo, string Message)
        {
            SMSSendModel sms = new SMSSendModel(MobileNo, Message);
            string Data = "";

            try
            {
              
                    // serailze model object to json string
                    DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(SMSSendModel));
                    MemoryStream mem = new MemoryStream();
                    ser.WriteObject(mem, sms);
                    Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                    // process the request and get response as string
                    string ServiceURL = ConfigurationHelper.SMSGatewayURL;

                    WebClient webClient = new WebClient();
                    webClient.Headers["Content-type"] = "application/json";
                    webClient.Encoding = Encoding.UTF8;

                    Uri address = new Uri(ServiceURL);
                    webClient.UploadString(address, "POST", Data);
                
            }
            catch (Exception ex)
            {
                throw new Exception("SMS alert fail. " + ex.Message);
            }
        }
        public void SendEmailToQueue(EmailModel emailModel)
        {
          //  SMSSendModel sms = new SMSSendModel(MobileNo, Message);
            string Data = "";

            try
            {
                // serailze model object to json string
                DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(EmailModel));
                MemoryStream mem = new MemoryStream();
                ser.WriteObject(mem, emailModel);
                Data = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

                // process the request and get response as string
                string serviceURL = ConfigurationHelper.EmailQueueURL;

                WebClient webClient = new WebClient();
                webClient.Headers["Content-type"] = "application/json";
                webClient.Encoding = Encoding.UTF8;

                Uri address = new Uri(serviceURL);
                webClient.UploadString(address, "POST", Data);
            }
            catch (Exception ex)
            {
                throw new Exception("SMS alert fail. " + ex.Message);
            }
        }

        /// <summary>
        /// Get file bytes against porivded stream
        /// </summary>
        /// <param name="inputstm"></param>
        /// <returns></returns>
        public Byte[] GetFileContent(System.IO.Stream inputstm)
        {
            Stream fs = inputstm;
            BinaryReader br = new BinaryReader(fs);
            Int32 lnt = Convert.ToInt32(fs.Length);

            byte[] bytes = br.ReadBytes(lnt);

            return bytes;
        }
    }
}