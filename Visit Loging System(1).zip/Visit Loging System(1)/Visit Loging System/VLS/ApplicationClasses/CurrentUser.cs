﻿
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.SessionState;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using VLS.BE.SessionState;

namespace VLS.ApplicationClasses
{
    public class CurrentUser
    {
       

        public static int? LoginID
        {
            get
            {
                if (HttpContext.Current.Session["LoginID"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel==null)
                    {
                        return null;
                    }
                    return userModel.UserID;
                  
                }
                else
                {

                    return Convert.ToInt32(HttpContext.Current.Session["LoginID"]);
                }
            }

        }
        public static string  UserDisplayName
        {
            get
            {
                if (HttpContext.Current.Session["EmployeeName"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.EmployeeName;
                  

                }
                else
                {

                    return Convert.ToString(HttpContext.Current.Session["EmployeeName"]);
                }
            }

        }
        public static string LoginName
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.UserName;                 
               
            }

        }


        public static int? DivisionID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.DivisionID;

            }

        }
        public static int? DistrictID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.DistrictID;

            }

        }

        public static int? TehsilID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.TehsilID;

            }

        }

        public static int? SectorID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.SectorID;

            }

        }

        public static int? SubSectorID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.SubSectorID;

            }

        }

        public static int? DepartmentID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.DepartmentID;

            }

        }

        public static int? PermitGroupID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.PermitGroupID;

            }

        }

        public static UserModel CurrentUserInfo
        {
            get
            {
                return GetSessionUserInfo();
            }

        }


        public static string Url
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.Url;

            }
        }

        public static string DistrictCode
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.DistrictCode;

            }
        }

        public static int? UserTypeID
        {
            get
            {
                if (HttpContext.Current.Session["UserTypeID"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.UserTypeID;
                }
                else
                {
                    return Convert.ToInt32(HttpContext.Current.Session["UserTypeID"]);
                }
            }

        }

        public static string  UserDepartmentName
        {
            get
            {
                if (HttpContext.Current.Session["UserDepartmentName"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.DepartmentName;
                }
                else
                {
                    return Convert.ToString (HttpContext.Current.Session["UserDepartmentName"]);
                }
            }

        }
        public static string UserDesignationName
        {
            get
            {
                if (HttpContext.Current.Session["DesignationName"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.DesignationName;
                }
                else
                {
                    return Convert.ToString(HttpContext.Current.Session["DesignationName"]);
                }
            }

        }
        
        public static string UserDivisionName
        {
            get
            {
                if (HttpContext.Current.Session["UserDivisionName"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.DivisionName;
                }
                else
                {
                    return Convert.ToString(HttpContext.Current.Session["UserDivisionName"]);
                }
            }

        }

        public static string UserDistrictName
        {
            get
            {
                if (HttpContext.Current.Session["UserDistrictName"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.DistrictName;
                }
                else
                {
                    return Convert.ToString(HttpContext.Current.Session["UserDistrictName"]);
                }
            }

        }
        

        public static string DashboardTitle
        {
            get
            {
               
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    if (userModel.DesignationID == 1)
                        return UserDesignationName + " " + UserDivisionName;
                    else if (userModel.DesignationID == 2)
                        return UserDesignationName + " " + UserDepartmentName;
                    else if (userModel.DesignationID == 3)
                        return UserDesignationName + " " + UserDistrictName;
                    else if (userModel.DesignationID == 4)
                        return UserDesignationName + " " + UserDistrictName;
                    else if (userModel.DesignationID == 5)
                        return UserDesignationName + " " + UserDistrictName;
                    else return null;
            }

        }


        public static UserModel GetSessionUserInfo()
        {
            UserModel moedel = null;
            if (HttpContext.Current.Session["CurrentUser"] == null)
            {
                if (HttpContext.Current.Request.Cookies["LoginID"] != null)
                {

                    int loingID = Convert.ToInt32(HttpContext.Current.Request.Cookies["LoginID"].Value);
                    moedel = new UserBLL().GeLoginUserInfoByLogin(loingID);
                    SetUserSessionValue(moedel);
                    //HttpContext.Current.Response.Cookies["LoginID"].Value = moedel.UserID.ToString();
                    //HttpContext.Current.Response.Cookies["LoginID"].Expires = DateTime.Now.AddDays(1);
                    //HttpContext.Current.Response.Cookies["UserName"].Value = moedel.UserName.ToString();
                    //HttpContext.Current.Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(1);
                    //HttpContext.Current.Session["CurrentUser"] = moedel;
                    //HttpContext.Current.Session["LoginID"] = moedel.UserID;
                    //HttpContext.Current.Session["EmployeeName"] = moedel.EmployeeName;
                    //HttpContext.Current.Session["UserTypeID"] = moedel.UserTypeID;
                }
                else
                {
                    if (ConfigurationHelper.SQLServer.HasValue && ConfigurationHelper.SQLServer.Value)
                    {


                        //Get Session State form Database
                        SessionStateModel sessionStateModel = LazyBaseSingletonBLL<SessionStateBLL>.Instance.GetSessiontStateByID(HttpContext.Current.Session.SessionID);
                        if (sessionStateModel != null)
                        {
                            SerializeDeserialize<UserModel> xmlObj = new SerializeDeserialize<UserModel>();
                            moedel = (UserModel)xmlObj.DeserializeData(sessionStateModel.XmlObject);
                            SetUserSessionValue(moedel);
                        }
                        else
                        {
                            return null;
                        }
                    }
                    else
                        return null;
                    
                }

            }
            else
            {
                moedel = (UserModel)(HttpContext.Current.Session["CurrentUser"]);
            }

            return moedel;
        }

        private static void SetUserSessionValue(UserModel moedel)
        {
            HttpContext.Current.Response.Cookies["LoginID"].Value = moedel.UserID.ToString();
            HttpContext.Current.Response.Cookies["LoginID"].Expires = DateTime.Now.AddDays(1);
            HttpContext.Current.Response.Cookies["UserName"].Value = moedel.UserName.ToString();
            HttpContext.Current.Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(1);
            HttpContext.Current.Session["CurrentUser"] = moedel;
            HttpContext.Current.Session["LoginID"] = moedel.UserID;
            HttpContext.Current.Session["EmployeeName"] = moedel.EmployeeName;
            HttpContext.Current.Session["UserTypeID"] = moedel.UserTypeID;
        }

       
    }
}