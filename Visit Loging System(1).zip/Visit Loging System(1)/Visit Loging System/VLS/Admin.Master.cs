﻿using BE.CustomEnums;
using BE.LogManager;
using BLL.CommonUtility;
using BLL.RightsManager;
using BLL.SessionState;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS
{
    public partial class Admin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
               
                if (CurrentUser.LoginID.HasValue && CurrentUser.LoginID.Value > 0)
                {
                    string staticPageName = System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath);
                  

                    bool isValidPageAccess = false;
                    if (staticPageName.Contains("Dashboard"))
                    {
                        isValidPageAccess = LazyBaseSingletonBLL<CommonBLL>.Instance.GetUserPageAccess(CurrentUser.LoginID, staticPageName, 1);
                    }
                    else
                    {
                        isValidPageAccess = LazyBaseSingletonBLL<CommonBLL>.Instance.GetUserPageAccess(CurrentUser.LoginID, staticPageName);
                    }

                    if (!isValidPageAccess)
                    {
                        Response.Redirect("~/Error.aspx?errorMessage=" + CutomMessage.NotAuthorizedToPage, false);
                    }
                    else if (CurrentUser.LoginID.HasValue)
                    {
                        lblLoginUserName.Text = CurrentUser.UserDisplayName;
                        BuildMenu(CurrentUser.LoginID);
                    }  
                 
                }
                else
                    Response.Redirect("~/Login.aspx", false);
                
               

            }
            catch (Exception ex)
            {
                //LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "PageLoad", 1, System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath), CurrentUser.GetSessionUserInfo()));
                //Response.Redirect("~/Error.aspx?errorMessage="+ex.Message, false);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "PageLoad", 1, System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath), CurrentUser.GetSessionUserInfo()));
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                    // featuresModel = new ApplicationFeatureModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    Response.Redirect("../../Layouts/Error.aspx?errorMessage=" + ex.Message, false);
                }
            }
        }

        #region Internal Methods
        private void BuildMenu(int? LoginID)
        {
            Panel pnlMenu = (Panel)this.FindControl("pnlMenu");
            StringBuilder menu = new StringBuilder();
            try
            {
                DataSet ds = new MenuBLL().GetMenuByUser(LoginID.Value);
                DataTable dt = ds.Tables[0];

                if (dt.Rows.Count > 0)
                {
                    dt.DefaultView.Sort = "Sort";
                    menu.AppendLine("<div id='sidebar' class='nav-collapse'><ul class='sidebar-menu'>");

                    foreach (DataRow dr in dt.Rows)     //loop for Features
                    {
                        menu.AppendLine("<li class='sub-menu'>");

                        if (Convert.ToBoolean(dr["HasChild"].ToString()) == true)
                        {
                            menu.AppendLine("<a href='javascript:;' class=''><i class='fa fa-chevron-right'></i>");
                            menu.AppendLine("<span>" + dr["MenuName"].ToString() + "</span><span class='arrow'></span></a>");
                            menu.AppendLine("<ul class='sub'>");

                            DataRow[] drObjects = ds.Tables[1].Select("AppFeatureID = " + dr["FeatureID"].ToString());
                            foreach (DataRow odr in drObjects)   // loop for Objects
                            {
                                menu.AppendLine("<li><a class='' href='" + odr["URL"] + "'>" + odr["Name"].ToString() + "</a></li>");
                            }   //end objects loop

                            menu.AppendLine("</ul></li>");
                        }
                        else
                            menu.AppendLine("<a class='' href='" + dr["URL"] + "' title='" + dr["MenuName"] + "'><i class='" + dr["Icon"] + "'></i><span>" + dr["Name"].ToString() + "</span></a></li>");

                    }   //end features loop

                    menu.AppendLine("</ul></div>");

                    pnlMenu.Controls.Add(new LiteralControl(menu.ToString()));
                }
            }
            catch (Exception ex)
            {
                pnlMenu.Controls.Add(new LiteralControl("<span>" + ex.Message + "</span>"));
            }
        }
        #endregion 

        #region "Button Events"

        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            try
            {
                HttpCookie aCookie;
                string cookieName;
                int limit = Request.Cookies.Count;
                for (int i = 0; i < limit; i++)
                {
                    cookieName = Request.Cookies[i].Name;
                    aCookie = new HttpCookie(cookieName);
                    aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                    Response.Cookies.Add(aCookie); // overwrite it
                }

                if (ConfigurationHelper.SQLServer.HasValue && ConfigurationHelper.SQLServer.Value)
                    LazyBaseSingletonBLL<SessionStateBLL>.Instance.DeleteSessionByID(Session.SessionID);
                Session.Clear();
                Session.Abandon();
                Response.Redirect("~/Login.aspx", false);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion
    }
}