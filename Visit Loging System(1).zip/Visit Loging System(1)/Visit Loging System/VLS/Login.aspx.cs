﻿using BE.CustomEnums;
using BE.LogManager;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.SessionState;
using BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VLS.ApplicationClasses;

namespace VLS
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    ////under pageload of logout.aspx
                    //if (Request.QueryString["action"] != null)
                    //{
                    //    Session.Clear();
                    //    Session.Abandon();

                    //    HttpCookie aCookie;
                    //    string cookieName;
                    //    int limit = Request.Cookies.Count;
                    //    for (int i = 0; i < limit; i++)
                    //    {
                    //        cookieName = Request.Cookies[i].Name;
                    //        aCookie = new HttpCookie(cookieName);
                    //        aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                    //        Response.Cookies.Add(aCookie); // overwrite it
                    //    }

                    //}
                }
            }
            catch (Exception ex)
            {
                //TODO: LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "Page_Load", 1, PageNames.Login, new UserModel()));
            }
        }

        #region Custom Methods

        internal static bool AuthenticationAD(string userName, string password)
        {
            bool isvalidate = false;

            try
            {
                //Validate User form databae
               // UserBLL userBLL = new UserBLL();
                isvalidate = LazyBaseSingletonBLL<UserBLL>.Instance.IsValidateUser(userName, password); 
               // isvalidate = userBLL.IsValidateUser(userName, password);
            }
            catch (Exception ex)
            {
                //TODO: LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "AuthenticationAD", 1, PageNames.Login, new UserModel()));
            }
            return isvalidate;
        }

        #endregion

        #region Button Events

        protected void btnAuthenticate_Click(object sender, EventArgs e)
        {
            //string url = string.Empty;
            //try
            //{
            //    if (AuthenticationAD(txtLoginName.Text, txtPassword.Text))
            //    {
            //        UserModel currentUser = new UserBLL().GeLoginUserInfoByLogin(txtLoginName.Text);
            //        if (currentUser != null)
            //        {

            //            HttpContext.Current.Response.Cookies["LoginID"].Value = currentUser.UserID.ToString();
            //            HttpContext.Current.Response.Cookies["LoginID"].Expires = DateTime.Now.AddDays(1);
            //            HttpContext.Current.Response.Cookies["UserName"].Value = currentUser.UserName.ToString();
            //            HttpContext.Current.Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(1);
            //            HttpContext.Current.Session["CurrentUser"] = currentUser;
            //            HttpContext.Current.Session["LoginID"] = currentUser.UserID;
            //            HttpContext.Current.Session["EmployeeName"] = currentUser.EmployeeName;
            //            url = currentUser.Url;
            //        }
            //        else
            //        {
            //            //User is not registered.Please contact with administrator.
            //            url = "~/Error.aspx?error|User is not registered.Please contact with administrator.";
            //        }
            //        Response.Redirect(url, false);
            //    }
            //    else
            //    {
            //        //Invalid password or login.
            //        txtLoginName.Text = "";
            //        txtPassword.Text = "";
            //        string script = "toastr.error('Invalid username or password.');";
            //        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
            //    }

            //}
            //catch (Exception ex)
            //{
            //    //LazySingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "btnAuthenticate_Click", 1, PageNames.Login, new UserModel()));
            //    //   ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ex.Message + "');", true);  

            //}

            try
            {
                string url = string.Empty;
                try
                {
                    if (AuthenticationAD(txtLoginName.Text, txtPassword.Text))
                    {
                        UserModel currentUser = new UserBLL().GeLoginUserInfoByLogin(txtLoginName.Text);
                        if (currentUser != null)
                        {

                            HttpContext.Current.Response.Cookies["LoginID"].Value = currentUser.UserID.ToString();
                            HttpContext.Current.Response.Cookies["LoginID"].Expires = DateTime.Now.AddDays(1);
                            HttpContext.Current.Response.Cookies["UserName"].Value = currentUser.UserName.ToString();
                            HttpContext.Current.Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(1);
                            HttpContext.Current.Session["CurrentUser"] = currentUser;
                            HttpContext.Current.Session["LoginID"] = currentUser.UserID;
                            HttpContext.Current.Session["EmployeeName"] = currentUser.EmployeeName;
                            HttpContext.Current.Session["UserDepartmentName"] = currentUser.DepartmentName;
                            HttpContext.Current.Session["UserDesignationName"] = currentUser.DesignationName;
                            HttpContext.Current.Session["UserDistrictName"] = currentUser.DistrictName;
                            HttpContext.Current.Session["UserDivisionName"] = currentUser.DivisionName;
                            
                            url = currentUser.Url;
                            //==Save Session state in DB
                            if (ConfigurationHelper.SQLServer.HasValue && ConfigurationHelper.SQLServer.Value)
                                this.SaveSessionState(currentUser);
                            Response.Redirect(url, false);

                        }
                        else
                        {
                            //User is not registered.Please contact with administrator.
                           // url = "~/Error.aspx?error|User is not registered.Please contact with administrator.";
                            //Invalid password or login.
                            txtLoginName.Text = "";
                            txtPassword.Text = "";
                            string script = "toastr.info('User has been blocked. Please contact with administrator.');";
                            ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                        }
                       // Response.Redirect(url, false);
                    }
                    else
                    {
                        //Invalid password or login.
                        txtLoginName.Text = "";
                        txtPassword.Text = "";
                        string script = "toastr.info('Invalid username or password.');";
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", script, true);
                    }

                }
                catch (Exception ex)
                {
                  //  LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "btnAuthenticate_Click", 1, PageNames.Login, new UserModel()));
                    //   ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ex.Message + "');", true);  
                    string errorCode = string.Empty;
                    errorCode = LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnAuthenticate_Click", 1, PageNames.Login, CurrentUser.GetSessionUserInfo()));
                    if (ConfigurationHelper.IsShowGeneralMsg)
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);  
                       // featuresModel = new ApplicationFeatureModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);  
                       // featuresModel = new ApplicationFeatureModel("error|" + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        #endregion

        #region Internal Methods
        internal void SaveSessionState(UserModel user)
        {
            try
            {
                SerializeDeserialize<UserModel> xmlObj = new SerializeDeserialize<UserModel>();
                string strUser = xmlObj.SerializeData(user);
                LazyBaseSingletonBLL<SessionStateBLL>.Instance.SaveSessionState(Session.SessionID, strUser, user.UserID, ConfigurationHelper.TimeOute);
            }
            catch (Exception ex)
            {
                LazyBaseSingletonBLL<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveSessionState", 1, PageNames.Login, new UserModel()));
            }
        }
        #endregion 
    }
}