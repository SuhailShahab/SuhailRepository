﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using DAL.Generic;
using BE.Lookups;


namespace DAL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil >
    // Create date: <7/10/2014 2:07:32 AM>
    // =================================================================================================================================
    // ===================================================== Modification City  ======================================================
    // =================================================================================================================================

    public class CityDAL : DALBase
    {

        /// <summary>
        /// Add City information
        /// </summary>
        /// <param name="CityModel">Set object of cityModel type</param>
        /// <returns></returns>
        public int Add(CityModel model)
        {
            object result = 0;
            using(SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddCity";

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                        result = sqlCmd.ExecuteScalar();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Update City information
        /// </summary>
        /// <param name="cityModel">Set object of cityModel type</param>
        /// <returns></returns>
        public int Edit(CityModel cityModel)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spEditCity";

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(cityModel, sqlCmd);

                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();                       
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Delete City information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(CityModel model)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spDeleteCity";

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();                       
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Get all Cities
        /// </summary>
        /// <returns></returns>
        public DataTable SelectCities()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCity", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                   
                }
            }
        }

        /// <summary>
        /// Get all Active Cities for dropdown 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllCities()
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCities", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    
   
    }
}
