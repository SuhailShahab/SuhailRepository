﻿using BE.Lookups;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DAL.Lookups
{
    public class ProvinceDAL : DALBase
    {
        #region "Constructors"

        public ProvinceDAL()
        {

        }

        public ProvinceDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }

        public ProvinceDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        #endregion


        public int Add(ProvinceModel provinceModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;                
                sqlCmd.CommandText = "spAddProvince";

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = provinceModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = provinceModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = provinceModel.Status.Value ? 1 : 0;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = provinceModel.CreatedBy.Value;

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        public int Edit(ProvinceModel provinceModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditProvince";

                sqlCmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int));
                sqlCmd.Parameters["@ID"].Value = provinceModel.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = provinceModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = provinceModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = provinceModel.ModifiedBy;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));

                if (provinceModel.Status.HasValue)
                {
                    sqlCmd.Parameters["@IsActive"].Value = provinceModel.Status.Value ? 1 : 0;
                }
                else
                    sqlCmd.Parameters["@IsActive"].Value = 0;

                result = Convert.ToInt32(sqlCmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        public int Delete(int id)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteProvince";

                sqlCmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int));
                sqlCmd.Parameters["@ID"].Value = id;

                result = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        public DataTable GetAllProvinces()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllProvinces", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        public DataTable GetAllActiveProvinces()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveProvinces", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
             
                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
}
