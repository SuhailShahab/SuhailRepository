﻿using BE.Lookups;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <24-03-2016 10:03:08PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
//   SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace DAL.Lookups
{
    public class DivisionDAL : DALBase
    {
        /// <summary>
        /// save Division information
        /// </summary>
        /// <param name="relationModel">Set object of DivisionModel type</param>
        /// <returns></returns>
        public int? Add(DivisionModel divisionModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddDivision";

                SetSqlParameters(divisionModel, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = divisionModel.CreatedBy;

                result = sqlCmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Update Division information
        /// </summary>
        /// <param name="divisionModel">Set object of DivisionModel type</param>
        /// <returns></returns>
        public int? Edit(DivisionModel divisionModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();

                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditDivision";

                SetSqlParameters(divisionModel, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@DivisionID"].Value = divisionModel.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = divisionModel.ModifiedBy;

                result = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// Delete Division information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, int modifiedBy)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteDivision";

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@DivisionID"].Value = id;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                result = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// Get all Active Divisions use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {    
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDivisions", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return dt;
        }

        /// <summary>
        /// Get all Active Divisions use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll(int? divisionID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDivisions", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                if (divisionID.HasValue && divisionID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                }

                sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return dt;
        }

        /// <summary>
        /// Get all Division
        /// </summary>
        /// <returns></returns>
        public DataTable Select()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDivision", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return dt;
        }

        #region "Private Methods"

        private static void SetSqlParameters(DivisionModel divisionModel, SqlCommand sqlCmd)
        {
            sqlCmd.Parameters.Add(new SqlParameter("@ProvinceID", SqlDbType.Int));
            sqlCmd.Parameters["@ProvinceID"].Value = divisionModel.ProvinceID;

            sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Title"].Value = divisionModel.Title;

            sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Description"].Value = divisionModel.Description;

            sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
            if (divisionModel.Status.HasValue)
            {
                sqlCmd.Parameters["@IsActive"].Value = divisionModel.Status.Value ? 1 : 0;
            }
            else
                sqlCmd.Parameters["@IsActive"].Value = 0;
        }

        #endregion
    }
}
