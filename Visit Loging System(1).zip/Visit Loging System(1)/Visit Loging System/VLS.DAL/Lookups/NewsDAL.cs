﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using DAL.Generic;
using BE.Lookups;


namespace DAL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Sabeeh Goheer>
    // Create date: <20/04/2016 1:04:04 AM>
    // =================================================================================================================================
    // ===================================================== Modification News  ======================================================
    // =================================================================================================================================

    public class NewsDAL : DALBase
    {

        /// <summary>
        /// Add News information
        /// </summary>
        /// <param name="NewsModel">Set object of NewsModel type</param>
        /// <returns></returns>
        public int Add(NewsModel model)
        {
            object result = 0;
            using(SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddNews";

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                        sqlCmd.Parameters.Add(new SqlParameter("@Image", SqlDbType.Binary));
                        sqlCmd.Parameters["@Image"].Value = ConvertBase64ToBytes(model.Image);

                        result = sqlCmd.ExecuteScalar();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Update news information
        /// </summary>
        /// <param name="NewsModel">Set object of NewsModel type</param>
        /// <returns></returns>
        public int Edit(NewsModel NewsModel)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spEditNews";

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(NewsModel, sqlCmd);

                        sqlCmd.Parameters.Add(new SqlParameter("@Image", SqlDbType.Binary));
                        sqlCmd.Parameters["@Image"].Value = ConvertBase64ToBytes(NewsModel.Image);

                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();                       
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Delete News information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(NewsModel model)
        {
            int result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spDeleteNews";

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();                       
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Get all News
        /// </summary>
        /// <returns></returns>
        public DataTable SelectNews()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetNews", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                   
                }
            }
        }
        public DataTable SelectSiteInfo()
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSiteInfo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();

                }
            }
        }

        /// <summary>
        /// Get all Active News for dropdown 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllNews()
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllNews", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get News by id 
        /// </summary>
        /// <returns></returns>
        public DataTable GetNewsByID(int NewsID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetNewsByID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@NewsID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@NewsID"].Value = NewsID;

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private byte[] ConvertBase64ToBytes(string content)
        {
            byte[] bytes = new byte[content.Length * sizeof(char)];
            System.Buffer.BlockCopy(content.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }
    }
}
