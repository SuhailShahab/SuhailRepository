﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VLS.DAL.Lookups
{
    public class AssigneeRecordDAL : DALBase
    {

        public int? Save(DataTable dt , int? departmentID)
        {
            int? result;
           

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlCommand sqlCmd = new SqlCommand();
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "spAddAssigningRecordMapping";

                    if (departmentID.HasValue)
                    {
                        sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlCmd.Parameters["@DepartmentID"].Value = departmentID;
                    }
                    sqlCmd.Parameters.Add(new SqlParameter("@AssignRecordMapping", SqlDbType.Structured));
                    sqlCmd.Parameters["@AssignRecordMapping"].Value = dt;

                    result = sqlCmd.ExecuteNonQuery();
                    if (con.State == ConnectionState.Open)
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                result = -1;
                throw ex;
            }
            //finally
            //{
            //    if (con.State == ConnectionState.Open)
            //    {
            //        con.Close();
            //        con.Dispose();
            //    }

            //}

            return result;
        }

        public DataTable GetAllByDepartmentID(int? departmentID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAssigningRecordMappingsByDept", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                   
                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int Delete(int id)
        {
            int _result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteRecordMapping";

                sqlCmd.Parameters.Add(new SqlParameter("@RecordID", SqlDbType.Int));
                sqlCmd.Parameters["@RecordID"].Value = id;

                _result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();

            }

            return _result;
        }

        
    }
}
