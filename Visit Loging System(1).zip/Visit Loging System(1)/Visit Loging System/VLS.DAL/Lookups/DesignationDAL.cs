﻿using BE.Lookups;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Lookups
{
    public class DesignationDAL : DALBase
    {
        /// <summary>
        /// Add  Designation Information 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(DesignationModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddDesignation";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }

            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Modify  Designation Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Edit(DesignationModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditDesignation";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// disable  Designation information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(DesignationModel model)
        {
            int _result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteDesignation";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                _result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Get All  Designation Records
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDesignations", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get Constituency Records
        /// </summary>
        /// <returns></returns>
        public DataTable GetDesignation()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDesignation", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get selected desginations against user
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public DataTable GetUsersDesignations(int userID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);

                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUsersDesignations", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }


        /// <summary>
        /// Get Designation on the basis of visited department person Designation
        /// </summary>
        /// <param name="userID">Visited person user ID</param>
        /// <returns></returns>
        public DataTable GetDashboardDesignations(int userID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);

                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashboardDesignations", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get designations on basis of facility
        /// </summary>
        /// <param name="facilityID"></param>
        /// <returns></returns>
        public DataTable GetDesignationByFacility(int facilityID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);

                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDesignationsByFacility", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID;

                sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

    }
}
