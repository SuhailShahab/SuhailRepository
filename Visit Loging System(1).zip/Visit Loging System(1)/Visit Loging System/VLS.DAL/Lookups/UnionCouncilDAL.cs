﻿using BE.Lookups;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil >
// Create date: <7/10/2014 2:07:32 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription

// =================================================================================================================================
namespace DAL.Lookups
{
    public class UnionCouncilDAL : DALBase
    {
        /// <summary>
        /// Add Union Council information
        /// </summary>
        /// <param name="unionCouncilModel">Set object of UnionCouncilModel type</param>
        /// <returns></returns>
        public int Add(UnionCouncilModel unionCouncilModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddUnionCouncil";

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = unionCouncilModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@DistrictID"].Value = unionCouncilModel.DistrictID;

                sqlCmd.Parameters.Add(new SqlParameter("@TehsilID", SqlDbType.Int));
                sqlCmd.Parameters["@TehsilID"].Value = unionCouncilModel.TehsilID;

            

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = unionCouncilModel.Description == null ? "" : unionCouncilModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = unionCouncilModel.Status ? 1 : 0;

                // added against CR:002
                sqlCmd.Parameters.Add(new SqlParameter("@AccountNo", SqlDbType.VarChar));
                sqlCmd.Parameters["@AccountNo"].Value = unionCouncilModel.AccountNo == null ? "" : unionCouncilModel.AccountNo;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CreatedBy"].Value = unionCouncilModel.CreatedBy.Value;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Update Union Council information
        /// </summary>
        /// <param name="unionCouncilModel">Set object of unionCouncilModel type</param>
        /// <returns></returns>
        public int Edit(UnionCouncilModel unionCouncilModel)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditUnionCouncil";

                sqlCmd.Parameters.Add(new SqlParameter("@UnionCouncilID", SqlDbType.Int));
                sqlCmd.Parameters["@UnionCouncilID"].Value = unionCouncilModel.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@DistrictID"].Value = unionCouncilModel.DistrictID;

                sqlCmd.Parameters.Add(new SqlParameter("@TehsilID", SqlDbType.Int));
                sqlCmd.Parameters["@TehsilID"].Value = unionCouncilModel.TehsilID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = unionCouncilModel.Title;

               

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = unionCouncilModel.Description == null ? "" : unionCouncilModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = unionCouncilModel.Status ? 1 : 0;

                // added against CR:002
                sqlCmd.Parameters.Add(new SqlParameter("@AccountNo", SqlDbType.VarChar));
                sqlCmd.Parameters["@AccountNo"].Value = unionCouncilModel.AccountNo == null ? "" : unionCouncilModel.AccountNo;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = unionCouncilModel.CreatedBy.Value;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// Delete Union Council information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, string modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteUnionCouncil";

                _sqlCmd.Parameters.Add(new SqlParameter("@UnionCouncilID", SqlDbType.Int));
                _sqlCmd.Parameters["@UnionCouncilID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.VarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Delete By Service
        /// </summary>
        /// <param name="UnionCouncilID"></param>
        /// <param name="serviceID"></param>
        /// <returns></returns>
        public int Delete(int UnionCouncilID, int serviceID)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteServiceUnionCouncil";

                sqlCmd.Parameters.Add(new SqlParameter("@UnionCouncil", SqlDbType.Int));
                sqlCmd.Parameters["@UnionCouncil"].Value = UnionCouncilID;
                sqlCmd.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlCmd.Parameters["@ServiceID"].Value = serviceID;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
                con.Dispose();
            }

            return result;
        }

        /// <summary>
        /// Get all Union Councils
        /// </summary>
        /// <returns></returns>
        public DataTable SelectUnionCouncils()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetUnionCouncil", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all union conucil against specific tehsil 
        /// CR:001
        /// </summary>
        /// <param name="tehsilID"></param>
        /// <returns></returns>
        public DataTable SelectUnionCouncilsByTehsil(int tehsilID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUnionCouncilByTehsil", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TehsilID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@TehsilID"].Value = tehsilID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all Active Union Councils
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUnionCouncils", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get all Active Union Councils
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll(int serviceID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUnionCouncils", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@ServiceID"].Value = serviceID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all Active Union Councils
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll(int serviceID, int? UnionCouncilID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUnionCouncils", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@ServiceID"].Value = serviceID;
                if (UnionCouncilID.HasValue && UnionCouncilID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UnionCouncilID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UnionCouncilID"].Value = UnionCouncilID;
                }
                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceID"></param>
        /// <param name="UnionCouncilID1"></param>
        /// <param name="UnionCouncilID2"></param>
        /// <returns></returns>
        public DataTable GetAll(int serviceID, int? UnionCouncilID1, int? UnionCouncilID2)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetTwoUnionCouncils", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@ServiceID"].Value = serviceID;
                
                if (UnionCouncilID1.HasValue && UnionCouncilID1.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UnionCouncilID1", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UnionCouncilID1"].Value = UnionCouncilID1;
                }
                if (UnionCouncilID2.HasValue && UnionCouncilID2.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UnionCouncilID2", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UnionCouncilID2"].Value = UnionCouncilID2;
                }

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceID"></param>
        /// <returns></returns>
        public DataTable SelectByServiceID(int serviceID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            SqlCommand sqlCmd = new SqlCommand();
            try
            {
                con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUnionCouncilByServiceID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                //sqlDadp.SelectCommand.Parameters.Add("@Code", serviceCode);
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@ServiceID"].Value = serviceID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// SaveServiceUnionCouncil
        /// </summary>
        /// <param name="unionCouncilID"></param>
        /// <param name="dtServiceUnionCouncil"></param>
        /// <param name="createdBy"></param>
        /// <returns></returns>
        public int SaveServiceUnionCouncil(int unionCouncilID, DataTable dtServiceUnionCouncil, string createdBy)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdateServiceUnionCouncil";


                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CreatedBy"].Value = createdBy;

                sqlCmd.Parameters.Add(new SqlParameter("@ServiceAssociationType", SqlDbType.Structured));
                sqlCmd.Parameters["@ServiceAssociationType"].Value = dtServiceUnionCouncil;


                result = sqlCmd.ExecuteNonQuery();
                result = 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
                con.Dispose();
            }


            return result;
        }

    }
}
