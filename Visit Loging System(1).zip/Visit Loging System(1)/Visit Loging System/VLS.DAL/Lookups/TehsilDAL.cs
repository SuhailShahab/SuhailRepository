﻿using BE.Lookups;
using DAL.Enums;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <02-06-2015 04:27:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace DAL.Lookups
{
    public class TehsilDAL : DALBase
    {
        public int Add(TehsilModel Tehsil)
        {
            object result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = StringEnum.GetValue(SPTehsilCodes.spAddTehsil);

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(Tehsil, sqlCmd);

                        result = sqlCmd.ExecuteScalar();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt32(result);
        }

        public int Edit(TehsilModel Tehsil)
        {
            object result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = StringEnum.GetValue(SPTehsilCodes.spEditTehsil);

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(Tehsil, sqlCmd);

                        result = sqlCmd.ExecuteScalar();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt16(result);
        }

        public int Delete(int? id, int? modifiedBy)
        {
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = StringEnum.GetValue(SPTehsilCodes.spDeleteTehsil);

                        sqlCmd.Parameters.Add(new SqlParameter("@TehsilID", SqlDbType.Int));
                        sqlCmd.Parameters["@TehsilID"].Value = id;

                        sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                        sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }

            return result;
        }

        public DataTable SelectAll()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter(StringEnum.GetValue(SPTehsilCodes.spGetAllTehsil), con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }

        public DataTable SelectAllActive()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter(StringEnum.GetValue(SPTehsilCodes.spGetTehsil), con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;

                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public DataTable SelectByDistrictID(int deistrictID)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter(StringEnum.GetValue(SPSubSectorCodes.spGetTehsilByDistrictID), con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = deistrictID;

                    sqlDadp.Fill(dt);
                    return dt;

                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public DataTable GetByCSV(string csvOfDistrictIDs)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter(StringEnum.GetValue(SPSubSectorCodes.spGetTehsilByCSV), con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictIDs", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DistrictIDs"].Value = csvOfDistrictIDs;

                    sqlDadp.Fill(dt);
                    return dt;

                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}
