﻿using BE.Lookups;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <07-04-2016 11:46:22AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace DAL.Lookups
{
    public class DoctorDAL : DALBase
    {
        #region "Constructors"

        public DoctorDAL()
        {

        }

        public DoctorDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }

        public DoctorDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        #endregion

        /// <summary>
        /// Get all active doctors
        /// </summary>
        /// <returns></returns>
        public DataTable GetDoctors()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDoctors", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
}
