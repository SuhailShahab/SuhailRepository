﻿using BE.Lookups;
using DAL.Enums;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <22-03-2015 02:01:17PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace DAL.Lookups
{
    public class DistrictDAL : DALBase
    {
        public int Add(DistrictModel district)
        {
            object result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = StringEnum.GetValue(SPDistrictCodes.spAddDistrict);

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(district, sqlCmd);

                        result = sqlCmd.ExecuteScalar();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }

            return Convert.ToInt32(result);
        }

        public int Edit(DistrictModel district)
        {
            object result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = StringEnum.GetValue(SPDistrictCodes.spEditDistrict);

                        sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlCmd.Parameters["@DistrictID"].Value = district.ID;

                        sqlCmd.Parameters.Add(new SqlParameter("@ProvinceID", SqlDbType.Int));
                        sqlCmd.Parameters["@ProvinceID"].Value = district.ProvinceID;

                        sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlCmd.Parameters["@DivisionID"].Value = district.DivisionID;

                        sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.VarChar));
                        sqlCmd.Parameters["@Code"].Value = district.Code;

                        sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.VarChar));
                        sqlCmd.Parameters["@Title"].Value = district.Title;

                        sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.VarChar));
                        sqlCmd.Parameters["@Description"].Value = district.Description == null ? "" : district.Description;

                        sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                        sqlCmd.Parameters["@IsActive"].Value = district.Status.Value ? 1 : 0;

                        sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                        sqlCmd.Parameters["@ModifiedBy"].Value = district.ModifiedBy;

                        result = sqlCmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt16(result);
        }

        public int Delete(int? id, int? modifiedBy)
        {
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = StringEnum.GetValue(SPDistrictCodes.spDeleteDistrict);

                        sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlCmd.Parameters["@DistrictID"].Value = id;

                        sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                        sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                        result = sqlCmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }

            return result;
        }

        public DataTable SelectAll()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter(StringEnum.GetValue(SPDistrictCodes.spGetAllDistrict), con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }

        public DataTable SelectAllActive()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter(StringEnum.GetValue(SPDistrictCodes.spGetDistrict), con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return dt;
        }

        public DataTable SelectDistrictsByDivisionID(int? divisionID)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictsByDivisionID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (divisionID.HasValue && divisionID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                    }

                    sqlDadp.Fill(dt);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return dt;
        }
    }
}
