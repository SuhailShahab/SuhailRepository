﻿using BE.Lookups;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <07-04-2016 11:46:22AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace DAL.Lookups
{
    public class HospitalEquipmentDAL : DALBase
    {
        #region "Constructors"

        public HospitalEquipmentDAL()
        {

        }

        public HospitalEquipmentDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }

        public HospitalEquipmentDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        #endregion

        /// <summary>
        /// Get HospitalEquipment INFO
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(HospitalEquipmentModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddHospitalEquipment";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Edit HospitalEquipment Info
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Edit(HospitalEquipmentModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditHospitalEquipment";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
      
        public int Delete(HospitalEquipmentModel model)
        {
            int _result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteHospitalEquipment";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                _result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public DataTable GetHospitalEquipments()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetHospitalEquipments", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        public DataTable GetAll()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllHospitalEquipments", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }
    }
}
