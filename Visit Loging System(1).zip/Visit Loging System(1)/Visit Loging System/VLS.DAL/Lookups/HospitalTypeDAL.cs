﻿using BE.Lookups;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <07-04-2016 11:46:22AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace DAL.Lookups
{
    public class HospitalTypeDAL : DALBase
    {
        #region "Constructors"

        public HospitalTypeDAL()
        {

        }

        public HospitalTypeDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }

        public HospitalTypeDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        #endregion

        /// <summary>
        /// Get all active hospital types
        /// </summary>
        /// <returns></returns>
        public DataTable GetHospitalTypes()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetHospitalTypes", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        public int Add(HospitalTypeModel HospitaModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddHospitalType";

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = HospitaModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Code"].Value = HospitaModel.Code;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = HospitaModel.Description;



                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                if (HospitaModel.Status.HasValue)
                    sqlCmd.Parameters["@IsActive"].Value = HospitaModel.Status.Value ? 1 : 0;
                else
                    sqlCmd.Parameters["@IsActive"].Value = 0;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CreatedBy"].Value = HospitaModel.CreatedBy;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Update Group information
        /// </summary>
        /// <param name="groupModel">Set object of groupModel type</param>
        /// <returns></returns>
        public int Edit(HospitalTypeModel HospitaModel)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();

                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditHospitalType";

                sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@GroupID"].Value = HospitaModel.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = HospitaModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Code"].Value = HospitaModel.Code;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = HospitaModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));

                if (HospitaModel.Status.HasValue)
                    sqlCmd.Parameters["@IsActive"].Value = HospitaModel.Status.Value ? 1 : 0;
                else
                    sqlCmd.Parameters["@IsActive"].Value = 0;


                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = HospitaModel.CreatedBy;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// Delete Group information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, int modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteHospitalType";

                _sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.Int));
                _sqlCmd.Parameters["@GroupID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetAllHospitalTypes", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
