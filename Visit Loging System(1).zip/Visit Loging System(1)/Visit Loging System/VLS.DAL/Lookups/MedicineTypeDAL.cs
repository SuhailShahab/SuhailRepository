﻿using BE.Lookups;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <07-04-2016 11:46:22AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace DAL.Lookups
{
    public class MedicineTypeDAL : DALBase
    {
        #region "Constructors"

        public MedicineTypeDAL()
        {

        }

        public MedicineTypeDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }

        public MedicineTypeDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        #endregion

        /// <summary>
        /// Get all active medicine types
        /// </summary>
        /// <returns></returns>
        public DataTable GetMedicineTypes()
        {
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(this.spConnectionString);

            try
            {
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetMedicineTypes", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        public int Add(MedicineTypeModel Model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddMedicineType";

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = Model.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = Model.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                if (Model.Status.HasValue)
                    sqlCmd.Parameters["@IsActive"].Value = Model.Status.Value ? 1 : 0;
                else
                    sqlCmd.Parameters["@IsActive"].Value = 0;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CreatedBy"].Value = Model.CreatedBy;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                    con.Dispose();
                }
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Update Group information
        /// </summary>
        /// <param name="groupModel">Set object of groupModel type</param>
        /// <returns></returns>
        public int Edit(MedicineTypeModel Model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();

                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditMedicineType";

                sqlCmd.Parameters.Add(new SqlParameter("@MedicineTypeID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@MedicineTypeID"].Value = Model.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = Model.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = Model.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));

                if (Model.Status.HasValue)
                    sqlCmd.Parameters["@IsActive"].Value = Model.Status.Value ? 1 : 0;
                else
                    sqlCmd.Parameters["@IsActive"].Value = 0;


                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = Model.CreatedBy;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// Delete Group information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, int modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteMedicineType";

                _sqlCmd.Parameters.Add(new SqlParameter("@MedicineTypeID", SqlDbType.Int));
                _sqlCmd.Parameters["@MedicineTypeID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetAllMedicinceTypes", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
