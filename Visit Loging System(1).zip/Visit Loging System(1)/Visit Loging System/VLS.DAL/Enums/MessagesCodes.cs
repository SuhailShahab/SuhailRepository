﻿using System;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <01-06-2015 03:39:33PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace DAL.Enums
{
    internal enum MessagesCodes : byte
    {
        none = 0,
        [StringValue("Code already exist.")]
        DuplicateCode = 1,
        [StringValue("Title already exist.")]
        DuplicateTite = 2,
        [StringValue("Project Name already exist.")]
        DuplicateProjectName = 2,
    }

    public static class Messages
    {
        public static string DuplicateTitle
        {
            get
            {
                return StringEnum.GetValue(MessagesCodes.DuplicateTite);
            }
        }

        public static string DuplicateCode
        {
            get
            {
                return StringEnum.GetValue(MessagesCodes.DuplicateCode);
            }
        }

        public static string DuplicateProjectName
        {
            get
            {
                return StringEnum.GetValue(MessagesCodes.DuplicateProjectName);
            }
        }
    }
}
