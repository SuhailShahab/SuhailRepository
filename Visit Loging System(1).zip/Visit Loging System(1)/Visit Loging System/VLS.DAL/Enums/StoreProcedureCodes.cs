﻿using System;
using System.Reflection;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <27-05-2015 02:46:29PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR:001       Muhammad Hammad Shahid      02-06-2015 02:00:26PM           Add SPSectorCodes, SPSubSectorCodes, SPDistrictCodes
// =================================================================================================================================
namespace DAL.Enums
{
    #region "Enums"

    /// <summary>
    /// General related store procedures names
    /// </summary>
    public enum SPGeneralCodes : byte
    {
        none = 0,
        [StringValue("spGetRecordVerify")]
        spGetRecordVerify = 1,
        [StringValue("spGetUserPageAccessRights")]
        spGetUserPageAccessRights = 2,
        [StringValue("spGetGrades")]
        spGetGrades = 3,
    }

    /// <summary>
    /// User related store procedures names
    /// </summary>
    public enum SPUsersCodes : byte
    {
        none = 0,
        [StringValue("spAddUsers")]
        spAddUsers = 1,
        [StringValue("spEditUsers")]
        spEditUsers = 2,
        [StringValue("spDeleteUser")]
        spDeleteUser = 3,
        [StringValue("spGetUserByID")]
        spGetUserByID = 4,
        [StringValue("spGetUsers")]
        spGetUsers = 5,
    }

    /// <summary>
    /// Menu related store procedures names
    /// </summary>
    public enum SPMenuCodes : byte
    {
        none = 0,
        [StringValue("spGetMenuFeatures")]
        spGetMenuFeatures = 1,
        [StringValue("spGetMenuObjectsByFeature")]
        spGetMenuObjectsByFeature = 2,
        [StringValue("spGetMenuFeaturesAndObjects")]
        spGetMenuFeaturesAndObjects = 3,
        [StringValue("spGetUserPermittedMenu")]
        spGetUserPermittedMenu = 4,
    }

    /// <summary>
    /// Error log related store procedure names
    /// </summary>
    public enum SPErrorLogCodes : byte
    {
        none = 0,
        [StringValue("spAddApplicationErrorLog")]
        spAddApplicationErrorLog = 1,
    }

    #region "Lookups"

    /// <summary>
    /// Sector related store procedures names
    /// </summary>
    public enum SPSectorCodes : byte
    {
        none = 0,
        [StringValue("spAddSector")]
        spAddSector = 1,
        [StringValue("spEditSector")]
        spEditSector = 2,
        [StringValue("spDeleteSector")]
        spDeleteSector = 3,
        [StringValue("spGetAllSector")]
        spGetAllSector = 4,
        [StringValue("spGetSector")]
        spGetSector = 5,
    }

    /// <summary>
    /// Sub Sector related store procedures names
    /// </summary>
    public enum SPSubSectorCodes : byte
    {
        none = 0,
        [StringValue("spAddSubSector")]
        spAddSubSector = 1,
        [StringValue("spEditSubSector")]
        spEditSubSector = 2,
        [StringValue("spDeleteSubSector")]
        spDeleteSubSector = 3,
        [StringValue("spGetAllSubSector")]
        spGetAllSubSector = 4,
        [StringValue("spGetSubSector")]
        spGetSubSector = 5,
        [StringValue("spGetSubSectorByID")]
        spGetSubSectorByID = 6,
        [StringValue("spGetSubSectorByCSV")]
        spGetSubSectorByCSV = 7,
        [StringValue("spGetTehsilByDistrictID")]
        spGetTehsilByDistrictID = 8,
         [StringValue("spGetTehsilByCSV")]
        spGetTehsilByCSV =9
        
        
    }

    /// <summary>
    /// District related store procedures names
    /// </summary>
    public enum SPDistrictCodes : byte
    {
        none = 0,
        [StringValue("spAddDistrict")]
        spAddDistrict = 1,
        [StringValue("spEditDistrict")]
        spEditDistrict = 2,
        [StringValue("spDeleteDistrict")]
        spDeleteDistrict = 3,
        [StringValue("spGetAllDistrict")]
        spGetAllDistrict = 4,
        [StringValue("spGetDistrict")]
        spGetDistrict = 5,
    }

    /// <summary>
    /// Teshil related store procedures names
    /// </summary>
    public enum SPTehsilCodes : byte
    {
        none = 0,
        [StringValue("spAddTehsil")]
        spAddTehsil = 1,
        [StringValue("spEditTehsil")]
        spEditTehsil = 2,
        [StringValue("spDeleteTehsil")]
        spDeleteTehsil = 3,
        [StringValue("spGetAllTehsil")]
        spGetAllTehsil = 4,
        [StringValue("spGetTehsil")]
        spGetTehsil = 5,
    }

    #endregion
    
   
    
    
    
    

    #endregion

    #region "Classes"

    public class StringValue : System.Attribute
    {
        private string strValue;

        public StringValue(string value)
        {
            strValue = value;
        }

        public string Value
        {
            get { return strValue; }
        }
    }

    public static class StringEnum
    {
        public static string GetValue(Enum value)
        {
            string output = null;
            Type type = value.GetType();

            //Check first in our cached results...

            //Look for our 'StringValueAttribute' 

            //in the field's custom attributes

            FieldInfo fi = type.GetField(value.ToString());
            StringValue[] attrs =
               fi.GetCustomAttributes(typeof(StringValue),
                                       false) as StringValue[];
            if (attrs.Length > 0)
            {
                output = attrs[0].Value;
            }

            return output;
        }
    }

    #endregion
}
