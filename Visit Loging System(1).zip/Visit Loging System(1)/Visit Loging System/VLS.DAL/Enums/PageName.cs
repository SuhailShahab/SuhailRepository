﻿using System;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <01-06-2015 12:41:29PM>
// Description: <Set menu object static name>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace DAL.Enums
{
    public class PageName
    {
        

        #region "Lookups"

        public const string Sector = "Sector";
        public const string SubSector = "SubSector";
        public const string District = "District";
        public const string Tehsil = "Tehsil";
        public const string Constituency = "Constituency";
        public const string Department = "Department";

        #endregion

        #region "Rights Manager"
        public const string GroupPermission = "GroupPermission";
        public const string ApplicationFeatures = "ApplicationFeatures"; 
        public const string ApplicationObjects = "ApplicationObjects";
        public const string Group = "Group";
        public const string User = "User";
        #endregion

        public const string Dashboard = "Dashboard";
        public const string DashboardDistrict = "DashboardDistrict";  
        public const string Index = "Index";
        public const string ActionDetail = "ActionDetail";

        #region "Reports"

        public const string DepartmentVisitingLogs = "Department Visiting Logs";
        public const string AdministrativeSecretariesVisitsLog = "Administrative Secretaries Visits Log";
        public const string OfficialsVisitsObservationByDistrict = "OfficialsVisitsObservationByDistrict";
        public const string OfficialsVisitsLogByDepartment = "OfficialsVisitsLogByDepartment";

        #endregion

    }
}
