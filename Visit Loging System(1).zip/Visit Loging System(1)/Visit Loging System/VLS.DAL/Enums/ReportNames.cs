﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <28-03-2016 03:15:58PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace DAL.Enums
{
    public class ReportNames
    {
        public const string RptDepartmentVisitingLogs = "RptDepartmentVisitingLogs";
        public const string RptDistrictVisitsLogByOfficialsMatrix = "RptDistrictVisitsLogByOfficialsMatrix";
        public const string RptOfficialVisitLogByDistrictMatrix = "RptOfficialVisitLogByDistrictMatrix";
        public const string RptOfficialsVisitsObservationByDistrict = "RptOfficialsVisitsObservationByDistrict";
        public const string RptOfficialsVisitsLogByDepartmentMatrix = "RptOfficialsVisitsLogByDepartmentMatrix";
    }
}
