﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.SessionState
{
    public class SessionStateDAL : SessionDALBase
    {

        public int Add(string sessionID ,string xmlObject,int? loginID, int? timeOute)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddSessionState";

                        sqlCmd.Parameters.Add(new SqlParameter("@SessionID", SqlDbType.NVarChar));
                        sqlCmd.Parameters["@SessionID"].Value = sessionID;

                        sqlCmd.Parameters.Add(new SqlParameter("@xmlObject", SqlDbType.NVarChar));
                        sqlCmd.Parameters["@xmlObject"].Value = xmlObject;

                        sqlCmd.Parameters.Add(new SqlParameter("@SessionTimeOute", SqlDbType.Int));
                        sqlCmd.Parameters["@SessionTimeOute"].Value = timeOute;

                        sqlCmd.Parameters.Add(new SqlParameter("@LoginID", SqlDbType.Int));
                        sqlCmd.Parameters["@LoginID"].Value = loginID;

                       

                        result = sqlCmd.ExecuteScalar();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt32(result);
        }

        public DataTable GetByID(string sessionId)
        {
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSessionStateByID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SessionID", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@SessionID"].Value = sessionId;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();

                }
            }
        }

        public int? Delete(string sessionID)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.ConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteSessionByID";

                if (!string.IsNullOrEmpty(sessionID))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@SessionID", SqlDbType.VarChar));
                    sqlCmd.Parameters["@SessionID"].Value = sessionID;
                }              
                

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
                con.Dispose();
            }

            return result;
        }


    }
}
