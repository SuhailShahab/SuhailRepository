﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.EmailScheduler
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <07-06-2016 11:41AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class EmailSMSTemplateDAL : DALBase
    {
       public DataTable GetEmailSMSTemplateByID(int? templateID)
       {
           DataTable dt = new DataTable();

           using (SqlConnection con = new SqlConnection(this.ConnectionString))
           {
               try
               {
                   SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEmailSMSTemplateByID", con);
                   sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                   if (templateID.HasValue && templateID.Value > 0)
                   {
                       sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TemplateID", SqlDbType.Int));
                       sqlDadp.SelectCommand.Parameters["@TemplateID"].Value = templateID;
                   }

                   sqlDadp.Fill(dt);
                   return dt;
               }
               catch (Exception ex)
               {
                   throw ex;
               }

           }
       }
    }
}
