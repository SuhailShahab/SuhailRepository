﻿using BE.EmailScheduler;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.EmailScheduler
{
   public  class NotVisitLogDAL:DALBase
    {
       /// <summary>
       /// Add the log in not visit table, if secretary donot visit in 14 days
       /// </summary>
       /// <param name="noOfDays"></param>
       /// <returns></returns>
       public int? AddNotVistLog(int? noOfDays)
       {
           object result = 0;

           using (SqlConnection con = new SqlConnection(this.ConnectionString))
           {
               using (SqlCommand sqlCmd = new SqlCommand())
               {

                   try
                   {
                       if (con.State == ConnectionState.Closed)
                           con.Open();

                       sqlCmd.Connection = con;
                       sqlCmd.CommandType = CommandType.StoredProcedure;
                       sqlCmd.CommandText = "spAddNotVisitedLog";
                       if (noOfDays.HasValue && noOfDays.Value >0)
                       {
                           sqlCmd.Parameters.Add(new SqlParameter("@NoOfDays", SqlDbType.Int));
                           sqlCmd.Parameters["@NoOfDays"].Value  = noOfDays.Value;
                       }
                       
                      
                       result = sqlCmd.ExecuteNonQuery ();
                   }
                   catch (Exception ex)
                   {
                       throw ex;
                   }
                   finally
                   {
                       if (con.State == ConnectionState.Open)
                           con.Close();
                   }
               }
           }

           return Convert.ToInt32(result);
       }

       /// <summary>
       /// Check th New not visit log
       /// </summary>
       /// <param name="topRecord"></param>
       /// <returns></returns>
       public DataTable GetAllNewNotVisitLogs(int? topRecord)
       {
           DataTable dt = new DataTable();

           using (SqlConnection con = new SqlConnection(this.ConnectionString))
           {
               try
               {
                   SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllNewNotVisitedLog", con);
                   sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                   if (topRecord.HasValue && topRecord.Value > 0)
                   {
                       sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TopRecord", SqlDbType.VarChar));
                       sqlDadp.SelectCommand.Parameters["@TopRecord"].Value = topRecord;
                   }

                   sqlDadp.Fill(dt);
                   return dt;
               }
               catch (Exception ex)
               {
                   throw ex;
               }
              
           }
       }


       /// <summary>
       /// Check New not visit log is exist
       /// </summary>
       /// <returns></returns>
       public bool? IsExist()
       {
           DataTable dt = new DataTable();

           using (SqlConnection con = new SqlConnection(this.ConnectionString))
           {
               try
               {
                   SqlDataAdapter sqlDadp = new SqlDataAdapter("spIsExitsNewNotVisitLog", con);
                   sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                   sqlDadp.Fill(dt);

                   if (dt != null && Convert.ToInt32(dt.Rows[0][0]) > 0)
                   {
                       return true;
                   }
                   else
                   {
                       return false;
                   }

               }
               catch (Exception ex)
               {
                   throw ex;
               }
               finally
               {
                   if (con.State == ConnectionState.Open)
                       con.Close();
               }

              // return null;
           }



       }

       /// <summary>
       /// Delete All logs those have been send email or which log have have status = 3 (Send Email Successfully)
       /// </summary>
       /// <returns></returns>
       public int? DeleteAll(int? noOfDays)
       {
           int result = 0;
           using (SqlConnection con = new SqlConnection(this.ConnectionString))
           {
               using (SqlCommand sqlCmd = new SqlCommand())
               {
                   try
                   {
                       con.Open();
                       sqlCmd.Connection = con;
                       sqlCmd.CommandType = CommandType.StoredProcedure;
                       sqlCmd.CommandText = "spDeleteSendEmail";

                       if (noOfDays.HasValue && noOfDays.Value >0)
                       {
                           sqlCmd.Parameters.Add(new SqlParameter("@DayDiff", SqlDbType.Int));
                           sqlCmd.Parameters["@DayDiff"].Value = noOfDays;
                       }

                       result = sqlCmd.ExecuteNonQuery();
                       con.Close();
                   }
                   catch (Exception ex)
                   {
                       throw ex;
                   }
                   finally
                   {
                       if (con.State == ConnectionState.Open)
                           con.Close();
                   }
               }
           }

           return result;
       }

       /// <summary>
       /// Updete Status of Log
       /// </summary>
       /// <param name="notVisitLogModel"></param>
       /// <returns></returns>
       public int? UpdateStatus(NotVisitLogModel notVisitLogModel)
       {
           object result = 0;

           using (SqlConnection con = new SqlConnection(this.ConnectionString))
           {
               using (SqlCommand sqlCmd = new SqlCommand())
               {

                   try
                   {
                       if (con.State == ConnectionState.Closed)
                           con.Open();

                       sqlCmd.Connection = con;
                       sqlCmd.CommandType = CommandType.StoredProcedure;
                       sqlCmd.CommandText = "spUpdateStatusNotVisitLog";

                       //sqlCmd.Parameters.Add(new SqlParameter("@EmailID", SqlDbType.Int));
                       //sqlCmd.Parameters["@EmailID"].Value = emailID;

                       //sqlCmd.Parameters.Add(new SqlParameter("@Status", SqlDbType.Int));
                       //sqlCmd.Parameters["@Status"].Value = status;

                       LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(notVisitLogModel, sqlCmd);

                       result = sqlCmd.ExecuteNonQuery();
                   }
                   catch (Exception ex)
                   {
                       throw ex;
                   }
                   finally
                   {
                       if (con.State == ConnectionState.Open)
                           con.Close();

                   }
               }
           }

           return Convert.ToInt16(result);
       }

    }
}
