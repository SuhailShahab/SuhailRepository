﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Generic
{
    public  class SessionDALBase
    {
         private string m_spConnectionString = "DBConnectionString";
        
        /// Defualt constructor
        /// </summary>
         public SessionDALBase()
        {
            this.m_spConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionStringSessionState"].ConnectionString.ToString();            
        }
      

        

        protected string ConnectionString
        {
            get { return m_spConnectionString; }
        }
       
       
      
    }
}
