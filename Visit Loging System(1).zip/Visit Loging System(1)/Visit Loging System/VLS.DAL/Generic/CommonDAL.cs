﻿

using DAL.Generic;
using BE;

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using BE.Common;
using BE.LogManager;

using DAL.Enums;



// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <07-09-2014 11:20AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription

// =================================================================================================================================
namespace DAL.Generic
{
    public class CommonDAL : DALBase
    {
        #region Constructor
        public CommonDAL()
        {

        }
        public CommonDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public CommonDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
            this.dbTransaction = transaction;
        }
       

        
        #endregion
        /// <summary>
        /// Add error detail in ErrorLog table.
        /// </summary>
        /// <param name="_method"></param>
        /// <param name="_message"></param>
        /// <param name="_stackTrace"></param>
        /// <param name="_source"></param>
        /// <param name="_webMethod"></param>
        /// <param name="_created"></param>
        /// <returns>Number of rows effected as interger</returns>
        public int SaveErrorLog(string _method, string _message, string _stackTrace, string _source, int _webMethod, DateTime _created)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddErrorLog";

                sqlCmd.Parameters.Add(new SqlParameter("@Method", SqlDbType.VarChar));
                sqlCmd.Parameters["@Method"].Value = _method;

                sqlCmd.Parameters.Add(new SqlParameter("@Message", SqlDbType.VarChar));
                sqlCmd.Parameters["@Message"].Value = _message;

                sqlCmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar));
                sqlCmd.Parameters["@StackTrace"].Value = _stackTrace;

                sqlCmd.Parameters.Add(new SqlParameter("@Source", SqlDbType.VarChar));
                sqlCmd.Parameters["@Source"].Value = _source;

                sqlCmd.Parameters.Add(new SqlParameter("@IsWebMethod", SqlDbType.Bit));
                sqlCmd.Parameters["@IsWebMethod"].Value = 0;

                sqlCmd.Parameters.Add(new SqlParameter("@Created", SqlDbType.DateTime));
                sqlCmd.Parameters["@Created"].Value = _created;

                result = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open) con.Close();
            }

            return result;
        }
        

        /// <summary>
        /// CR : 008
        /// </summary>
        /// <param name="ErrorLog"></param>
        /// <returns></returns>
        public int SaveErrorLog(ErrorLogModel ErrorLog)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddErrorLog";

                if (!string.IsNullOrEmpty(ErrorLog.Method))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Method", SqlDbType.VarChar));
                    sqlCmd.Parameters["@Method"].Value = ErrorLog.Method;
                }

                if (!string.IsNullOrEmpty(ErrorLog.Message))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Message", SqlDbType.VarChar));
                    sqlCmd.Parameters["@Message"].Value = ErrorLog.Message;
                }

                if (!string.IsNullOrEmpty(ErrorLog.StackTrace))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar));
                    sqlCmd.Parameters["@StackTrace"].Value = ErrorLog.StackTrace;
                }

                if (!string.IsNullOrEmpty(ErrorLog.Source))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Source", SqlDbType.VarChar));
                    sqlCmd.Parameters["@Source"].Value = ErrorLog.Source;
                }

                if (ErrorLog.IsWebMethod.HasValue)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@IsWebMethod", SqlDbType.Bit));
                    sqlCmd.Parameters["@IsWebMethod"].Value = ErrorLog.IsWebMethod;
                }


                if (!string.IsNullOrEmpty(ErrorLog.ErrorCode))
                {

                    sqlCmd.Parameters.Add(new SqlParameter("@ErrorCode", SqlDbType.VarChar));
                    sqlCmd.Parameters["@ErrorCode"].Value = ErrorLog.ErrorCode;
                }

                if (ErrorLog.DistrictID.HasValue && ErrorLog.DistrictID.Value>0)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlCmd.Parameters["@DistrictID"].Value = ErrorLog.DistrictID;
                }

                if (ErrorLog.CreatedBy.HasValue)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                    sqlCmd.Parameters["@CreatedBy"].Value = ErrorLog.CreatedBy;
                }
               
             
                sqlCmd.Parameters.Add(new SqlParameter("@PageName", SqlDbType.VarChar));
                sqlCmd.Parameters["@PageName"].Value = ErrorLog.PageName;

                result = sqlCmd.ExecuteScalar();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open) con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Check any record duplication and data dependances
        /// </summary>
        /// <param name="_table"></param>
        /// <param name="_column"></param>
        /// <param name="_value"></param>
        /// <param name="_caluse"></param>
        /// <returns>True when related record exist else false</returns>
        public bool SelectRecordVerification(string _table, string _column, string _value, string _caluse)
        {
            bool result = false;

            try
            {
                DataTable dt = new DataTable();
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spCheckRecords", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Table"].Value = _table;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@column", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@column"].Value = _column;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@value", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@value"].Value = _value;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@caluse", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@caluse"].Value = _caluse;

                _sqlDadp.Fill(dt);

                if (dt.Rows.Count > 0)
                    result = true;

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// CR: 007
        /// check user access right on a selected page.
        /// </summary>
        /// <param name="_user"></param>
        /// <param name="_page"></param>
        /// <returns></returns>
        public bool GetUserPageAccess(int? loginID, string _page, int _level)
        {
            bool result = true;

            try
            {
                DataTable dt = new DataTable();

                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetUserPageAccess", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LoginID", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@LoginID"].Value = loginID;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Page", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Page"].Value = _page;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Level", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@Level"].Value = _level;

                _sqlDadp.Fill(dt);

                if (dt.Rows.Count == 0)
                    result = false;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }


        
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tblName"></param>
        /// <param name="locationID"></param>
        /// <returns></returns>
        public int GetAutoQmaticNo(string tblName, int locationID)
        {


            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAutoQmaticNo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LocationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@LocationID"].Value = locationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@tblName", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@tblName"].Value = tblName;

                    sqlDadp.Fill(dt);

                    if (dt.Rows.Count > 0)
                        return Convert.ToInt32(dt.Rows[0][0]);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return 0;
        }
        public DataSet  GetCommonUserLookups(LookupModel lookupModel)
        {


            try
            {
                DataSet ds = new DataSet();
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCommonUserLookups", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    

                    if (lookupModel.DistrictID.HasValue && lookupModel.DistrictID.Value>0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = lookupModel.DistrictID;
                    }

                    if (lookupModel.TehsilID.HasValue && lookupModel.TehsilID.Value >0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TehsilID ", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@TehsilID "].Value = lookupModel.TehsilID;
                    }



                    sqlDadp.Fill(ds);
                    return ds;
                  
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }



        /// <summary>
        /// Get Common Lookup List for Dashboard
        /// </summary>
        /// <param name="lookupModel"> lookup model</param>
        /// <param name="userID">Selected User ID</param>
        /// <returns>DataSet</returns>
        public DataSet GetDashBoardCommonUserLookups(LookupModel lookupModel, int? userID)
        {


            try
            {
                DataSet ds = new DataSet();
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashboardCommonUserLookups", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (lookupModel.SectorID.HasValue && lookupModel.SectorID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SectorID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SectorID"].Value = lookupModel.SectorID;
                    }

                    if (lookupModel.SubSectorID.HasValue && lookupModel.SubSectorID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SubSectorID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SubSectorID"].Value = lookupModel.SubSectorID;
                    }


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(ds);
                    //ds.Tables[0].TableName = TableName.tblUserSector.ToString();
                    //ds.Tables[1].TableName = TableName.tblUserSubSector.ToString();
                
                    return ds;

                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// CR: 005
        /// get Service Name from Database on the basis of Code
        /// </summary>
        /// <returns>Datatable of Service table </returns>
        public DataTable GetServiceInfoByCode(string Code)
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetServiceInfoByCode", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Code"].Value = Code != null ? Code : "";

                _sqlDadp.Fill(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        /// <summary>
        /// Update the Satus in Services Table
        /// </summary>
        /// <param name="TableName">Table Name</param>
        /// <param name="TaskStatusID">Task satus id need to be update</param>
        /// <param name="ApplicantID">Applicant Id</param>
        /// <returns></returns>
        public int UpdateServiceTableStatus(string TableName, int TaskStatusID, string ApplicantID)
        {
            object _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spUpdateServiceTableStatus";

                _sqlCmd.Parameters.Add(new SqlParameter("@TaskStatusID", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@TaskStatusID"].Value = TaskStatusID;

                _sqlCmd.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Table"].Value = TableName;

                _sqlCmd.Parameters.Add(new SqlParameter("@ApplicantID", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@ApplicantID"].Value = ApplicantID;



                _result = _sqlCmd.ExecuteScalar();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(_result);
        }
        public int UpdateServiceTableStatus(string TableName, int TaskStatusID, string ApplicantID, string remarks, string modifiedBy)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdateServiceTableStatus";

                sqlCmd.Parameters.Add(new SqlParameter("@TaskStatusID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TaskStatusID"].Value = TaskStatusID;

                sqlCmd.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Table"].Value = TableName;

                sqlCmd.Parameters.Add(new SqlParameter("@ApplicantID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ApplicantID"].Value = ApplicantID;

                sqlCmd.Parameters.Add(new SqlParameter("@Remarks", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Remarks"].Value = remarks;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;


                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="table"></param>
        /// <param name="caluse"></param>
        /// <returns></returns>
        public bool GetDuplicationWithCaluseOnly(string table, string caluse)
        {
            bool result = false;

            try
            {
                DataTable dt = new DataTable();
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("GetDuplicationWithcaluseOnly", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@Table"].Value = table;


                if (!string.IsNullOrEmpty(caluse))
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@caluse", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@caluse"].Value = caluse;
                }

                sqlDadp.Fill(dt);

                /* if (dt.Rows.Count > 0)
                     result = true;*/
                if (dt != null && dt.Rows.Count > 0 && Convert.ToInt32(dt.Rows[0][0]) > 0)
                {
                    result = true;
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

      
        /// use to check duplication value
        /// </summary>
        /// <param name="_table">Table name where to search</param>
        /// <param name="_column">Column name</param>
        /// <param name="_value"></param>
        /// <returns></returns>
        public bool GetDuplication(string table, string column, string value, string caluse)
        {
            bool result = false;

            try
            {
                DataTable dt = new DataTable();
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spCheckDuplication", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@Table"].Value = table;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@column", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@column"].Value = column;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@value", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@value"].Value = value.Trim();
                if (!string.IsNullOrEmpty(caluse))
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@caluse", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@caluse"].Value = caluse;
                }

                sqlDadp.Fill(dt);

                /* if (dt.Rows.Count > 0)
                     result = true;*/
                if (dt != null && dt.Rows.Count > 0 && Convert.ToInt32(dt.Rows[0][0]) > 0)
                {
                    result = true;
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Get Latest Case ID from Table
        /// </summary>
        /// <param name="districtCode">District Code</param>
        /// <param name="year">Current Year</param>
        /// <returns>return latest updated Case ID</returns>
        public int? GetCaseID(string districtCode, string year)
        {
            try
            {
                DataTable dt = new DataTable();
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetCaseID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictCode", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@DistrictCode"].Value = districtCode;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Year", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@Year"].Value = year;

                sqlDadp.Fill(dt);

                if (dt.Rows.Count > 0)
                    return Convert.ToInt32(dt.Rows[0][0]);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }


        /// <summary>
        /// Save   Document URL in Releated Table 
        /// </summary>
        /// <param name="tableName">Selected Table Name</param>
        /// <param name="caseID">Selected Case ID</param>
        /// <param name="documentURL">Documents URLS</param>
        /// <returns></returns>
        public int SaveDocumentsURL(string tableName, string id, string documentURL, string documentTitles)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spSaveDocumentURL";

                sqlCmd.Parameters.Add(new SqlParameter("@TableName", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TableName"].Value = tableName;

                sqlCmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ID"].Value = id;

                sqlCmd.Parameters.Add(new SqlParameter("@DocumentURL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@DocumentURL"].Value = documentURL;

                sqlCmd.Parameters.Add(new SqlParameter("@DocumentTitle", SqlDbType.NVarChar));
                sqlCmd.Parameters["@DocumentTitle"].Value = documentTitles;
                result = sqlCmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open) con.Close();
            }

            return result;
        }


        /// <summary>
        /// Get Document URLS  by ID
        /// </summary>
        /// <param name="tableName">Selected Table Name</param>
        /// <param name="id">Selected ID</param>
        /// <returns></returns>
        public DataTable GetDocuments(string tableName, string id)
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDocumentsID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@ID"].Value = id;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TableName", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@TableName"].Value = tableName;
                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Update Document URL in Database
        /// </summary>
        /// <param name="documentsURL">Document URLs info</param>
        /// <param name="tblName">Table which need to be update</param>
        /// <param name="id">selected ID</param>
        /// <returns></returns>
        public int? UpdateDocuments(string documentsURL, string documentsTitle, string tblName, string id)
        {
            int? result = null;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();
                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    sqlCmd.Connection = con;
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.CommandText = "spUpdateDocumentsURL";

                    sqlCmd.Parameters.Add(new SqlParameter("@TableName", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@TableName"].Value = tblName;

                    sqlCmd.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@ID"].Value = id;

                    sqlCmd.Parameters.Add(new SqlParameter("@DocumentsURL", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@DocumentsURL"].Value = documentsURL;

                    sqlCmd.Parameters.Add(new SqlParameter("@DocumentsTitle", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@DocumentsTitle"].Value = documentsTitle;

                    result = sqlCmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }



        //private List<SqlParameter> GetAddParameter(object obj)
        //{
        //    PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
        //    var sqlParams = new List<SqlParameter>();
        //    foreach (var f in fields)
        //    {
        //        var cols = f.GetCustomAttributes(typeof(PITB.PFSA. Common.MappingInfoAttribute), false);
        //        if (cols.Length > 0 && f.GetCustomAttributes(typeof(PITB.PFSA. Common.MappingInfoAttribute.), false).Length == 0)
        //        {
        //            var p = cols[0];
        //            sqlParams.Add(new SqlParameter(((DbColumnAttribute)p).Name, f.GetValue(obj, null)));
        //        }
        //    }
        //    return sqlParams;
        //}


        public bool GetUserPageAccessRights(string userName, string page)
        {
            bool result = true;

            try
            {
                DataTable dt = new DataTable();

                SqlConnection _con = new SqlConnection(this.ConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter(StringEnum.GetValue(SPGeneralCodes.spGetUserPageAccessRights), _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LoginName", SqlDbType.VarChar));
                _sqlDadp.SelectCommand.Parameters["@LoginName"].Value = userName;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Page", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Page"].Value = page;

                _sqlDadp.Fill(dt);

                if (dt.Rows.Count == 0)
                    result = false;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public bool GetRecordVerify(string table, string column, string value, string caluse)
        {
            bool result = false;

            try
            {
                DataTable dt = new DataTable();
                SqlConnection con = new SqlConnection(this.ConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter(StringEnum.GetValue(SPGeneralCodes.spGetRecordVerify), con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@Table"].Value = table;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@column", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@column"].Value = column;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@value", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@value"].Value = value.Trim();

                if (!string.IsNullOrEmpty(caluse))
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@caluse", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@caluse"].Value = caluse;
                }

                sqlDadp.Fill(dt);

                /* if (dt.Rows.Count > 0)
                     result = true;*/
                if (dt != null && dt.Rows.Count > 0 && Convert.ToInt32(dt.Rows[0][0]) > 0)
                {
                    result = true;
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
