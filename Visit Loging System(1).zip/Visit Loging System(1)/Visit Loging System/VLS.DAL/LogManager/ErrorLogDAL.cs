﻿
using BE.LogManager;
using DAL.Enums;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <01-06-2015 12:41:29PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.DAL.LogManager
{
    public class ErrorLogDAL : DALBase
    {
        public int Add(ErrorLogModel error)
        {
            object result = 0;

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = StringEnum.GetValue(SPErrorLogCodes.spAddApplicationErrorLog);

                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@Method", SqlDbType.VarChar));
                            sqlCmd.Parameters["@Method"].Value = error.Method;
                        }


                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@Message", SqlDbType.VarChar));
                            sqlCmd.Parameters["@Message"].Value = error.Message;
                        }

                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar));
                            sqlCmd.Parameters["@StackTrace"].Value = error.StackTrace;
                        }

                        if (!string.IsNullOrEmpty(error.Method))
                        {
                            sqlCmd.Parameters.Add(new SqlParameter("@Source", SqlDbType.VarChar));
                            sqlCmd.Parameters["@Source"].Value = error.Source;
                        }


                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Get Error Record from loG
        /// </summary>
        /// <param name="logID"></param>
        /// <param name="LocationID"></param>
        /// <param name="ServiceID"></param>
        /// <param name="DivisionID"></param>
        /// <param name="DistrictID"></param>
        /// <param name="PageName"></param>
        /// <param name="dateFrom"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public DataTable GetErrorRecords(ErrorLogModel ErrorLogModel)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                con = new SqlConnection(this.spConnectionString);

                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetErrorLogRecords", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                if (ErrorLogModel.logID > 0 && ErrorLogModel.logID != null)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@logID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@logID"].Value = ErrorLogModel.logID;
                }

                if (ErrorLogModel.DistrictID != null && ErrorLogModel.DistrictID > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = ErrorLogModel.DistrictID;
                }


                if (ErrorLogModel.PageStaticName != null)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageName", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@PageName"].Value = ErrorLogModel.PageStaticName;
                }

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dateFrom", SqlDbType.DateTime));
                if (ErrorLogModel.FromDate != null)
                    sqlDadp.SelectCommand.Parameters["@dateFrom"].Value = ErrorLogModel.FromDate;
                else
                    sqlDadp.SelectCommand.Parameters["@dateFrom"].Value = DateTime.Now;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dateTo", SqlDbType.DateTime));

                if (ErrorLogModel.ToDate != null)
                    sqlDadp.SelectCommand.Parameters["@dateTo"].Value = ErrorLogModel.ToDate;
                else
                    sqlDadp.SelectCommand.Parameters["@dateTo"].Value = DateTime.Now;

                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
        }

        public DataTable GetErrorRecords()
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            try
            {
                con = new SqlConnection(this.spConnectionString);

                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetErrorLogRecords", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dateFrom", SqlDbType.DateTime));

                sqlDadp.SelectCommand.Parameters["@dateFrom"].Value = DateTime.Now;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dateTo", SqlDbType.DateTime));

                sqlDadp.SelectCommand.Parameters["@dateTo"].Value = DateTime.Now;

                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
        }

        public DataTable GetErrorLogsBySearchCretira(int? searchByID, string searchByMessage)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    using (SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDataByIDandTextFromErrorLog", con))
                    {
                        sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                        if (searchByID.HasValue && searchByID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchType", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@SearchType"].Value = searchByID;
                        }

                        if (!string.IsNullOrEmpty(searchByMessage))
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.NVarChar));
                            sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchByMessage;
                        }
                        sqlDadp.Fill(dt);
                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
