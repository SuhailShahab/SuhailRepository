﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.RamzanBazar
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <08-06-2016 01:39AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class TentageDAL : DALBase
    {
        public DataTable GetTentages(int? tentageID)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetTentages", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (tentageID.HasValue && tentageID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TentageID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@TentageID"].Value = tentageID;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
        }
    }
}
