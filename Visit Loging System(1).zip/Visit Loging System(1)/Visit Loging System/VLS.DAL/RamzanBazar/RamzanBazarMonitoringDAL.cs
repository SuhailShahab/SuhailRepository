﻿using BE.CustomEnums;
using BE.RamzanBazars;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.RamzanBazar
{
    public class RamzanBazarMonitoringDAL : DALBase
    {

        public int? AddRamzanBazarMonitoring(RamzanBazarMonitoringModel model, DataTable dtAllItems, int? visitorID)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddRamzanBazarMonitoring";
                        sqlCmd.Transaction = transaction;
                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);
                        sqlCmd.Parameters.Add("@visitorID", SqlDbType.Int);
                        sqlCmd.Parameters["@visitorID"].Value = visitorID;


                        try
                        {
                            result = sqlCmd.ExecuteScalar();

                            // ============================================================================================================== //
                            // ============================================ Add Residence Histroy =========================================== //
                            sqlCmd = new SqlCommand();
                            sqlCmd.Connection = con;
                            sqlCmd.Transaction = transaction;
                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.CommandText = "spAddRamzanBazarMonitoringItem";

                            if (result != null)
                            {
                                int id = Convert.ToInt32(result);
                                if (id > 0)
                                {
                                    sqlCmd.Parameters.Add("@MonitoringID", SqlDbType.Int);
                                    sqlCmd.Parameters["@MonitoringID"].Value = id;

                                    sqlCmd.Parameters.Add("@CreatedBy", SqlDbType.Int);
                                    sqlCmd.Parameters["@CreatedBy"].Value = model.CreatedBy;

                                    sqlCmd.Parameters.Add("@RamzanItems", SqlDbType.Structured);
                                    sqlCmd.Parameters["@RamzanItems"].Value = dtAllItems;

                                }
                            }


                            object noOfRows = sqlCmd.ExecuteNonQuery();



                            transaction.Commit();

                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }
        public int? EditRamzanBazarMonitoring(RamzanBazarMonitoringModel model, DataTable dtAllItems, int? visitorID)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = new SqlCommand();

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spEditRamzanBazarMonitoring";
                        sqlCmd.Transaction = transaction;
                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);
                       

                        try
                        {
                            result = sqlCmd.ExecuteScalar();

                            // ============================================================================================================== //
                            // ============================================ Add Residence Histroy =========================================== //
                            sqlCmd = new SqlCommand();
                            sqlCmd.Connection = con;
                            sqlCmd.Transaction = transaction;
                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.CommandText = "spEditRamzanBazarMonitoringItem";

                            if (result != null)
                            {
                                int id = Convert.ToInt32(result);
                                if (id > 0)
                                {
                                    
                                    sqlCmd.Parameters.Add("@MonitoringID", SqlDbType.Int);
                                    sqlCmd.Parameters["@MonitoringID"].Value = id;

                                    sqlCmd.Parameters.Add("@ModifiedBy", SqlDbType.Int);
                                    sqlCmd.Parameters["@ModifiedBy"].Value = model.ModifiedBy;

                                    sqlCmd.Parameters.Add("@RamzanItems", SqlDbType.Structured);
                                    sqlCmd.Parameters["@RamzanItems"].Value = dtAllItems;

                                }
                            }


                            object noOfRows = sqlCmd.ExecuteNonQuery();



                            transaction.Commit();

                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }
        public DataSet GetRamzanBazarMonitoringByID(int visitorLogID)
        {
            DataSet ds = new DataSet();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetRamzanBazarMonitoringByID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@VisitorLogID"].Value = visitorLogID;


                    sqlDadp.Fill(ds);
                    ds.Tables[0].TableName = TableName.tblRamzanMonitoring.ToString();
                    ds.Tables[1].TableName = TableName.tblRamzanMonitoringLineItem.ToString();
                    return ds;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
        }

        public DataTable GetRamzanBazarMonitoring()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetRamzanMonitoringItems", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);

                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
        }



    }
}
