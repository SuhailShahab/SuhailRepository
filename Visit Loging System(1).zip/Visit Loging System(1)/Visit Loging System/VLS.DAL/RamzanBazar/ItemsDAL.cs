﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.RamzanBazar
{
   public  class ItemsDAL: DALBase
    {
       public DataTable GetRamzanItems(int? itemID)
       {
           DataTable dt = new DataTable();

           using (SqlConnection con = new SqlConnection(this.ConnectionString))
           {
               try
               {
                   SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetItems", con);
                   sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                   if (itemID.HasValue && itemID.Value > 0)
                   {
                       sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ItemID", SqlDbType.Int));
                       sqlDadp.SelectCommand.Parameters["@ItemID"].Value = itemID;
                   }

                   sqlDadp.Fill(dt);
                   return dt;
               }
               catch (Exception ex)
               {
                   throw ex;
               }

           }
       }
    }
}
