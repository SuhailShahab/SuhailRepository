﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.RamzanBazar
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <08-06-2016 01:39AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class ConditionDAL : DALBase
    {
        public DataTable GetConditions(int? coditionID)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetItemConditions", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (coditionID.HasValue && coditionID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ItemConditionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@ItemConditionID"].Value = coditionID;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
        }
    }
}
