﻿using BE.Content;
using BE.CustomEnums;
using BE.Visit;
using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <22-03-2016 08:30PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR:001       Muhammad Hammad Shahid      21-04-2016 04:00:00PM       Add Save() method for enter vist log from web api.
// =================================================================================================================================
namespace DAL.Lookups
{
    public class VisitorLogDAL : DALBase
    {
        public int Add(VisitorLogModel model, DataTable dtDoctor, DataTable dtDoctorPosts, DataTable dtHospitalEquipment, DataTable dtMedicineTypes)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddVisitorLog";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                //sqlCmd.Parameters.Add(new SqlParameter("@dtImages", SqlDbType.Structured));
                //sqlCmd.Parameters["@dtImages"].Value = dtImages;

                sqlCmd.Parameters.Add(new SqlParameter("@dtDoctor", SqlDbType.Structured));
                sqlCmd.Parameters["@dtDoctor"].Value = dtDoctor;

                sqlCmd.Parameters.Add(new SqlParameter("@dtDoctorPosts", SqlDbType.Structured));
                sqlCmd.Parameters["@dtDoctorPosts"].Value = dtDoctorPosts;

                sqlCmd.Parameters.Add(new SqlParameter("@dtHospitalEquipment", SqlDbType.Structured));
                sqlCmd.Parameters["@dtHospitalEquipment"].Value = dtHospitalEquipment;

                sqlCmd.Parameters.Add(new SqlParameter("@dtMedicineTypes", SqlDbType.Structured));
                sqlCmd.Parameters["@dtMedicineTypes"].Value = dtMedicineTypes;

                result = sqlCmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }
        public int AddTansaction(VisitorLogInput visitorLogInput)
        {
           
            object result = 0;
            object resultRamzan = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = null;

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {
                       
                        try
                        {
                            sqlCmd = new SqlCommand();
                            sqlCmd.Connection = con;
                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.CommandText = "spAddVisitorLog";
                            sqlCmd.Transaction = transaction;
                            LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(visitorLogInput.VisitorModel, sqlCmd);

                            sqlCmd.Parameters.Add(new SqlParameter("@dtDoctor", SqlDbType.Structured));
                            sqlCmd.Parameters["@dtDoctor"].Value = visitorLogInput.dtDoctor;

                            sqlCmd.Parameters.Add(new SqlParameter("@dtDoctorPosts", SqlDbType.Structured));
                            sqlCmd.Parameters["@dtDoctorPosts"].Value = visitorLogInput.dtDoctorPosts;

                            sqlCmd.Parameters.Add(new SqlParameter("@dtHospitalEquipment", SqlDbType.Structured));
                            sqlCmd.Parameters["@dtHospitalEquipment"].Value = visitorLogInput.dtHospitalEquipment;

                            sqlCmd.Parameters.Add(new SqlParameter("@dtMedicineTypes", SqlDbType.Structured));
                            sqlCmd.Parameters["@dtMedicineTypes"].Value = visitorLogInput.dtMedicineTypes;

                            result = sqlCmd.ExecuteScalar();

                            #region "Add for Ramzan Bazzar"

                            if (visitorLogInput.VisitorModel.DepartmentID == DepartmentName.IndustriesCommerceAndInvestment.GetHashCode())
                            {
                                //Add Ramzan Bazar Information 
                                sqlCmd = new SqlCommand();
                                sqlCmd.Connection = con;
                                sqlCmd.CommandType = CommandType.StoredProcedure;
                                sqlCmd.CommandText = "spAddRamzanBazarMonitoring";
                                sqlCmd.Transaction = transaction;
                                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(visitorLogInput.VisitorModel.RamzanBazarModel, sqlCmd);
                                sqlCmd.Parameters.Add("@visitorID", SqlDbType.Int);
                                sqlCmd.Parameters["@visitorID"].Value = result;

                                resultRamzan = sqlCmd.ExecuteScalar();

                                // ============================================================================================================== //
                              
                                sqlCmd = new SqlCommand();
                                sqlCmd.Connection = con;
                                sqlCmd.Transaction = transaction;
                                sqlCmd.CommandType = CommandType.StoredProcedure;
                                sqlCmd.CommandText = "spAddRamzanBazarMonitoringItem";

                                if (resultRamzan != null)
                                {
                                    int id = Convert.ToInt32(resultRamzan);
                                    if (id > 0)
                                    {
                                        sqlCmd.Parameters.Add("@MonitoringID", SqlDbType.Int);
                                        sqlCmd.Parameters["@MonitoringID"].Value = id;

                                        sqlCmd.Parameters.Add("@CreatedBy", SqlDbType.Int);
                                        sqlCmd.Parameters["@CreatedBy"].Value = visitorLogInput.VisitorModel.CreatedBy;

                                        sqlCmd.Parameters.Add("@RamzanItems", SqlDbType.Structured);
                                        sqlCmd.Parameters["@RamzanItems"].Value = visitorLogInput.dtRamzanAllItems;

                                    }
                                }


                                object noOfRows = sqlCmd.ExecuteNonQuery();

                            }
                            #endregion 


                            transaction.Commit();

                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }
        public int EditTansaction(VisitorLogInput visitorLogInput)
        {

            object result = 0;
            object resultRamzan = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                SqlCommand sqlCmd = null;

                try
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    using (SqlTransaction transaction = con.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
                    {

                        try
                        {
                            sqlCmd = new SqlCommand();
                            sqlCmd.Connection = con;
                            sqlCmd.CommandType = CommandType.StoredProcedure;
                            sqlCmd.CommandText = "spEditVisitorLog";
                            sqlCmd.Transaction = transaction;
                            LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(visitorLogInput.VisitorModel, sqlCmd);

                            sqlCmd.Parameters.Add(new SqlParameter("@dtDoctor", SqlDbType.Structured));
                            sqlCmd.Parameters["@dtDoctor"].Value = visitorLogInput.dtDoctor;

                            sqlCmd.Parameters.Add(new SqlParameter("@dtDoctorPosts", SqlDbType.Structured));
                            sqlCmd.Parameters["@dtDoctorPosts"].Value = visitorLogInput.dtDoctorPosts;

                            sqlCmd.Parameters.Add(new SqlParameter("@dtHospitalEquipment", SqlDbType.Structured));
                            sqlCmd.Parameters["@dtHospitalEquipment"].Value = visitorLogInput.dtHospitalEquipment;

                            sqlCmd.Parameters.Add(new SqlParameter("@dtMedicineTypes", SqlDbType.Structured));
                            sqlCmd.Parameters["@dtMedicineTypes"].Value = visitorLogInput.dtMedicineTypes;

                            result = sqlCmd.ExecuteNonQuery();

                            result = visitorLogInput.VisitorModel.VisitorLogID;

                            #region "Add for Ramzan Bazzar"

                            if (visitorLogInput.VisitorModel.DepartmentID == DepartmentName.IndustriesCommerceAndInvestment.GetHashCode())
                            {
                                //Add Ramzan Bazar Information 
                                sqlCmd = new SqlCommand();
                                sqlCmd.Connection = con;
                                sqlCmd.CommandType = CommandType.StoredProcedure;
                                sqlCmd.CommandText = "spEditRamzanBazarMonitoring";
                                sqlCmd.Transaction = transaction;
                                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(visitorLogInput.VisitorModel.RamzanBazarModel, sqlCmd);
                                sqlCmd.Parameters.Add("@visitorID", SqlDbType.Int);
                                sqlCmd.Parameters["@visitorID"].Value = result;

                                resultRamzan = sqlCmd.ExecuteNonQuery();
                                resultRamzan = visitorLogInput.VisitorModel.VisitorLogID;
                                // ============================================================================================================== //

                                sqlCmd = new SqlCommand();
                                sqlCmd.Connection = con;
                                sqlCmd.Transaction = transaction;
                                sqlCmd.CommandType = CommandType.StoredProcedure;
                                sqlCmd.CommandText = "spEditRamzanBazarMonitoringItem";

                                if (resultRamzan != null)
                                {
                                    int id = Convert.ToInt32(resultRamzan);
                                    if (id > 0)
                                    {
                                        sqlCmd.Parameters.Add("@VisitorLogID", SqlDbType.Int);
                                        sqlCmd.Parameters["@VisitorLogID"].Value = id;

                                        sqlCmd.Parameters.Add("@ModifiedBy", SqlDbType.Int);
                                        sqlCmd.Parameters["@ModifiedBy"].Value = visitorLogInput.VisitorModel.ModifiedBy;

                                        sqlCmd.Parameters.Add("@RamzanItems", SqlDbType.Structured);
                                        sqlCmd.Parameters["@RamzanItems"].Value = visitorLogInput.dtRamzanAllItems;

                                    }
                                }


                                object noOfRows = sqlCmd.ExecuteNonQuery();

                            }
                            #endregion


                            transaction.Commit();

                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw ex;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return Convert.ToInt32(result);
        }

        public int AddVisitLogImages(int VisitLogID, DataTable dtImages)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddVisitorLogImages";

                sqlCmd.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                sqlCmd.Parameters["@VisitorLogID"].Value = VisitLogID;

                sqlCmd.Parameters.Add(new SqlParameter("@dtImages", SqlDbType.Structured));
                sqlCmd.Parameters["@dtImages"].Value = dtImages;

                result = sqlCmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Modify  VisitorLog Information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Edit(VisitorLogModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditVisitorLog";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// disable  VisitorLog information
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(VisitorLogModel model)
        {
            int _result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeleteVisitorLog";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                _result = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return _result;
        }
        public int DeleteImage(int imageID)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "DeleteVisitLogImage";

                sqlCmd.Parameters.Add("@ImageID", SqlDbType.Int);
                sqlCmd.Parameters["@ImageID"].Value = imageID;

                result = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// Get All  VisitorLog Records
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllVisitorLog", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet  GetVisitorLogInformation(int? visitorLogID)
        {
            DataSet ds = new DataSet();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitorLogInfo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (visitorLogID.HasValue && visitorLogID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@VisitorLogID"].Value = visitorLogID;
                    }

                    sqlDadp.Fill(ds);
                    ds.Tables[0].TableName = TableName.tblVisitorLog.ToString();
                   // ds.Tables[1].TableName = TableName.tblVisitLogEducation.ToString();
                    ds.Tables[1].TableName = TableName.tblVisitLogDoctorAbsence.ToString();
                    ds.Tables[2].TableName = TableName.tblDoctorPosts.ToString();
                    ds.Tables[3].TableName = TableName.tblVisitHospitalEquipment.ToString();
                    ds.Tables[4].TableName = TableName.tblMedicineType.ToString();
                    ds.Tables[5].TableName = TableName.tblRamzanMonitoring.ToString();
                    ds.Tables[6].TableName = TableName.tblRamzanMonitoringLineItem.ToString();
                   
                    return ds;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
        }
        /// <summary>
        /// Get VisitorLog Records
        /// </summary>
        /// <returns></returns>
        public DataTable GetVisitorLog()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitorLog", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Save visit log information pushed from web api
        /// </summary>
        /// <param name="model"></param>
        /// <param name="dtImages"></param>
        /// <param name="dtDoctor"></param>
        /// <param name="dtDoctorPosts"></param>
        /// <param name="dtHospitalEquipment"></param>
        /// <param name="dtMedicineTypes"></param>
        /// <returns></returns>
        public int Save(Visit model, DataTable dtImages, DataTable dtDoctor, DataTable dtDoctorPosts, DataTable dtHospitalEquipment, DataTable dtMedicineTypes)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddVisitLog";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@dtImages", SqlDbType.Structured));
                sqlCmd.Parameters["@dtImages"].Value = dtImages;

                if (model.Hospital != null)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@HospitalTypeID", SqlDbType.Int));
                    sqlCmd.Parameters["@HospitalTypeID"].Value = model.Hospital.HospitalTypeID.Value;

                    sqlCmd.Parameters.Add(new SqlParameter("@HospitalCleanliness", SqlDbType.Bit));
                    sqlCmd.Parameters["@HospitalCleanliness"].Value = model.Hospital.HospitalCleanliness ? 1 : 0;
                }

                if (model.Education != null)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@TecherAbsentPercentage", SqlDbType.Int));
                    sqlCmd.Parameters["@TecherAbsentPercentage"].Value = model.Education.AbsentTecherPercentage.Value;

                    sqlCmd.Parameters.Add(new SqlParameter("@StudentAbsentPercentage", SqlDbType.Int));
                    sqlCmd.Parameters["@StudentAbsentPercentage"].Value = model.Education.AbsentStudentPercentage.Value;

                    sqlCmd.Parameters.Add(new SqlParameter("@IsWashroomClean", SqlDbType.Bit));
                    sqlCmd.Parameters["@IsWashroomClean"].Value = model.Education.WashroomCleanliness ? 1 : 0;

                    sqlCmd.Parameters.Add(new SqlParameter("@GeneralCleanlines", SqlDbType.Bit));
                    sqlCmd.Parameters["@GeneralCleanlines"].Value = model.Education.GeneralCleanliness ? 1 : 0;

                    sqlCmd.Parameters.Add(new SqlParameter("@DrinkWaterAvailable", SqlDbType.Bit));
                    sqlCmd.Parameters["@DrinkWaterAvailable"].Value = model.Education.DrinkWaterAvailable ? 1 : 0;

                    sqlCmd.Parameters.Add(new SqlParameter("@ElectricityAvailable", SqlDbType.Bit));
                    sqlCmd.Parameters["@ElectricityAvailable"].Value = model.Education.ElectricityAvailable ? 1 : 0;

                    sqlCmd.Parameters.Add(new SqlParameter("@SecuirtyArrangements", SqlDbType.Bit));
                    sqlCmd.Parameters["@SecuirtyArrangements"].Value = model.Education.SecurityArrangementAvailable ? 1 : 0;
                }

                sqlCmd.Parameters.Add(new SqlParameter("@dtDoctor", SqlDbType.Structured));
                sqlCmd.Parameters["@dtDoctor"].Value = dtDoctor;

                sqlCmd.Parameters.Add(new SqlParameter("@dtDoctorPosts", SqlDbType.Structured));
                sqlCmd.Parameters["@dtDoctorPosts"].Value = dtDoctorPosts;

                sqlCmd.Parameters.Add(new SqlParameter("@dtHospitalEquipment", SqlDbType.Structured));
                sqlCmd.Parameters["@dtHospitalEquipment"].Value = dtHospitalEquipment;

                sqlCmd.Parameters.Add(new SqlParameter("@dtMedicineTypes", SqlDbType.Structured));
                sqlCmd.Parameters["@dtMedicineTypes"].Value = dtMedicineTypes;

                result = sqlCmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }
    }
}
