﻿using BE.Content;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <28-03-2016 05:00PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// =================================================================================================================================
namespace VLS.DAL.Content
{
    public class ActionDetailDAL : DALBase
    {
        /// <summary>
        /// Get assign task 
        /// </summary>
        /// <param name="visitorLogID">Selected visitorLog ID</param>
        /// <returns>Action Task DataSet</returns>
        public DataSet GetAssignTaskDetail(int visitorLogID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAssignTaskDetail", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@VisitorLogID"].Value = visitorLogID;

                    sqlDadp.Fill(ds);

                    ds.Tables[0].TableName = "VisitLog";
                    ds.Tables[1].TableName = "VisitLogImages";
                    ds.Tables[2].TableName = "VisitHospitalEquipment";
                    ds.Tables[3].TableName = "VisitLogDoctorAbsence";
                    ds.Tables[4].TableName = "VisitLogMedicine";
                    ds.Tables[5].TableName = "VisitLogVacantDoctor";


                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Add Action Remarks Against Task
        /// </summary>
        /// <param name="ActionDetailModel">selected action model</param>
        /// <param name="dtImages">Images data table</param>
        /// <returns></returns>
        public int Add(ActionDetailModel model, DataTable dtImages)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddActionRemarks";

                sqlCmd.Parameters.Add(new SqlParameter("@TaskID", SqlDbType.Int));
                sqlCmd.Parameters["@TaskID"].Value = model.TaskID;

                sqlCmd.Parameters.Add(new SqlParameter("@ActionRemarks", SqlDbType.Int));
                sqlCmd.Parameters["@ActionRemarks"].Value = model.ActionRemarks;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = model.ModifiedBy;

                sqlCmd.Parameters.Add(new SqlParameter("@dtImages", SqlDbType.Structured));
                sqlCmd.Parameters["@dtImages"].Value = dtImages;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Add Action Remarks Against Task
        /// </summary>
        /// <param name="ActionDetailModel">selected action model</param>
        /// <returns></returns>
        public int Add(ActionDetailModel model, int visitorLogID, int? designationID)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddActionRemarksData";

                sqlCmd.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                sqlCmd.Parameters["@VisitorLogID"].Value = visitorLogID;

                sqlCmd.Parameters.Add(new SqlParameter("@DesignationID", SqlDbType.Int));
                sqlCmd.Parameters["@DesignationID"].Value = designationID.Value;

                sqlCmd.Parameters.Add(new SqlParameter("@ActionRemarks", SqlDbType.VarChar));
                sqlCmd.Parameters["@ActionRemarks"].Value = model.ActionRemarks;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = model.ModifiedBy;

                //sqlCmd.Parameters.Add(new SqlParameter("@dtImages", SqlDbType.Structured));
                //sqlCmd.Parameters["@dtImages"].Value = dtImages;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }

        public int UploadAttachment(int visitorLogID,int? designationID, byte[] document, string contentType)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddActionAttachment";

                sqlCmd.Parameters.Add(new SqlParameter("@DesignationID", SqlDbType.Int));
                sqlCmd.Parameters["@DesignationID"].Value = designationID;

                sqlCmd.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                sqlCmd.Parameters["@VisitorLogID"].Value = visitorLogID;

                sqlCmd.Parameters.Add(new SqlParameter("@Attachment", SqlDbType.VarBinary));
                sqlCmd.Parameters["@Attachment"].Value = document;

                sqlCmd.Parameters.Add(new SqlParameter("@ContentType", SqlDbType.VarChar));
                sqlCmd.Parameters["@ContentType"].Value = contentType;

                result = sqlCmd.ExecuteScalar();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open) con.Close();
            }

            return Convert.ToInt32(result);
        }



        /// <summary>
        /// valid access
        /// </summary>
        /// <param name="visitorLogID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public bool IsValidActionTakenUser(int visitorLogID, int userID)
        {
            DataSet ds = new DataSet();

            bool isAuthorise = false;



            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spIsValidActionTakenUser", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@VisitorLogID"].Value = visitorLogID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(ds);

                    isAuthorise = ds.Tables[0].Rows[0][0].ToString()=="1" ? true :false;
                    
                    return isAuthorise;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="visitorLogID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public bool IsValidUserPrintActionReport(int visitorLogID, int userID)
        {
            DataSet ds = new DataSet();

            bool isAuthorise = false;



            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spIsValidUserPrintActionReport", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@VisitorLogID"].Value = visitorLogID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(ds);

                    isAuthorise = ds.Tables[0].Rows[0][0].ToString() == "1" ? true : false;

                    return isAuthorise;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool IsValidVistorUser(int visitorLogID, int? userID)
        {
            DataSet ds = new DataSet();

            bool isAuthorise = false;



            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spIsValidVistorUser", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@VisitorLogID"].Value = visitorLogID;

                    if (userID.HasValue && userID.Value>0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    }
                   

                    sqlDadp.Fill(ds);

                    isAuthorise = ds.Tables[0].Rows[0][0].ToString() == "1" ? true : false;

                    return isAuthorise;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
