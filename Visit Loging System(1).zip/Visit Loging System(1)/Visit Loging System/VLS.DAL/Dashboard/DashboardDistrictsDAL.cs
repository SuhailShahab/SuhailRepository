﻿using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <28-03-2016 03:15:58PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.DAL.Dashboard
{
    public class DashboardDistrictsDAL : DALBase
    {
        public DataTable GetDepartmentVisitsByDistrict(int? districtID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartmentVisitsByDistrict", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    sqlDadp.Fill(dt);

                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetVisitsStatusByDistrict(int? districtID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitsStatusByDistrict", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    sqlDadp.Fill(dt);

                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetVisitsLogsDashboardDistrict(int? districtID, int pageNo, int pageSize)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitsLogsDashboardDistrict", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.Fill(dt);

                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
