﻿using DAL.Enums;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

  
// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <18-Mar-2016 02:50:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription

// =================================================================================================================================
namespace DAL.Dashboard
{
    public class DashBoardDAL : DALBase
    {
        /// <summary>
        /// Get assign task 
        /// </summary>
        /// <param name="assignTo">Selected User ID</param>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="searchText">Selected Search Text</param>
        /// <returns></returns>
        public DataSet GetAssignTask(int assignTo, int pageNo, int pageSize, string searchText)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardAssignTask", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AssignTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AssignTo"].Value = assignTo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Visited task 
        /// </summary>
        /// <param name="assignTo">Selected User ID</param>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="searchText">Selected Search Text</param>
        /// <returns></returns>
        public DataSet GetVisitedTask(int assignTo, int pageNo, int pageSize, string searchText)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardVisited", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AssignTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AssignTo"].Value = assignTo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Pending task 
        /// </summary>
        /// <param name="assignTo">Selected User ID</param>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="searchText">Selected Search Text</param>
        /// <returns></returns>
        public DataSet GetPendingTask(int assignTo, int pageNo, int pageSize, string searchText)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardPendingTask", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AssignTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AssignTo"].Value = assignTo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get  Action Taken Count
        /// </summary>
        /// <param name="AssignTo">Selected  user ID</param>
        /// <returns> Data Table</returns>
        public DataTable GetActionTakenCount(int assignTo)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardActionTakenCounts", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AssignTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AssignTo"].Value = assignTo;


                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get  Overdue Assign and Visited Count
        /// </summary>
        /// <param name="AssignTo">Selected  user ID</param>
        /// <returns> Data Table</returns>
        public DataTable GetDashBoardStaticCounts(int assignTo)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardStaticCounts", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AssignTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AssignTo"].Value = assignTo;


                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Assign Task on Designation Base
        /// </summary>
        /// <param name="assignTo">Selected User ID</param>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="designationID">Selected Designation ID</param>
        /// <returns>Data Set</returns>
        public DataSet GetDashBoardAssignTaskForDesignation(int assignTo, int pageNo, int pageSize, int designationID, 
            int rateID, string sortColumn, int? sortDirection, int? divisionID, int? districtID )
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardAssignTaskForDesignation", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AssignTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AssignTo"].Value = assignTo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DesignationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DesignationID"].Value = designationID;

                    if (divisionID .HasValue && divisionID.Value > 0 )
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                    }

                    if (districtID .HasValue && districtID.Value > 0 )
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }



                    if (!string.IsNullOrEmpty(sortColumn))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SortColumn", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@SortColumn"].Value = sortColumn;
                    }

                    if (sortDirection.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SortDirection", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SortDirection"].Value = sortDirection.Value;
                    }


                    if (rateID != 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RatingID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RatingID"].Value = rateID;
                    }
                     
                    sqlDadp.Fill(ds);

                    ds.Tables[0].TableName = "Observations";
                    ds.Tables[1].TableName = "TotalRecords";
                    ds.Tables[2].TableName = "RatingCount";
                    if (rateID != 0) ds.Tables[3].TableName = "RateTotalCount";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }


        /// <summary>
        /// Get Visited Task on Designation Base
        /// </summary>
        /// <param name="assignTo">Selected User ID</param>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="designationID">Selected Designation ID</param>
        /// <returns>Data Set</returns>
        public DataSet GetDashBoardVisitedForDesignation(int assignTo, int pageNo, int pageSize, int designationID, int rateID, string sortColumn, int? sortDirection)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardVisitedForDesignation", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AssignTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AssignTo"].Value = assignTo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DesignationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DesignationID"].Value = designationID;

                    if (!string.IsNullOrEmpty(sortColumn))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SortColumn", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@SortColumn"].Value = sortColumn;
                    }

                    if (sortDirection.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SortDirection", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@SortDirection"].Value = sortDirection.Value;
                    }

                    if (rateID != 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RatingID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RatingID"].Value = rateID;
                    }

                    sqlDadp.Fill(ds);

                    ds.Tables[0].TableName = "Visits";
                    ds.Tables[1].TableName = "TotalRecords";
                    ds.Tables[2].TableName = "RatingCount";
                    if (rateID != 0) ds.Tables[3].TableName = "RateTotalCount";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }

    }
}


