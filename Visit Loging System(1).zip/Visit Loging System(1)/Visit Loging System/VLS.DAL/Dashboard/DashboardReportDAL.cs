﻿using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Sabeeh Goheer>
// Create date: <25-04-2016 03:15:58PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR :001      Syed Zeeshan Aqil           09-May-2016 03:15:58PM          Add Method   "GetVisitsRatingPerformedBreakdown"  
// CR :002      Syed Zeeshan Aqil           09-May-2016 03:15:58PM          Add Method   "GetVisitsRatingPerformedBreakdown"  
// CR :003      Syed Zeeshan Aqil           09-May-2016 03:15:58PM          Add Method   "GetVisitsRatingPerformedBreakdown"  
// CR :004      Syed Zeeshan Aqil           08-May-2016 5:11 PM             Add Method    "GetVisitsLogPictures" to  get visit log the Picture List
// =================================================================================================================================
namespace VLS.DAL.Dashboard
{
    public class DashboardReportDAL : DALBase
    {

        /// <summary>
        /// Get Visit Performed Breakdown
        /// </summary>
        /// <param name="AssignTo">UserID</param>
        /// <returns>DataSet</returns>
        public DataSet GetVisitsPerformedBreakdown(int? AssignTo, int? DivisionID, int? DistrictID, int? DepartmentID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardVisitsPerformed", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = AssignTo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = DivisionID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = DepartmentID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetDistrictsWiseVisitsPerformedBreakdown(int? AssignTo, int? DivisionID, int? DistrictID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictWiseDashBoardVisitsPerformed", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = AssignTo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = DivisionID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetDepartmentsWiseVisitsPerformedBreakdown(int? AssignTo, int? DepartmentID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartmentWiseDashBoardVisitsPerformed", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = AssignTo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = DepartmentID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetVisitsObservedBreakdown(int? DivisionID, int? DistrictID, int? DepartmentID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardVisitsObserved", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = DivisionID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = DepartmentID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetDistrictsWiseVisitsObservedBreakdown(int? DivisionID, int? DistrictID, int? DepartmentID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictWiseDashBoardVisitsObserved", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = DivisionID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = DepartmentID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetDepartmentsWiseVisitsObservedBreakdown(int? UserDepartment, int? DepartmentID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartmentWiseDashBoardVisitsObserved", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserDepartment", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserDepartment"].Value = UserDepartment;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = DepartmentID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetDistrictRatingLogDetail(int? userID, int? divisionID, int? districtID, int? ratingID, int? facilityID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictRatingLogDetail", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@userID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@userID"].Value = userID;
                    }
                    
                    if (divisionID.HasValue && divisionID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID.Value;
                    }

                    if (districtID.HasValue && districtID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID.Value;
                    }

                    if (ratingID.HasValue && ratingID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RatingID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RatingID"].Value = ratingID.Value;
                    }

                    if (facilityID.HasValue && facilityID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID.Value;
                    }

                    sqlDadp.Fill(dt);
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        /// <summary>
        /// Get Dashboard Most Recent Rating Info
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="departmentID"></param>
        /// <param name="ratingID"></param>
        /// <returns></returns>
        public DataTable GetDashBoardMostRecentVisitRatingInfo()
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardMostRecentVisitRatingInfo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }


        public DataTable GetDepartmentRatingLogDetail(int? userID, int? departmentID, int? ratingID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartmentRatingLogDetail", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;



                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@userID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@userID"].Value = userID;


                    if (departmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID.Value;
                    }
                    
                    if (ratingID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RatingID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RatingID"].Value = ratingID.Value;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable GetDepartmentRatingLogDetailNew(int? userDepartmentID, int? departmentID, int? ratingID, int? districtID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartmentRatingLogDetailExt", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;



                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@userDepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@userDepartmentID"].Value = userDepartmentID;


                    if (departmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID.Value;
                    }

                    if (ratingID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RatingID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RatingID"].Value = ratingID.Value;
                    }

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID.Value;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetDistrictRatingObservedLogDetail(int? DepartmentID, int? divisionID, int? districtID, int? ratingID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictRatingObservedLogDetail", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = DepartmentID;


                    if (divisionID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID.Value;
                    }
                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID.Value;
                    }
                    if (ratingID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RatingID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RatingID"].Value = ratingID.Value;
                    }
                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        

        public DataTable GetDepartmentRatingObservedLogDetail(int? userDepartmentID, int? departmentID, int? ratingID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDepartmentRatingObservedLogDetail", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;



                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@userDepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@userDepartmentID"].Value = userDepartmentID;


                    if (departmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID.Value;
                    }

                    if (ratingID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RatingID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RatingID"].Value = ratingID.Value;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
       



        /// <summary> 
        /// // CR :001 
        /// Get Visit Rating Performed Breakdown On District and Department Wise
        /// </summary>
        /// <param name="AssignedTo">Created Visit person ID</param>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="districtID">selected district ID</param>
        /// <param name="departmentID">selected DepartmentID</param>
        /// <returns>DataSet</returns>
        public DataSet GetVisitsRatingPerformedBreakdown(int? assignTo, int? divisionID, int? districtID, int? departmentID, int? facilityID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardVisitRatingInformaiton", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (assignTo.HasValue && assignTo.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = assignTo;
                    }

                    if (divisionID.HasValue && divisionID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                    }

                    if (districtID.HasValue && districtID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    if (departmentID.HasValue && departmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    if (facilityID.HasValue && facilityID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID;
                    }

                    sqlDadp.Fill(ds);


                    ds.Tables[0].TableName = "Rating";
                    ds.Tables[1].TableName = "DistrictVisits";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }

        /// <summary> 
        /// // CR :001 
        /// Get Visit Rating Performed Breakdown On Designation Wise
        /// </summary>
        /// <param name="designationID">selected DesignationID</param>
        /// <returns>DataSet</returns>
        public DataSet GetDesignationVisitsRatingPerformedBreakdown(int? designationID, int? facilityID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardVisitRatingInformaitonByDesignation", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DesignationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DesignationID"].Value = designationID;

                    if (facilityID.HasValue && facilityID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID.Value;
                    }

                    sqlDadp.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }


        public DataSet GetVisitsRatingPerformedBreakdownExt(int? assignTo, int? divisionID, int? districtID, int? departmentID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardVisitRatingInformaitonExt", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (assignTo.HasValue && assignTo.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = assignTo;
                    }
                   
                    if (divisionID.HasValue && divisionID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                    }

                    if (districtID.HasValue && districtID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@districtID"].Value = districtID;
                    }
                    if (departmentID.HasValue && departmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary> 
        /// // CR :002 
        /// Get Visit Rating Observation Breakdown On District and Department Wise
        /// </summary>
        /// <param name="AssignedTo">Created Visit person ID</param>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="districtID">selected district ID</param>
        /// <param name="departmentID">selected DepartmentID</param>
        /// <returns>DataSet</returns>
        public DataSet GetVisitsRatingObservationBreakdown(int? assignTo, int? divisionID, int? districtID, int? departmentID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashBoardVisitRatingObservation", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = assignTo;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        /// <summary>
        /// CR :004 
        /// </summary>
        /// <param name="visitlogID">selected visitor Log ID</param>
        /// <returns></returns>
        public DataTable GetVisitsLogPictures(int visitorLogID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitLogImages", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@VisitorLogID"].Value = visitorLogID;
                    
                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
