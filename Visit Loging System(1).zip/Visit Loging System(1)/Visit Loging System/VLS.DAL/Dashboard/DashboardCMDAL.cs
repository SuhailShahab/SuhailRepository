﻿using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <31-03-2016 03:36:26PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR:001       Muhammad Hammad Shahid      30-05-2016 10:51:05AM           Add GetVisitCountByDesignation method to get visit log against provided designation
// CR:002       Muhammad Hammad Shahid      31-05-2016 12:02:03             Add GetVisitsRatingPerformedBreakdownByUserID method to get user wise visit rating breakdown
// =================================================================================================================================
namespace DAL.Dashboard
{
    public class DashboardCMDAL : DALBase
    {
        public DataTable GetVisitCountByDistrict(int? districtID, DateTime? fromDate, DateTime? toDate, DataTable dtDesignationIDs, int? facilityID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitCountByDistrict", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    if (fromDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate;
                    }

                    if (toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DesignationIDs", SqlDbType.Structured));
                    sqlDadp.SelectCommand.Parameters["@DesignationIDs"].Value = dtDesignationIDs;

                    if (facilityID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID;
                    }

                    sqlDadp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        public DataTable GetFieldVisitsByDistrict(int? districtID, DateTime? fromDate, DateTime? toDate)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitLogsByDateRange", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    if (fromDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate;
                    }

                    if (toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetVisitCountByAdministrativeSecretaries(int? districtID, DateTime? fromDate, DateTime? toDate)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitCountByAdministrativeSecretaries", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    if (fromDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate;
                    }

                    if (toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get visit counts by provided desingations
        /// </summary>
        /// <param name="districtID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <param name="dtDesignationIDs"></param>
        /// <returns></returns>
        public DataTable GetVisitCountByDesignation(int? districtID, DateTime? fromDate, DateTime? toDate, DataTable dtDesignationIDs, int? facilityID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitCountByDesignation", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    if (fromDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate;
                    }

                    if (toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DesignationIDs", SqlDbType.Structured));
                    sqlDadp.SelectCommand.Parameters["@DesignationIDs"].Value = dtDesignationIDs;

                    if (facilityID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID;
                    }

                    sqlDadp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        public DataTable GetSecretariesContactList()
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetSecretariesContacts", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public string GetSectaryCellNumberByID(int DepartmentID)
        {
            string result;

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spGetCellNumberByDepartmentID";

                        sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlCmd.Parameters["@DepartmentID"].Value = DepartmentID;

                        result = sqlCmd.ExecuteScalar().ToString();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Get visit rating breakdown by user id
        /// </summary>
        /// <remarks>CR:002</remarks>
        /// <param name="userID"></param>
        /// <param name="districtID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public DataSet GetVisitsRatingPerformedBreakdownByUserID(int userID, int? districtID, DateTime? fromDate, DateTime? toDate, int? facilityID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashboardVisitRatingByUserID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    if (districtID.HasValue && districtID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@districtID"].Value = districtID;
                    }

                    if (fromDate.HasValue && toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate.Value;

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate.Value;
                    }

                    if (facilityID.HasValue && facilityID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID.Value;
                    }

                    sqlDadp.Fill(ds);

                    ds.Tables[0].TableName = "Rating";
                    ds.Tables[1].TableName = "Visits";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }

        /// <summary>
        /// Get visit rating breakdown detail by user and rating
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="districtID"></param>
        /// <param name="ratingID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public DataTable GetVisitRatingDetailByUserID(int userID, int? districtID, int? ratingID, DateTime? fromDate, DateTime? toDate, int? facilityID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashboardVisitRatingDetailByUserID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;


                    if (districtID.HasValue && districtID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID.Value;
                    }

                    if (ratingID.HasValue && ratingID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RatingID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RatingID"].Value = ratingID.Value;
                    }

                    if (fromDate.HasValue && toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate.Value;

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate.Value;
                    }

                    if (facilityID.HasValue && facilityID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID.Value;
                    }

                    sqlDadp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        /// <summary>
        /// Get visit rating breakdown by district id
        /// </summary>
        /// <param name="districtID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public DataSet GetVisitsRatingPerformedBreakdownByDistrictID(int districtID, DateTime? fromDate, DateTime? toDate, DataTable dtDesignationIDs, int? facilityID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashboardVisitRatingByDistrictID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;

                    if (fromDate.HasValue && toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate.Value;

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate.Value;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DesignationIDs", SqlDbType.Structured));
                    sqlDadp.SelectCommand.Parameters["@DesignationIDs"].Value = dtDesignationIDs;

                    if (facilityID.HasValue && facilityID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID.Value;
                    }

                    sqlDadp.Fill(ds);

                    ds.Tables[0].TableName = "Rating";
                    ds.Tables[1].TableName = "Visits";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }

        /// <summary>
        /// Get visit rationg breakdown detain by district and rating
        /// </summary>
        /// <param name="districtID"></param>
        /// <param name="ratingID"></param>
        /// <param name="fromDate"></param>
        /// <param name="toDate"></param>
        /// <returns></returns>
        public DataTable GetDistrictRatingLogDetail(int districtID, int? ratingID, DateTime? fromDate, DateTime? toDate, DataTable dtDesignationIDs, int? facilityID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.ConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDashboardVisitRatingByDistrict", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;

                    if (ratingID.HasValue && ratingID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@RatingID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@RatingID"].Value = ratingID.Value;
                    }

                    if (fromDate.HasValue && toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate.Value;

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate.Value;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DesignationIDs", SqlDbType.Structured));
                    sqlDadp.SelectCommand.Parameters["@DesignationIDs"].Value = dtDesignationIDs;

                    if (facilityID.HasValue && facilityID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FacilityID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@FacilityID"].Value = facilityID.Value;
                    }

                    sqlDadp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }
    }
}
