﻿
using BE.RigthManager;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.RightsManager
{
    public class ApplicationObjectsDAL : DALBase
    {

        public ApplicationObjectsDAL()
        {

        }
        public ApplicationObjectsDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public ApplicationObjectsDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(ApplicationObjectModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddApplicationObjects";

                sqlCmd.Parameters.Add(new SqlParameter("@AppFeatureID", SqlDbType.Int));
                sqlCmd.Parameters["@AppFeatureID"].Value = model.AppFeatureID;
                if (!string.IsNullOrEmpty(model.Icon))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Icon", SqlDbType.VarChar));
                    sqlCmd.Parameters["@Icon"].Value = model.Icon;
                }                
                sqlCmd.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Name"].Value = model.Name;
                sqlCmd.Parameters.Add(new SqlParameter("@StaticName", SqlDbType.NVarChar));
                sqlCmd.Parameters["@StaticName"].Value = model.StaticName.Trim();
                sqlCmd.Parameters.Add(new SqlParameter("@URL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@URL"].Value = model.URL;
                if (!string.IsNullOrEmpty(model.Description))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@Description"].Value = model.Description;
                }
                sqlCmd.Parameters.Add(new SqlParameter("@HasChild", SqlDbType.Bit));
                sqlCmd.Parameters["@HasChild"].Value = model.HasChild ? true : false;
                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = model.Status  ??false ;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = model.CreatedBy ?? 0;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Edit 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Edit(ApplicationObjectModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditApplicationObjects";

                sqlCmd.Parameters.Add(new SqlParameter("@AppObjectID", SqlDbType.Int));
                sqlCmd.Parameters["@AppObjectID"].Value = model.ID;
                sqlCmd.Parameters.Add(new SqlParameter("@AppFeatureID", SqlDbType.Int));
                sqlCmd.Parameters["@AppFeatureID"].Value = model.AppFeatureID;
                if (!string.IsNullOrEmpty(model.Icon))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Icon", SqlDbType.VarChar));
                    sqlCmd.Parameters["@Icon"].Value = model.Icon;
                } 
                sqlCmd.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Name"].Value = model.Name;
                sqlCmd.Parameters.Add(new SqlParameter("@Sort", SqlDbType.Int));
                sqlCmd.Parameters["@Sort"].Value = model.Sort;

                sqlCmd.Parameters.Add(new SqlParameter("@URL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@URL"].Value = model.URL;
                if (!string.IsNullOrEmpty(model.Description))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@Description"].Value = model.Description;
                }
                sqlCmd.Parameters.Add(new SqlParameter("@HasChild", SqlDbType.Bit));
                sqlCmd.Parameters["@HasChild"].Value = model.HasChild ? true : false;
                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = model.Status  ?? false;
                if (!string.IsNullOrEmpty(model.StaticName))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@StaticName", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@StaticName"].Value = model.StaticName.Trim();
                }

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = model.CreatedBy ?? 0;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        /// <summary>
        /// Get all Features for drop down list
        /// </summary>
        /// <returns></returns>
        public DataTable SelectFeatures()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetApplicationFeatures", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Getting all Features for grid
        /// </summary>
        /// <returns></returns>
        public DataTable GetAppObject()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetApplicationObjects", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }
    }
}
