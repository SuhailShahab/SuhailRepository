﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Generic;
using BE.RigthManager;

namespace DAL.RightsManager
{
    public class FeaturesDAL : DALBase
    {

        /// <summary>
        /// Edit Record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Edit(FeaturesModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditAppFeature";

                
                sqlCmd.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Name"].Value = model.Name;
                sqlCmd.Parameters.Add(new SqlParameter("@URL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@URL"].Value = model.Url;
                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = model.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@HasChild", SqlDbType.Bit));
                sqlCmd.Parameters["@HasChild"].Value = model.HasChild ? 1 : 0;
                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = model.IsActive ? 1 : 0;

                sqlCmd.Parameters.Add(new SqlParameter("@menuLocation", SqlDbType.Int));
                sqlCmd.Parameters["@menuLocation"].Value = model.menuLocation;

                sqlCmd.Parameters.Add(new SqlParameter("@AppFeatureID", SqlDbType.Int));
                sqlCmd.Parameters["@AppFeatureID"].Value = model.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@Sort", SqlDbType.Int));
                sqlCmd.Parameters["@Sort"].Value = model.Sort;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// Add New Record to db table
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(FeaturesModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddAppFeature";
                
                sqlCmd.Parameters.Add(new SqlParameter("@MenuName", SqlDbType.NVarChar));
                sqlCmd.Parameters["@MenuName"].Value = model.MenuName;
                sqlCmd.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Name"].Value = model.Name;
                sqlCmd.Parameters.Add(new SqlParameter("@URL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@URL"].Value = model.Url;
                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = model.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@HasChild", SqlDbType.Bit));
                sqlCmd.Parameters["@HasChild"].Value = model.HasChild ? 1 : 0;
                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = model.IsActive ? 1 : 0;

                sqlCmd.Parameters.Add(new SqlParameter("@menuLocation", SqlDbType.Int));
                sqlCmd.Parameters["@menuLocation"].Value = model.menuLocation;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Get all Feature of MenuLocation  2
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllFeaturesByLocation(int location)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetFeaturesByLocation", con);
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@menuLocation", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@menuLocation"].Value = location;
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// Get all Role base CSR Menu/Feature
        /// </summary>
        /// <returns></returns>
        public DataTable GetCSRMenuByID(int userID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetMenuByID", con);
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.Fill(dt);
                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        /// <summary>
        /// Getting all Features for grid
        /// </summary>
        /// <returns></returns>
        public DataTable GetFeature()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetFeature", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        /// <summary>
        /// Getting all Active Features 
        /// </summary>
        /// <returns></returns>
        public DataTable GetFeatures()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetActiveFeatures", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }
    }
}
