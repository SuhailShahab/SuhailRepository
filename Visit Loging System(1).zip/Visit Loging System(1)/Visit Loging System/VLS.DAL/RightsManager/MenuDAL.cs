﻿
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DAL.RightsManager
{

    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil >
    // Create date: <7/11/2014 2:07:32 AM>
    // =================================================================================================================================
    // ===================================================== Modification Menu    ======================================================
    // =================================================================================================================================
    public class MenuDAL : DALBase
    {
        /// <summary>
        /// This Method get the info of Top menu List
        /// </summary>
        /// <param name="_menuType"> which type of menu left Menu or Top menu</param>
        /// <returns>return the Menu list in data table format</returns>
        public DataTable GetFeatures(int _menuType)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetFeatures", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@menuType", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@menuType"].Value = _menuType;

                _sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        /// <summary>
        /// get the Sub Menu on the basis of main menu ID
        /// </summary>
        /// <param name="_featureID">Main Menu ID</param>
        /// <returns>return the data of Sub Menu in Datatable Format</returns>
        public DataTable GetObjectsByFeature(int _featureID,bool? isActive)
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetObjectByFeature", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FeatureID", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@FeatureID"].Value = _featureID;
                if (isActive.HasValue)
                {
                    _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Int));
                    _sqlDadp.SelectCommand.Parameters["@IsActive"].Value = isActive;
                }

                _sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        /// <summary>
        /// Get permitted menus against login user
        /// </summary>
        /// <param name="_user"></param>
        /// <returns></returns>
        public DataSet GetMenuByUser(string _user)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetMenuByLogin", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LoginID", SqlDbType.VarChar));
                _sqlDadp.SelectCommand.Parameters["@LoginID"].Value = _user;

                _sqlDadp.Fill(ds);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }

        public DataSet GetMenuByUser(int loginID)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetMenuByLoginID", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LoginID", SqlDbType.VarChar));
                _sqlDadp.SelectCommand.Parameters["@LoginID"].Value = loginID;

                _sqlDadp.Fill(ds);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }

        public DataTable GetReportsByLoginID(int? id)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.ConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetReportsByLoginID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (id.HasValue && id.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LoginID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@LoginID"].Value = id;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
        }


        /// <summary>
        /// Get Management Menus By UserId
        /// </summary>
        /// <param name="loginID"></param>
        /// <returns></returns>
        public DataTable GetManagementMenuByUser(int loginID)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetPermitMgtMenusByLoginID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LoginID", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@LoginID"].Value = loginID;

                sqlDadp.Fill(ds);
                dt = ds.Tables[0].Copy();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }
      
    }
}
