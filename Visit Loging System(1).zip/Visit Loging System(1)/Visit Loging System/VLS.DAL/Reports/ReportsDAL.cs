﻿using DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

namespace DAL.Reports
{

    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <25-Mar-2016 02:50:05PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time              Desription
    // CR:001       Syed Zeeshan Aqil           30-March-2016                   Add method GetRptAssignTaskDetail to get Action taken report data
    // =================================================================================================================================
    public class ReportsDAL : DALBase
    {
        /// <summary>
        ///  Get Visitor Log Report
        /// </summary>
        /// <returns></returns>
        public DataSet GetRptSecretaryVisitingLogData(int deptID, int userId, int fromMonth, int fromYear, int toMonth, int toYear)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetRptSecretaryVisitLogData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userId;

                    //sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.DateTime));
                    //sqlDadp.SelectCommand.Parameters["@StartDate"].Value = startDate;

                    //sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.DateTime));
                    //sqlDadp.SelectCommand.Parameters["@EndDate"].Value = endDate;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthFrom"].Value = fromMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearFrom"].Value = fromYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthTo"].Value = toMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearTo"].Value = toYear;


                    sqlDadp.Fill(ds);
                    return ds;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();

                }
            }
        }

        /// <summary>
        /// Get department wise vists logs
        /// </summary>
        /// <param name="deptID"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public DataTable GetRptDepartmentVisitsLogs(int? departmentID, int? districtID,int? divisionID, 
            int fromMonth, int fromYear, int toMonth, int toYear, int userID)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitsLogsByMonths", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                   
                    if (departmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }
                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    if (divisionID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthFrom"].Value = fromMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearFrom"].Value = fromYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthTo"].Value = toMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearTo"].Value = toYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserId"].Value = userID;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }

        public DataTable GetRptOfficialDistrictVisitsLog(int? createdBy,int? departmentID, int? districtID, int? divisionID, int fromMonth, int fromYear, int toMonth, int toYear)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictVisitsLogsByOfficials", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (departmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    if (divisionID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                    }

                    if (createdBy.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CreatedBy"].Value = createdBy;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthFrom"].Value = fromMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearFrom"].Value = fromYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthTo"].Value = toMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearTo"].Value = toYear;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }


        public DataTable GetRptRamzanBazarVisitLog(int? createdBy, int? departmentID, int? districtID, int? divisionID, int fromMonth, int fromYear, int toMonth, int toYear, string designationCSV)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictVisitsLogsofRamzanBazarByOfficials", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (departmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    if (divisionID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                    }

                    if (createdBy.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CreatedBy"].Value = createdBy;
                    }

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthFrom"].Value = fromMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearFrom"].Value = fromYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthTo"].Value = toMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearTo"].Value = toYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DesignationCSV", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DesignationCSV"].Value = designationCSV;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }


        /// <summary>
        /// Get Visit Action By District Data
        /// </summary>
        /// <param name="fromMonth"></param>
        /// <param name="fromYear"></param>
        /// <param name="toMonth"></param>
        /// <param name="toYear"></param>
        /// <returns></returns>
        public DataTable GetRptOfficialVisitActionByDistrict(int fromMonth, int fromYear, int toMonth, int toYear, int? districtID, int? deptID,int ? divisionID, int userID)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitActionByDistrictData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthFrom"].Value = fromMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearFrom"].Value = fromYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthTo"].Value = toMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearTo"].Value = toYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserId"].Value = userID;

                    if (districtID.HasValue && districtID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID.Value;
                    }

                    if (deptID.HasValue && deptID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = deptID.Value;
                    }

                    if (divisionID.HasValue && divisionID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID.Value;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }


        public DataTable GetRptActionTakenPerform(int fromMonth, int fromYear, int toMonth, int toYear, int? userID)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetActionTaskPerformData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthFrom"].Value = fromMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearFrom"].Value = fromYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthTo"].Value = toMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearTo"].Value = toYear;

                    if (userID.HasValue && userID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID.Value;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }

        /// <summary>
        /// Get Visit Action By Department Data
        /// </summary>
        /// <param name="fromMonth"></param>
        /// <param name="fromYear"></param>
        /// <param name="toMonth"></param>
        /// <param name="toYear"></param>
        /// <param name="districtID"></param>
        /// <returns></returns>
        public DataTable GetRptOfficialVisitActionByDepartment(int fromMonth, int fromYear, int toMonth, int toYear, int? departmentID, int ? divisionID, int? districtID, int  userID)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitActionByDepartmentData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlDadp.SelectCommand.Parameters.Clear();

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthFrom"].Value = fromMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearFrom"].Value = fromYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthTo"].Value = toMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserId", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserId"].Value = userID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearTo"].Value = toYear;

                    if (departmentID.HasValue && departmentID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID.Value;
                    }

                    if (divisionID.HasValue && divisionID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@divisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@divisionID"].Value = divisionID.Value;
                    }
                    if (districtID.HasValue && districtID.Value > 0)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID.Value;
                    }

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }

        /// <summary>
        /// Get the Action taken Report
        /// </summary>
        /// <param name="visitorLogID">selected visitorLog ID</param>
        /// <returns>Data set</returns>
        public DataSet GetRptAssignTaskDetail(int visitorLogID)
        {
            DataSet ds = new DataSet();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetRptAssignTaskDetail", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@VisitorLogID"].Value = visitorLogID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }
        public DataSet GetRamzanBazarMonitoringDetail(int visitorLogID)
        {
            DataSet ds = new DataSet();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetRamzanBazarMonitoringDetailByID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@VisitorLogID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@VisitorLogID"].Value = visitorLogID;

                    sqlDadp.Fill(ds);
                    return ds;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }

        public DataTable GetOfficialsVisitsObservationByDistrict(int? departmentID, int? districtID, int? divisionID, int fromMonth, int fromYear, int toMonth, int toYear)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAdministrativeVisitsObservation", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    if (departmentID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentID;
                    }

                    if (districtID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                    }

                    if (divisionID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = divisionID;
                    }


                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthFrom"].Value = fromMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearFrom", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearFrom"].Value = fromYear;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@MonthTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@MonthTo"].Value = toMonth;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@YearTo", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@YearTo"].Value = toYear;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }

        public DataTable GetOfficialsVisitsObservationByDistrict(int districtID, DateTime? fromDate, DateTime? toDate)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {

                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetVisitsObservationByDistrict", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;

                    if (fromDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FromDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@FromDate"].Value = fromDate;
                    }

                    if (toDate.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ToDate", SqlDbType.Date));
                        sqlDadp.SelectCommand.Parameters["@ToDate"].Value = toDate;
                    }


                    //if (districtID.HasValue && districtID.Value > 0)
                    //{
                    //    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    //    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID.Value;
                    //}


                    sqlDadp.Fill(dt);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }

            return dt;
        }


       
     /// <summary>
     /// Get Action Taken Attach Documents
     /// </summary>
     /// <param name="taskID">selected taskID</param>
     /// <returns></returns>
        public DataTable GetActionTakenDocument(int taskID)
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                try
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetRptActionTakenDocument", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TaskID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@TaskID"].Value = taskID;

                    sqlDadp.Fill(dt);
                    return dt;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                        con.Close();
                }
            }
        }
    }
}
