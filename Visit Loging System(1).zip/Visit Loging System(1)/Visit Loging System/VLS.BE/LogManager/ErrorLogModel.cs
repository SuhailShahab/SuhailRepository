﻿
using BE.Lookups;
using BE.RigthManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.LogManager
{
    public class ErrorLogModel:BaseModel 
    {
        public int? logID { get; set; }
        public string ErrorCode { get; set; }
        public int? DistrictID { get; set; }
        public string Method { get; set; }
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public string Source { get; set; }
        public int? IsWebMethod { get; set; }        
        public string PageName { get; set; }
        public string PageStaticName { get; set; }
        public Exception CustomException { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        
        // public  DataTable DataUser{ get; set; }




        public ErrorLogModel()
        {

        }

        public ErrorLogModel(Exception ex, string method, string pageName)
        {
            this.Message = ex.Message;
            this.Method = method;
            this.StackTrace = ex.StackTrace;
            this.Source = ex.Source;
            this.PageName = pageName;
        }
       public ErrorLogModel(Exception ex, string methodName, int webMethod, string PageName,int? createdBy)
        {
            this.CustomException = ex;
            this.Method = methodName;
            this.IsWebMethod = webMethod;

            this.PageName = PageName;
            this.ErrorCode = "0";
            this.CreatedBy = createdBy;
        }

       public ErrorLogModel(Exception ex, string methodName, int webMethod, string PageName, string errorCode, int? createdBy)
        {
            this.CustomException = ex;
            this.Method = methodName;
            this.IsWebMethod = webMethod;

            this.PageName = PageName;
            this.ErrorCode = errorCode;
            this.CreatedBy = createdBy;
        }

       public ErrorLogModel(Exception ex, string methodName, int webMethod, string PageName, string errorCode, UserModel currentUser)
       {
           this.CustomException = ex;
           this.Method = methodName;
           this.IsWebMethod = webMethod;

           this.PageName = PageName;
           this.ErrorCode = errorCode;
           if (currentUser != null)
           {
               this.CreatedBy = currentUser.UserID;
               this.DistrictID = currentUser.DistrictID;
           }
       }

       public ErrorLogModel(Exception ex, string methodName, int webMethod, string PageName, UserModel currentUser)
       {
           if (currentUser != null)
           {
               this.CreatedBy = currentUser.UserID;
               this.DistrictID = currentUser.DistrictID;
           }
           this.CustomException = ex;
           this.Method = methodName;
           this.IsWebMethod = webMethod;
           this.PageName = PageName;          
          
       }


        public string GetaAllMessages()
        {
            string message = string.Empty;
            Exception innerException = this.CustomException;

            do
            {
                message = message + (string.IsNullOrEmpty(innerException.Message) ? string.Empty : innerException.Message);
                innerException = innerException.InnerException;
            }
            while (innerException != null);

            return message;
        }


    }

    public class ErrorLogModelView
    {
       
        public List<PageNameModel> PageNames { get; set; }       
        public List<GeneralDistrictModel> Districts { get; set; }        
        public List<ErrorLogModel> ErrorLogs { get; set; }
        public string Notification { get; set; }

         public ErrorLogModelView()
        {

        }
         public ErrorLogModelView(string notification)
        {
            this.Notification = notification;
        }
    }
}
