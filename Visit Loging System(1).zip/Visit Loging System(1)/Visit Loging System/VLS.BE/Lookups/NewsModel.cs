﻿using BE.Common;
using BE.RigthManager;
using System;
using System.Collections.Generic;
using System.Text;

namespace BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Sabeeh Goheer>
    // Create date: <20/04/2016 1:04:04 AM>
    // =================================================================================================================================
    // ================================================ News Model Class======================================================
    // =================================================================================================================================

    [ClassMapping(TableName = "tblNews", Identifier = "NewsID")]

    [Serializable]
    public class NewsModel : BaseModel
    {

        [MappingInfo(ColumnName = "NewsID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "NewsDate")]
        public DateTime? NewsDate { get; set; }

        public string Image { get; set; }

        public NewsModel()
        {
        }

        public NewsModel(string notification)
        {
            this.Notification = notification;
        }

        public NewsModel(int? ID, int? ModifiedBy)
        {
            this.ID = ID;
            this.ModifiedBy = ModifiedBy;
        }

    }


    public class NewsModelView
    {
        public List<NewsModel> allRecords { get; set; }
        public List<ApplicationObjectModel> Reports { get; set; }
        public string Vision { get; set; }
        public string Mission { get; set; }
        public string Governance { get; set; }
        public string Notification { get; set; }

         #region "Constructors"

        public NewsModelView()
        {

        }

        public NewsModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }




}