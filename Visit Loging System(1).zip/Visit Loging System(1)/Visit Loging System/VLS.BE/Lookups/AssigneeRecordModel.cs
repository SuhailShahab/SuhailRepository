﻿using BE.Common;
using BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VLS.BE.Lookups
{
    [ClassMapping(TableName = "tblAssigningRecordMapping", Identifier = "DepartmentID")]
    [Serializable]
   public  class AssigneeRecordModel
    {
        [MappingInfo(ColumnName = "DesignationID")]
        public int? DesignationID { get; set; }
        [MappingInfo(ColumnName = "RecordID")]
        public int? RecordID { get; set; }
        [MappingInfo(ColumnName = "SortOrder")]
        public int? SortOrder { get; set; }
    }

    public class AssigneeRecordView 
      {
          public List<DepartmentModel> Departments { get; set; }
          public List<DesignationModel> Designations { get; set; }
          public int? DepartmentID { get; set; }
          public List<AssigneeRecordModel> AssigneeRecords { get; set; }
          public string Notification { get; set; }

         #region "Constructors"

        public AssigneeRecordView()
        {

        }

        public AssigneeRecordView(string Notification)
        {
            this.Notification = Notification;
        }

          #endregion
      }
}
