﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Lookups
{
    [ClassMapping(TableName = "tblProvince", Identifier = "ProvinceID")]
    [Serializable]
    public class ProvinceModel : BaseModel
    {
        [MappingInfo(ColumnName = "ProvinceID", IdentitySpecification = true)]
        public int ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        #region "Constructors"

        public ProvinceModel()
        {
 
        }

        public ProvinceModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class ProvinceModelView : BaseModel
    {
        public List<ProvinceModel> Provinces { get; set; }

        #region "Constructors"

        public ProvinceModelView()
        {
 
        }

        public ProvinceModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
