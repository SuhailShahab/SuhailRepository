﻿using BE.Common;
using System;
using System.Collections.Generic;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <22-03-2015 02:01:17PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BE.Lookups
{
    [ClassMapping(TableName = "tblTehsil", Identifier = "TehsilID")]
    [Serializable]
    public class TehsilModel : BaseModel
    {
        [MappingInfo(ColumnName = "TehsilID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "ProvinceID", Transient = true)]
        public int? ProvinceID { get; set; }

        [MappingInfo(ColumnName = "DivisionID", Transient = true)]
        public int? DivisionID { get; set; } 

        [MappingInfo(ColumnName = "DistrictID")]
        public int? DistrictID { get; set; }

        [MappingInfo(ColumnName = "DistrictName", Transient=true)]
        public string DistrictName { get; set; }

        #region "Constructors"

        public TehsilModel()
        {

        }

        public TehsilModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class TehsilModelView : BaseModel
    {
        public List<ProvinceModel> Provinces { get; set; }
        public List<DivisionModel> Divisions { get; set; }
        public List<DistrictModel> Districts { get; set; }
        public List<TehsilModel> Tehsils { get; set; }

        #region "Constructors"

        public TehsilModelView()
        {

        }

        public TehsilModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
