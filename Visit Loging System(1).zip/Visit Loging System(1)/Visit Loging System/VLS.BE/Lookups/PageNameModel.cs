﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Lookups
{
    public class PageNameModel
    {
        public string pageName { get; set; }
        //public string PageName {get; set;}
        public string StaticName { get; set; }
        public string FileNameURL { get; set; }
        public string URL { get; set; }
    }
}
