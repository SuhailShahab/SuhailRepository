﻿using BE.Common;
using System;
using System.Text;

// =================================================================================================================================
// Create by:	<Suhail Shahab>
// Create date: <09-07-2014 10:01AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
//   SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace BE.Lookups
{
    [ClassMapping(TableName = "tblDepartmentFacility", Identifier = "FacilityID")]
    [Serializable]
    public class DepartmentFacilityModel : BaseModel
    {
        [MappingInfo(ColumnName = "FacilityID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        
    }
}
