﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <22-03-2015 02:01:17PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BE.Lookups
{
    [ClassMapping(TableName = "tblDistrict", Identifier = "DistrictID")]
    [Serializable]
    public class DistrictModel : BaseModel
    {
        [MappingInfo(ColumnName = "DistrictID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "ProvinceID")]
        public int? ProvinceID { get; set; }

        [MappingInfo(ColumnName = "ProvinceName")]
        public string ProvinceName { get; set; }

        [MappingInfo(ColumnName = "DivisionID")]
        public int? DivisionID { get; set; }

        [MappingInfo(ColumnName = "DivisionName")]
        public string DivisionName { get; set; }

        #region "Constructors"

        public DistrictModel()
        {

        }

        public DistrictModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class DistrictModelView : BaseModel
    {
        public List<ProvinceModel> Provinces { get; set; }
        public List<DivisionModel> Divisions { get; set; }
        public List<DistrictModel> Districts { get; set; }

        #region "Constructors"

        public DistrictModelView()
        {

        }

        public DistrictModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
