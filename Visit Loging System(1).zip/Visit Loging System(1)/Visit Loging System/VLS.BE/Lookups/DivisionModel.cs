﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <24-03-2016 10:03:08AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
//   SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace BE.Lookups
{
    [ClassMapping(TableName = "tblDivision", Identifier = "DivisionID")]
    [Serializable]
    public class DivisionModel : BaseModel
    {
        [MappingInfo(ColumnName = "DivisionID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "ProvinceID")]
        public int? ProvinceID { get; set; }

        [MappingInfo(ColumnName = "ProvinceName")]
        public string ProvinceName { get; set; }

        #region "Constructors"

        public DivisionModel()
        { 
        }

        public DivisionModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class DivisionModelView : BaseModel
    {
        public List<ProvinceModel> Provinces { get; set; }
        public List<DivisionModel> Divisions { get; set; }

        #region "Constructors"

        public DivisionModelView()
        { 
        }

        public DivisionModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
