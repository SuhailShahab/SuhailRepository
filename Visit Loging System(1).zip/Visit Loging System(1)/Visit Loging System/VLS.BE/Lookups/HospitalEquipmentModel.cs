﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <06-04-2016 12:27:04PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// =================================================================================================================================
namespace BE.Lookups
{
    [ClassMapping(TableName = "tblHospitalEquipments", Identifier = "EquipmentID")]
    [Serializable]
    public class HospitalEquipmentModel : BaseModel
    {
        [MappingInfo(ColumnName = "EquipmentID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }


        [MappingInfo(ColumnName = "Checked")]
        public bool? Checked { get; set; }

        #region "Constructors"

        public HospitalEquipmentModel(int? id, int? modifiedBy)
        {
            this.ID = id;
            this.ModifiedBy = modifiedBy;
        }

        public HospitalEquipmentModel()
        {
            this.Checked = false;
        }

        public HospitalEquipmentModel(string notification)
        {
            this.Notification = notification;
        }

        #endregion
    }

    public class HospitalEquipmentModelView : BaseModel
    {

        public List<HospitalEquipmentModel> HospitalEquipments { get; set; }
         #region "Constructors"

       

        public HospitalEquipmentModelView()
        {
           
        }

        public HospitalEquipmentModelView(string notification)
        {
            this.Notification = notification;
        }

        #endregion
    }
}
