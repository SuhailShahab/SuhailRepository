﻿using BE;
using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Sohail Kamran>
// Create date: <29-03-2016 10:40:55PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BE.Lookups
{
    public class RatingModel : BaseModel
    {

        [MappingInfo(ColumnName = "RateID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Name")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }
        //RateCategory
        [MappingInfo(ColumnName = "RateCategory")]
        public string Category { get; set; }

        [MappingInfo(ColumnName = "Sort")]
        public int? Sort { get; set; }

        #region "properties for sms and emial message"
        // properties for sms and emial message
        //ObservationSMSForOfficial
        [MappingInfo(ColumnName = "ObservationSMSForOfficial")]
        public string ObservationSMSForOfficial { get; set; }

        //ObservationEMailForOfficial
        [MappingInfo(ColumnName = "ObservationEMailForOfficial")]
        public string ObservationEMailForOfficial { get; set; }

        //ObservationSMSForSubOrdinates
        [MappingInfo(ColumnName = "ObservationSMSForSubOrdinates")]
        public string ObservationSMSForSubOrdinates { get; set; }

        //ObservationEamilForSubOrdinates
        [MappingInfo(ColumnName = "ObservationEamilForSubOrdinates")]
        public string ObservationEamilForSubOrdinates { get; set; }

        //VisitSMSForOffical
        [MappingInfo(ColumnName = "VisitSMSForOffical")]
        public string VisitSMSForOffical { get; set; }

        //VisitEmailForOffical
        [MappingInfo(ColumnName = "VisitEmailForOffical")]
        public string VisitEmailForOffical { get; set; }

        [MappingInfo(ColumnName = "ActionTakenOfficialEmail")]
        public string ActionTakenOfficialEmail { get; set; }

        [MappingInfo(ColumnName = "ActionTakenOfficialSMS")]
        public string ActionTakenOfficialSMS { get; set; }

        #endregion

        //public int VisitCount { get; set; }

        [MappingInfo(ColumnName = "VisitCount", Transient = true)]
        public int VisitCount { get; set; }

        //[MappingInfo(ColumnName = "VisitCount"), MappingInfo(Transient = true)]

        #region "Constructors"

        public RatingModel()
        {
        }

        public RatingModel(int? ID)
        {
            this.ID = ID;
        }

        public RatingModel(int? ID, int? ModifiedBy)
        {
            this.ID = ID;
            this.ModifiedBy = ModifiedBy;
           
        }

        public RatingModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class RatingModelView : BaseModel
    {
        public List<RatingModel> Ratings { get; set; }

        #region "Constructors"

        public RatingModelView()
        {

        }
        public RatingModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
