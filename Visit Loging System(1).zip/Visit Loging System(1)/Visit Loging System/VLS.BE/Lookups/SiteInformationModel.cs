﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Sohail Kamran>
    // Create date: <20/05/2016 12:16:04 PM>
    // =================================================================================================================================
    // ================================================ SiteInformationModel Model Class======================================================
    // =================================================================================================================================

    [ClassMapping(TableName = "tblSiteInfo", Identifier = "InfoID")]
    [Serializable]
    public class SiteInformationModel : BaseModel
    {
        [MappingInfo(ColumnName = "InfoID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Vision")]
        public string Vision { get; set; }
        [MappingInfo(ColumnName = "Mission")]
        public string Mission { get; set; }
        [MappingInfo(ColumnName = "Governance")]
        public string Governance { get; set; }

        #region "Constructors"
        public SiteInformationModel()
        {

        }
        public SiteInformationModel(string Notification)
        {
            this.Notification = Notification;
        }
        public SiteInformationModel(int? ID)
        {
            this.ID = ID;
        }

        public SiteInformationModel(int? ID, int? ModifiedBy)
        {
            this.ID = ID;
            this.ModifiedBy = ModifiedBy;
        }
        #endregion
    }

    public class SiteInformationView : BaseModel
    {
        public List<SiteInformationModel> SiteInformations { get; set; }

        #region "Constructors"

        public SiteInformationView()
        { }
        public SiteInformationView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
