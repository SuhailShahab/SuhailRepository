﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <06-04-2016 12:27:04PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// =================================================================================================================================
namespace BE.Lookups
{
    [ClassMapping(TableName = "tblHospitalType", Identifier = "HospitalTypeID")]
    [Serializable]
    public class HospitalTypeModel : BaseModel
    {
        [MappingInfo(ColumnName = "HospitalTypeID", IdentitySpecification = true)]
        public int ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }

        public bool Checked { get; set; }

        #region "Constructors"

        public HospitalTypeModel()
        {
            this.Checked = false;
        }

        public HospitalTypeModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion


      
    }

    public class HospitalTypeModelView : BaseModel
    {
        public List<HospitalTypeModel> HospitalType { get; set; }
           #region "Constructors"

        public HospitalTypeModelView()
        {
            
        }

        public HospitalTypeModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
