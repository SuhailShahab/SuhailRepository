﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <06-04-2016 12:27:04PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// =================================================================================================================================
namespace BE.Lookups
{
    [ClassMapping(TableName = "tblMedicineType", Identifier = "MedicinesTypeID")]
    [Serializable]
    public class MedicineTypeModel : BaseModel
    {
        [MappingInfo(ColumnName = "MedicinesTypeID", IdentitySpecification = true)]
        public int ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

         [MappingInfo(ColumnName = "Checked")]
        public bool? Checked { get; set; }

        #region "Constructors"

        public MedicineTypeModel()
        {
            this.Checked = false;
        }

        public MedicineTypeModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class MedicinceTypeModelView : BaseModel
    {
        public List<MedicineTypeModel> MedcinceTypes { get; set; }
              #region "Constructors"

        public MedicinceTypeModelView()
        {
         
        }

        public MedicinceTypeModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
