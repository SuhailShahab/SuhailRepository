﻿
using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Lookups
{
    [ClassMapping(TableName = "tblConstituency", Identifier = "ConstituencyID")]
    [Serializable]
    public class ConstituencyModel : BaseModel
    {
         public ConstituencyModel()
        {
        }
         public ConstituencyModel(string notification)
        {
            this.Notification = notification;
        }
        public ConstituencyModel(int? ID)
        {
            this.ID = ID;
        }

        public ConstituencyModel(int? ID, int? ModifiedBy)
        {
            this.ID = ID;
            this.ModifiedBy = ModifiedBy;
        }

        [MappingInfo(ColumnName = "ConstituencyID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int? DistrictID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "District"), MappingInfo(Transient = true)]
        public string District { get; set; }

    }



    public class ConstituencyModelView : BaseModel
    {
        public List<DistrictModel> Districts { get; set; }
        public List<ConstituencyModel> Constituencyies { get; set; }
        
       public ConstituencyModelView()
        {
        }
       public ConstituencyModelView(string notification)
        {
            this.Notification = notification;
        }
    }
}
