﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <06-04-2016 12:27:04PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// =================================================================================================================================
namespace BE.Lookups
{
    [ClassMapping(TableName = "tblDoctorPosts", Identifier = "DoctorPostID")]
    [Serializable]
    public class DoctorPostModel : BaseModel
    {
        [MappingInfo(ColumnName = "DoctorPostID", IdentitySpecification = true)]
        public int ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "Checked")]
        public bool? Checked { get; set; }

        #region "Constructors"

        public DoctorPostModel()
        {
            this.Checked = false;
        }

        public DoctorPostModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class DoctorPostModelView : BaseModel
    {
        public List<DoctorPostModel> DoctorPosts { get; set; }
          #region "Constructors"

        public DoctorPostModelView()
        {
            
        }

        public DoctorPostModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
