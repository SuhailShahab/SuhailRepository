﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <26-12-2014 08:30PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time      Desription
    // CR:          Usman Mirza                 10-Jun-2015             Addition of Dropdown for mapping FC District ID 
    // =================================================================================================================================
    public class GeneralDistrictModel : BaseModel
    {
        public int? ID { get; set; }
        public int DivisionID { get; set; }
        public string DivisionName { get; set; }
        public string Title { get; set; }
     
        public string Description { get; set; }           
        public int? ProvinceID { get; set; }


    }

    public class GeneralDistrictModelView : BaseModel
    {
        public List<DivisionModel> Divisions { get; set; }       
        public List<GeneralDistrictModel> AllActiveDistricts { get; set; }
        public List<GeneralDistrictModel> Districts { get; set; }       
    }


}
