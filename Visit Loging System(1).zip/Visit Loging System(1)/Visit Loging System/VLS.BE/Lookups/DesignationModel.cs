﻿
using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Lookups
{
    [ClassMapping(TableName = "tblDesignation", Identifier = "DesignationID")]
    [Serializable]
    public class DesignationModel : BaseModel
    {
        #region "Constructors"

        public DesignationModel()
        {
        }

        public DesignationModel(string Notification)
        {
            this.Notification = Notification;
        }

        public DesignationModel(int? ID)
        {
            this.ID = ID;
        }

        public DesignationModel(int? ID, int? ModifiedBy)
        {
            this.ID = ID;
            this.ModifiedBy = ModifiedBy;
        }

        public DesignationModel(int ID, string Title)
        {
            this.ID = ID;
            this.Title = Title;
        }

        #endregion

        [MappingInfo(ColumnName = "DesignationID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "TargetID")]
        public string TargetID { get; set; }

        public bool Checked { get; set; }
    }

    public class DesignationModelView
    {
        public List<DesignationModel> colDesingations { get; set; }
        public string Notification { get; set; }

        public DesignationModelView() { }

        public DesignationModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
