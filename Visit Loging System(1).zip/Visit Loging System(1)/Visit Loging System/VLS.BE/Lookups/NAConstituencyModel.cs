﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Lookups
{

    [ClassMapping(TableName = "tblNAConstituency", Identifier = "NAConstituencyID")]
    [Serializable]
    public class NAConstituencyModel : BaseModel
    {
        public NAConstituencyModel()
        {

        }

        public NAConstituencyModel(int? ID)
        {
            this.ID = ID;
        }

        public NAConstituencyModel(int? ID, int? ModifiedBy)
        {
            this.ID = ID;
            this.ModifiedBy = ModifiedBy;
        }

        [MappingInfo(ColumnName = "NAConstituencyID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int? DistrictID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

        [MappingInfo(ColumnName = "District"), MappingInfo(Transient = true)]
        public string District { get; set; }

    }




}
