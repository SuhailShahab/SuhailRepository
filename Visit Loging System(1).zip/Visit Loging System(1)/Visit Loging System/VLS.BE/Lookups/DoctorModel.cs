﻿using BE.Common;
using System;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <06-04-2016 12:27:04PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// =================================================================================================================================
namespace BE.Lookups
{
    [ClassMapping(TableName = "tblDoctors", Identifier = "DoctorID")]
    [Serializable]
    public class DoctorModel : BaseModel
    {
        [MappingInfo(ColumnName = "DoctorID", IdentitySpecification = true)]
        public int ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

         [MappingInfo(ColumnName = "Checked")]
        public bool? Checked { get; set; }

        #region "Constructors"

        public DoctorModel()
        {
            this.Checked = false;
        }

        public DoctorModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
