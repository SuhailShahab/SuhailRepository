﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <7/10/2014 1:04:04 AM>
    // =================================================================================================================================
    // ================================================ City Model Class======================================================
    // =================================================================================================================================

    [ClassMapping(TableName = "tblCity", Identifier = "CityID")]
    [Serializable]
    public class CityModel : BaseModel
    {

        [MappingInfo(ColumnName = "CityID", IdentitySpecification = true)]
        public int? ID { get; set; }

         [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

         [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }

       

        public CityModel()
        {
        }
        public CityModel(string notification)
        {
            this.Notification = notification;
        }

        public CityModel(int? ID, int? ModifiedBy)
        {
            this.ID = ID;
            this.ModifiedBy = ModifiedBy;
        }

    }


    public class CityModelView
    {
        public List<CityModel> allRecords { get; set; }
        public string Notification { get; set; }
         public CityModelView()
        {
        }
         public CityModelView(string notification)
        {
            this.Notification = notification;
        }
    }

     

    
}