﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VLS.BE.Lookups
{
    public class PlaceCategoryModel
    {
    }
}
