﻿using BE.Common;
using BE.Content;
using BE.RamzanBazars;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <21-04-2016 01:15:34PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// =================================================================================================================================
namespace BE.Visit
{
    public class Visit
    {
        [MappingInfo(ColumnName = "VisitorLogID", IdentitySpecification = true)]
        public int VisitorLogID { get; set; }

        [MappingInfo(ColumnName = "ProvinceID")]
        public int ProvinceID { get; set; }

        [MappingInfo(ColumnName = "DivisionID")]
        public int DivisionID { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int DistrictID { get; set; }

        [MappingInfo(ColumnName = "TehsilID")]
        public int TehsilID { get; set; }

        [MappingInfo(ColumnName = "UnionCouncilID")]
        public int UnionCouncilID { get; set; }

        [MappingInfo(ColumnName = "ConstituencyID")]
        public int ConstituencyID { get; set; }

        [MappingInfo(ColumnName = "NAConstituencyID")]
        public int NAConstituencyID { get; set; }

        [MappingInfo(ColumnName = "DepartmentID")]
        public int DepartmentID { get; set; }

        [MappingInfo(ColumnName = "Place")]
        public string Place { get; set; }

        [MappingInfo(ColumnName = "StartDate")]
        public DateTime? VisitStartDate { get; set; }

        [MappingInfo(ColumnName = "StartTime")]
        public DateTime? VisitStartTime { get; set; }

        [MappingInfo(ColumnName = "EndDate")]
        public DateTime? VisitEndDate { get; set; }

        [MappingInfo(ColumnName = "EndTime")]
        public DateTime? VisitEndTime { get; set; }

        [MappingInfo(ColumnName = "Agenda")]
        public string VisitAgenda { get; set; }

        [MappingInfo(ColumnName = "FeedBack")]
        public string FeedBack { get; set; }

        [MappingInfo(ColumnName = "Rating")]
        public int? Rating { get; set; }

        [MappingInfo(ColumnName = "Latitude")]
        public decimal? Latitude { get; set; }

        [MappingInfo(ColumnName = "Longitude")]
        public decimal? Longitude { get; set; }

        public HealthObservation Hospital { get; set; }
        public EducationObservation Education { get; set; }
        public List<VisitImage> Images { get; set; }

        #region "Mobile Entry Extra Properties"

        [MappingInfo(ColumnName = "IMENo")]
        public string IMENo { get; set; }

        [MappingInfo(ColumnName = "ActivityDateTime")]
        public DateTime ActivityDateTime { get; set; }

        public string LatLong { get; set; }     // comma separated latitude and longitude values

        #endregion

        [MappingInfo(ColumnName = "IsUnauthorizedEntry")]
        public bool IsUnauthorizedEntry { get; set; } 

        [MappingInfo(ColumnName = "CreatedBy")]
        public int CreatedBy { get; set; }

        public Visit()
        {
            this.IsUnauthorizedEntry = false;
        }
    }

    public class VisitImage
    {
        public string Title { get; set; }
        //public string VisitLogImage { get; set; }     //Base64 string of image
        public string ContentType { get; set; }          //image/jpg
        public byte[] FileBinary { get; set; }
    }

    public class Model
    {
        public int ID { get; set; }
    }

    public class HealthObservation
    {
        [MappingInfo(ColumnName = "HospitalTypeID")]
        public int? HospitalTypeID { get; set; }

        [MappingInfo(ColumnName = "HospitalCleanliness")]
        public bool HospitalCleanliness { get; set; }

        public List<Model> DoctorIDs { get; set; }
        public List<Model> DoctorPostIDs { get; set; }
        public List<Model> HospitalEquipmentIDs { get; set; }
        public List<Model> MedicineTypeIDs { get; set; }
    }

    public class EducationObservation
    {
        [MappingInfo(ColumnName = "TecherAbsentPercentage")]
        public int? AbsentTecherPercentage { get; set; }

        [MappingInfo(ColumnName = "StudentAbsentPercentage")]
        public int? AbsentStudentPercentage { get; set; }

        [MappingInfo(ColumnName = "IsWashroomClean")]
        public bool WashroomCleanliness { get; set; }

        [MappingInfo(ColumnName = "GeneralCleanlines")]
        public bool GeneralCleanliness { get; set; }

        [MappingInfo(ColumnName = "DrinkWaterAvailable")]
        public bool DrinkWaterAvailable { get; set; }

        [MappingInfo(ColumnName = "ElectricityAvailable")]
        public bool ElectricityAvailable { get; set; }

        [MappingInfo(ColumnName = "SecuirtyArrangements")]
        public bool SecurityArrangementAvailable { get; set; } 
    }

    public class VisitorLogInput
    {
        public VisitorLogModel VisitorModel { get; set; }
        public DataTable dtDoctor { get; set; }
        public DataTable dtDoctorPosts { get; set; }
        public DataTable dtHospitalEquipment { get; set; }
        public DataTable dtMedicineTypes { get; set; }        
        public DataTable dtRamzanAllItems { get; set; }

    }
}
