﻿using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <27-05-2015 02:55:24PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace  BE
{
    public class MenuModel
    {
        public int MenuFeatureID { get; set; }
        public string MenuName { get; set; }
        public string Name { get; set; }
        public bool HasChild { get; set; }
        public bool Select { get; set; }
        public List<MenuObjectModel> Object { get; set; }
    }

    public class MenuObjectModel
    {
        public int MenuObjectID { get; set; }
        public string Name { get; set; }
        public bool Select { get; set; }
    }
}
