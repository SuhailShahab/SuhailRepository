﻿using BE.Common;

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.RigthManager
{
    public class ManageGroupBaseRight : BaseModel
    {
        [MappingInfo(ColumnName = "FileRemove")]
        public bool? AllowFileRemoved { get; set; }
        [MappingInfo(ColumnName = "FileView")]
        public bool? AllowFileView { get; set; }
        [MappingInfo(ColumnName = "FileDownload")]
        public bool? AllowFileDownload { get; set; }
        [MappingInfo(ColumnName = "FileAdd")]
        public bool? AllowFileAttachment { get; set; }
        [MappingInfo(ColumnName = "ActionTaken")]
        public bool? AllowActionTaken { get; set; }
        [MappingInfo(ColumnName = "IsAllowedToEdit")]
        public bool? IsAllowedToEdit { get; set; }

    }

    public class UserGroupRights:ManageGroupBaseRight
    {
        public DataSet dsAllPermitRights { get; set; }
    }
}
