﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BE.RigthManager
{
     [ClassMapping(TableName = "tblAppObjects", Identifier = "AppObjectID")]
     [Serializable]
    public class ApplicationObjectModel : BaseModel
    {
        public int ID { get; set; }
        public int AppFeatureID { get; set; }
        public string StaticName { get; set; }
        [MappingInfo(ColumnName = "Name")]
        public string Name { get; set; }
        [MappingInfo(ColumnName = "URL")]
        public string URL { get; set; }
        public string Description { get; set; }
        public bool HasChild { get; set; }
        public int Sort { get; set; }
        public string Icon { get; set; }

          #region "Constructors"

        public ApplicationObjectModel()
        {

        }

        public ApplicationObjectModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    /// <summary>
    /// Application Objects View Model
    /// </summary>
    public class ApplicationObjectsModelView : BaseModel
    {
        public List<ApplicationFeatureModel> Features { get; set; }
        public List<ApplicationObjectModel> ApplicationObjectes { get; set; }
        public bool IsAdmin { get; set; }

        
          #region "Constructors"

        public ApplicationObjectsModelView()
        {

        }

        public ApplicationObjectsModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
