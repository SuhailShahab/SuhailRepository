﻿
using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <08-01-2015 05:04:07PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
//1             Asad Ali                          07/03/3016                  Add Designation
// =================================================================================================================================
namespace BE.RigthManager
{
    [ClassMapping(TableName = "tblUsers", Identifier = "UserID")]
    [Serializable]
    public class UserModel : ManageGroupBaseRight
    {
        [MappingInfo(ColumnName = "UserID", IdentitySpecification = true)]
        public int? UserID { get; set; }
        [MappingInfo(ColumnName = "DepartmentID")]
        public int? DepartmentID { get; set; }
        [MappingInfo(ColumnName = "DivisionID")]
        public int? DivisionID { get; set; }
        [MappingInfo(ColumnName = "DistrictID")]
        public int? DistrictID { get; set; }
        [MappingInfo(ColumnName = "TehsilID")]
        public int? TehsilID { get; set; }
        [MappingInfo(ColumnName = "SectorID")]
        public int? SectorID { get; set; }
        [MappingInfo(ColumnName = "SubSectorID")]
        public int? SubSectorID { get; set; }        
        [MappingInfo(ColumnName = "DistrictCode")]
        public string  DistrictCode { get; set; }
        [MappingInfo(ColumnName = "UserName")]
        public string UserName { get; set; }
        [MappingInfo(ColumnName = "EmployeeName")]
        public string EmployeeName { get; set; }
        [MappingInfo(ColumnName = "CNIC")]
        public string CNIC { get; set; }
        [MappingInfo(ColumnName = "EMail")]
        public string EMail { get; set; }
        [MappingInfo(ColumnName = "CellNumber")]
        public string CellNumber { get; set; }
        [MappingInfo(ColumnName = "UserTypeID")]
        public int? UserTypeID { get; set; }
        public bool IsActive { get; set; }
        [MappingInfo(ColumnName = "Url")]
        public string  Url { get; set; }
        [MappingInfo(ColumnName = "DesignationID")]
        public int? DesignationID { get; set; }
        [MappingInfo(ColumnName = "IsVisitLog")]
        public bool? IsVisitLog { get; set; }
        [MappingInfo(ColumnName = "DepartmentName",Transient=true)]
        public string DepartmentName { get; set; }
        [MappingInfo(ColumnName = "DesignationName", Transient = true)]
        public string DesignationName { get; set; }
        [MappingInfo(ColumnName = "DistrictName", Transient = true)]
        public string DistrictName { get; set; }
        [MappingInfo(ColumnName = "DivisionName", Transient = true)]
        public string DivisionName { get; set; }  
        [MappingInfo(ColumnName = "PermitGroupID", Transient = true)]
        public int? PermitGroupID { get; set; }

        
        
    }

    public class UserModelView
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string EmployeeName { get; set; }
        public string CNIC { get; set; }
        public string District { get; set; }
        public string CellNumber { get; set; }
        public string EMail { get; set; }
        public bool IsActive { get; set; }

        public int UserTypeID { get; set; }
    }

    public class VisitConcernUser
    {
        public UserModel  Visiter { get; set; }
        public UserModel Secretary { get; set; }
        public List<UserModel> SecretaryReportingUsers { get; set; }
        public UserModel DCO { get; set; }
        public UserModel Commissioner { get; set; }

    }

    public class SMSModel
    {
        public string  PhoneNo { get; set; }
        public string  SMSMessage { get; set; }
    }



}
