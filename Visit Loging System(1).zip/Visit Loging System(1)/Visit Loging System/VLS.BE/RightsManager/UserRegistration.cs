﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time              Desription
//CR:001            SUHAIL SHAHAB                   11-6-2015                       Add Address Fields
//CR:002            Muhammad Usman                  30-6-2015                       Add Officiating User Rights Fields Fields
//CR:002            Asad Ali                        07-3-2016                       Add Designation Fields
// =================================================================================================================================
namespace BE.RigthManager
{
    public class UserRegistration : UserRights
    {
        public DataTable UserDistricts { get; set; }
        public DataTable UserDivisions { get; set; }
        public DataTable UserTehsils { get; set; }
        public DataTable UserFeaturs { get; set; }
       
        public DataTable UserDesignations { get; set; }
        public DataTable UserDepartments { get; set; }
        public DataTable UserDepartmentFacility { get; set; }
        public DateTime? JoinDate { get; set; }
        public DateTime? ResignDate { get; set; }
        public bool? EnforceRight { get; set; }      
       // public string CurrentUserName { get; set; }
        public string BlockReason { get; set; }      
      
        public int? UserTypeID { get; set; }
        public int? GroupID { get; set; }
        public string CellNumber { get; set; }
        public string IMENo { get; set; }
        public string EMail { get; set; }
        public string CNIC { get; set; }
        public string EmployeeName { get; set; }
        public string LoginName { get; set; }
        public int? DepartmentID { get; set; }
        public int? DivisionID { get; set; }
        public int? ProvinceID { get; set; }
        public int? DesignationID { get; set; }
        public int? GeneralDistrictID { get; set; }
        public int? TehsilID { get; set; }
        public string Signature { get; set; }
        public int? UserID { get; set; }
        public int? ReportingUserID { get; set; }
       
        public int? AddressDivisionID { get; set; }
        public int? AddressDistrictID { get; set; }

        public int? SectorID { get; set; }
        public int? SubSectorID { get; set; }
    
        public string FullAddress { get; set; }
       

    }
}
