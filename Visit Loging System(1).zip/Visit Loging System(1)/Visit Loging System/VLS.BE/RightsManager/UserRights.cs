﻿
using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.RigthManager
{
    //[ClassMapping(TableName = "Post_Products", Identifier = "ProductID")]
    [Serializable]
    public class UserRights : BaseModel
    {
        [MappingInfo(ColumnName = "FileAdd", IdentitySpecification = true)]
        public bool FileAdd { get; set; }
        [MappingInfo(ColumnName = "FileRemove", IdentitySpecification = false)]
        public bool FileRemove { get; set; }
        [MappingInfo(ColumnName = "FileDownload", IdentitySpecification = false)]
        public bool FileDownload { get; set; }
        [MappingInfo(ColumnName = "ActionTaken", IdentitySpecification = false)]
        public bool ActionTaken { get; set; }
        [MappingInfo(ColumnName = "FileView", IdentitySpecification = false)]
        public bool FileView { get; set; }
        [MappingInfo(ColumnName = "IsAllowedToEdit", IdentitySpecification = false)]
        public bool? IsAllowedToEdit { get; set; }
        [MappingInfo(ColumnName = "Password")]
        public string  Password { get; set; }

    }
}
