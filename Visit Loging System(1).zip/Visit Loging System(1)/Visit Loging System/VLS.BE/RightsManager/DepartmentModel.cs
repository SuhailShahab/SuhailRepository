﻿using BE;
using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.BE.RigthManager
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:01AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblDepartments", Identifier = "DepartmentID")]
    [Serializable]
    public class DepartmentModel : BaseModel
    {

        public DepartmentModel()
        { 
        }
        public DepartmentModel(int? ID)
        {
            this.ID = ID;
        }

        public DepartmentModel(int? ID, int? modifiedBy)
        {
            this.ID = ID;
            this.ModifiedBy = modifiedBy;
        }



        [MappingInfo(ColumnName = "DepartmentID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }


        //[MappingInfo(ColumnName = "IsActive")]
        //public bool Status { get; set; }
    }

   
}
