﻿using BE;
using BE.Common;
using PITB.BE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.FMS.Modules.DataModelLayer.Lookups
{
    [ClassMapping(TableName = "tblDesignation", Identifier = "DesignationID")]
    [Serializable]
    public class DesignationModel : BaseModel
    {
        public DesignationModel()
        {
        }
        public DesignationModel(int? ID)
        {
            this.ID = ID;
        }

        public DesignationModel(int? ID, int? modifiedBy)
        {
            this.ID = ID;
            this.ModifiedBy = modifiedBy;
        }

        [MappingInfo(ColumnName = "DesignationID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }

        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }


    }
}
