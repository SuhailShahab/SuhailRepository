﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.EmailScheduler
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <25-05-2016 12:13AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblNotVisitedLog", Identifier = "UserID")]
    [Serializable]
    public class NotVisitLogModel
    {
        [MappingInfo(ColumnName = "LogID", IdentitySpecification = true)]
        public int? ID { get; set; }
         [MappingInfo(ColumnName = "UserID")]
        public int? UserID { get; set; }
        [MappingInfo(ColumnName = "EmployeeName")]
        public string EmployeeName { get; set; }
        [MappingInfo(ColumnName = "Message")]
        public string Message { get; set; }
        [MappingInfo(ColumnName = "StatusID")]
        public int? StatusID { get; set; }
        [MappingInfo(ColumnName = "SendDate")]
        public DateTime? SendDate { get; set; }
        [MappingInfo(ColumnName = "SendDate")]
        public string CNIC { get; set; }
        [MappingInfo(ColumnName = "Email")]
        public string Email { get; set; }
        [MappingInfo(ColumnName = "CellNumber")]
        public string CellNumber { get; set; }

    }


}
