﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.EmailScheduler
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <25-05-2016 12:13AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblEmailSMSTemplate", Identifier = "TemplateID")]
    [Serializable]
    public class EmailSMSTemplateModel
    {
        [MappingInfo(ColumnName = "TemplateID", IdentitySpecification = true)]
        public int? TemplateID { get; set; }
        [MappingInfo(ColumnName = "EmailSubject")]
        public string EmailSubject { get; set; }
        [MappingInfo(ColumnName = "EmailBoday")]
        public string EmailBoday { get; set; }
        [MappingInfo(ColumnName = "SMSMessage")]
        public string SMSMessage { get; set; }
    }
}
