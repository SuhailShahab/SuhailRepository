﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.EmailQueue
{
   public class EmailModel
    {

       public EmailModel()
       {

       }

       public EmailModel(string subject ,string body)
       {
           this.Subject = subject;
           this.Body = body;

       }
      
        public string Subject { get; set; }       
        public string Body { get; set; }      
        public List<string> ToEmailAddresses { get; set; }      
        public List<string> CCEamilAddresses { get; set; }       
        public List<string> BCEmailAddresses { get; set; }
        public string SenderEmail { get; set; }   
    }
}
