﻿
using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <19-01-2016 10:01AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================

namespace VLS.BE.SessionState
{
    [ClassMapping(TableName = "tblSessionState", Identifier = "SessionID")]
    [Serializable]
    public class SessionStateModel
    {
        [MappingInfo(ColumnName = "SessionID", IdentitySpecification = true)]
        public string SessionID { get; set; }
        [MappingInfo(ColumnName = "LoginID")]
        public int? LoginID { get; set; }
        [MappingInfo(ColumnName = "XmlObject")]
        public string XmlObject { get; set; }
        [MappingInfo(ColumnName = "TimeOut")]
        public int? TimeOut { get; set; }
    }
}
