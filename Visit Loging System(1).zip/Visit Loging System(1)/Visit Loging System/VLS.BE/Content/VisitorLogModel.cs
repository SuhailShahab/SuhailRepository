﻿using BE.Common;
using BE.Lookups;
using BE.RamzanBazars;
using System;
using System.Collections.Generic;

namespace BE.Content
{
    public class VisitorLogModel : BaseModel
    {
        [MappingInfo(ColumnName = "VisitorLogID", IdentitySpecification = true)]
        public int VisitorLogID { get; set; }

        [MappingInfo(ColumnName = "ProvinceID")]
        public int ProvinceID { get; set; }

        [MappingInfo(ColumnName = "DivisionID")]
        public int DivisionID { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int DistrictID { get; set; }

        [MappingInfo(ColumnName = "CityID")]
        public int? CityID { get; set; }

        [MappingInfo(ColumnName = "TehsilID")]
        public int TehsilID { get; set; }

        [MappingInfo(ColumnName = "UnionCouncilID")]
        public int UnionCouncilID { get; set; }

        [MappingInfo(ColumnName = "ConstituencyID")]
        public int ConstituencyID { get; set; }

        [MappingInfo(ColumnName = "DepartmentID")]
        public int DepartmentID { get; set; }

        [MappingInfo(ColumnName = "Place")]
        public string Place { get; set; }

        [MappingInfo(ColumnName = "StartDate")]
        public DateTime? VisitStartDate { get; set; }

        [MappingInfo(ColumnName = "StartTime")]
        public DateTime? VisitStartTime { get; set; }

        [MappingInfo(ColumnName = "EndDate")]
        public DateTime? VisitEndDate { get; set; }

        [MappingInfo(ColumnName = "EndTime")]
        public DateTime? VisitEndTime { get; set; }

        [MappingInfo(ColumnName = "Agenda")]
        public string VisitAgenda { get; set; }

        [MappingInfo(ColumnName = "FeedBack")]
        public string FeedBack { get; set; }

        [MappingInfo(ColumnName = "AssignedTo")]
        public int AssignedTo { get; set; }

        [MappingInfo(ColumnName = "Rating")]
        public int? Rating { get; set; }

        [MappingInfo(ColumnName = "Latitude")]
        public decimal? Latitude { get; set; }

        [MappingInfo(ColumnName = "Longitude")]
        public decimal? Longitude { get; set; }

        public List<ImageModel> Images { get; set; }

        [MappingInfo(ColumnName = "NAConstituencyID")]
        public int? NAConstituencyID { get; set; }



        #region "Health Additional Properties"

        [MappingInfo(ColumnName = "HospitalTypeID")]
        public int? HospitalTypeID { get; set; }

        [MappingInfo(ColumnName = "IsHospitalCleanliness")]
        public bool? HospitalCleanliness { get; set; }

        public List<DoctorModel> Doctors { get; set; }
        public List<DoctorPostModel> DoctorPosts { get; set; }
        public List<HospitalEquipmentModel> HospitalEquipments { get; set; }
        public List<MedicineTypeModel> MedicineTypes { get; set; }

        #endregion

        #region "Education Additional Properties"

        [MappingInfo(ColumnName = "TecherAbsentPercentage")]
        public int? AbsentTecherPercentage { get; set; }

        [MappingInfo(ColumnName = "StudentAbsentPercentage")]
        public int? AbsentStudentPercentage { get; set; }

        [MappingInfo(ColumnName = "IsWashroomClean")]
        public bool? WashroomCleanliness { get; set; }

        [MappingInfo(ColumnName = "GeneralCleanlines")]
        public bool? GeneralCleanliness { get; set; }

        [MappingInfo(ColumnName = "DrinkWaterAvailable")]
        public bool? DrinkWaterAvailable { get; set; }

        [MappingInfo(ColumnName = "ElectricityAvailable")]
        public bool? ElectricityAvailable { get; set; }

        [MappingInfo(ColumnName = "SecuirtyArrangements")]
        public bool? SecurityArrangementAvailable { get; set; }

        [MappingInfo(ColumnName = "IsBoundaryWallIntact")]
        public bool? IsBoundaryWallIntact { get; set; } 

        #endregion


        public RamzanBazarMonitoringModel RamzanBazarModel { get; set; }

        #region "Constructors"

        public VisitorLogModel()
        {

        }

        public VisitorLogModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }



    public class VisitorLogModelView:BaseModel
    {
        public List<ProvinceModel> Provinces { get; set; }
        public List<DivisionModel> Divisions { get; set; }
        public List<DistrictModel> Districts { get; set; }
        public List<CityModel> Cities { get; set; }
        public List<TehsilModel> Tehsils { get; set; }
        public List<UnionCouncilModel> UnionCouncils { get; set; }
        public List<ConstituencyModel> Constituencies { get; set; }
        public List<NAConstituencyModel> NAConstituencies { get; set; }
        public List<DepartmentModel> Departments { get; set; }
        //public List<ImageModel> VisitoryImages { get; set; }
        public List<ActionImageModel> VisitoryImages { get; set; }
        
        public VisitorLogModel VisitorLogs { get; set; }

        //public List<DoctorModel> Doctors { get; set; }
        //public List<DoctorPostModel> DoctorPosts { get; set; }
        //public List<HospitalEquipmentModel> HospitalEquipments { get; set; }
        public List<HospitalTypeModel> HospitalTypes { get; set; }
        public List<ConditionModel> Conditions { get; set; }
        //public List<MedicineTypeModel> MedicineTypes { get; set; }

        public VisitorLogModel visit { get; set; }
        //public string Notification { get; set; }

        #region "Constructors"

        public VisitorLogModelView()
        {

        }

        public VisitorLogModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }


    public class ImageModel
    {

        [MappingInfo(ColumnName = "ImageID", IdentitySpecification = true)]
        public int ImageID { get; set; }

        [MappingInfo(ColumnName = "VisitorLogID")]
        public int VisitorLogID { get; set; }

        [MappingInfo(ColumnName = "ImageTitle")]
        public string ImageTitle { get; set; }

        [MappingInfo(ColumnName = "ImageDescription")]
        public string ImageDescription { get; set; }

        
        public string ContentType { get; set; }

        public string VisitorLogImage { get; set; }
    }
}
