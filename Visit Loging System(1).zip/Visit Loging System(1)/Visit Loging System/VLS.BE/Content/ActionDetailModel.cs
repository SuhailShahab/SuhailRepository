﻿using BE.Common;
using BE.Lookups;
using BE.RamzanBazars;
using System;
using System.Collections.Generic;

namespace BE.Content
{
    public class ActionDetailModel : BaseModel
    {
        [MappingInfo(ColumnName = "VisitorLogID")]
        public int VisitorLogID { get; set; }

        [MappingInfo(ColumnName = "TaskID")]
        public int TaskID { get; set; }

        [MappingInfo(ColumnName = "ProvinceName")]
        public string ProvinceName { get; set; }

        [MappingInfo(ColumnName = "DivisionName")]
        public string DivisionName { get; set; }

        [MappingInfo(ColumnName = "DistrictName")]
        public string DistrictName { get; set; }

        [MappingInfo(ColumnName = "TehsilName")]
        public string TehsilName { get; set; }

        [MappingInfo(ColumnName = "UnionCouncilName")]
        public string UnionCouncilName { get; set; }

        [MappingInfo(ColumnName = "ConstituencyName")]
        public string ConstituencyName { get; set; }

        [MappingInfo(ColumnName = "ConstituencyNAName")]
        public string ConstituencyNAName { get; set; }

        [MappingInfo(ColumnName = "DepartmentName")]
        public string DepartmentName { get; set; }

        [MappingInfo(ColumnName = "DepartmentID")]
        public int DepartmentID { get; set; }


        [MappingInfo(ColumnName = "Place")]
        public string Place { get; set; }


        [MappingInfo(ColumnName = "FeedBack")]
        public string Feedback { get; set; }

        [MappingInfo(ColumnName = "StartDate")]
        public DateTime StartDate { get; set; }

        [MappingInfo(ColumnName = "EndDate")]
        public DateTime EndDate { get; set; }

        [MappingInfo(ColumnName = "StartTime")]
        public DateTime StartTime { get; set; }

        [MappingInfo(ColumnName = "EndTime")]
        public DateTime EndTime { get; set; }

        [MappingInfo(ColumnName = "Agenda")]
        public string VisitAgenda { get; set; }

        [MappingInfo(ColumnName = "Rating")]
        public int? Rating { get; set; }

        [MappingInfo(ColumnName = "RatingName")]
        public string RatingName { get; set; }


        [MappingInfo(ColumnName = "StatusID")]
        public int StatusID { get; set; }


        [MappingInfo(ColumnName = "ActionRemarks")]
        public string ActionRemarks { get; set; }

        [MappingInfo(ColumnName = "AssignPersonName")]
        public string AssignPersonName { get; set; }

        [MappingInfo(ColumnName = "ActionPersonName")]
        public string ActionPersonName { get; set; }

        [MappingInfo(ColumnName = "AssignedDate")]
        public DateTime AssignedDate { get; set; }

        [MappingInfo(ColumnName = "DueDate")]
        public DateTime DueDate { get; set; }

        public List<ActionImageModel> Images { get; set; }
        public List<ActionImageModel> ActionImages { get; set; }

        public RamzanBazarMonitoringModel RamzanBazarModel { get; set; }
        public List<ConditionModel> Conditions { get; set; }

        #region "Education Additional Properties"

        [MappingInfo(ColumnName = "TecherAbsentPercentage")]
        public int? AbsentTecherPercentage { get; set; }

        [MappingInfo(ColumnName = "StudentAbsentPercentage")]
        public int? AbsentStudentPercentage { get; set; }

        [MappingInfo(ColumnName = "IsWashroomClean")]
        public bool WashroomCleanliness { get; set; }

        [MappingInfo(ColumnName = "GeneralCleanlines")]
        public bool GeneralCleanliness { get; set; }

        [MappingInfo(ColumnName = "DrinkWaterAvailable")]
        public bool DrinkWaterAvailable { get; set; }

        [MappingInfo(ColumnName = "ElectricityAvailable")]
        public bool ElectricityAvailable { get; set; }

        [MappingInfo(ColumnName = "SecuirtyArrangements")]
        public bool SecurityArrangementAvailable { get; set; }
        // Education Model is duplicated this Wrong
        [MappingInfo(ColumnName = "IsBoundaryWallIntact")]
        public bool? IsBoundaryWallIntact { get; set; }

        #endregion

        #region "Health Additional Properties"

        [MappingInfo(ColumnName = "HospitalType")]
        public string HospitalType { get; set; }

        [MappingInfo(ColumnName = "HospitalCleanliness")]
        public bool HospitalCleanliness { get; set; }

        public List<DoctorPostModel> Doctors { get; set; }
        public List<DoctorPostModel> DoctorPosts { get; set; }
        public List<HospitalEquipmentModel> HospitalEquipments { get; set; }
        public List<MedicineTypeModel> MedicineTypes { get; set; }

        #endregion


        #region "Constructors"

        public ActionDetailModel()
        {

        }

        public ActionDetailModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }



    public class ActionImageModel
    {

        [MappingInfo(ColumnName = "ImageID", IdentitySpecification = true)]
        public int ImageID { get; set; }

        [MappingInfo(ColumnName = "ImageTitle")]
        public string ImageTitle { get; set; }

        [MappingInfo(ColumnName = "ImageDescription")]
        public string ImageDescription { get; set; }

        [MappingInfo(ColumnName = "VisitedDate", Transient = true)]
        public DateTime? VisitedDate { get; set; }
        [MappingInfo(ColumnName = "VistedDepartment", Transient = true)]
        public string VistedDepartmentName { get; set; }
        [MappingInfo(ColumnName = "Place", Transient = true)]
        public string Place { get; set; }
        [MappingInfo(ColumnName = "VisitedBy", Transient = true)]
        public string VisitedBy { get; set; }

        public string VisitorLogImage { get; set; }
        public string VisitorLogRptImage { get; set; }
    }

    public class ActionImageModelView : BaseModel
    {
        public List<ActionImageModel> ActionImageModel { get; set; }
    }


}
