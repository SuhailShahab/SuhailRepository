﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BaseModel
    {
        [MappingInfo(ColumnName = "VersionNo")]
        public int? VersionNo { get; set; }

        [MappingInfo(ColumnName = "CreatedBy")]
        public int? CreatedBy { get; set; }

        [MappingInfo(ColumnName = "CreatedDate")]
        public DateTime? CreatedDate { get; set; }

        [MappingInfo(ColumnName = "ModifiedDate")]
        public DateTime? ModifiedDate { get; set; }

        [MappingInfo(ColumnName = "ModifiedBy")]
        public int? ModifiedBy { get; set; }

        [MappingInfo(ColumnName = "IsActive")]
        public bool? Status { get; set; }


        [MappingInfo(ColumnName = "IsVisitLog")]
        public bool? IsVisitLog { get; set; }

        public string Notification { get; set; }
        public bool? IsEdit { get; set; }

        public string DashboardTitle { get; set; }

        public string UserDesignation { get; set; }
        public string UserDepartment { get; set; }
        public bool IsActionTaken { get; set; }
        public bool? IsAllowedToEdit { get; set; }



        //public bool IsEdit { get; set; }
        //public string Author { get; set; }
        //public DateTime Created { get; set; }
        //public string Editor { get; set; }
        //public DateTime Modified { get; set; }
        //public string Notification { get; set; }
      


    }
}
