﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Reports
{
    public class SecretaryVisitingLogModel
    {
        public string Department { get; set; }
        public int UserID { get; set; }
        public string EmployeeName { get; set; }
        public string Designation { get; set; }
        public DateTime VisitDate { get; set; }
    }
}
