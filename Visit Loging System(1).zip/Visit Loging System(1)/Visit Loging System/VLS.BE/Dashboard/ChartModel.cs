﻿using System;
using System.Text;
using BE.Dashboard;
using System.Collections.Generic;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <28-03-2016 03:15:58PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.BE.Dashboard
{
    public class ChartModel
    {
        public string Title { get; set; }
        public int Value { get; set; }
        public int Value2 { get; set; }
        public int Value3 { get; set; }
        public double Lang { get; set; }
        public double Lat { get; set; }
        public string Notification { get; set; }
    }

    public class ChartModelView
    {
        public List<ChartModel> ChartModel { get; set; }
        public string Notification { get; set; }

        public ChartModelView() { }
        public ChartModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
