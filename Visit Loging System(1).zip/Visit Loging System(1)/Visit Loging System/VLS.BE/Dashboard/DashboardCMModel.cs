﻿using BE.Common;
using BE.Lookups;
using System;
using System.Collections.Generic;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <31-03-2016 03:36:26PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// 001          Suhail Shahab               05-04-2016 10:41AM              inherit  baseMode
// 002          Muhammad Hammad Shahid      20-06-2016 12:24:26PM           Add DepartmentFacilities property in DashboardCMModelView, Add FacilityID property in DashboardCMModel
// =================================================================================================================================
namespace BE.Dashboard
{
    public class DashboardCMModel
    {
        public int? DistrictID { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public List<DesignationModel> Designations { get; set; }
        public int? FacilityID { get; set; }        //002
    }

    public class DashboardCMModelView : BaseModel
    { //CR:001
        public DashboardCMModel DashboardModel { get; set; }
        public List<DistrictModel> Districts { get; set; }
        public List<DistrictVisistsModel> Markers { get; set; }
        public List<DistrictVisitsCountModel> Legends { get; set; }
        public List<DistrictVisitsCountModel> Officials { get; set; }
        public List<DepartmentFacilityModel> DepartmentFacilities { get; set; }         // 002
        //public List<DesignationModel> Designations { get; set; }

        public List<DesignationVisitModel> DesignationVisits { get; set; }      // collection of designation wise vists count for side panel
        public int TotalDistrictVisitCount { get; set; }
        public int TotalDepartmentVisitCount { get; set; }
        // public int TotalDistrictVisitCount { get; set; }

        public DashboardCMModelView() { }

        public DashboardCMModelView(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class DistrictVisitsCountModel
    {
        public int DistrictID { get; set; }
        public string DistrictName { get; set; }
        public int VisitsCount { get; set; }
        public string Color { get; set; }
        public bool IsVisitLog { get; set; }
    }

    public class DesignationVisitModel
    {
        public int DesignationID { get; set; }
        public string Title { get; set; }
        public int Count { get; set; }
        public List<DistrictVisitsCountModel> Visits { get; set; }
    }

    public class DistrictVisistsModel
    {
        [MappingInfo(ColumnName = "VisitorLogID")]
        public int VisitLogID { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int DistrictID { get; set; }

        [MappingInfo(ColumnName = "DistrictName")]
        public string DistrictName { get; set; }

        [MappingInfo(ColumnName = "Department")]
        public string Department { get; set; }

        [MappingInfo(ColumnName = "Place")]
        public string Place { get; set; }

        [MappingInfo(ColumnName = "EmployeeName")]
        public string EmployeeName { get; set; }

        [MappingInfo(ColumnName = "UserDepartment")]
        public string UserDepartment { get; set; }

        [MappingInfo(ColumnName = "Designation")]
        public string Designation { get; set; }

        [MappingInfo(ColumnName = "StartDate")]
        public DateTime StartDate { get; set; }

        [MappingInfo(ColumnName = "StartTime")]
        public DateTime StartTime { get; set; }

        [MappingInfo(ColumnName = "EndDate")]
        public DateTime EndDate { get; set; }

        [MappingInfo(ColumnName = "EndTime")]
        public DateTime EndTime { get; set; }

        [MappingInfo(ColumnName = "Latitude")]
        public decimal Latitude { get; set; }

        [MappingInfo(ColumnName = "Longitude")]
        public decimal Longitude { get; set; }

        [MappingInfo(ColumnName = "Rating")]
        public string Rating { get; set; }
    }
}
