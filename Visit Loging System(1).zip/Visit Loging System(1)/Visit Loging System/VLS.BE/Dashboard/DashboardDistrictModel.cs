﻿using BE.Dashboard;
using BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <28-03-2016 03:15:58PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.BE.Dashboard
{
    public class DashboardDistrictModel
    {
        public List<DistrictModel> Districts { get; set; }
        public List<TehsilModel> Tehsils { get; set; }
        public List<UnionCouncilModel> UnionCouncils { get; set; }
        public List<ConstituencyModel> Constituencies { get; set; }
        public List<DepartmentModel> Departments { get; set; }
        public List<RatingModel> Ratings { get; set; }

        public VisitSearchModel Search { get; set; }
        public List<DashBoardModel> colVisits { get; set; }

        public int PageNo { get; set; }
        public int PageSize { get; set; }
        public string Notification { get; set; }

        #region "Constructors"

        public DashboardDistrictModel()
        { 
        }

        public DashboardDistrictModel(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class VisitSearchModel
    {
        public int TehsilID { get; set; }
        public int UnionCouncileID { get; set; }
        public int ConsitituencyID { get; set; }
        public int DepartmentID { get; set; }
        public int RateID { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
    }
}
