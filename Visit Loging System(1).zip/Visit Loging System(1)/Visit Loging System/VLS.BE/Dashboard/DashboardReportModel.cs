﻿using BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Dashboard
{



    public class DashboardReportModel
    {
        public List<DistrictLogModel> DistrictLogs { get; set; }
        public List<DepartmentLogModel> DepartmentLogs { get; set; }
    }

    public class DashboardReportModelView : DashboardReportModel
    {

        public List<DivisionModel> Divisions { get; set; }
        public List<DistrictModel> Districts { get; set; }
        public List<DepartmentModel> Departments { get; set; }
        public List<RatingModel> RatingHeader { get; set; }
        public List<DistrictCountModel> AllDistrictCounts { get; set; }

        public int? DivisionID { get; set; }
        public int? DistrictID { get; set; }
        public int? DepartmentID { get; set; }
        public string Notification { get; set; }

        public DashboardReportModelView() { }
        public DashboardReportModelView(string Notification)
        {
            this.Notification = Notification;
        }

    }

    public class DistrictLogModel
    {
        public string Division { get; set; }
        public int DivisionID { get; set; }
        public string District { get; set; }
        public int DistrictID { get; set; }

        public int TotalVisits { get; set; }
        public List<RatingModel> Rating { get; set; }
    }

    public class DepartmentLogModel
    {
        public string Department { get; set; }
        public int DepartmentID { get; set; }

        public int TotalVisits { get; set; }
        public List<RatingModel> Rating { get; set; }
    }

    public class DistrictCountModel
    {
        public int DivisionID { get; set; }
        public int DistrictCount { get; set; }
    }

    public class LogDetail : BaseModel
    {
        public string Place { get; set; }
        public string Department { get; set; }
        public string Rated { get; set; }
        public int RateID { get; set; }
        public int TaskID { get; set; }
        public int VisitorLogID { get; set; }
        public DateTime StartDate { get; set; }
        public Boolean HasImage { get; set; }
        public Boolean HasActionTaken { get; set; }
        //public int DepartmentID { get; set; }

        public LogDetail()
        {

        }

        public LogDetail(string Notification)
        {
            this.Notification = Notification;
        }
    }

    public class LogDetailView
    {
        public List<LogDetail> LogDetail { get; set; }
        public string Notification { get; set; }

        public LogDetailView()
        {

        }
        public LogDetailView(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
