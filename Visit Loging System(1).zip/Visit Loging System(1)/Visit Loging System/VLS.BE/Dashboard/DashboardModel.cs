﻿using BE.Common;
using BE.Lookups;
using System;
using System.Collections.Generic;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <25-Mar-2016 02:50:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BE.Dashboard
{
    public class DashBoardModel : BaseModel
    {
        [MappingInfo(ColumnName = "VisitorLogID")]
        public int VisitorLogID { get; set; }

        [MappingInfo(ColumnName = "TaskID")]
        public int TaskID { get; set; }

        [MappingInfo(ColumnName = "ProvinceID")]
        public int ProvinceID { get; set; }

        [MappingInfo(ColumnName = "DistrictID")]
        public int DistrictID { get; set; }

        [MappingInfo(ColumnName = "DivisionID")]
        public int DivisionID { get; set; }

        [MappingInfo(ColumnName = "TehsilID")]
        public int TehsilID { get; set; }

        [MappingInfo(ColumnName = "UnionCouncilID")]
        public int UnionCouncilID { get; set; }

        [MappingInfo(ColumnName = "ConstituencyID")]
        public int ConstituencyID { get; set; }

        [MappingInfo(ColumnName = "DepartmentID")]
        public int DepartmentID { get; set; }

        [MappingInfo(ColumnName = "DistrictName")]
        public string DistrictName { get; set; }

        [MappingInfo(ColumnName = "TehsilName")]
        public string TehsilName { get; set; }

        [MappingInfo(ColumnName = "ProvinceName")]
        public string ProvinceName { get; set; }

        [MappingInfo(ColumnName = "DivisionName")]
        public string DivisionName { get; set; }

        [MappingInfo(ColumnName = "DepartmentName")]
        public string DepartmentName { get; set; }

        [MappingInfo(ColumnName = "UnionCouncilName")]
        public string UnionCouncilName { get; set; }

        [MappingInfo(ColumnName = "DesignationName")]
        public string DesignationName { get; set; }

        [MappingInfo(ColumnName = "Place")]
        public string Place { get; set; }

        [MappingInfo(ColumnName = "StartDate")]
        public DateTime StartDate { get; set; }

        [MappingInfo(ColumnName = "EndDate")]
        public DateTime EndDate { get; set; }

        [MappingInfo(ColumnName = "StartTime")]
        public DateTime StartTime { get; set; }

        [MappingInfo(ColumnName = "EndTime")]
        public DateTime EndTime { get; set; }

        [MappingInfo(ColumnName = "Agenda")]
        public string VisitAgenda { get; set; }

        [MappingInfo(ColumnName = "Rating")]
        public int? Rating { get; set; }

        [MappingInfo(ColumnName = "RatingName")]
        public string RatingName { get; set; }

        [MappingInfo(ColumnName = "AssignPersonName")]
        public string AssignPersonName { get; set; }

        [MappingInfo(ColumnName = "AssignedDate")]
        public DateTime AssignedDate { get; set; }

        [MappingInfo(ColumnName = "DueDate")]
        public DateTime DueDate { get; set; }

        [MappingInfo(ColumnName = "ActionTaken")]
        public bool ActionTaken { get; set; }

        [MappingInfo(ColumnName = "HasImage")]
        public bool HasImage { get; set; }

        [MappingInfo(ColumnName = "RowNumber")]
        public Int64 RowNumber { get; set; }
    }

    public class DashBoardModelView : CommonListModel
    {
        public List<DashBoardModel> Tasks { get; set; }
        public List<DesignationModel> Designations { get; set; }
        public List<DashBoardModel> TasksSecretary { get; set; }
        public List<DashBoardModel> TasksDCO { get; set; }
        public List<DashBoardModel> TasksCommissioner { get; set; }
        //public string Notification { get; set; }
        public int RESULT_COUNT { get; set; }

        public int DesignationID { get; set; }
        public int UserDesignationID { get; set; }
        //public int AssignCount { get; set; }
        //public int VisitedCount { get; set; }
        //public int OverDueCount { get; set; }

        //public int ConcernDepartment { get; set; }
        //public int ConcernDistrictAdmin { get; set; }
        //public int ConcernDPORPO { get; set; }

        public int PageSize { get; set; }
        public int PageNo { get; set; }

        public List<StatesCountModel> ActionCounts { get; set; }
        public List<StatesCountModel> Counts { get; set; }
        public List<RatingCountModel> RatingCounts { get; set; }

        #region "Constructors"

        public DashBoardModelView()
        {

        }

        public DashBoardModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class StatesCountModel
    {
        public int Count { get; set; }
        public string Title { get; set; }
        public string MethodName { get; set; }
    }

    public class RatingCountModel
    {
        public int RateID { get; set; }
        public int Count { get; set; }
        public string Title { get; set; }
        public string Category { get; set; }
        public int Sort { get; set; }
    }

}
