﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Sabeeh Goheer>
    // Create date: <20/04/2016 1:04:04 AM>
    // =================================================================================================================================
    // ================================================ News Model Class======================================================
    // =================================================================================================================================



    [Serializable]
    public class SecretaryContactModel : BaseModel
    {

        [MappingInfo(ColumnName = "UserID", IdentitySpecification = true)]
        public int? ID { get; set; }
         
        [MappingInfo(ColumnName = "EmployeeName")]
        public string Name { get; set; }

        [MappingInfo(ColumnName = "Department")]
        public string Department { get; set; }


        [MappingInfo(ColumnName = "CellNumber")]
        public string CellNumber { get; set; }

        public bool Checked { get; set; }

        public SecretaryContactModel()
        {
        }
    }
    public class SecretaryContactModelView
    {
        public List<SecretaryContactModel> Contacts { get; set; }

        public string SMS { get; set; }

    }



}