﻿using BE.Lookups;
using System;
using System.Collections.Generic;

namespace BE.Dashboard
{
    public class DashboardRatingModel:BaseModel
    {
        public List<DistrictVisitLogModel> DistrictLogs { get; set; }
        public List<DepartmentVisitLogModel> DepartmentLogs { get; set; }
        public List<DesignationVisitLogModel> DesignationLogs { get; set; }
    }

    public class DashboardRatingModelView : DashboardRatingModel
    {
        public List<DivisionModel> Divisions { get; set; }
        public List<DistrictModel> Districts { get; set; }
        public List<DepartmentModel> Departments { get; set; }
        public List<DesignationModel> Designations { get; set; }
        public List<RatingModel> RatingHeader { get; set; }
        public List<DepartmentFacilityModel> DepartmentFacilities { get; set; }
        

        public int? DivisionID { get; set; }
        public int? DistrictID { get; set; }
        public int? DepartmentID { get; set; }
        public int? FacilityID { get; set; }


        #region "Constructors"

        public DashboardRatingModelView()
        {
 
        }

        public DashboardRatingModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }

    public class DistrictVisitLogModel
    {
        public int VisitorLogID { get; set; }
        public int DivisionID { get; set; }
        public string Division { get; set; }
        public int DistrictID { get; set; }
        public string District { get; set; }
        public int VeryPoor { get; set; }
        public int Poor { get; set; }
        public int Unsatisfactory { get; set; }
        public int Average { get; set; }
        public int Satisfactory { get; set; }
        public int Good { get; set; }
        public int Excellent { get; set; }
        public int TotalVisits { get; set; }
    }

    public class DepartmentVisitLogModel
    {
        public int DepartmentID { get; set; }
        public string Department { get; set; }
        public int VeryPoor { get; set; }
        public int Poor { get; set; }
        public int Unsatisfactory { get; set; }
        public int Average { get; set; }
        public int Satisfactory { get; set; }
        public int Good { get; set; }
        public int Excellent { get; set; }
        public int TotalVisits { get; set; }
    }

    public class DCOVisitLogModel
    {
        public int UserID { get; set; }
        public int DesignationID { get; set; }
        public string EmployeeName { get; set; }
        public int VeryPoor { get; set; }
        public int Poor { get; set; }
        public int Unsatisfactory { get; set; }
        public int Average { get; set; }
        public int Satisfactory { get; set; }
        public int Good { get; set; }
        public int Excellent { get; set; }
        public int TotalVisits { get; set; }
    }


    public class DesignationVisitLogModel
    {
        public int UserID { get; set; }
        public int DesignationID { get; set; }
        public string EmployeeName { get; set; }
        public int VeryPoor { get; set; }
        public int Poor { get; set; }
        public int Unsatisfactory { get; set; }
        public int Average { get; set; }
        public int Satisfactory { get; set; }
        public int Good { get; set; }
        public int Excellent { get; set; }
        public int TotalVisits { get; set; }
    }

    public class LogVisitDetail
    {
        public string Place { get; set; }
        public string Department { get; set; }
        public string Rated { get; set; }
        public int RateID { get; set; }
        public int TaskID { get; set; }
        public DateTime StartDate {get; set;}
    }
}
