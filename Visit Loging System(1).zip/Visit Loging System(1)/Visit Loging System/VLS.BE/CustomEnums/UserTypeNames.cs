﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum UserTypeNames : int
    {
        None = 0,
        Admin = 1,
        Department = 2,
        RegisteredUser = 3,
        CSR = 4,
        CompetentCreatedByity = 5,
    }
}
