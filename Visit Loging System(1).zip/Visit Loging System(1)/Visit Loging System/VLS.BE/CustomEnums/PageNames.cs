﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{

    public class ReportNames
    {
        public const string ConstituencyReport = "RptConstituency";
        public const string ADPPerformaReport = "RptADPPerforma";
        public const string ADPPerforma2Report = "RptADPPerforma2";

        public const string ActionTakenReport = "RptActionTakenReport";
        public const string ActionTakenImageReport = "RptActionTakenReportWithImage";
        public const string RptVisitBySecretary = "RptVisitBySecretary";
        public const string RptVisitByOtherSecretary = "RptVisitByOtherSecretary";
        public const string RptVisitActionByDistrict = "RptVisitActionByDistrict";
        public const string RptVisitActionByDepartment = "RptVisitActionByDepartment";
        public const string RptRamzanBazarMonitoring = "RptRamzanBazarMonitoring";


        public const string RptDepartmentVisitingLogs = "RptDepartmentVisitingLogs";
        public const string RptRamzanBazarVisitLog = "RptRamzanBazarVisitLog";
        public const string RptDistrictVisitsLogByOfficialsMatrix = "RptDistrictVisitsLogByOfficialsMatrix";
        public const string RptOfficialVisitLogByDistrictMatrix = "RptOfficialVisitLogByDistrictMatrix";
        public const string RptOfficialsVisitsObservationByDistrict = "RptOfficialsVisitsObservationByDistrict";
        public const string RptOfficialsVisitsLogByDepartmentMatrix = "RptOfficialsVisitsLogByDepartmentMatrix";
        public const string RptActionTakenPerform = "RptActionTakenPerform";
    }

    public class PageNames
    {
        /// <summary>
        /// Value is MenuName for Table Feature table
        /// Value is StaticName for Table AppObjects
        /// Note Very Important
        ///Use values of MenuName for Feature table 
        ///Use values are StaticName for AppObjects
        /// </summary>
        /// 
        public const string ActionTakenPerformReport = "ActionTakenPerformReport";
       public const string ApplicationFeature = "ApplicationFeature";
      
      
      
       public const string Users = "user";
       public const string EvidenceInformation = "EvidenceSubmision";
       public const string EvidenceInformation1 = "EvidenceSubmision1";
       public const string Home = "index";
     
       public const string GeneralDistrict = "GeneralDistrict";
       public const string SubmittedAgency = "SubmittedAgency";
       public const string PoliceStation = "PoliceStation";
       public const string AdminDashboard = "AdminDashboard";
       public const string Login = "Login";
       public const string ConstituencyReport = "ConstituencyReport";
       public const string ADPPerformaReport = "ADPPerformaReport";
       public const string ADPPerforma2Report = "ADPPerforma2Report";
       public const string ADPPerforma3Report = "ADPPerforma3Report";      
       public const string AssigneeRecord = "AssigneeRecord";

       public const string VisitActionByDistrictReport = "VisitActionByDistrictReport";
       public const string VisitActionByDepartmentReport = "VisitActionByDepartmentReport";
       public const string SecretaryVisitorLogReport = "SecretaryVisitorLogReport";
       public const string SecretaryVisitorObservationByDistrict = "SecretaryVisitorObservationByDistrict";
       public const string OtherSecretaryVisitorLogReport = "OtherSecretaryVisitorLogReport";
       public const string ActionTakenPrintReport = "ActionTakenPrintReport";
       public const string HospitalEquipment = "HospitalEquipment";
       public const string HospitalType = "HospitalType";
       public const string SiteInfo = "SiteInfo";
       public const string RamzanBazarVisitLog = "RamzanBazarVisitLog";
        
       public const string DisplayRamzanBazarMonitoring = "DisplayRamzanBazarMonitoring";
        
        



       #region "Lookups"

       public const string Provinces = "Provinces";
       public const string Division = "Division";
       public const string SubSector = "SubSector";
       public const string District = "District";
       public const string Tehsil = "Tehsil";
       public const string Constituency = "Constituency";
       
       public const string Department = "Department";
       public const string Rating = "Rating";
       public const string City = "City";
       public const string News = "News";
       public const string NewsDetail = "NewsDetail";
       public const string Designations = "Designations";
       public const string ErrorLog = "ErrorLogs";

       #endregion

       #region "Rights Manager"
       public const string GroupPermission = "GroupPermission";
       public const string ApplicationFeatures = "ApplicationFeatures";
       public const string ApplicationObjects = "ApplicationObjects";
       
       public const string Group = "Group";
       public const string User = "User";
       #endregion

       #region "Dashboard"

       public const string Dashboard = "Dashboard";
       public const string DashboardObservation = "DashboardObservation";
       public const string DashboardDistrict = "DashboardDistrict";
       public const string DashboardCM = "DashboardCM";
       public const string DashboardReport = "DashboardReport";
       public const string VisitLog = "VisitLog";
       public const string VisitObservation = "VisitObservation";
       public const string DashboardLogs = "DashboardLogs";
        

        

       #endregion

       public const string Index = "Index";
       public const string ActionDetail = "ActionDetail";

       #region "Reports"

       public const string DepartmentVisitingLogs = "Department Visiting Logs";
       public const string AdministrativeSecretariesVisitsLog = "Administrative Secretaries Visits Log";
       public const string OfficialsVisitsObservationByDistrict = "OfficialsVisitsObservationByDistrict";
       public const string OfficialsVisitsLogByDepartment = "OfficialsVisitsLogByDepartment";
       public const string ActionTakenReprot = "RptActionTakenReprot";
       public const string RPTVisitBySecretary = "RPTVisitBySecretary";
       public const string RPTVisitByOtherSecretary = "RPTVisitByOtherSecretary";
       public const string RptVisitActionByDistrict = "RptVisitActionByDistrict";
       public const string RptVisitActionByDepartment = "RptVisitActionByDepartment";




        #endregion

        #region vls
      
        public const string Download = "Download";

       #endregion
       
    }
}

