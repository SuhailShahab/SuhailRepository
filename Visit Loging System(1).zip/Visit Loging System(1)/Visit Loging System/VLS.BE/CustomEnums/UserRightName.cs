﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum UserRightName : int
    {
        FileAdd = 0,
        FileView = 1,
        FileRemove = 2,
        FileDownload = 3,
        ActionTaken=4,
        IsAllowedToEditRecord= 5,

    }
}
