﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum NotificationCode:byte
    {
        success =1,
        delete_success=2,
        error=3,
        info=4,
        warning=5,

    }
}
