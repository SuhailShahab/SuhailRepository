﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
   public  class CutomMessage
    {
       
       public const  string InvalidUserRights = "You have not rights on this page.Please contact with administrator.";
       public const string InvalidRegisterUser = "User is not registered.Please contact with administrator.";
       public const string InvalidLogin = "Invalid password or login.";
       public const string InvalidUser = "You have enter invalid user";
       public const string SavedSuccessfully = "Your record has been saved successfully";
       public const string DocumentDeleteSuccessfully = "Document has been deleted successfully";
       public const string UserDistrictMissing = "User District is missing.";
       public const string deleteSuccessfully = "Record delete successfully.";
       public const string blockSuccessfully = "Your record has been blocked successfully";
       public const string NotAuthorizedToPage = "You are not Authorized to access this page.";
       public const string NotAuthorizedToViewRecord = "You are not Authorized to view or edit this record.";


    }
}
