﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum TableName : byte
    {
        tblUser=1,
        tblDepartment = 2,
        tblAppFeatures = 3,
        tblDistrict = 4,
        tblDivision = 5,
        tblProvince=6,
        tblGroups = 7,
        tblGroupRights = 8,
        tblAppObjects = 9,
        tblConstituency  = 10,
        tblUserTehsil =11,
        tblDesignation= 12,
        tblUserDesignation = 13,
        tblCity = 14,
        tblUserDistrict = 15,
        tblUnionCouncil = 16,
        tblDashboardGroupMenu =17,
        tblPermitUserMgtMenu =18,
        tblRating = 19,
        tblTehsil = 20,
        tblNews = 21,
        tblHospitalType = 22,
        tblMedicineType = 23,
        tblDoctorPosts = 24,
        tblHospitalEquipments = 25,
        tblNAConstituency = 26,
        tblSiteInfo  = 27 ,
        tblUserDepartment=28,
        tblRamzanMonitoring,
        tblRamzanMonitoringLineItem,
        tblDepartmentFacility = 31,
        tblUserDepartmentFacility = 32,
        tblVisitorLog =33,
        tblVisitLogEducation=34,
        tblVisitLogDoctorAbsence=35,
        tblVisitHospitalEquipment= 36,
        tblVisitorLogImage=37,
        tblUserDivision = 38,
    }
}

