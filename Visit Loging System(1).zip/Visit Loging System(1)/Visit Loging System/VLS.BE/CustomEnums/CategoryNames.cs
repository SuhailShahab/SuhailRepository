﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum CategoryNames : int
    {
        None = 0,
        SubsidizedItem = 1,
        WholeSaleItem = 2,
    }
}
