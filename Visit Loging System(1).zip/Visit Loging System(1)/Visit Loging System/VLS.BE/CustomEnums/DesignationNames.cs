﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum DesignationNames: int
    {
        CMChiefMinisterPunjab = 6,
        CMChiefSecretaryPunjab = 9,
        NewsEditor = 8,
        Secretary = 2
    }
}
