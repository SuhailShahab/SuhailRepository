﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.CustomEnums
{
    public enum ColumnName : byte
    {
        Title = 1,
        UserName = 2,
        CityID = 3,
        DepartmentID = 4,
        DistrictID = 5,
        ProvinceID = 6,
        CaseNo = 7,
        DivisionID = 8,
        Code = 9,
        GroupID = 10,
        MenuName = 11,
        AppFeatureID = 12,
        StaticName = 13,
        AppObjectID = 14,
        SubmittedAgencyID  = 15,
        ID=16,
        PoliceStationID = 17,
        menuLocation = 18,
        ConstituencyID = 19,
        BeneficiariesID= 20,
        DesignationID=21,
        TehsilID=22,
        UnionCouncilID=23,
        Name = 24,
        RateID = 25,
        NewsID = 26,
        HospitalTypeID = 27,
        MedicinesTypeID = 28,
        DoctorPostID = 29,
        EquipmentID = 30,
        NAConstituencyID = 31,
        InfoID = 32,
        FacilityID = 33,

    }
}
