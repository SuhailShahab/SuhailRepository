﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VLS.BE.CustomEnums
{
    public enum MenuTypeNames : int
    {
        MainMenu = 1,
        OperationalMenu = 2,
    }
}
