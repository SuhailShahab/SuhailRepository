﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <25-04-2016 12:23:09 PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// =================================================================================================================================
namespace BE
{
    public class SMSSendModel
    {
        public string PhoneNo { get; set; }
        public string SMSMessage { get; set; }

        #region "Constructors"

        public SMSSendModel()
        {

        }

        public SMSSendModel(string ContactNo, string Message)
        {
            this.PhoneNo = ContactNo;
            this.SMSMessage = Message;
        }

        #endregion
    }
}
