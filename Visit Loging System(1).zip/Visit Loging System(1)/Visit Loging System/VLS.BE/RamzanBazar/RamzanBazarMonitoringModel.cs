﻿using BE.Common;
using BE.RamzanBazar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.RamzanBazars
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <08-06-2016 11:17>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblRamzanBazarMonitoring", Identifier = "MonitoringID")]
    [Serializable]
    public class RamzanBazarMonitoringModel : BaseModel
    {
        [MappingInfo(ColumnName = "MonitoringID", IdentitySpecification = true)]
        public int ID { get; set; }

        #region 1-Atta Sale Point
       
        [MappingInfo(ColumnName = "AttaQualityAvailablity")]
        public bool? AttaQualityAvailablity { get; set; }
        [MappingInfo(ColumnName = "AttaGreenColorBags")]
        public bool? AttaGreenColorBags { get; set; }
        [MappingInfo(ColumnName = "AttaMonitoringArrangements")]
        public bool? MonitoringArrangements { get; set; }
        [MappingInfo(ColumnName = "AttaQueueManagement")]
        public bool? QueueManagement { get; set; }
        //new
        [MappingInfo(ColumnName = "AttaRate")]
        public bool? AttaRate { get; set; }

        #endregion

        #region 2- Sugar Sale Point

        [MappingInfo(ColumnName = "SugarAvailablity")]
        public bool? SugarAvailablity { get; set; }
        [MappingInfo(ColumnName = "SugarRate")]
        public bool? SugarRate { get; set; }
        [MappingInfo(ColumnName = "SugarPrintedBags")]
        public bool? SugarPrintedBags { get; set; }
        [MappingInfo(ColumnName = "SugarQueueManagement")]
        public bool? SugarQueueManagement { get; set; }

        #endregion

        #region 3-Ghee / Oile Sale Point

        [MappingInfo(ColumnName = "OilGheeAvailablity")]
        public bool? OilGheeAvailablity { get; set; }
        [MappingInfo(ColumnName = "OilGheeDiscount")]
        public bool? OilGheeDiscount { get; set; }
        [MappingInfo(ColumnName = "OilGheeCategory")]
        public bool? OilGheeCategory { get; set; }        

        #endregion


        #region 4-Poultry Products Sale Point

        [MappingInfo(ColumnName = "PoultryChickenMeatAvailablity")]
        public bool? PoultryChickenMeatAvailablity { get; set; }
        [MappingInfo(ColumnName = "PoultryChickenEggsAvailablity")]
        public bool? PoultryChickenEggsAvailablity { get; set; }
        [MappingInfo(ColumnName = "PoultryChickenRateDiscount")]
        public bool? PoultryChickenRateDiscount { get; set; }
        [MappingInfo(ColumnName = "PoultryQueueManagement")]
        public bool? PoultryQueueManagement { get; set; }

        //new
        [MappingInfo(ColumnName = "PoultryEggRateDiscount")]
        public bool? PoultryEggRateDiscount { get; set; }

        
        #endregion


        #region 5- Other Ramzar Items

        [MappingInfo(ColumnName = "AgricultureFairPriceShop")]
        public bool? AgricultureFairPriceShop { get; set; }
        [MappingInfo(ColumnName = "DisplayWholesalePrice")]
        public bool? DisplayWholesalePrice { get; set; }

        public List<RamzanBazarMonitoringItemModel> SubsidizedItemsRates { get; set; }
        public List<RamzanBazarMonitoringItemModel> WholeSaleItemsRates { get; set; }
       
        #endregion

        #region 6 to 7 Other Ramzar Items

        [MappingInfo(ColumnName = "ItemAvailablityNotifiedRates")]
        public bool? ItemAvailablityNotifiedRates { get; set; }
        [MappingInfo(ColumnName = "CheckingWeightAndMeasures")]
        public bool? CheckingWeightAndMeasures { get; set; }

        #endregion

        #region -8 Tentage

        [MappingInfo(ColumnName = "TentageAvailability")]
        public bool? TentageAvailability { get; set; }
        [MappingInfo(ColumnName = "TentageCondition")]
        public int? TentageCondition { get; set; }
        [MappingInfo(ColumnName = "TentageStatusID")]
        public int? TentageStatusID { get; set; }

        #endregion

        #region -9 Facilitation

        [MappingInfo(ColumnName = "FacilitaionSeatingArrangement")]
        public bool? FacilitaionSeatingArrangement { get; set; }
        [MappingInfo(ColumnName = "FacilitaionOfFans")]
        public bool? FacilitaionOfFans { get; set; }
        [MappingInfo(ColumnName = "FacilitaionOfToilets")]
        public bool? FacilitaionOfToilets { get; set; }
        [MappingInfo(ColumnName = "FacilitaionOfFirstAidService")]
        public bool? FacilitaionOfFirstAidService { get; set; }
        [MappingInfo(ColumnName = "FacilitaionOfGuideTags")]
        public bool? FacilitaionOfGuideTags { get; set; }

        //new
        [MappingInfo(ColumnName = "LoudspeakerArrangements")]
        public bool? LoudspeakerArrangements { get; set; }
        //[MappingInfo(ColumnName = "FacilitaionLoudSpeaker")]
        //public bool? FacilitaionLoudSpeaker { get; set; }
        

        #endregion

        #region -10 Availability Of Staff

        [MappingInfo(ColumnName = "RevenueStaff")]
        public bool? RevenueStaff { get; set; }
        [MappingInfo(ColumnName = "AgriculturStaff")]
        public bool? AgriculturStaff { get; set; }
        [MappingInfo(ColumnName = "HealthStaff")]
        public bool? HealthStaff { get; set; }
        [MappingInfo(ColumnName = "LiveStockStaff")]
        public bool? LiveStockStaff { get; set; }
        [MappingInfo(ColumnName = "WeightAndMeasureStaff")]
        public bool? WeightAndMeasureStaff { get; set; }

        //new
        [MappingInfo(ColumnName = "AvailabilityFoodAuthority")]
        public bool? AvailabilityFoodAuthority { get; set; }
        [MappingInfo(ColumnName = "AvailabilityTMA")]
        public bool? AvailabilityTMA { get; set; }
        [MappingInfo(ColumnName = "AvailabilityCivilDefence")]
        public bool? AvailabilityCivilDefence { get; set; }
        #endregion


        #region -11 Other Ramzan Items

        [MappingInfo(ColumnName = "DisplayRateList")]
        public bool? DisplayRateList { get; set; }      

        #endregion

        #region -12 Cleanliness Arrangements

        [MappingInfo(ColumnName = "CleanlinessSanitaryStaff")]
        public bool? CleanlinessSanitaryStaff { get; set; }
        [MappingInfo(ColumnName = "CleanlinessCondition")]
        public int? CleanlinessCondition { get; set; }
        [MappingInfo(ColumnName = "CleanlinessWASA")]
        public bool? CleanlinessWASA { get; set; }
       
        #endregion

        #region -13 Compliant System

        [MappingInfo(ColumnName = "CompliantBanner")]
        public bool? CompliantBanner { get; set; }
        [MappingInfo(ColumnName = "CompliantRegister")]
        public bool? CompliantRegister { get; set; }      

        #endregion

        #region -14 Security and Parking arrangement

        [MappingInfo(ColumnName = "SecurityCondition")]
        public int? SecurityCondition { get; set; }
        [MappingInfo(ColumnName = "SecurityPersonnel")]
        public bool? SecurityPersonnel { get; set; }
        [MappingInfo(ColumnName = "SecurityMetalDetectors")]
        public bool? SecurityMetalDetectors { get; set; }
        [MappingInfo(ColumnName = "SecurityTrafficControlStaff")]
        public bool? SecurityTrafficControlStaff { get; set; }

        //new
        [MappingInfo(ColumnName = "SecurityofWomen")]
        public bool? SecurityofWomen { get; set; }
        [MappingInfo(ColumnName = "AdequateParkingArrangements")]
        public bool? AdequateParkingArrangements { get; set; }
        #endregion


        #region -15 to 24 other items

        [MappingInfo(ColumnName = "AgricultureMarketingStaff")]
        public bool? AgricultureMarketingStaff { get; set; }
        [MappingInfo(ColumnName = "VideoLinks")]
        public bool? VideoLinks { get; set; }
        [MappingInfo(ColumnName = "DCOsVisitersRamzanBaar")]
        public bool? DCOsVisitersRamzanBaar { get; set; }
        [MappingInfo(ColumnName = "ParlianmentariansVisiters")]
        public bool? ParlianmentariansVisiters { get; set; }
        [MappingInfo(ColumnName = "DistrictCommiteeMembersVisisters")]
        public bool? DistrictCommiteeMembersVisisters { get; set; }
        [MappingInfo(ColumnName = "UtilityStoresCorporation")]
        public bool? UtilityStoresCorporation { get; set; }
        [MappingInfo(ColumnName = "AnyOter")]
        public string AnyOter { get; set; }
        #endregion

       

    }
     // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <08-06-2016 11:17>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblRamzanBazarMonitoringItem", Identifier = "MonitoringItemID")]
    [Serializable]
    public class RamzanBazarMonitoringItemModel : BaseModel
    {
        [MappingInfo(ColumnName = "MonitoringItemID")]
        public int? ID { get; set; }
        
        [MappingInfo(ColumnName = "ItemID")]
        public int? ItemID { get; set; }

        [MappingInfo(ColumnName = "CategoryID")]
        public int? CategoryID { get; set; }

        [MappingInfo(ColumnName = "MonitoringID")]
        public int? MonitoringID { get; set; }       

        [MappingInfo(ColumnName = "Availabitliy")]
        public bool? Availabitliy { get; set; }

        [MappingInfo(ColumnName = "ConditionID")]
        public int? ConditionID { get; set; }

        [MappingInfo(ColumnName = "Rates")]
        public decimal? Rates { get; set; }

        [MappingInfo(ColumnName = "Remarks")]
        public string Remarks { get; set; }

        [MappingInfo(ColumnName = "ItemTitle",Transient=true)]
        public string ItemTitle { get; set; }

    }

    
}
