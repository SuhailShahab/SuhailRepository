﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.RamzanBazars
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <08-06-2016 11:17>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblItems", Identifier = "ItemID")]
    [Serializable]
    public class ItemsModel : BaseModel
    {
        [MappingInfo(ColumnName = "ItemID")]
        public int? ID { get; set; }
      
        [MappingInfo(ColumnName = "CategoryID")]
        public int? CategoryID { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
    }
}
