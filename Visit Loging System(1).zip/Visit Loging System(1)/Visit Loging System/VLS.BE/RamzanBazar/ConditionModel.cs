﻿using BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.RamzanBazars
{
    
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <08-06-2016 11:17>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblItemCondition", Identifier = "ItemConditionID")]
    [Serializable]
    public class ConditionModel : BaseModel
    {
        [MappingInfo(ColumnName = "ItemConditionID")]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
    }
}
