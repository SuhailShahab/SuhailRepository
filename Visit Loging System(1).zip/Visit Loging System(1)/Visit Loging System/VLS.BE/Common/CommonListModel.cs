﻿
using BE.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE.Common
{
    public class CommonListModel : BaseModel
    {
        //public List<SectorModel> Sectors { get; set; }
        //public List<SubSectorModel> SubSectors { get; set; }
        public List<DistrictModel> Districts { get; set; }
        public List<TehsilModel> Tehsils { get; set; }
       
    }

    public class LookupModel
    {
        public int? SectorID { get; set; }
        public int? SubSectorID { get; set; }
        public int? DistrictID { get; set; }
        public int? TehsilID { get; set; }
    }
}
