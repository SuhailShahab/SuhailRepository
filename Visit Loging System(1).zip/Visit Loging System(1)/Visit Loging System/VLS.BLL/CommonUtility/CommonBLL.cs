﻿
using BE;
using BE.Common;
using BE.CustomEnums;
using BE.LogManager;
using BE.Lookups;
using DAL.Generic;
using DAL.RightsManager;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Reflection;
using System.Text;


// =================================================================================================================================
// Create by:	<>
// Create date: <>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By             Modified Date/Time      Desription

// =================================================================================================================================
namespace BLL.CommonUtility
{
    public class CommonBLL
    {
        private string districtCode = string.Empty;

        #region "Constructors"

        public CommonBLL()
        {

        }

        #endregion

        #region "OLD Code"


        public bool IsExist(TableName tblName, ColumnName clolumnName, string value, string caluse)
        {

            return new CommonDAL().GetDuplication(tblName.ToString(), clolumnName.ToString(), value, caluse);
          
        }

        public bool IsExist(TableName tblName, string caluse)
        {

            return new CommonDAL().GetDuplicationWithCaluseOnly(tblName.ToString(), caluse);

        }

        public string GetClause1(ColumnName columnName, int id)
        {
            StringBuilder sbClause = new StringBuilder();
            sbClause.Append(columnName.ToString());
            sbClause.Append(" Not IN (");
            sbClause.Append(id);
            sbClause.Append(")");
            return sbClause.ToString();
        }

        public string GetClause(ColumnName columnName, int id)
        {
            StringBuilder sbClause = new StringBuilder();
            sbClause.Append(columnName.ToString());
            sbClause.Append(" Not IN (");
            sbClause.Append(id);
            sbClause.Append(")");
            return sbClause.ToString();
        }

        public string GetClause(Hashtable coloums, ColumnName? columnName, int? id)
        {
            StringBuilder sbClause = new StringBuilder();

            foreach (DictionaryEntry entry in coloums)
            {
                sbClause.Append(entry.Key);
                sbClause.Append(" = ");
                sbClause.Append(entry.Value.ToString());
                sbClause.Append(" AND ");
            }
            if (id.HasValue)
            {
                sbClause.Append(GetClause(columnName.Value, id.Value));
            }
            else
                sbClause.Append(" 1 = 1 ");
            return sbClause.ToString();
        }


        #endregion

        public int SaveErrorLog(ErrorLogModel erroLog)
        {
            FillErrorLogData(erroLog);
            return new CommonDAL().SaveErrorLog(erroLog);
        }
        public int AddErrorLog(ErrorLogModel erroLog)
        {
            FillErrorLogData(erroLog);
            return new CommonDAL().SaveErrorLog(erroLog);
        }
        public string AddErrorLogs(ErrorLogModel erroLog)
        {
            FillErrorLogData(erroLog);
            int id = LazyBaseSingletonDAL<CommonDAL>.Instance.SaveErrorLog(erroLog);
            return "(" + id.ToString() + "-" + DateTime.Now.Day + DateTime.Now.Month + DateTime.Now.Year + ")";
        }
        public bool SelectRecordVerification(string Table, string Column, string Value, string Clause)
        {
            return new ServicesDAL().SelectRecordVerification(Table, Column, Value, Clause);
        }

        private static void FillErrorLogData(ErrorLogModel ErrorLog)
        {


            //ErrorLog.WebMethod = WebMethod;
            if (ErrorLog.CustomException!=null)
            {
                if (ErrorLog.CustomException.Message != "") ErrorLog.Message = ErrorLog.GetaAllMessages();//ErrorLog.g //ErrorLog.CustomException.Message;
                if (ErrorLog.CustomException.StackTrace != "") ErrorLog.StackTrace = ErrorLog.CustomException.StackTrace;
                if (ErrorLog.CustomException.Source != "") ErrorLog.Source = ErrorLog.CustomException.Source;
            }
       
        }

        public bool GetUserPageAccess(int? loginID, string page, int level = 2)
        {
           try
           {
               return LazyBaseSingletonDAL<CommonDAL>.Instance.GetUserPageAccess(loginID, page, level);
              // return new CommonDAL().GetUserPageAccess(LoginID, Page, Level);
           }
            catch(Exception ex)
           {
               throw ex;
           }
            
        }

        public  string NotificationErrorMsg(string errorMsg)
        {
            return "error|" + errorMsg;
        }
        public string NotificationDeleteSuccessuly(string errorMsg)
        {
            return "delete_success|" + errorMsg;
        }

        /// <summary>
        ///  CR: 013
        /// this method use to Shwo the Error Message
        /// </summary>
        /// <param name="model">Genericl base Model</param>
        /// <param name="ex">Exception Which Need to be Show</param>
        /// <returns>return the BaseModel With Notification Prpoerty</returns>
        public  BaseModel NotificationErrorMsg(BaseModel model, string errorMsg)
        {
            if (model == null)
            {
                Type typ = model.GetType();
                model = (BaseModel)Activator.CreateInstance(typ);
            }

            model.Notification = "error|" + errorMsg;
            return model;
        }

        public  BaseModel NotificationInfo(BaseModel model, string errorMsg)
        {
            if (model == null)
            {
                Type typ = model.GetType();
                model = (BaseModel)Activator.CreateInstance(typ);
            }

            model.Notification = "info|" + errorMsg;
            return model;
        }

        public BaseModel NotificationSuccess(BaseModel model, string successMsg)
        {
            if (model == null)
            {
                Type typ = model.GetType();
                model = (BaseModel)Activator.CreateInstance(typ);
            }

            model.Notification = "success|" + successMsg;
            return model;
        }

        public  BaseModel NotificationMsg(BaseModel model, string errorMsg, Type typ)
        {
            if (model == null)
            {
                model = (BaseModel)Activator.CreateInstance(typ);
            }

            model.Notification = "Error|" + errorMsg;
            return model;
        }


        /// <summary>
        /// Get applicant id against provided service code and center
        /// </summary>
        /// <param name="fcCenter"></param>
        /// <param name="serviceCode"></param>
        /// <returns></returns>
        public static string GetCaseIDKey(string districtCode)
        {
            StringBuilder sbCode = new StringBuilder();

            sbCode.Append(districtCode.Trim());
            sbCode.Append("-");
            sbCode.Append(DateTime.Now.Day.ToString().PadLeft(2, '0'));
            sbCode.Append(DateTime.Now.ToString("MM"));
            sbCode.Append(DateTime.Now.ToString("yy"));
            sbCode.Append("-");

            int? counter = new CommonDAL().GetCaseID(districtCode, DateTime.Now.Year.ToString());
            if (counter.HasValue && counter.Value > 0)
            {
                sbCode.Append(counter.Value.ToString().PadLeft(6, '0'));
                return sbCode.ToString();
            }
            return null;

        }


        /// <summary>
        /// Save Document URLs
        /// </summary>
        /// <param name="caseID">Selected Case ID</param>
        /// <param name="Body">Url Body info</param>
        /// <returns></returns>
        public int SaveDocumentsURL(TableName tableName, string id, string documentURL, string documentTitles)
        {
            int ret = 0;
            //string tbaleName = "tblEvidenceInformation";
            ret = new CommonDAL().SaveDocumentsURL(tableName.ToString(), id, documentURL, documentTitles);
            return ret;
        }


        public DataTable GetDocuments(string tableName, string id)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = new CommonDAL().GetDocuments(tableName, id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }


        public int? UpdateDocuments(string documentsURL, string documentsTitle, string tblName, string id)
        {
            int? result = null;
            try
            {
                result = new CommonDAL().UpdateDocuments(documentsURL,documentsTitle, tblName, id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }



        /// <summary>
        /// Convert Integer Array into string 
        /// </summary>
        /// <param name="list">interger array</param>
        /// <returns>string data</returns>
        public  string ConvertIntArryToString(int[] list)
        {
            List<string> objs = new List<string>();
            if (list.Length > 0)
            {
                try
                {
                    for (int i = 0; i < list.Length; i++)
                    {
                        objs.Add(Convert.ToString(list[i]));
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return string.Join("|", objs.ToArray());
        }


     

        /// <summary>
        ///  Bind the Drop Down Table for Sending info to Database
        /// </summary>
        /// <param name="list">Interger List of Selected Drop down items</param>
        /// <param name="id">Mapping Parent ID</param>
        /// <returns>Drop down table </returns>
        public DataTable BindDropdownTable(int[] list)
        {
            DataTable dt = new DataTable();
            // add columns in the table
            dt.Columns.Add("ID", typeof(System.Int32));

            DataRow dr = null;
            List<string> objs = new List<string>();
            if (list.Length > 0)
            {
                try
                {
                    for (int i = 0; i < list.Length; i++)
                    {
                        dr = dt.NewRow();
                        dr["ID"] = Convert.ToInt16(list[i]);
                        dt.Rows.Add(dr);
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            return dt;
        }


        ///// <summary>
        ///// Convert Integer Array into string 
        ///// </summary>
        ///// <param name="list">interger array</param>
        ///// <returns>string data</returns>
        //public string ConvertStringToIntArry(int[] list)
        //{
        //    List<string> objs = new List<string>();
        //    if (list.Length > 0)
        //    {
        //        try
        //        {
        //            for (int i = 0; i < list.Length - 1; i++)
        //            {
        //                objs.Add(Convert.ToString(list[i]));
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            throw ex;
        //        }
        //    }
        //    return string.Join("|", objs.ToArray());
        //}
        public CommonListModel GetCommonUserLookups(LookupModel model)
        {
            CommonListModel commonListModel = new CommonListModel();
            try
            {
                DataSet ds = LazyBaseSingletonDAL<CommonDAL>.Instance.GetCommonUserLookups(model);
                DataTable dt = ds.Tables[0];
                commonListModel.Districts = (List<DistrictModel>)LazyBaseSingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new DistrictModel());

                dt = ds.Tables[1];
                commonListModel.Tehsils = (List<TehsilModel>)LazyBaseSingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new TehsilModel());

                //DataTable dt = ds.Tables[TableName.tblUserSector.ToString()];
                //commonListModel.Sectors = (List<SectorModel>)LazyBaseSingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new SectorModel());
                // dt = ds.Tables[TableName.tblUserSubSector.ToString()];
                //commonListModel.SubSectors = (List<SubSectorModel>)LazyBaseSingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new SubSectorModel());
               
              
                return commonListModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        /// <summary>
        /// Get Common Lookup List for Dashboard
        /// </summary>
        /// <param name="lookupModel"> lookup model</param>
        /// <param name="userID">Selected User ID</param>
        /// <returns>Common List Model</returns>
        public CommonListModel GetDashBoardCommonUserLookups(LookupModel model, int? userID)
        {
            CommonListModel commonListModel = new CommonListModel();
            try
            {
                DataSet ds = LazyBaseSingletonDAL<CommonDAL>.Instance.GetDashBoardCommonUserLookups(model, userID);
                //DataTable dt = ds.Tables[TableName.tblUserSector.ToString()];
                //commonListModel.Sectors = (List<SectorModel>)LazyBaseSingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new SectorModel());
                //dt = ds.Tables[TableName.tblUserSubSector.ToString()];
                //commonListModel.SubSectors = (List<SubSectorModel>)LazyBaseSingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new SubSectorModel());
        
                return commonListModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// CR:007
        /// <summary>
        /// Get String of provided file
        /// </summary>
        /// <param name="inputstm">byte array</param>
        /// <returns>Return String</returns>
        public string GetString(byte[] bytes)
        {
            char[] chars = new char[bytes.Length / sizeof(char)];
            System.Buffer.BlockCopy(bytes, 0, chars, 0, bytes.Length);
            return new string(chars);
        }

        /// <summary>
        /// CR:007
        /// <summary>
        /// Get String of provided file
        /// </summary>
        /// <param name="inputstm">String</param>
        /// <returns>Return byte[] array</returns>
        public byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }


        public DateTime ConvertDateFormat(string value)
        {
            DateTime Date = new DateTime();

            string[] arrValue = value.Split('/');
            if (arrValue.Length == 3)
            {
                Date = new DateTime(Convert.ToInt32(arrValue[2]), Convert.ToInt32(arrValue[1]), Convert.ToInt32(arrValue[0]));
            }

            return Date;
        }

        public static bool ValidateDateControl(int fromMonth, int fromYear, int toMonth, int toYear)
        {
            bool ret = false;

            DateTime Start = new DateTime(fromYear, fromMonth, 1);
            DateTime End = new DateTime(toYear, toMonth, 1);
        
            ret = Start > End ? false : true;

            return ret; 
        }

    }
}

