﻿

using BE.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BLL.CommonUtility
{
   public  class CommonBuildModel
    {
       public  IList<T> BuildModel<T>(DataTable dt, T objectType)
       {
           Type handlerType = objectType.GetType();
           if (dt != null && dt.Rows.Count > 0)
           {
               IList<T> genList = new List<T>();
               foreach (DataRow dr in dt.Rows)
               {
                   T item = (T)Activator.CreateInstance(handlerType);
                   foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                   {
                       foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                       {
                           MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                           if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                           {
                               propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                               break;
                           }
                       }

                   }
                   genList.Add(item);
               }
               return genList;
           }

           return null;

       }
       public List<T> BuildModelList<T>(DataTable dt, T objectType)
       {
           Type handlerType = objectType.GetType();
           if (dt != null && dt.Rows.Count > 0)
           {
               List<T> genList = new List<T>();
               foreach (DataRow dr in dt.Rows)
               {
                   T item = (T)Activator.CreateInstance(handlerType);
                   foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                   {
                       foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                       {
                           MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                           if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                           {
                               propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                               break;
                           }
                       }

                   }
                   genList.Add(item);
               }
               return genList;
           }

           return null;

       }

       // this is the method I have been using
       public static DataTable ConvertTo<T>(IList<T> list)
       {
           DataTable table = CreateTable<T>();
           Type entityType = typeof(T);
           PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(entityType);

           foreach (T item in list)
           {
               DataRow row = table.NewRow();

               foreach (PropertyDescriptor prop in properties)
               {

                   row[prop.Name] = prop.GetValue(item);
               }

               table.Rows.Add(row);
           }

           return table;
       }
       public static DataTable ConvertToTable<T>(IList<T> list)
       {
           DataTable table = CreateTable2<T>();
           Type entityType = typeof(T);
           PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(entityType);

           foreach (T item in list)
           {
               DataRow row = table.NewRow();

               foreach (PropertyInfo prop in properties)
               {
                   foreach (Object obj in prop.GetCustomAttributes(true))
                   {
                       MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                      // row[mappingInfoAttribute.ColumnName] = prop.GetValue(item);
                       row[mappingInfoAttribute.ColumnName] = prop.GetValue(item) ?? DBNull.Value;
                       break;
                   }
               }

               table.Rows.Add(row);
           }

           return table;
       }

       public static DataTable CreateTable<T>()
       {
           Type entityType = typeof(T);
           DataTable table = new DataTable(entityType.Name);
           PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(entityType);

           foreach (PropertyDescriptor prop in properties)
           {

               // HERE IS WHERE THE ERROR IS THROWN FOR NULLABLE TYPES
               table.Columns.Add(prop.Name, prop.PropertyType);
           }

           return table;
       }

       public static DataTable CreateTable2<T>()
       {
           Type entityType = typeof(T);
           DataTable table = new DataTable(entityType.Name);
           PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(entityType);

           foreach (PropertyInfo prop in properties)
           {
               foreach (Object obj in prop.GetCustomAttributes(true))
               {
                   MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                   // HERE IS WHERE THE ERROR IS THROWN FOR NULLABLE TYPES
                 //  table.Columns.Add(mappingInfoAttribute.ColumnName, prop.PropertyType);
                   table.Columns.Add(mappingInfoAttribute.ColumnName, Nullable.GetUnderlyingType(
            prop.PropertyType) ?? prop.PropertyType);
                   break;
               }
           }

           return table;
       }


    }
}
