﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.CommonUtility
{
   public class BaseBLL
    {
       //public void SaveSessionState(string sessionID ,string xmlObject,int? loginID, int? timeOute)
       //{
       //    try
       //    {
       //        LazyBaseSingletonDAL<SessionStateDAL>.Instance.Add(sessionID, xmlObject, loginID, timeOute);

       //    }
       //    catch(Exception ex)
       //    {
       //        throw ex;
       //    }
       //}

    }
}
