﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BLL.CustomExceptions
{
    public class BusinessException : Exception
    {
        public int ErroID { get; set; }
        public string ErroMessage { get; set; }
        public BusinessException(string erroMsg)
        {
            this.ErroMessage = erroMsg;
            this.ErroID = 1;
        }
        public BusinessException(string erroMsg,string errorCode)
        {
            this.ErroMessage = erroMsg;
            this.ErroID = 1;
        }
    }
}
