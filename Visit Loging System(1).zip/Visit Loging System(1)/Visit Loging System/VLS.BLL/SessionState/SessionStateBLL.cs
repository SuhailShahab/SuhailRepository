﻿
using BLL.CommonUtility;
using DAL.Generic;
using DAL.SessionState;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLS.BE.SessionState;

namespace BLL.SessionState
{
   public  class SessionStateBLL
    {

       /// <summary>
       /// Save Session State
       /// </summary>
       /// <param name="sessionID"></param>
       /// <param name="xmlObject"></param>
       /// <param name="loginID"></param>
       /// <param name="timeOute"></param>
       public void SaveSessionState(string sessionID, string xmlObject, int? loginID, int? timeOute)
       {
           try
           {
               LazyBaseSingletonDAL<SessionStateDAL>.Instance.Add(sessionID, xmlObject, loginID, timeOute);

           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="sessionID"></param>
       /// <returns></returns>
       public SessionStateModel GetSessiontStateByID(string sessionID)
       {
           List<SessionStateModel> sessionStateModel = null;

           try
           {
               DataTable dt = LazyBaseSingletonDAL<SessionStateDAL>.Instance.GetByID(sessionID);

               if (dt.Rows.Count > 0)
               {
                   sessionStateModel = (List<SessionStateModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SessionStateModel());
                   return sessionStateModel[0];
               }
                  
           }
           catch (Exception ex)
           {
               throw ex;
           }
           return null;
       }


       /// <summary>
       /// 
       /// </summary>
       /// <param name="sessionID"></param>
       /// <returns></returns>
       public int? DeleteSessionByID(string sessionID)
       {
           int? result;

           try
           {
              result = LazyBaseSingletonDAL<SessionStateDAL>.Instance.Delete(sessionID);             
              return result;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }
    }
}
