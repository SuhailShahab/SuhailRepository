﻿using BE.Content;
using BE.CustomEnums;
using BE.Lookups;
using BE.RamzanBazars;
using BE.Visit;
using BLL.CommonUtility;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
namespace BLL.Content
{
    public class VisitorLogBLL
    {
        /// <summary>
        /// Saving VisitorLog Record
        /// </summary>
        /// <param name="model"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int Save(VisitorLogModel model)
        {
            if (model.VisitorLogID == 0)        // add new record
                return new VisitorLogDAL().Add(model, BuildDoctorDateTable(model.Doctors), BuildDoctorPostDateTable(model.DoctorPosts), 
                    BuildHospitalEquipmentDateTable(model.HospitalEquipments), BuildMedicineTypeDateTable(model.MedicineTypes));
            else
                return new VisitorLogDAL().Edit(model);
        }

        public int SaveVisit(VisitorLogModel model)
        {
            int result = 0;
            try
            {
                if (model.VisitorLogID == 0)
                {
                    // add new record
                    VisitorLogInput visitorLogInput = new VisitorLogInput();
                    visitorLogInput.VisitorModel = model;
                    visitorLogInput.VisitorModel.RamzanBazarModel.CreatedBy = model.CreatedBy;
                    //Addd Ramzan Information 
                    List<RamzanBazarMonitoringItemModel> allItems = new List<RamzanBazarMonitoringItemModel>();
                    allItems.AddRange(model.RamzanBazarModel.SubsidizedItemsRates);
                    allItems.AddRange(model.RamzanBazarModel.WholeSaleItemsRates);
                    visitorLogInput.dtRamzanAllItems  = this.BuildRamzanItemsDataTable(allItems);


                    visitorLogInput.dtDoctor = BuildDoctorDateTable(model.Doctors);
                    visitorLogInput.dtDoctorPosts = BuildDoctorPostDateTable(model.DoctorPosts);
                    visitorLogInput.dtHospitalEquipment = BuildHospitalEquipmentDateTable(model.HospitalEquipments);
                    visitorLogInput.dtMedicineTypes = BuildMedicineTypeDateTable(model.MedicineTypes);
                    result = LazyBaseSingletonBLL<VisitorLogDAL>.Instance.AddTansaction(visitorLogInput);
                }
                else
                {
                  //  return new VisitorLogDAL().Edit(model);
                    VisitorLogInput visitorLogInput = new VisitorLogInput();
                    visitorLogInput.VisitorModel = model;
                    visitorLogInput.VisitorModel.RamzanBazarModel.ModifiedBy  = model.ModifiedBy;
                    //Addd Ramzan Information 
                    List<RamzanBazarMonitoringItemModel> allItems = new List<RamzanBazarMonitoringItemModel>();
                    allItems.AddRange(model.RamzanBazarModel.SubsidizedItemsRates);
                    allItems.AddRange(model.RamzanBazarModel.WholeSaleItemsRates);
                    visitorLogInput.dtRamzanAllItems = this.BuildRamzanItemsDataTable(allItems);


                    visitorLogInput.dtDoctor = BuildDoctorDateTable(model.Doctors);
                    visitorLogInput.dtDoctorPosts = BuildDoctorPostDateTable(model.DoctorPosts);
                    visitorLogInput.dtHospitalEquipment = BuildHospitalEquipmentDateTable(model.HospitalEquipments);
                    visitorLogInput.dtMedicineTypes = BuildMedicineTypeDateTable(model.MedicineTypes);
                    result = LazyBaseSingletonBLL<VisitorLogDAL>.Instance.EditTansaction(visitorLogInput);
                }
                    
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }

        public VisitorLogModel GetVsitorLogInformation(int? visitorLoginID)
        {
            DataSet ds = new DataSet();
            VisitorLogModel model = new VisitorLogModel();
            try
            {
                ds = LazyBaseSingletonBLL<VisitorLogDAL>.Instance.GetVisitorLogInformation(visitorLoginID);
                //Get VisitorLog Information 
                DataTable dt = ds.Tables[TableName.tblVisitorLog.ToString()];

              

                if(dt!=null && dt.Rows.Count>0)
                {
                    IList<VisitorLogModel> visitors = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<VisitorLogModel>(dt, new VisitorLogModel());
                    model = visitors[0];
                }

                //Get doctor absence Information 
                dt = ds.Tables[TableName.tblVisitLogDoctorAbsence.ToString()];               

                if (dt != null && dt.Rows.Count > 0)
                {
                    IList<DoctorModel> AbsensDoctors = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<DoctorModel>(dt, new DoctorModel());
                    model.Doctors = AbsensDoctors.ToList();
                }

                //Get doctor vacant post Information 
                dt = ds.Tables[TableName.tblDoctorPosts.ToString()];

                if (dt != null && dt.Rows.Count > 0)
                {
                    IList<DoctorPostModel> doctorPosts = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<DoctorPostModel>(dt, new DoctorPostModel());
                    model.DoctorPosts = doctorPosts.ToList();
                }

                //Get hospital equipments Information 
                dt = ds.Tables[TableName.tblVisitHospitalEquipment.ToString()];

                if (dt != null && dt.Rows.Count > 0)
                {
                    IList<HospitalEquipmentModel> hospitalEquipments = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<HospitalEquipmentModel>(dt, new HospitalEquipmentModel());
                    model.HospitalEquipments = hospitalEquipments.ToList();
                }

                //Get medicines Information 
                dt = ds.Tables[TableName.tblMedicineType.ToString()];

                if (dt != null && dt.Rows.Count > 0)
                {
                    IList<MedicineTypeModel> medicineTypes = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<MedicineTypeModel>(dt, new MedicineTypeModel());
                    model.MedicineTypes = medicineTypes.ToList();
                }


                //Get Ramzan bazar Monitoring Information 
                dt = ds.Tables[TableName.tblRamzanMonitoring.ToString()];

                if (dt != null && dt.Rows.Count > 0)
                {
                    IList<RamzanBazarMonitoringModel> ramzanBazarMonitoringModel = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<RamzanBazarMonitoringModel>(dt, new RamzanBazarMonitoringModel());
                    model.RamzanBazarModel = ramzanBazarMonitoringModel.ToList()[0];
                }


                //Get Ramzan bazar Monitoring Information 
                dt = ds.Tables[TableName.tblRamzanMonitoringLineItem.ToString()];

                if (dt != null && dt.Rows.Count > 0)
                {
                    if(model.RamzanBazarModel== null)
                    {
                        model.RamzanBazarModel = new RamzanBazarMonitoringModel();
                    }
                    IList<RamzanBazarMonitoringItemModel> items = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<RamzanBazarMonitoringItemModel>(dt, new RamzanBazarMonitoringItemModel());
                    model.RamzanBazarModel.SubsidizedItemsRates = items.Where(i => i.CategoryID == CategoryNames.SubsidizedItem.GetHashCode()).ToList();
                    model.RamzanBazarModel.WholeSaleItemsRates = items.Where(i => i.CategoryID == CategoryNames.WholeSaleItem.GetHashCode()).ToList();
                }

                

                return model;

            }
            catch(Exception ex)
            {
                throw ex;
            }

        }

        public int SaveImages(int VisitLogID, List<ImageModel> colImages)
        {
            return new VisitorLogDAL().AddVisitLogImages(VisitLogID, BuildImageDataTable(colImages));
        }

        public int DeleteVistorLogImage(int imageID)
        {
            int rsult = 0;
            try
            {
               rsult=  LazyBaseSingletonBLL<VisitorLogDAL>.Instance.DeleteImage(imageID);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return rsult;
        }

        #region "internal and Private Methods"

        private List<VisitorLogModel> BindData(DataTable dt)
        {
            List<VisitorLogModel> lists = new List<VisitorLogModel>();

            if (dt.Rows.Count > 0)

                lists = (List<VisitorLogModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new VisitorLogModel());

            return lists;
        }

        /// <summary>
        /// 
        ///  Bind the Datatable Collection From Image Model Colelction 
        /// </summary>
        /// <param name="dt">DataTable</param>
        /// <returns></returns>
        private DataTable BuildImageDataTable(List<ImageModel> model)
        {
            DataTable dt = new DataTable();
            // add columns in the table
            dt.Columns.Add("ImageID", typeof(System.Int32));
            dt.Columns.Add("VisitorLogID", typeof(System.Int32));
            dt.Columns.Add("ImageTitle", typeof(System.String));
            dt.Columns.Add("ImageDescription", typeof(System.String));
            dt.Columns.Add("VisitorLogImage", typeof(byte[]));
            dt.Columns.Add("ContentType", typeof(System.String));
            DataRow dr = null;

            foreach (ImageModel item in model)
            {
                dr = dt.NewRow();
                dr["ImageID"] = item.ImageID;
                dr["VisitorLogID"] = item.VisitorLogID;
                dr["ImageTitle"] = item.ImageTitle;
                dr["ImageDescription"] = item.ImageDescription;
                dr["VisitorLogImage"] = new CommonBLL().GetBytes(item.VisitorLogImage);
                dr["ContentType"] = item.ContentType;

                dt.Rows.Add(dr);
            }

            return dt;
        }

        private DataTable BuildDoctorDateTable(List<DoctorModel> colDoctors)
        { 
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(System.Int32));

            if (colDoctors != null)
            {
                foreach (var itm in colDoctors)
                {
                    if (itm.Checked.HasValue && itm.Checked.Value)
                    {
                        DataRow dr = dt.NewRow();
                        dr["ID"] = itm.ID;

                        dt.Rows.Add(dr);
                    }
                }
            }

            return dt;
        }

        private DataTable BuildDoctorPostDateTable(List<DoctorPostModel> colDoctorPosts)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(System.Int32));

            if (colDoctorPosts != null)
            {
                foreach (var itm in colDoctorPosts)
                {
                    if (itm.Checked.HasValue && itm.Checked.Value)
                    {
                        DataRow dr = dt.NewRow();
                        dr["ID"] = itm.ID;

                        dt.Rows.Add(dr);
                    }
                }
            }

            return dt;
        }

        private DataTable BuildHospitalEquipmentDateTable(List<HospitalEquipmentModel> colHospitalEquipments)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(System.Int32));

            if (colHospitalEquipments != null)
            {
                foreach (var itm in colHospitalEquipments)
                {
                    if (itm.Checked.HasValue && itm.Checked.Value)
                    {
                        DataRow dr = dt.NewRow();
                        dr["ID"] = itm.ID;

                        dt.Rows.Add(dr);
                    }
                }
            }

            return dt;
        }

        private DataTable BuildMedicineTypeDateTable(List<MedicineTypeModel> colMedicineTypes)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(System.Int32));

            if (colMedicineTypes != null)
            {
                foreach (var itm in colMedicineTypes)
                {
                    if (itm.Checked.HasValue && itm.Checked.Value)
                    {
                        DataRow dr = dt.NewRow();
                        dr["ID"] = itm.ID;

                        dt.Rows.Add(dr);
                    }
                }
            }

            return dt;
        }

        private DataTable BuildRamzanItemsDataTable(List<RamzanBazarMonitoringItemModel> item)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("MonitoringItemID", typeof(int)));
            dt.Columns.Add(new DataColumn("ItemID", typeof(int)));
            dt.Columns.Add(new DataColumn("Availabitliy", typeof(string)));
            dt.Columns.Add(new DataColumn("ConditionID", typeof(int)));
            dt.Columns.Add(new DataColumn("Rates", typeof(Decimal)));
            dt.Columns.Add(new DataColumn("Remarks", typeof(string)));

            DataRow dr = null;
            if (item != null && item.Count > 0)
            {
                foreach (RamzanBazarMonitoringItemModel itm in item)
                {
                    dr = dt.NewRow();

                    if (itm.ID != null)
                        dr["MonitoringItemID"] = itm.ID;
                    if (itm.ItemID != null)
                        dr["ItemID"] = itm.ItemID;
                    if (itm.Availabitliy != null)
                        dr["Availabitliy"] = itm.Availabitliy;
                    if (itm.ConditionID != null)
                        dr["ConditionID"] = itm.ConditionID;
                    if (itm.Rates != null)
                        dr["Rates"] = itm.Rates;
                    if (itm.Remarks != null)
                        dr["Remarks"] = itm.Remarks;

                    dt.Rows.Add(dr);
                }

                return dt;

            }
            return dt;
        }
        #endregion
    }

   
}
