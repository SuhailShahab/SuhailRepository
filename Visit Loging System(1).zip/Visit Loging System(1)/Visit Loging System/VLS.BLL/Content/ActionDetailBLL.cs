﻿using BE.Content;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLS.DAL.Content;


// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <28-03-2016 05:00PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// =================================================================================================================================
namespace VLS.BLL.Content
{
    public class ActionDetailBLL
    {
        #region "Public Methods"

        /// <summary>
        /// Restrict unauthorised access for action taken
        /// </summary>
        /// <param name="visitorLogID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public bool IsValidActionTakenUser(int visitorLogID, int userID)
        {
            return LazyBaseSingletonDAL<ActionDetailDAL>.Instance.IsValidActionTakenUser(visitorLogID, userID);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="visitorLogID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public bool IsValidUserPrintActionReport(int visitorLogID, int userID)
        {
            return LazyBaseSingletonDAL<ActionDetailDAL>.Instance.IsValidUserPrintActionReport(visitorLogID, userID);
        }

        
        public bool IsValidVistorUser(int visitorLogID, int? userID)
        {
            try
            {
                return LazyBaseSingletonDAL<ActionDetailDAL>.Instance.IsValidVistorUser(visitorLogID, userID);
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }


        /// <summary>
        /// Get Assign Task Detail Info
        /// </summary>
        /// <param name="visitorLogID">Selected visitor Log ID</param>
        /// <returns>Action Detail Model</returns>
        public ActionDetailModel GetAssignTaskDetail(int visitorLogID)
        {
            try
            {
                ActionDetailModel model = new ActionDetailModel();
                DataSet ds;

                ds = LazyBaseSingletonDAL<ActionDetailDAL>.Instance.GetAssignTaskDetail(visitorLogID);
                model = BindData(ds.Tables["VisitLog"])[0];
                model.Images = BindImageList(ds.Tables["VisitLogImages"]);


                model.Doctors = BuildDoctorAbsence(ds.Tables["VisitLogDoctorAbsence"]);
                model.DoctorPosts = BuildVacantDoctors(ds.Tables["VisitLogVacantDoctor"]);
                model.HospitalEquipments = BuildHospitalEquipment(ds.Tables["VisitHospitalEquipment"]);
                model.MedicineTypes = BuildMedicineType(ds.Tables["VisitLogMedicine"]);

            

                

                return model;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Saving Action Detail  Record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(ActionDetailModel model, int visitorLogID, int? designationID)
        {
            int result = 0;
            // add new record
            //result = new ActionDetailDAL().Add(model, BuildImageDataTable(model.Images));
            result = new ActionDetailDAL().Add(model, visitorLogID, designationID);
            return result;
        }

        /// <summary>
        /// Bind Data from Database
        /// </summary>
        /// <param name="dt">Data Table</param>
        /// <returns></returns>
        public List<ActionImageModel> BindImageList(DataTable dt)
        {
            List<ActionImageModel> lists = null;
            if (dt != null && dt.Rows.Count > 0)
            {
                lists = new List<ActionImageModel>();

                foreach (DataRow dr in dt.Rows)
                {
                    ActionImageModel actionImage = new ActionImageModel();

                    if (dt.Columns.Contains("ImageID") && !Convert.IsDBNull(dr["ImageID"]))
                        actionImage.ImageID = Convert.ToInt32(dr["ImageID"]);

                    if (dt.Columns.Contains("ImageTitle") && !Convert.IsDBNull(dr["ImageTitle"]))
                        actionImage.ImageTitle = Convert.ToString(dr["ImageTitle"]);

                    if (dt.Columns.Contains("ImageDescription") && !Convert.IsDBNull(dr["ImageDescription"]))
                        actionImage.ImageDescription = Convert.ToString(dr["ImageDescription"]);

                    if (dt.Columns.Contains("VisitedDate") && !Convert.IsDBNull(dr["VisitedDate"]))
                        actionImage.VisitedDate = Convert.ToDateTime(dr["VisitedDate"]);

                    if (dt.Columns.Contains("VistedDepartment") && !Convert.IsDBNull(dr["VistedDepartment"]))
                        actionImage.VistedDepartmentName = Convert.ToString(dr["VistedDepartment"]);

                    if (dt.Columns.Contains("Place") && !Convert.IsDBNull(dr["Place"]))
                        actionImage.Place = Convert.ToString(dr["Place"]);

                    if (dt.Columns.Contains("VisitedBy") && !Convert.IsDBNull(dr["VisitedBy"]))
                        actionImage.VisitedBy = Convert.ToString(dr["VisitedBy"]);


                    if (dt.Columns.Contains("VisitorLogImage") && !Convert.IsDBNull(dr["VisitorLogImage"]))
                    {
                        byte[] pictureArry = (byte[])(dr["VisitorLogImage"]);

                        using (MemoryStream memoryStream = new MemoryStream(pictureArry))
                        {
                            StreamReader streamReader = new StreamReader(memoryStream, Encoding.Unicode);
                            //generalField.Image = streamReader.ReadToEnd();
                            string fileContent = streamReader.ReadToEnd();
                            actionImage.VisitorLogImage = fileContent;

                            if (fileContent != "")
                                actionImage.VisitorLogRptImage = fileContent.Split(',')[1].ToString();

                            streamReader.Close();

                        }
                    }
                    lists.Add(actionImage);
                }

                lists.TrimExcess();

            }
            return lists;
        }

        /// <summary>
        /// Upload action taken attachment
        /// </summary>
        /// <param name="visitorLogID"></param>
        /// <param name="Document"></param>
        /// <returns></returns>
        public int UploadAttachment(int visitorLogID,int? designationID, byte[] Document, string contentType)
        {
            return LazyBaseSingletonBLL<ActionDetailDAL>.Instance.UploadAttachment(visitorLogID,designationID, Document, contentType);
        }

        #endregion


        #region "internal and Private Methods"

        /// <summary>
        /// Bind Data from Database
        /// </summary>
        /// <param name="dt">Data Table</param>
        /// <returns></returns>
        private List<ActionDetailModel> BindData(DataTable dt)
        {
            List<ActionDetailModel> model = new List<ActionDetailModel>();
            if (dt.Rows.Count > 0)
                model = (List<ActionDetailModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new ActionDetailModel());

            return model;
        }

        /// <summary>
        /// 
        ///  Bind the Datatable Collection From Image Model Colelction 
        /// </summary>
        /// <param name="dt">DataTable</param>
        /// <returns></returns>
        private DataTable BuildImageDataTable(List<ActionImageModel> model)
        {
            DataTable dt = new DataTable();
            // add columns in the table
            dt.Columns.Add("ImageID", typeof(System.Int32));
            dt.Columns.Add("VisitorLogID", typeof(System.Int32));
            dt.Columns.Add("ImageTitle", typeof(System.String));
            dt.Columns.Add("ImageDescription", typeof(System.String));
            dt.Columns.Add("VisitorLogImage", typeof(byte[]));
            DataRow dr = null;

            foreach (ActionImageModel item in model)
            {
                dr = dt.NewRow();
                dr["ImageID"] = item.ImageID;
                dr["ImageTitle"] = item.ImageTitle;
                dr["ImageDescription"] = item.ImageDescription;
                dr["VisitorLogImage"] = new CommonBLL().GetBytes(item.VisitorLogImage);

                dt.Rows.Add(dr);
            }
            return dt;
        }

        private List<HospitalEquipmentModel> BuildHospitalEquipment(DataTable dt)
        {
            List<HospitalEquipmentModel> HospitalEquipments = LazyBaseSingletonBLL<HospitalEquipmentBLL>.Instance.GetActiveHospitalEquipments();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    HospitalEquipmentModel he = HospitalEquipments.Where(h => h.ID == Convert.ToInt32(dr["EquipmentID"].ToString())).FirstOrDefault();
                    if (he != null)
                        he.Checked = true;
                }
            }

            return HospitalEquipments;
        }

        private List<DoctorPostModel> BuildDoctorAbsence(DataTable dt)
        {
            List<DoctorPostModel> Doctors = LazyBaseSingletonBLL<DoctorPostBLL>.Instance.GetActiveDoctorPosts();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    DoctorPostModel dm = Doctors.Where(d => d.ID == Convert.ToInt32(dr["DoctorID"].ToString())).FirstOrDefault();
                    if (dm != null)
                        dm.Checked = true;
                }
            }

            return Doctors;
        }

        private List<MedicineTypeModel> BuildMedicineType(DataTable dt)
        {
            List<MedicineTypeModel> MedicineTypes = LazyBaseSingletonBLL<MedicineTypeBLL>.Instance.GetActiveMedicineTypes();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    MedicineTypeModel mt = MedicineTypes.Where(m => m.ID == Convert.ToInt32(dr["MedicineTypeID"].ToString())).FirstOrDefault();
                    if (mt != null)
                        mt.Checked = true;
                }
            }

            return MedicineTypes;
        }

        private List<DoctorPostModel> BuildVacantDoctors(DataTable dt)
        {
            List<DoctorPostModel> VacantDoctors = LazyBaseSingletonBLL<DoctorPostBLL>.Instance.GetActiveDoctorPosts();

            if (dt != null && dt.Rows.Count > 0) 
            {
                foreach (DataRow dr in dt.Rows)
                {
                    DoctorPostModel mt = VacantDoctors.Where(m => m.ID == Convert.ToInt32(dr["DoctorPostID"].ToString())).FirstOrDefault();
                    if (mt != null)
                        mt.Checked = true;
                }
            }

            return VacantDoctors;
        }

        #endregion
    }
}
