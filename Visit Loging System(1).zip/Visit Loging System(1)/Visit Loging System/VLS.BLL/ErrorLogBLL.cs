﻿
using BE.LogManager;
using System;
using VLS.DAL.LogManager;


// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <01-06-2015 01:06:33PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BLL
{
    public class ErrorLogBLL
    {
        /// <summary>
        /// Save application error or exception information
        /// </summary>
        /// <param name="model"></param>
        public void Save(ErrorLogModel model)
        {
            new ErrorLogDAL().Add(model);
        }
    }
}
