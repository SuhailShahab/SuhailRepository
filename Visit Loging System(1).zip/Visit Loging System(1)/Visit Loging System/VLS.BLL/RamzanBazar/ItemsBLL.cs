﻿using BE.RamzanBazars;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.RamzanBazar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.RamzanBazar
{
    public class ItemsBLL
    {
        public List<ItemsModel> GetConditions(int? tentageID)
        {
            IList<ItemsModel> items = null;
            try
            {
                DataTable dt = LazyBaseSingletonDAL<ItemsDAL>.Instance.GetRamzanItems(tentageID);
                if (dt.Rows.Count > 0)
                    items = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<ItemsModel>(dt, new ItemsModel());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (items != null && items.Count > 0)
                return items.ToList();
            else
                return null;
        }
    }

}
