﻿using BE.RamzanBazars;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.RamzanBazar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.RamzanBazar
{
   public class ConditionBLL
    {
       public IList<ConditionModel> GetConditions(int? conditionID)
       {
           IList<ConditionModel> conditions = new List<ConditionModel>();
           try
           {
               DataTable dt =  LazyBaseSingletonDAL<ConditionDAL>.Instance.GetConditions(conditionID);
               if (dt.Rows.Count > 0)
                   conditions = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<ConditionModel>(dt, new ConditionModel());
           }
           catch(Exception ex)
           {
               throw ex;

           }
           return conditions;
       }
    }
}
