﻿using BE.CustomEnums;
using BE.RamzanBazars;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.RamzanBazar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.RamzanBazar
{
   public  class RamzanBazarMonitoringBLL
    {
       /// <summary>
       /// And and Edit Ramzan Bazar Analaysis
       /// </summary>
       /// <param name="model"></param>
       /// <returns></returns>
       public int? SaveRamzanBazarMonitoring(RamzanBazarMonitoringModel model,int ? visitorID)
       {
           int? resutl = null;
           try
           {
               if (model.IsEdit.HasValue && model.IsEdit.Value)
               {
                   List<RamzanBazarMonitoringItemModel> allItems = new List<RamzanBazarMonitoringItemModel>();
                   allItems.AddRange(model.SubsidizedItemsRates);
                   allItems.AddRange(model.WholeSaleItemsRates);
                   DataTable tblAllItems = this.GetDataTable(allItems);
                   resutl = LazyBaseSingletonDAL<RamzanBazarMonitoringDAL>.Instance.EditRamzanBazarMonitoring(model, tblAllItems, visitorID);
               }
               else
               {
                   List<RamzanBazarMonitoringItemModel> allItems = new List<RamzanBazarMonitoringItemModel>();
                   allItems.AddRange(model.SubsidizedItemsRates);
                   allItems.AddRange(model.WholeSaleItemsRates);
                   DataTable tblAllItems = this.GetDataTable(allItems);
                   resutl = LazyBaseSingletonDAL<RamzanBazarMonitoringDAL>.Instance.AddRamzanBazarMonitoring(model, tblAllItems, visitorID);

               }
           }
           catch (Exception ex)
           {

           }

           return resutl;

       }

       public RamzanBazarMonitoringModel GetRamzanBazarMonitoringByID(int visitorLogID)
       {
           RamzanBazarMonitoringModel model = null;
           try
           {
               DataSet ds = LazyBaseSingletonDAL<RamzanBazarMonitoringDAL>.Instance.GetRamzanBazarMonitoringByID(visitorLogID);
               if(ds!=null)
               {
                    
                   DataTable dtRamzanMonitoring = ds.Tables[TableName.tblRamzanMonitoring.ToString()];
                   DataTable dtRamzanMonitoringLineItem = ds.Tables[TableName.tblRamzanMonitoringLineItem.ToString()];
                   //Get Main table Inforamtion
                   if(dtRamzanMonitoring!=null && dtRamzanMonitoring.Rows.Count>0)
                   {
                      IList<RamzanBazarMonitoringModel> items = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<RamzanBazarMonitoringModel>(dtRamzanMonitoring, new RamzanBazarMonitoringModel());
                      model = items[0];                      
                   }

                   if (dtRamzanMonitoringLineItem != null && dtRamzanMonitoringLineItem.Rows.Count > 0)
                   {
                       IList<RamzanBazarMonitoringItemModel> items = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<RamzanBazarMonitoringItemModel>(dtRamzanMonitoringLineItem, new RamzanBazarMonitoringItemModel());
                       model.SubsidizedItemsRates = items.Where(i => i.CategoryID == CategoryNames.SubsidizedItem.GetHashCode()).ToList();
                       model.WholeSaleItemsRates  = items.Where (i => i.CategoryID == CategoryNames.WholeSaleItem.GetHashCode()).ToList();
                   }

                   return model;

               }
           }
           catch(Exception ex)
           {
               throw ex;
           }

           return null;
          
       }

       public RamzanBazarMonitoringModel GetRamzanBazarMonitoring()
       {
           RamzanBazarMonitoringModel model = new RamzanBazarMonitoringModel();
           try
           {
               DataTable  dt = LazyBaseSingletonDAL<RamzanBazarMonitoringDAL>.Instance.GetRamzanBazarMonitoring();
               if (dt != null && dt.Rows.Count > 0)
               {


                   IList<RamzanBazarMonitoringItemModel> items = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<RamzanBazarMonitoringItemModel>(dt, new RamzanBazarMonitoringItemModel());
                   model.SubsidizedItemsRates = items.Where(i => i.CategoryID == CategoryNames.SubsidizedItem.GetHashCode()).ToList();
                   model.WholeSaleItemsRates = items.Where(i => i.CategoryID == CategoryNames.WholeSaleItem.GetHashCode()).ToList();


                   return model;

               }
           }
           catch (Exception ex)
           {
               throw ex;
           }

           return null;

       }


        

        #region Internal Method

       private   DataTable GetDataTable(List<RamzanBazarMonitoringItemModel> item)
       {
           DataTable dt = new DataTable();
           dt.Columns.Add(new DataColumn("MonitoringItemID", typeof(int)));
           dt.Columns.Add(new DataColumn("ItemID", typeof(int)));
           dt.Columns.Add(new DataColumn("Availabitliy", typeof(string)));
           dt.Columns.Add(new DataColumn("ConditionID", typeof(int)));
           dt.Columns.Add(new DataColumn("Rates", typeof(Decimal)));
           dt.Columns.Add(new DataColumn("Remarks", typeof(string)));
          
           DataRow dr = null;
           if (item != null && item.Count > 0)
           {
               foreach (RamzanBazarMonitoringItemModel itm in item)
               {
                   dr = dt.NewRow();

                   if (itm.ID != null)
                        dr["MonitoringItemID"] = itm.ID;
                   if (itm.ItemID != null)
                        dr["ItemID"] = itm.ItemID;
                   if (itm.Availabitliy != null)
                        dr["Availabitliy"] = itm.Availabitliy;
                   if (itm.ConditionID != null)
                        dr["ConditionID"] = itm.ConditionID;
                   if (itm.Rates != null)
                        dr["Rates"] = itm.Rates;
                   if (itm.Remarks != null)
                        dr["Remarks"] = itm.Remarks;

                   dt.Rows.Add(dr);
               }

               return dt;

           }
           return dt;
       }
        #endregion 
   }
}
