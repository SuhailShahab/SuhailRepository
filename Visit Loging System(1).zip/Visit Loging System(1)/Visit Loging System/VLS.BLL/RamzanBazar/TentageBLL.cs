﻿using BE.RamzanBazar;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.RamzanBazar;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.RamzanBazar
{
  public   class TentageBLL
    {
      public List<TentageModel> GetConditions(int? tentageID)
      {
          IList<TentageModel> items = null;
          try
          {
              DataTable dt = LazyBaseSingletonDAL<TentageDAL>.Instance.GetTentages(tentageID);
              if (dt.Rows.Count > 0)
                  items = LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel<TentageModel>(dt, new TentageModel());
          }
          catch (Exception ex)
          {
              throw ex;
          }
          if (items != null && items.Count > 0)
              return items.ToList();
          else
              return null;
      }
    }
}
