﻿using BE.Dashboard;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using DAL.Dashboard;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <25-Mar-2016 02:50:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BLL.Dashboard
{
    public class DashboardLogsBLL
    {
        /// <summary>
        /// Get Visited Task on Designation Base
        /// </summary>
        /// <param name="assignTo">Selected User ID</param>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="designationID">Selected Designation ID</param>
        /// <returns>Dash Board Model View</returns>>
        public DashBoardModelView GetDashBoardVisitedForDesignation(int userID, int pageNo, int pageSize, int designationID, int rateID, string sortColumn, int? sortDirection)
        {
            try
            {
                DashBoardModelView mianModel = new DashBoardModelView();
                DataSet ds;

                ds = LazyBaseSingletonDAL<DashBoardDAL>.Instance.GetDashBoardVisitedForDesignation(userID, pageNo, pageSize, designationID, rateID, sortColumn, sortDirection);
                mianModel.Tasks = BuildModelCollection(ds.Tables["Visits"]);
                mianModel.RESULT_COUNT = rateID == 0 ? Convert.ToInt32(ds.Tables["TotalRecords"].Rows[0][0]) : Convert.ToInt32(ds.Tables["RateTotalCount"].Rows[0][0]);
                mianModel = DashBoardStaticCount(mianModel, Convert.ToInt32(ds.Tables["TotalRecords"].Rows[0][0]));
                mianModel.RatingCounts = BuildRatingCounts(ds.Tables["RatingCount"]);        // create rating counts

                return mianModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region "Private Methods"

        /// <summary>
        /// Bind Data from Database
        /// </summary>
        /// <param name="dt">Data Table</param>
        /// <returns></returns>
        private List<DashBoardModel> BuildModelCollection(DataTable dt)
        {
            List<DashBoardModel> lists = new List<DashBoardModel>();
            if (dt.Rows.Count > 0)
                lists = (List<DashBoardModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DashBoardModel());

            return lists;
        }

        private DashBoardModelView DashBoardStaticCount(DashBoardModelView mianModel, int count)
        {
            List<StatesCountModel> counts = new List<StatesCountModel>();

            try
            {
                StatesCountModel model = null;

                model = new StatesCountModel();
                model.Count = count;        //Convert.ToInt32(dt.Rows[0][0]);
                model.Title = "LOG OF VISITS BY ADMINISTRATIVE SECRETARY";
                model.MethodName = "GetDashBoardVisitedForDesignation";
                counts.Add(model);

                mianModel.Counts = counts;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return mianModel;
        }

        private List<RatingCountModel> BuildRatingCounts(DataTable dt)
        {
            List<RatingModel> colRates = (List<RatingModel>)LazyBaseSingletonBLL<RatingBLL>.Instance.GetAllRatings();
            List<RatingCountModel> colRatings = new List<RatingCountModel>();

            foreach (DataRow dr in dt.Rows)
            {
                RatingCountModel rcm = new RatingCountModel();
                rcm.RateID = Convert.ToInt32(dr["Rating"].ToString());
                rcm.Title = dr["RatingName"].ToString();
                rcm.Count = Convert.ToInt32(dr["Counts"].ToString());
                rcm.Category = dr["RateCategory"].ToString();
                rcm.Sort = Convert.ToInt32(dr["RateSort"].ToString());

                colRatings.Add(rcm);
            }

            // add missing rating with 0 counts
            foreach (RatingModel r in colRates)
            {
                RatingCountModel scm = colRatings.Where(t => t.Title.ToLower() == r.Title.ToLower()).FirstOrDefault();
                if (scm == null)
                {
                    RatingCountModel sc = new RatingCountModel();
                    sc.RateID = r.ID.Value;
                    sc.Title = r.Title;
                    sc.Count = 0;
                    sc.Category = r.Category;
                    sc.Sort = r.Sort.Value;

                    colRatings.Add(sc);
                }
            }

            if (colRatings.Count > 0) colRatings.TrimExcess();

            return colRatings.OrderBy(r => r.Category).ThenBy(r => r.Sort).ToList();
        }

        #endregion
    }
}
