﻿using BE.Dashboard;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using DAL.Dashboard;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <31-03-2016 03:36:26PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BLL.Dashboard
{
    public class DashboardCMBLL
    {
        public List<DistrictVisitsCountModel> GetVisitCountByDistrict(int? DistrictID, DateTime? FromDate, DateTime? ToDate, List<DesignationModel> colDesignations, int UserID, int? FacilityID)
        {
            DataTable dtDesignationIDs = BuildDesignationIDsTable(colDesignations, UserID);     // build designation ids datatable
            DataTable dt = LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetVisitCountByDistrict(DistrictID, FromDate, ToDate, dtDesignationIDs, FacilityID);
            return BuildVisitCountCollection(dt);
        }

        public List<DistrictVisistsModel> GetFieldVisitsByDistrict(int? DistrictID, DateTime? FromDate, DateTime? ToDate)
        {
            List<DistrictVisistsModel> colVisits = new List<DistrictVisistsModel>();

            DataTable dt = LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetFieldVisitsByDistrict(DistrictID, FromDate, ToDate);
            if (dt.Rows.Count > 0)
                colVisits = (List<DistrictVisistsModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DistrictVisistsModel());

            return colVisits;
        }

        //public List<DistrictVisitsCountModel> GetVisitCountByAdministrativeSecretaries(int? DistrictID, DateTime? FromDate, DateTime? ToDate)
        //{
        //    DataTable dt = LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetVisitCountByAdministrativeSecretaries(DistrictID, FromDate, ToDate);
        //    return BuildVisitCountModelOfficals(dt);
        //}

        /// <summary>
        /// Get visit logs against designation ids
        /// </summary>
        /// <param name="DistrictID"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <param name="colDesignations"></param>
        /// <returns></returns>
        public List<DesignationVisitModel> GetVisitCountByDesignation(int? DistrictID, DateTime? FromDate, DateTime? ToDate, List<DesignationModel> colDesignations, int UserID, int? FacilityID)
        {
            DataTable dtDesignationIDs = BuildDesignationIDsTable(colDesignations, UserID);     // build designation ids datatable
            DataTable dt = LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetVisitCountByDesignation(DistrictID, FromDate, ToDate, dtDesignationIDs, FacilityID);

            return BuildVisitDesignation(dt, dtDesignationIDs);
        }

        public List<SecretaryContactModel> GetSecretariesContactList()
        {
            DataTable dt = LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetSecretariesContactList();
            return BuildSecreatryContactList(dt);
        }

        public string GetSectaryCellNumberByID(int DepartmentID)
        {
            return LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetSectaryCellNumberByID(DepartmentID);
        }

        public DashboardRatingModelView GetRatingPerformedBreakdownByUserID(int UserID, int? DistrictID, DateTime? FromDate, DateTime? ToDate, int? FacilityID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();

            DataSet ds = LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetVisitsRatingPerformedBreakdownByUserID(UserID, DistrictID, FromDate, ToDate, FacilityID);

            model.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables["Rating"], new RatingModel());
            model.DepartmentLogs = BuildVisitsRatingModel(ds.Tables["Visits"]);

            return model;
        }

        /// <summary>
        /// Get user wise rating breakdown visit logs
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="DistrictID"></param>
        /// <param name="RatingID"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <returns></returns>
        public List<LogDetail> GetVisitRatingDetailByUserID(int UserID, int? DistrictID, int? RatingID, DateTime? FromDate, DateTime? ToDate, int? FacilityID)
        {
            DataTable dt = LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetVisitRatingDetailByUserID(UserID, DistrictID, RatingID, FromDate, ToDate, FacilityID);
            return BuildVisitRatingDetailModel(dt);
        }

        /// <summary>
        /// Get visit rating breakdown by district id
        /// </summary>
        /// <param name="DistrictID"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <returns></returns>
        public DashboardRatingModelView GetRatingPerformedBreakdownByDistrictID(int DistrictID, DateTime? FromDate, DateTime? ToDate, List<DesignationModel> colDesignations, int UserID, int? FacilityID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();

            DataTable dtDesignationIDs = BuildDesignationIDsTable(colDesignations, UserID);     // build designation ids datatable 
            DataSet ds = LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetVisitsRatingPerformedBreakdownByDistrictID(DistrictID, FromDate, ToDate, dtDesignationIDs, FacilityID);

            model.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables["Rating"], new RatingModel());
            model.DistrictLogs = BuildVisitsRatingDistrictModel(ds.Tables["Visits"]);
            return model;
        }


        /// <summary>
        /// Get distrit wise rating breakdown visits logs
        /// </summary>
        /// <param name="DistrictID"></param>
        /// <param name="RatingID"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <returns></returns>
        public List<LogDetail> GetDistrictRatingLogDetail(int DistrictID, int? RatingID, DateTime? FromDate, DateTime? ToDate, List<DesignationModel> colDesignations, int UserID, int? FacilityID)
        {
            DataTable dtDesignationIDs = BuildDesignationIDsTable(colDesignations, UserID);     // build designation ids datatable 
            DataTable dt = LazyBaseSingletonDAL<DashboardCMDAL>.Instance.GetDistrictRatingLogDetail(DistrictID, RatingID, FromDate, ToDate, dtDesignationIDs, FacilityID);
            return BuildVisitRatingDetailModel(dt);
        }


        #region "Private Methods"

        private List<DistrictVisitsCountModel> BuildVisitCountCollection(DataTable dt)
        {
            List<DistrictVisitsCountModel> colVisitsDistrict = new List<DistrictVisitsCountModel>();
            DistrictVisitsCountModel dv = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    dv = new DistrictVisitsCountModel();

                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        dv.DistrictID = Convert.ToInt32(dr["DistrictID"].ToString());

                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        dv.DistrictName = dr["Title"].ToString();

                    if (dt.Columns.Contains("NoOfVisits") && !Convert.IsDBNull(dr["NoOfVisits"]))
                        dv.VisitsCount = Convert.ToInt32(dr["NoOfVisits"].ToString());

                    // colVisitsDistrict. .VisitsCount = dv.VisitsCount + Convert.ToInt32(dr["NoOfVisits"].ToString());

                    if (dv.VisitsCount >= 0 && dv.VisitsCount <= 4)
                        dv.Color = "gray";
                    else if (dv.VisitsCount >= 5 && dv.VisitsCount <= 9)
                        dv.Color = "Red";
                    else if (dv.VisitsCount >= 10 && dv.VisitsCount <= 14)
                        dv.Color = "Orange";
                    else
                        dv.Color = "Green";

                    colVisitsDistrict.Add(dv);
                }

                colVisitsDistrict.TrimExcess();
            }

            return colVisitsDistrict.OrderByDescending(v => v.VisitsCount).ToList();
        }

        //private List<DistrictVisitsCountModel> BuildVisitCountModelOfficals(DataTable dt)
        //{
        //    List<DistrictVisitsCountModel> colVisitsDistrict = new List<DistrictVisitsCountModel>();
        //    DistrictVisitsCountModel dv = null;

        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            dv = new DistrictVisitsCountModel();

        //            if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
        //                dv.DistrictID = Convert.ToInt32(dr["DepartmentID"].ToString());

        //            if (dt.Columns.Contains("Designation") && !Convert.IsDBNull(dr["Designation"]))
        //                dv.DistrictName = dr["Designation"].ToString() + ", " + dr["Department"].ToString();

        //            if (dt.Columns.Contains("NoOfVisits") && !Convert.IsDBNull(dr["NoOfVisits"]))
        //                dv.VisitsCount = Convert.ToInt32(dr["NoOfVisits"].ToString());

        //            if (dv.VisitsCount >= 1 && dv.VisitsCount <= 3)
        //                dv.Color = "Red";
        //            else if (dv.VisitsCount >= 4 && dv.VisitsCount <= 6)
        //                dv.Color = "Orange";
        //            else
        //                dv.Color = "Green";

        //            colVisitsDistrict.Add(dv);
        //        }

        //        colVisitsDistrict.TrimExcess();
        //    }

        //    return colVisitsDistrict.OrderByDescending(v => v.VisitsCount).ToList();
        //}

        private List<SecretaryContactModel> BuildSecreatryContactList(DataTable dt) 
        {
            List<SecretaryContactModel> lstModel = new List<SecretaryContactModel>();
            SecretaryContactModel model = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    model = new SecretaryContactModel();

                    if (dt.Columns.Contains("UserID") && !Convert.IsDBNull(dr["UserID"]))
                        model.ID = Convert.ToInt32(dr["UserID"].ToString());

                    if (dt.Columns.Contains("EmployeeName") && !Convert.IsDBNull(dr["EmployeeName"]))
                        model.Name = dr["EmployeeName"].ToString();

                    if (dt.Columns.Contains("Department") && !Convert.IsDBNull(dr["Department"]))
                        model.Department = dr["Department"].ToString();

                    if (dt.Columns.Contains("CellNumber") && !Convert.IsDBNull(dr["CellNumber"]))
                        model.CellNumber = dr["CellNumber"].ToString();

                    lstModel.Add(model);
                }

                lstModel.TrimExcess();
            }

            return lstModel;
        }

        private DataTable BuildDesignationIDsTable(List<DesignationModel> DesignationIDs, int UserID)
        {
            DataRow dr = null;
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("ID", typeof(int)));

            if (DesignationIDs.Count > 0)
            {
                foreach (DesignationModel dm in DesignationIDs)
                {
                    if (dm.ID != 0 && dm.Checked)     // skip all value
                    {
                        dr = dt.NewRow();
                        dr["ID"] = dm.ID;

                        dt.Rows.Add(dr);
                    }
                }
            }
            else
            {
                List<DesignationModel> colDesingation = LazyBaseSingletonBLL<DesignationBLL>.Instance.GetUsersDesignations(UserID);

                foreach (DesignationModel designation in colDesingation)
                {
                    if (designation.Checked)
                    {
                        dr = dt.NewRow();
                        dr["ID"] = designation.ID;

                        dt.Rows.Add(dr);
                    }
                }
            }
            

            return dt;
        }

        private List<DistrictVisitsCountModel> BuildVisitCountModelOfficals(DataRow[] Rows)
        {
            List<DistrictVisitsCountModel> colVisitsDistrict = new List<DistrictVisitsCountModel>();
            DistrictVisitsCountModel dv = null;

            if (Rows.Length > 0)
            {
                foreach (DataRow dr in Rows)
                {
                    dv = new DistrictVisitsCountModel();

                    if (!Convert.IsDBNull(dr["UserID"]))
                        dv.DistrictID = Convert.ToInt32(dr["UserID"].ToString());

                    if (!Convert.IsDBNull(dr["EmployeeName"]))
                        dv.DistrictName = dr["EmployeeName"].ToString();

                    if (!Convert.IsDBNull(dr["NoOfVisits"]))
                        dv.VisitsCount = Convert.ToInt32(dr["NoOfVisits"].ToString());

                    if (dr.Table.Columns.Contains("IsVisitLog") && !Convert.IsDBNull(dr["IsVisitLog"]))
                        dv.IsVisitLog = Convert.ToBoolean(dr["IsVisitLog"].ToString());

                    if (dv.VisitsCount >= 1 && dv.VisitsCount <= 3)
                        dv.Color = "Red";
                    else if (dv.VisitsCount >= 4 && dv.VisitsCount <= 6)
                        dv.Color = "Orange";
                    else
                        dv.Color = "Green";

                    colVisitsDistrict.Add(dv);
                }

                colVisitsDistrict.TrimExcess();
            }

            return colVisitsDistrict.OrderByDescending(v => v.VisitsCount).ToList();
        }

        private List<DesignationVisitModel> BuildVisitDesignation(DataTable dt, DataTable dtDesignation)
        {
            List<DesignationVisitModel> colVisits = new List<DesignationVisitModel>();
            DesignationVisitModel dv = null;

            foreach (DataRow dr in dtDesignation.Rows)
            {
                DataRow[] rows = dt.Select("DesignationID = " + dr["ID"].ToString());
                if (rows.Length != 0)
                {
                    dv = new DesignationVisitModel();
                    dv.DesignationID = Convert.ToInt32(rows[0]["DesignationID"]);
                    dv.Title = rows[0]["Designation"].ToString();
                    dv.Visits = BuildVisitCountModelOfficals(rows);

                    dv.Count = dv.Visits.Select(p => p.VisitsCount).Sum();

                    colVisits.Add(dv);
                }
            }

            return colVisits;
        }

        private List<DepartmentVisitLogModel> BuildVisitsRatingModel(DataTable dt)
        {
            List<DepartmentVisitLogModel> allLogs = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                allLogs = new List<DepartmentVisitLogModel>();
                DepartmentVisitLogModel model = null;

                foreach (DataRow dr in dt.Rows)
                {
                    model = new DepartmentVisitLogModel();
                    model.TotalVisits = 0;

                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                        model.DepartmentID = Convert.ToInt32(dr["DepartmentID"]);

                    if (dt.Columns.Contains("Department") && !Convert.IsDBNull(dr["Department"]))
                        model.Department = Convert.ToString(dr["Department"]);

                    if (dt.Columns.Contains("Very Poor") && !Convert.IsDBNull(dr["Very Poor"]))
                        model.VeryPoor = Convert.ToInt32(dr["Very Poor"]);

                    if (dt.Columns.Contains("Poor") && !Convert.IsDBNull(dr["Poor"]))
                        model.Poor = Convert.ToInt32(dr["Poor"]);

                    if (dt.Columns.Contains("Un-satisfactory") && !Convert.IsDBNull(dr["Un-satisfactory"]))
                        model.Unsatisfactory = Convert.ToInt32(dr["Un-satisfactory"]);

                    if (dt.Columns.Contains("Average") && !Convert.IsDBNull(dr["Average"]))
                        model.Average = Convert.ToInt32(dr["Average"]);

                    if (dt.Columns.Contains("Satisfactory") && !Convert.IsDBNull(dr["Satisfactory"]))
                        model.Satisfactory = Convert.ToInt32(dr["Satisfactory"]);

                    if (dt.Columns.Contains("Good") && !Convert.IsDBNull(dr["Good"]))
                        model.Good = Convert.ToInt32(dr["Good"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.Excellent = Convert.ToInt32(dr["Excellent"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.TotalVisits = model.Excellent + model.Good + model.Satisfactory + model.Average + model.Unsatisfactory + model.Poor + model.VeryPoor;

                    allLogs.Add(model);
                }

                allLogs.TrimExcess();
            }

            return allLogs;
        }

        private List<LogDetail> BuildVisitRatingDetailModel(DataTable dt)
        { 
            List<LogDetail> lstDetail = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                lstDetail = new List<LogDetail>();
                LogDetail log = null;

                foreach (DataRow dr in dt.Rows)
                {
                    log = new LogDetail();

                    if (dt.Columns.Contains("Department") && !Convert.IsDBNull(dr["Department"]))
                        log.Department = Convert.ToString(dr["Department"]);

                    if (dt.Columns.Contains("VisitorLogID") && !Convert.IsDBNull(dr["VisitorLogID"]))
                        log.VisitorLogID = Convert.ToInt32(dr["VisitorLogID"]);

                    if (dt.Columns.Contains("Place") && !Convert.IsDBNull(dr["Place"]))
                        log.Place = Convert.ToString(dr["Place"]);

                    if (dt.Columns.Contains("Rated") && !Convert.IsDBNull(dr["Rated"]))
                        log.Rated = Convert.ToString(dr["Rated"]);

                    if (dt.Columns.Contains("RateID") && !Convert.IsDBNull(dr["RateID"]))
                        log.RateID = Convert.ToInt32(dr["RateID"].ToString());

                    if (dt.Columns.Contains("TaskID") && !Convert.IsDBNull(dr["TaskID"]))
                        log.TaskID = Convert.ToInt32(dr["TaskID"].ToString());

                    if (dt.Columns.Contains("StartDate") && !Convert.IsDBNull(dr["StartDate"]))
                        log.StartDate = Convert.ToDateTime(dr["StartDate"].ToString());

                    if (dt.Columns.Contains("HasImage") && !Convert.IsDBNull(dr["HasImage"]))
                        log.HasImage = Convert.ToBoolean(dr["HasImage"].ToString());

                    lstDetail.Add(log);
                }

                lstDetail.TrimExcess();
            }

            return lstDetail;
        }

        private List<DistrictVisitLogModel> BuildVisitsRatingDistrictModel(DataTable dt)
        {
            List<DistrictVisitLogModel> allLogs = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                allLogs = new List<DistrictVisitLogModel>();
                DistrictVisitLogModel model = null;

                foreach (DataRow dr in dt.Rows)
                {
                    model = new DistrictVisitLogModel();
                    model.TotalVisits = 0;

                    if (dt.Columns.Contains("VisitorLogID") && !Convert.IsDBNull(dr["VisitorLogID"]))
                        model.VisitorLogID = Convert.ToInt32(dr["VisitorLogID"]);

                    if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                        model.DivisionID = Convert.ToInt32(dr["DivisionID"]);

                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        model.DistrictID = Convert.ToInt32(dr["DistrictID"]);

                    if (dt.Columns.Contains("Division") && !Convert.IsDBNull(dr["Division"]))
                        model.Division = Convert.ToString(dr["Division"]);

                    if (dt.Columns.Contains("District") && !Convert.IsDBNull(dr["District"]))
                        model.District = Convert.ToString(dr["District"]);

                    if (dt.Columns.Contains("Very Poor") && !Convert.IsDBNull(dr["Very Poor"]))
                        model.VeryPoor = Convert.ToInt32(dr["Very Poor"]);

                    if (dt.Columns.Contains("Poor") && !Convert.IsDBNull(dr["Poor"]))
                        model.Poor = Convert.ToInt32(dr["Poor"]);

                    if (dt.Columns.Contains("Un-satisfactory") && !Convert.IsDBNull(dr["Un-satisfactory"]))
                        model.Unsatisfactory = Convert.ToInt32(dr["Un-satisfactory"]);

                    if (dt.Columns.Contains("Average") && !Convert.IsDBNull(dr["Average"]))
                        model.Average = Convert.ToInt32(dr["Average"]);

                    if (dt.Columns.Contains("Satisfactory") && !Convert.IsDBNull(dr["Satisfactory"]))
                        model.Satisfactory = Convert.ToInt32(dr["Satisfactory"]);

                    if (dt.Columns.Contains("Good") && !Convert.IsDBNull(dr["Good"]))
                        model.Good = Convert.ToInt32(dr["Good"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.Excellent = Convert.ToInt32(dr["Excellent"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.TotalVisits = model.Excellent + model.Good + model.Satisfactory + model.Average + model.Unsatisfactory + model.Poor + model.VeryPoor;

                    allLogs.Add(model);
                }


            }

            return allLogs;
        }

        #endregion
    }
}
