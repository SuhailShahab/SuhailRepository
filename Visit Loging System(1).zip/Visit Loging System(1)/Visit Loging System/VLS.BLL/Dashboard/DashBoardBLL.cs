﻿using BE.Dashboard;
using BE.Lookups;
using BLL.CommonUtility;
using BLL.Lookups;
using DAL.Dashboard;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace BLL.Dashboard
{
    public class DashBoardBLL
    {
        #region "Public Methods"

        /// <summary>
        /// Get assign task 
        /// </summary>
        /// <param name="assignTo">Selected User ID</param>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="searchText">Selected Search Text</param>
        /// <returns>DashBoard Model View</returns>
        public DashBoardModelView GetAssignTask(int userID, int pageNo, int pageSize, string searchText)
        {
            try
            {
                DashBoardModelView mianModel = new DashBoardModelView();
                DataSet ds;

                ds = LazyBaseSingletonDAL<DashBoardDAL>.Instance.GetAssignTask(userID, pageNo, pageSize, searchText);
                mianModel.Tasks = BindData(ds.Tables[0]);
                mianModel.RESULT_COUNT = Convert.ToInt32(ds.Tables[1].Rows[0][0]);
                mianModel = DashBoardStaticCount(mianModel, userID);

                return mianModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Visited task  info
        /// </summary>
        /// <param name="assignTo">Selected User ID</param>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="searchText">Selected Search Text</param>
        /// <returns>DashBoard Model View</returns>
        public DashBoardModelView GetVisitedTask(int userID, int pageNo, int pageSize, string searchText)
        {
            try
            {
                DashBoardModelView mianModel = new DashBoardModelView();
                DataSet ds;

                ds = LazyBaseSingletonDAL<DashBoardDAL>.Instance.GetVisitedTask(userID, pageNo, pageSize, searchText);
                mianModel.Tasks = BindData(ds.Tables[0]);
                mianModel.RESULT_COUNT = Convert.ToInt32(ds.Tables[1].Rows[0][0]);
                mianModel = DashBoardStaticCount(mianModel, userID);
                return mianModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Pending task  info
        /// </summary>
        /// <param name="assignTo">Selected User ID</param>
        /// <param name="pageNo">Selected page no</param>
        /// <param name="pageSize">Selected page size</param>
        /// <param name="searchText">Selected Search Text</param>
        /// <returns>DashBoard Model View</returns>
        public DashBoardModelView GetPendingTask(int userID, int pageNo, int pageSize, string searchText)
        {
            try
            {
                DashBoardModelView mianModel = new DashBoardModelView();
                DataSet ds;

                ds = LazyBaseSingletonDAL<DashBoardDAL>.Instance.GetPendingTask(userID, pageNo, pageSize, searchText);
                mianModel.Tasks = BindData(ds.Tables[0]);
                mianModel.RESULT_COUNT = Convert.ToInt32(ds.Tables[1].Rows[0][0]);
                mianModel = DashBoardStaticCount(mianModel, userID);
                return mianModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DashBoardModelView DashBoardStaticCount(DashBoardModelView mianModel, int userID)
        {
            try
            {
                DataTable dt;

                dt = LazyBaseSingletonDAL<DashBoardDAL>.Instance.GetDashBoardStaticCounts(userID);
                List<StatesCountModel> counts = new List<StatesCountModel>();

                StatesCountModel model = null;

                model = new StatesCountModel();
                model.Count = Convert.ToInt32(dt.Rows[0][0]);
                model.Title = Convert.ToString(dt.Rows[0][2]);
                model.MethodName = "GetDashBoardVisitedForDesignation";
                counts.Add(model);

                model = new StatesCountModel();
                model.Count = Convert.ToInt32(dt.Rows[0][1]);
                model.Title = Convert.ToString(dt.Rows[0][3]);
                model.MethodName = "GetDashBoardAssignTaskForDesignation";
                counts.Add(model);

                //model = new StatesCountModel();
                //model.Count = Convert.ToInt32(dt.Rows[0][2]);
                //model.Title = Convert.ToString(dt.Rows[0][5]);
                //model.MethodName = "GetPendingTask";
                ////model.Title = "ACTION PENDING";
                //actionCounts.Add(model);

                mianModel.Counts = counts;

                // dt = LazyBaseSingletonDAL<DashBoardDAL>.Instance.GetActionTakenCount(userID);
                // List<StatesCountModel> counts = new List<StatesCountModel>();

                // StatesCountModel mod = null;

                // mod = new StatesCountModel();
                // mod.Count = Convert.ToInt32(dt.Rows[0][0]);
                // mod.Title = Convert.ToString(dt.Rows[0][3]);
                //// model.Title = "CONCERN DEPARTMENT";
                // counts.Add(mod);

                // mod = new StatesCountModel();
                // mod.Count = Convert.ToInt32(dt.Rows[0][1]);
                // mod.Title = Convert.ToString(dt.Rows[0][4]);
                // //model.Title = "CONCERN DISTRICT ADMINISTRATION";
                // counts.Add(mod);

                // mod = new StatesCountModel();
                // mod.Count = Convert.ToInt32(dt.Rows[0][2]);
                // mod.Title = Convert.ToString(dt.Rows[0][5]);
                // //model.Title = "CONCERN RPO/DPO";
                // counts.Add(mod);


                // mianModel.ActionCounts = counts;

                return mianModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region "Private Methods"

        /// <summary>
        /// Bind Data from Database
        /// </summary>
        /// <param name="dt">Data Table</param>
        /// <returns></returns>
        private List<DashBoardModel> BindData(DataTable dt)
        {
            List<DashBoardModel> lists = new List<DashBoardModel>();
            if (dt.Rows.Count > 0)
                lists = (List<DashBoardModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DashBoardModel());

            return lists;
        }



        #endregion

        private List<StatesCountModel> BuildRatingCounts(List<DashBoardModel> colVistis)
        {
            List<RatingModel> colRates = (List<RatingModel>)LazyBaseSingletonBLL<RatingBLL>.Instance.GetAllRatings();
            List<StatesCountModel> colRatings = new List<StatesCountModel>();

            var data = from row in colVistis
                       group row by row.RatingName into Rate
                       orderby Rate.Key
                       select new
                       {
                           Title = Rate.Key,
                           Count = Rate.Count()
                       };

            foreach (var e in data)
            {
                StatesCountModel scm = new StatesCountModel();
                scm.Title = e.Title;
                scm.Count = e.Count;

                colRatings.Add(scm);
            }

            foreach (RatingModel r in colRates)
            {
                StatesCountModel scm = colRatings.Where(t => t.Title.ToLower() == r.Title.ToLower()).FirstOrDefault();
                if (scm == null)
                {
                    StatesCountModel sc = new StatesCountModel();
                    sc.Title = r.Title;
                    sc.Count = 0;

                    colRatings.Add(sc);
                }
            }

            if (colRatings.Count > 0) colRatings.TrimExcess();

            return colRatings;
        }
    }
}
