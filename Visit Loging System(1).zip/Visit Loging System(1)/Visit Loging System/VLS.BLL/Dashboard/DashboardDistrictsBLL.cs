﻿using BE.Dashboard;
using BLL.CommonUtility;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using VLS.BE.Dashboard;
using VLS.DAL.Dashboard;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <28-03-2016 03:15:58PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace VLS.BLL.Dashboard
{
    public class DashboardDistrictsBLL
    {
        public List<ChartModel> GetDepartmentVisitsByDistrict(int? DistrictID)
        {
            DataTable dt = LazyBaseSingletonDAL<DashboardDistrictsDAL>.Instance.GetDepartmentVisitsByDistrict(DistrictID);
            return BuildChartModel(dt);
        }

        public List<ChartModel> GetVisitsStatusByDistrict(int? DistrictID)
        {
            DataTable dt = LazyBaseSingletonDAL<DashboardDistrictsDAL>.Instance.GetVisitsStatusByDistrict(DistrictID);
            return BuildChartModel(dt);
        }

        public List<DashBoardModel> GetVisitsLogsDashboardDistrict(int? DistrictID, int PageNo, int PageSize)
        {
            List<DashBoardModel> colVisits = new List<DashBoardModel>();

            DataTable dt = LazyBaseSingletonDAL<DashboardDistrictsDAL>.Instance.GetVisitsLogsDashboardDistrict(DistrictID, PageNo, PageSize);
            if (dt.Rows.Count > 0)
                colVisits = (List<DashBoardModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DashBoardModel());

            return colVisits;
        }

        #region "Private Methods"

        private List<ChartModel> BuildChartModel(DataTable dt)
        {
            List<ChartModel> collection = null;
            ChartModel cm = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    cm = new ChartModel();

                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        cm.Title = dr["Title"].ToString();

                    if (dt.Columns.Contains("Value") && !Convert.IsDBNull(dr["Value"]))
                        cm.Value = Convert.ToInt32(dr["Value"].ToString());

                    if (dt.Columns.Contains("Value2") && !Convert.IsDBNull(dr["Value2"]))
                        cm.Value2 = Convert.ToInt32(dr["Value2"].ToString());

                    if (dt.Columns.Contains("Value3") && !Convert.IsDBNull(dr["Value3"]))
                        cm.Value3 = Convert.ToInt32(dr["Value3"].ToString());

                    collection.Add(cm);
                }

                collection.TrimExcess();
            }

            return collection;
        }

        #endregion
    }
}
