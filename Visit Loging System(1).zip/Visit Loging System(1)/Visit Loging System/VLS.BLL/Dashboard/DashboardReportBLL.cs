﻿using BE.Content;
using BE.Dashboard;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using VLS.BLL.Content;
using VLS.DAL.Dashboard;

// =================================================================================================================================
// Create by:	<Sabeeh Goheer>
// Create date: <25-04-2016 03:15:58PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR :001      Syed Zeeshan Aqil           09-May-2016 03:15:58PM          Add Method  "BuildVisitsRatingDistrictModelLog"  
// CR :002      Syed Zeeshan Aqil           09-May-2016 03:15:58PM          Add Method  "GetDistrictVisitsRatingPerformedBreakdown"  
// CR :003      Syed Zeeshan Aqil           09-May-2016 03:15:58PM          Add Method  "GetDepartmentVisitsRatingPerformedBreakdown"  
// CR :004      Syed Zeeshan Aqil           09-May-2016 03:15:58PM          Add Method  "BuildVisitsRatingDepartmentModelLog"  
// CR :005       Syed Zeeshan Aqil          08-May-2016 5:11 PM             Add Method "GetVisitsLogPictures" to  get visit log the Picture List
// =================================================================================================================================
namespace VLS.BLL.Dashboard
{
    public class DashboardReportBLL
    {
        #region "Public Methods"

        public DashboardReportModelView GetAllVisitsPerformedBreakdown(int? AssignedTo, int? DivisionID, int? DistrictID, int? DepartmentID)
        {
            DashboardReportModelView DashboardReportModelView = new DashboardReportModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsPerformedBreakdown(AssignedTo, DivisionID,DistrictID,DepartmentID);

            if (ds.Tables[0].Rows.Count > 0)
                DashboardReportModelView.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel());

            DashboardReportModelView.DistrictLogs = BuildVisitsDistrictBreakdownModelLog(ds.Tables[1], DashboardReportModelView.RatingHeader);
            DashboardReportModelView.DepartmentLogs = BuildVisitsDepartmentBreakdownModelLog(ds.Tables[2], DashboardReportModelView.RatingHeader);
            return DashboardReportModelView;
        }

        public DashboardReportModelView GetDistrictsWiseVisitsPerformedBreakdown(int? AssignedTo, int? DivisionID, int? DistrictID)
        {
            DashboardReportModelView DashboardReportModelView = new DashboardReportModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDistrictsWiseVisitsPerformedBreakdown(AssignedTo, DivisionID, DistrictID);

            if (ds.Tables[0].Rows.Count > 0)
                DashboardReportModelView.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel());

            DashboardReportModelView.DistrictLogs = BuildVisitsDistrictBreakdownModelLog(ds.Tables[1], DashboardReportModelView.RatingHeader);
            return DashboardReportModelView;
        }

        public DashboardReportModelView GetDepartmentsWiseVisitsPerformedBreakdown(int? AssignedTo, int? DepartmentID)
        {
            DashboardReportModelView DashboardReportModelView = new DashboardReportModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDepartmentsWiseVisitsPerformedBreakdown(AssignedTo, DepartmentID);

            if (ds.Tables[0].Rows.Count > 0)
                DashboardReportModelView.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel());

            DashboardReportModelView.DepartmentLogs = BuildVisitsDepartmentBreakdownModelLog(ds.Tables[1], DashboardReportModelView.RatingHeader);
            return DashboardReportModelView;
        }

        public DashboardReportModelView GetAllVisitsObservedBreakdown(int? DivisionID, int? DistrictID, int? DepartmentID)
        {
            DashboardReportModelView DashboardReportModelView = new DashboardReportModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsObservedBreakdown(DivisionID, DistrictID, DepartmentID);

            if (ds.Tables[0].Rows.Count > 0)
                DashboardReportModelView.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel());

            DashboardReportModelView.DistrictLogs = BuildVisitsDistrictBreakdownModelLog(ds.Tables[1], DashboardReportModelView.RatingHeader);
            DashboardReportModelView.DepartmentLogs = BuildVisitsDepartmentBreakdownModelLog(ds.Tables[2], DashboardReportModelView.RatingHeader);
            return DashboardReportModelView;
        }

        public DashboardReportModelView GetDistrictsWiseVisitsObservedBreakdown(int? DivisionID, int? DistrictID, int? DepartmentID)
        {
            DashboardReportModelView DashboardReportModelView = new DashboardReportModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDistrictsWiseVisitsObservedBreakdown(DivisionID, DistrictID, DepartmentID);

            if (ds.Tables[0].Rows.Count > 0)
                DashboardReportModelView.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel());

            DashboardReportModelView.DistrictLogs = BuildVisitsDistrictBreakdownModelLog(ds.Tables[1], DashboardReportModelView.RatingHeader);
            return DashboardReportModelView;
        }

        public DashboardReportModelView GetDepartmentsWiseVisitsObservedBreakdown(int? UserDepartment, int? DepartmentID)
        {
            DashboardReportModelView DashboardReportModelView = new DashboardReportModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDepartmentsWiseVisitsObservedBreakdown(UserDepartment, DepartmentID);

            if (ds.Tables[0].Rows.Count > 0)
                DashboardReportModelView.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel());

            DashboardReportModelView.DepartmentLogs = BuildVisitsDepartmentBreakdownModelLog(ds.Tables[1], DashboardReportModelView.RatingHeader);
            return DashboardReportModelView;
        }

        public List<LogDetail> GetDistrictRatingLogDetail(int? UserID, int? DivisionID, int? DistrictID, int? RatingID, int? FacilityID)
        {
            List<LogDetail> logDetail = null;
            DataTable dt = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDistrictRatingLogDetail(UserID, DivisionID, DistrictID, RatingID, FacilityID);
            logDetail = BuildModelForDistrictRatingLogDetail(dt);
            return logDetail;
        }

        public List<LogDetail> GetDepartmentRatingLogDetail(int? userID, int? departmentID, int? ratingID)
        {
            List<LogDetail> logDetail = null;
            DataTable dt = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDepartmentRatingLogDetail(userID, departmentID, ratingID);
            logDetail = BuildModelForDistrictRatingLogDetail(dt);
            return logDetail;
        }

        public List<LogDetail> GetDepartmentRatingLogDetailNew(int? userID, int? departmentID, int? ratingID, int? districtID)
        {
            List<LogDetail> logDetail = null;
            DataTable dt = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDepartmentRatingLogDetailNew(userID, departmentID, ratingID, districtID);
            logDetail = BuildModelForDistrictRatingLogDetail(dt);
            return logDetail;
        }

        /// <summary>
        /// Get Most Recent visiting Rating Info
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="departmentID"></param>
        /// <param name="ratingID"></param>
        /// <returns></returns>
        public List<LogDetail> GetDashBoardMostRecentVisitRatingInfo()
        {
            List<LogDetail> logDetail = null;

            DataTable dt = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDashBoardMostRecentVisitRatingInfo();
            logDetail = BuildModelForDistrictRatingLogDetail(dt);
            return logDetail;
        }

        

        public List<LogDetail> GetDistrictRatingObservedLogDetail(int? DepartmentID, int? divisionID, int? districtID, int? ratingID)
        {
            List<LogDetail> logDetail = null;
            DataTable dt = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDistrictRatingObservedLogDetail(DepartmentID, divisionID, districtID, ratingID);
            logDetail = BuildModelForDistrictRatingLogDetail(dt);
            return logDetail;
        }

        public List<LogDetail> GetDepartmentRatingObservedLogDetail(int? userDepartmentID, int? departmentID, int? ratingID)
        {
            List<LogDetail> logDetail = null;
            DataTable dt = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDepartmentRatingObservedLogDetail(userDepartmentID, departmentID, ratingID);
            logDetail = BuildModelForDistrictRatingLogDetail(dt);
            return logDetail;
        }

        //public List<LogDetail> GetDepartmentRatingObservedLogDetailNew(int? userDepartmentID, int? departmentID, int? ratingID, int? districtID)
        //{
        //    List<LogDetail> logDetail = null;
        //    DataTable dt = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDepartmentRatingObservedLogDetailNew (userDepartmentID, departmentID, ratingID,  districtID);
        //    logDetail = BuildModelForDistrictRatingLogDetail(dt);
        //    return logDetail;
        //}




        #region "Performed Visted Info"  

        /// <summary>
        /// Get the Rating information on district and department wise
        /// </summary>
        /// <param name="AssignedTo">Created Visit person ID</param>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="DistrictID">selected district ID</param>
        /// <param name="DepartmentID">selected DepartmentID</param>
        /// <returns></returns>
        public DashboardRatingModelView GetVisitsRatingPerformedBreakdown(int? AssignedTo, int? DivisionID, int? DistrictID, int? DepartmentID, int? FacilityID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();

            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsRatingPerformedBreakdown(AssignedTo, DivisionID, DistrictID, DepartmentID, FacilityID);

            model.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables["Rating"], new RatingModel());        // build rating model
            model.DistrictLogs = BuildVisitsRatingDistrictModelLog(ds.Tables["DistrictVisits"]);

            //model.DepartmentLogs = BuildVisitsRatingDepartmentModelLog(ds.Tables[2]);
            
            return model;
        }

        /// <summary>
        /// Get the rating on the district wise
        /// </summary>
        /// <param name="AssignedTo">selected user ID</param>
        /// <param name="DivisionID">selected devision ID</param>
        /// <param name="DistrictID">selected District ID</param>
        /// <param name="DepartmentID">selected department ID</param>
        /// <returns></returns>
        public DashboardRatingModelView GetDistrictVisitsRatingPerformedBreakdown(int? AssignedTo, int? DivisionID, int? DistrictID, int? DepartmentID, int? FacilityID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();
            
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsRatingPerformedBreakdown(AssignedTo, DivisionID, DistrictID, DepartmentID, FacilityID);

            model.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables["Rating"], new RatingModel());     // build rating model
            model.DistrictLogs = BuildVisitsRatingDistrictModelLog(ds.Tables["DistrictVisits"]);
           // model.DepartmentLogs = BuildVisitsRatingDepartmentModelLog(ds.Tables[2]);

            return model;
        }

        /// <summary>
        /// Get the rating on the Designation wise
        /// </summary>
        /// <param name="DesignationID">selected DesignationID</param>
        /// <returns></returns>
        public DashboardRatingModelView GetDesignationsWiseVisitsPerformedBreakdown(int? DesignationID, int? FacilityID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetDesignationVisitsRatingPerformedBreakdown(DesignationID, FacilityID);

            model.DesignationLogs = BuildVisitsRatingDesignationModelLog(ds.Tables[1]);
            return model;
        }

        /// <summary>
        /// Get the rating on the department wise
        /// </summary>
        /// <param name="assignedTo">selected user ID</param>
        /// <param name="divisionID">selected devision ID</param>
        /// <param name="districtID">selected District ID</param>
        /// <param name="departmentID">selected department ID</param>
        /// <returns></returns>
        public DashboardRatingModelView GetDepartmentVisitsRatingPerformedBreakdown(int? assignedTo, int? divisionID, int? districtID, int? departmentID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsRatingPerformedBreakdown(assignedTo, divisionID, districtID, departmentID, null);

            model.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel()); 
           // model.DistrictLogs = BuildVisitsRatingDistrictModelLog(ds.Tables[1]);
             model.DepartmentLogs = BuildVisitsRatingDepartmentModelLog(ds.Tables[2]);
            return model;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="assignedTo"></param>
        /// <param name="divisionID"></param>
        /// <param name="districtID"></param>
        /// <param name="departmentID"></param>
        /// <returns></returns>
        public DashboardRatingModelView GetDepartmentVisitsRatingPerformedBreakdownExt(int? assignedTo, int? divisionID, int? districtID, int? departmentID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsRatingPerformedBreakdownExt (assignedTo, divisionID, districtID, departmentID);

            model.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel());
            // model.DistrictLogs = BuildVisitsRatingDistrictModelLog(ds.Tables[1]);
            model.DepartmentLogs = BuildVisitsRatingDepartmentModelLog(ds.Tables[2]);
            return model;
        }


        #endregion

        #region "Observation Visted Info"

        /// <summary>
        /// Get the Rating information on district and department wise
        /// </summary>
        /// <param name="AssignedTo">Created Visit person ID</param>
        /// <param name="DivisionID">selected division ID</param>
        /// <param name="districtID">selected district ID</param>
        /// <param name="departmentID">selected DepartmentID</param>
        /// <returns></returns>
        public DashboardRatingModelView GetVisitsRatingObservationBreakdown(int? assignedTo, int? divisionID, int? districtID, int? departmentID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsRatingObservationBreakdown(assignedTo, divisionID, districtID, departmentID);

            model.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel()); 
            model.DistrictLogs = BuildVisitsRatingDistrictModelLog(ds.Tables[1]);
            model.DepartmentLogs = BuildVisitsRatingDepartmentModelLog(ds.Tables[2]);
            return model;
        }

        /// <summary>
        /// Get the rating on the district wise
        /// </summary>
        /// <param name="assignedTo">selected user ID</param>
        /// <param name="divisionID">selected devision ID</param>
        /// <param name="districtID">selected District ID</param>
        /// <param name="departmentID">selected department ID</param>
        /// <returns></returns>
        public DashboardRatingModelView GetDistrictVisitsRatingObservationBreakdown(int? assignedTo, int? divisionID, int? districtID, int? departmentID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsRatingObservationBreakdown(assignedTo, divisionID, districtID, departmentID);

            model.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel()); 
            model.DistrictLogs = BuildVisitsRatingDistrictModelLog(ds.Tables[1]);
            return model;
        }


        /// <summary>
        /// Get the rating on the department wise
        /// </summary>
        /// <param name="assignedTo">selected user ID</param>
        /// <param name="divisionID">selected devision ID</param>
        /// <param name="districtID">selected District ID</param>
        /// <param name="departmentID">selected department ID</param>
        /// <returns></returns>
        public DashboardRatingModelView GetDepartmentVisitsRatingObservationBreakdown(int? assignedTo, int? divisionID, int? districtID, int? departmentID)
        {
            DashboardRatingModelView model = new DashboardRatingModelView();
            DataSet ds = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsRatingObservationBreakdown(assignedTo, divisionID, districtID, departmentID);

            model.RatingHeader = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(ds.Tables[0], new RatingModel()); 
            model.DepartmentLogs = BuildVisitsRatingDepartmentModelLog(ds.Tables[2]);
            return model;
        }

        #endregion


        #region "Get Visit Log  Picture Information"


        /// <summary>
        /// // CR :005  
        /// </summary>
        /// <param name="visitlogID">selected visitor Log ID</param>
        /// <returns></returns>
        public List<ActionImageModel> GetVisitsLogPictures(int visitorLogID)
        {
            try
            {
                List<ActionImageModel> models = new List<ActionImageModel>();

                DataTable dt = LazyBaseSingletonDAL<DashboardReportDAL>.Instance.GetVisitsLogPictures(visitorLogID);
                models = LazyBaseSingletonBLL<ActionDetailBLL>.Instance.BindImageList(dt);

                return models;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion
        #endregion

        #region "Private Methods"

        private List<DistrictLogModel> BuildVisitsDistrictBreakdownModelLog(DataTable dt, List<RatingModel> lstRatingModel)
        {
            List<DistrictLogModel> allLogs = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                allLogs = new List<DistrictLogModel>();
                DistrictLogModel model = null;
                int tempDistrictID = 0;

                foreach (DataRow dr in dt.Rows)
                {
                    //If Next Dsitrict 
                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]) && (Convert.ToInt32(dr["DistrictID"]) != tempDistrictID))
                    {
                        if (model != null)
                            FillEmptyRatingModelListForDistricts(model, lstRatingModel);
                        model = null;
                        model = new DistrictLogModel();
                        model.Rating = new List<RatingModel>();
                        model.TotalVisits = 0;

                        if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                            model.DivisionID = Convert.ToInt32(dr["DivisionID"]);

                        if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                            model.DistrictID = Convert.ToInt32(dr["DistrictID"]);

                        if (dt.Columns.Contains("Division") && !Convert.IsDBNull(dr["Division"]))
                            model.Division = Convert.ToString(dr["Division"]);

                        if (dt.Columns.Contains("District") && !Convert.IsDBNull(dr["District"]))
                            model.District = Convert.ToString(dr["District"]);
                    }

                    RatingModel rtModel = new RatingModel();
                    if (dt.Columns.Contains("RateID") && !Convert.IsDBNull(dr["RateID"]) && dt.Columns.Contains("Rating") && !Convert.IsDBNull(dr["Rating"]))
                    {
                        rtModel.ID = Convert.ToInt32(dr["RateID"]);
                        rtModel.Title = Convert.ToString(dr["Rating"]);
                    }

                    if (dt.Columns.Contains("TotalCount") && !Convert.IsDBNull(dr["TotalCount"]))
                    {
                        model.TotalVisits += Convert.ToInt32(dr["TotalCount"]);
                        rtModel.VisitCount = Convert.ToInt32(dr["TotalCount"]);
                    }

                    model.Rating.Add(rtModel);

                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]) && (Convert.ToInt32(dr["DistrictID"]) != tempDistrictID))
                    {
                        allLogs.Add(model);
                        tempDistrictID = model.DistrictID;
                    }
                    if (dt.Rows.IndexOf(dr) == dt.Rows.Count - 1)
                    {
                        FillEmptyRatingModelListForDistricts(model, lstRatingModel);   
                    }
                }
            }

            return allLogs;
        }

        private List<DepartmentLogModel> BuildVisitsDepartmentBreakdownModelLog(DataTable dt, List<RatingModel> lstRatingModel)
        {
            List<DepartmentLogModel> allLogs = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                allLogs = new List<DepartmentLogModel>();
                DepartmentLogModel model = null;
                int tempDeptID = 0;

                foreach (DataRow dr in dt.Rows)
                {

                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]) && (Convert.ToInt32(dr["DepartmentID"]) != tempDeptID))
                    {
                        if (model != null)
                            FillEmptyRatingModelListForDivision(model, lstRatingModel);
                        model = new DepartmentLogModel();
                        model.Rating = new List<RatingModel>();
                        model.TotalVisits = 0;

                        if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                            model.DepartmentID = Convert.ToInt32(dr["DepartmentID"]);

                        if (dt.Columns.Contains("Department") && !Convert.IsDBNull(dr["Department"]))
                            model.Department = Convert.ToString(dr["Department"]);
                    }

                    RatingModel rtModel = new RatingModel();
                    if (dt.Columns.Contains("RateID") && !Convert.IsDBNull(dr["RateID"]) && dt.Columns.Contains("Rating") && !Convert.IsDBNull(dr["Rating"]))
                    {
                        rtModel.ID = Convert.ToInt32(dr["RateID"]);
                        rtModel.Title = Convert.ToString(dr["Rating"]);
                    }

                    if (dt.Columns.Contains("TotalCount") && !Convert.IsDBNull(dr["TotalCount"]))
                    {
                        model.TotalVisits += Convert.ToInt32(dr["TotalCount"]);
                        rtModel.VisitCount = Convert.ToInt32(dr["TotalCount"]);
                    }

                    model.Rating.Add(rtModel);

                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]) && (Convert.ToInt32(dr["DepartmentID"]) != tempDeptID))
                    {
                        allLogs.Add(model);
                        tempDeptID = model.DepartmentID;
                    }
                    if (dt.Rows.IndexOf(dr) == dt.Rows.Count - 1)
                    {
                        FillEmptyRatingModelListForDivision(model, lstRatingModel);
                    }
                }
            }

            return allLogs;
        }

        private void FillEmptyRatingModelListForDistricts(DistrictLogModel model, List<RatingModel> lstRatingModel)
        {
            foreach (RatingModel r in lstRatingModel)
            {
                var rt = model.Rating.Where(t => t.Title.ToLower() == r.Title.ToLower()).FirstOrDefault();
                if (rt == null)
                {
                    RatingModel ratingObj = new RatingModel();
                    ratingObj.ID = r.ID;
                    ratingObj.Title = r.Title;
                    ratingObj.VisitCount = 0;

                    model.Rating.Add(ratingObj);
                }
            }
            model.Rating = model.Rating.OrderBy(r => r.ID).ToList();
        }

        private void FillEmptyRatingModelListForDivision(DepartmentLogModel model, List<RatingModel> lstRatingModel)
        {
            foreach (RatingModel r in lstRatingModel)
            {
                var rt = model.Rating.Where(t => t.Title.ToLower() == r.Title.ToLower()).FirstOrDefault();
                if (rt == null)
                {
                    RatingModel ratingObj = new RatingModel();
                    ratingObj.ID = r.ID;
                    ratingObj.Title = r.Title;
                    ratingObj.VisitCount = 0;

                    model.Rating.Add(ratingObj);
                }
            }
            model.Rating = model.Rating.OrderBy(r => r.ID).ToList();
        }

        private List<LogDetail> BuildModelForDistrictRatingLogDetail(DataTable dt)
        {
            List<LogDetail> lstDetail = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                lstDetail = new List<LogDetail>();
                LogDetail log = null;

                foreach(DataRow dr in dt.Rows)
                {
                    log = new LogDetail();

                    if (dt.Columns.Contains("Department") && !Convert.IsDBNull(dr["Department"]))
                        log.Department = Convert.ToString(dr["Department"]);

                    if (dt.Columns.Contains("VisitorLogID") && !Convert.IsDBNull(dr["VisitorLogID"]))
                        log.VisitorLogID = Convert.ToInt32(dr["VisitorLogID"]);

                    if (dt.Columns.Contains("Place") && !Convert.IsDBNull(dr["Place"]))
                        log.Place = Convert.ToString(dr["Place"]);

                    if (dt.Columns.Contains("Rated") && !Convert.IsDBNull(dr["Rated"]))
                        log.Rated = Convert.ToString(dr["Rated"]);

                    if (dt.Columns.Contains("RateID") && !Convert.IsDBNull(dr["RateID"]))
                        log.RateID = Convert.ToInt32(dr["RateID"].ToString());

                    if (dt.Columns.Contains("TaskID") && !Convert.IsDBNull(dr["TaskID"]))
                        log.TaskID = Convert.ToInt32(dr["TaskID"].ToString());

                    if (dt.Columns.Contains("StartDate") && !Convert.IsDBNull(dr["StartDate"]))
                        log.StartDate = Convert.ToDateTime(dr["StartDate"].ToString());

                    if (dt.Columns.Contains("HasImage") && !Convert.IsDBNull(dr["HasImage"]))
                        log.HasImage = Convert.ToBoolean(dr["HasImage"].ToString());

                    lstDetail.Add(log);
                }
                lstDetail.TrimExcess();
            }

            return lstDetail;
        }



        /// <summary>
        /// // CR :001
        /// Bind the Rating model District wise
        /// </summary>
        /// <param name="dt">selected datatable</param>
        /// <returns>District visited Log Model</returns>
        private List<DistrictVisitLogModel> BuildVisitsRatingDistrictModelLog(DataTable dt)
        {
            List<DistrictVisitLogModel> allLogs = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                allLogs = new List<DistrictVisitLogModel>();
                DistrictVisitLogModel model = null;

                foreach (DataRow dr in dt.Rows)
                {
                    model = new DistrictVisitLogModel();
                    model.TotalVisits = 0;

                    if (dt.Columns.Contains("VisitorLogID") && !Convert.IsDBNull(dr["VisitorLogID"]))
                        model.VisitorLogID = Convert.ToInt32(dr["VisitorLogID"]);

                    if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                        model.DivisionID = Convert.ToInt32(dr["DivisionID"]);

                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        model.DistrictID = Convert.ToInt32(dr["DistrictID"]);

                    if (dt.Columns.Contains("Division") && !Convert.IsDBNull(dr["Division"]))
                        model.Division = Convert.ToString(dr["Division"]);

                    if (dt.Columns.Contains("District") && !Convert.IsDBNull(dr["District"]))
                        model.District = Convert.ToString(dr["District"]);

                    if (dt.Columns.Contains("Very Poor") && !Convert.IsDBNull(dr["Very Poor"]))
                        model.VeryPoor = Convert.ToInt32(dr["Very Poor"]);

                    if (dt.Columns.Contains("Poor") && !Convert.IsDBNull(dr["Poor"]))
                        model.Poor = Convert.ToInt32(dr["Poor"]);

                    if (dt.Columns.Contains("Un-satisfactory") && !Convert.IsDBNull(dr["Un-satisfactory"]))
                        model.Unsatisfactory = Convert.ToInt32(dr["Un-satisfactory"]);

                    if (dt.Columns.Contains("Average") && !Convert.IsDBNull(dr["Average"]))
                        model.Average = Convert.ToInt32(dr["Average"]);

                    if (dt.Columns.Contains("Satisfactory") && !Convert.IsDBNull(dr["Satisfactory"]))
                        model.Satisfactory = Convert.ToInt32(dr["Satisfactory"]);

                    if (dt.Columns.Contains("Good") && !Convert.IsDBNull(dr["Good"]))
                        model.Good = Convert.ToInt32(dr["Good"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.Excellent = Convert.ToInt32(dr["Excellent"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.TotalVisits = model.Excellent + model.Good + model.Satisfactory + model.Average + model.Unsatisfactory + model.Poor + model.VeryPoor;

                    allLogs.Add(model);
                }
               
                  
            }

            return allLogs;
        }

        /// <summary>
        /// // CR :002
        /// Bind the Rating model Department wise
        /// </summary>
        /// <param name="dt">selected datatable</param>
        /// <returns>Department visited Log Model</returns>
        private List<DepartmentVisitLogModel> BuildVisitsRatingDepartmentModelLog(DataTable dt)
        {
            List<DepartmentVisitLogModel> allLogs = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                allLogs = new List<DepartmentVisitLogModel>();
                DepartmentVisitLogModel model = null;

                foreach (DataRow dr in dt.Rows)
                {
                    model = new DepartmentVisitLogModel();
                    model.TotalVisits = 0;

                    if (dt.Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                        model.DepartmentID = Convert.ToInt32(dr["DepartmentID"]);

                    if (dt.Columns.Contains("Department") && !Convert.IsDBNull(dr["Department"]))
                        model.Department = Convert.ToString(dr["Department"]);

                    if (dt.Columns.Contains("Very Poor") && !Convert.IsDBNull(dr["Very Poor"]))
                        model.VeryPoor = Convert.ToInt32(dr["Very Poor"]);

                    if (dt.Columns.Contains("Poor") && !Convert.IsDBNull(dr["Poor"]))
                        model.Poor = Convert.ToInt32(dr["Poor"]);

                    if (dt.Columns.Contains("Un-satisfactory") && !Convert.IsDBNull(dr["Un-satisfactory"]))
                        model.Unsatisfactory = Convert.ToInt32(dr["Un-satisfactory"]);

                    if (dt.Columns.Contains("Average") && !Convert.IsDBNull(dr["Average"]))
                        model.Average = Convert.ToInt32(dr["Average"]);

                    if (dt.Columns.Contains("Satisfactory") && !Convert.IsDBNull(dr["Satisfactory"]))
                        model.Satisfactory = Convert.ToInt32(dr["Satisfactory"]);

                    if (dt.Columns.Contains("Good") && !Convert.IsDBNull(dr["Good"]))
                        model.Good = Convert.ToInt32(dr["Good"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.Excellent = Convert.ToInt32(dr["Excellent"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.TotalVisits = model.Excellent + model.Good + model.Satisfactory + model.Average + model.Unsatisfactory + model.Poor + model.VeryPoor;
                    allLogs.Add(model);
                }

              
            }

            return allLogs;
        }


        /// <summary>
        /// // CR :002
        /// Bind the Rating model Designation wise
        /// </summary>
        /// <param name="dt">selected datatable</param>
        /// <returns>Designation visited Log Model</returns>
        private List<DesignationVisitLogModel> BuildVisitsRatingDesignationModelLog(DataTable dt)
        {
            List<DesignationVisitLogModel> allLogs = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                allLogs = new List<DesignationVisitLogModel>();
                DesignationVisitLogModel model = null;

                foreach (DataRow dr in dt.Rows)
                {
                    model = new DesignationVisitLogModel();
                    model.TotalVisits = 0;

                    if (dt.Columns.Contains("UserID") && !Convert.IsDBNull(dr["UserID"]))
                        model.UserID = Convert.ToInt32(dr["UserID"]);

                    if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                        model.EmployeeName = Convert.ToString(dr["Name"]);

                    if (dt.Columns.Contains("Very Poor") && !Convert.IsDBNull(dr["Very Poor"]))
                        model.VeryPoor = Convert.ToInt32(dr["Very Poor"]);

                    if (dt.Columns.Contains("Poor") && !Convert.IsDBNull(dr["Poor"]))
                        model.Poor = Convert.ToInt32(dr["Poor"]);

                    if (dt.Columns.Contains("Un-satisfactory") && !Convert.IsDBNull(dr["Un-satisfactory"]))
                        model.Unsatisfactory = Convert.ToInt32(dr["Un-satisfactory"]);

                    if (dt.Columns.Contains("Average") && !Convert.IsDBNull(dr["Average"]))
                        model.Average = Convert.ToInt32(dr["Average"]);

                    if (dt.Columns.Contains("Satisfactory") && !Convert.IsDBNull(dr["Satisfactory"]))
                        model.Satisfactory = Convert.ToInt32(dr["Satisfactory"]);

                    if (dt.Columns.Contains("Good") && !Convert.IsDBNull(dr["Good"]))
                        model.Good = Convert.ToInt32(dr["Good"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.Excellent = Convert.ToInt32(dr["Excellent"]);

                    if (dt.Columns.Contains("Excellent") && !Convert.IsDBNull(dr["Excellent"]))
                        model.TotalVisits = model.Excellent + model.Good + model.Satisfactory + model.Average + model.Unsatisfactory + model.Poor + model.VeryPoor;
                    allLogs.Add(model);
                }


            }

            return allLogs;
        }


        #endregion
    }
}
