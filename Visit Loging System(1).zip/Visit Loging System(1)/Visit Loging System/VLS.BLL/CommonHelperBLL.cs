﻿
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <27-05-2015 03:08:41PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR:001       Syed Zeeshan Aqil           23/Feb/2016 3:11 PM             Add Method  BuildADPFormulationPlanDataTable  to Build the DataTable   
// =================================================================================================================================
namespace BLL
{
    public class CommonHelperBLL
    {
        /// <summary>
        /// Get provide page access rights against provided login name
        /// </summary>
        /// <param name="LoginName"></param>
        /// <param name="Page"></param>
        /// <returns></returns>
        public bool GetUserPageAccessRights(string LoginName, string Page)
        {
            return new CommonDAL().GetUserPageAccessRights(LoginName, Page);
        }

        /// <summary>
        /// Check record existance according to provided parameters
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="ColumnName"></param>
        /// <param name="Value"></param>
        /// <param name="Caluse"></param>
        /// <returns></returns>
        public bool IsRecordExist(string TableName, string ColumnName, string Value, string Caluse)
        {
            return new CommonDAL().GetRecordVerify(TableName, ColumnName, Value, Caluse);
        }

       


  

        public int[] GetList(DataTable dt,string columnName)
        {
            List<int> list = new List<int>();
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    if (dt.Columns.Contains(columnName) && !Convert.IsDBNull(dr[columnName]))
                        list.Add(Convert.ToInt32(dr[columnName]));
                }
            }

            return list.ToArray();

        }




    }
}
