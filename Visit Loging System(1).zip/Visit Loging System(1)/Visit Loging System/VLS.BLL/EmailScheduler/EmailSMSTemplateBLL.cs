﻿using BE.EmailScheduler;
using BLL.CommonUtility;
using DAL.EmailScheduler;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.EmailScheduler
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <07-06-2016 11:41AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
  
   public  class EmailSMSTemplateBLL
    {
       public EmailSMSTemplateModel GetEmailSMSTemplateByID(int? templateID)
       {
           try
           {
               DataTable dt= LazyBaseSingletonDAL<EmailSMSTemplateDAL>.Instance.GetEmailSMSTemplateByID(templateID);
               List<EmailSMSTemplateModel> records = (List<EmailSMSTemplateModel>)LazyBaseSingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new EmailSMSTemplateModel());
               if (records != null && records.Count > 0)
                   return records[0];
           }
           catch(Exception ex)
           {
               throw ex;
           }
           return null;
       }
    }
}
