﻿using BE.EmailScheduler;
using BLL.CommonUtility;
using DAL.EmailScheduler;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.EmailScheduler
{
  public  class NotVisitLogBLL
    {

      public int? AddNotVistLog(int? noOfDays)
      {
          try
          {

              return LazyBaseSingletonDAL<NotVisitLogDAL>.Instance.AddNotVistLog(noOfDays);
          }
          catch (Exception ex)
          {

              throw ex;
          }


      }

      public int? UpdateStatus(NotVisitLogModel model)
      {
          try
          {
              return LazyBaseSingletonDAL<NotVisitLogDAL>.Instance.UpdateStatus(model);
          }
          catch (Exception ex)
          {

              throw ex;
          }

      }

      public List<NotVisitLogModel> GetAllNewNotVisitLogs(int? topRecord)
      {
          DataTable dt = null;
          try
          {
              dt = LazyBaseSingletonDAL<NotVisitLogDAL>.Instance.GetAllNewNotVisitLogs(topRecord);
              return BindData(dt);
          }
          catch (Exception ex)
          {
              throw ex;
          }

      }


      public int? DeleteAllSendEmail(int? noOfDays)
      {
          int? result = null;

          try
          {
              result = LazyBaseSingletonDAL<NotVisitLogDAL>.Instance.DeleteAll(noOfDays);
              return result;
          }
          catch (Exception ex)
          {
              throw ex;
          }

          
      }


      public bool? IsNewNotVistLogExist()
      {

          try
          {
              return LazyBaseSingletonDAL<NotVisitLogDAL>.Instance.IsExist();

          }
          catch (Exception ex)
          {
              throw ex;
          }



      }


      #region "internal and Private Methods"


      internal List<NotVisitLogModel> BindData(DataTable dt)
      {
          List<NotVisitLogModel> lists = null; ;

          if (dt.Rows.Count > 0)

              lists = (List<NotVisitLogModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new NotVisitLogModel());

          return lists;
      }

      #endregion


    }
}
