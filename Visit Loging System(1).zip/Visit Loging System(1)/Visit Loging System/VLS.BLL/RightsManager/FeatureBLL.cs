﻿
using BE.CustomEnums;
using BE.RigthManager;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.RightsManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace BLL.RightsManager
{
   public class FeatureBLL
    {

       /// <summary>
       /// Save Method
       /// </summary>
       /// <param name="featuresModel"></param>
       /// <returns></returns>
       public int Save(FeaturesModel featuresModel)
       {
           CommonBLL commonBLL = new CommonBLL();
           if (featuresModel.ID > 0)
           {
               if (commonBLL.IsExist(TableName.tblAppFeatures, ColumnName.MenuName, featuresModel.MenuName, commonBLL.GetClause(ColumnName.AppFeatureID, featuresModel.ID)))
               {
                   throw new Exception(CustomMsg.DuplicateTitle);
               }
               return  LazyBaseSingletonDAL<FeaturesDAL>.Instance.Edit(featuresModel);
             
           }
           else if (commonBLL.IsExist(TableName.tblAppFeatures, ColumnName.MenuName, featuresModel.MenuName, null))
           {
               throw new Exception(CustomMsg.DuplicateTitle);
           }

           else
               return LazyBaseSingletonDAL<FeaturesDAL>.Instance.Add(featuresModel);
             
       }

        /// <summary>
        /// Get all UserTypes Info
        /// </summary>
        /// <returns>result of City in CityModel class</returns
       public List<FeaturesModel> GetFeaturesByLocation(int location)
        {
            DataTable dt = null;
            dt = new FeaturesDAL().GetAllFeaturesByLocation(location);
            return BuildModel(dt);
        }


       /// <summary>
       /// Getting All App Features
       /// </summary>
       /// <returns></returns>
       public List<FeaturesModel> GetFeature()
       {
           DataTable dt = null;
           dt = new FeaturesDAL().GetFeature();
           return BuildModel(dt);
       }

       /// <summary>
       /// Getting All App Features
       /// </summary>
       /// <returns></returns>
       public List<FeaturesModel> GetFeatures()
       {
           DataTable dt = null;
           dt = new FeaturesDAL().GetFeatures();
           return BuildModel(dt);
       }


       /// <summary>
       /// Get all Role base CSR Menu/Feature
       /// </summary>
       /// <returns>result of Feature in FeaturesModel class</returns>
       public List<FeaturesModel> GetCSRMenuByUserID(int userID)
       {
           DataTable dt = null;
           dt = new FeaturesDAL().GetCSRMenuByID(userID);
           return BuildModel(dt);
       }
       /// <summary>
       /// Bind the City Model with Data Table
       /// </summary>
       /// <param name="dt"></param>
       /// <returns>CityModel class</returns>
       internal List<FeaturesModel> BuildModel(DataTable dt)
       {
           List<FeaturesModel> featuresModel = null;

           if (dt != null && dt.Rows.Count > 0)
           {
               featuresModel = new List<FeaturesModel>();
               foreach (DataRow dr in dt.Rows)
               {
                   FeaturesModel featureModel = new FeaturesModel();
                   if (dt.Columns.Contains("AppFeatureID") && !Convert.IsDBNull(dr["AppFeatureID"]))
                       featureModel.ID = Convert.ToInt32(dr["AppFeatureID"]);
                   if (dt.Columns.Contains("MenuName") && !Convert.IsDBNull(dr["MenuName"]))
                       featureModel.MenuName  = Convert.ToString(dr["MenuName"]);
                   if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                       featureModel.Name = Convert.ToString(dr["Name"]);
                   if (dt.Columns.Contains("URL") && !Convert.IsDBNull(dr["URL"]))
                       featureModel.Url = Convert.ToString(dr["URL"]);
                   if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                       featureModel.Description = Convert.ToString(dr["Description"]);
                   if (dt.Columns.Contains("HasChild") && !Convert.IsDBNull(dr["HasChild"]))
                       featureModel.HasChild = Convert.ToInt32(dr["HasChild"]) == 1 ? true : false;
                   if (dt.Columns.Contains("menuLocation") && !Convert.IsDBNull(dr["menuLocation"]))
                       featureModel.menuLocation = Convert.ToInt32(dr["menuLocation"]);
                   if (dt.Columns.Contains("Sort") && !Convert.IsDBNull(dr["Sort"]))
                       featureModel.Sort = Convert.ToInt32(dr["Sort"]);
                   if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                       featureModel.IsActive = Convert.ToBoolean(dr["IsActive"]);
                 
                   featuresModel.Add(featureModel);
               }

               featuresModel.TrimExcess();
           }

           return featuresModel;
       }
    }
}
