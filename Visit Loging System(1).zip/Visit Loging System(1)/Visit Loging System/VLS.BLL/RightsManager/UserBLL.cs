﻿using BE.CustomEnums;
using BE.RigthManager;
using BLL.CommonUtility;
using BLL.CustomExceptions;
using DAL.Generic;
using DAL.RightsManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Text;

// =================================================================================================================================
// Create by:	<Suhial Shahab>
// Create date: <16-02-2014 12:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
namespace BLL.RightsManager
{
    public class UserBLL
    {
        /// <summary>
        ///  CR: 003
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        public int Save(UserRegistration user)
        {
            try
            {
                return LazyBaseSingletonDAL<UserDAL>.Instance.Add(user, user.CreatedBy);
                // return new UserDAL().Add(user, user.CreatedBy);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int Update(UserRegistration user)
        {
            try
            {
                return new UserDAL().Edit(user, user.CreatedBy);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int Delete(int UserID)
        {
            return new UserDAL().Delete(UserID);
        }

        public DataSet GetUserByID(int UserID)
        {
            return new UserDAL().SelectUserByID(UserID);
        }

        public DataSet GetRegisterUserInfoByUserID(int? userId)
        {
            DataSet ds = new DataSet();
            try
            {
                ds = LazyBaseSingletonDAL<UserDAL>.Instance.GetRegisterUserInfoByUserID(userId);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UserModel> GetReportingUsers(int? userID, int? departmentID)
        {
            try
            {
                DataTable dt = LazyBaseSingletonDAL<UserDAL>.Instance.GetReportingUsers(userID, departmentID);
                List<UserModel> users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                return users;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UserModelView> GetUsersLoginNameInfo()
        {
            DataSet ds = new UserDAL().GetUsersLoginNameInfo();
            return BuildModelCollection(ds.Tables[0]);
        }

        public VisitConcernUser GetUsersToSendEmailAndSMS(int? userID,int? districtID,int? divisionID, int? departmentID)
        {
            try
            {
                VisitConcernUser visitConcernUser = new VisitConcernUser();
                DataSet ds = LazyBaseSingletonDAL<UserDAL>.Instance.GetUsersToSendEmailAndSMS(userID,districtID,divisionID, departmentID);
                //Vistor User
                DataTable dt = ds.Tables[0];
                List<UserModel> users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    visitConcernUser.Visiter = users[0];
                }
                //Secretary of Department
                dt = ds.Tables[1];
                users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    visitConcernUser.Secretary = users[0];
                }

                //Secretary of Department
                dt = ds.Tables[2];
                users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    visitConcernUser.SecretaryReportingUsers = users;
                }


                //DCO of that location obervation log
                dt = ds.Tables[3];
                users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    visitConcernUser.DCO = users[0];
                }

                //Commissioner of that location obervation log
                dt = ds.Tables[4];
                users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    visitConcernUser.Commissioner = users[0];
                }

                return visitConcernUser;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public UserModel GetUserInfoForSendingSMSansEmail(int? userID)
        {
           DataTable dt =new DataTable();
            try
            {
                dt = LazyBaseSingletonDAL<UserDAL>.Instance.GetUserInfoForSendSMSandEmail(userID);
                List<UserModel> users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if(users!=null && users.Count>0)
                {
                    return users[0];
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return null;
        }

        //public void SendSMS(VisitConcernUser user)
        //{
        //    string strDataMoedel = "";
        //    try
        //    {
        //        DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(ResponseModel));
        //        MemoryStream mem = new MemoryStream();
        //        ser.WriteObject(mem, responseModel);
        //        strDataMoedel = Encoding.UTF8.GetString(mem.ToArray(), 0, (int)mem.Length);

        //        //WebOperationContext.Current.OutgoingResponse.Headers.Add("data", Data);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Data contract serializer exception : " + ex.Message);
        //    }

        //  WebRequest request = WebRequest.Create("http://www.contoso.com/PostAccepter.aspx ");
        //  // Set the Method property of the request to POST.
        //  request.Method = "POST";
        //  // Create POST data and convert it to a byte array.
        //  string postData = "This is a test that posts this string to a Web server.";
        //  byte[] byteArray = Encoding.UTF8.GetBytes(postData);
        //  // Set the ContentType property of the WebRequest.
        //  request.ContentType = "application/x-www-form-urlencoded";
        //  // Set the ContentLength property of the WebRequest.
        //  request.ContentLength = byteArray.Length;
        //  // Get the request stream.
        //  Stream dataStream = request.GetRequestStream();
        //  // Write the data to the request stream.
        //  dataStream.Write(byteArray, 0, byteArray.Length);
        //  // Close the Stream object.
        //  dataStream.Close();
        //  // Get the response.
        //  WebResponse response = request.GetResponse();
        //  // Display the status.
        ////  Console.WriteLine(((HttpWebResponse)response).StatusDescription);
        //  // Get the stream containing content returned by the server.
        //  dataStream = response.GetResponseStream();
        //  // Open the stream using a StreamReader for easy access.
        //  StreamReader reader = new StreamReader(dataStream);
        //  // Read the content.
        //  string responseFromServer = reader.ReadToEnd();
        //  // Display the content.
        // // Console.WriteLine(responseFromServer);
        //  // Clean up the streams.
        //  reader.Close();
        //  dataStream.Close();
        //  response.Close();


        //}

        public DataTable GetDistirctByUserID(int UserID)
        {
            return new UserDAL().SelectDistrictByUserID(UserID);
        }

        public DataSet GetUsers(int DistrictID, int TehsilID, int UnionCouncilID, Int32 PageNumber, Int32 PageSize, string SearchIn = "", string Keyword = "")
        {
            return new UserDAL().SelectUsers(DistrictID, PageNumber, PageSize, SearchIn, Keyword);
        }

        public DataSet GetUserByLogin(string UserName)
        {
            return new UserDAL().SelectUserByLogin(UserName);
        }

        public UserModel GeLoginUserInfoByLogin(string UserName)
        {
            try
            {
                DataSet dsUserInfo = LazyBaseSingletonDAL<UserDAL>.Instance.SelectUserByLogin(UserName);
                DataTable dt = dsUserInfo.Tables[TableName.tblUser.ToString()];
                List<UserModel> users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    return users[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        public UserModel GeLoginUserInfoByLogin(int loginID)
        {
            try
            {
                DataSet dsUserInfo = LazyBaseSingletonDAL<UserDAL>.Instance.SelectUserByID(loginID);
                DataTable dt = dsUserInfo.Tables[TableName.tblUser.ToString()];
                List<UserModel> users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
                if (users != null && users.Count > 0)
                {
                    return users[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        //public R GetUserInformationByLogin(string UserName)
        //{
        //    return new UserDAL().SelectUserByLogin(UserName);
        //}

        public DataSet GetUserRightInfoByID(int userID)
        {
            try
            {
                return new UserDAL().SelectUserRightInfoByID(userID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UserModelView> GetUsersByFCCenter(string FCCode, string Condition = "")
        {
            DataTable dt = null;
            dt = new UserDAL().SelectUsersByFCCenter(FCCode, Condition);
            return BuildModelCollection(dt);
        }

        public List<UserModelView> SelectUsersByFCCenterID(int locationID)
        {
            DataTable dt = null;
            dt = new UserDAL().SelectUsersByFCCenterID(locationID);
            return BuildModelCollection(dt);
        }

        public DataTable SelectUserByTypeID(int DistrictID, int UserTypeID)
        {
            DataTable dt = null;
            dt = new UserDAL().SelectUserByTypeID(DistrictID, UserTypeID);
            return dt;
        }

        public List<UserModel> GetUsers()
        {
            DataTable dt = null;
            dt = new UserDAL().GetUsers();
            List<UserModel> users = (List<UserModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new UserModel());
            return users;
        }

        public bool IsValidateUser(string loginName, string password)
        {
            try
            {
                return LazyBaseSingletonDAL<UserDAL>.Instance.IsValidateUser(loginName, password);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int ResetPassword(string loginName, string oldpassword, string newpassword, int? loginID, bool IsAdmin)
        {
            object result = 0;
            try
            {
                if (loginID.HasValue)
                {
                    result = new UserDAL().UpdatePassword(loginName, oldpassword, newpassword, loginID, IsAdmin);
                }
                else
                {
                    throw new BusinessException(CutomMessage.InvalidUser);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Convert.ToInt32(result);
        }

        #region "Method With Model Retrun"

        public List<UserModelView> GetUsers(int DistrictID, Int32 PageNumber, Int32 PageSize, out int TotalRecord, string SearchIn = "", string Keyword = "")
        {
            DataSet ds = new UserDAL().SelectUsers(DistrictID, PageNumber, PageSize, SearchIn, Keyword);
            TotalRecord = Convert.ToInt32(ds.Tables[1].Rows[0]["TotalRecords"]);
            return BuildModelCollection(ds.Tables[0]);
        }

        // Get User by Department
        public List<UserModel> GetUsersByDepartmentID(int deptID)
        {
            DataSet ds = new UserDAL().GetUsersByDepartmentID(deptID);
            return BuildModelList(ds);
        }

        // Get 
        public UserModel GetUserByID(int UserID, string v)
        {
            DataSet ds = null;
            ds = new UserDAL().SelectUserByID(UserID);
            return BuildModel(ds);
        }


        #endregion

        #region "Private Methods"

        internal List<UserModelView> BuildModelCollection(DataTable dt)
        {
            List<UserModelView> collection = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                collection = new List<UserModelView>();
                foreach (DataRow dr in dt.Rows)
                {
                    UserModelView model = new UserModelView();

                    if (dt.Columns.Contains("UserID") && !Convert.IsDBNull(dr["UserID"]))
                        model.UserID = Convert.ToInt32(dr["UserID"].ToString());
                    if (dt.Columns.Contains("UserTypeID") && !Convert.IsDBNull(dr["UserTypeID"]))
                        model.UserTypeID = Convert.ToInt32(dr["UserTypeID"].ToString());
                    if (dt.Columns.Contains("ID") && !Convert.IsDBNull(dr["ID"]))
                        model.UserID = Convert.ToInt32(dr["ID"].ToString());
                    if (dt.Columns.Contains("UserName") && !Convert.IsDBNull(dr["UserName"]))
                        model.UserName = dr["UserName"].ToString();
                    if (dt.Columns.Contains("EmployeeName") && !Convert.IsDBNull(dr["EmployeeName"]))
                        model.EmployeeName = Convert.ToString(dr["EmployeeName"]);
                    if (dt.Columns.Contains("CNIC") && !Convert.IsDBNull(dr["CNIC"]))
                        model.CNIC = Convert.ToString(dr["CNIC"]);
                    if (dt.Columns.Contains("District") && !Convert.IsDBNull(dr["District"]))
                        model.District = Convert.ToString(dr["District"]);
                    if (dt.Columns.Contains("CellNumber") && !Convert.IsDBNull(dr["CellNumber"]))
                        model.CellNumber = Convert.ToString(dr["CellNumber"]);
                    if (dt.Columns.Contains("EMail") && !Convert.IsDBNull(dr["EMail"]))
                        model.EMail = Convert.ToString(dr["EMail"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        model.IsActive = Convert.ToBoolean(dr["IsActive"].ToString());

                    collection.Add(model);
                }

                collection.TrimExcess();
            }

            return collection;
        }

        internal UserModel BuildModel(DataSet ds)
        {
            UserModel model = new UserModel();

            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];

                if (ds.Tables[0].Columns.Contains("UserID") && !Convert.IsDBNull(dr["UserID"]))
                    model.UserID = Convert.ToInt32(dr["UserID"].ToString());
                if (ds.Tables[0].Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                    model.DepartmentID = Convert.ToInt32(dr["DepartmentID"].ToString());

                if (ds.Tables[0].Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                    model.DistrictID = Convert.ToInt32(dr["DistrictID"].ToString());


                if (ds.Tables[0].Columns.Contains("UserName") && !Convert.IsDBNull(dr["UserName"]))
                    model.UserName = dr["UserName"].ToString();
                if (ds.Tables[0].Columns.Contains("EmployeeName") && !Convert.IsDBNull(dr["EmployeeName"]))
                    model.EmployeeName = Convert.ToString(dr["EmployeeName"]);
                if (ds.Tables[0].Columns.Contains("CNIC") && !Convert.IsDBNull(dr["CNIC"]))
                    model.CNIC = Convert.ToString(dr["CNIC"]);
                if (ds.Tables[0].Columns.Contains("EMail") && !Convert.IsDBNull(dr["EMail"]))
                    model.EMail = Convert.ToString(dr["EMail"]);
                if (ds.Tables[0].Columns.Contains("CellNumber") && !Convert.IsDBNull(dr["CellNumber"]))
                    model.CellNumber = Convert.ToString(dr["CellNumber"]);
                //if (ds.Tables[0].Columns.Contains("PermitGroupID") && !Convert.IsDBNull(dr["PermitGroupID"]))
                //    model.GroupID = Convert.ToInt32(dr["PermitGroupID"].ToString());
                //if (ds.Tables[0].Columns.Contains("UserType") && !Convert.IsDBNull(dr["UserType"]))
                //    model.UserType = Convert.ToString(dr["UserType"]);
                //if (ds.Tables[0].Columns.Contains("PermitGroupID") && !Convert.IsDBNull(dr["PermitGroupID"]))
                //    model.GroupID = Convert.ToInt32(dr["PermitGroupID"].ToString());
                //if (ds.Tables[0].Columns.Contains("UserTypeID") && !Convert.IsDBNull(dr["UserTypeID"]))
                //    model.UserTypeID = Convert.ToString(dr["UserType"]);

                if (ds.Tables[0].Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    model.IsActive = Convert.ToBoolean(dr["IsActive"].ToString());

                //if (ds.Tables[0].Columns.Contains("JoiningDate") && !Convert.IsDBNull(dr["JoiningDate"]))
                //    model.JoinDate = Convert.ToDateTime(dr["JoiningDate"].ToString());
                //if (ds.Tables[0].Columns.Contains("ResignedDate") && !Convert.IsDBNull(dr["ResignedDate"]))
                //    model.ResignedDate = Convert.ToDateTime(dr["ResignedDate"].ToString());
                //if (ds.Tables[0].Columns.Contains("InActiveReason") && !Convert.IsDBNull(dr["InActiveReason"]))
                //    model.BlockReason = Convert.ToString(dr["InActiveReason"]);

                if (ds.Tables[0].Columns.Contains("AllowFileRemove") && !Convert.IsDBNull(dr["AllowFileRemove"]))
                    model.AllowFileRemoved = Convert.ToBoolean(dr["AllowFileRemove"].ToString());


            }

            return model;
        }

        internal List<UserModel> BuildModelList(DataSet ds)
        {

            List<UserModel> list = new List<UserModel>();

            UserModel model = new UserModel();

            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                DataRow dr = ds.Tables[0].Rows[0];

                if (ds.Tables[0].Columns.Contains("UserID") && !Convert.IsDBNull(dr["UserID"]))
                    model.UserID = Convert.ToInt32(dr["UserID"].ToString());
                if (ds.Tables[0].Columns.Contains("DepartmentID") && !Convert.IsDBNull(dr["DepartmentID"]))
                    model.DepartmentID = Convert.ToInt32(dr["DepartmentID"].ToString());

                if (ds.Tables[0].Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                    model.DistrictID = Convert.ToInt32(dr["DistrictID"].ToString());


                if (ds.Tables[0].Columns.Contains("UserName") && !Convert.IsDBNull(dr["UserName"]))
                    model.UserName = dr["UserName"].ToString();
                if (ds.Tables[0].Columns.Contains("EmployeeName") && !Convert.IsDBNull(dr["EmployeeName"]))
                    model.EmployeeName = Convert.ToString(dr["EmployeeName"]);
                if (ds.Tables[0].Columns.Contains("CNIC") && !Convert.IsDBNull(dr["CNIC"]))
                    model.CNIC = Convert.ToString(dr["CNIC"]);
                if (ds.Tables[0].Columns.Contains("EMail") && !Convert.IsDBNull(dr["EMail"]))
                    model.EMail = Convert.ToString(dr["EMail"]);
                if (ds.Tables[0].Columns.Contains("CellNumber") && !Convert.IsDBNull(dr["CellNumber"]))
                    model.CellNumber = Convert.ToString(dr["CellNumber"]);
                //if (ds.Tables[0].Columns.Contains("PermitGroupID") && !Convert.IsDBNull(dr["PermitGroupID"]))
                //    model.GroupID = Convert.ToInt32(dr["PermitGroupID"].ToString());
                //if (ds.Tables[0].Columns.Contains("UserType") && !Convert.IsDBNull(dr["UserType"]))
                //    model.UserType = Convert.ToString(dr["UserType"]);
                //if (ds.Tables[0].Columns.Contains("PermitGroupID") && !Convert.IsDBNull(dr["PermitGroupID"]))
                //    model.GroupID = Convert.ToInt32(dr["PermitGroupID"].ToString());
                //if (ds.Tables[0].Columns.Contains("UserTypeID") && !Convert.IsDBNull(dr["UserTypeID"]))
                //    model.UserTypeID = Convert.ToString(dr["UserType"]);

                if (ds.Tables[0].Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    model.IsActive = Convert.ToBoolean(dr["IsActive"].ToString());

                //if (ds.Tables[0].Columns.Contains("JoiningDate") && !Convert.IsDBNull(dr["JoiningDate"]))
                //    model.JoinDate = Convert.ToDateTime(dr["JoiningDate"].ToString());
                //if (ds.Tables[0].Columns.Contains("ResignedDate") && !Convert.IsDBNull(dr["ResignedDate"]))
                //    model.ResignedDate = Convert.ToDateTime(dr["ResignedDate"].ToString());
                //if (ds.Tables[0].Columns.Contains("InActiveReason") && !Convert.IsDBNull(dr["InActiveReason"]))
                //    model.BlockReason = Convert.ToString(dr["InActiveReason"]);

                if (ds.Tables[0].Columns.Contains("AllowFileRemove") && !Convert.IsDBNull(dr["AllowFileRemove"]))
                    model.AllowFileRemoved = Convert.ToBoolean(dr["AllowFileRemove"].ToString());

                list.Add(model);


            }

            return list;
        }

        //internal List<ServiceModel> BuildServiceModel(DataTable dt)
        //{
        //    List<ServiceModel> collection = new List<ServiceModel>();

        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            ServiceModel model = new ServiceModel();

        //            if (dt.Columns.Contains("ServiceID") && !Convert.IsDBNull(dr["ServiceID"]))
        //                model.ID = Convert.ToInt32(dr["ServiceID"].ToString());

        //            collection.Add(model);
        //        }

        //        collection.TrimExcess();
        //    }

        //    return collection;
        //}

        //internal List<TaskStatusModel> BuildStatusModel(DataTable dt)
        //{
        //    List<TaskStatusModel> collection = new List<TaskStatusModel>();

        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            TaskStatusModel model = new TaskStatusModel();

        //            if (dt.Columns.Contains("StatusID") && !Convert.IsDBNull(dr["StatusID"]))
        //                model.ID = Convert.ToInt32(dr["StatusID"].ToString());

        //            collection.Add(model);
        //        }

        //        collection.TrimExcess();
        //    }

        //    return collection;
        //}

        //internal List<CentrePermittedReportAndForms> BuildCenterModel(DataTable dt)
        //{
        //    List<CentrePermittedReportAndForms> collection = new List<CentrePermittedReportAndForms>();

        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            CentrePermittedReportAndForms model = new CentrePermittedReportAndForms();

        //            if (dt.Columns.Contains("AppFeatureID") && !Convert.IsDBNull(dr["AppFeatureID"]))
        //                model.FeatureID = Convert.ToInt32(dr["AppFeatureID"].ToString());

        //            collection.Add(model);
        //        }

        //        collection.TrimExcess();
        //    }

        //    return collection;
        //}

        //internal List<ServiceUserRights> BuildServiceUserRightsModel(DataTable dt)
        //{
        //    List<ServiceUserRights> collection = new List<ServiceUserRights>();

        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        int Row = 1;
        //        foreach (DataRow dr in dt.Rows)
        //        {
        //            ServiceUserRights model = new ServiceUserRights();

        //            model.RowID = Row;
        //            if (dt.Columns.Contains("ServiceID") && !Convert.IsDBNull(dr["ServiceID"]))
        //                model.ServiceID = Convert.ToInt32(dr["ServiceID"].ToString());
        //            if (dt.Columns.Contains("IsEditDeliveryDate") && !Convert.IsDBNull(dr["IsEditDeliveryDate"]))
        //                model.EnableDeliveryDateEditing = Convert.ToBoolean(dr["IsEditDeliveryDate"].ToString());

        //            collection.Add(model);
        //            Row++;
        //        }

        //        collection.TrimExcess();
        //    }

        //    return collection;
        //}

        public string ConvertBytesToBase64(byte[] content)
        {
            string Base64Content = "";
            using (MemoryStream memoryStream = new MemoryStream(content))
            {
                StreamReader streamReader = new StreamReader(memoryStream, Encoding.Unicode);
                Base64Content = streamReader.ReadToEnd();

                streamReader.Close();
            }

            return Base64Content;
        }

        #endregion
    }
}
