﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using BE.RigthManager;
using BE.CustomEnums;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.RightsManager;



namespace BLL.RightsManager
{
    public class ApplicationFeaturesBLL
    {

        /// <summary>
        /// Save Method
        /// </summary>
        /// <param name="appfeaturesModel"></param>
        /// <returns></returns>
        public int Save(ApplicationFeatureModel appfeaturesModel)
        {

            Hashtable htbWhere = new Hashtable();
            htbWhere.Add(ColumnName.menuLocation, appfeaturesModel.menuLocation);

            CommonBLL commonBLL = new CommonBLL();
            if (appfeaturesModel.ID > 0)
            {
                if (commonBLL.IsExist(TableName.tblAppFeatures, ColumnName.MenuName, appfeaturesModel.MenuName, commonBLL.GetClause(htbWhere, ColumnName.AppFeatureID, appfeaturesModel.ID)))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }
                return LazyBaseSingletonDAL<ApplicationFeatureDAL>.Instance.Edit(appfeaturesModel);
            }
            else if (commonBLL.IsExist(TableName.tblAppFeatures, ColumnName.MenuName, appfeaturesModel.MenuName, commonBLL.GetClause(htbWhere, null, null)))
            {
                throw new Exception(CustomMsg.DuplicateTitle);
            }
            else
                return LazyBaseSingletonDAL<ApplicationFeatureDAL>.Instance.Add(appfeaturesModel);

        }

        /// <summary>
        /// Get Features By Location 
        /// </summary>
        /// <param name="location"></param>
        /// <returns></returns>

        public List<ApplicationFeatureModel> GetFeaturesByLocation(int location)
        {
            DataTable dt = null;
            dt = new ApplicationFeatureDAL().GetAllFeaturesByLocation(location);
            return BuildModel(dt);
        }

      /// <summary>
      /// Get Features
      /// </summary>
      /// <returns></returns>
        public List<ApplicationFeatureModel> GetFeature()
        {
            DataTable dt = null;
            dt = new ApplicationFeatureDAL().GetFeature();
            return BuildModel(dt);
        }

        /// <summary>
        /// Getting All App Features
        /// </summary>
        /// <returns></returns>
        public List<ApplicationFeatureModel> GetFeatures()
        {
            DataTable dt = null;
            dt = new ApplicationFeatureDAL().GetFeatures();
            return BuildModel(dt);
        }

        /// <summary>
        /// Get all Role base CSR Menu/Feature
        /// </summary>
        /// <returns>result of Feature in FeaturesModel class</returns>
        public List<ApplicationFeatureModel> GetCSRMenuByUserID(int userID)
        {
            DataTable dt = null;
            dt = new ApplicationFeatureDAL().GetCSRMenuByID(userID);
            return BuildModel(dt);
        }

        #region "private & internal methods"
        internal List<ApplicationFeatureModel> BuildModel(DataTable dt)
        {
            List<ApplicationFeatureModel> featuresModel = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                featuresModel = new List<ApplicationFeatureModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    ApplicationFeatureModel featureModel = new ApplicationFeatureModel();
                    if (dt.Columns.Contains("AppFeatureID") && !Convert.IsDBNull(dr["AppFeatureID"]))
                        featureModel.ID = Convert.ToInt32(dr["AppFeatureID"]);
                    if (dt.Columns.Contains("MenuName") && !Convert.IsDBNull(dr["MenuName"]))
                        featureModel.MenuName = Convert.ToString(dr["MenuName"]);
                    if (dt.Columns.Contains("Icon") && !Convert.IsDBNull(dr["Icon"]))
                        featureModel.Icon = Convert.ToString(dr["Icon"]);
                    if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                        featureModel.Name = Convert.ToString(dr["Name"]);
                    if (dt.Columns.Contains("URL") && !Convert.IsDBNull(dr["URL"]))
                        featureModel.URL = Convert.ToString(dr["URL"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        featureModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("HasChild") && !Convert.IsDBNull(dr["HasChild"]))
                        featureModel.HasChild = Convert.ToInt32(dr["HasChild"]) == 1 ? true : false;
                    if (dt.Columns.Contains("menuLocation") && !Convert.IsDBNull(dr["menuLocation"]))
                        featureModel.menuLocation = Convert.ToInt32(dr["menuLocation"]);
                    if (dt.Columns.Contains("Sort") && !Convert.IsDBNull(dr["Sort"]))
                        featureModel.Sort = Convert.ToInt32(dr["Sort"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        featureModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("CreatedDate") && !Convert.IsDBNull(dr["CreatedDate"]))
                        featureModel.CreatedDate = Convert.ToDateTime(dr["CreatedDate"]);
                    if (dt.Columns.Contains("ModifiedDate") && !Convert.IsDBNull(dr["ModifiedDate"]))
                        featureModel.ModifiedDate = Convert.ToDateTime(dr["ModifiedDate"]);
                    if (dt.Columns.Contains("CreatedBy") && !Convert.IsDBNull(dr["CreatedBy"]))
                        featureModel.CreatedBy = Convert.ToInt32(dr["CreatedBy"]);
                    if (dt.Columns.Contains("ModifiedBy") && !Convert.IsDBNull(dr["ModifiedBy"]))
                        featureModel.ModifiedBy = Convert.ToInt32(dr["ModifiedBy"]);

                    featuresModel.Add(featureModel);
                }

                featuresModel.TrimExcess();
            }

            return featuresModel;
        }
        #endregion
    }
}
