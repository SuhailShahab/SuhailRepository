﻿

using BE.CustomEnums;
using BE.RigthManager;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.RightsManager;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.RightsManager
{
    public class ApplicationObjectsBLL
    {
        /// <summary>
        /// Save Record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(ApplicationObjectModel model)
        {
            CommonBLL commonBLL = LazyBaseSingletonDAL<CommonBLL>.Instance;
            Hashtable htbWhere = new Hashtable();
            htbWhere.Add(ColumnName.AppFeatureID.ToString(), model.AppFeatureID);
 
            if (model.ID > 0)
            {

                if (commonBLL.IsExist(TableName.tblAppObjects, ColumnName.StaticName, model.StaticName, commonBLL.GetClause(htbWhere, ColumnName.AppObjectID, model.ID)))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }
                return new ApplicationObjectsDAL().Edit(model);
            }//else if (commonBLL.IsExist(TableName.tblAppObjects, ColumnName.StaticName, model.StaticName, null))
            else if (commonBLL.IsExist(TableName.tblAppObjects, ColumnName.StaticName, model.StaticName, commonBLL.GetClause(htbWhere, null, null)))
            {
                throw new Exception(CustomMsg.DuplicateTitle);
            }

            else

                return new ApplicationObjectsDAL().Add(model);
        }

        /// <summary>
        /// Getting All Record for 
        /// </summary>
        /// <returns></returns>
        public List<ApplicationObjectModel> GetAppObject()
        {
            DataTable dt = null;
            dt = new ApplicationObjectsDAL().GetAppObject();
            return BuildModel(dt);
        }

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<ApplicationObjectModel> BuildModel(DataTable dt)
        {
            List<ApplicationObjectModel> ApplicationObjectes = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                ApplicationObjectes = new List<ApplicationObjectModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    ApplicationObjectModel model = new ApplicationObjectModel();
                    if (dt.Columns.Contains("AppObjectID") && !Convert.IsDBNull(dr["AppObjectID"]))
                        model.ID = Convert.ToInt32(dr["AppObjectID"]);
                    if (dt.Columns.Contains("AppFeatureID") && !Convert.IsDBNull(dr["AppFeatureID"]))
                        model.AppFeatureID = Convert.ToInt32(dr["AppFeatureID"]);
                    if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                        model.StaticName = Convert.ToString(dr["StaticName"]);
                    if (dt.Columns.Contains("Icon") && !Convert.IsDBNull(dr["Icon"]))
                        model.Icon = Convert.ToString(dr["Icon"]);
                    if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                        model.Name = Convert.ToString(dr["Name"]);
                    if (dt.Columns.Contains("URL") && !Convert.IsDBNull(dr["URL"]))
                        model.URL = Convert.ToString(dr["URL"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        model.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("HasChild") && !Convert.IsDBNull(dr["HasChild"]))
                        model.HasChild = Convert.ToInt32(dr["HasChild"]) == 1 ? true : false;

                    if (dt.Columns.Contains("Sort") && !Convert.IsDBNull(dr["Sort"]))
                        model.Sort = Convert.ToInt32(dr["Sort"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        model.Status = Convert.ToBoolean(dr["IsActive"]);

                    ApplicationObjectes.Add(model);
                }

                ApplicationObjectes.TrimExcess();
            }

            return ApplicationObjectes;
        }
    }
}
