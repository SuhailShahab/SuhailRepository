﻿using System;
using System.Data;
using System.Collections.Generic;

using System.Text;
using BE.Lookups;
using BLL.CommonUtility;
using BE.CustomEnums;
using DAL.Lookups;



namespace BLL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil >
    // Create date: <7/10/2014 2:07:32 AM>
    // =================================================================================================================================
    // ===================================================== Modification City  ======================================================
    // =================================================================================================================================
    public class CityBLL
    {
        /// <summary>
        /// Save the City Info
        /// </summary>
        /// <param name="cityModel"></param>
        /// <returns>Result of  add or Updated Status</returns>
        public int Save(CityModel cityModel)
        {

            CommonBLL commonBLL = new CommonBLL();

            int result = 0;
            try
            {
                if (!string.IsNullOrEmpty(cityModel.Title))
                {
                    if (cityModel.ID.HasValue && cityModel.ID.Value  > 0)
                    {
                        if (commonBLL.IsExist(TableName.tblCity, ColumnName.Title, cityModel.Title, commonBLL.GetClause(ColumnName.CityID, cityModel.ID.Value)))
                        {
                            throw new Exception(CustomMsg.DuplicateTitle);
                        }

                      
                        return new CityDAL().Edit(cityModel);
                    }
                    else if (commonBLL.IsExist(TableName.tblCity, ColumnName.Title, cityModel.Title, null))
                    {
                       throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    else
                       return new CityDAL().Add(cityModel);
                }

              
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
      
      

        /// <summary>
        /// Get all Cities Info
        /// </summary>
        /// <returns>result of City in CityModel class</returns
        public List<CityModel> GetCities()
        {
            DataTable dt = null;
            dt = new CityDAL().SelectCities();
            return this.BuildModel(dt);
           
        }
      
        /// <summary>
        /// Get All Active cities for drowpdown 
        /// </summary>
        /// <param name="servcieID"></param>
        /// <returns></returns>
        public List<CityModel> GetAllCities()
        {
            DataTable dt = null;
            dt = new CityDAL().GetAllCities();
            return this.BuildModel(dt);

        }

     


        /// <summary>
        /// Delete the City By ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>success or error Type on delete </returns>
        public int Delete(CityModel model, int? ModifiedBy)
        {
            return new CityDAL().Delete(new CityModel(model.ID, ModifiedBy));
        }

   

       

        #region "Private Methods"
        
      

        /// <summary>
        /// Bind the City Model with Data Table
        /// </summary>
        /// <param name="dt"></param>
        /// <returns>CityModel class</returns>
        internal List<CityModel> BuildModel(DataTable dt)
        {
            List<CityModel> cities = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                cities = new List<CityModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    CityModel cityModel = new CityModel();
                    if (dt.Columns.Contains("CityID") && !Convert.IsDBNull(dr["CityID"]))
                    cityModel.ID = Convert.ToInt32(dr["CityID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                    cityModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                    cityModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    cityModel.Status = Convert.ToBoolean(dr["IsActive"]);
                 
                    cities.Add(cityModel);
                }

                cities.TrimExcess();
            }

            return cities;
        }

       

        #endregion
    }
}
