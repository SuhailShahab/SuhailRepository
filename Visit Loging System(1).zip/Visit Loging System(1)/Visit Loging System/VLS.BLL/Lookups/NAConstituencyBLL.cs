﻿
using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<SOHAIL KAMRAN >
// Create date: <11-5-2016 10:40:55PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription

// =================================================================================================================================
namespace BLL.Lookups
{
    public class NAConstituencyBLL
    {
        /// <summary>
        /// Saving Constituency Record
        /// </summary>
        /// <param name="model"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int Save(NAConstituencyModel model, int? userId)
        {
            
            CommonBLL commonBLL = new CommonBLL();
            try
            {
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblNAConstituency, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.NAConstituencyID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }

                    model.ModifiedBy = userId;
                    model.District = null;

                    return LazyBaseSingletonDAL<NAConstituencyDAL>.Instance.Edit (model);
                }

                else if (commonBLL.IsExist(TableName.tblNAConstituency, ColumnName.Title, model.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }
                else
                {
                    model.CreatedBy = userId;

                    return LazyBaseSingletonDAL<NAConstituencyDAL>.Instance.Add(model);
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                commonBLL = null;

            }

        }

        public List<NAConstituencyModel> GetAllNAconstituencies()
        {
            DataTable dt = null;
            //dt = new NAConstituencyDAL().GetAll();
            dt = LazyBaseSingletonDAL<NAConstituencyDAL>.Instance.GetAll();
            return BindData(dt);

        }

        public List<NAConstituencyModel> GetNAConstituency()
        {
            DataTable dt = null;
            
            dt =LazyBaseSingletonDAL<NAConstituencyDAL>.Instance.GetNAConstituency ();
            return BindData(dt);
            
        }

        public int Delete(NAConstituencyModel model, int? ModifiedBy)
        {
            try
            {
                return LazyBaseSingletonDAL<NAConstituencyDAL>.Instance.Delete(new NAConstituencyModel(model.ID, ModifiedBy));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int Delete(NAConstituencyModel model)
        {
            try
            {
                return LazyBaseSingletonDAL<NAConstituencyDAL>.Instance.Delete(new NAConstituencyModel(model.ID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region "internal and Private Methods"

       
        internal List<NAConstituencyModel> BindData(DataTable dt)
        {
            List<NAConstituencyModel> lists = new List<NAConstituencyModel>();

            if (dt.Rows.Count > 0)

                lists = (List<NAConstituencyModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new NAConstituencyModel());

            return lists;
        }

        #endregion
    }
}
