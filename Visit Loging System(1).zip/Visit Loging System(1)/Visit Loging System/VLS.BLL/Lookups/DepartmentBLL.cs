﻿using System;
using System.Data;
using System.Collections.Generic;
using BE.Lookups;
using BLL.CommonUtility;
using BE.CustomEnums;
using DAL.Lookups;
using DAL.Generic;


namespace BLL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:30AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class DepartmentBLL
    {
        public int Save(DepartmentModel model, int ? userId)
        {
            CommonBLL commonBLL = new CommonBLL();
            try
            {

                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblDepartment, ColumnName.Code, model.Code, commonBLL.GetClause(ColumnName.DepartmentID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateCode);
                    }
                    else if (commonBLL.IsExist(TableName.tblDepartment, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.DepartmentID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }

                    model.ModifiedBy = userId;
                    return LazyBaseSingletonDAL<DepartmentDAL>.Instance.Edit(model);
                }
                else if (commonBLL.IsExist(TableName.tblDepartment, ColumnName.Code, model.Code, null))
                {
                    throw new Exception(CustomMsg.DuplicateCode);
                }
                else if (commonBLL.IsExist(TableName.tblDepartment, ColumnName.Title, model.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                else
                {
                    model.CreatedBy = userId;
                    return LazyBaseSingletonDAL<DepartmentDAL>.Instance.Add(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                commonBLL = null;

            }

        }

        public List<DepartmentModel> GetDepartments()
        {
            DataTable dt = null;
            dt =  LazyBaseSingletonDAL<DepartmentDAL>.Instance.GetAll();
            return BindData(dt);
            //return BuildModel(dt);
            
        }

        /// <summary>
        /// Get All Departs
        /// </summary>
        /// <returns></returns>
        public List<DepartmentModel> GetDepartment()
        {
            DataTable dt = null;
            dt =  LazyBaseSingletonDAL<DepartmentDAL>.Instance.SelectDepartments();
            return BindData(dt);
            //return BuildModel(dt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(DepartmentModel model, int ? ModifiedBy )
        {
            try
            {
                return LazyBaseSingletonDAL<DepartmentDAL>.Instance.Delete(new DepartmentModel(model.ID, ModifiedBy));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DepartmentModel GetDepartmentByID(int DepartmentID)
        {
            DataTable dtDepartment = LazyBaseSingletonDAL<DepartmentDAL>.Instance.GetDepartmentByID(DepartmentID);
            return BuildModel(dtDepartment);
        }

        #region "internal and Private Methods"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<DepartmentModel> BindData(DataTable dt)
        {
            List<DepartmentModel> lists = new List<DepartmentModel>();

            if (dt.Rows.Count > 0)

                lists = (List<DepartmentModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DepartmentModel());

            return lists;
        }

        private DepartmentModel BuildModel(DataTable dt)
        {
            List<DepartmentModel> colDepartments = new List<DepartmentModel>();
            DepartmentModel dm = new DepartmentModel();

            if (dt.Rows.Count > 0)
                colDepartments = (List<DepartmentModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DepartmentModel());

            if (colDepartments.Count > 0) dm = colDepartments[0];

            return dm;
        }

        #endregion
    }
}
