﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <07-04-2016 11:46:22AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace BLL.Lookups
{
    public class HospitalEquipmentBLL
    {
        /// <summary>
        /// Get all active hospital equipments information
        /// </summary>
        /// <returns></returns>
        public List<HospitalEquipmentModel> GetActiveHospitalEquipments()
        {
            List<HospitalEquipmentModel> colHospitalEquipments = new List<HospitalEquipmentModel>();

            DataTable dt = LazyBaseSingletonDAL<HospitalEquipmentDAL>.Instance.GetHospitalEquipments();
            if (dt.Rows.Count > 0)
                colHospitalEquipments = (List<HospitalEquipmentModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new HospitalEquipmentModel());

            return colHospitalEquipments;
        }

        public List<HospitalEquipmentModel> GetHospitalEquipments()
        {
            List<HospitalEquipmentModel> colHospitalEquipments = new List<HospitalEquipmentModel>();

            DataTable dt = LazyBaseSingletonDAL<HospitalEquipmentDAL>.Instance.GetAll();
            if (dt.Rows.Count > 0)
                colHospitalEquipments = (List<HospitalEquipmentModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new HospitalEquipmentModel());

            return colHospitalEquipments;
        }


        /// <summary>
        /// Save Information 
        /// </summary>
        /// <param name="model"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int Save(HospitalEquipmentModel model, int? userId)
        {

            CommonBLL commonBLL = new CommonBLL();
            try
            {
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblHospitalEquipments, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.EquipmentID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }

                    model.ModifiedBy = userId;
                    
                    return LazyBaseSingletonDAL<HospitalEquipmentDAL>.Instance.Edit(model);
                }

                else if (commonBLL.IsExist(TableName.tblHospitalEquipments, ColumnName.Title, model.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                else
                {
                    model.CreatedBy = userId;
                    
                    return LazyBaseSingletonDAL<HospitalEquipmentDAL>.Instance.Add(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                commonBLL = null;

            }

        }

        /// <summary>
        /// De-activate information
        /// </summary>
        /// <param name="model"></param>
        /// <param name="ModifiedBy"></param>
        /// <returns></returns>
        public int Delete(HospitalEquipmentModel model, int? ModifiedBy)
        {
            try
            {
                return LazyBaseSingletonDAL<HospitalEquipmentDAL>.Instance.Delete(new HospitalEquipmentModel(model.ID, ModifiedBy));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region "internal and Private Methods"


        internal List<HospitalEquipmentModel> BindData(DataTable dt)
        {
            List<HospitalEquipmentModel> lists = new List<HospitalEquipmentModel>();

            if (dt.Rows.Count > 0)

                lists = (List<HospitalEquipmentModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new HospitalEquipmentModel());

            return lists;
        }

        #endregion
    }
}
