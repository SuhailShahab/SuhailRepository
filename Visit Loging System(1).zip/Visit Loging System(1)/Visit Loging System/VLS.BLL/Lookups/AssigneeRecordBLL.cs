﻿using BLL.CommonUtility;
using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLS.BE.Lookups;
using VLS.DAL.Lookups;

namespace VLS.BLL.Lookups
{
   public  class AssigneeRecordBLL
    {
       public int? Save(AssigneeRecordView model)
       {
           DataTable dt = new DataTable();
           int? result = null;
           try
           {
               if (model.DepartmentID > 0)
               {
                   dt = this.GetDataTabe(model.AssigneeRecords);
                   result = LazyBaseSingletonDAL<AssigneeRecordDAL>.Instance.Save(dt, model.DepartmentID);
               }

           }
           catch (Exception ex)
           {
               throw ex;
           }


           return result;

       }

       public List<AssigneeRecordModel> GetbyDepartmentID (int? departmentID)
       {
           DataTable dt = new DataTable();
          List<AssigneeRecordModel> records = null;
           try
           {
               if (departmentID.HasValue && departmentID.Value > 0)
               {

                   dt = LazyBaseSingletonDAL<AssigneeRecordDAL>.Instance.GetAllByDepartmentID(departmentID);
                   records =(List<AssigneeRecordModel>) LazyBaseSingletonDAL<CommonBuildModel>.Instance.BuildModel(dt, new AssigneeRecordModel());
               }
               

           }
           catch (Exception ex)
           {
               throw ex;
           }

           return records;

       }

       public int? Delete(int? recordID)
       {
           int result = 0;
           try
           {
               if (recordID.HasValue && recordID.Value > 0)
               {

                 result=   LazyBaseSingletonDAL<AssigneeRecordDAL>.Instance.Delete(recordID??0);
               }


           }
           catch (Exception ex)
           {
               throw ex;
           }
           return result;
       }

        #region Internal Methods
       internal DataTable GetDataTabe(List<AssigneeRecordModel> assigneeRecords)
       {
           DataTable dt = new DataTable("AssingRecMapping");
           DataColumn dc = new DataColumn("ID",typeof(int));
           dt.Columns.Add(dc);
           dc = new DataColumn("DesignationID", typeof(int));
           dt.Columns.Add(dc);
           dc = new DataColumn("SortOrder", typeof(int));
           dt.Columns.Add(dc);

          

           if (assigneeRecords != null && assigneeRecords.Count > 0)
           {
               
               foreach (AssigneeRecordModel item in assigneeRecords)
               {
                   if(item.DesignationID.HasValue && item.DesignationID.Value >0)
                   {
                       DataRow[] foundAuthors = dt.Select("DesignationID = '" + item.DesignationID.Value + "'");
                       if (foundAuthors.Length == 0)
                       {
                           DataRow dtRow = dt.NewRow();
                           dtRow["ID"] = item.RecordID ?? 0;
                           dtRow["DesignationID"] = item.DesignationID ?? 0;
                           dtRow["SortOrder"] = item.SortOrder ?? 0;

                           dt.Rows.Add(dtRow);
                       }
                      
                   }
                  
               }

           }

           return dt;
       }
        #endregion 
    }
}
