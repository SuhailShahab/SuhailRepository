﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <07-04-2016 11:46:22AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace BLL.Lookups
{
    public class DoctorBLL
    {
        /// <summary>
        /// Get all active docotrs information
        /// </summary>
        /// <returns></returns>
        public List<DoctorModel> GetActiveDoctors()
        {
            List<DoctorModel> colDoctors = new List<DoctorModel>();

            DataTable dt = LazyBaseSingletonDAL<DoctorDAL>.Instance.GetDoctors();
            if (dt.Rows.Count > 0)
                colDoctors = (List<DoctorModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DoctorModel());

            return colDoctors;
        }
    }
}
