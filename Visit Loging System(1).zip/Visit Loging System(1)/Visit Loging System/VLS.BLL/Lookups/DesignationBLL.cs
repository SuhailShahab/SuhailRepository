﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace BLL.Lookups
{
    public class DesignationBLL
    {
        /// <summary>
        /// Saving Designation Record
        /// </summary>
        /// <param name="model"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int Save(DesignationModel model, int? userId)
        {

            CommonBLL commonBLL = new CommonBLL();
            try
            {
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblDesignation, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.DesignationID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }

                    model.ModifiedBy = userId;
                    return new DesignationDAL().Edit(model);
                }

                else if (commonBLL.IsExist(TableName.tblDesignation, ColumnName.Title, model.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                else
                {
                    model.CreatedBy = userId;
                    return new DesignationDAL().Add(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                commonBLL = null;

            }

        }

        /// <summary>
        /// Getting All Designation Records
        /// </summary>
        /// <returns></returns>
        public List<DesignationModel> GetAllDesignations()
        {
            DataTable dt = null;
            dt = new DesignationDAL().GetAll();
            return BindData(dt);

        }

        /// <summary>
        ///  Getting Designations Records
        /// </summary>
        /// <returns></returns>
        public List<DesignationModel> GetDesignation()
        {
            DataTable dt = null;
            dt = new DesignationDAL().GetDesignation();
            return BindData(dt);

        }

        /// <summary>
        /// Getting assigned designations against user
        /// </summary>
        /// <returns></returns>
        public List<DesignationModel> GetUsersDesignations(int UserID)
        {
            DataTable dt = null;
            dt = new DesignationDAL().GetUsersDesignations(UserID);
            return BindData(dt);
        }

        /// <summary>
        /// Get Designation on the basis of visited department person Designation
        /// </summary>
        /// <param name="userID">Visited person user ID</param>
        /// <returns></returns>
        public List<DesignationModel> GetDashboardDesignations(int userID)
        {
            DataTable dt = null;
            dt = new DesignationDAL().GetDashboardDesignations(userID);
            return BindData(dt);

        }

        /// <summary>
        /// disable Designation Model
        /// </summary>
        /// <param name="model"></param>
        /// <param name="ModifiedBy"></param>
        /// <returns></returns>
        public int Delete(DesignationModel model, int? ModifiedBy)
        {
            try
            {
                return LazyBaseSingletonDAL<DesignationDAL>.Instance.Delete(new DesignationModel(model.ID, ModifiedBy));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Designation on the basis of visited department person Designation
        /// </summary>
        /// <param name="userID">Visited person user ID</param>
        /// <returns></returns>
        public List<DesignationModel> GetDesignationsByFacilityID(int FacilityID)
        {
            DataTable dt = LazyBaseSingletonBLL<DesignationDAL>.Instance.GetDesignationByFacility(FacilityID);
            return BindData(dt);
        }

        #region "internal and Private Methods"


        internal List<DesignationModel> BindData(DataTable dt)
        {
            List<DesignationModel> colDesingations = new List<DesignationModel>();

            if (dt.Rows.Count > 0)
            {
                colDesingations = (List<DesignationModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DesignationModel());

                // check Secretary designation by default
                DesignationModel desingation = colDesingations.Where(d => d.ID == 2).FirstOrDefault();
                if (desingation != null)
                {
                    desingation.Checked = true;
                }
            }

            return colDesingations;
        }

        #endregion
    }
}
