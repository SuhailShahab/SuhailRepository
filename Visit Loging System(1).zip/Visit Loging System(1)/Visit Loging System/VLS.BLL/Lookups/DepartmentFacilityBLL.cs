﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <20-06-2016 12:03:11PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace BLL.Lookups
{
    public class DepartmentFacilityBLL
    {
        /// <summary>
        /// Get all active hospital equipments information
        /// </summary>
        /// <returns></returns>
        public List<DepartmentFacilityModel> GetActiveDepartmentFacilities()
        {
            List<DepartmentFacilityModel> colDepartmentFacilities = new List<DepartmentFacilityModel>();

            DataTable dt = LazyBaseSingletonDAL<DepartmentFacilityDAL>.Instance.GetDepartmentFacilities();
            if (dt.Rows.Count > 0)
                colDepartmentFacilities = (List<DepartmentFacilityModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DepartmentFacilityModel());

            return colDepartmentFacilities;
        }

        /// <summary>
        /// Get all (active & block) information
        /// </summary>
        /// <returns></returns>
        public List<DepartmentFacilityModel> GetHospitalEquipments()
        {
            List<DepartmentFacilityModel> colDepartmentFacilities = new List<DepartmentFacilityModel>();

            DataTable dt = LazyBaseSingletonDAL<DepartmentFacilityDAL>.Instance.GetAll();
            if (dt.Rows.Count > 0)
                colDepartmentFacilities = (List<DepartmentFacilityModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DepartmentFacilityModel());

            return colDepartmentFacilities;
        }

        /// <summary>
        /// Save Information 
        /// </summary>
        /// <param name="model"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int Save(DepartmentFacilityModel model, int? userId)
        {
            CommonBLL commonBLL = new CommonBLL();

            try
            {
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblDepartmentFacility, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.FacilityID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }

                    model.ModifiedBy = userId;

                    return LazyBaseSingletonDAL<DepartmentFacilityDAL>.Instance.Edit(model);
                }

                else if (commonBLL.IsExist(TableName.tblDepartmentFacility, ColumnName.Title, model.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                else
                {
                    model.CreatedBy = userId;

                    return LazyBaseSingletonDAL<DepartmentFacilityDAL>.Instance.Add(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                commonBLL = null;
            }
        }

        /// <summary>
        /// De-activate information
        /// </summary>
        /// <param name="model"></param>
        /// <param name="ModifiedBy"></param>
        /// <returns></returns>
        public int Delete(DepartmentFacilityModel model)
        {
            try
            {
                return LazyBaseSingletonDAL<DepartmentFacilityDAL>.Instance.Delete(model);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region "internal and Private Methods"


        internal List<DepartmentFacilityModel> BindData(DataTable dt)
        {
            List<DepartmentFacilityModel> lists = new List<DepartmentFacilityModel>();

            if (dt.Rows.Count > 0)

                lists = (List<DepartmentFacilityModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DepartmentFacilityModel());

            return lists;
        }

        #endregion
    }
}
