﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <07-04-2016 11:46:22AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace BLL.Lookups
{
    public class DoctorPostBLL
    {
        /// <summary>
        /// Get all active docotrs posts information
        /// </summary>
        /// <returns></returns>
        public List<DoctorPostModel> GetActiveDoctorPosts()
        {
            List<DoctorPostModel> colDoctorPosts = new List<DoctorPostModel>();

            DataTable dt = LazyBaseSingletonDAL<DoctorPostDAL>.Instance.GetDoctorPosts();
            if (dt.Rows.Count > 0)
                colDoctorPosts = (List<DoctorPostModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DoctorPostModel());

            return colDoctorPosts;
        }

        public int Save(DoctorPostModel Model)
        {
            CommonBLL commonBLL = new CommonBLL();
            try
            {
                if (Model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblDoctorPosts, ColumnName.Title, Model.Title, commonBLL.GetClause(ColumnName.DoctorPostID, Model.ID)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    return new DoctorPostDAL().Edit(Model);
                }
                else if (commonBLL.IsExist(TableName.tblDoctorPosts, ColumnName.Title, Model.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                else
                    return new DoctorPostDAL().Add(Model);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<DoctorPostModel> GetAllDoctorPosts()
        {
            DataTable dt = null;
            dt = new DoctorPostDAL().GetAll();
            return BindData(dt);
        }

        public int Delete(int id, int modifiedBy)
        {
            return new DoctorPostDAL().Delete(id, modifiedBy);
        }

        internal List<DoctorPostModel> BindData(DataTable dt)
        {
            List<DoctorPostModel> lists = new List<DoctorPostModel>();

            if (dt.Rows.Count > 0)

                lists = (List<DoctorPostModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DoctorPostModel());

            return lists;
        }

        private DoctorPostModel BuildModel(DataTable dt)
        {
            List<DoctorPostModel> colDepartments = new List<DoctorPostModel>();
            DoctorPostModel dm = new DoctorPostModel();

            if (dt.Rows.Count > 0)
                colDepartments = (List<DoctorPostModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DoctorPostModel());

            if (colDepartments.Count > 0) dm = colDepartments[0];

            return dm;
        }
    }
}
