﻿
using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Lookups;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil >
// Create date: <7/10/2014 2:07:32 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription

// =================================================================================================================================
namespace BLL.Lookups
{
    public class UnionCouncilBLL
    {
        /// <summary>
        /// Save the Union Council Info
        /// </summary>
        /// <param name="unionCouncilModel"></param>
        /// <returns>Result of  add or Updated Status</returns>
        public int Save(UnionCouncilModel unionCouncilModel)
        {
            CommonBLL commonBLL = LazyBaseSingletonBLL<CommonBLL>.Instance;
            int result = 0;
            try
            {
                if (!string.IsNullOrEmpty(unionCouncilModel.Title))
                {
                    Hashtable htbWhere = new Hashtable();
                    htbWhere.Add(ColumnName.DistrictID.ToString(), unionCouncilModel.DistrictID);
                    htbWhere.Add(ColumnName.TehsilID.ToString(), unionCouncilModel.TehsilID);
                    if (unionCouncilModel.ID > 0)
                    {
                        if (commonBLL.IsExist(TableName.tblUnionCouncil, ColumnName.Title, unionCouncilModel.Title, commonBLL.GetClause(htbWhere, ColumnName.UnionCouncilID, unionCouncilModel.ID)))
                        {
                            throw new Exception(CustomMsg.DuplicateTitle);
                        }
                        return new UnionCouncilDAL().Edit(unionCouncilModel);
                    }
                    else if (commonBLL.IsExist(TableName.tblUnionCouncil, ColumnName.Title, unionCouncilModel.Title, commonBLL.GetClause(htbWhere, null, null)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    else
                        return new UnionCouncilDAL().Add(unionCouncilModel);
                }

               


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        /// <summary>
        /// Get all UnionCouncil Info
        /// </summary>
        /// <returns>result of UnionCouncil in UnionCouncilModel class</returns
        public List<UnionCouncilModel> GetUnionCouncil()
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().SelectUnionCouncils();
            return BuildModel(dt);
        }

        /// <summary>
        /// Get all Active UnionCouncil Info
        /// </summary>
        /// <returns>result of UnionCouncil in UnionCouncilModel class</returns
        public List<UnionCouncilModel> GetUnionCouncils()
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().GetAll();
            return BuildModel(dt);
        }
        /// <summary>
        /// Get all Active UnionCouncil Info
        /// </summary>
        /// <returns>result of UnionCouncil in UnionCouncilModel class</returns
        public List<UnionCouncilModel> GetUnionCouncils(int ServiceID)
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().GetAll(ServiceID);
            return BuildModel(dt);
        }

        /// <summary>
        /// Get all Active UnionCouncil Info
        /// </summary>
        /// <returns>result of UnionCouncil in UnionCouncilModel class</returns
        public List<UnionCouncilModel> GetUnionCouncils(int ServiceID, int? UnionCouncilID)
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().GetAll(ServiceID, UnionCouncilID);
            return BuildModel(dt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ServiceID"></param>
        /// <param name="UnionCouncilID1"></param>
        /// <param name="UnionCouncilID2"></param>
        /// <returns></returns>
        public List<UnionCouncilModel> GetUnionCouncils(int ServiceID, int? UnionCouncilID1, int? UnionCouncilID2)
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().GetAll(ServiceID, UnionCouncilID1, UnionCouncilID2);
            return BuildModel(dt);
        }

        /// <summary>
        /// Delete the UnionCouncil By ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>success or error Type on delete </returns>
        public int Delete(int id, string modifiedBy)
        {
            return new UnionCouncilDAL().Delete(id, modifiedBy);
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="id"></param>
        /// <param name="servcieID"></param>
        /// <returns></returns>
        public int Delete(int id, int servcieID)
        {
            return new UnionCouncilDAL().Delete(id, servcieID);
        }

        /// <summary>
        /// CR:001
        /// </summary>
        /// <returns></returns>
        public DataTable GetUnionCouncilsByTehsil(int TehsilID)
        {
            return new UnionCouncilDAL().SelectUnionCouncilsByTehsil(TehsilID);
        }
        /// <summary>
        /// CR:001
        /// </summary>
        /// <returns></returns>
        public List<UnionCouncilModel> GetUnionCouncilsByTehsilID(int tehsilID)
        {
            return BuildModel(new UnionCouncilDAL().SelectUnionCouncilsByTehsil(tehsilID));
        }

        #region "Private Methods"

        /// <summary>
        /// Bind the UnionCouncil Model with Data Table
        /// </summary>
        /// <param name="dt"></param>
        /// <returns>UnionCouncilModel class</returns>
        internal List<UnionCouncilModel> BuildModel(DataTable dt)
        {
            List<UnionCouncilModel> unionCouncils = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                unionCouncils = new List<UnionCouncilModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    UnionCouncilModel unionCouncilModel = new UnionCouncilModel();

                    if (dt.Columns.Contains("UnionCouncilID") && !Convert.IsDBNull(dr["UnionCouncilID"]))
                        unionCouncilModel.ID = Convert.ToInt32(dr["UnionCouncilID"]);
                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        unionCouncilModel.DistrictID = Convert.ToInt32(dr["DistrictID"]);
                    if (dt.Columns.Contains("TehsilID") && !Convert.IsDBNull(dr["TehsilID"]))
                        unionCouncilModel.TehsilID = Convert.ToInt32(dr["TehsilID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        unionCouncilModel.Title = Convert.ToString(dr["Title"]);
                   
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        unionCouncilModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        unionCouncilModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("TehsilName") && !Convert.IsDBNull(dr["TehsilName"]))
                        unionCouncilModel.TehsilName = Convert.ToString(dr["TehsilName"]);
                    if (dt.Columns.Contains("DistrictName") && !Convert.IsDBNull(dr["DistrictName"]))
                        unionCouncilModel.DistrictName = Convert.ToString(dr["DistrictName"]);
                    if (dt.Columns.Contains("AccountNo") && !Convert.IsDBNull(dr["AccountNo"]))
                        unionCouncilModel.AccountNo = Convert.ToString(dr["AccountNo"]);

                    unionCouncils.Add(unionCouncilModel);
                }

                unionCouncils.TrimExcess();
            }

            return unionCouncils;
        }

        #endregion

    }
}
