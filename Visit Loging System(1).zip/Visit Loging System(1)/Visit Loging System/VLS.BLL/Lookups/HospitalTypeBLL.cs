﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <07-04-2016 11:46:22AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace BLL.Lookups
{
    public class HospitalTypeBLL
    {
        /// <summary>
        /// Get all active hospital types information
        /// </summary>
        /// <returns></returns>
        public List<HospitalTypeModel> GetActiveHospitalTypes()
        {
            List<HospitalTypeModel> colHospitalTypes = new List<HospitalTypeModel>();

            DataTable dt = LazyBaseSingletonDAL<HospitalTypeDAL>.Instance.GetHospitalTypes();
            if (dt.Rows.Count > 0)
                colHospitalTypes = (List<HospitalTypeModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new HospitalTypeModel());

            return colHospitalTypes;
        }

        public int Save(HospitalTypeModel HospitalTypeModel)
        {
            CommonBLL commonBLL = new CommonBLL();
            try
            {
                if (HospitalTypeModel.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblHospitalType, ColumnName.Title, HospitalTypeModel.Title, commonBLL.GetClause(ColumnName.HospitalTypeID, HospitalTypeModel.ID)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    return new HospitalTypeDAL().Edit(HospitalTypeModel);
                }
                else if (commonBLL.IsExist(TableName.tblGroups, ColumnName.Title, HospitalTypeModel.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                else
                    return new HospitalTypeDAL().Add(HospitalTypeModel);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public List<HospitalTypeModel> GetHospitalType()
        {
            DataTable dt = null;
            //dt = new HospitalTypeDAL().SelectGroups();
            dt = new HospitalTypeDAL().GetHospitalTypes();
            return BindData (dt);
        }

        public DataTable GetGroups()
        {
            DataTable dt = null;
            dt = new HospitalTypeDAL().GetAll();
            return dt;
        }

        public List<HospitalTypeModel> GetAllHospitalType()
        {
            DataTable dt = null;
            dt = new HospitalTypeDAL().GetAll();
            return BindData(dt);
        }

        public int Delete(int id, int modifiedBy)
        {
            return new HospitalTypeDAL().Delete(id, modifiedBy);
        }

        internal List<HospitalTypeModel> BindData(DataTable dt)
        {
            List<HospitalTypeModel> lists = new List<HospitalTypeModel>();

            if (dt.Rows.Count > 0)

                lists = (List<HospitalTypeModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new HospitalTypeModel());

            return lists;
        }

        private HospitalTypeModel BuildModel(DataTable dt)
        {
            List<HospitalTypeModel> colDepartments = new List<HospitalTypeModel>();
            HospitalTypeModel dm = new HospitalTypeModel();

            if (dt.Rows.Count > 0)
                colDepartments = (List<HospitalTypeModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new HospitalTypeModel());

            if (colDepartments.Count > 0) dm = colDepartments[0];

            return dm;
        }
    }
}
