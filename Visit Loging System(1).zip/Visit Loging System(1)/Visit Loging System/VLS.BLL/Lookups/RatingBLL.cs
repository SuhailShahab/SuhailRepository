﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<SOHAIL KAMRAN >
// Create date: <4-4-2016 10:40:55PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR:001       SOHAIL KAMRAN               Added GetAllRatings/Save/Delete/BindData Methods
// =================================================================================================================================
namespace BLL.Lookups
{
    public class RatingBLL
    {
        /// <summary>
        /// Get All Rating Information
        /// </summary>
        /// <returns></returns>
        public List<RatingModel> GetAllRatings()
        {
            List<RatingModel> colRatings = new List<RatingModel>();

            DataTable dt = LazyBaseSingletonDAL<RatingDAL>.Instance.GetAllRatings();
            if (dt.Rows.Count > 0)
                colRatings = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new RatingModel());

            return colRatings;
        }

        /// <summary>
        /// Saving Rating Information
        /// </summary>
        /// <param name="model"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int Save(RatingModel model, int? userId)
        {
            CommonBLL commonBLL = new CommonBLL();
            try
            {
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblRating, ColumnName.Name, model.Title, commonBLL.GetClause(ColumnName.RateID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }

                    model.ModifiedBy = userId;


                    return LazyBaseSingletonDAL<RatingDAL>.Instance.Edit(model);
                }

                else if (commonBLL.IsExist(TableName.tblRating, ColumnName.Name, model.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                else
                {
                    model.CreatedBy = userId;

                    return LazyBaseSingletonDAL<RatingDAL>.Instance.Add(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                commonBLL = null;

            }
        }

        /// <summary>
        /// In-active  Rating Information
        /// </summary>
        /// <param name="model"></param>
        /// <param name="modifiedBy"></param>
        /// <returns></returns>
        public int Delete(RatingModel model, int? modifiedBy)
        {
            try
            {
                return LazyBaseSingletonDAL<RatingDAL>.Instance.Delete(new RatingModel(model.ID, modifiedBy));

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public RatingModel GetRatingByID(int rateID)
        {
            DataTable dt = LazyBaseSingletonDAL<RatingDAL>.Instance.GetRateByRateID(rateID);
            return BuildModel(dt);
        }

        #region "internal and Private Methods"


        private List<RatingModel> BindData(DataTable dt)
        {
            List<RatingModel> lists = new List<RatingModel>();

            if (dt.Rows.Count > 0)

                lists = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new RatingModel());

            return lists;
        }

        private RatingModel BuildModel(DataTable dtRating)
        {
            List<RatingModel> colRating = new List<RatingModel>();
            RatingModel rm = new RatingModel();

            if (dtRating.Rows.Count > 0)
                colRating = (List<RatingModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dtRating, new RatingModel());

            if (colRating.Count > 0) rm = colRating[0];

            return rm;
        }

        #endregion
    }
}
