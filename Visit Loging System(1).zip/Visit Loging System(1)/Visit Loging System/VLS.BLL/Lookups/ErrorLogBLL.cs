﻿
using BE.LogManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLS.DAL.LogManager;

namespace BLL.Lookups
{
    public class ErrorLogBLL
    {
        public List<ErrorLogModel> GetErrorLogs(ErrorLogModel ErrorLogModel)
        {
            DataTable dt = null;
            dt = new ErrorLogDAL().GetErrorRecords(ErrorLogModel);
            return this.BuildModel(dt);

        }

        public List<ErrorLogModel> GetErrorLogs()
        {
            DataTable dt = null;
            dt = new ErrorLogDAL().GetErrorRecords();
            return this.BuildModel(dt);

        }
        public List<ErrorLogModel> GetErrorLogsBySearchCretira(int? searchByID, string searchByMessage)
        {
            DataTable dt = null;
            try
            {
                dt = new ErrorLogDAL().GetErrorLogsBySearchCretira(searchByID, searchByMessage);
                return BuildModel(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region "Private Methods"


        internal List<ErrorLogModel> BuildModel(DataTable dt)
        {
            List<ErrorLogModel> ErrorLogs = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                ErrorLogs = new List<ErrorLogModel>();

                foreach (DataRow dr in dt.Rows)
                {
                    ErrorLogModel ErrorLogModel = new ErrorLogModel();

                    if (dt.Columns.Contains("logID") && !Convert.IsDBNull(dr["logID"]))
                        ErrorLogModel.logID = Convert.ToInt32(dr["logID"]);

                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        ErrorLogModel.DistrictID = Convert.ToInt32(dr["DistrictID"]);

                    if (dt.Columns.Contains("Method") && !Convert.IsDBNull(dr["Method"]))
                        ErrorLogModel.Method = Convert.ToString(dr["Method"]);

                    if (dt.Columns.Contains("Message") && !Convert.IsDBNull(dr["Message"]))
                        ErrorLogModel.Message = Convert.ToString(dr["Message"]);

                    if (dt.Columns.Contains("StackTrace") && !Convert.IsDBNull(dr["StackTrace"]))
                        ErrorLogModel.StackTrace = Convert.ToString(dr["StackTrace"]);

                    if (dt.Columns.Contains("Source") && !Convert.IsDBNull(dr["Source"]))
                        ErrorLogModel.Source = Convert.ToString(dr["Source"]);

                    if (dt.Columns.Contains("IsWebMethod") && !Convert.IsDBNull(dr["IsWebMethod"]))
                        ErrorLogModel.IsWebMethod = Convert.ToInt32(dr["IsWebMethod"]);

                    if (dt.Columns.Contains("CreatedDate") && !Convert.IsDBNull(dr["CreatedDate"]))
                        ErrorLogModel.CreatedDate = Convert.ToDateTime(dr["CreatedDate"]);

                    if (dt.Columns.Contains("PageName") && !Convert.IsDBNull(dr["PageName"]))
                        ErrorLogModel.PageName = Convert.ToString(dr["PageName"]);

                    ErrorLogs.Add(ErrorLogModel);
                }

                ErrorLogs.TrimExcess();
            }

            return ErrorLogs;
        }

        #endregion
    }
}
