﻿
using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<SOHAIL KAMRAN >
// Create date: <4-4-2016 10:40:55PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// CR:001       SOHAIL KAMRAN               Added GetAllRatings/Save/Delete/BindData Methods
// =================================================================================================================================
namespace BLL.Lookups
{
    public class ConstituencyBLL
    {
        /// <summary>
        /// Saving Constituency Record
        /// </summary>
        /// <param name="model"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int Save(ConstituencyModel model, int? userId)
        {
            
            CommonBLL commonBLL = new CommonBLL();
            try
            {
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblConstituency, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.ConstituencyID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }

                    model.ModifiedBy = userId;
                    model.District = null;
                    
                   

                    return LazyBaseSingletonDAL<ConstituencyDAL>.Instance.Edit (model);
                }

                else if (commonBLL.IsExist(TableName.tblConstituency, ColumnName.Title, model.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                else
                {
                    model.CreatedBy = userId;

                    return LazyBaseSingletonDAL<ConstituencyDAL>.Instance.Add(model);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                commonBLL = null;

            }

        }

        /// <summary>
        /// Getting All Constituency Records
        /// </summary>
        /// <returns></returns>
        public List<ConstituencyModel> GetAllConstituencyies()
        {
            DataTable dt = null;
            //dt = new ConstituencyDAL().GetAll();
            dt = LazyBaseSingletonDAL<ConstituencyDAL>.Instance.GetAll();
            return BindData(dt);

        }

        /// <summary>
        ///  Getting Constituency Records
        /// </summary>
        /// <returns></returns>
        public List<ConstituencyModel> GetConstituency()
        {
            DataTable dt = null;
            //dt = new ConstituencyDAL().GetConstituency();
            dt =LazyBaseSingletonDAL<ConstituencyDAL>.Instance.GetConstituency();
            return BindData(dt);
            
        }


        /// <summary>
        /// disable Constituency Model
        /// </summary>
        /// <param name="model"></param>
        /// <param name="ModifiedBy"></param>
        /// <returns></returns>
        public int Delete(ConstituencyModel model, int? ModifiedBy)
        {
            try
            {
                return LazyBaseSingletonDAL<ConstituencyDAL>.Instance.Delete(new ConstituencyModel(model.ID, ModifiedBy));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To de-activative 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(ConstituencyModel model)
        {
            try
            {
                return LazyBaseSingletonDAL<ConstituencyDAL>.Instance.Delete(new ConstituencyModel(model.ID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region "internal and Private Methods"

       
        internal List<ConstituencyModel> BindData(DataTable dt)
        {
            List<ConstituencyModel> lists = new List<ConstituencyModel>();

            if (dt.Rows.Count > 0)

                lists = (List<ConstituencyModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new ConstituencyModel());

            return lists;
        }

        #endregion
    }
}
