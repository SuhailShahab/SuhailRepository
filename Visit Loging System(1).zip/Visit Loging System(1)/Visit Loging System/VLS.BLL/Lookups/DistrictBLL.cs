﻿using BE.Lookups;
using DAL.Lookups;
using DAL.Enums;
using System;
using System.Collections.Generic;
using System.Data;
using BLL.CommonUtility;
using DAL.Generic;
using BE.CustomEnums;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <22-03-2015 02:01:17PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BLL.Lookups
{
    public class DistrictBLL
    {
        #region "Public Methods"

        /// <summary>
        /// Add/Edit a district record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(DistrictModel model)
        {
            CommonBLL commonBLL = new CommonBLL();
            if (model.ID.HasValue && model.ID.Value > 0)        // edit record
            {
                if (commonBLL.IsExist(TableName.tblDistrict, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.DistrictID, model.ID.Value)))
                    throw new Exception(CustomMsg.DuplicateTitle);
                else
                    return LazyBaseSingletonDAL<DistrictDAL>.Instance.Edit(model);
            }
            else if (commonBLL.IsExist(TableName.tblDistrict, ColumnName.Title, model.Title, null))
            {
                throw new Exception(CustomMsg.DuplicateTitle);
            }
            else
                return LazyBaseSingletonDAL<DistrictDAL>.Instance.Add(model);
        }

        /// <summary>
        /// Block a district record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(DistrictModel model)
        {
            return LazyBaseSingletonDAL<DistrictDAL>.Instance.Delete(model.ID, model.ModifiedBy);
        }

        /// <summary>
        /// Get all districts information
        /// </summary>
        /// <returns></returns>
        public List<DistrictModel> SelectAll()
        {
            List<DistrictModel> colDistricts = new List<DistrictModel>();
            
            DataTable dt = LazyBaseSingletonDAL<DistrictDAL>.Instance.SelectAll();
            if (dt.Rows.Count > 0)
                colDistricts = (List<DistrictModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DistrictModel());

            return colDistricts;
        }

        /// <summary>
        /// Get all active districts information
        /// </summary>
        /// <returns></returns>
        public List<DistrictModel> SelectAllActive()
        {
            List<DistrictModel> colDistricts = new List<DistrictModel>();

            DataTable dt = LazyBaseSingletonDAL<DistrictDAL>.Instance.SelectAllActive();
            if (dt.Rows.Count > 0)
                colDistricts = (List<DistrictModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DistrictModel());

            return colDistricts;
        }

        /// <summary>
        /// Get all district information against division
        /// </summary>
        /// <param name="divisionID"></param>
        /// <returns></returns>
        public List<DistrictModel> GetAllDistrictsByDivisionID(int? divisionID)
        {
            List<DistrictModel> colDistricts = new List<DistrictModel>();

            DataTable dt = LazyBaseSingletonDAL<DistrictDAL>.Instance.SelectDistrictsByDivisionID(divisionID);
            if (dt.Rows.Count > 0)
                colDistricts = (List<DistrictModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DistrictModel());

            return colDistricts;
        }

        #endregion
    }
}
