﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Lookups
{
    public class SiteInfoBLL
    {
        /// <summary>
        /// Saving Constituency Record
        /// </summary>
        /// <param name="model"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public int Save(SiteInformationModel model, int? userId)
        {

            CommonBLL commonBLL = new CommonBLL();
            try
            {
               if (model.ID > 0)
               {
                //    if (commonBLL.IsExist(TableName.tblSiteInfo, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.InfoID, model.ID.Value)))
                //    {
                //        throw new Exception(CustomMsg.DuplicateTitle);
                //    }

                    model.ModifiedBy = userId;
                   

                    return LazyBaseSingletonDAL<SiteInfoDAL>.Instance.Edit(model);
                }

                //else if (commonBLL.IsExist(TableName.tblSiteInfo, ColumnName.Title, model.Title, null))
                //{
                //    throw new Exception(CustomMsg.DuplicateTitle);
                //}
                else
                {
                    model.CreatedBy = userId;

                    return LazyBaseSingletonDAL<SiteInfoDAL>.Instance.Add(model);
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                commonBLL = null;

            }

        }

        /// <summary>
        /// Get All Site Info
        /// </summary>
        /// <returns></returns>
        public List<SiteInformationModel> GetSiteInfo()
        {
            DataTable dt = null;
            dt = LazyBaseSingletonDAL<SiteInfoDAL>.Instance.GetAll();
            return BindData(dt);

        }

        /// <summary>
        /// Get Site Info
        /// </summary>
        /// <returns></returns>

        //public List<SiteInformationModel> GetiteInfo()
        //{
        //    DataTable dt = null;
        //    dt = LazyBaseSingletonDAL<SiteInfoDAL>.Instance.GetSiteInfo();
        //    return BindData(dt);

        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <param name="ModifiedBy"></param>
        /// <returns></returns>
        public int Delete(SiteInformationModel model, int? ModifiedBy)
        {
            try
            {
                return LazyBaseSingletonDAL<SiteInfoDAL>.Instance.Delete(new SiteInformationModel(model.ID, ModifiedBy));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
       

        #region "internal and Private Methods"

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<SiteInformationModel> BindData(DataTable dt)
        {
            List<SiteInformationModel> lists = new List<SiteInformationModel>();

            if (dt.Rows.Count > 0)

                lists = (List<SiteInformationModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SiteInformationModel());

            return lists;
        }

       

      

        #endregion
    }
}
