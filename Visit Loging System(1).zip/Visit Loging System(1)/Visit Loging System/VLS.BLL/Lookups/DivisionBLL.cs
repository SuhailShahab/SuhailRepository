﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <24-03-2016 10:03:08PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// =================================================================================================================================
namespace BLL.Lookups
{
    public class DivisionBLL
    {
        /// <summary>
        /// Add/Update a division record
        /// </summary>
        /// <param name="divisionModel"></param>
        /// <returns></returns>
        public int? Save(DivisionModel divisionModel)
        {
            CommonBLL commonBLL = new CommonBLL();
            if (divisionModel.ID.HasValue && divisionModel.ID.Value > 0)
            {
                if (commonBLL.IsExist(TableName.tblDivision, ColumnName.Title, divisionModel.Title, commonBLL.GetClause(ColumnName.DivisionID, divisionModel.ID.Value)))
                    throw new Exception(CustomMsg.DuplicateTitle);
                else
                    return LazyBaseSingletonDAL<DivisionDAL>.Instance.Edit(divisionModel);
            }
            else if (commonBLL.IsExist(TableName.tblDivision, ColumnName.Title, divisionModel.Title, null))
            {
                throw new Exception(CustomMsg.DuplicateTitle);
            }
            else
                return LazyBaseSingletonDAL<DivisionDAL>.Instance.Add(divisionModel);
        }

        /// <summary>
        /// Block a division record
        /// </summary>
        /// <param name="DivisionID"></param>
        /// <returns></returns>
        public int Delete(int DivisionID, int ModifiedBy)
        {
            return LazyBaseSingletonDAL<DivisionDAL>.Instance.Delete(DivisionID, ModifiedBy);
        }

        /// <summary>
        /// Get all (active and blocked) divisions information
        /// </summary>
        /// <returns></returns>
        public List<DivisionModel> GetDivision()
        {
            List<DivisionModel> colDivisions = new List<DivisionModel>();

            DataTable dt = LazyBaseSingletonDAL<DivisionDAL>.Instance.Select();
            if (dt.Rows.Count > 0)
                colDivisions = (List<DivisionModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DivisionModel());

            return colDivisions;
        }

        /// <summary>
        /// Get all active divisions information
        /// </summary>
        /// <returns></returns>
        public List<DivisionModel> GetDivisions()
        {
            List<DivisionModel> colDivisions = new List<DivisionModel>();

            DataTable dt = LazyBaseSingletonDAL<DivisionDAL>.Instance.GetAll();
            if (dt.Rows.Count > 0)
                colDivisions = (List<DivisionModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new DivisionModel());

            return colDivisions;
        }

        #region "Private Methods"

        internal List<DivisionModel> BuildModel(DataTable dt)
        {
            List<DivisionModel> Divisions = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                Divisions = new List<DivisionModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    DivisionModel DivisionModel = new DivisionModel();
                    if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                        DivisionModel.ID = Convert.ToInt32(dr["DivisionID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        DivisionModel.Title = Convert.ToString(dr["Title"]);

                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        DivisionModel.Description = Convert.ToString(dr["Description"]);


                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        DivisionModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("ProvinceName") && !Convert.IsDBNull(dr["ProvinceName"]))
                        DivisionModel.ProvinceName = Convert.ToString(dr["ProvinceName"]);
                    if (dt.Columns.Contains("ProvinceID") && !Convert.IsDBNull(dr["ProvinceID"]))
                        DivisionModel.ProvinceID = Convert.ToInt32(dr["ProvinceID"]);
                    Divisions.Add(DivisionModel);
                }

                Divisions.TrimExcess();
            }

            return Divisions;
        }

        #endregion

    }
}

