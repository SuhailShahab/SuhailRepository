﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Atif Farooq>
// Create date: <02-06-2015 04:27:05PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace BLL.Lookups
{
    public class TehsilBLL
    {
        #region "Public Methods"

        /// <summary>
        /// Add/Edit tehsil record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(TehsilModel model)
        {
            CommonBLL commonBLL = new CommonBLL();

            if (model.ID.HasValue && model.ID.Value > 0)        // edit record
            {
                if (commonBLL.IsExist(TableName.tblTehsil, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.TehsilID, model.ID.Value)))
                    throw new Exception(CustomMsg.DuplicateTitle);
                else
                    return LazyBaseSingletonDAL<TehsilDAL>.Instance.Edit(model);
            }
            else if (commonBLL.IsExist(TableName.tblTehsil, ColumnName.Title, model.Title, null))
            {
                throw new Exception(CustomMsg.DuplicateTitle);
            }
            else
                return LazyBaseSingletonDAL<TehsilDAL>.Instance.Add(model);
        }

        /// <summary>
        /// Block a specific tehsil record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Delete(TehsilModel model)
        {
            return LazyBaseSingletonDAL<TehsilDAL>.Instance.Delete(model.ID, model.ModifiedBy);
        }

        /// <summary>
        /// Get all tehsils information
        /// </summary>
        /// <returns></returns>
        public List<TehsilModel> SelectAll()
        {
            List<TehsilModel> colTehsils = new List<TehsilModel>();

            DataTable dt = LazyBaseSingletonDAL<TehsilDAL>.Instance.SelectAll();
            if (dt.Rows.Count > 0)
                colTehsils = (List<TehsilModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new TehsilModel());

            return colTehsils;
        }

        /// <summary>
        /// Get all active tehsils information
        /// </summary>
        /// <returns></returns>
        public List<TehsilModel> SelectAllActive()
        {
            List<TehsilModel> colTehsils = new List<TehsilModel>();

            DataTable dt = LazyBaseSingletonDAL<TehsilDAL>.Instance.SelectAllActive();
            if (dt.Rows.Count > 0)
                colTehsils = (List<TehsilModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new TehsilModel());

            return colTehsils;
        }

        /// <summary>
        /// Get all active tehsil by district
        /// </summary>
        /// <param name="districtID"></param>
        /// <returns></returns>
        public List<TehsilModel> GetTehsilByDistrictID(int districtID)
        {
            List<TehsilModel> colTehsils = new List<TehsilModel>();

            DataTable dt = LazyBaseSingletonDAL<TehsilDAL>.Instance.SelectByDistrictID(districtID);
            if (dt.Rows.Count > 0)
                colTehsils = (List<TehsilModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new TehsilModel());

            return colTehsils;
        }

        public List<TehsilModel> GetTehsilByCSV(List<string> districtIDs)
        {
            List<TehsilModel> colTehsils = new List<TehsilModel>();

            string csvOfDistrictIDs = string.Join(",", districtIDs.ToArray());
            DataTable dt = LazyBaseSingletonDAL<TehsilDAL>.Instance.GetByCSV(csvOfDistrictIDs);
            if (dt.Rows.Count > 0)
                colTehsils = (List<TehsilModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new TehsilModel());

            return colTehsils;
        }

        #endregion

        #region "Private Methods"

        private List<TehsilModel> BuildModelCollection(DataTable dt)
        {
            List<TehsilModel> Tehsils = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                Tehsils = new List<TehsilModel>();

                foreach (DataRow dr in dt.Rows)
                {
                    TehsilModel dm = new TehsilModel();

                    if (dt.Columns.Contains("TehsilID") && !Convert.IsDBNull(dr["TehsilID"]))
                        dm.ID = Convert.ToInt32(dr["TehsilID"].ToString());
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        dm.Title = dr["Title"].ToString();
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        dm.Description = dr["Description"].ToString();
                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        dm.ID = Convert.ToInt32(dr["DistrictID"].ToString());
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        dm.Status = Convert.ToBoolean(dr["IsActive"].ToString());

                    Tehsils.Add(dm);
                }

                Tehsils.TrimExcess();
            }

            return Tehsils;
        }

        #endregion
    }
}
