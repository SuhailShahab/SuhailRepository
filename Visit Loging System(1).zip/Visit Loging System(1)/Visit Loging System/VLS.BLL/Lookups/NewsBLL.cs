﻿using System;
using System.Data;
using System.Collections.Generic;

using System.Text;
using BE.Lookups;
using BLL.CommonUtility;
using BE.CustomEnums;
using DAL.Lookups;
using BLL.RightsManager;
using DAL.Generic;



namespace BLL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Sabeeh Goheer>
    // Create date: <20/04/2016 1:04:04 AM>
    // =================================================================================================================================
    // ===================================================== Modification News  ======================================================
    // =================================================================================================================================
    public class NewsBLL
    {
        /// <summary>
        /// Save the News Info
        /// </summary>
        /// <param name="NewsModel"></param>
        /// <returns>Result of  add or Updated Status</returns>
        public int Save(NewsModel NewsModel)
        {

            CommonBLL commonBLL = new CommonBLL();

            int result = 0;
            try
            {
                if (!string.IsNullOrEmpty(NewsModel.Title))
                {
                    if (NewsModel.ID.HasValue && NewsModel.ID.Value > 0)
                    {
                        if (commonBLL.IsExist(TableName.tblNews, ColumnName.Title, NewsModel.Title, commonBLL.GetClause(ColumnName.NewsID, NewsModel.ID.Value)))
                        {
                            throw new Exception(CustomMsg.DuplicateTitle);
                        }


                        return new NewsDAL().Edit(NewsModel);
                    }
                    else if (commonBLL.IsExist(TableName.tblNews, ColumnName.Title, NewsModel.Title, null))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    else
                        return new NewsDAL().Add(NewsModel);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        

        /// <summary>
        /// Get all News Info
        /// </summary>
        /// <returns>result of News in NewsModel class</returns
        public List<NewsModel> GetNews()
        {
            DataTable dt = null;
            dt = new NewsDAL().SelectNews();
            return this.BuildModel(dt);

        }

        /// <summary>
        /// Get All Active News for drowpdown 
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public List<NewsModel> GetAllNews()
        {
            DataTable dt = null;
            dt = new NewsDAL().GetAllNews();
            return this.BuildModel(dt);

        }

        public SiteInformationModel GetFVMSSiteInfo()
        {
            DataTable dt = null;
            List<SiteInformationModel> lists = null;
            try
            {

               dt = LazyBaseSingletonDAL<NewsDAL>.Instance.SelectSiteInfo();
                if (dt.Rows.Count > 0)
                    lists = (List<SiteInformationModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new SiteInformationModel());

                if(lists!=null && lists.Count>0)
                {
                    return lists[0];
                }
                else
                {
                    return null;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Delete the News By ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>success or error Type on delete </returns>
        public int Delete(NewsModel model, int? ModifiedBy)
        {
            return new NewsDAL().Delete(new NewsModel(model.ID, ModifiedBy));
        }

        /// <summary>
        /// Get News by ID
        /// </summary>
        /// <param name="NewsID"></param>
        /// <returns>NewsModel</returns>
        public NewsModel GetNewsByID(int NewsID)
        {
            DataTable dt = null;
            dt = new NewsDAL().GetNewsByID(NewsID);
            return this.BuildNewsModel(dt);

        }

        #region "Private Methods"



        /// <summary>
        /// Bind the News Model with Data Table
        /// </summary>
        /// <param name="dt"></param>
        /// <returns>NewsModel class</returns>
        internal List<NewsModel> BuildModel(DataTable dt)
        {
            List<NewsModel> News = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                News = new List<NewsModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    NewsModel NewsModel = new NewsModel();
                    if (dt.Columns.Contains("NewsID") && !Convert.IsDBNull(dr["NewsID"]))
                        NewsModel.ID = Convert.ToInt32(dr["NewsID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        NewsModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        NewsModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("NewsDate") && !Convert.IsDBNull(dr["NewsDate"]))
                        NewsModel.NewsDate = Convert.ToDateTime(dr["NewsDate"]);
                    if (dt.Columns.Contains("Image") && !Convert.IsDBNull(dr["Image"]))
                    {
                        byte[] Image = (byte[])(dr["Image"]);
                        NewsModel.Image = new UserBLL().ConvertBytesToBase64(Image);
                    }

                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        NewsModel.Status = Convert.ToBoolean(dr["IsActive"]);



                    News.Add(NewsModel);
                }

                News.TrimExcess();
            }

            return News;
        }

        /// <summary>
        /// Bind the News Model with Data Table for a single news 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns>NewsModel class</returns>
        internal NewsModel BuildNewsModel(DataTable dt)
        {
            NewsModel NewsModel = new NewsModel();

            foreach (DataRow dr in dt.Rows)
            {
                
                if (dt.Columns.Contains("NewsID") && !Convert.IsDBNull(dr["NewsID"]))
                    NewsModel.ID = Convert.ToInt32(dr["NewsID"]);
                if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                    NewsModel.Title = Convert.ToString(dr["Title"]);
                if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                    NewsModel.Description = Convert.ToString(dr["Description"]);
                if (dt.Columns.Contains("NewsDate") && !Convert.IsDBNull(dr["NewsDate"]))
                    NewsModel.NewsDate = Convert.ToDateTime(dr["NewsDate"]);
                if (dt.Columns.Contains("Image") && !Convert.IsDBNull(dr["Image"]))
                {
                    byte[] Image = (byte[])(dr["Image"]);
                    NewsModel.Image = new UserBLL().ConvertBytesToBase64(Image);
                }

                if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    NewsModel.Status = Convert.ToBoolean(dr["IsActive"]);
            }
            return NewsModel;
        }

        #endregion
    }
}
