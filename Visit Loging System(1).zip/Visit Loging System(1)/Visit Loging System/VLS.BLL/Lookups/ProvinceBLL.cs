﻿using BE.CustomEnums;
using BE.Lookups;
using BLL.CommonUtility;
using DAL.Generic;
using DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

namespace BLL.Lookups
{
    public class ProvinceBLL
    {
        /// <summary>
        /// Add or update a province record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(ProvinceModel model)
        {
            CommonBLL commonBLL = LazyBaseSingletonBLL<CommonBLL>.Instance;
            if (model.ID > 0)
            {
                if (commonBLL.IsExist(TableName.tblProvince, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.ProvinceID, model.ID)))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                return LazyBaseSingletonDAL<ProvinceDAL>.Instance.Edit(model);
            }
            else if (commonBLL.IsExist(TableName.tblProvince, ColumnName.Title, model.Title, null))
            {
                throw new Exception(CustomMsg.DuplicateTitle);
            }
            else
                return LazyBaseSingletonDAL<ProvinceDAL>.Instance.Add(model);
        }

        public int Delete(int id)
        {
            return LazyBaseSingletonDAL<ProvinceDAL>.Instance.Delete(id);
        }

        /// <summary>
        /// Getting All Provinces Record  
        /// </summary>
        /// <returns></returns>
        public List<ProvinceModel> GetAllProvinces()
        {
            List<ProvinceModel> colProvinces = new List<ProvinceModel>();

            DataTable dt = LazyBaseSingletonDAL<ProvinceDAL>.Instance.GetAllProvinces();
            if (dt.Rows.Count > 0)
                colProvinces = (List<ProvinceModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new ProvinceModel());

            return colProvinces;
        }

        /// <summary>
        /// Getting All Active Provinces Record  
        /// </summary>
        /// <returns></returns>
        public List<ProvinceModel> GetAllActiveProvinces()
        {
            List<ProvinceModel> colProvinces = new List<ProvinceModel>();

            DataTable dt = LazyBaseSingletonDAL<ProvinceDAL>.Instance.GetAllActiveProvinces();
            if (dt.Rows.Count > 0)
                colProvinces = (List<ProvinceModel>)LazyBaseSingletonBLL<CommonBuildModel>.Instance.BuildModel(dt, new ProvinceModel());

            return colProvinces;
        }


        #region "Private Methods"

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<ProvinceModel> BuildModel(DataTable dt)
        {
            List<ProvinceModel> provinceModelList = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                provinceModelList = new List<ProvinceModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    ProvinceModel model = new ProvinceModel();
                    if (dt.Columns.Contains("ProvinceID") && !Convert.IsDBNull(dr["ProvinceID"]))
                        model.ID = Convert.ToInt32(dr["ProvinceID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        model.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        model.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        model.Status = Convert.ToBoolean(dr["IsActive"]);

                    provinceModelList.Add(model);
                }

                provinceModelList.TrimExcess();
            }

            return provinceModelList;
        }

        #endregion
    }
}
