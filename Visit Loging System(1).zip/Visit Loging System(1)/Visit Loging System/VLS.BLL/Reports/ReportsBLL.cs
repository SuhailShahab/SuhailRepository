﻿using BE.Reports;
using DAL.Generic;
using DAL.Reports;
using System;
using System.Collections.Generic;
using System.Data;

namespace BLL.Reports
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <25-Mar-2016 02:50:05PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time              Desription
    // CR:001       Syed Zeeshan Aqil           30-March-2016                   Add method GetRptAssignTaskDetail to get Action taken report data
    // =================================================================================================================================

    public class ReportsBLL
    {
        /// <summary>
        /// Get Secretary Visitor Log Report
        /// </summary>
        /// <param name="deptID"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public DataSet GetRptSecretaryVisitingLog(int deptID, int userId, int fromMonth, int fromYear, int toMonth, int toYear)
        {
            DataSet ds = null;
            ds = new ReportsDAL().GetRptSecretaryVisitingLogData(deptID, userId,  fromMonth,  fromYear,  toMonth,  toYear);
            ds.Tables[0].TableName = "tblSecretaryVisitingLog";
            ds.Tables[1].TableName = "tblSecretary2VisitingLog";
            return ds;
        }

        public DataTable GetRptDepartmentVisitsLog(int? departmentID, int? districtID, int? divisionID, int fromMonth, int fromYear, int toMonth, int toYear, int userID)
        {
            return LazyBaseSingletonDAL<ReportsDAL>.Instance.GetRptDepartmentVisitsLogs(departmentID, districtID, divisionID,fromMonth, fromYear, toMonth, toYear,  userID);
        }

        public DataTable GetRptOfficialDistrictVisitsLog(int? createdBy,int? departmentID, int? districtID, int? divisionID, int fromMonth, int fromYear, int toMonth, int toYear)
        {
            return LazyBaseSingletonDAL<ReportsDAL>.Instance.GetRptOfficialDistrictVisitsLog(createdBy,departmentID, districtID, divisionID, fromMonth, fromYear, toMonth, toYear);
        }

        public DataTable GetRptRamzanBazarVisitLog(int? createdBy, int? departmentID, int? districtID, int? divisionID, int fromMonth, int fromYear, int toMonth, int toYear, string designationCSV)
        {
            return LazyBaseSingletonDAL<ReportsDAL>.Instance.GetRptRamzanBazarVisitLog(createdBy, departmentID, districtID, divisionID, fromMonth, fromYear, toMonth, toYear, designationCSV);
        }

        /// <summary>
        /// Getting Visit Action By District
        /// </summary>
        /// <param name="fromMonth"></param>
        /// <param name="fromYear"></param>
        /// <param name="toMonth"></param>
        /// <param name="toYear"></param>
        /// <param name="districtID"></param>
        /// <returns></returns>
        public DataTable GetRptOfficialVisitActionByDistrict(int fromMonth, int fromYear, int toMonth, int toYear, int? districtID,int? deptID,int ? divisionID, int userID)
        {
            return LazyBaseSingletonDAL<ReportsDAL>.Instance.GetRptOfficialVisitActionByDistrict(fromMonth, fromYear, toMonth, toYear, districtID, deptID, divisionID,userID);
        }

        /// <summary>
        /// Getting Visit Action By Department
        /// </summary>
        /// <param name="fromMonth"></param>
        /// <param name="fromYear"></param>
        /// <param name="toMonth"></param>
        /// <param name="toYear"></param>
        /// <param name="departmentID"></param>
        /// <returns></returns>
        public DataTable GetRptOfficialVisitActionByDepartment(int fromMonth, int fromYear, int toMonth, int toYear, int? departmentID, int? divisionID, int? districtID, int  userID)
        {
            return LazyBaseSingletonDAL<ReportsDAL>.Instance.GetRptOfficialVisitActionByDepartment(fromMonth, fromYear, toMonth, toYear, departmentID, divisionID, districtID, userID);
        }


        public DataTable GetRptActionTakenPerform(int fromMonth, int fromYear, int toMonth, int toYear, int? userID)
        {
            return LazyBaseSingletonDAL<ReportsDAL>.Instance.GetRptActionTakenPerform(fromMonth, fromYear, toMonth, toYear, userID);
        }

        /// <summary>
        /// Get the Action taken Report
        /// </summary>
        /// <param name="visitorLogID">selected visitorLog ID</param>
        /// <returns>Data set</returns>
        public DataSet GetRptAssignTaskDetail(int visitorLogID)
        {

            DataSet ds = null;
            ds = new ReportsDAL().GetRptAssignTaskDetail(visitorLogID);
           
            return ds;
        }

        public DataSet GetRamzanBazarMonitoringDetail(int visitorLogID)
        {

            DataSet ds = null;
            ds = new ReportsDAL().GetRamzanBazarMonitoringDetail(visitorLogID);

            return ds;
        }

        public DataTable GetOfficialsVisitsObservationByDistrict(int? departmentID, int? districtID, int? divisionID, int FromMonth, int FromYear, int ToMonth, int ToYear)
        {
            return LazyBaseSingletonDAL<ReportsDAL>.Instance.GetOfficialsVisitsObservationByDistrict(departmentID,districtID,divisionID, FromMonth, FromYear, ToMonth, ToYear);
        }

        public DataTable GetOfficialsVisitsObservationByDistrict(int DistrictID, DateTime? FromDate, DateTime? ToDate)
        {
            return LazyBaseSingletonDAL<ReportsDAL>.Instance.GetOfficialsVisitsObservationByDistrict(DistrictID, FromDate, ToDate);
        }

        /// <summary>
        /// Get Action Taken Attach Documents
        /// </summary>
        /// <param name="taskID">selected taskID</param>
        /// <returns></returns>
        public DataTable GetActionTakenDocument(int taskID)
        {
            return LazyBaseSingletonDAL<ReportsDAL>.Instance.GetActionTakenDocument(taskID);
        }


      


    }
}
