﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.DataModelLayer
{
    public class ErrorLogModel 
    {
        public int logID { get; set; }       
        public string LocationCode { get; set; }       
        public string ServiceCode { get; set; }      
        public int DivisionID { get; set; }     
        public int DistrictID { get; set; }      
        public string Method { get; set; }
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public string Source { get; set; }
        public int IsWebMethod { get; set; }
        public DateTime Created { get;set; }
        public string PageName { get; set; }
        public string PageStaticName { get; set; }
        public Exception CustomException { get; set; }        
        public string FromDate { get; set; }
        public string ToDate { get; set; }
       
        public  DataTable DataUser{ get; set; }
     

        

        public ErrorLogModel()
        { 

        }
        public ErrorLogModel(Exception ex, string methodName, int webMethod,   string PageName)
        {
            this.CustomException = ex;
            this.Method  = methodName;
            this.IsWebMethod = webMethod;
          
            this.PageName = PageName;
        }

        public string GetaAllMessages()
        {
            string message = string.Empty;
            Exception innerException = this.CustomException;

            do
            {
                message = message + (string.IsNullOrEmpty(innerException.Message) ? string.Empty : innerException.Message);
                innerException = innerException.InnerException;
            }
            while (innerException != null);

            return message;
        }
        

        }

    public class ErrorLogModelView
    {
        //public List<LocationModel> Locations { get; set; }
        //public List<PageNameModel> PageNames { get; set; }
        //public List<DivisionModel> Divisions { get; set; }
        //public List<DistrictModel> Districts { get; set; }
        //public List<ServiceModel>  Services  { get; set; }
        public List<ErrorLogModel> ErrorLogs { get; set; }

    }
}
