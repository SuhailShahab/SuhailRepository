﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.Base
{
   public  class ThirdPartyBase
    {
        public string ThirdPartyID { get; set; }
        public string ThirdPartyTitle { get; set; }
        public bool IsActive { get; set; }       
        public bool IsThirdParty { get; set; }
    }
}
