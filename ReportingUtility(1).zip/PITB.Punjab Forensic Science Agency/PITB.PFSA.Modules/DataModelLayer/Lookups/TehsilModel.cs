﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.DataModelLayer.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:01AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class TehsilModel : BaseModel
    {
        public int ID { get; set; }
        public int DistrictID { get; set; }
        public string DistrictName { get; set; }
        public string Title { get; set; }
        public string TitleUrdu { get; set; }
        public string StaticName { get; set; }
        public string Description { get; set; }
        public bool Status { get; set; }
        
        // Added New By Sohail Kamran
      //  public List<ServiceTehsil> ThirdPartyRecord { get; set; }

    }

    public class TehsilModelView
    {
        public List<TehsilModel> Tehsils { get; set; }
        public List<GeneralDistrictModel> Districts { get; set; }
        
        // Added New By Sohail Kamran
      //  public List<ServiceModel> Services { get; set; }
        public List<TehsilModel> AllActiveTehsils { get; set; }
        
    }

    public class ServiceTehsil
    {
        public string ThirdPartyID { get; set; }
        public string ThirdPartyTitle { get; set; }
        public bool IsActive { get; set; }
        public int SelectedTehsilID { get; set; }
        public bool IsThirdParty { get; set; }
    }
}
