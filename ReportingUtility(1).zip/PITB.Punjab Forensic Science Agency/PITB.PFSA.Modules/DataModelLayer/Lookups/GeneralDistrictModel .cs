﻿using PITB.PFSA.Modules.Base;
using PITB.PFSA.Modules.DataModelLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.DataModelLayer.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <26-12-2014 08:30PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time      Desription
    // CR:          Usman Mirza                 10-Jun-2015             Addition of Dropdown for mapping FC District ID 
    // =================================================================================================================================
    public class GeneralDistrictModel : BaseModel
    {
        public int? ID { get; set; }
        public int DivisionID { get; set; }
        public string DivisionName { get; set; }
        public string Title { get; set; }
        public string TitleUrdu { get; set; }
        public string StaticName { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public bool Status { get; set; }
        public string ID_StaticName { get; set; }
        //public int DistrictID { get; set; }
        public string MapDistrictName { get; set; }
        //public string ThirdPartyID { get; set; }
       // public List<ServiceDistrict> ThirdPartyRecord { get; set; }
        public int? MapFCDistrictID { get; set; }

    }

    public class GeneralDistrictModelView
    {
        public List<DivisionModel> Divisions { get; set; }
      //  public List<ServiceModel> Services { get; set; }
        public List<GeneralDistrictModel> AllActiveDistricts { get; set; }
        public List<GeneralDistrictModel> Districts { get; set; }
        public List<DistrictModel> MappedFCDistricts { get; set; }
    }

    public class ServiceDistrict : ThirdPartyBase
    {
        public int SelectedDistrictID { get; set; }
    }
}
