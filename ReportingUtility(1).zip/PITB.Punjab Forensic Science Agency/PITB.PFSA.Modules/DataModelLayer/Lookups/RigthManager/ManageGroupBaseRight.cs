﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.DataModelLayer.RightsManager
{
   public  class ManageGroupBaseRight
    {
       public DataSet dsAllPermitRights { get; set; }
       public bool? AllowFileRemoved { get; set; }
       public bool? AllowFileView { get; set; }
       public bool? AllowFileDownload { get; set; }
       public bool? AllowServiceDataPosting { get; set; }
       public bool? AllowDataUpdate { get; set; }
       public bool? AllowAccessOutSideLocation { get; set; }

       public bool? AllowFileAttachment { get; set; }
       public bool? AllowResidenceHistory { get; set; }
       public bool? AllowPersonalInfo { get; set; }
       public bool? AllowAddressInfo { get; set; }
       public bool? AllowVerification { get; set; } 
    }
}
