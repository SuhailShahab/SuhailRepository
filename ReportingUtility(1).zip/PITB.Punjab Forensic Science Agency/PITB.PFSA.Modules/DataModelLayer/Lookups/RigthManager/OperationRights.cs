﻿using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <08-01-2015 05:14:35PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace PITB.PFSA.Modules.DataModelLayer.RightsManager
{
    public class OperationRights
    {
        public bool AllowFileRemove { get; set; }
    }

    public class CentrePermittedReportAndForms
    {
        public int FeatureID { get; set; }
        public int UserType { get; set; }
    }

    public class ServiceUserRights
    {
        public int RowID { get; set; }
        public int ServiceID { get; set; }
        public bool EnableDeliveryDateEditing { get; set; }
    }
}
