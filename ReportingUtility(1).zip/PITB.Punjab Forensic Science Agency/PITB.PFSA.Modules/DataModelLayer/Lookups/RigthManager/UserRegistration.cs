﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
// ===================================================== Modification History ======================================================
// SR#              Modified By                     Modified Date/Time              Desription
//CR:001            SUHAIL SHAHAB                   11-6-2015                       Add Address Fields
//CR:002            Muhammad Usman                  30-6-2015                       Add Officiating User Rights Fields Fields
// =================================================================================================================================
namespace PITB.PFSA.Modules.DataModelLayer.RightsManager
{
    public class UserRegistration
    {
        public DataTable UserRights { get; set; }
        public DateTime? JoinDate { get; set; }
        public DateTime? ResignDate { get; set; }
        public bool? EnforceRight { get; set; }
        public DataTable CSRManagement { get; set; }
        public DataTable AssigneeStatuses { get; set; }
        public DataTable Statuses { get; set; }
        public DataTable Services { get; set; }
        public string CurrentUserName { get; set; }
        public string BlockReason { get; set; }
        public ManageGroupBaseRight GroupBaseRights { get; set; }
        public bool? Status { get; set; }
        public int? FCLocationID { get; set; }
        public string UserType { get; set; }
        public int? GroupID { get; set; }
        public string CellNumber { get; set; }
        public string EMail { get; set; }
        public string CNIC { get; set; }
        public string EmployeeName { get; set; }
        public string LoginName { get; set; }
        public int? DepartmentID { get; set; }
        public int? GeneralDistrictID { get; set; }
        public int? FCDistrictID { get; set; }
        public int? TehsilID { get; set; }
        public int? UnionCouncilID { get; set; }
        public int? UserID { get; set; }
        // Start CR:001
        public int? AddressDivisionID { get; set; }
        public int? AddressDistrictID { get; set; }
        public int? AddressTehsilID { get; set; }
        public int? AddressUnionCouncilID { get; set; }
        public string FullAddress { get; set; }
        // END CR:001

        //CR:002
        public DataTable UserOfficiatingRights { get; set; }


        // CR:003
        public DataTable UserFCLocations { get; set; }

    }
}
