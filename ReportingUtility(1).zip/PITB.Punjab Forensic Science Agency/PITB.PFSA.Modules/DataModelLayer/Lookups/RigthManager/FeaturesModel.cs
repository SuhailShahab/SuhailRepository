﻿using PITB.PFSA.Modules.DataModelLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.DataModelLayer.Lookups
{
    public class FeaturesModel : BaseModel
    {
        public int ID { get; set; }
        public string MenuName { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
       
        public string Description { get; set; }

        public int menuLocation { get; set; }
        public int Sort { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        public bool IsActive { get; set; }
        public bool HasChild { get; set; }
    }
}
