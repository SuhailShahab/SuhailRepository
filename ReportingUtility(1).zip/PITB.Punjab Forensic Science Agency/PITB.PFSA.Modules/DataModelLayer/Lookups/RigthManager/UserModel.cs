﻿using System;
using System.Collections.Generic;
using System.Text;

// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <08-01-2015 05:04:07PM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time              Desription
// =================================================================================================================================
namespace PITB.PFSA.Modules.DataModelLayer.RightsManager
{
    public class UserModel : ManageGroupBaseRight
    {
        public int UserID { get; set; }
        public int DepartmentID { get; set; }
        public int DistrictID { get; set; }
        public int TehsilID { get; set; }
        public int UnionCouncilID { get; set; }
        public int GroupID { get; set; }
        public int FCLocation { get; set; }
        public string UserName { get; set; }
        public string EmployeeName { get; set; }
        public string CNIC { get; set; }
        public string EMail { get; set; }
        public string CellNumber { get; set; }
        public string UserType { get; set; }
        public bool IsActive { get; set; }
        public string BlockReason { get; set; }
        public DateTime? JoinDate { get; set; }
        public DateTime? ResignedDate { get; set; }
        public bool IsResigned { get; set; }
        public string User { get; set; }

        //public List<ServiceModel> PermittedServices { get; set; }
        //public List<TaskStatusModel> PermittedAssignStatus { get; set; }
        //public List<TaskStatusModel> PermittedMarkStatus { get; set; }
        public List<CentrePermittedReportAndForms> PermittedCenterReportForm { get; set; }
        //public List<ServiceUserRights> PermittedServicesUserRights { get; set; }
    }

    public class UserModelView
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string EmployeeName { get; set; }
        public string CNIC { get; set; }
        public string District { get; set; }
        public string CellNumber { get; set; }
        public string EMail { get; set; }
        public bool IsActive { get; set; }
    }
}
