﻿using PITB.PFSA.Modules.Base;
using System.Collections.Generic;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <7/10/2014 1:04:04 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#              Modified By                 Modified Date/Time          Desription
// CR:001           Muhammad Hammad Shahid      08-01-2015 12:06:30PM       Add AccountNo property
// =================================================================================================================================
namespace PITB.PFSA.Modules.DataModelLayer.Lookups
{
    
    public class UnionCouncilModel : BaseModel
    {
        public int ID { get; set; }
        public int DistrictID { get; set; }
        public int TehsilID { get; set; }
        public string TehsilName { get; set; }
        public string StaticName { get; set; }
        public string DistrictName { get; set; }        
        public string Title { get; set; }
        public string TitleUrdu { get; set; }
        public string Description { get; set; }
        public bool Status { get; set; }
        public string AccountNo { get; set; }   // add against CR:001

        public List<ServiceUnionCouncil> ThirdPartyRecord { get; set; }
    }

    /// <summary>
    /// UnionCouncilModelView
    /// </summary>
    public class UnionCouncilModelView
    {
        public List<DivisionModel> Divisions { get; set; }
        public List<GeneralDistrictModel> Districts { get; set; }
        public List<TehsilModel> Tehsils { get; set; }
        //
       // public List<ServiceModel> Services { get; set; }
        public List<UnionCouncilModel> UnionCouncil { get; set; }
        public List<UnionCouncilModel> AllActiveUnionConcils { get; set; }
    }

    /// <summary>
    /// 
    /// </summary>
    public class ServiceUnionCouncil : ThirdPartyBase
    {
        public int SelectedUnionConcil { get; set; }
    }
}
