﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.DataModelLayer.Lookups
{
   public  class UserRightsModel
    {
       public int? ServiceID { get; set; }
       public int? UserID { get; set; }
       public bool  IsEditDeliveryDate { get; set; }
    }
}
