﻿using PITB.PFSA.Modules.DataModelLayer;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.DataModelLayer.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:01AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class DistrictModel : BaseModel
    {
        public int? ID { get; set; }
        public int DivisionID { get; set; }
        public string DivisionName { get; set; }
        public string Title { get; set; }
        public string TitleUrdu { get; set; }
        public string StaticName { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public bool Status { get; set; }
        public bool EnableServiceDocumentCenter { get; set; }
        public string ServiceDocumentCenterURL { get; set; }
        public bool EnableCommonDocumentCenter { get; set; }
        public string CommonDocumentCenterURL { get; set; }
        public bool IsActiveCenter { get; set; } 
        //public string ID_StaticName { get; set; }
    }

    public class DistrictModelView : DistrictModel
    {
        public List<DivisionModel> Divisions { get; set; }
        public List<DistrictModel> Districts { get; set; }
        //public List<ServiceModel> FcServices { get; set; }        
        //public bool IsListCreated { get; set; }
       


    }

   
}
