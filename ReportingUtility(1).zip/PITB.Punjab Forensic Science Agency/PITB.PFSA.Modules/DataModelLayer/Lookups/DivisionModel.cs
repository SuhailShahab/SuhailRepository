﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.DataModelLayer.Lookups
{
    // =================================================================================================================================
    // Create by:	<syed Zeeshan Aqil>
    // Create date: <18-08-2014 03:01 PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class DivisionModel : BaseModel
    {
        public int? ID { get; set; }
        public string Title { get; set; }
        public string TitleUrdu { get; set; }
        public string StaticName { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
       // public string AllValue { get; set; }
       
        

    }
}
