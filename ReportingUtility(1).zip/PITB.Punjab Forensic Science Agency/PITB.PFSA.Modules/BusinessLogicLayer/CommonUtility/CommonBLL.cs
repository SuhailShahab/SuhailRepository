﻿
using PITB.PFSA.Modules.CustomEnums;
using PITB.PFSA.Modules.DataAccessLayer;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Reflection;
using System.Text;

// =================================================================================================================================
// Create by:	<>
// Create date: <>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By             Modified Date/Time      Desription
// CR: 001  -   Syed Zeeshan Aqil       17-07-2014 04:32PM      Add SelectLookupsTitle methods
// CR: 002  -   Syed Zeeshan Aqil       17-07-2014 04:32PM      Add SelectLookupsID methods
// CR: 003  -   Suhail Shahab           05-08-2014 07:32PM      Add FillGeneralItems methods
// CR: 004  -   Suhail Shahab           05-08-2014 07:32PM      Add FillSPItems methods
// CR: 005  -   Syed Zeeshan Aqil       26-11-2014 10:32AM      Add FillImages methods
// CR: 006  -   Syed Zeeshan Aqil       28-11-2014 10:32AM      Add ApplyUserRights methods
// CR: 007  -   Syed Zeeshan Aqil       08-12-2014 10:32AM      Add FillBarCodeImages methods
// CR: 008  -   Syed Zeeshan Aqil       16-12-2014 05:00PM      Add RemoveListRecords methods
// CR: 009  -   Syed Zeeshan Aqil       18-12-2014 04:00PM      Add DeletServiceTablesData methods
// CR: 010  -   Syed Zeeshan Aqil       18-12-2014 04:00PM      Add GetMainTableName methods
// CR: 011  -   Syed Zeeshan Aqil       18-12-2014 04:00PM      Add GetTrackTableName methods
// CR: 012  -   Syed Zeeshan Aqil       18-12-2014 04:00PM      Add GetObjectionTableName methods
// CR: 013  -   Muhammad Hammad Shahid  19-12-2014 04:41:47PM   Comment lstItem.Update() line in AddServiceTracks method and set SPListItem as return type, set List<OjectionTypeLineItems> as return type in AddUpdateServiceObjectionTypes() method
// CR: 014  -   Syed Zeeshan Aqil       18-12-2014 04:00PM      Add GetDomicileChildranTableName methods
// CR: 015  -   Syed Zeeshan Aqil       18-12-2014 04:00PM      Add DeleteChildranTable methods
// CR: 016  -   Syed Zeeshan Aqil       18-12-2014 04:00PM      Add GetCharacterResidenceTableName methods
// CR: 017  -   Syed Zeeshan Aqil       18-12-2014 04:00PM      Add DeleteCharacterResidenceTable methods
// CR: 018  -   Suhail Shahab           08-01-2015 3:32PM       Add new field Modther Inforamtion 
// CR: 019  -   Suhail Shahab           28-01-2015 3:32PM       Add new field Issue date and Issue no
// CR: 020  -   Suhail Shahab           28-01-2015 3:32PM       Add new field Issue date and Issue no
// CR: 021 -    Suhail Shahab           07-04-2015              Add  GetServiceAndDeliveryTypes() methods
// CR: 022 -    Suhail Shahab           29-04-2015              Add  Fill Location ID in Method CommonBuildModel
// =================================================================================================================================
namespace PITB.PFSA.Modules.BusinessLogicLayer
{
    public class CommonBLL
    {
        private string districtCode = string.Empty;

        #region "Constructors"

        public CommonBLL()
        {

        }

        #endregion

        #region "OLD Code"


        public bool IsExist(TableName tblName, ColumnName clolumnName, string value, string caluse)
        {

            return new CommonDAL().GetDuplication(tblName.ToString(), clolumnName.ToString(), value, caluse);

        }
        public string GetClause(ColumnName columnName, int id)
        {
            StringBuilder sbClause = new StringBuilder();
            sbClause.Append(columnName.ToString());
            sbClause.Append(" Not IN (");
            sbClause.Append(id);
            sbClause.Append(")");
            return sbClause.ToString();
        }

        public string GetClause(Hashtable coloums, ColumnName? columnName, int? id)
        {
            StringBuilder sbClause = new StringBuilder();

            foreach (DictionaryEntry entry in coloums)
            {
                sbClause.Append(entry.Key);
                sbClause.Append(" = ");
                sbClause.Append(entry.Value.ToString());
                sbClause.Append(" AND ");
            }
            if (id.HasValue)
            {
                sbClause.Append(GetClause(columnName.Value, id.Value));
            }
            else
                sbClause.Append(" 1 = 1 ");
            return sbClause.ToString();
        }


        #endregion





    }
}

