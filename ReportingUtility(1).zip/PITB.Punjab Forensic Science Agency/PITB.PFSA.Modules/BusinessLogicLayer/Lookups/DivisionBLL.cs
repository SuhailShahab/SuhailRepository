﻿using System;
using System.Data;
using System.Collections.Generic;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using PITB.PFSA.Modules.CustomEnums;
using PITB.PFSA.Modules.DataAccessLayer;
namespace PITB.PFSA.Modules.BusinessLogicLayer
{
    // =================================================================================================================================
    // Create by:	<syed Zeeshan Aqil>
    // Create date: <18-08-2014 03:01 PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // CR: 001  -   Syed Zeeshan Aqil           18-08-2014 03:32 PM      Add GetDivision methods
    // CR: 002  -   Syed Zeeshan Aqil           18-08-2014 03:32 PM      Add GetAllDivisions methods
    // CR: 003     Suhail Shahab                15-9-2014                IsExistTitle Duplicatnion Check
    // =================================================================================================================================
    public class DivisionBLL
    {
        public int? Save(DivisionModel divisionModel)
        {
            CommonBLL commonBLL = new CommonBLL();
            if (divisionModel.ID.HasValue && divisionModel.ID.Value > 0)
            {
                
                if (commonBLL.IsExist(TableName.tblDivision, ColumnName.Code, divisionModel.Code, commonBLL.GetClause(ColumnName.DivisionID, divisionModel.ID.Value)))
                {
                    throw new Exception(CustomMsg.DuplicateCode);
                }else
                    if (commonBLL.IsExist(TableName.tblDivision, ColumnName.Title, divisionModel.Title, commonBLL.GetClause(ColumnName.DivisionID, divisionModel.ID.Value)))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }               
                return new DivisionDAL().Edit(divisionModel);
            }
            else if (commonBLL.IsExist(TableName.tblDivision, ColumnName.Title, divisionModel.Title, null))
            {
                throw new Exception(CustomMsg.DuplicateTitle);
            }
            else if (commonBLL.IsExist(TableName.tblDivision, ColumnName.Code, divisionModel.Code, null))
            {
                throw new Exception(CustomMsg.DuplicateCode);
            }
            else
                return new DivisionDAL().Add(divisionModel);
        }

        public List<DivisionModel> GetDivision()
        {
            DataTable dt = null;
            dt = new DivisionDAL().Select();
            return BuildModel(dt);
        }

        public List<DivisionModel> GetDivisions()
        {
            DataTable dt = null;
            dt = new DivisionDAL().GetAll();
            return BuildModel(dt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="divisionID"></param>
        /// <returns></returns>
        public List<DivisionModel> GetDivisions(int? divisionID)
        {
            DataTable dt = null;
            dt = new DivisionDAL().GetAll(divisionID);
            return BuildModel(dt);
        }
       



        public int Delete(int id, string modifiedBy)
        {
            return new DivisionDAL().Delete(id, modifiedBy);
        }


    

        #region "Private Methods"

        internal List<DivisionModel> BuildModel(DataTable dt)
        {
            List<DivisionModel> Divisions = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                Divisions = new List<DivisionModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    DivisionModel DivisionModel = new DivisionModel();
                    if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                        DivisionModel.ID = Convert.ToInt32(dr["DivisionID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        DivisionModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                        DivisionModel.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        DivisionModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        DivisionModel.Code = Convert.ToString(dr["Code"]);
                    if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                        DivisionModel.StaticName = Convert.ToString(dr["StaticName"]);
                   
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        DivisionModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    Divisions.Add(DivisionModel);
                }

                Divisions.TrimExcess();
            }

            return Divisions;
        }

        #endregion

    }
}

