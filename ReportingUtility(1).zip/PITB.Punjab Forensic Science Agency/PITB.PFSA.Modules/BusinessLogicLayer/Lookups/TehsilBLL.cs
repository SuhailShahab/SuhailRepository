﻿using System;
using System.Data;
using System.Collections.Generic;

using System.Collections;

using PITB.PFSA.Modules.CustomEnums;
using PITB.PFSA.Modules.BusinessLogicLayer;
using PITB.PFSA.Modules.DataAccessLayer;
using PITB.PFSA.Modules.DataModelLayer.Lookups;

namespace PITB.PFSA.Modules.BusinessLogicLayer
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:01AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // CR: 001  -   Muhammad Hammad Shahid      11-07-2014 12:32PM      Add GetTehsilsByDistrict methods
    //     002              Suhail Shahab        15-9-2014           IsExistTitle Duplicatnion Check
    // =================================================================================================================================
    public class TehsilBLL
    {
        /// <summary>
        /// Saving Record
        /// </summary>
        /// <param name="tehsilModel"></param>
        /// <returns></returns>
        public int Save(TehsilModel tehsilModel)
        {
            int result = 0;
            try
            {
                CommonBLL commonBLL = new CommonBLL();
                if (!string.IsNullOrEmpty(tehsilModel.Title))
                {
                    Hashtable htbWhere = new Hashtable();
                    htbWhere.Add(ColumnName.DistrictID.ToString(), tehsilModel.DistrictID);
                    if (tehsilModel.ID > 0)
                    { // SR 002

                        if (commonBLL.IsExist(TableName.tblTehsil, ColumnName.Title, tehsilModel.Title, commonBLL.GetClause(htbWhere, ColumnName.TehsilID, tehsilModel.ID)))
                        {
                            throw new Exception(CustomMsg.DuplicateTitle);
                        }
                        return new TehsilDAL().Edit(tehsilModel);
                    }
                    else if (commonBLL.IsExist(TableName.tblTehsil, ColumnName.Title, tehsilModel.Title, commonBLL.GetClause(htbWhere, null, null)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    else
                        return new TehsilDAL().Add(tehsilModel);
                }

                //DataTable dtServcieTehsil = GetServiceTeshilTable(tehsilModel.ThirdPartyRecord, tehsilModel.ServiceID);

                //if (dtServcieTehsil != null && dtServcieTehsil.Rows.Count > 0)
                //{

                //    result = new TehsilDAL().SaveServiceTehsil(tehsilModel.ID, dtServcieTehsil, tehsilModel.CreatedBy);
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        
        /// <summary>
        /// Get Tehsils
        /// </summary>
        /// <returns></returns>
        public List<TehsilModel> GetTehsils()
        {
            DataTable dt = null;
            dt = new TehsilDAL().GetAll();
            return BuildModel(dt);
        }

        /// <summary>
        /// Get Tehsils
        /// </summary>
        /// <returns></returns>
        public List<TehsilModel> GetTehsils(int serviceID)
        {
            DataTable dt = null;
            dt = new TehsilDAL().GetAll(serviceID);
            return BuildModel(dt);
        }

        /// <summary>
        /// Get Tehsils
        /// </summary>
        /// <returns></returns>
        public List<TehsilModel> GetTehsils(int serviceID, int? tehsilID)
        {
            DataTable dt = null;
            dt = new TehsilDAL().GetAll(serviceID, tehsilID);
            return BuildModel(dt);
        }
        /// <summary>
        /// Get Tehsils
        /// </summary>
        /// <returns></returns>
        public List<TehsilModel> GetTehsils(int serviceID, int? tehsilID1, int? tehsilID2)
        {
            DataTable dt = null;
            dt = new TehsilDAL().GetAll(serviceID, tehsilID1, tehsilID2);
            return BuildModel(dt);
            
        }

        public List<TehsilModel> GetTehsil()
        {
            DataTable dt = null;
            dt = new TehsilDAL().Select();
            return BuildModel(dt);
        }
        
        /// <summary>
        /// Delete Tehsil
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, string modifiedBy)
        {
            return new TehsilDAL().Delete(id, modifiedBy);
        }

        /// <summary>
        /// Delete 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="servcieID"></param>
        /// <returns></returns>
        public int Delete(int id, int servcieID)
        {
            return new TehsilDAL().Delete(id, servcieID);
        }

        /// <summary>
        /// CR: 001
        /// </summary>
        /// <param name="DistrictID"></param>
        /// <returns></returns>
        public DataTable GetTehsilsByDistrict(int DistrictID)
        {
            return new TehsilDAL().SelectTehsilsByDistrict(DistrictID);
        }

        /// <summary>
        /// CR: 001
        /// </summary>
        /// <param name="DistrictID"></param>
        /// <returns></returns>
        public List<TehsilModel> GetTehsilsByDistrictID(int districtID)
        {
            return BuildModel(new TehsilDAL().SelectTehsilsByDistrict(districtID));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //public List<TehsilModel> GetServcieTehsils()
        //{
        //    DataSet ds = null;
        //    ds = new TehsilDAL().SelectServiceTehsils();
        //    List<TehsilModel> serviceTehsils = BuildModel(ds.Tables[0]);//Tehsil
        //    BuildServcieTehsilModel(serviceTehsils, ds.Tables[1]);//Set mapping table vlaues
        //    return serviceTehsils;
        //}

        /// <summary>
        /// GetMappedTehsil
        /// </summary>
        /// <param name="servcieID"></param>
        /// <returns></returns>
        public List<ServiceTehsil> GetMappedTehsil(int servcieID)
        {
            DataTable dt = null;
            dt = new TehsilDAL().SelectByServiceID(servcieID);
            return BuildServiceTehsilModel(dt);
        }

        /// <summary>
        ///GetServiceTeshilTable
        /// </summary>
        /// <param name="tehsils"></param>
        /// <param name="servcieID"></param>
        /// <returns></returns>
        public DataTable GetServiceTeshilTable(List<ServiceTehsil> tehsils, int servcieID)
        {
            DataTable dt = null;
            if (tehsils != null && tehsils.Count > 0)
            {
                dt = new DataTable();
                // add columns in the table
                dt.Columns.Add("TehsilID", typeof(System.Int32));
                dt.Columns.Add("ServiceID", typeof(System.Int32));
                dt.Columns.Add("ThirdPartyID", typeof(System.String));
                dt.Columns.Add("ThirdPartyTitle", typeof(System.String));
                dt.Columns.Add("IsActive", typeof(System.Int16));
                DataRow dr = null;
                foreach (ServiceTehsil item in tehsils)
                {
                    if (item.SelectedTehsilID > 0)
                    {
                        dr = dt.NewRow();
                        dr["TehsilID"] = item.SelectedTehsilID;
                        dr["ServiceID"] = servcieID;
                        dr["ThirdPartyID"] = item.ThirdPartyID;
                        dr["ThirdPartyTitle"] = item.ThirdPartyTitle;
                        dr["IsActive"] = item.IsActive;
                        dt.Rows.Add(dr);
                    }


                }

            }
            return dt;
        }

        #region "Private Methods"
        /// <summary>
        /// BuildServiceTehsilModel
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<ServiceTehsil> BuildServiceTehsilModel(DataTable dt)
        {
            List<ServiceTehsil> Tehsils = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                Tehsils = new List<ServiceTehsil>();
                foreach (DataRow dr in dt.Rows)
                {
                    ServiceTehsil TehsilModel = new ServiceTehsil();
                    if (dt.Columns.Contains("TehsilID") && !Convert.IsDBNull(dr["TehsilID"]))
                        TehsilModel.SelectedTehsilID = Convert.ToInt32(dr["TehsilID"]);
                    //if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                    //    genderModel.Title = Convert.ToString(dr["Title"]);
                    //if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                    //    genderModel.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);
                    //if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                    //    genderModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        TehsilModel.IsActive = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("ThirdPartyID") && !Convert.IsDBNull(dr["ThirdPartyID"]))
                        TehsilModel.ThirdPartyID = Convert.ToString(dr["ThirdPartyID"]);
                    if (dt.Columns.Contains("ThirdPartyTitle") && !Convert.IsDBNull(dr["ThirdPartyTitle"]))
                        TehsilModel.ThirdPartyTitle = Convert.ToString(dr["ThirdPartyTitle"]);
                    //if (dt.Columns.Contains("ServiceID") && !Convert.IsDBNull(dr["ServiceID"]))
                    //    genderModel..ServiceID = Convert.ToInt32(dr["ServiceID"]);
                    //if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                    //    genderModel.StaticName = Convert.ToString(dr["StaticName"]);
                    //if (dt.Columns.Contains("ServiceTitle") && !Convert.IsDBNull(dr["ServiceTitle"]))
                    //    genderModel.ServiceTitle = Convert.ToString(dr["ServiceTitle"]);
                    TehsilModel.IsThirdParty = false;

                    Tehsils.Add(TehsilModel);
                }

                Tehsils.TrimExcess();
            }

            return Tehsils;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<TehsilModel> BuildModel(DataTable dt)
        {
            List<TehsilModel> tehsils = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                tehsils = new List<TehsilModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    TehsilModel tehsilModel = new TehsilModel();
                    if (dt.Columns.Contains("TehsilID") && !Convert.IsDBNull(dr["TehsilID"]))
                        tehsilModel.ID = Convert.ToInt32(dr["TehsilID"]);
                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        tehsilModel.DistrictID = Convert.ToInt32(dr["DistrictID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        tehsilModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                        tehsilModel.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        tehsilModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        tehsilModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("DistrictName") && !Convert.IsDBNull(dr["DistrictName"]))
                        tehsilModel.DistrictName = Convert.ToString(dr["DistrictName"]);
                    tehsils.Add(tehsilModel);
                }

                tehsils.TrimExcess();
            }

            return tehsils;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Tehsils"></param>
        /// <param name="dt"></param>
        //internal void BuildServcieTehsilModel(List<TehsilModel> Tehsils, DataTable dt)
        //{

        //    if (dt != null && dt.Rows.Count > 0)
        //    {
        //        foreach (TehsilModel Tehsil in Tehsils)
        //        {
        //            DataRow[] dr = dt.Select(" ServiceID ='" + Tehsil.ServiceID.ToString() + "'");

        //            Tehsil.ThirdPartyRecord = new List<ServiceTehsil>();

        //            foreach (DataRow row in dr)
        //            {
        //                ServiceTehsil reqTehsil = new ServiceTehsil();

        //                if (!Convert.IsDBNull(row["TehsilID"]))
        //                    reqTehsil.SelectedTehsilID = Convert.ToInt32(row["TehsilID"]);

        //                if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(row["IsActive"]))
        //                    reqTehsil.IsActive = Convert.ToBoolean(row["IsActive"]);

        //                if (!Convert.IsDBNull(row["ThirdPartyID"]))
        //                    reqTehsil.ThirdPartyID = Convert.ToString(row["ThirdPartyID"]);

        //                if (!Convert.IsDBNull(row["ThirdPartyTitle"]))
        //                    reqTehsil.ThirdPartyTitle = Convert.ToString(row["ThirdPartyTitle"]);

        //                reqTehsil.IsThirdParty = false;

        //                Tehsil.ThirdPartyRecord.Add(reqTehsil);

        //            }

        //            Tehsil.ThirdPartyRecord.TrimExcess();
        //        }
        //    }

        //}
        #endregion
    }
}
