﻿
using PITB.PFSA.Modules.DataAccessLayer;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using System;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Suhail Shahab>
// Create date: <09-07-2014 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR: 001  -   Muhammad Hammad Shahid      11-07-2014 12:32PM          Add GetDistrict methods
// CR: 002  -   Syed Zeeshan Aqil           11-07-2014 04:32PM          Add GetAllDistricts methods
// CR: 003  -   Syed Zeeshan Aqil           16-09-2014 05:32PM          Add GetDistrictsByDivisionID methods
// CR:004       Muhammad Hammad Shahid      30-12-2014 06:50:23PM       Add GetDistrictByID(), BuildMethod() methods
// CR: 005  -   syed Zeeshan Aqil           09-01-2015 05:32PM          Add GetDistrictByLocationID methods
// =================================================================================================================================
namespace PITB.PFSA.Modules.BusinessLogicLayer
{
    public class DistrictBLL
    {
        public int? Save(DistrictModel districtModel)
        {
            //Hashtable htbWhere = new Hashtable();
            //htbWhere.Add(ColumnName.DivisionID.ToString(), districtModel.DivisionID);
            if (districtModel.ID.HasValue && districtModel.ID.Value > 0)
            {
                //if (CommonBLL.IsExist(TableName.tblDistrict, ColumnName.Code, districtModel.Code, CommonBLL.GetClause(ColumnName.DistrictID, districtModel.ID.Value)))
                //{
                //    throw new Exception(CustomMsg.DuplicateCode);
                //}
                //else if (CommonBLL.IsExist(TableName.tblDistrict, ColumnName.Title, districtModel.Title, CommonBLL.GetClause(ColumnName.DistrictID, districtModel.ID.Value)))
                //{
                //    throw new Exception(CustomMsg.DuplicateTitle);
                //}
                return new DistrictDAL().Edit(districtModel);
            }
            //else if (CommonBLL.IsExist(TableName.tblDistrict, ColumnName.Code, districtModel.Code, CommonBLL.GetClause(htbWhere, null, null)))
            //{
            //    throw new Exception(CustomMsg.DuplicateCode);
            //}
            //else if (CommonBLL.IsExist(TableName.tblDistrict, ColumnName.Title, districtModel.Title, CommonBLL.GetClause(htbWhere, null, null)))
            //{
            //    throw new Exception(CustomMsg.DuplicateTitle);
            //}

            else
                return new DistrictDAL().Add(districtModel);
        }

        public List<DistrictModel> GetDistrict()
        {
            DataTable dt = null;
            dt = new DistrictDAL().Select();
            return BuildModelCollection(dt);
        }

        public List<DistrictModel> GetDistricts()
        {
            DataTable dt = null;
            dt = new DistrictDAL().GetAll();
            return BuildModelCollection(dt);
        }

        public List<DistrictModel> GetAllActiveDistitricts()
        {
            try
            {
                DataTable dt = null;
                dt = new DistrictDAL().GetAllActiveDistitricts();
                return BuildModelCollection(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void AddCertificateList()
        {

        }

        public int Delete(int? id, int? modifiedBy)
        {
            return new DistrictDAL().Delete(id, modifiedBy);
        }

        /// <summary>
        /// CR: 002
        /// Get All District Data from DB
        /// </summary>
        /// <returns>return the District Model with District Data</returns>
        public List<DistrictModel> GetAllDistricts()
        {
            DataTable dt = null;
            dt = new DistrictDAL().SelectDistricts();
            return BuildModelCollection(dt);
        }

        /// <summary>
        /// CR: 003
        /// Get District Data from DB on the basis od Division ID
        /// </summary>
        /// <returns>return the District Model with District Data</returns>
        public List<DistrictModel> GetDistrictsByDivisionID(int divisionID)
        {
            DataTable dt = null;
            dt = new DistrictDAL().GetDistrictsByDivisionID(divisionID);
            return BuildModelCollection(dt);
        }

        public DistrictModel GetDistrictByID(int districtID)
        {
            DataTable dt = null;
            dt = new DistrictDAL().GetDistrictsByID(districtID);
            return BuildModel(dt);
        }

        /// <summary>
        /// CR: 005
        /// Get  districts by Fc Location ID
        /// </summary>
        /// <returns>return the District Model with District Data</returns>
        public DistrictModel GetDistrictByLocationID(int locationID)
        {
            DataTable dt = null;
            dt = new DistrictDAL().GetDistrictByLocationID(locationID);
            return BuildModel(dt);
        }


        #region "Private Methods"

        internal List<DistrictModel> BuildModelCollection(DataTable dt)
        {
            List<DistrictModel> districts = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                districts = new List<DistrictModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    DistrictModel districtModel = new DistrictModel();

                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        districtModel.ID = Convert.ToInt32(dr["DistrictID"]);

                    if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                        districtModel.DivisionID = Convert.ToInt32(dr["DivisionID"]);

                    if (dt.Columns.Contains("DivisionName") && !Convert.IsDBNull(dr["DivisionName"]))
                        districtModel.DivisionName = Convert.ToString(dr["DivisionName"]);

                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        districtModel.Title = Convert.ToString(dr["Title"]);

                    if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                        districtModel.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);

                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        districtModel.Description = Convert.ToString(dr["Description"]);

                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        districtModel.Code = Convert.ToString(dr["Code"]);

                    if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                        districtModel.StaticName = Convert.ToString(dr["StaticName"]);

                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        districtModel.Status = Convert.ToBoolean(dr["IsActive"]);

                    if (dt.Columns.Contains("IsActiveCenter") && !Convert.IsDBNull(dr["IsActiveCenter"]))
                        districtModel.IsActiveCenter = Convert.ToBoolean(dr["IsActiveCenter"]);

                    if (dt.Columns.Contains("EnableServiceDocumentCenter") && !Convert.IsDBNull(dr["EnableServiceDocumentCenter"]))
                        districtModel.EnableServiceDocumentCenter = Convert.ToBoolean(dr["EnableServiceDocumentCenter"]);

                    if (dt.Columns.Contains("ServiceDocumentCenterURL") && !Convert.IsDBNull(dr["ServiceDocumentCenterURL"]))
                        districtModel.ServiceDocumentCenterURL = dr["ServiceDocumentCenterURL"].ToString();

                    if (dt.Columns.Contains("EnableCommonDocumentCenter") && !Convert.IsDBNull(dr["EnableCommonDocumentCenter"]))
                        districtModel.EnableCommonDocumentCenter = Convert.ToBoolean(dr["EnableCommonDocumentCenter"]);

                    if (dt.Columns.Contains("CommonDocumentCenterURL") && !Convert.IsDBNull(dr["CommonDocumentCenterURL"]))
                        districtModel.CommonDocumentCenterURL = dr["CommonDocumentCenterURL"].ToString();

                    //if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                    //    districtModel.ID_StaticName = Convert.ToString(dr["DistrictID"]) + "_" + Convert.ToString(dr["StaticName"]) + "_" + Convert.ToString(dr["Title"]) + "~" + Convert.ToString(dr["DistrictID"]) + "~" + Convert.ToString(dr["TitleUrdu"]);

                    districts.Add(districtModel);
                }

                districts.TrimExcess();
            }

            return districts;
        }

        internal DistrictModel BuildModel(DataTable dt)
        {
            DistrictModel model = new DistrictModel(); ;

            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                    model.ID = Convert.ToInt32(dr["DistrictID"]);

                if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                    model.DivisionID = Convert.ToInt32(dr["DivisionID"]);

                if (dt.Columns.Contains("DivisionName") && !Convert.IsDBNull(dr["DivisionName"]))
                    model.DivisionName = Convert.ToString(dr["DivisionName"]);

                if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                    model.Title = Convert.ToString(dr["Title"]);

                if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                    model.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);

                if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                    model.Description = Convert.ToString(dr["Description"]);

                if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                    model.Code = Convert.ToString(dr["Code"]);

                if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                    model.StaticName = Convert.ToString(dr["StaticName"]);

                if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    model.Status = Convert.ToBoolean(dr["IsActive"]);

                if (dt.Columns.Contains("EnableServiceDocumentCenter") && !Convert.IsDBNull(dr["EnableServiceDocumentCenter"]))
                    model.EnableServiceDocumentCenter = Convert.ToBoolean(dr["EnableServiceDocumentCenter"]);

                if (dt.Columns.Contains("ServiceDocumentCenterURL") && !Convert.IsDBNull(dr["ServiceDocumentCenterURL"]))
                    model.ServiceDocumentCenterURL = dr["ServiceDocumentCenterURL"].ToString();

                if (dt.Columns.Contains("EnableCommonDocumentCenter") && !Convert.IsDBNull(dr["EnableCommonDocumentCenter"]))
                    model.EnableCommonDocumentCenter = Convert.ToBoolean(dr["EnableCommonDocumentCenter"]);

                if (dt.Columns.Contains("CommonDocumentCenterURL") && !Convert.IsDBNull(dr["CommonDocumentCenterURL"]))
                    model.CommonDocumentCenterURL = dr["CommonDocumentCenterURL"].ToString();

                //if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                //    model.ID_StaticName = Convert.ToString(dr["DistrictID"]) + "_" + Convert.ToString(dr["StaticName"]) + "_" + Convert.ToString(dr["Title"]) + "~" + Convert.ToString(dr["DistrictID"]) + "~" + Convert.ToString(dr["TitleUrdu"]);

            }

            return model;
        }

        #endregion

    }
}

