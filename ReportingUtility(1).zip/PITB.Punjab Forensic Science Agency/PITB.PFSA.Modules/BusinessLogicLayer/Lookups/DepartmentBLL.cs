﻿using System;
using System.Data;
using System.Collections.Generic;
using PITB.PFSA.Modules.DataAccessLayer;
using PITB.PFSA.Modules.DataModelLayer;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using PITB.PFSA.Modules.CustomEnums;

namespace PITB.PFSA.Modules.BusinessLogicLayer
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:30AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class DepartmentBLL
    {
        public int Save(DepartmentModel model)
        {
            CommonBLL commonBLL = new CommonBLL();
            if (model.ID > 0)
            {
                if (commonBLL.IsExist(TableName.tblDepartment, ColumnName.Code, model.Code, commonBLL.GetClause(ColumnName.DepartmentID, model.ID)))
                {
                    throw new Exception(CustomMsg.DuplicateCode);
                }
                else if (commonBLL.IsExist(TableName.tblDepartment, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.DepartmentID, model.ID)))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                return new DepartmentDAL().Edit(model);
            }
            else if (commonBLL.IsExist(TableName.tblDepartment, ColumnName.Code, model.Code, null))
            {
                throw new Exception(CustomMsg.DuplicateCode);
            }
            else if (commonBLL.IsExist(TableName.tblDepartment, ColumnName.Title, model.Title, null))
            {
                throw new Exception(CustomMsg.DuplicateTitle);
            }
           
            else
                return new DepartmentDAL().Add(model);
        }
        public List<DepartmentModel> GetDepartments()
        {
            DataTable dt = null;
            dt = new DepartmentDAL().GetAll();
            return BuildModel(dt);
        }
        public List<DepartmentModel> GetDepartment()
        {
            DataTable dt = null;
            dt = new DepartmentDAL().SelectDepartments();
            return BuildModel(dt);
        }

        public int Delete(int id, string modifiedBy)
        {
            return new DepartmentDAL().Delete(id, modifiedBy);
        }

        #region "Private Methods"

        internal List<DepartmentModel> BuildModel(DataTable dt)
        {
            List<DepartmentModel> departments = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                departments = new List<DepartmentModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    DepartmentModel departmentModel = new DepartmentModel();

                    departmentModel.ID = Convert.ToInt32(dr["DepartmentID"]);
                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        departmentModel.Code = Convert.ToString(dr["Code"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        departmentModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        departmentModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    departmentModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    departments.Add(departmentModel);
                }

                departments.TrimExcess();
            }

            return departments;
        }

        #endregion
    }
}
