﻿using PITB.PFSA.Modules.DataAccessLayer.Lookups;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.BusinessLogicLayer.Lookups
{
   public  class UserTypeBLL
    {
        /// <summary>
        /// Get all UserTypes Info
        /// </summary>
        /// <returns>result of City in CityModel class</returns
       public List<UserTypeModel> GetAllUsersType()
        {
            DataTable dt = null;
            dt = new UserTypeDAL().GetAllUsersType();
            return BuildModel(dt);
        }

       #region "Private Methods"

       /// <summary>
       /// Bind the User Type Model with Data Table
       /// </summary>
       /// <param name="dt"></param>
       /// <returns>CityModel class</returns>
       internal List<UserTypeModel> BuildModel(DataTable dt)
       {
           List<UserTypeModel> usersTypeModel = null;

           if (dt != null && dt.Rows.Count > 0)
           {
               usersTypeModel = new List<UserTypeModel>();
               foreach (DataRow dr in dt.Rows)
               {
                   UserTypeModel userTypeModel = new UserTypeModel();
                   if (dt.Columns.Contains("UserTypeID") && !Convert.IsDBNull(dr["UserTypeID"]))
                       userTypeModel.ID = Convert.ToInt32(dr["UserTypeID"]);
                   if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                       userTypeModel.Title = Convert.ToString(dr["Title"]);      
                   if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                       userTypeModel.StaticName  = Convert.ToString(dr["StaticName"]);                   
                   if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                       userTypeModel.Description = Convert.ToString(dr["Description"]);
                   if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                       userTypeModel.Status = Convert.ToBoolean(dr["IsActive"]);
                   usersTypeModel.Add(userTypeModel);
               }

               usersTypeModel.TrimExcess();
           }

           return usersTypeModel;
       }

       #endregion
    }
}
