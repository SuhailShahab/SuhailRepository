﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Collections;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using PITB.PFSA.Modules.CustomEnums;
using PITB.PFSA.Modules.BusinessLogicLayer;
using PITB.PFSA.Modules.DataAccessLayer;

namespace PITB.PFSA.Modules.BusinessLogicLayer
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <26-12-2014 08:30PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time      Desription

    // =================================================================================================================================

    public class GeneralDistrictBLL
    {
        public int? Save(GeneralDistrictModel districtModel)
        {


            try
            {
                CommonBLL commonBLL = new CommonBLL();
                if (!string.IsNullOrEmpty(districtModel.Title))
                {

                    Hashtable htbWhere = new Hashtable();
                    htbWhere.Add(ColumnName.DivisionID.ToString(), districtModel.DivisionID);
                    if (districtModel.ID.HasValue && districtModel.ID.Value > 0)
                    {
                        if (commonBLL.IsExist(TableName.tblGeneralDistrict, ColumnName.Title, districtModel.Title, commonBLL.GetClause(ColumnName.DistrictID, districtModel.ID.Value)))
                       {
                           throw new Exception(CustomMsg.DuplicateTitle);
                       }
                        return new GeneralDistrictDAL().Edit(districtModel);
                    }
                    else if (commonBLL.IsExist(TableName.tblGeneralDistrict, ColumnName.Title, districtModel.Title, commonBLL.GetClause(htbWhere, null, null)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    else
                        return new GeneralDistrictDAL().Add(districtModel);
                }
               // DataTable dtServcieDistrict = GetServiceDistrictTable(districtModel.ThirdPartyRecord, districtModel.ServiceID);
                //if (dtServcieDistrict != null && dtServcieDistrict.Rows.Count > 0)
                //{

                   // return new GeneralDistrictDAL().SaveServiceDistrict(dtServcieDistrict, districtModel.CreatedBy);
               // }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        public List<GeneralDistrictModel> GetDistrict()
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().Select();
            return BuildModel(dt);
        }

        public List<GeneralDistrictModel> GetDistricts()
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().GetAll();
            return BuildModel(dt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fcDistrictID"></param>
        /// <returns></returns>
        public List<GeneralDistrictModel> GetDistrictsByFCDistrictID(int fcDistrictID)
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().GetDistrictsByFCDistrictID(fcDistrictID);
            return BuildModel(dt);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceID"></param>
        /// <param name="districtID"></param>
        /// <returns></returns>
        public List<GeneralDistrictModel> GetDistricts(int serviceID, int? districtID)
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().GetAll(serviceID, districtID);
            return BuildModel(dt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceID"></param>
        /// <param name="districtID1"></param>
        /// <param name="districtID2"></param>
        /// <returns></returns>
        public List<GeneralDistrictModel> GetDistricts(int serviceID, int? districtID1, int? districtID2)
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().GetAll(serviceID, districtID1, districtID2);
            return BuildModel(dt);
        }

        private void AddCertificateList()
        {


        }

        public int Delete(int id, string modifiedBy)
        {
            return new GeneralDistrictDAL().Delete(id, modifiedBy);
        }
        public int DeleteServiceDistrict(int id, int serivceID)
        {
            return new GeneralDistrictDAL().DeleteServiceDistrict(id, serivceID);
        }

        /// <summary>
        /// CR: 002
        /// Get All District Data from DB
        /// </summary>
        /// <returns>return the District Model with District Data</returns>
        public List<GeneralDistrictModel> GetAllDistricts()
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().SelectDistricts();
            return BuildModel(dt);
        }

        ///// <summary>
        /////  Created By Suahil Shahab Get All Active Distirst to fill in drowpdown of Report and admin pages
        ///// </summary>
        ///// <returns></returns>
        //public List<GeneralDistrictModel> GetAllActiveDistricts()
        //{
        //    DataTable dt = null;
        //    dt = new GeneralDistrictDAL().GetAllActiveDistricts();
        //    return BuildModel(dt);
        //}


        /// <summary>
        /// CR: 003
        /// Get District Data from DB on the basis od Division ID
        /// </summary>
        /// <returns>return the District Model with District Data</returns>
        public List<GeneralDistrictModel> GetDistrictsByDivisionID(int DivisionID)
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().GetDistrictsByDivisionID(DivisionID);
            return BuildModel(dt);
        }


        public DataTable GetServiceDistrictTable(List<ServiceDistrict> district, int servcieID)
        {
            DataTable dt = null;
            if (district != null && district.Count > 0)
            {
                dt = new DataTable();
                // add columns in the table
                dt.Columns.Add("SelectedDistrictID", typeof(System.Int32));
                dt.Columns.Add("ServiceID", typeof(System.Int32));
                dt.Columns.Add("ThirdPartyID", typeof(System.String));
                dt.Columns.Add("ThirdPartyTitle", typeof(System.String));
                dt.Columns.Add("IsActive", typeof(System.Int16));
                DataRow dr = null;
                foreach (ServiceDistrict item in district)
                {
                    if (item.SelectedDistrictID > 0)
                    {
                        dr = dt.NewRow();
                        dr["SelectedDistrictID"] = item.SelectedDistrictID;
                        dr["ServiceID"] = servcieID;
                        dr["ThirdPartyID"] = item.ThirdPartyID;
                        dr["ThirdPartyTitle"] = item.ThirdPartyTitle;
                        dr["IsActive"] = item.IsActive;
                        dt.Rows.Add(dr);
                    }


                }

            }
            return dt;
        }



        public List<ServiceDistrict> GetMappedDistrict(int servcieID)
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().SelectDistrictByServiceID(servcieID);
            return BuildDistrictModel(dt);
        }


        #region "Private Methods"

        internal List<GeneralDistrictModel> BuildModel(DataTable dt)
        {
            List<GeneralDistrictModel> districts = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                districts = new List<GeneralDistrictModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    GeneralDistrictModel GeneralDistrictModel = new GeneralDistrictModel();
                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        GeneralDistrictModel.ID = Convert.ToInt32(dr["DistrictID"]);
                    if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                        GeneralDistrictModel.DivisionID = Convert.ToInt32(dr["DivisionID"]);
                    if (dt.Columns.Contains("DivisionName") && !Convert.IsDBNull(dr["DivisionName"]))
                        GeneralDistrictModel.DivisionName = Convert.ToString(dr["DivisionName"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        GeneralDistrictModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                        GeneralDistrictModel.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        GeneralDistrictModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        GeneralDistrictModel.Code = Convert.ToString(dr["Code"]);
                    if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                        GeneralDistrictModel.StaticName = Convert.ToString(dr["StaticName"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        GeneralDistrictModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    //if (dt.Columns.Contains("MapFCDistrictID") && !Convert.IsDBNull(dr["MapFCDistrictID"]))
                    //    GeneralDistrictModel.DistrictID = Convert.ToInt32(dr["MapFCDistrictID"]);
                    if (dt.Columns.Contains("MapDistrictName") && !Convert.IsDBNull(dr["MapDistrictName"]))
                        GeneralDistrictModel.MapDistrictName = Convert.ToString(dr["MapDistrictName"]);
                      if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                          GeneralDistrictModel.ID_StaticName = Convert.ToString(dr["DistrictID"]) + "_" + Convert.ToString(dr["StaticName"]) + "_" + Convert.ToString(dr["Title"]) + "~" + Convert.ToString(dr["DistrictID"]) + "~" + Convert.ToString(dr["TitleUrdu"]);
                   
                    if (dt.Columns.Contains("MapFCDistrictID") && !Convert.IsDBNull(dr["MapFCDistrictID"]))
                          GeneralDistrictModel.MapFCDistrictID = Convert.ToInt32(dr["MapFCDistrictID"]);

                    districts.Add(GeneralDistrictModel);
                }

                districts.TrimExcess();
            }

            return districts;
        }

        /// <summary>
        /// Bind the Districts Model with Data Table
        /// </summary>
        /// <param name="dt"></param>
        /// <returns>General District model class</returns>
        internal List<ServiceDistrict> BuildDistrictModel(DataTable dt)
        {
            List<ServiceDistrict> districts = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                districts = new List<ServiceDistrict>();
                foreach (DataRow dr in dt.Rows)
                {
                    ServiceDistrict districtModel = new ServiceDistrict();
                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        districtModel.SelectedDistrictID = Convert.ToInt32(dr["DistrictID"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        districtModel.IsActive = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("ThirdPartyID") && !Convert.IsDBNull(dr["ThirdPartyID"]))
                        districtModel.ThirdPartyID = Convert.ToString(dr["ThirdPartyID"]);
                    if (dt.Columns.Contains("ThirdPartyTitle") && !Convert.IsDBNull(dr["ThirdPartyTitle"]))
                        districtModel.ThirdPartyTitle = Convert.ToString(dr["ThirdPartyTitle"]);

                    districtModel.IsThirdParty = false;
                    districts.Add(districtModel);
                }
                districts.TrimExcess();
            }

            return districts;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal GeneralDistrictModel BuildGeneralDistrictModel(DataTable dt)
        {
            GeneralDistrictModel model = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                model = new GeneralDistrictModel();

                if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                    model.ID = Convert.ToInt32(dr["DistrictID"]);
                if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                    model.DivisionID = Convert.ToInt32(dr["DivisionID"]);
                if (dt.Columns.Contains("DivisionName") && !Convert.IsDBNull(dr["DivisionName"]))
                    model.DivisionName = Convert.ToString(dr["DivisionName"]);
                if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                    model.Title = Convert.ToString(dr["Title"]);
                if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                    model.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);
                if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                    model.Description = Convert.ToString(dr["Description"]);
                if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                    model.Code = Convert.ToString(dr["Code"]);
                if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                    model.StaticName = Convert.ToString(dr["StaticName"]);
                if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    model.Status = Convert.ToBoolean(dr["IsActive"]);
                if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                    model.ID_StaticName = Convert.ToString(dr["DistrictID"]) + "_" + Convert.ToString(dr["StaticName"]) + "_" + Convert.ToString(dr["Title"]) + "~" + Convert.ToString(dr["DistrictID"]) + "~" + Convert.ToString(dr["TitleUrdu"]);

                if (dt.Columns.Contains("MapFCDistrictID") && !Convert.IsDBNull(dr["MapFCDistrictID"]))
                    model.MapFCDistrictID = Convert.ToInt32(dr["MapFCDistrictID"]);


            }

            return model;
        }
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public GeneralDistrictModel GetDistrictByID(int ID)
        {
            DataTable dt = new GeneralDistrictDAL().GetDistrictModelByDistrictID(ID);
            return BuildGeneralDistrictModel(dt);
        }
    }
}

