﻿
using PITB.PFSA.Modules.BusinessLogicLayer;
using PITB.PFSA.Modules.CustomEnums;
using PITB.PFSA.Modules.DataAccessLayer;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil >
// Create date: <7/10/2014 2:07:32 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// CR:001  -    Muhammad Hammad Shahid      11-07-2014 12:32PM      Add GetUnionCouncilsByTehsil methods
// CR:002       Suhail Shahab               15-9-2014               IsExistTitle Duplicatnion Check
// =================================================================================================================================
namespace PITB.PFSA.Modules.BusinessLogicLayer
{
    public class UnionCouncilBLL
    {
        /// <summary>
        /// Save the Union Council Info
        /// </summary>
        /// <param name="unionCouncilModel"></param>
        /// <returns>Result of  add or Updated Status</returns>
        public int Save(UnionCouncilModel unionCouncilModel)
        {
            int result = 0;
            try
            {
                CommonBLL commonBLL = new CommonBLL();
                if (!string.IsNullOrEmpty(unionCouncilModel.Title))
                {
                    Hashtable htbWhere = new Hashtable();
                    htbWhere.Add(ColumnName.DistrictID.ToString(), unionCouncilModel.DistrictID);
                    htbWhere.Add(ColumnName.TehsilID.ToString(), unionCouncilModel.TehsilID);
                    if (unionCouncilModel.ID > 0)
                    {
                        if (commonBLL.IsExist(TableName.tblUnionCouncil, ColumnName.Title, unionCouncilModel.Title, commonBLL.GetClause(htbWhere, ColumnName.UnionCouncilID, unionCouncilModel.ID)))
                        {
                            throw new Exception(CustomMsg.DuplicateTitle);
                        }
                        return new UnionCouncilDAL().Edit(unionCouncilModel);
                    }
                    else if (commonBLL.IsExist(TableName.tblUnionCouncil, ColumnName.Title, unionCouncilModel.Title, commonBLL.GetClause(htbWhere, null, null)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    else
                        return new UnionCouncilDAL().Add(unionCouncilModel);
                }

                //DataTable dtServcieUnionCouncil = GetServiceUnionCouncilTable(unionCouncilModel.ThirdPartyRecord, unionCouncilModel.ServiceID);

                //if (dtServcieUnionCouncil != null && dtServcieUnionCouncil.Rows.Count > 0)
                //{

                //    result = new UnionCouncilDAL().SaveServiceUnionCouncil(unionCouncilModel.ID, dtServcieUnionCouncil, unionCouncilModel.CreatedBy);
                //}


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        /// <summary>
        /// Get all UnionCouncil Info
        /// </summary>
        /// <returns>result of UnionCouncil in UnionCouncilModel class</returns
        public List<UnionCouncilModel> GetUnionCouncil()
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().SelectUnionCouncils();
            return BuildModel(dt);
        }

        /// <summary>
        /// Get all Active UnionCouncil Info
        /// </summary>
        /// <returns>result of UnionCouncil in UnionCouncilModel class</returns
        public List<UnionCouncilModel> GetUnionCouncils()
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().GetAll();
            return BuildModel(dt);
        }
        /// <summary>
        /// Get all Active UnionCouncil Info
        /// </summary>
        /// <returns>result of UnionCouncil in UnionCouncilModel class</returns
        public List<UnionCouncilModel> GetUnionCouncils(int ServiceID)
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().GetAll(ServiceID);
            return BuildModel(dt);
        }

        /// <summary>
        /// Get all Active UnionCouncil Info
        /// </summary>
        /// <returns>result of UnionCouncil in UnionCouncilModel class</returns
        public List<UnionCouncilModel> GetUnionCouncils(int ServiceID, int? UnionCouncilID)
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().GetAll(ServiceID, UnionCouncilID);
            return BuildModel(dt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ServiceID"></param>
        /// <param name="UnionCouncilID1"></param>
        /// <param name="UnionCouncilID2"></param>
        /// <returns></returns>
        public List<UnionCouncilModel> GetUnionCouncils(int ServiceID, int? UnionCouncilID1, int? UnionCouncilID2)
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().GetAll(ServiceID, UnionCouncilID1, UnionCouncilID2);
            return BuildModel(dt);
        }

        /// <summary>
        /// Delete the UnionCouncil By ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns>success or error Type on delete </returns>
        public int Delete(int id, string modifiedBy)
        {
            return new UnionCouncilDAL().Delete(id, modifiedBy);
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="id"></param>
        /// <param name="servcieID"></param>
        /// <returns></returns>
        public int Delete(int id, int servcieID)
        {
            return new UnionCouncilDAL().Delete(id, servcieID);
        }

        /// <summary>
        /// CR:001
        /// </summary>
        /// <returns></returns>
        public DataTable GetUnionCouncilsByTehsil(int TehsilID)
        {
            return new UnionCouncilDAL().SelectUnionCouncilsByTehsil(TehsilID);
        }
        /// <summary>
        /// CR:001
        /// </summary>
        /// <returns></returns>
        public List<UnionCouncilModel> GetUnionCouncilsByTehsilID(int tehsilID)
        {
            return BuildModel(new UnionCouncilDAL().SelectUnionCouncilsByTehsil(tehsilID));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="servcieID"></param>
        /// <returns></returns>
        public List<ServiceUnionCouncil> GetMappedUnionCouncil(int servcieID)
        {
            DataTable dt = null;
            dt = new UnionCouncilDAL().SelectByServiceID(servcieID);
            return BuildServiceUnionConcilModel(dt);
        }

        public DataTable GetServiceUnionCouncilTable(List<ServiceUnionCouncil> UnionCouncils, int servcieID)
        {
            DataTable dt = null;
            if (UnionCouncils != null && UnionCouncils.Count > 0)
            {
                dt = new DataTable();
                // add columns in the table
                dt.Columns.Add("UnionCouncilID", typeof(System.Int32));
                dt.Columns.Add("ServiceID", typeof(System.Int32));
                dt.Columns.Add("ThirdPartyID", typeof(System.String));
                dt.Columns.Add("ThirdPartyTitle", typeof(System.String));
                dt.Columns.Add("IsActive", typeof(System.Int16));
                DataRow dr = null;
                foreach (ServiceUnionCouncil item in UnionCouncils)
                {
                    if (item.SelectedUnionConcil > 0)
                    {
                        dr = dt.NewRow();
                        dr["UnionCouncilID"] = item.SelectedUnionConcil;
                        dr["ServiceID"] = servcieID;
                        dr["ThirdPartyID"] = item.ThirdPartyID;
                        dr["ThirdPartyTitle"] = item.ThirdPartyTitle;
                        dr["IsActive"] = item.IsActive;
                        dt.Rows.Add(dr);
                    }


                }

            }
            return dt;
        }

        #region "Private Methods"

        /// <summary>
        /// Bind the UnionCouncil Model with Data Table
        /// </summary>
        /// <param name="dt"></param>
        /// <returns>UnionCouncilModel class</returns>
        internal List<UnionCouncilModel> BuildModel(DataTable dt)
        {
            List<UnionCouncilModel> unionCouncils = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                unionCouncils = new List<UnionCouncilModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    UnionCouncilModel unionCouncilModel = new UnionCouncilModel();

                    if (dt.Columns.Contains("UnionCouncilID") && !Convert.IsDBNull(dr["UnionCouncilID"]))
                        unionCouncilModel.ID = Convert.ToInt32(dr["UnionCouncilID"]);
                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        unionCouncilModel.DistrictID = Convert.ToInt32(dr["DistrictID"]);
                    if (dt.Columns.Contains("TehsilID") && !Convert.IsDBNull(dr["TehsilID"]))
                        unionCouncilModel.TehsilID = Convert.ToInt32(dr["TehsilID"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        unionCouncilModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                        unionCouncilModel.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        unionCouncilModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        unionCouncilModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("TehsilName") && !Convert.IsDBNull(dr["TehsilName"]))
                        unionCouncilModel.TehsilName = Convert.ToString(dr["TehsilName"]);
                    if (dt.Columns.Contains("DistrictName") && !Convert.IsDBNull(dr["DistrictName"]))
                        unionCouncilModel.DistrictName = Convert.ToString(dr["DistrictName"]);
                    if (dt.Columns.Contains("AccountNo") && !Convert.IsDBNull(dr["AccountNo"]))
                        unionCouncilModel.AccountNo = Convert.ToString(dr["AccountNo"]);

                    unionCouncils.Add(unionCouncilModel);
                }

                unionCouncils.TrimExcess();
            }

            return unionCouncils;
        }

        /// <summary>
        /// BuildServiceUnionConcilModel
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<ServiceUnionCouncil> BuildServiceUnionConcilModel(DataTable dt)
        {
            List<ServiceUnionCouncil> ServiceUnionCouncils = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                ServiceUnionCouncils = new List<ServiceUnionCouncil>();
                foreach (DataRow dr in dt.Rows)
                {
                    ServiceUnionCouncil UnionCounciModel = new ServiceUnionCouncil();
                    if (dt.Columns.Contains("UnionCouncilID") && !Convert.IsDBNull(dr["UnionCouncilID"]))
                        UnionCounciModel.SelectedUnionConcil = Convert.ToInt32(dr["UnionCouncilID"]);
                    //if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                    //    genderModel.Title = Convert.ToString(dr["Title"]);
                    //if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                    //    genderModel.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);
                    //if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                    //    genderModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        UnionCounciModel.IsActive = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("ThirdPartyID") && !Convert.IsDBNull(dr["ThirdPartyID"]))
                        UnionCounciModel.ThirdPartyID = Convert.ToString(dr["ThirdPartyID"]);
                    if (dt.Columns.Contains("ThirdPartyTitle") && !Convert.IsDBNull(dr["ThirdPartyTitle"]))
                        UnionCounciModel.ThirdPartyTitle = Convert.ToString(dr["ThirdPartyTitle"]);
                    //if (dt.Columns.Contains("ServiceID") && !Convert.IsDBNull(dr["ServiceID"]))
                    //    genderModel..ServiceID = Convert.ToInt32(dr["ServiceID"]);
                    //if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                    //    genderModel.StaticName = Convert.ToString(dr["StaticName"]);
                    //if (dt.Columns.Contains("ServiceTitle") && !Convert.IsDBNull(dr["ServiceTitle"]))
                    //    genderModel.ServiceTitle = Convert.ToString(dr["ServiceTitle"]);
                    UnionCounciModel.IsThirdParty = false;

                    ServiceUnionCouncils.Add(UnionCounciModel);
                }

                ServiceUnionCouncils.TrimExcess();
            }

            return ServiceUnionCouncils;
        }

        #endregion

    }
}
