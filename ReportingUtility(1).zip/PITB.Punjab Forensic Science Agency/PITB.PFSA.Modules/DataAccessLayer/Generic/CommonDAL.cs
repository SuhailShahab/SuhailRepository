﻿using PITB.PFSA.Modules.Base;
using PITB.PFSA.Modules.CustomEnums;
using PITB.PFSA.Modules.DataModelLayer;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <07-09-2014 11:20AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// CR: 001  -   Syed Zeeshan Aqil           11-07-2014 4:32PM       Add SaveErrorLog methods
// CR: 002  -   Syed Zeeshan Aqil           11-07-2014 4:32PM       Add GetDuplication methods
// CR: 003  -   Syed Zeeshan Aqil           17-07-2014 4:32PM       Add SelectLookupsTitle methods
// CR: 004  -   Syed Zeeshan Aqil           17-07-2014 4:32PM       Add SelectLookupsID methods
// CR: 005  -   Syed Zeeshan Aqil           27-07-2014 4:32PM       Add GetServiceInfoByCode methods
// CR: 006  -   Syed Zeeshan Aqil           27-07-2014 4:32PM       Add GetServiceInfoByCode methods
// CR: 007 -    Muhammad Hammad Shahid      08-08-2014 11:36AM      Add _level parameter in GetUserPageAccess method
// CR: 008 -    Sohail Kamran               27-11-2014 11:36AM      Add Add Errlong with model
// CR: 009 -    Syed Zeeshan Aqil           18-12-2014 4:32PM       Add DeletServiceTablesData methods
// CR: 010 -    Syed Zeeshan Aqil           19-12-2014 4:32PM       Add DeleteDomicileChildranTableData methods
// CR: 011 -    Syed Zeeshan Aqil           19-12-2014 4:32PM       Add DeleteCharacterResidenceTableData methods
// CR: 012 -    Suhail Shahab               7-04-2015               Add  GetServiceAndDeliveryTypes() methods
// =================================================================================================================================
namespace PITB.PFSA.Modules.DataAccessLayer
{
    public class CommonDAL : DALBase
    {
        #region Constructor
        public CommonDAL()
        {

        }
        public CommonDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public CommonDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
            this.dbTransaction = transaction;
        }
       

        
        #endregion
        /// <summary>
        /// Add error detail in ErrorLog table.
        ///  CR: 001 
        /// </summary>
        /// <param name="_method"></param>
        /// <param name="_message"></param>
        /// <param name="_stackTrace"></param>
        /// <param name="_source"></param>
        /// <param name="_webMethod"></param>
        /// <param name="_created"></param>
        /// <returns>Number of rows effected as interger</returns>
        public int SaveErrorLog(string _method, string _message, string _stackTrace, string _source, int _webMethod, DateTime _created)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddErrorLog";

                sqlCmd.Parameters.Add(new SqlParameter("@Method", SqlDbType.VarChar));
                sqlCmd.Parameters["@Method"].Value = _method;

                sqlCmd.Parameters.Add(new SqlParameter("@Message", SqlDbType.VarChar));
                sqlCmd.Parameters["@Message"].Value = _message;

                sqlCmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar));
                sqlCmd.Parameters["@StackTrace"].Value = _stackTrace;

                sqlCmd.Parameters.Add(new SqlParameter("@Source", SqlDbType.VarChar));
                sqlCmd.Parameters["@Source"].Value = _source;

                sqlCmd.Parameters.Add(new SqlParameter("@IsWebMethod", SqlDbType.Bit));
                sqlCmd.Parameters["@IsWebMethod"].Value = 0;

                sqlCmd.Parameters.Add(new SqlParameter("@Created", SqlDbType.DateTime));
                sqlCmd.Parameters["@Created"].Value = _created;

                result = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open) con.Close();
            }

            return result;
        }
        

        /// <summary>
        /// CR : 008
        /// </summary>
        /// <param name="ErrorLog"></param>
        /// <returns></returns>
        public int SaveErrorLog(ErrorLogModel ErrorLog)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddErrorLog";

                sqlCmd.Parameters.Add(new SqlParameter("@Method", SqlDbType.VarChar));
                sqlCmd.Parameters["@Method"].Value = ErrorLog.Method;

                sqlCmd.Parameters.Add(new SqlParameter("@Message", SqlDbType.VarChar));
                sqlCmd.Parameters["@Message"].Value = ErrorLog.Message;

                sqlCmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar));
                sqlCmd.Parameters["@StackTrace"].Value = ErrorLog.StackTrace;

                sqlCmd.Parameters.Add(new SqlParameter("@Source", SqlDbType.VarChar));
                sqlCmd.Parameters["@Source"].Value = ErrorLog.Source;

                sqlCmd.Parameters.Add(new SqlParameter("@IsWebMethod", SqlDbType.Bit));
                sqlCmd.Parameters["@IsWebMethod"].Value = ErrorLog.IsWebMethod;

                sqlCmd.Parameters.Add(new SqlParameter("@Created", SqlDbType.DateTime));
                sqlCmd.Parameters["@Created"].Value = DateTime.Now;

                
                sqlCmd.Parameters.Add(new SqlParameter("@LocationCode", SqlDbType.VarChar));
                sqlCmd.Parameters["@LocationCode"].Value = ErrorLog.LocationCode;

                
                sqlCmd.Parameters.Add(new SqlParameter("@ServiceCode", SqlDbType.VarChar));
                sqlCmd.Parameters["@ServiceCode"].Value = ErrorLog.ServiceCode;

                sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@DistrictID"].Value = ErrorLog.DistrictID;
              

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@DivisionID"].Value = ErrorLog.DivisionID;
             
                sqlCmd.Parameters.Add(new SqlParameter("@PageName", SqlDbType.VarChar));
                sqlCmd.Parameters["@PageName"].Value = ErrorLog.PageName;

                result = sqlCmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open) con.Close();
            }

            return result;
        }

        /// <summary>
        /// Check any record duplication and data dependances
        /// </summary>
        /// <param name="_table"></param>
        /// <param name="_column"></param>
        /// <param name="_value"></param>
        /// <param name="_caluse"></param>
        /// <returns>True when related record exist else false</returns>
        public bool SelectRecordVerification(string _table, string _column, string _value, string _caluse)
        {
            bool result = false;

            try
            {
                DataTable dt = new DataTable();
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spCheckRecords", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Table"].Value = _table;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@column", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@column"].Value = _column;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@value", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@value"].Value = _value;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@caluse", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@caluse"].Value = _caluse;

                _sqlDadp.Fill(dt);

                if (dt.Rows.Count > 0)
                    result = true;

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// CR: 007
        /// check user access right on a selected page.
        /// </summary>
        /// <param name="_user"></param>
        /// <param name="_page"></param>
        /// <returns></returns>
        public bool GetUserPageAccess(string _user, string _page, int _level)
        {
            bool result = true;

            try
            {
                DataTable dt = new DataTable();

                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetUserPageAccess", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LoginID", SqlDbType.VarChar));
                _sqlDadp.SelectCommand.Parameters["@LoginID"].Value = _user;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Page", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Page"].Value = _page;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Level", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@Level"].Value = _level;

                _sqlDadp.Fill(dt);

                if (dt.Rows.Count == 0)
                    result = false;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }


        
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tblName"></param>
        /// <param name="locationID"></param>
        /// <returns></returns>
        public int GetAutoQmaticNo(string tblName, int locationID)
        {


            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAutoQmaticNo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LocationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@LocationID"].Value = locationID;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@tblName", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@tblName"].Value = tblName;

                    sqlDadp.Fill(dt);

                    if (dt.Rows.Count > 0)
                        return Convert.ToInt32(dt.Rows[0][0]);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return 0;
        }


        /// <summary>
        /// CR: 005
        /// get Service Name from Database on the basis of Code
        /// </summary>
        /// <returns>Datatable of Service table </returns>
        public DataTable GetServiceInfoByCode(string Code)
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetServiceInfoByCode", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Code"].Value = Code != null ? Code : "";

                _sqlDadp.Fill(dt);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dt;
        }

        /// <summary>
        /// Update the Satus in Services Table
        /// </summary>
        /// <param name="TableName">Table Name</param>
        /// <param name="TaskStatusID">Task satus id need to be update</param>
        /// <param name="ApplicantID">Applicant Id</param>
        /// <returns></returns>
        public int UpdateServiceTableStatus(string TableName, int TaskStatusID, string ApplicantID)
        {
            object _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spUpdateServiceTableStatus";

                _sqlCmd.Parameters.Add(new SqlParameter("@TaskStatusID", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@TaskStatusID"].Value = TaskStatusID;

                _sqlCmd.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Table"].Value = TableName;

                _sqlCmd.Parameters.Add(new SqlParameter("@ApplicantID", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@ApplicantID"].Value = ApplicantID;



                _result = _sqlCmd.ExecuteScalar();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(_result);
        }
        public int UpdateServiceTableStatus(string TableName, int TaskStatusID, string ApplicantID, string remarks, string modifiedBy)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spUpdateServiceTableStatus";

                sqlCmd.Parameters.Add(new SqlParameter("@TaskStatusID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TaskStatusID"].Value = TaskStatusID;

                sqlCmd.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Table"].Value = TableName;

                sqlCmd.Parameters.Add(new SqlParameter("@ApplicantID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ApplicantID"].Value = ApplicantID;

                sqlCmd.Parameters.Add(new SqlParameter("@Remarks", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Remarks"].Value = remarks;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;


                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }
     
      
        /// use to check duplication value
        /// </summary>
        /// <param name="_table">Table name where to search</param>
        /// <param name="_column">Column name</param>
        /// <param name="_value"></param>
        /// <returns></returns>
        public bool GetDuplication(string table, string column, string value, string caluse)
        {
            bool result = false;

            try
            {
                DataTable dt = new DataTable();
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spCheckDuplication", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@Table"].Value = table;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@column", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@column"].Value = column;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@value", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@value"].Value = value.Trim();
                if (!string.IsNullOrEmpty(caluse))
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@caluse", SqlDbType.NVarChar));
                    sqlDadp.SelectCommand.Parameters["@caluse"].Value = caluse;
                }

                sqlDadp.Fill(dt);

                /* if (dt.Rows.Count > 0)
                     result = true;*/
                if (dt != null && dt.Rows.Count > 0 && Convert.ToInt32(dt.Rows[0][0]) > 0)
                {
                    result = true;
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
     
    }
}
