﻿using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using PITB.PFSA.Modules.Base;
using PITB.PFSA.Modules.DataModelLayer;
using PITB.PFSA.Modules.DataModelLayer.Lookups;

namespace PITB.PFSA.Modules.DataAccessLayer
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <26-12-2014 08:30PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time      Desription

    // =================================================================================================================================

    public class GeneralDistrictDAL : DALBase
    {
        /// <summary>
        /// save GeneralDistrict information
        /// </summary>
        /// <param name="relationModel">Set object of GeneralDistrictModel type</param>
        /// <returns></returns>
        public int? Add(GeneralDistrictModel districtModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
               // sqlCmd.CommandText = "spAddDistrict";
                sqlCmd.CommandText = "spAddGeneralDistrict";

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@DivisionID"].Value = districtModel.DivisionID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = districtModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@TitleUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TitleUrdu"].Value = districtModel.TitleUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = districtModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = districtModel.Status ? 1 : 0;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CreatedBy"].Value = districtModel.CreatedBy;

                sqlCmd.Parameters.Add(new SqlParameter("@MappedDistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@MappedDistrictID"].Value = districtModel.MapFCDistrictID;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return null;
            
        }

        /// <summary>
        /// Update District information
        /// </summary>
        /// <param name="districtModel">Set object of DistrictModel type</param>
        /// <returns></returns>
        public int? Edit(GeneralDistrictModel districtModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.CommandText = "spEditDistrict";
                sqlCmd.CommandText = "spEditGeneralDistrict";

                sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@DistrictID"].Value = districtModel.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@DivisionID"].Value = districtModel.DivisionID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = districtModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@TitleUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TitleUrdu"].Value = districtModel.TitleUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = districtModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = districtModel.Status ? 1 : 0;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = districtModel.CreatedBy;

                sqlCmd.Parameters.Add(new SqlParameter("@MappedDistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@MappedDistrictID"].Value = districtModel.MapFCDistrictID;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// Delete District information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, string modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                //_sqlCmd.CommandText = "spDeleteDistrict";
                _sqlCmd.CommandText = "spDeleteGeneralDistrict";

                _sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                _sqlCmd.Parameters["@DistrictID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.VarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.VarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Get all Active Districts use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
               // SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistricts", con);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistricts", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetDistrictsByFCDistrictID(int fcDistrictID)
        {
            DataTable dt = new DataTable();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                // SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistricts", con);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistrictByFCDistrictID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FCDistrictID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@FCDistrictID"].Value = fcDistrictID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public DataTable GetDistrictModelByDistrictID(int @DistrictID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                // SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistricts", con);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistrictByID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceID"></param>
        /// <param name="districtID1"></param>
        /// <param name="districtID2"></param>
        /// <returns></returns>
        public DataTable GetAll(int serviceID, int? districtID1, int? districtID2)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetTwoGeneralDistricts", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@ServiceID"].Value = serviceID;

                if (districtID1.HasValue && districtID1.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID1", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID1"].Value = districtID1;
                }

                if (districtID2.HasValue && districtID2.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID2", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID2"].Value = districtID2;
                }

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all Active Districts use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll(int serviceID, int? districtID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);               
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistricts", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@ServiceID"].Value = serviceID;

                if (districtID.HasValue && districtID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                }

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get all District
        /// </summary>
        /// <returns></returns>
        public DataTable Select()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                //SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrict", con);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistrict", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all districts
        /// CR:001
        /// Mofied the sp name by suhail shahab. now sp is get all active disticts
        /// </summary>
        /// <returns></returns>
        public DataTable SelectDistricts()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                //SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrict", con);
               // SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistrict", con);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllGeneralDistricts", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get  districts by Division ID
        /// CR:002
        /// </summary>
        /// <returns></returns>
        public DataTable GetDistrictsByDivisionID(int DivisionID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                //SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictByDivisionID", con);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistrictByDivisionID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = DivisionID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        //public int SaveServiceDistrict(DataTable dtServiceDistrict, string createdBy)
        //{
        //    int result = 0;
        //    SqlConnection con = new SqlConnection(this.spConnectionString);
        //    SqlCommand sqlCmd = new SqlCommand();

        //    try
        //    {
        //        if (con.State == ConnectionState.Closed)
        //            con.Open();
        //        sqlCmd.Connection = con;
        //        sqlCmd.CommandType = CommandType.StoredProcedure;
        //        //sqlCmd.CommandText = "spUpdateServiceApplicationType";
        //        sqlCmd.CommandText = "spUpdateServiceDistrict";


        //        sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
        //        sqlCmd.Parameters["@CreatedBy"].Value = createdBy;

        //        sqlCmd.Parameters.Add(new SqlParameter("@ServiceDistrict", SqlDbType.Structured));
        //        sqlCmd.Parameters["@ServiceDistrict"].Value = dtServiceDistrict;


        //        result = sqlCmd.ExecuteNonQuery();
        //        result = 1;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        if (con.State == ConnectionState.Open)
        //            con.Close();
        //        con.Dispose();
        //    }


        //    return result;
        //}
        public int SaveServiceDistrict(DataTable dtServiceDistrict, string createdBy)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.CommandText = "spUpdateServiceApplicationType";
                sqlCmd.CommandText = "spUpdateServiceDistrict";


                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CreatedBy"].Value = createdBy;

                sqlCmd.Parameters.Add(new SqlParameter("@ServiceDistrict", SqlDbType.Structured));
                sqlCmd.Parameters["@ServiceDistrict"].Value = dtServiceDistrict;


                result = sqlCmd.ExecuteNonQuery();
                result = 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
                con.Dispose();
            }


            return result;
        }

        /// <summary>
        /// Get all District
        /// </summary>
        /// <returns></returns>
        public DataTable SelectDistrictByServiceID(int serviceID)
        {
            DataTable dt = new DataTable();
            SqlConnection con = null;
            SqlCommand sqlCmd = new SqlCommand();
            try
            {
                con = new SqlConnection(this.spConnectionString);
               // SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetApplicationTypeByServiceID", con);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictByServiceID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@ServiceID"].Value = serviceID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        ///// <summary>
        ///// Created By Suahil Shahab Get All Active Distirst to fill in drowpdown of Report and admin pages
        ///// </summary>
        ///// <returns></returns>
        //public DataTable GetAllActiveDistricts()
        //{
        //    DataTable dt = new DataTable();
        //    SqlConnection con = null;
        //    SqlCommand sqlCmd = new SqlCommand();
        //    try
        //    {
        //        con = new SqlConnection(this.spConnectionString);
        //        // SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetApplicationTypeByServiceID", con);
        //        SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllGeneralDistricts", con);
        //        sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

        //        sqlDadp.Fill(dt);
        //        return dt;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public int DeleteServiceDistrict(int id, int serviceID)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
             //   sqlCmd.CommandText = "spDeleteServiceApplicationType";
                sqlCmd.CommandText = "spDeleteServiceDistrict";

                sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@DistrictID"].Value = id;

                sqlCmd.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlCmd.Parameters["@ServiceID"].Value = serviceID;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ConCloseDisponse(con);
            }

            return result;
        }
    }
}
