﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using PITB.PFSA.Modules.Base;
using PITB.PFSA.Modules.DataModelLayer.Lookups;

namespace PITB.PFSA.Modules.DataAccessLayer
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class DepartmentDAL : DALBase
    {
        /// <summary>
        /// save Department information
        /// </summary>
        /// <param name="relationModel">Set object of DepartmentModel type</param>
        /// <returns></returns>
        public int Add(DepartmentModel departmentModel)
        {
            object _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spAddDepartment";

                _sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Code"].Value = departmentModel.Code;

                _sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Title"].Value = departmentModel.Title;

                _sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Description"].Value = departmentModel.Description;

                _sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                _sqlCmd.Parameters["@IsActive"].Value = departmentModel.Status ? 1 : 0;

                _sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@CreatedBy"].Value = departmentModel.CreatedBy;

                _result = _sqlCmd.ExecuteScalar();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(_result);
        }

        /// <summary>
        /// Update Department information
        /// </summary>
        /// <param name="departmentModel">Set object of DepartmentModel type</param>
        /// <returns></returns>
        public int Edit(DepartmentModel departmentModel)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spEditDepartment";

                _sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                _sqlCmd.Parameters["@DepartmentID"].Value = departmentModel.ID;

                _sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Code"].Value = departmentModel.Code;

                _sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Title"].Value = departmentModel.Title;

                _sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Description"].Value = departmentModel.Description;

                _sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                _sqlCmd.Parameters["@IsActive"].Value = departmentModel.Status ? 1 : 0;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = departmentModel.CreatedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Delete Department information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, string modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteDepartment";

                _sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                _sqlCmd.Parameters["@DepartmentID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.VarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }
        /// <summary>
        /// Get all Active Department
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetDepartments", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get all Department
        /// </summary>
        /// <returns></returns>
        public DataTable SelectDepartments()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetDepartment", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
