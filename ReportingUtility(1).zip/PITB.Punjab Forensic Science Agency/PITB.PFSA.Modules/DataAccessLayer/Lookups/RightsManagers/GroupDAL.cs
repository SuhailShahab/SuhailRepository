﻿using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using PITB.PFSA.Modules.DataModelLayer;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using PITB.PFSA.Modules.Base;
using PITB.PFSA.Modules.DataModelLayer.RightsManager;
using PITB.PFSA.Modules.CustomEnums;

namespace PITB.PFSA.Modules.DataAccessLayer
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil >
    // Create date: <7/10/2014 2:07:32 AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // CR: 001           Syed Zeeshan Aqil      06-07-2015 04:21:08PM   Add new operational rights "File attachment", Residential history, Personal info  and show address info Paneel
    // =================================================================================================================================
    public class GroupDAL : DALBase
    {
        /// <summary>
        /// Add Group information
        /// </summary>
        /// <param name="groupModel">Set object of groupModel type</param>
        /// <returns></returns>
        public int Add(GroupModel groupModel)
        {
            object _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spAddGroup";

                _sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Title"].Value = groupModel.Title;

                _sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Description"].Value = groupModel.Description;

                _sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                _sqlCmd.Parameters["@IsActive"].Value = groupModel.Status ? 1 : 0;

                _sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@CreatedBy"].Value = groupModel.CreatedBy;

                _result = _sqlCmd.ExecuteScalar();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(_result);
        }

        /// <summary>
        /// Update Group information
        /// </summary>
        /// <param name="groupModel">Set object of groupModel type</param>
        /// <returns></returns>
        public int Edit(GroupModel groupModel)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spEditGroup";

                _sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@GroupID"].Value = groupModel.ID;

                _sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Title"].Value = groupModel.Title;

                _sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@Description"].Value = groupModel.Description;

                _sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                _sqlCmd.Parameters["@IsActive"].Value = groupModel.Status ? 1 : 0;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = groupModel.CreatedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Delete Group information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, string modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteGroup";

                _sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.Int));
                _sqlCmd.Parameters["@GroupID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.VarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Get  Groups for DropDown
        /// </summary>
        /// <returns>Group Data in dataTable</returns>
        public DataTable SelectGroups()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetGroup", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get  Groups for DropDown
        /// </summary>
        /// <returns>Group Data in dataTable</returns>
        public DataTable GetGroups()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetGroups", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Add group permissions
        /// </summary>
        /// <param name="groupID"></param>
        /// <param name="dt"></param>
        /// <param name="_arrRights"></param>
        /// <returns></returns>
        public int AddGroupPermissions(int groupID, DataTable dt, DataTable csrRights)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if(con.State == ConnectionState.Closed)
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddGroupPermissions";

                sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.Int));
                sqlCmd.Parameters["@GroupID"].Value = groupID;

                sqlCmd.Parameters.Add(new SqlParameter("@GroupPermission", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupPermission"].Value = dt;

                sqlCmd.Parameters.Add(new SqlParameter("@GroupCSRPermission", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupCSRPermission"].Value = csrRights;

                result = sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        public int AddGroupPermissions(int groupID, ManageGroupBaseRight manageGroupBaseRight)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if(con.State == ConnectionState.Closed)
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddGroupPermissions";

                sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.Int));
                sqlCmd.Parameters["@GroupID"].Value = groupID;

                sqlCmd.Parameters.Add(new SqlParameter("@AllowFileRemove", SqlDbType.Int));
                sqlCmd.Parameters["@AllowFileRemove"].Value = manageGroupBaseRight.AllowFileRemoved.HasValue ? manageGroupBaseRight.AllowFileRemoved.Value : false;

                if (manageGroupBaseRight.AllowFileView.HasValue)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@AllowFileView", SqlDbType.Int));
                    sqlCmd.Parameters["@AllowFileView"].Value = manageGroupBaseRight.AllowFileView.HasValue ? manageGroupBaseRight.AllowFileView.Value : false;
                }

                if (manageGroupBaseRight.AllowFileDownload.HasValue)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@AllowFileDownload", SqlDbType.Int));
                    sqlCmd.Parameters["@AllowFileDownload"].Value = manageGroupBaseRight.AllowFileDownload.HasValue ? manageGroupBaseRight.AllowFileDownload.Value : false;
                }

                if (manageGroupBaseRight.AllowServiceDataPosting.HasValue)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@AllowServiceDataPosting", SqlDbType.Int));
                    sqlCmd.Parameters["@AllowServiceDataPosting"].Value = manageGroupBaseRight.AllowServiceDataPosting.HasValue ? manageGroupBaseRight.AllowServiceDataPosting.Value : false;
                }

                if (manageGroupBaseRight.AllowDataUpdate.HasValue)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@AllowDataUpdate", SqlDbType.Int));
                    sqlCmd.Parameters["@AllowDataUpdate"].Value = manageGroupBaseRight.AllowDataUpdate.HasValue ? manageGroupBaseRight.AllowDataUpdate.Value : false;
                }

                if (manageGroupBaseRight.AllowAccessOutSideLocation.HasValue)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@AllowAccessOutSideLocation", SqlDbType.Bit));
                    sqlCmd.Parameters["@AllowAccessOutSideLocation"].Value = manageGroupBaseRight.AllowAccessOutSideLocation.Value;
                }

                if (manageGroupBaseRight.AllowFileAttachment.HasValue)// CR: 001
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@AllowFileAttachment", SqlDbType.Bit));
                    sqlCmd.Parameters["@AllowFileAttachment"].Value = manageGroupBaseRight.AllowFileAttachment.Value;
                }

                if (manageGroupBaseRight.AllowAccessOutSideLocation.HasValue)// CR: 001
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@AllowResidenceHistory", SqlDbType.Bit));
                    sqlCmd.Parameters["@AllowResidenceHistory"].Value = manageGroupBaseRight.AllowResidenceHistory.Value;
                }

                if (manageGroupBaseRight.AllowPersonalInfo.HasValue)// CR: 001
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@AllowPersonalInfo", SqlDbType.Bit));
                    sqlCmd.Parameters["@AllowPersonalInfo"].Value = manageGroupBaseRight.AllowPersonalInfo.Value;
                }

                if (manageGroupBaseRight.AllowAddressInfo.HasValue)// CR: 001
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@AllowAddressInfo", SqlDbType.Bit));
                    sqlCmd.Parameters["@AllowAddressInfo"].Value = manageGroupBaseRight.AllowAddressInfo.Value;
                }
               
                sqlCmd.Parameters.Add(new SqlParameter("@GroupPermission", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupPermission"].Value = manageGroupBaseRight.dsAllPermitRights.Tables[TableName.tblGroupRights.ToString()];

                sqlCmd.Parameters.Add(new SqlParameter("@GroupCSRPermission", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupCSRPermission"].Value = manageGroupBaseRight.dsAllPermitRights.Tables[TableName.tblAppFeatures.ToString()];

                sqlCmd.Parameters.Add(new SqlParameter("@GroupServicePermission", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupServicePermission"].Value = manageGroupBaseRight.dsAllPermitRights.Tables[TableName.tblGroupPermitServices.ToString()];

                sqlCmd.Parameters.Add(new SqlParameter("@GroupPermitMarkStatuses", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupPermitMarkStatuses"].Value = manageGroupBaseRight.dsAllPermitRights.Tables[TableName.tblGroupPermitStatuses.ToString()];

                sqlCmd.Parameters.Add(new SqlParameter("@GroupPermitAssigneeStatuses", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupPermitAssigneeStatuses"].Value = manageGroupBaseRight.dsAllPermitRights.Tables[TableName.tblGroupPermitAssigneeStatuses.ToString()];

                sqlCmd.Parameters.Add(new SqlParameter("@GroupControlRights", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupControlRights"].Value = manageGroupBaseRight.dsAllPermitRights.Tables[TableName.tblGroupControlRights.ToString()];
               

                result = sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }
        /// <summary>
        /// Get groups permissions against selected group
        /// </summary>
        /// <param name="_groupID"></param>
        /// <returns></returns>
        public DataSet GetGroupPermissions(int _groupID)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetGroupPermission", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@GroupID"].Value = _groupID;

                _sqlDadp.Fill(ds);
                ds.Tables[2].TableName = TableName.tblGroupPermitServices.ToString();
                ds.Tables[3].TableName = TableName.tblGroupPermitStatuses.ToString(); 
                ds.Tables[4].TableName = TableName.tblGroupPermitAssigneeStatuses.ToString();
                ds.Tables[5].TableName = TableName.tblGroupControlRights.ToString();
                ds.Tables[6].TableName = TableName.tblGroup.ToString();
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
