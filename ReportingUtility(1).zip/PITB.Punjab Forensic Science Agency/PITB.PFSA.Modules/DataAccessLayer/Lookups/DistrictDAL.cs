﻿
using PITB.PFSA.Modules.Base;
using PITB.PFSA.Modules.DataModelLayer.Lookups;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Suhail Shahab>
// Create date: <09-07-2014 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// CR: 001  -   Muhammad Hammad Shahid      11-07-2014 12:32PM          Add SelectDistricts methods
// CR: 002  -   syed Zeeshan Aqil           16-09-2014 05:32PM          Add GetDistrictsByDivisionID methods
// CR:002       Muhammad Hammad Shahid      30-12-2014 06:46:51PM       Add GetDistrictsByID() method
// CR: 004  -   syed Zeeshan Aqil           09-01-2015 05:32PM          Add GetDistrictByLocationID methods
// =================================================================================================================================
namespace PITB.PFSA.Modules.DataAccessLayer
{
    public class DistrictDAL : DALBase
    {
        /// <summary>
        /// save District information
        /// </summary>
        /// <param name="relationModel">Set object of DistrictModel type</param>
        /// <returns></returns>
        public int? Add(DistrictModel districtModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddDistrict";

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@DivisionID"].Value = districtModel.DivisionID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = districtModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@TitleUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TitleUrdu"].Value = districtModel.TitleUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = districtModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Code"].Value = districtModel.Code;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = districtModel.Status ? 1 : 0;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CreatedBy"].Value = districtModel.CreatedBy;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActiveCenter", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActiveCenter"].Value = districtModel.IsActiveCenter;

                sqlCmd.Parameters.Add(new SqlParameter("@EnableServiceDocumentCenter", SqlDbType.Bit));
                sqlCmd.Parameters["@EnableServiceDocumentCenter"].Value = districtModel.EnableServiceDocumentCenter;

                sqlCmd.Parameters.Add(new SqlParameter("@ServiceDocumentCenterURL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ServiceDocumentCenterURL"].Value = districtModel.ServiceDocumentCenterURL;

                sqlCmd.Parameters.Add(new SqlParameter("@EnableCommonDocumentCenter", SqlDbType.Bit));
                sqlCmd.Parameters["@EnableCommonDocumentCenter"].Value = districtModel.EnableCommonDocumentCenter;

                sqlCmd.Parameters.Add(new SqlParameter("@CommonDocumentCenterURL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CommonDocumentCenterURL"].Value = districtModel.CommonDocumentCenterURL;

                result = sqlCmd.ExecuteScalar();
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return null;

        }

        /// <summary>
        /// Update District information
        /// </summary>
        /// <param name="districtModel">Set object of DistrictModel type</param>
        /// <returns></returns>
        public int? Edit(DistrictModel districtModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditDistrict";

                sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@DistrictID"].Value = districtModel.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@DivisionID"].Value = districtModel.DivisionID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = districtModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@TitleUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TitleUrdu"].Value = districtModel.TitleUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = districtModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Code"].Value = districtModel.Code;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = districtModel.Status ? 1 : 0;

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = districtModel.CreatedBy;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActiveCenter", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActiveCenter"].Value = districtModel.IsActiveCenter;

                sqlCmd.Parameters.Add(new SqlParameter("@EnableServiceDocumentCenter", SqlDbType.Bit));
                sqlCmd.Parameters["@EnableServiceDocumentCenter"].Value = districtModel.EnableServiceDocumentCenter;

                sqlCmd.Parameters.Add(new SqlParameter("@ServiceDocumentCenterURL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ServiceDocumentCenterURL"].Value = districtModel.ServiceDocumentCenterURL;

                sqlCmd.Parameters.Add(new SqlParameter("@EnableCommonDocumentCenter", SqlDbType.Bit));
                sqlCmd.Parameters["@EnableCommonDocumentCenter"].Value = districtModel.EnableCommonDocumentCenter;

                sqlCmd.Parameters.Add(new SqlParameter("@CommonDocumentCenterURL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CommonDocumentCenterURL"].Value = districtModel.CommonDocumentCenterURL;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// Delete District information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int? id, int? modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteDistrict";

                _sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                _sqlCmd.Parameters["@DistrictID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.VarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Get all Active Districts use for dropdown
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistricts", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetAllActiveDistitricts()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllActiveDistricts", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        /// <summary>
        /// Get all District
        /// </summary>
        /// <returns></returns>
        public DataTable Select()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrict", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all districts
        /// CR:001
        /// </summary>
        /// <returns></returns>
        public DataTable SelectDistricts()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrict", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get  districts by Division ID
        /// CR:002
        /// </summary>
        /// <returns></returns>
        public DataTable GetDistrictsByDivisionID(int DivisionID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictByDivisionID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = DivisionID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get district infromation by district id
        /// </summary>
        /// <param name="districtID"></param>
        /// <returns></returns>
        public DataTable GetDistrictsByID(int districtID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictByID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get districts by Fc Location ID
        /// CR:004
        /// </summary>
        /// <returns></returns>
        public DataTable GetDistrictByLocationID(int locationID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictByLocationID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LocationID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@LocationID"].Value = locationID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
