﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.CustomEnums
{
    public enum ColumnName : byte
    {
        Title = 1,
        CityID = 2,
        DepartmentID = 3,
        DistrictID = 4,
        GenderID = 5,
        Name = 6,
        LocationID = 7,
        MaritalStatusID = 8,
        RelationID = 9,
        ReligionID = 10,
        StatusID = 11,
        TehsilID = 12,
        UnionCouncilID = 13,
        ApplicationTypeID = 14,
        DivisionID = 15,
        DivorceStatusID = 16,
        Code = 17,
        ServiceID = 18,
        VehicleTypeID = 19,
        PermitTypeID = 20,

        AssigneeSatusID = 21,
        MarkStatusID = 22,
        ServiceCode = 23,
        LocationCode = 24,
        ObjectionTypeID = 25,
        DriverTypeID = 26,
        CitizenTypeID = 27,
        BloodGroupID = 28,
        GroupID = 29,
        DocumentLibraryID = 30,
        DocumentTypeID = 31,
        DeliveryTypeID = 32,
        ServiceTypeID = 33,
        ArmsLicenseID = 34,
        CNICCardID = 35,
        DrivingLicenceID = 36,
        IssuanceFardID = 37,
        IssuancePassportID = 38,
        MotorVehicleID = 39,
        KiosksServiceID = 40,
        TokenTaxID = 41,
        DeptDeliveryDate = 42,
        MenuName = 43,
        AppFeatureID = 44,
        ApplicantTypeID = 45,
        StaticName = 46,
        AppObjectID = 47,
        ID = 48,
        EnumStaticName = 49,
        FCLocaionID = 50,
        DefaultSettingID = 51,
        ESahulatID = 52
    }
}
