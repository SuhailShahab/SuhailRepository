﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.CustomEnums
{
    public enum TableName : byte
    {
        tblCity = 1,
        tblDepartment = 2,
        tblAppFeatures = 3,
        tblApplicationType = 4,
        tblDistrict = 5,
        tblDivision = 6,
        tblDivorceStatus = 7,
        tblGender = 8,
        tblLocation = 9,
        tblMaritalStatus = 10,
        tblRelation = 11,
        tblReligion = 12,
        tblService = 13,
        tblStatus = 14,
        tblTehsil = 15,
        tblUnionCouncil = 16,
        tblVehicleType = 17,
        tblPermitType = 18,
        tblStatusProcessTrack = 19,
        tblObjectionTypes = 20,
        tblGeneralDistrict = 21,
        tblDriverType = 22,
        tblCitizenType = 23,
        tblBloodGroup = 24,
        tblGroup = 25,
        tblGroupRights = 26,
        tblGroupPermitServices = 27,
        tblGroupPermitStatuses = 28,
        tblGroupPermitAssigneeStatuses = 29,
        tblGroupControlRights = 30,
        tblServiceCommonDocumentLibrary = 31,
        tblDocumentTypes = 32,
        tblDeliveryType = 33,
        tblServiceType = 34,
        tblDefaultSetting = 35,
        tblPoliceStation = 36,
        tblGazettedHolidays = 37,
        tblApplicantTypes = 38,
        tblAppObjects = 39,
        tblServicePosting = 40,
        tblServiceFormConfiguration = 41,
        tblCitizenAvailedServices = 42,
        tblNadraCNICRecord = 43
    }
}
