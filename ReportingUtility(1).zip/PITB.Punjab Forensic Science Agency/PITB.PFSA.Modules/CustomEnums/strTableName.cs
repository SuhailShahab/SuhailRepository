﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.Modules.CustomEnums
{
   public  class strTableName
    {
        public const string tblUser = "Users";
        public const string tblUserPermitServices = "UserPermitServices";
        public const string tblPermitCSRManagement = "PermitCSRManagement";
        public const string tblUserRights = "tblUserRights";
        public const string tblOfficiatingDashboards = "tblOfficiatingDashboards";
    }
}
