﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Security
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region Custom Methods
        
        //private bool AuthenticationAD(string userName, string pasword)
        //{
        //    DirectoryEntry entry = new DirectoryEntry("LDAP://" + ConfigurationHelper.DomainName, userName, pasword);
        //    try
        //    {
        //        object obj = entry.NativeObject;
        //        DirectorySearcher search = new DirectorySearcher(entry);
        //        search.Filter = "CAMAccountName=" + userName + ")";
        //        search.PropertiesToLoad.Add("cn");
        //        SearchResult result = search.FindOne();


        //        if (result == null)
        //        {
        //            return false;
        //        }
        //        else
        //        {
        //            return true;
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;

        //    }
        //    return false;
        //}

        private bool AuthenticationAD(string userName, string pasword)
        {
            bool isvalidate = false;
            try
            {
                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, ConfigurationHelper.DomainName, "ABUNDANTCODEDOMAIN"))
                {
                     isvalidate = pc.ValidateCredentials(userName, pasword);
                }

            }
            catch (Exception ex)
            {
                throw ex;

            }
            return isvalidate;
        }
        

        protected void btnAuthenticate_Click(object sender, EventArgs e)
        {
            try
            {
                if(this.AuthenticationAD(txtLoginName.Text,txtPassword.Text))
                {
                    UserModel currentUser = new  UserBLL().GeLoginUserInfoByLogin(txtLoginName.Text);
                    if (currentUser != null)
                    {
                        //Response.Cookies["LoginID"].Value  = currentUser.UserID.ToString();
                        //Response.Cookies["LoginID"].Expires = DateTime.Now.AddDays(1);
                        //Response.Cookies["UserName"].Value = currentUser.UserName.ToString();
                        //Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(1);
                        Session["CurrentUser"] = currentUser;
                        Session["LoginID"] = currentUser.UserID;
                        Response.Redirect("index.aspx", false);
                        //Response.Redirect(currentUser.Url, false);
                    }
                    else
                    {
                        //User is not registered.Please contact with administrator.
                    }
                   
                }
                else
                {
                    //Invalid password or login.
                }
            }
            catch(Exception ex)
            {

            }
        }
        #endregion 
    }
}