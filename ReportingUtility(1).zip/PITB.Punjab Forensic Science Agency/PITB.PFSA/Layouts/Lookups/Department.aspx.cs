﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Lookups
{
    public partial class Department : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

            }
        }

        #region "Web Methods"

        [WebMethod]
        public static DepartmentModel SaveRecord(string jsonModel)
        {
            int result = 0;
            DepartmentModel departmentModel = null;
            try
            {
                departmentModel = new JavaScriptSerializer().Deserialize<DepartmentModel>(jsonModel);
                departmentModel.CreatedBy = CurrentUser.LoginID;
                result = new DepartmentBLL().Save(departmentModel);
                if (departmentModel.ID == 0 || departmentModel.ID ==null)
                {
                    departmentModel.ID = result;
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Department, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(departmentModel, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Department, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    departmentModel = new DepartmentModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    departmentModel = new DepartmentModel("error|" + ex.Message);
                }
            }

            return departmentModel;
        }

        [WebMethod]
        public static DepartmentModel[] GetRecords()
        {
            List<DepartmentModel> departments = null;

            try
            {
                departments = new DepartmentBLL().GetDepartment();
                if (departments != null && departments.Count > 0)
                    return departments.ToArray();
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Department, CurrentUser.GetSessionUserInfo()));
            }

            return null;
        }

        [WebMethod]
        public static string RemoveRecord(string jsonModel)
        {
            string result;

            try
            {
                DepartmentModel departmentModel = new JavaScriptSerializer().Deserialize<DepartmentModel>(jsonModel);
                int savedResult = new DepartmentBLL().Delete(departmentModel.ID.Value, Convert.ToInt32(CurrentUser.LoginID));
                return (savedResult > 0 ? "true" : "Record is not deleted.");

            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Department, CurrentUser.GetSessionUserInfo()));
                result = LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message);

            }
            return result;
            //TODO: return value or message for integation   
        }

        #endregion
    }
}