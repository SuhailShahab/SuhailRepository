﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Lookups
{
    public partial class SubmittedAgency : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            try
            {
                if (!IsPostBack)
                {
                    // check the current user have rights to access to the page
                    //if (new Common().GetPageAccessPermission(login, PageNames.Division) == false)
                    //{
                    //    Response.Redirect("../Dashboard/Error/Error.aspx?Key=PageRightsDenied", true);
                    //}
                }
            }
            catch { }
        }



        #region "Web Methods"

        [WebMethod]
        public static SubmittedAgencyModel SaveRecord(string jsonModel)
        {
            int? result = null;
            SubmittedAgencyModel submittedagencyModel = null;

            try
            {
                submittedagencyModel = new JavaScriptSerializer().Deserialize<SubmittedAgencyModel>(jsonModel);
                if (submittedagencyModel.ID.HasValue && submittedagencyModel.ID > 1)
                {
                    submittedagencyModel.ModifiedBy = CurrentUser.LoginID;
                }
                else
                {
                    submittedagencyModel.CreatedBy = CurrentUser.LoginID;
                }
                result = new SubmittedAgencyBLL().Save(submittedagencyModel);
                if (submittedagencyModel != null)
                {
                    submittedagencyModel.ID = result;
                    LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(submittedagencyModel, CutomMessage.SavedSuccessfully);
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SubmittedAgency, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(submittedagencyModel, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.SubmittedAgency, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    submittedagencyModel = new SubmittedAgencyModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    submittedagencyModel = new SubmittedAgencyModel("error|" + ex.Message);
                }
            }

            return submittedagencyModel;
        }

        [WebMethod]
        public static SubmittedAgencyModel[] GetRecords()
        {
            List<SubmittedAgencyModel> agencies = new List<SubmittedAgencyModel>();
            try
            {
                
                agencies= new SubmittedAgencyBLL().GetAllAgencies();

                if (agencies != null && agencies.Count > 0)
                    return agencies.ToArray();
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.SubmittedAgency, CurrentUser.LoginID));
              //  LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(agencies, ex.Message);
            }

            return null;
        }

        [WebMethod]
        public static string RemoveRecord(string jsonModel)
        {
            int? result = null;

            try
            {
                SubmittedAgencyModel agencyModel = new JavaScriptSerializer().Deserialize<SubmittedAgencyModel>(jsonModel);
                agencyModel.CreatedBy = CurrentUser.LoginID;

                result = new SubmittedAgencyBLL().Delete(agencyModel);
                return (result.HasValue && result > -1 ? "true" : "false");
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.SubmittedAgency, CurrentUser.LoginID));
                return LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message);
            }

            //TODO: return value or message for integation   
        }

        #endregion
    }
}