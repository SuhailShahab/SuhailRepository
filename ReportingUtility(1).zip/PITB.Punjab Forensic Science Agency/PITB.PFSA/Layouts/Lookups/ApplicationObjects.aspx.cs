﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Lookups
{
    public partial class ApplicationObjects : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static ApplicationObjectsModel SaveRecord(string jsonModel)
        {

            int result = 0;
            ApplicationObjectsModel model = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<ApplicationObjectsModel>(jsonModel);

                model.CreatedBy = CurrentUser.LoginID;// Convert.ToString(dtUser.Rows[0]["EmployeeName"]);

                result = new ApplicationObjectsBLL().Save(model);
                if (model.ID == 0)
                {
                    model.ID = result;
                }
            }
            catch (Exception ex)
            {

                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new ApplicationObjectsModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new ApplicationObjectsModel("error|" + ex.Message);
                }
            }

            return model;
        }


        [WebMethod]
        public static ApplicationObjectsModelView GetRecords()
        {
            List<ApplicationObjectsModel> applicationObjectes = null;
            List<FeaturesModel> features = null;
            ApplicationObjectsModelView applicationObjectsModelView = new ApplicationObjectsModelView();

            try
            {
                applicationObjectes = new ApplicationObjectsBLL().GetAppObject();
                features = new FeatureBLL().GetFeatures();

                features = features.Where(p => p.menuLocation == 1).ToList();

                if (applicationObjectes != null && applicationObjectes.Count > 0)
                    applicationObjectsModelView.ApplicationObjectes = applicationObjectes;

                if (features != null && features.Count > 0)

                    //features.GetEnumerator().
                    applicationObjectsModelView.Features = features;
                applicationObjectsModelView.IsAdmin = CurrentUser.LoginName.Contains("super.user") ? true : false;

                return applicationObjectsModelView;
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(applicationObjectsModelView, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    applicationObjectsModelView = new ApplicationObjectsModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    applicationObjectsModelView = new ApplicationObjectsModelView("error|" + ex.Message);
                }
            }

            return applicationObjectsModelView;
        }

        #endregion
    }
}