﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.BLL.RightsManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Lookups
{
    public partial class Province : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static ProvinceModel SaveRecord(string jsonModel)
        {
            int result = 0;
            ProvinceModel ProvinceModel = null;

            try
            {
                ProvinceModel = new JavaScriptSerializer().Deserialize<ProvinceModel>(jsonModel);
                result = new ProvinceBLL().Save(ProvinceModel);
                if (result > 0)
                {
                    ProvinceModel.ID = result;
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Province, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ProvinceModel = new ProvinceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ProvinceModel = new ProvinceModel("error|" + ex.Message);
                }
            }

            return ProvinceModel;
        }

        [WebMethod]
        public static List<ProvinceModel> GetRecord()
        {
            List<ProvinceModel> Provinces = null;

            try
            {
                Provinces = new ProvinceBLL().GetAllProvinces();
                if (Provinces != null && Provinces.Count > 0)
                {
                    return Provinces;
                }
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecord", 1, PageNames.Province, CurrentUser.LoginID));
               
                //TODO: save error log and return error message
            }

            return null;
        }

        [WebMethod]
        public static string RemoveRecord(string jsonModel)
        {
            int? result = null;
            try
            {
                ProvinceModel ProvinceModel = new JavaScriptSerializer().Deserialize<ProvinceModel>(jsonModel);
                result = new ProvinceBLL().Delete(ProvinceModel.ID);
                return (result.HasValue && result.Value > -1 ? "true" : "false");
            }
            catch (Exception ex)
            {
                throw ex;
            }

            //TODO: return value or message for integation   
        }

        #endregion
    }
}