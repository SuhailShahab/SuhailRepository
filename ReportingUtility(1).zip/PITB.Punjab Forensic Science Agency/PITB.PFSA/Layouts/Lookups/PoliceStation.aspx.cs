﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Lookups
{
    public partial class PoliceStation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static PoliceStationModelView GetRecords()
        {
            PoliceStationModelView objPoliceStationModelView = new PoliceStationModelView();

            try
            {
                List<DivisionModel> colDivison = new DivisionBLL().GetDivision().Where( p=>p.Status == true).OrderBy (p=>p.Title ).ToList ();
                List<GeneralDistrictModel> colDistrict = new GeneralDistrictBLL().GetAllGeneralDistricts().OrderBy ( p=>p.Title ) .ToList ();
                List<PoliceStationModel> colPoliceStations = new PoliceStationBLL().GetPoliceStations() ;

                if (colDivison != null && colDivison.Count > 0)
                {
                    objPoliceStationModelView.Divisions = new List<DivisionModel>();
                    objPoliceStationModelView.Divisions = colDivison;
                }

                if (colDistrict != null && colDistrict.Count > 0)
                {
                    objPoliceStationModelView.Districts = new List<GeneralDistrictModel>();
                    objPoliceStationModelView.Districts = colDistrict;
                }

                if (colPoliceStations != null && colPoliceStations.Count > 0)
                {
                    objPoliceStationModelView.PoliceStation = new List<PoliceStationModel>();
                    objPoliceStationModelView.PoliceStation = colPoliceStations;
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.PoliceStation, CurrentUser.GetSessionUserInfo()));
                //objPoliceStationModelView.Notification = ex.Message;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.PoliceStation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    objPoliceStationModelView = new PoliceStationModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    objPoliceStationModelView = new PoliceStationModelView("error|" + ex.Message);
                }
            }

            return objPoliceStationModelView;
        }

        [WebMethod]
        public static PoliceStationModel SaveRecord(string jsonModel)
        {
            PoliceStationModel ObjPoliceStationModel = new PoliceStationModel();

            try
            {
                PoliceStationBLL objPoliceStationBLL = new PoliceStationBLL();

                ObjPoliceStationModel = new JavaScriptSerializer().Deserialize<PoliceStationModel>(jsonModel);
                ObjPoliceStationModel.CreatedBy = CurrentUser.LoginID;

                int Result = objPoliceStationBLL.Save(ObjPoliceStationModel);
                if (Result > 0)
                {
                    ObjPoliceStationModel.ID = Result;
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.PoliceStation, CurrentUser.GetSessionUserInfo()));
                //ObjPoliceStationModel.Notification = ex.Message;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.PoliceStation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ObjPoliceStationModel = new PoliceStationModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ObjPoliceStationModel = new PoliceStationModel("error|" + ex.Message);
                }
            }

            return ObjPoliceStationModel;
        }

        [WebMethod]
        public static string RemoveRecord(string jsonModel)
        {
            int? result = null;

            try
            {
                PoliceStationModel policeStationModel = new JavaScriptSerializer().Deserialize<PoliceStationModel>(jsonModel);
                policeStationModel.CreatedBy = CurrentUser.LoginID;

                result = new PoliceStationBLL().Delete(policeStationModel);
                return (result.HasValue && result > -1 ? "true" : "false");
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.PoliceStation, CurrentUser.LoginID));
                return LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message);
            }

            //TODO: return value or message for integation   
        }
        #endregion
    }
}