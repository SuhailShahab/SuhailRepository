﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
// =================================================================================================================================
// Create by:	<Suhail Shahab>
// Create date: <17-09-2015 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
namespace PITB.PFSA.Layouts.Lookups
{
    public partial class ApplicationFeatures : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static FeaturesModel SaveRecord(string jsonModel)
        {
            int result = 0;
            FeaturesModel ApplicationFeaturesModel = null;
            try
            {
                ApplicationFeaturesModel = new JavaScriptSerializer().Deserialize<FeaturesModel>(jsonModel);

                ApplicationFeaturesModel.CreatedBy = CurrentUser.LoginID;

                FeatureBLL featureBLL = new FeatureBLL();

                result =featureBLL.Save(ApplicationFeaturesModel);
                if (ApplicationFeaturesModel.ID == 0)
                {
                    ApplicationFeaturesModel.ID = result;
                }
                featureBLL = null;
            }
            catch (Exception ex)
            {
                //CommonBLL common = LazyBaseSingleton<CommonBLL>.Instance;
                //common.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1,PageNames.ApplicationFeature,CurrentUser.GetSessionUserInfo()));
                //common.NotificationErrorMsg(ApplicationFeaturesModel, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationFeature, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ApplicationFeaturesModel = new FeaturesModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    ApplicationFeaturesModel = new FeaturesModel("error|" + ex.Message);
                }
            }

            return ApplicationFeaturesModel;
        }

        /// <summary>
        /// Get Records
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static FeaturesModel[] GetRecords()
        {
            List<FeaturesModel> Lists = null;

            try
            {
                Lists = new FeatureBLL().GetFeature();
                if (Lists != null && Lists.Count > 0)
                    return Lists.ToArray();
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ApplicationFeature, CurrentUser.GetSessionUserInfo()));
                //TODO: save error log and return error message

               
            }

            return null;
        }
        
        #endregion
    }
}