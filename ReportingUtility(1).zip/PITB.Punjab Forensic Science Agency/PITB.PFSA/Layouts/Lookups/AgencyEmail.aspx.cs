﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.CustomExceptions;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Lookups
{
    public partial class AgencyEmail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        [WebMethod]
        public static AgencyEmailModel SaveRecord(string jsonModel)
        {
            int? result = null;
            AgencyEmailModel agncyModel = null;

            try
            {
                agncyModel = new JavaScriptSerializer().Deserialize<AgencyEmailModel>(jsonModel);
                agncyModel.CreatedBy = CurrentUser.LoginID;


                result = LazyBaseSingleton<AgencyEmailBLL>.Instance.Save(agncyModel);
                if (agncyModel != null)
                {
                    agncyModel.ID = result;
                    LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(agncyModel, CutomMessage.SavedSuccessfully);
                }
                
            }
            catch (BusinessException ex)
            {
                agncyModel = new AgencyEmailModel("info|" + ex.ErroMessage);
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.AgencyEmail, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingleton<CommonBLL>.Instance.NotificationMsg(agncyModel, ex.Message, new AgencyEmailModel().GetType());

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.AgencyEmail, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    agncyModel = new AgencyEmailModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    agncyModel = new AgencyEmailModel("error|" + ex.Message);
                }
            }

            return agncyModel;
        }

        [WebMethod]
        public static AgencyEmailModelView GetRecords()
        {
            AgencyEmailModelView agencyEmailModelView = new AgencyEmailModelView();

            try
            {
                // Fill Model
              
                agencyEmailModelView.Agencies = LazyBaseSingleton<SubmittedAgencyBLL>.Instance.GetAllAgencies().OrderBy(p => p.Title).ToList();
                agencyEmailModelView.EmailAgencies = LazyBaseSingleton<AgencyEmailBLL>.Instance.GetAllAgencies(); 

            }

            catch (Exception ex)
            {
                //TODO: save error log and return error message
                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.AgencyEmail, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(agencyEmailModelView, ex.Message);
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.AgencyEmail, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    agencyEmailModelView = new AgencyEmailModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    agencyEmailModelView = new AgencyEmailModelView("error|" + ex.Message);
                }
            }

            return agencyEmailModelView;
        }

        [WebMethod]
        public static string RemoveRecord(string jsonModel)
        {
            int? result = null;
            string errorMessage = string.Empty;

            try
            {
                AgencyEmailModel agncyModel = new JavaScriptSerializer().Deserialize<AgencyEmailModel>(jsonModel);

                agncyModel.CreatedBy = CurrentUser.LoginID;

                result = LazyBaseSingleton<AgencyEmailBLL>.Instance.Delete(agncyModel.AgencyID);
                return (result.HasValue && result > -1 ? "true" : "false");
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.AgencyEmail, CurrentUser.GetSessionUserInfo()));
                errorMessage = LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message);
            }
            //TODO: return value or message for integation 
            return errorMessage;
        }


        #endregion
    }
}