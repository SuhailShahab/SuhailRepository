﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Lookups
{
    public partial class ErrorLog : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// Get all task status
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static ErrorLogModelView GetRecords(string ErrorLogModel)
        {
            ErrorLogModelView errorLogModelView = new ErrorLogModelView();


            try
            {
                List<ErrorLogModel> ErrorLogs = null;
                ErrorLogModel model = new ErrorLogModel();

                #region "Dropdoown"

                List<GeneralDistrictModel> Districts = new GeneralDistrictBLL().GetDistricts(null);
                if (Districts != null && Districts.Count > 0)
                    errorLogModelView.Districts = Districts;

                List<PageNameModel> Pages = new PageNameBLL().GetPages();
                errorLogModelView.PageNames = Pages;

                #endregion

                if (ErrorLogModel != "undefined")
                {
                    model = new JavaScriptSerializer().Deserialize<ErrorLogModel>(ErrorLogModel);
                    ErrorLogs = new ErrorLogBLL().GetErrorLogs(model);
                    if (ErrorLogs != null && ErrorLogs.Count > 0)
                    {
                        errorLogModelView.ErrorLogs = new List<ErrorLogModel>();
                        errorLogModelView.ErrorLogs = ErrorLogs;
                    }
                }
                else
                {
                    ErrorLogs = new ErrorLogBLL().GetErrorLogs(model);
                    if (ErrorLogs != null && ErrorLogs.Count > 0)
                    {
                        errorLogModelView.ErrorLogs = new List<ErrorLogModel>();
                        errorLogModelView.ErrorLogs = ErrorLogs;
                    }
                }
                return errorLogModelView;
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ErrorLog, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    errorLogModelView = new ErrorLogModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    errorLogModelView = new ErrorLogModelView("error|" + ex.Message);
                }
            }

            return null;
        }


        [WebMethod]
        public static ErrorLogModelView GetRecordsBySearchCreiteria(string jsonModel, string searchByID, string searchByMessage)
        {
            ErrorLogModelView modelView = new ErrorLogModelView();

            try
            {
                List<ErrorLogModel> ErrorLogs = new List<ErrorLogModel>();
                ErrorLogModel model = new ErrorLogModel();

                int SearchByID = 0; string SearchByMessage = null;
                if (searchByID != "" && searchByID != null && searchByID != "undefined")
                    SearchByID = Convert.ToInt32(searchByID);
                if (searchByMessage != "" && searchByMessage != null)
                    SearchByMessage = (searchByMessage);
                if (jsonModel != "undefined")
                    model = new JavaScriptSerializer().Deserialize<ErrorLogModel>(jsonModel);

                // Get records based on filter
                List<ErrorLogModel> LogErrorsList = new ErrorLogBLL().GetErrorLogsBySearchCretira(SearchByID, SearchByMessage);
                if (LogErrorsList != null && LogErrorsList.Count > 0)
                    modelView.ErrorLogs = LogErrorsList;




            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.ErrorLog, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    modelView = new ErrorLogModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    modelView = new ErrorLogModelView("error|" + ex.Message);
                }
            }

            return modelView;
        }
   
    }
}