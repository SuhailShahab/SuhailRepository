﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Lookups
{
    public partial class Division : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {


            try
            {
                if (!IsPostBack)
                {
                    // check the current user have rights to access to the page
                    //if (new Common().GetPageAccessPermission(login, PageNames.Division) == false)
                    //{
                    //    Response.Redirect("../Dashboard/Error/Error.aspx?Key=PageRightsDenied", true);
                    //}
                }
            }
            catch { }
        }



        #region "Web Methods"

        [WebMethod]
        public static DivisionModel SaveRecord(string jsonModel)
        {
            int? result = null;
            DivisionModel divisionModel = null;

            try
            {
                divisionModel = new JavaScriptSerializer().Deserialize<DivisionModel>(jsonModel);

                divisionModel.CreatedBy = CurrentUser.LoginID;
                result = new DivisionBLL().Save(divisionModel);
                if (divisionModel != null)
                {
                    divisionModel.ID = result;
                    LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(divisionModel, CutomMessage.SavedSuccessfully);
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Division, CurrentUser.GetSessionUserInfo()));
                //LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(divisionModel, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.Division, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    divisionModel = new DivisionModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    divisionModel = new DivisionModel("error|" + ex.Message);
                }

            }

            return divisionModel;
        }

        [WebMethod]
        public static DivisionViewModel GetRecords()
        {

            DivisionViewModel model = new DivisionViewModel();
            try
            {
                model.Divisions = new DivisionBLL().GetDivision();
                //model.Provinces = new ProvinceBLL().GetAllActiveProvinces();
                model.Provinces = new ProvinceBLL().GetAllProvinces().OrderBy(p => p.Title).ToList();
                //if (divisions != null && divisions.Count > 0)
                //    return divisions.ToArray();
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message
                //LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Division, CurrentUser.LoginID));
                //LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.Division, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DivisionViewModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DivisionViewModel("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static string RemoveRecord(string jsonModel)
        {
            int? result = null;

            try
            {
                DivisionModel DivisionModel = new JavaScriptSerializer().Deserialize<DivisionModel>(jsonModel);


                DivisionModel.CreatedBy = CurrentUser.LoginID;

                result = new DivisionBLL().Delete(DivisionModel.ID.Value, DivisionModel.CreatedBy.Value);
                return (result.HasValue && result > -1 ? "true" : "false");
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.Division, CurrentUser.LoginID));
                return LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message);
            }

            //TODO: return value or message for integation   
        }

        #endregion
    }
}