﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Lookups
{
    public partial class Group : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "Web Methods"

        /// <summary>
        /// Save group information
        /// </summary>
        /// <param name="jsonModel"></param>
        /// <returns>Added GroupID as integer</returns>
        [WebMethod]
        public static int SaveRecord(string jsonModel)
        {
            int result = 0;
            GroupModel groupModel = null;

            try
            {
                groupModel = new JavaScriptSerializer().Deserialize<GroupModel>(jsonModel);

                groupModel.CreatedBy = CurrentUser.LoginID;

                result = new GroupBLL().Save(groupModel);

                if (groupModel.ID == 0)
                {
                    groupModel.ID = result;
                }

            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
               
            }

            return result;
        }

        /// <summary>
        /// Get all groups
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static GroupModel[] GetRecords()
        {
            List<GroupModel> groups = null;

            try
            {
                groups = new GroupBLL().GetGroup();
                if (groups != null && groups.Count > 0)
                    return groups.ToArray();
            }
            catch (Exception ex)
            {
                //TODO: save error log and return error message

            }

            return null;
        }

        /// <summary>
        /// Delete existing group against provider group
        /// </summary>
        /// <param name="jsonModel"></param>
        [WebMethod]
        public static string RemoveRecord(string jsonModel)
        {
            int? result = null;

            try
            {
                GroupModel groupModel = new JavaScriptSerializer().Deserialize<GroupModel>(jsonModel);
                groupModel.CreatedBy = CurrentUser.LoginID;
                result = new GroupBLL().Delete(groupModel.ID, groupModel.CreatedBy.Value);
                return (result.HasValue && result > -1 ? "true" : "false");
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "RemoveRecord", 1, PageNames.ApplicationObjects, CurrentUser.GetSessionUserInfo()));
                return LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message);
            }

            //TODO: return value or message for integation   
        }

        #endregion
    }
}