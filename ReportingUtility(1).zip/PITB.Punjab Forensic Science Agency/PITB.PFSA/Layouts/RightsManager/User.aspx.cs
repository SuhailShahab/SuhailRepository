﻿using PITB.PFSA.ApplicationClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.RightsManager
{
    public partial class User : PageBase
    {
        protected override void OnPreInit(EventArgs e)
        {
            base.OnPreInit(e);
        }
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
    }
}