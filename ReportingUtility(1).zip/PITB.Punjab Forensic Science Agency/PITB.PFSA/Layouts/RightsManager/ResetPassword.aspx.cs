﻿using PITB.PFSA.ApplicationClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.RightsManager
{
    public partial class ResetPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnUserType.Value = CurrentUser.UserTypeID.ToString();
        }
    }
}