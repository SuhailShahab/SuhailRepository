﻿
using Microsoft.Reporting.WebForms;
using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.Reports;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Reports
{
    public partial class FileProcessingInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
            //    this.hdfReportUrl.Value = ConfigurationHelper.ReportUrl;
            //    this.hdfLoginName.Value = CurrentUser.LoginName;
            //    this.hdfLoginID.Value = (CurrentUser.LoginID ?? 0).ToString();
            //}
        }

        #region "Web Methods"


        [WebMethod]
        public static FileProcessingInfoView GetRecords()
        {

            FileProcessingInfoView model = new FileProcessingInfoView();
            try
            {
                model.Departments = LazyBaseSingleton<DepartmentBLL>.Instance.GetDepartments();
                model.FilteProcessStatues = LazyBaseSingleton<FileProcessStatusBLL>.Instance.GetAllFileProcessStatuses();
                model.Users = LazyBaseSingleton<UserBLL>.Instance.GeUsersByDepartmentID(null);

                model.ReportUrl = ConfigurationHelper.CommonReportUrl;
                model.LoginName = CurrentUser.LoginName;
                model.UserID = (CurrentUser.LoginID ?? 0);
                model.ReportTypeName = ReportTypeName.FileProcessingInfoDetail.GetHashCode().ToString();

            }

            catch (Exception ex)
            {
                //TODO: save error log and return error message
              //  LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.GeneralDistrict, CurrentUser.GetSessionUserInfo()));             
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.FileProcessingInfo, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new FileProcessingInfoView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new FileProcessingInfoView("error|" + ex.Message);
                }
            }

            return model;
        }

        [WebMethod]
        public static FileProcessingInfoView GetUsersByDepartmentID(string departmentID)
        {

            FileProcessingInfoView model = new FileProcessingInfoView();

            try
            {
                model.Users = LazyBaseSingleton<UserBLL>.Instance.GeUsersByDepartmentID(Convert.ToInt32(departmentID));
               

            }

            catch (Exception ex)
            {
                //TODO: save error log and return error message
               // LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 1, PageNames.GeneralDistrict, CurrentUser.GetSessionUserInfo()));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetUsersByDepartmentID", 1, PageNames.FileProcessingInfo, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new FileProcessingInfoView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new FileProcessingInfoView("error|" + ex.Message);
                }
            }

            return model;
        }
        #endregion;

      

    }
}