﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.Inquiry;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.CustomExceptions;
using PITB.PFSA.BLL.EvidenceForms;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.BLL.RightsManager;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Layouts.Inquiry
{

    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <17-09-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // 001          Sajjad Aslam                24-May-2017                 Add method SendEmail
    // =================================================================================================================================
    public partial class EvidenceSubmision : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!CurrentUser.LoginID.HasValue)
                {
                    throw new BusinessException(CutomMessage.UserDistrictMissing);
                }
                hdnUserType.Value = CurrentUser.UserTypeID.ToString();
                //============Document Save=============================================
                //if (Request.Form["CaseID"] != null)// implement document center 
                //    new Common().UpdateFiles(Page.Request, TableName.tblEvidenceInformations);
                if (Request.Form["CaseID"] != null)
                {
                    string ipAddress = Convert.ToString(Request.Form["IPAddress"]);
                    string computerName = Convert.ToString(Request.Form["hostName"]);
                    new Common().UpdateFiles(Page.Request, TableName.tblEvidenceInformations, ipAddress, computerName);
                }

            }
            catch (BusinessException ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo()));
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode + "');", true);
                }
                else
                {

                    ScriptManager.RegisterStartupScript(this, GetType(), "ServerControlScript", "toastr.error('" + ex.Message + "');", true);
                }
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo()));
            }
        }

        #region Web Methods


        /// <summary>
        /// Get record from Database
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static EvidenceModelView GetRecords(string paramObject)
        {
            IndexSearchModel paramModel = null;
            paramModel = new JavaScriptSerializer().Deserialize<IndexSearchModel>(paramObject);


            UserModel userInfo = CurrentUser.GetSessionUserInfo();
            EvidenceModelView viewModel = new EvidenceModelView();
            viewModel.Evidences = new List<EvidenceModel>();
            try
            {
                #region "Set Page Size"
                int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                #endregion

                #region " ************************ Comment Out ***************************"
                //int? UserID = null;
                //int? DistrictID = null;
                //int? UserTypeID = null;
                //UserID = Convert.ToInt32(userID);
                //DistrictID = Convert.ToInt32(districtID);
                //UserTypeID = Convert.ToInt32(userTypeID);

                //UserModel User = new UserModel();
                //User.UserID = CurrentUser.LoginID;
                //User.DistrictID = CurrentUser.DistrictID;
                //User.UserTypeID = CurrentUser.UserTypeID;
                #endregion

                viewModel = new EvidenceModelView();
                int PageNo = Convert.ToInt32(paramModel.PageIndex);

                if (PageNo != 0)

                    viewModel.PageNo = PageNo;
                else
                {
                    viewModel.PageNo = 1;
                    PageNo = 1;
                }

                viewModel.PageSize = PageSize;
                viewModel.TotalCount = 0;
                // viewModel.User = User;


                //viewModel.Evidences = new EvidenceInformationBLL().GetAllEvidenceSubmissionsDBP(userInfo.UserID.Value, userInfo.DistrictID.Value, userInfo.UserTypeID.Value, PageNo, PageSize, paramModel.ID);
                paramModel.UserID = userInfo.UserID;
                paramModel.UserTypeID = userInfo.UserTypeID;
                paramModel.PageSize = PageSize;
                viewModel.Evidences = new EvidenceInformationBLL().GetAllEvidenceSubmissionsDBP(paramModel);
                if (paramModel.IsLoad == true)
                {
                    viewModel.Districts = new GeneralDistrictBLL().GetAllGeneralDistricts().ToList();
                    viewModel.Provinces = new ProvinceBLL().GetAllActiveProvinces();
                    viewModel.PoliceStations = LazyBaseSingleton<PoliceStationBLL>.Instance.GetAllPoliceStationsByDistrictID(null);
                    viewModel.CaseStatuses = LazyBaseSingleton<CaseStatusBLL>.Instance.GetAllStatues();
                    viewModel.Countries = LazyBaseSingleton<CountryBLL>.Instance.GetAllCountries();
                    viewModel.Agencies = LazyBaseSingleton<SubmittedAgencyBLL>.Instance.GetAllAgencies().OrderBy(p => p.Title).ToList();
                }

                viewModel.AllowFileAttachment = userInfo.AllowFileAttachment;
                viewModel.AllowFileDownload = userInfo.AllowFileDownload;
                viewModel.AllowFileRemoved = userInfo.AllowFileRemoved;
                viewModel.AllowFileView = userInfo.AllowFileView;
                /// Total Records Count
                /// 
                if (viewModel.Evidences.Count > 0)
                    viewModel.TotalCount = viewModel.Evidences[0].RESULT_COUNT.Value;


            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords", 1, PageNames.EvidenceInformation, userInfo)).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    viewModel = new EvidenceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    viewModel = new EvidenceModelView("error|" + ex.Message);
                }
            }

            return viewModel;
        }

        [WebMethod]
        public static EvidenceModelView GetRecords1()
        {

            UserModel userInfo = CurrentUser.GetSessionUserInfo();
            EvidenceModelView viewModel = new EvidenceModelView();
            viewModel.Evidences = new List<EvidenceModel>();
            try
            {
                viewModel.Evidences = new EvidenceInformationBLL().GetAllEvidenceInformationByID(userInfo.UserID.Value, userInfo.DistrictID.Value, userInfo.UserTypeID.Value);
                viewModel.Districts = new GeneralDistrictBLL().GetAllGeneralDistricts().OrderBy(p => p.Title).ToList();
                viewModel.Provinces = new ProvinceBLL().GetAllActiveProvinces();
                viewModel.PoliceStations = LazyBaseSingleton<PoliceStationBLL>.Instance.GetAllPoliceStationsByDistrictID(null);
                viewModel.CaseStatuses = LazyBaseSingleton<CaseStatusBLL>.Instance.GetAllStatues();
                viewModel.Countries = LazyBaseSingleton<CountryBLL>.Instance.GetAllCountries();
                viewModel.Agencies = LazyBaseSingleton<SubmittedAgencyBLL>.Instance.GetAllAgencies().OrderBy(p => p.Title).ToList();

                viewModel.AllowFileAttachment = userInfo.AllowFileAttachment;
                viewModel.AllowFileDownload = userInfo.AllowFileDownload;
                viewModel.AllowFileRemoved = userInfo.AllowFileRemoved;
                viewModel.AllowFileView = userInfo.AllowFileView;

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetRecords1", 1, PageNames.EvidenceInformation, userInfo)).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    viewModel = new EvidenceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    viewModel = new EvidenceModelView("error|" + ex.Message);
                }
            }

            return viewModel;
        }

        /// <summary>
        /// Save Evidence Information in Database
        /// </summary>
        /// <param name="jsonModel">Pass the Evidence Model from Client Page</param>
        /// <returns> return 1 in case of Success</returns>
        [WebMethod]
        public static EvidenceModel SaveRecord(string jsonModel)
        {
            EvidenceModel model = null;
            try
            {
                if (CurrentUser.UserTypeID == 4)
                {
                    model = new JavaScriptSerializer().Deserialize<EvidenceModel>(jsonModel);

                    //-----------General Fields-----------------------------
                    model.CreatedBy = CurrentUser.LoginID;

                    if (string.IsNullOrEmpty(model.CaseID))
                    {
                        model.CaseID = CommonBLL.GetCaseIDKey(CurrentUser.DistrictCode);
                        model.IsEdit = false;
                    }
                    else
                        model.IsEdit = true;

                    ///=====================Save In Database =======================
                    new EvidenceInformationBLL().Save(model);
                    ///====================================================================
                   // LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo()));
                // LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(model, ex.Message);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveRecord", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new EvidenceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new EvidenceModel("error|" + ex.Message);
                }
            }

            return model;
        }

        /// <summary>
        /// Delete Evidence Documents
        /// </summary>
        /// <param name="documentURL">Document URL</param>
        /// <param name="documentID">Document ID</param>
        /// <param name="caseID">Selected Case ID</param>
        /// <returns></returns>
        //[WebMethod]
        //public static DocumentModel DeleteDocument(string documentURL, string documentTitle, string documentFileName, string caseID)
        //{
        //    DocumentModel model = new DocumentModel();

        //    try
        //    {
        //        LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(new Exception(documentURL), documentURL, 1, "Start DeleteDocument web Mehod", CurrentUser.GetSessionUserInfo()));

        //        model.Notification = Common.DeleteDocuments(documentURL, documentTitle,documentFileName, caseID, TableName.tblEvidenceInformations);

        //       // LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(new Exception(documentURL), documentURL, 1, " End DeleteDocument web Mehod", CurrentUser.GetSessionUserInfo()));
        //        LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.DocumentDeleteSuccessfully);


        //    }
        //    catch (Exception ex)
        //    {
        //        LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "DeleteDocument Case ID:" + caseID, 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo()));
        //        model.Notification = LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message + "Case ID" + caseID);
        //    }


        //    return model;
        //}
        [WebMethod]
        public static DocumentModel DeleteDocument(string ipAddress, string computerName, string documentURL, string documentTitle, string documentFileName, string caseID)
        {
            DocumentModel model = new DocumentModel();

            try
            {
                model.Notification = Common.DeleteDocuments(documentURL, documentTitle, documentFileName, caseID, TableName.tblEvidenceInformations);
                LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.DocumentDeleteSuccessfully);
                FileProcessingInfoModel fileModel = new FileProcessingInfoModel()
                {
                    CaseID = caseID,
                    CreatedBy = CurrentUser.LoginID,
                    FileProcessStatusID = FileProcessName.FileDelete.GetHashCode(),
                    //FileName = documentFileName,
                    FileName = documentTitle,
                    ClientIPAddress = ipAddress,
                    ComputerName = computerName
                };

                //Add User Information for file delete
                if (model.Notification.Contains("success|"))
                {
                    int? result = LazyBaseSingleton<FileProcessingInfoBLL>.Instance.AddFileProcessingInfo(fileModel);
                }



            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "DeleteDocument Case ID:" + caseID, 1, PageNames.Home, CurrentUser.GetSessionUserInfo()));
                //model.Notification = LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message + "Case ID" + caseID);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "DeleteDocument", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DocumentModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DocumentModel("error|" + ex.Message);
                }
            }

            LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            return model;
        }


        [WebMethod]
        public static FileProcessingInfoModel SaveInfo(string ipAddress, string computerName, string documentFileName, string caseID, string fileProcessStatusID)
        {
            FileProcessingInfoModel model = null;

            try
            {

                model = new FileProcessingInfoModel()
                {
                    CaseID = caseID,
                    CreatedBy = CurrentUser.LoginID,
                    FileProcessStatusID = string.IsNullOrEmpty(fileProcessStatusID) ? FileProcessName.None.GetHashCode() : Convert.ToInt32(fileProcessStatusID),
                    FileName = documentFileName,
                    ClientIPAddress = ipAddress,
                    ComputerName = computerName
                };

                //Add User Information for file delete
                int? result = LazyBaseSingleton<FileProcessingInfoBLL>.Instance.AddFileProcessingInfo(model);


            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "DeleteDocument Case ID:" + caseID, 1, PageNames.Home, CurrentUser.GetSessionUserInfo()));
                //if (model == null)
                //    model = new FileProcessingInfoModel();
                //model.Notification = LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message + "Case ID" + caseID);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SaveInfo", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new FileProcessingInfoModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new FileProcessingInfoModel("error|" + ex.Message);
                }
            }

            LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            return model;
        }

        //[WebMethod]
        //public static int? SendEmail(string jsonModel, bool isAttachment)
        //{
        //    EvidenceModel model = null;
        //    try
        //    {

        //        model = new JavaScriptSerializer().Deserialize<EvidenceModel>(jsonModel);

        //        string subject = "Transmittal of PFSA Laboratory examination E-report";
        //        string body = "<div> The analysis request you submitted to Punjab Forensic Science Agency under PFSA case number <b>" + model.CaseNo + "</b> has been completed. Original hard copy of the said lab examination report has been dispatched via TCS courier to the concerned authority. <br>" +
        //                      "If the scanned electronic version of the laboratory report  is desired, please log in to the PFSA E-report server (<a href='http://reports.pfsa.gop.pk/'>reports.pfsa.gop.pk</a>) using legal user/password information to receive a secure PIN code on designated individual's (focal person) mobile phone. <br>" +
        //                      "While still loggd in, upon receiving the PIN code, enter provided PIN to gain access to the above described laboratory examination report. <br>" +
        //                      "This is system generated E-mail, please do not send communication to this address. <br><br>" +
        //                      "Sincerely, <br>Punjab Forensic Science Agency <br><br>" +
        //                      "<b>Legal Disclaimer:</b> This message contains confidential information and is intended only for the individual named. If you are not the named addressee you should not disseminate, distribute or copy this e-mail. Please notify the sender immediately by e-mail at (e-reports.support@pfsa.gop.pk) if you have received this e-mail by mistake and delete this e-mail from your system.";

        //        string emailAddress = model.Email;
        //        if (Convert.ToBoolean(ConfigurationHelper.EnableEmail))
        //        {
        //            //LazyMultiton<SendEmail>.Instance().MailSendAttachment(subject, body, emailAddress, isAttachment, model.Documents);
        //           // EvidenceInformationBLL evidenceInformation = new EvidenceInformationBLL();
        //            return LazyBaseSingleton<EvidenceInformationBLL>.Instance.saveIsSendEmail(model.CaseID);
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        string errorCode = string.Empty;
        //        errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SendEmail", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo())).ToString();
        //        if (ConfigurationHelper.IsShowGeneralMsg)
        //        {
        //            model = new EvidenceModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
        //        }
        //        else
        //        {
        //            model = new EvidenceModel("error|" + ex.Message);
        //        }
        //    }
        //    return null;
        //}

        [WebMethod]
        public static AgencyEmailModelView GetAgencyEmails(int agencyID)
        {
            AgencyEmailModelView agencyEmailModelView = new AgencyEmailModelView();

            try
            {
                agencyEmailModelView.EmailAgencies = LazyBaseSingleton<AgencyEmailBLL>.Instance.GetAgencyEmails(agencyID);
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAgencyEmails", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    agencyEmailModelView = new AgencyEmailModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    agencyEmailModelView = new AgencyEmailModelView("error|" + ex.Message);
                }
            }
            return agencyEmailModelView;
        }

        [WebMethod]
        public static AgencyEmailModelView GetEmailsLogs(int evidenceID)
        {
            AgencyEmailModelView agencyEmailModelView = new AgencyEmailModelView();

            try
            {
                agencyEmailModelView.EmailLogs = LazyBaseSingleton<AgencyEmailBLL>.Instance.GetEmailsLogs(evidenceID);
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetEmailsLogs", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    agencyEmailModelView = new AgencyEmailModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    agencyEmailModelView = new AgencyEmailModelView("error|" + ex.Message);
                }
            }
            return agencyEmailModelView;
        }

        [WebMethod]
        public static AgencyEmail SendEmails(string jsonModel)
        {
            AgencyEmail model = new AgencyEmail();
            string noAttachmentIsRequired = string.Empty;

            //List<AgencyEmailModel> agencyEmails = null;
            try
            {
                model = new JavaScriptSerializer().Deserialize<AgencyEmail>(jsonModel);
                //agencyEmails = new List<AgencyEmailModel>();
                //string subject = "Transmittal of PFSA Laboratory examination E-report";
                string subject = "Transmittal of PFSA Laboratory Examination Report Status";
                //string body = "<div> The analysis request you submitted to Punjab Forensic Science Agency under PFSA case number <b>" + model.CaseNo + "</b> has been completed. Original hard copy of the said lab examination report has been dispatched via TCS courier to the concerned authority. <br>" +
                //              "If the scanned electronic version of the laboratory report  is desired, please log in to the PFSA E-report server (<a href='http://reports.pfsa.gop.pk/'>reports.pfsa.gop.pk</a>) using legal user/password information to receive a secure PIN code on designated individual's (focal person) mobile phone. <br>" +
                //              "While still loggd in, upon receiving the PIN code, enter provided PIN to gain access to the above described laboratory examination report. <br>" +
                //              "This is system generated E-mail, please do not send communication to this address. <br><br>" +
                //              "Sincerely, <br>Punjab Forensic Science Agency <br><br>" +
                //              "<b>Legal Disclaimer:</b> This message contains confidential information and is intended only for the individual named. If you are not the named addressee you should not disseminate, distribute or copy this e-mail. Please notify the sender immediately by e-mail at (e-reports.support@pfsa.gop.pk) if you have received this e-mail by mistake and delete this e-mail from your system.";
                if (model.IsAttachedDocument.HasValue || !model.IsAttachedDocument.Value)
                {
                    noAttachmentIsRequired = "Attachments:&nbsp;&nbsp;&nbsp;No Attachment is required <br><br>";
                }
                string body = noAttachmentIsRequired + "<div> The analysis request submitted to Punjab Forensic Science Agency under PFSA case number <b>" + model.CaseNo + "</b>"
                    + ", FIR # <b>" + model.FIRNo + "</b>"
                    + ", Police Station: <b>" + model.PoliceStationTitle + "</b>"
                    + ", District: <b>" + model.District + "</b> has been completed." +
                    " Original hard copy of the said lab examination report to the concerned authority has been dispatched via UMS Pakistan tracking no <b>" + model.UMSTrackNo + "</b></div><br><br>" +
                    "<div>This is system generated E-mail, please do not send communication to this address.</div><br>" +
                    "<div>Sincerely,</div><br><br>" +
                    "<div>Punjab Forensic Science Agency</div><br><br><br>" +
                    "<b>Legal Disclaimer:</b> This message contains confidential information and is intended only for the individual named. If you are not the named addressee you should not disseminate, distribute or copy this e-mail. Please notify the sender immediately by e-mail at (intimation.reports@pfsa.gop.pk) if you have received this e-mail by mistake and deleted this e-mail from your system.";


                //string emailAddress = model.EmailAgencies;
                //agencyEmails = model.EmailAgencies;



                if (Convert.ToBoolean(ConfigurationHelper.EnableEmail))
                {
                    LazyMultiton<SendEmail>.Instance().MailSendAttachment(subject, body, model.EmailAgencies, model.IsAttachedDocument, model.Documents);
                    LazyBaseSingleton<EvidenceInformationBLL>.Instance.SaveEmailLog(model, CurrentUser.CurrentUserInfo.UserID);
                }

                ////Uncomment Below Block for PFSA and Police API submittion
                if (Convert.ToBoolean(ConfigurationHelper.EnablePoliceDataPosting))
                {
                    PoliceRequestData d = new PoliceRequestData();
                    d.CaseNo = model.CaseNo;
                    d.FIRNo = model.FIRNo;
                    d.PoliceStationTitle = model.PoliceStationTitle;
                    d.District = model.District;
                    d.UMSTrackNo = model.UMSTrackNo;
                    d.EvidenceID = model.EvidenceID;
                    d.FIMSDistrictID = model.FIMSDistrictID;
                    d.FIMSPoliceStationID = model.FIMSPoliceStationID;
                    ResponseModel responseAPI = SendRequestToPoliceAPI(d);

                    if (!responseAPI.status)
                        model.Notification = "error|" + responseAPI.Message;

                    int? result = LazyBaseSingleton<EvidenceInformationBLL>.Instance.SaveRequestToPoliceAPILogs(d, CurrentUser.CurrentUserInfo.UserID); // Logs Call in DB
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SendEmail", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    model.Notification = "error|" + ex.Message;
                }
            }
            return model;
        }
        #endregion


        #region Private Methods



        private static ResponseModel SendRequestToPoliceAPI(PoliceRequestData RequestData)
        {
            PoliceRequestData model = new PoliceRequestData();
            model = RequestData;
            string response = string.Empty;
            ResponseModel responseModel = new ResponseModel();
            try
            {
                Uri address = new Uri(ConfigurationHelper.PunjabPoliceAPIURL);
                NameValueCollection values = new NameValueCollection();
                values.Add("PSRMS-API-KEY", "1G12QkZ90Kv7CQiLmUXkLEd6665eIe970LAE987");
                values.Add("case_no", RequestData.CaseNo);
                values.Add("fir_no", RequestData.FIRNo);
                values.Add("ps_id", Convert.ToString(RequestData.FIMSPoliceStationID));
                values.Add("dis_id", Convert.ToString(RequestData.FIMSDistrictID));
                values.Add("fir_year", string.Empty);
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                using (WebClient client = new WebClient())
                {
                    client.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
                    byte[] result = client.UploadValues(address, "POST", values);
                    response = Encoding.UTF8.GetString(result);

                    if (response.IndexOf("{") >= 0)
                        response = response.Substring(response.IndexOf("{"), response.Length - response.IndexOf("{"));

                    var serializer = new JavaScriptSerializer();

                    responseModel = serializer.Deserialize<ResponseModel>(response.Trim());
                }
            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SendRequestToPoliceAPI", 1, PageNames.EvidenceInformation, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model.Notification = "error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode;
                }
                else
                {
                    model.Notification = "error|" + ex.Message;
                }
            }
            return responseModel;
        }

        #endregion


    }
}