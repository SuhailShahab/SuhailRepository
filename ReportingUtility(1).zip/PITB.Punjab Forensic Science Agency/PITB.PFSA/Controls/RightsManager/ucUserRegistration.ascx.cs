﻿using Microsoft.SharePoint;
using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.CustomExceptions;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.BLL.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Controls.RightsManager
{
    public partial class ucUserRegistration : System.Web.UI.UserControl
    {

        #region "Paging Variable and Paging Properties"

        int PageSize = 25;
        int PagingSize = 5;
        int TotalRecords = 0;

        public int PageNumber
        {
            get
            {
                int val = 0;
                if (ViewState["PageNumber"] != null)
                    val = Convert.ToInt32(ViewState["PageNumber"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageNumber"] = value;
                else
                    ViewState["PageNumber"] = null;
            }
        }
        public int PageStart
        {
            get
            {
                int val = 1;
                if (ViewState["PageStart"] != null)
                    val = Convert.ToInt32(ViewState["PageStart"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageStart"] = value;
                else
                    ViewState["PageStart"] = null;
            }
        }
        public int PageCount
        {
            get
            {
                int val = 1;
                if (this.hidPageCount.Value != string.Empty)
                    val = Convert.ToInt32(this.hidPageCount.Value);
                return val;
            }
            set
            {
                if (value >= 1)
                {
                    this.hidPageCount.Value = value.ToString();
                }
            }
        }

        #endregion

        #region "Private Data Members"
        //private int? DistrictID;
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            pnlError.Visible = false;

            if (!IsPostBack)
            {
                try
                {
                    dtpJoined.Value = DateTime.Now.ToString("dd/MM/yyyy");
                    this.GetAddressDivision();
                    GetDepartment();
                    GetDistrict();
                    this.GetAddressDistricts(0);
                    GetGroups();
                    PopulateUsers();
                    this.GetUsertypes();
                    this.dtpResigned.Disabled = true;
                    this.GetAllDistris();
                    this.BindUserRights();
                    this.SetAllDistirctsVisibility();
                    this.PopulateFeaturesMngtMenus();
                }
                catch (Exception ex)
                {
                    //new Common().AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                    //lblError.Text = ex.Message;
                    //pnlError.Visible = true;

                    string errorCode = string.Empty;
                    errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 1, PageNames.Users, CurrentUser.GetSessionUserInfo())).ToString();
                    if (ConfigurationHelper.IsShowGeneralMsg)
                    {
                        lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                        pnlError.Visible = true;

                    }
                    else
                    {
                        lblError.Text = ex.Message;
                        pnlError.Visible = true;

                    }
                }

                ViewState["UserID"] = "";
                ViewState["Edit"] = "No";

            }
        }

        #region "Methods"

        private void GetAddressDivision()
        {
            this.ddlAddressDivisions.DataSource = new DivisionBLL().GetDivisions();
            this.ddlAddressDivisions.DataValueField = "ID";
            this.ddlAddressDivisions.DataTextField = "Title";
            this.ddlAddressDivisions.DataBind();
            this.ddlAddressDivisions.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        private void GetDepartment()
        {
            ddlDepartment.DataSource = new DepartmentBLL().GetDepartments();
            ddlDepartment.DataValueField = "ID";
            ddlDepartment.DataTextField = "Title";
            ddlDepartment.DataBind();
            ddlDepartment.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        private void GetDistrict()
        {
            List<GeneralDistrictModel> genralDisticts = null;


            genralDisticts = new GeneralDistrictBLL().GetDistricts(null);
            ddlDistrict.DataSource = genralDisticts;
            ddlDistrict.DataValueField = "ID";
            ddlDistrict.DataTextField = "Title";
            ddlDistrict.DataBind();
            ddlDistrict.Items.Insert(0, new ListItem("Choose...", "0"));
        }

        private void GetAllDistris()
        {

            this.cblAllDistricts.DataSource = new GeneralDistrictBLL().GetDistricts(null);
            this.cblAllDistricts.DataValueField = "ID";
            this.cblAllDistricts.DataTextField = "Title";
            this.cblAllDistricts.DataBind();
            this.cblAllDistricts.Items.Insert(0, new ListItem("Select All", "0"));
        }

        private void GetAddressDistricts(int divisionID)
        {
            if (this.ddlAddressDistiricts.Items != null && this.ddlAddressDistiricts.Items.Count > 0)
            {
                this.ddlAddressDistiricts.Items.Clear();
            }
            if (divisionID > 0)
            {
                this.ddlAddressDistiricts.DataSource = new GeneralDistrictBLL().GetDistrictsByDivisionID(divisionID);
                this.ddlAddressDistiricts.DataValueField = "ID";
                this.ddlAddressDistiricts.DataTextField = "Title";
                this.ddlAddressDistiricts.DataBind();
            }
            this.ddlAddressDistiricts.Items.Insert(0, new ListItem("Choose...", "0"));
        }



        private void GetGroups()
        {
            ddlGroup.Items.Clear();

            ddlGroup.DataSource = new GroupBLL().GetAllGroups().Where(p => p.Status.Value == true).OrderBy(p => p.Title).ToList();
            ddlGroup.DataValueField = "ID";
            ddlGroup.DataTextField = "Title";
            ddlGroup.DataBind();
            ddlGroup.Items.Insert(0, new ListItem("Choose...", "0"));
        }








        private void GetUsertypes()
        {
            this.ddlUserType.DataSource = new UserTypeBLL().GetAllUsersType().OrderBy(p => p.Title).ToList();
            this.ddlUserType.DataTextField = "Title";
            this.ddlUserType.DataValueField = "ID";
            this.ddlUserType.DataBind();
        }


        private void PopulateFeaturesMngtMenus()
        {
            this.chkFeatures.DataSource = new MenuBLL().GetAppFeatures(2); ;
            this.chkFeatures.DataTextField = "Name";
            this.chkFeatures.DataValueField = "ID";
            this.chkFeatures.DataBind();
            // this.chkFeatures.Items.Insert(0, new ListItem("Select All", "0"));
        }


        private void PopulateUsers()
        {
            try
            {

                List<UserModelView> Users = new UserBLL().GetUsers(Convert.ToInt32(ddlDistrict.SelectedValue), PageNumber, PageSize, out TotalRecords, ddlSearchBy.SelectedValue, txtSearch.Text.Trim());

                //                TotalRecords = Record;
                PageCount = Convert.ToInt32(Math.Ceiling((decimal)TotalRecords / PageSize));
                ViewState["PageCount"] = PageCount;

                if (Users != null)
                {
                    rptUsers.DataSource = Users;
                    rptUsers.DataBind();

                    pnlUserNoFound.Visible = false;
                }
                else
                {
                    if (PageNumber > 0)
                    {
                        PageNumber = PageNumber - 1;
                        PopulateUsers();
                    }
                    else
                    {
                        rptUsers.DataSource = null;
                        rptUsers.DataBind();
                        pnlUserNoFound.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                //new Common().AddErrorLog(new ErrorLogModel(ex, "PopulateUsers", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                //lblError.Text = ex.Message;
                //pnlError.Visible = true;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "PopulateUsers", 1, PageNames.Users, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                    pnlError.Visible = true;

                }
                else
                {
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;

                }
            }
        }

        /// <summary>
        /// Get provide login claim information
        /// </summary>
        /// <param name="login"></param>
        /// <returns></returns>
        private static string GetLoginClaim(string login)
        {
            string userName = login;
            /*  SPClaimProviderManager mgr = SPClaimProviderManager.Local;
              if (mgr == null) return userName;

              // comment by hammad => use to claim against window user
              //SPClaim claim = new SPClaim(SPClaimTypes.IdentityProvider, login, "http://www.w3.org/2001/XMLSchema#string", SPOriginalIssuers.Format(SPOriginalIssuerType.Windows));

              string FBAMembershipProvider = ConfigurationManager.AppSettings["FBAMembership"];
              SPClaim claim = new SPClaim(SPClaimTypes.UserLogonName, login, "http://www.w3.org/2001/XMLSchema#string", SPOriginalIssuers.Format(SPOriginalIssuerType.Forms, FBAMembershipProvider));
              userName = mgr.EncodeClaim(claim);
             */
            return userName;
        }

        private void PopulateEditPanel(int UserID)
        {
            try
            {
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();

                ds = new UserBLL().GetUserByID(UserID);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt = ds.Tables[0];
                    dtpResigned.Disabled = false;
                    ddlDepartment.SelectedValue = dt.Rows[0]["DepartmentID"].ToString();
                    if (ddlDistrict.Items != null)
                    {
                        ListItem item = ddlDistrict.Items.FindByValue(dt.Rows[0]["DistrictID"].ToString());
                        if (item != null && Convert.ToInt32(item.Value) > 0)
                            ddlDistrict.SelectedValue = item.Value;
                    }


                    txtCNIC.Text = dt.Rows[0]["CNIC"].ToString();
                    txtEmployeeName.Text = dt.Rows[0]["EmployeeName"].ToString();

                    //Address Information

                    if (dt.Columns.Contains("AddressDivisionID") && !Convert.IsDBNull(dt.Rows[0]["AddressDivisionID"]))
                    {
                        int ID = Convert.ToInt32(dt.Rows[0]["AddressDivisionID"]);
                        this.ddlAddressDivisions.SelectedValue = ID.ToString();
                        this.GetAddressDistricts(ID);
                    }

                    if (dt.Columns.Contains("AddressDistrictID") && !Convert.IsDBNull(dt.Rows[0]["AddressDistrictID"]))
                    {
                        int ID = Convert.ToInt32(dt.Rows[0]["AddressDistrictID"]);
                        this.ddlAddressDistiricts.SelectedValue = ID.ToString();
                        // this.GetAddressTehsil(ID);
                    }



                    if (dt.Columns.Contains("FullAddress") && !Convert.IsDBNull(dt.Rows[0]["FullAddress"]))
                    {
                        this.txtFullAddress.Text = Convert.ToString(dt.Rows[0]["FullAddress"]);
                    }


                    // added against CR:007
                    txtEmail.Text = dt.Rows[0]["EMail"].ToString();
                    txtCell.Text = dt.Rows[0]["CellNumber"].ToString();

                    ddlGroup.SelectedValue = dt.Rows[0]["PermitGroupID"].ToString();
                    ddlUserType.SelectedValue = dt.Rows[0]["UserTypeID"].ToString();


                    cbxStatus.Checked = Convert.ToBoolean(dt.Rows[0]["IsActive"].ToString());


                    txtBlockReason.Text = dt.Rows[0]["InActiveReason"].ToString();
                    if (!Convert.IsDBNull(dt.Rows[0]["JoiningDate"]))
                        this.dtpJoined.Value = Convert.ToDateTime(dt.Rows[0]["JoiningDate"]).ToString("dd/MM/yyyy");
                    if (!Convert.IsDBNull(dt.Rows[0]["ResignedDate"]))
                        this.dtpResigned.Value = Convert.ToDateTime(dt.Rows[0]["ResignedDate"]).ToString("dd/MM/yyyy");
                    this.chkEnforceRight.Checked = Convert.ToBoolean(dt.Rows[0]["IsEnforceRight"].ToString());
                    this.chkPremesis.Checked = Convert.ToBoolean(dt.Rows[0]["IsWithinPremesis"].ToString());
                    txtLoginName.Text = dt.Rows[0]["UserName"].ToString();
                    //// set user login name
                    //txtLoginName.Text = dt.Rows[0]["UserName"].ToString();
                    //cppLogin.Visible = false;
                    //txtLoginName.Visible = true;

                    // set serice rights

                    this.cblUserRights.Items[UserRightName.FileAdd.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileAdd"]);
                    this.cblUserRights.Items[UserRightName.FileView.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileView"]);
                    this.cblUserRights.Items[UserRightName.FileRemove.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileRemove"]);
                    this.cblUserRights.Items[UserRightName.FileDownload.GetHashCode()].Selected = Convert.ToBoolean(dt.Rows[0]["FileDownload"]);

                    this.FillUserDistricts(UserID);

                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        foreach (DataRow dr1 in ds.Tables[1].Rows)
                        {
                            chkFeatures.Items.FindByValue(dr1["FeatureID"].ToString()).Selected = true;
                        }
                    }


                    this.SetAllDistirctsVisibility();

                    try
                    {
                        //  string _userName = GetLoginClaim(dt.Rows[0]["UserName"].ToString());
                        //  SPUser user = SPContext.Current.Web.EnsureUser(_userName);

                        //  peUserLogin.CommaSeparatedAccounts = user.LoginName;
                        //  peUserLogin.Enabled = false;
                    }
                    catch (Exception ex)
                    {
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('user name not found in active directory server. Please contact your administrator.');", true);
                    }
                }
            }
            catch (Exception ex)
            {

                //new Common().AddErrorLog(new ErrorLogModel(ex, "PopulateEditPanel", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                //lblError.Text = ex.Message;
                //pnlError.Visible = true;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "PopulateEditPanel", 1, PageNames.Users, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                    pnlError.Visible = true;

                }
                else
                {
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;

                }
            }
        }

        private void FillUserDistricts(int userID)
        {
            DataTable dtUserDistrict = new DataTable();
            dtUserDistrict = new UserBLL().GetDistirctByUserID(userID);

            this.ClearChecked(this.cblAllDistricts);
            foreach (DataRow dr in dtUserDistrict.Rows)
            {
                foreach (ListItem item in this.cblAllDistricts.Items)
                {
                    if (item.Value == dr["DistrictID"].ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }




        private void SetSeltectedCSRManagement(DataTable dtStatuses, CheckBoxList chklStatues)
        {
            this.ClearChecked(chklStatues);
            foreach (DataRow dr in dtStatuses.Rows)
            {
                foreach (ListItem item in chklStatues.Items)
                {
                    if (item.Value == dr["AppFeatureID"].ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }




        /// <summary>
        /// Verify login name is selects in people picker
        /// </summary>
        /// <returns></returns>
        private bool ValidatePeoplePicker()
        {
            /*
            if (Page.IsValid)
            {
                if (peUserLogin.CommaSeparatedAccounts == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Select user login name');", true);
                    peUserLogin.Focus();
                    return false;
                }
                else
                {
                    if (peUserLogin.CommaSeparatedAccounts.Contains("\\"))
                    {
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Invalid user selection');", true);
                    }
                }
            }
             */


            return true;
        }

        /// <summary>
        /// check select login Name transactions
        /// </summary>
        /// <param name="LoginName"></param>
        /// <returns></returns>
        private bool ValidateDependanceReocrd(string LoginName)
        {
            //// check data existing against user in sharepoint library
            //using (SPSite site = new SPSite(SPContext.Current.Site.ID))
            //{
            //    using (SPWeb web = site.OpenWeb(SPContext.Current.Web.ID))
            //    {
            //        DataTable dt = new UserBLL().GetUserByLogin(LoginName, Convert.ToInt32(cultureID));
            //        if (dt.Rows.Count > 0)
            //        {
            //            SPList lstTrack = web.Lists[dt.Rows[0]["DepartmentName"].ToString() + " Tasks Track"];
            //            SPQuery query = new SPQuery();
            //            SPUser user = web.EnsureUser(LoginName);

            //            query.Query = "<Where>" +
            //                            "<Eq><FieldRef Name='AssignedFrom' /><Value Type='User'>" + user.Name + "</Value></Eq>" +
            //                        "</Where>";
            //            query.RowLimit = 1;
            //            SPListItemCollection lstItems = lstTrack.GetItems(query);
            //            if (lstItems.Count > 0)
            //            {
            //                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.warning('" + new Common().GetResourceString("RecodDependance", cultureID) + "');", true);
            //                return false;
            //            }

            //            query = new SPQuery();
            //            query.Query = "<Where>" +
            //                            "<Eq><FieldRef Name='AssignedTo' /><Value Type='User'>" + user.Name + "</Value></Eq>" +
            //                        "</Where>";
            //            query.RowLimit = 1;

            //            lstItems = lstTrack.GetItems(query);
            //            if (lstItems.Count > 0)
            //            {
            //                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.warning('" + new Common().GetResourceString("RecodDependance", cultureID) + "');", true);
            //                return false;
            //            }
            //        }
            //    }
            //}

            return true;
        }

        private void ResetControls()
        {
            ddlDepartment.SelectedIndex = 0;
            ddlDistrict.SelectedIndex = 0;
            ddlUserType.SelectedIndex = 0;
            txtCNIC.Text = "";
            txtEmployeeName.Text = "";
            txtEmail.Text = "";
            txtCell.Text = "";
            ddlGroup.SelectedIndex = 0;
            txtLoginName.Text = string.Empty;
            cbxStatus.Checked = true;
            txtBlockReason.Text = "";
            ddlDepartment.Focus();
            ViewState["UserID"] = "";
            ViewState["Edit"] = "No";
            this.dtpJoined.Value = null;
            this.dtpResigned.Value = null;
            dtpResigned.Disabled = true;
            this.chkEnforceRight.Checked = false;
            this.chkPremesis.Checked = false;
            this.ddlAddressDivisions.SelectedIndex = 0;
            this.ddlAddressDistiricts.SelectedIndex = 0;
            this.txtFullAddress.Text = string.Empty;
            this.ClearChecked(this.cblAllDistricts);
            this.ClearChecked(this.cblUserRights);
            this.txtPassword.Text = string.Empty;
            this.txtConfirmPassword.Text = string.Empty;
            this.SetAllDistirctsVisibility();
        }








        protected void ClearChecked(CheckBoxList chklStatues)
        {

            foreach (ListItem item in chklStatues.Items)
            {
                item.Selected = false;
            }

        }

        /// <summary>
        /// Get selected login window base login claim
        /// </summary>
        /// <remarks>CR:010</remarks>
        /// <returns></returns>
        private string GetLoginWindowsBaseClaim()
        {
            /*
            string login = peUserLogin.CommaSeparatedAccounts;
            if (ConfigurationManager.AppSettings["SignInMethod"].ToString() == "Form")
                login = login.Split('|')[2].ToString();
            else
                login = login.ToString().Substring(login.ToString().LastIndexOf(@"\") + 1, login.ToString().Length - (login.ToString().LastIndexOf(@"\") + 1));

            string userName = login;
            SPClaimProviderManager mgr = SPClaimProviderManager.Local;
            if (mgr == null) return userName;

            SPClaim claim = new SPClaim(SPClaimTypes.UserLogonName, login, "http://www.w3.org/2001/XMLSchema#string", SPOriginalIssuers.Format(SPOriginalIssuerType.Windows));
            userName = mgr.EncodeClaim(claim);

            return userName;
             */
            return null;
        }

        /// <summary>
        /// Add provided user login to sharepoint collections
        /// <remarks>CR:010</remarks>
        /// </summary>
        /*
        private bool SaveToSharePointCollection()
        {
            try
            {
                SPGroup groups;
                DataTable dtUser = Common.GetSessionUserTable();

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    #region "Primary Site Collection"

                    using (SPSite site = new SPSite(SPContext.Current.Site.ID))
                    {
                        site.AllowUnsafeUpdates = true;

                        using (SPWeb web = site.OpenWeb(SPContext.Current.Web.ID))
                        {
                            #region "Grant Permission"

                            web.AllowUnsafeUpdates = true;

                            // assign administrator role on user to add, edit or update
                            SPUser user = SPContext.Current.Web.CurrentUser;
                            SPRoleDefinition roleDef = web.RoleDefinitions.GetByType(SPRoleType.Administrator);

                            if (!web.HasUniqueRoleAssignments)
                            {
                                web.BreakRoleInheritance(true);
                            }

                            SPRoleAssignment spRoleAssignment = new SPRoleAssignment(user);
                            spRoleAssignment.RoleDefinitionBindings.Add(roleDef);
                            web.RoleAssignments.Add(spRoleAssignment);

                            #endregion

                            try
                            {
                                //check group exist if not add new group
                                if (isGroupAlreadyExist(web, ddlGroup.SelectedItem.Text) == false)
                                {
                                    web.SiteGroups.Add(ddlGroup.SelectedItem.Text, web.CurrentUser, web.CurrentUser, "Use this group to grant read permission on application having role of " + ddlGroup.SelectedItem.Text);

                                    //some permissions to group
                                    groups = web.SiteGroups[ddlGroup.SelectedItem.Text];
                                    SPRoleDefinition roleDefinition = web.RoleDefinitions.GetByType(SPRoleType.Reader);
                                    SPRoleAssignment roleAssigment = new SPRoleAssignment(groups);
                                    roleAssigment.RoleDefinitionBindings.Add(roleDefinition);
                                    web.RoleAssignments.Add(roleAssigment);
                                    web.Update();
                                }
                                else
                                    groups = web.Groups[ddlGroup.SelectedItem.Text];

                                // verify user exists in site collection
                                SPUser peoplePickerUser = null;
                                try
                                {
                                    peoplePickerUser = groups.Users[peUserLogin.CommaSeparatedAccounts];
                                }
                                catch
                                {
                                    peoplePickerUser = null;
                                }

                                //Add user into user site collection
                                if (peoplePickerUser == null)
                                {
                                    //add user to group
                                    groups.Users.Add(peUserLogin.CommaSeparatedAccounts, string.Empty, txtEmployeeName.Text, string.Empty);
                                    groups.Update();
                                }
                                else
                                {
                                    //update site user title in user information list
                                    SPUser profile = web.SiteUsers[peUserLogin.CommaSeparatedAccounts];
                                    profile.Name = txtEmployeeName.Text;
                                    profile.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                            finally
                            {
                                #region "Remove Permission"

                                // remove administrator role from user
                                roleDef = web.RoleDefinitions.GetByType(SPRoleType.Reader);

                                if (!web.HasUniqueRoleAssignments)
                                {
                                    web.BreakRoleInheritance(true);
                                }

                                spRoleAssignment = new SPRoleAssignment(user);
                                spRoleAssignment.RoleDefinitionBindings.Remove(roleDef);
                                web.RoleAssignments.Remove(user);

                                web.AllowUnsafeUpdates = false;

                                #endregion
                            }
                        }

                        site.AllowUnsafeUpdates = false;
                    }

                    #endregion

                    //ConfigurationManager.AppSettings["EnableServiceRelatedDocumentCenter"].ToString()
                    if (ddlFCDistricts.SelectedIndex != 0)
                    {
                        DistrictModel fcDistrict = new DistrictBLL().GetDistrictByID(Convert.ToInt32(ddlFCDistricts.SelectedValue));

                        // ====================================================================================================================================== //
                        // ==================================== check common document's document center is enable =============================================== //
                        if (fcDistrict.EnableCommonDocumentCenter)                        //ConfigurationManager.AppSettings["EnableDocumentCenter"].ToString()
                        {
                            #region "Common Documents"

                            //ConfigurationManager.AppSettings["DocumentCenterURL"].ToString()
                            using (SPSite site = new SPSite(fcDistrict.CommonDocumentCenterURL))
                            {
                                site.AllowUnsafeUpdates = true;

                                using (SPWeb web = site.OpenWeb())
                                {
                                    web.AllowUnsafeUpdates = true;

                                    groups = web.Groups["e-Khidmat Center"];        //get sharepoint group wehere user add
                                    SPUser user = null;
                                    string LoginName = GetLoginWindowsBaseClaim();             // get sharepoint claim token
                                    LoginName = web.EnsureUser(LoginName).LoginName;

                                    try
                                    {
                                        user = groups.Users[LoginName];
                                    }
                                    catch
                                    { }

                                    if (user == null)       //Add user into user site collection
                                    {
                                        //add user to group
                                        groups.Users.Add(LoginName, string.Empty, txtEmployeeName.Text, string.Empty);
                                        groups.Update();
                                    }
                                    else
                                    {
                                        SPUser profile = web.SiteUsers[user.LoginName];
                                        profile.Name = txtEmployeeName.Text;
                                        profile.Update();
                                    }

                                    web.AllowUnsafeUpdates = false;

                                }

                                site.AllowUnsafeUpdates = false;
                            }

                            #endregion
                            
                        }

                        // ====================================================================================================================================== //
                        // ============================= check service related document's document center is enable - CR:011 ==================================== //
                        if (fcDistrict.EnableServiceDocumentCenter)
                        {
                            #region "Document Center - Service Related Documents"
                            //ConfigurationManager.AppSettings["ServiceRelatedDocumentCenterURL"].ToString()
                            using (SPSite site = new SPSite(fcDistrict.ServiceDocumentCenterURL))
                            {
                                site.AllowUnsafeUpdates = true;

                                using (SPWeb web = site.OpenWeb())
                                {
                                    web.AllowUnsafeUpdates = true;

                                    groups = web.Groups["e-Khidmat Center"];        //get sharepoint group wehere user add
                                    SPUser user = null;
                                    string LoginName = GetLoginWindowsBaseClaim();             // get sharepoint claim token
                                    LoginName = web.EnsureUser(LoginName).LoginName;

                                    try
                                    {
                                        user = groups.Users[LoginName];
                                    }
                                    catch
                                    { }

                                    if (user == null)       //Add user into user site collection
                                    {
                                        //add user to group
                                        groups.Users.Add(LoginName, string.Empty, txtEmployeeName.Text, string.Empty);
                                        groups.Update();
                                    }
                                    else
                                    {
                                        SPUser profile = web.SiteUsers[user.LoginName];
                                        profile.Name = txtEmployeeName.Text;
                                        profile.Update();
                                    }

                                    web.AllowUnsafeUpdates = false;

                                }

                                site.AllowUnsafeUpdates = false;
                            }

                            #endregion
                        }
                    }
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }
        */
        #endregion

        #region "Dropdown Events"

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {

            PopulateUsers();
            ddlDistrict.Focus();
            if (this.ddlDistrict.SelectedValue != null && Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0)
            {
                this.GetAllDistris();

            }
            this.SetAllDistirctsVisibility();
        }

        private void SetAllDistirctsVisibility()
        {

            this.divAllDistricts.Visible = ((this.ddlUserType.SelectedValue == null || this.ddlUserType.SelectedValue != PITB.PFSA.BE.CustomEnums.UserTypeNames.CSR.GetHashCode().ToString()) && (this.ddlDistrict.SelectedValue == null || Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0)) ? true : false;
        }
        protected void ddlUserType_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.SetAllDistirctsVisibility();
        }



        /// <summary>
        /// dropdown Change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>


        protected void ddlAddressDivisions_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.GetAddressDistricts(Convert.ToInt32(this.ddlAddressDivisions.SelectedValue));
            this.ddlAddressDivisions.Focus();

        }



        #endregion

        #region "CheckBox Events"

        protected void cbxStatus_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxStatus.Checked == true)
                pnlBlockReason.Visible = false;
            else
                pnlBlockReason.Visible = true;
        }

        #endregion

        #region "Set Paging Method"

        private void SetPagingControl(RepeaterItemEventArgs e)
        {
            try
            {
                DataRowView rptRow = (DataRowView)e.Item.DataItem;
                DataTable dt = new DataTable();
                dt.Columns.Add("Value");

                //Display only PageNumber upto PagingSize            
                if ((PageStart + (PagingSize - 1)) <= PageCount)
                {
                    for (int i = PageStart; i <= PageStart + (PagingSize - 1); i++)
                        dt.Rows.Add(i);
                }
                else
                {
                    for (int i = PageStart; i <= PageCount; i++)
                        dt.Rows.Add(i);
                }

                Repeater rptPaging = (Repeater)e.Item.FindControl("rptPaging");
                rptPaging.DataSource = dt;
                rptPaging.DataBind();

                if (PageNumber == 0 || PageStart == 1)
                    ((LinkButton)e.Item.FindControl("lbtnPrevious")).Enabled = false;


                if (PageNumber == PageCount - 1 || (PageStart + PagingSize - 1) > PageCount)
                    ((LinkButton)e.Item.FindControl("lbtnNext")).Enabled = false;

                Label lbl = (Label)e.Item.FindControl("lblDisplayingRecords");
                if (TotalRecords != 0)
                {
                    if (TotalRecords > (PageNumber * PageSize + PageSize))
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + (PageNumber * PageSize + PageSize) + " of " + TotalRecords + " records";
                    else
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + TotalRecords + " of " + TotalRecords + " records";
                }
                else
                {
                    lbl.Text = "Showing 0 to 0 of 0 records";
                }
            }
            catch (Exception ex)
            {
                //new Common().AddErrorLog(ex, "SetPagingControl", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.Users);
                //new Common().AddErrorLog(new ErrorLogModel(ex, "SetPagingControl", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                //lblError.Text = ex.Message;
                //pnlError.Visible = true;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SetPagingControl", 1, PageNames.Users, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                    pnlError.Visible = true;

                }
                else
                {
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;

                }
            }
        }

        #endregion

        #region "Repeator Events"

        protected void rptUsers_ItemCreated(object sender, RepeaterItemEventArgs e)
        {

            try
            {
                if (e.Item.ItemType == ListItemType.Footer)
                {
                    Repeater rptPaging = (Repeater)e.Item.FindControl("rptPaging");
                    rptPaging.ItemCommand += new RepeaterCommandEventHandler(rptPaging_ItemCommand);
                    rptPaging.ItemDataBound += new RepeaterItemEventHandler(rptPaging_ItemDataBound);
                }
            }
            catch (Exception ex)
            {

                //new Common().AddErrorLog(new ErrorLogModel(ex, "rptUsers_ItemCreated", 0, PageNames.Users, CurrentUser.GetSessionUserInfo()));

                //lblError.Text = ex.Message;
                //pnlError.Visible = true;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "rptUsers_ItemCreated", 1, PageNames.Users, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                    pnlError.Visible = true;

                }
                else
                {
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;

                }
            }
        }

        protected void rptUsers_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                try
                {
                    UserModelView model = (UserModelView)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnUserID")).Value = model.UserID.ToString();
                    ((Label)e.Item.FindControl("lblLoginName")).Text = model.UserName;
                    ((Label)e.Item.FindControl("lblEmployeeName")).Text = model.EmployeeName;
                    ((Label)e.Item.FindControl("lblCNIC")).Text = model.CNIC;
                    ((Label)e.Item.FindControl("lblDistrict")).Text = model.District;

                    if (model.IsActive)
                    {
                        ((Label)e.Item.FindControl("lblActive")).CssClass = "label label-success label-mini";
                        ((Label)e.Item.FindControl("lblActive")).Text = "<i class='fa fa-check'></i>";
                        ((Label)e.Item.FindControl("lblActive")).ToolTip = "Active";
                    }
                    else
                    {
                        ((Label)e.Item.FindControl("lblActive")).CssClass = "label label-important label-mini";
                        ((Label)e.Item.FindControl("lblActive")).Text = "<i class='fa fa-times'></i>";
                        ((Label)e.Item.FindControl("lblActive")).ToolTip = "Block";
                    }

                    LinkButton lbtnDelete = (LinkButton)e.Item.FindControl("lbtnDelete");
                    lbtnDelete.Attributes.Add("onclick", "if ( ! confirm('Do you want to delete this record?')) return false;");
                }
                catch (Exception ex)
                {
                    //new Common().AddErrorLog(ex, "rptUsers_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.Users);
                    //new Common().AddErrorLog(new ErrorLogModel(ex, "rptUsers_ItemDataBound", 0, PageNames.Users, CurrentUser.LoginID));
                    //lblError.Text = ex.Message;
                    //pnlError.Visible = true;

                    string errorCode = string.Empty;
                    errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "rptUsers_ItemDataBound", 1, PageNames.Users, CurrentUser.GetSessionUserInfo())).ToString();
                    if (ConfigurationHelper.IsShowGeneralMsg)
                    {
                        lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                        pnlError.Visible = true;

                    }
                    else
                    {
                        lblError.Text = ex.Message;
                        pnlError.Visible = true;

                    }
                }
            }
            else if (e.Item.ItemType == ListItemType.Footer)
            {
                this.SetPagingControl(e);
            }
        }

        protected void rptUsers_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                txtPassword.CssClass = txtPassword.CssClass.Replace("validate[required]", "");
                txtConfirmPassword.CssClass = txtConfirmPassword.CssClass.Replace("validate[required]", "");
                string strUserID = ((HiddenField)e.Item.FindControl("hdnUserID")).Value;
                ViewState["UserID"] = strUserID;
                ViewState["Edit"] = "Yes";
                //lbtnSave.Text = "<i class='fa fa-check'></i>&nbsp;Update";

                this.PopulateEditPanel(Convert.ToInt32(strUserID));

            }
            else if (e.CommandName == "Delete")
            {
                try
                {
                    string strUserID = ((HiddenField)e.Item.FindControl("hdnUserID")).Value;
                    string LoginName = ((Label)e.Item.FindControl("lblLoginName")).Text;
                    ViewState["UserID"] = strUserID;

                    //verify record depanded records
                    if (ValidateDependanceReocrd(LoginName))
                    {
                        //  string currentUserlogin = SPContext.Current.Web.CurrentUser.LoginName;
                        // currentUserlogin = currentUserlogin.ToString().Substring(currentUserlogin.ToString().LastIndexOf(@"\") + 1, currentUserlogin.ToString().Length - (currentUserlogin.ToString().LastIndexOf(@"\") + 1));

                        int result = new UserBLL().Delete(Convert.ToInt32(ViewState["UserID"]));
                        if (result > 0)
                        {
                            ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Record deleted successfully');", true);
                            ResetControls();
                            PopulateUsers();
                        }
                    }
                }
                catch (Exception ex)
                {
                    //new Common().AddErrorLog(new ErrorLogModel(ex, "rptUsers_DeleteCommand", 1, PageNames.Users, CurrentUser.GetSessionUserInfo()));
                    //lblError.Text = ex.Message;
                    //pnlError.Visible = true;

                    string errorCode = string.Empty;
                    errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "rptUsers_DeleteCommand", 1, PageNames.Users, CurrentUser.GetSessionUserInfo())).ToString();
                    if (ConfigurationHelper.IsShowGeneralMsg)
                    {
                        lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                        pnlError.Visible = true;

                    }
                    else
                    {
                        lblError.Text = ex.Message;
                        pnlError.Visible = true;

                    }
                }
            }
            else if (e.CommandName == "Next")
            {
                if ((PageStart + PagingSize) <= PageCount)
                {
                    PageStart += PagingSize;
                    PageNumber = PageStart - 1;
                }

                PopulateUsers();
            }

            else if (e.CommandName == "Previous")
            {
                if ((PageStart - PagingSize) >= 1)
                {
                    PageStart -= PagingSize;
                    PageNumber = PageStart - 1;
                }

                PopulateUsers();
            }
        }



        #endregion

        #region "Paging Repeator Events"

        protected void rptPaging_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            LinkButton lbtnPageNumber = null;
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                lbtnPageNumber = (LinkButton)e.Item.FindControl("lbtnPageNumber");

                if (e.Item.ItemIndex == (PageNumber % PagingSize))
                {
                    ((HtmlGenericControl)e.Item.FindControl("liPageNo")).Attributes.Add("class", "active");
                }
                else
                {
                    ((HtmlGenericControl)e.Item.FindControl("liPageNo")).Attributes.Add("class", "");
                }

                lbtnPageNumber.Text = lbtnPageNumber.Text;
            }
            else if (e.Item.ItemType == ListItemType.Header)
            {
                if (PageNumber == 0 || PageStart == 1)
                {
                    ((LinkButton)e.Item.FindControl("lbtnPrevious")).Enabled = false;
                }
            }
            else if (e.Item.ItemType == ListItemType.Footer)
            {
                if (PageNumber == PageCount - 1 || (PageStart + PagingSize - 1) > PageCount)
                {
                    ((LinkButton)e.Item.FindControl("IbtnNext")).Enabled = false;
                }
            }
        }

        protected void rptPaging_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            if (e.CommandName == "PageNumber")
            {
                PageNumber = Convert.ToInt32(((LinkButton)e.Item.FindControl("lbtnPageNumber")).Text) - 1;
                PopulateUsers();
            }
        }

        #endregion

        #region "Button Click Events"

        private DataTable GetFeaturesMngntPermittedMenu(CheckBoxList chklst)
        {
            DataRow dr;
            DataTable dt = new DataTable();
            dt.Columns.Add("GroupID", typeof(string));
            dt.Columns.Add("AppFeatureID", typeof(string));
            dt.Columns.Add("AppObjectID", typeof(string));

            foreach (ListItem litem in chklst.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dt.NewRow();
                    dr["GroupID"] = 0;
                    dr["AppFeatureID"] = litem.Value;
                    dr["AppObjectID"] = 0;
                    dt.Rows.Add(dr);
                }
            }

            return dt;

        }


        protected void lbtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // validate user input
                if (!ValidatePeoplePicker()) return;
                if (ViewState["Edit"].ToString() != "Yes")  // add new record
                {
                    string login = txtLoginName.Text;// peUserLogin.CommaSeparatedAccounts;
                    // login = login.Split('|')[2].ToString();

                    //varify user name exist in database

                   

                    DateTime? dtJoine = null;
                    if (!string.IsNullOrEmpty(this.dtpJoined.Value))
                    {
                        string[] dateInfo = this.dtpJoined.Value.Split('/');
                        dtJoine = Convert.ToDateTime(dateInfo[1] + "/" + dateInfo[0] + "/" + dateInfo[2]);
                    }


                    UserRegistration user = new UserRegistration();
                    user.EnforceRight = this.chkEnforceRight.Checked;
                    user.JoinDate = dtJoine;
                    user.BlockReason = txtBlockReason.Text;
                    user.Status = cbxStatus.Checked;
                    user.WithinPremesis = chkPremesis.Checked;

                    user.UserTypeID = Convert.ToInt32(ddlUserType.SelectedValue);
                    user.GroupID = Convert.ToInt32(ddlGroup.SelectedValue);
                    user.CellNumber = txtCell.Text;
                    user.EMail = txtEmail.Text;
                    user.CNIC = txtCNIC.Text;
                    user.LoginName = txtLoginName.Text;

                    user.EmployeeName = txtEmployeeName.Text;
                    user.LoginName = login;
                   
                    user.GeneralDistrictID = Convert.ToInt32(ddlDistrict.SelectedValue);
                    user.DepartmentID = Convert.ToInt32(ddlDepartment.SelectedValue);
                    user.UserDistricts = this.FillUserDistricts(this.cblAllDistricts);


                    FillUserInfo(user);
                    if (IsValidUserData(user))
                    {
                        // this.SaveToSharePointCollection();
                        int result = new UserBLL().Save(user);      // CR: 009 END
                        if (result > 0)
                        {
                            ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.success('Record saved successfully.');", true);
                            ResetControls();
                            PopulateUsers();
                            ClearChecked(chkFeatures);
                        }
                    }

                } // end add new record
                else
                {

                    DateTime? dtJoine = null;
                    DateTime? dtResign = null;
                    if (!string.IsNullOrEmpty(this.dtpJoined.Value))
                    {
                        string[] dateInfo = this.dtpJoined.Value.Split('/');
                        dtJoine = Convert.ToDateTime(dateInfo[1] + "/" + dateInfo[0] + "/" + dateInfo[2]);
                    }
                    if (!string.IsNullOrEmpty(this.dtpResigned.Value))
                    {
                        string[] dateInfo = this.dtpResigned.Value.Split('/');
                        dtResign = Convert.ToDateTime(dateInfo[1] + "/" + dateInfo[0] + "/" + dateInfo[2]);
                    }

                    UserRegistration user = new UserRegistration();
                    user.EnforceRight = this.chkEnforceRight.Checked;
                    user.WithinPremesis = chkPremesis.Checked;
                    user.ResignDate = dtResign;
                    user.JoinDate = dtJoine;

                    user.BlockReason = txtBlockReason.Text;
                    user.Status = cbxStatus.Checked;
                    user.UserTypeID = Convert.ToInt32(ddlUserType.SelectedValue);
                    user.GroupID = Convert.ToInt32(ddlGroup.SelectedValue);
                    user.CellNumber = txtCell.Text;
                    user.EMail = txtEmail.Text;
                    user.CNIC = txtCNIC.Text;

                    string cnic = user.CNIC;
                    user.UserID = Convert.ToInt32(ViewState["UserID"]);

                    user.EmployeeName = txtEmployeeName.Text;
                    user.LoginName = txtLoginName.Text;

          
                    user.GeneralDistrictID = Convert.ToInt32(ddlDistrict.SelectedValue);
                    user.DepartmentID = Convert.ToInt32(ddlDepartment.SelectedValue);
                  
                    FillUserInfo(user);
                    user.UserDistricts = this.FillUserDistricts(this.cblAllDistricts);
                    if (IsValidUserData(user))
                    {
                        //this.SaveToSharePointCollection();
                        int result = new UserBLL().Update(user);
                        if (result > 0)
                        {
                            txtPassword.CssClass = "validate[required]";
                            txtConfirmPassword.CssClass = "validate[required]";
                            ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.success('Record updated successfully.');", true);
                            ResetControls();
                            PopulateUsers();
                            ClearChecked(chkFeatures);
                        }
                    }
                }
            }
            catch (BusinessException ex)
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('" + ex.ErroMessage + "');", true);
                return;
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "lbtnSave_Click", 1, PageNames.Users, CurrentUser.GetSessionUserInfo()));

                //lblError.Text = ex.Message;
                //pnlError.Visible = true;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 1, PageNames.Users, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                    pnlError.Visible = true;

                }
                else
                {
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;

                }
            }
        }



        internal void FillUserInfo(UserRegistration user)
        {
            user.CreatedBy = CurrentUser.LoginID;
            user.AddressDivisionID = Convert.ToInt32(this.ddlAddressDivisions.SelectedValue);
            user.AddressDistrictID = Convert.ToInt32(this.ddlAddressDistiricts.SelectedValue);
            user.FullAddress = this.txtFullAddress.Text;
            user.FileAdd = this.cblUserRights.Items[0].Selected;
            user.FileView = this.cblUserRights.Items[1].Selected;
            user.FileRemove = this.cblUserRights.Items[2].Selected;
            user.FileDownload = this.cblUserRights.Items[3].Selected;
            user.Password = txtPassword.Text;

            // Add Featur Table
            DataTable featureMngtRights = this.GetFeaturesMngntPermittedMenu(this.chkFeatures);
            featureMngtRights.TableName = TableName.tblAppFeatures.ToString();
            user.UserFeaturs = featureMngtRights;


        }

        protected void lbtnCancel_Click(object sender, EventArgs e)
        {
            ResetControls();
            ViewState["PageNumber"] = null;
            PopulateUsers();
        }

        protected void lbtnSearch_Click(object sender, EventArgs e)
        {
            ViewState["PageNumber"] = null;
            PopulateUsers();
        }

        protected void lbtnReload_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            ddlSearchBy.SelectedIndex = 0;
            ViewState["PageNumber"] = null;
            PopulateUsers();
        }



        #endregion

        //protected void ddlUserType_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //    DropDownList ddl = sender as DropDownList;
        //    RepeaterItem ri = ddl.NamingContainer as RepeaterItem;

        //    if (ri != null)
        //    {
        //        DataRowView dataRowView = (DataRowView)ri.DataItem;
        //        DropDownList ddlUsers = (DropDownList)ri.FindControl("ddlUsers");
        //        DropDownList ddlDistricts = (DropDownList)ri.FindControl("ddlDistricts");
        //        string ddlUserTypeID = ((DropDownList)ri.FindControl("ddlUserType")).SelectedValue;

        //        ddlUsers.Items.Clear();

        //        ddlUsers.DataSource = new UserBLL().SelectUserByTypeID(Convert.ToInt32(ddlDistricts.SelectedValue), Convert.ToInt32(ddlUserTypeID));
        //        ddlUsers.DataTextField = "EmployeeName";
        //        ddlUsers.DataValueField = "UserID";
        //        ddlUsers.DataBind();
        //        ddlUsers.Items.Insert(0, new ListItem("Choose...", "0"));

        //    }
        //}


        #region Custom Methods
        private DataTable FillUserDistricts(CheckBoxList chklStatues)
        {
            DataRow dr;
            DataTable dtUserDistricts = new DataTable();
            dtUserDistricts.Columns.Add("ID", typeof(string));
            if (string.IsNullOrEmpty(this.ddlDistrict.SelectedValue) || Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0)
                foreach (ListItem litem in chklStatues.Items)
                {
                    if (litem.Selected && litem.Value != "0")
                    {
                        dr = dtUserDistricts.NewRow();
                        dr["ID"] = litem.Value;
                        dtUserDistricts.Rows.Add(dr);
                    }
                }

            return dtUserDistricts;

        }
        private bool IsValidUserData(UserRegistration user)
        {
            if ((this.ddlDistrict.SelectedValue == null || Convert.ToInt32(this.ddlDistrict.SelectedValue) == 0) && (user.UserDistricts == null || user.UserDistricts.Rows.Count == 0))
            {
                ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "alert('Please select at least on district.');", true);
                this.ddlDistrict.Focus();
                return false;
            }
            return true;
        }
        private void BindUserRights()
        {
            this.cblUserRights.Items.Insert(0, new ListItem("File Add", "1"));
            this.cblUserRights.Items.Insert(1, new ListItem("File View", "2"));
            this.cblUserRights.Items.Insert(2, new ListItem("File Remove", "3"));
            this.cblUserRights.Items.Insert(3, new ListItem("File Download", "4"));
        }


        /// <summary>
        /// Add provided user login to sharepoint  Document Center collections
        /// 
        /// </summary>
        private bool SaveToSharePointCollection()
        {
            try
            {
                SPGroup groups;

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    #region "Common Documents"

                    using (SPSite site = new SPSite(ConfigurationManager.AppSettings["DocumentDownloadURL"].ToString()))
                    {
                        site.AllowUnsafeUpdates = true;

                        using (SPWeb web = site.OpenWeb())
                        {
                            web.AllowUnsafeUpdates = true;
                            groups = web.Groups[ConfigurationManager.AppSettings["DocumentCenterGroup"].ToString()];

                            SPUser user = null;
                            //string LoginName = GetLoginWindowsBaseClaim();             // get sharepoint claim token
                            string LoginName = txtLoginName.Text;
                            LoginName = web.EnsureUser(LoginName).LoginName;

                            try
                            {
                                user = groups.Users[LoginName];
                            }
                            catch
                            { }

                            if (user == null)       //Add user into user site collection
                            {
                                //add user to group
                                groups.Users.Add(LoginName, string.Empty, txtEmployeeName.Text, string.Empty);
                                groups.Update();
                            }
                            else
                            {
                                SPUser profile = web.SiteUsers[user.LoginName];
                                profile.Name = txtEmployeeName.Text;
                                profile.Update();
                            }

                            web.AllowUnsafeUpdates = false;

                        }

                        site.AllowUnsafeUpdates = false;
                    }

                    #endregion
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return true;
        }
        #endregion

        
    }
}