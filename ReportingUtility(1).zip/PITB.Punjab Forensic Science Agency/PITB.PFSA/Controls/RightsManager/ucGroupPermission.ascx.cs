﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.BLL.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Controls.RightsManager
{
    public partial class ucGroupPermission : System.Web.UI.UserControl
    {
        #region "Paging Variable and Paging Properties"

        int PageSize = 25;
        int PagingSize = 5;
        int TotalRecords = 0;

        public int PageNumber
        {
            get
            {
                int val = 0;
                if (ViewState["PageNumber"] != null)
                    val = Convert.ToInt32(ViewState["PageNumber"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageNumber"] = value;
                else
                    ViewState["PageNumber"] = null;
            }
        }
        public int PageStart
        {
            get
            {
                int val = 1;
                if (ViewState["PageStart"] != null)
                    val = Convert.ToInt32(ViewState["PageStart"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageStart"] = value;
                else
                    ViewState["PageStart"] = null;
            }
        }
        public int PageCount
        {
            get
            {
                int val = 1;
                //if (this.hidPageCount.Value != string.Empty)
                //    val = Convert.ToInt32(this.hidPageCount.Value);
                return val;
            }
            set
            {
                //if (value >= 1)
                //{
                //    this.hidPageCount.Value = value.ToString();
                //}

            }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            pnlError.Visible = false;

            if (!IsPostBack)
            {
                try
                {

                    GetGroups();
                    PopulateMenu();
                    BindUserRights();
                    PopulateFeaturesMngtMenus();

                }
                catch (Exception ex)
                {
                    //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo()));
                    //lblError.Text = ex.Message;
                    //pnlError.Visible = true;

                    string errorCode = string.Empty;
                    errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Page_Load", 1, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo())).ToString();
                    if (ConfigurationHelper.IsShowGeneralMsg)
                    {
                        lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                        pnlError.Visible = true;

                    }
                    else
                    {
                        lblError.Text = ex.Message;
                        pnlError.Visible = true;

                    }
                }
            }
        }

        #region "Methods"

        /// <summary>
        /// Bind the Group Control with Database Info
        /// </summary>
        private void GetGroups()
        {

            drpGroup.Items.Clear();
            drpGroup.DataSource = new GroupBLL().GetAllGroups().Where(p => p.Status.Value == true).OrderBy (p=>p.Title ).ToList();
            drpGroup.DataValueField = "ID";
            drpGroup.DataTextField = "Title";
            drpGroup.DataBind();
            drpGroup.Items.Insert(0, new ListItem("Select Group", "0"));
        }


        private void PopulateFeaturesMngtMenus()
        {
            this.chkFeatures.DataSource = new MenuBLL().GetAppFeatures(2); ;
            this.chkFeatures.DataTextField = "Name";
            this.chkFeatures.DataValueField = "ID";
            this.chkFeatures.DataBind();
           // this.chkFeatures.Items.Insert(0, new ListItem("Select All", "0"));
        }



        /// <summary>
        /// Bind the Menu Feature Repeater with Current Menu Data
        /// </summary>
        private void PopulateMenu()
        {

            try
            {

                List<ApplicationFeaturesModel> appFeatures = new MenuBLL().GetAppFeatures(1);
                rptFeature.DataSource = appFeatures;
                rptFeature.DataBind();
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "PopulateMenu", 0, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo()));
                throw ex;
            }
        }

        private void SetChecked(DataTable dtStatuses, CheckBoxList chklStatues)
        {
            this.ClearChecked(chklStatues);
            foreach (DataRow dr in dtStatuses.Rows)
            {
                foreach (ListItem item in chklStatues.Items)
                {
                    if (item.Value == dr["FeatureID"].ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }

        private void SetChecked(DataTable dt, CheckBoxList chklStatues, string fieldName)
        {
            this.ClearChecked(chklStatues);
            if (dt != null)
                foreach (DataRow dr in dt.Rows)
                {
                    foreach (ListItem item in chklStatues.Items)
                    {
                        if (item.Value == dr[fieldName].ToString())
                        {
                            item.Selected = true;
                            break;
                        }
                    }
                }
        }
        private DataTable GetCSRPermittedMenu(CheckBoxList chklStatues)
        {
            DataRow dr;
            DataTable dt = new DataTable();
            dt.Columns.Add("GroupID", typeof(string));
            dt.Columns.Add("AppFeatureID", typeof(string));
            dt.Columns.Add("AppObjectID", typeof(string));

            foreach (ListItem litem in chklStatues.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dt.NewRow();
                    dr["GroupID"] = 0;
                    dr["AppFeatureID"] = litem.Value;
                    dr["AppObjectID"] = 0;
                    dt.Rows.Add(dr);
                }
            }

            return dt;

        }
        private DataTable GetGroupRightTable(CheckBoxList chklStatues)
        {


            DataRow dr;

            DataTable dt = GetGroupRightTable();

            foreach (ListItem litem in chklStatues.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dt.NewRow();
                    dr["ID"] = litem.Value;
                    dr["IsActive"] = litem.Selected ? 1 : 0;
                    dt.Rows.Add(dr);
                }
            }

            return dt;
        }


        private static DataTable GetGroupRightTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("IsActive", typeof(int));
            return dt;
        }
        protected void ClearChecked(CheckBoxList chklist)
        {

            foreach (ListItem item in chklist.Items)
            {

                item.Selected = false;

            }

        }


        #endregion

        #region "Dropdown Events"

        private void BindUserRights()
        {
            this.cblUserRights.Items.Clear();
            this.cblUserRights.Items.Insert(0, new ListItem("File Add", "1"));
            this.cblUserRights.Items.Insert(1, new ListItem("File View", "2"));
            this.cblUserRights.Items.Insert(2, new ListItem("File Remove", "3"));
            this.cblUserRights.Items.Insert(3, new ListItem("File Download", "4"));
        }

        /// <summary>
        /// Thsi event Bind the Menu Selected Info of Current Group
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void drpGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PopulateMenu();
                // this.ClearChecked(this.chkFeatures);
                // this.Reset();
                DataSet ds = new GroupBLL().GetGroupRights(Convert.ToInt32(drpGroup.SelectedValue));
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ds.Tables[0].DefaultView.Sort = "Sort";
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        foreach (RepeaterItem Item in rptFeature.Items)
                        {
                            CheckBox chkSelectFeature = (CheckBox)Item.FindControl("chkSelectFeature");
                            HiddenField hdnFeatureID = (HiddenField)Item.FindControl("hdnFeatureID");
                            Repeater rptObject = (Repeater)Item.FindControl("rptObject");

                            if (Convert.ToInt32(hdnFeatureID.Value) == Convert.ToInt32(dr["FeatureID"].ToString()))
                            {
                                chkSelectFeature.Checked = true;

                                //Get Feature Object against Group
                                DataRow[] drObjects = ds.Tables[1].Select("AppFeatureID = " + dr["FeatureID"].ToString() );
                                if (drObjects.Length > 0)
                                {
                                    foreach (DataRow drObject in drObjects)
                                    {
                                        foreach (RepeaterItem oItem in rptObject.Items)
                                        {
                                            CheckBox chkSelectObject = (CheckBox)oItem.FindControl("chkSelectObject");
                                            HiddenField hdnObjectID = (HiddenField)oItem.FindControl("hdnObjectID");

                                            if (Convert.ToInt32(hdnObjectID.Value) == Convert.ToInt32(drObject["ObjectID"].ToString()))
                                            {
                                                chkSelectObject.Checked = true;
                                                break;
                                            }
                                        }
                                    }
                                }

                                //drObjects = null;
                                //DataRow[] drObjects1  = ds.Tables[3].Rows;//.Select("FeatureID = " + dr["FeatureID"].ToString());
                               
                                   
                                //}

                                break;
                            }
                        }
                    }

                    if (ds.Tables[3].Rows.Count > 0)
                    {
                        foreach (DataRow dr1 in ds.Tables[3].Rows)
                        {
                            chkFeatures.Items.FindByValue(dr1["FeatureID"].ToString()).Selected = true;
                        }
                    }

                    FillGroupRights(ds);
                }
                else
                {
                    FillGroupRights(ds);
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "drpGroup_SelectedIndexChanged", 0, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo()));
                //lblError.Text = ex.Message;
                //pnlError.Visible = true;
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "drpGroup_SelectedIndexChanged", 1, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                    pnlError.Visible = true;

                }
                else
                {
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;

                }
            }
        }

        
        private void FillGroupRights(DataSet ds)
        {
            //------------Set Check for CSR Menu-----------------
            //this.SetChecked(ds.Tables[2], this.cblUserRights);
            //-----------Set Check for Services------------------          

            DataTable dtGorpLevelPermission = ds.Tables[2];
            if (dtGorpLevelPermission != null && dtGorpLevelPermission.Rows.Count > 0)
            {
                this.cblUserRights.Items[0].Selected = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["FileAdd"]);
                this.cblUserRights.Items[1].Selected = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["FileView"]);
                this.cblUserRights.Items[2].Selected = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["FileRemove"]);
                this.cblUserRights.Items[3].Selected = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["FileDownload"]);
            }
            else
            {
                this.cblUserRights.Items[0].Selected = false;
                this.cblUserRights.Items[1].Selected = false;
                this.cblUserRights.Items[2].Selected = false;
                this.cblUserRights.Items[3].Selected = false;
            }
        }

        #endregion

        #region "Repeater Event"

        /// <summary>
        /// Bind the Current Selected Main Menu Info
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptFeature_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            /*
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
              

                try
                {
                    DataRowView _DataRowView = (DataRowView)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnFeatureID")).Value = _DataRowView["AppFeatureID"].ToString();
                    ((CheckBox)e.Item.FindControl("chkSelectFeature")).Checked = Convert.ToBoolean(_DataRowView["Select"].ToString());
                    ((Label)e.Item.FindControl("lblFeature")).Text = _DataRowView["Name"].ToString();

                    ImageButton IbFeature = ((ImageButton)e.Item.FindControl("IbFeature"));
                    HtmlGenericControl pnlObject = ((HtmlGenericControl)e.Item.FindControl("pnlObject"));
                    CheckBox chkSelectFeature = (CheckBox)e.Item.FindControl("chkSelectFeature");

                    IbFeature.Attributes.Add("onclick", "return ExpandCollapseNode('" + IbFeature.ClientID + "','" + pnlObject.ClientID + "')");
                    chkSelectFeature.Attributes.Add("onclick", "return CheckChildNode('" + chkSelectFeature.ClientID + "','" + pnlObject.ClientID + "')");

                    // get object of selected feature
                    DataTable dt = new MenuBLL().GetObjectsByFeature(Convert.ToInt32(_DataRowView["AppFeatureID"].ToString()));
                    dt.Columns.Add(new DataColumn("Select", typeof(bool)));
                    foreach (DataRow dr in dt.Rows)
                    {
                        dr["Select"] = false;
                    }

                    if (dt.Rows.Count == 0)
                        IbFeature.Visible = false;

                    Repeater rptObject = (Repeater)e.Item.FindControl("rptObject");
                    rptObject.DataSource = dt;
                    rptObject.DataBind();
                }
                catch (Exception ex)
                {
                    new Common().AddErrorLog(ex, "rptFeature_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.GroupPermission);
                    //new Common().AddErrorLog("rptFeature_ItemDataBound", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
              */

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {


                try
                {
                    ApplicationFeaturesModel appFeature = (ApplicationFeaturesModel)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnFeatureID")).Value = appFeature.ID.ToString();
                    ((CheckBox)e.Item.FindControl("chkSelectFeature")).Checked = appFeature.Select; // Convert.ToBoolean(appFeature["Select"].ToString());
                    ((Label)e.Item.FindControl("lblFeature")).Text = appFeature.Name;// appFeature["Name"].ToString();


                    ImageButton IbFeature = ((ImageButton)e.Item.FindControl("IbFeature"));
                    HtmlGenericControl pnlObject = ((HtmlGenericControl)e.Item.FindControl("pnlObject"));
                    CheckBox chkSelectFeature = (CheckBox)e.Item.FindControl("chkSelectFeature");

                    IbFeature.Attributes.Add("onclick", "return ExpandCollapseNode('" + IbFeature.ClientID + "','" + pnlObject.ClientID + "')");
                    chkSelectFeature.Attributes.Add("onclick", "return CheckChildNode('" + chkSelectFeature.ClientID + "','" + pnlObject.ClientID + "')");

                    // get object of selected feature
                    //DataTable dt = new MenuBLL().GetObjectsByFeature(Convert.ToInt32(appFeature.ID.ToString()));
                    List<ApplicationFeaturesModel> appFeatures = new MenuBLL().GetAppObjectsByFeature(appFeature.ID.Value);
                    //dt.Columns.Add(new DataColumn("Select", typeof(bool)));
                    //foreach (DataRow dr in dt.Rows)
                    //{
                    //    dr["Select"] = false;
                    //}

                    //if (appFeatures == null || appFeatures.Count == 0)
                    //    IbFeature.Visible = false;

                    Repeater rptObject = (Repeater)e.Item.FindControl("rptObject");
                    rptObject.DataSource = appFeatures;
                    rptObject.DataBind();
                }
                catch (Exception ex)
                {
                    //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "rptFeature_ItemDataBound", 0, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo()));
                    //lblError.Text = ex.Message;
                    //pnlError.Visible = true;

                    string errorCode = string.Empty;
                    errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "rptFeature_ItemDataBound", 1, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo())).ToString();
                    if (ConfigurationHelper.IsShowGeneralMsg)
                    {
                        lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                        pnlError.Visible = true;

                    }
                    else
                    {
                        lblError.Text = ex.Message;
                        pnlError.Visible = true;

                    }
                }
            }
        }

        /// <summary>
        /// Bind the Curent Selected Sub Menu Info 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptObject_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            /*
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
               

                try
                {
                    DataRowView _DataRowView = (DataRowView)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnObjectID")).Value = _DataRowView["AppObjectID"].ToString();
                    ((CheckBox)e.Item.FindControl("chkSelectObject")).Checked = Convert.ToBoolean(_DataRowView["Select"].ToString());
                    ((Label)e.Item.FindControl("lblObject")).Text = _DataRowView["Name"].ToString();

                    // get parant controls
                    CheckBox chkSelectFeature = (CheckBox)e.Item.Parent.Parent.Parent.FindControl("chkSelectFeature");
                    HtmlGenericControl pnlObject = ((HtmlGenericControl)e.Item.Parent.Parent.Parent.FindControl("pnlObject"));
                    CheckBox chkSelectObject = (CheckBox)e.Item.FindControl("chkSelectObject");

                    chkSelectObject.Attributes.Add("onclick", "return CheckParentNode('" + chkSelectFeature.ClientID + "','" + pnlObject.ClientID + "','" + chkSelectObject.ClientID + "')");
                }
                catch (Exception ex)
                {
                    new Common().AddErrorLog(ex, "rptObject_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.GroupPermission);
                    //new Common().AddErrorLog("rptObject_ItemDataBound", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
            }
             * */

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {


                try
                {
                    ApplicationFeaturesModel appFeatuer = (ApplicationFeaturesModel)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnObjectID")).Value = appFeatuer.ID.ToString();//["AppObjectID"].ToString();
                    ((CheckBox)e.Item.FindControl("chkSelectObject")).Checked = appFeatuer.Select;// Convert.ToBoolean(appFeatuer["Select"].ToString());
                    ((Label)e.Item.FindControl("lblObject")).Text = appFeatuer.Name;//["Name"].ToString();

                    // get parant controls
                    CheckBox chkSelectFeature = (CheckBox)e.Item.Parent.Parent.Parent.FindControl("chkSelectFeature");
                    HtmlGenericControl pnlObject = ((HtmlGenericControl)e.Item.Parent.Parent.Parent.FindControl("pnlObject"));
                    CheckBox chkSelectObject = (CheckBox)e.Item.FindControl("chkSelectObject");

                    chkSelectObject.Attributes.Add("onclick", "return CheckParentNode('" + chkSelectFeature.ClientID + "','" + pnlObject.ClientID + "','" + chkSelectObject.ClientID + "')");
                }
                catch (Exception ex)
                {
                    //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "rptObject_ItemDataBound", 0, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo()));
                    //lblError.Text = ex.Message;
                    //pnlError.Visible = true;

                    string errorCode = string.Empty;
                    errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "rptObject_ItemDataBound", 1, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo())).ToString();
                    if (ConfigurationHelper.IsShowGeneralMsg)
                    {
                        lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                        pnlError.Visible = true;

                    }
                    else
                    {
                        lblError.Text = ex.Message;
                        pnlError.Visible = true;

                    }
                }
            }
        }

        #endregion

        #region "Button Click Events"

        /// <summary>
        /// Save the selected Menu Info  on the basis of Selected Group
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSave_Click(object sender, EventArgs e)
        {


            try
            {
                DataTable dt = new DataTable();
                DataTable dtGroupDistricts = new DataTable();
                DataRow dr;
                dt.Columns.Add(new DataColumn("GroupID", typeof(string)));
                dt.Columns.Add(new DataColumn("AppFeatureID", typeof(string)));
                dt.Columns.Add(new DataColumn("AppObjectID", typeof(string)));
                dt.TableName = TableName.tblGroupRights.ToString();
                foreach (RepeaterItem item in rptFeature.Items)
                {
                    CheckBox chkSelectFeature = (CheckBox)item.FindControl("chkSelectFeature");
                    HiddenField hdnFeatureID = (HiddenField)item.FindControl("hdnFeatureID");
                    Label lblFeature = (Label)item.FindControl("lblFeature");
                    Repeater rptObject = (Repeater)item.FindControl("rptObject");

                    if (chkSelectFeature.Checked == true)
                    {
                        if (rptObject.Items.Count > 0)
                        {
                            foreach (RepeaterItem oItem in rptObject.Items)
                            {
                                CheckBox chkSelectObject = (CheckBox)oItem.FindControl("chkSelectObject");
                                HiddenField hdnObjectID = (HiddenField)oItem.FindControl("hdnObjectID");

                                if (chkSelectObject.Checked == true)
                                {
                                    dr = dt.NewRow();
                                    dr["GroupID"] = drpGroup.SelectedValue;
                                    dr["AppFeatureID"] = hdnFeatureID.Value;
                                    dr["AppObjectID"] = hdnObjectID.Value;
                                    dt.Rows.Add(dr);
                                }
                            }
                        }
                        else
                        {
                            dr = dt.NewRow();
                            dr["GroupID"] = drpGroup.SelectedValue;
                            dr["AppFeatureID"] = hdnFeatureID.Value;
                            dr["AppObjectID"] = 0;
                            dt.Rows.Add(dr);
                        }
                    }
                }


                DataTable featureMngtRights = this.GetFeaturesMngntPermittedMenu(this.chkFeatures);
                featureMngtRights.TableName = TableName.tblAppFeatures.ToString();

                UserGroupRights userGroup = new UserGroupRights();
                userGroup.dsAllPermitRights = new DataSet();
                userGroup.dsAllPermitRights.Tables.Add(dt);
                userGroup.dsAllPermitRights.Tables.Add(featureMngtRights);
                
                userGroup.AllowFileAttachment = this.cblUserRights.Items[0].Selected;
                userGroup.AllowFileView = this.cblUserRights.Items[1].Selected;
                userGroup.AllowFileRemoved = this.cblUserRights.Items[2].Selected;
                userGroup.AllowFileDownload = this.cblUserRights.Items[3].Selected;

                if (dt.Rows.Count > 0)
                {

                    int result = new GroupBLL().SaveGroupRights(Convert.ToInt32(drpGroup.SelectedValue), userGroup);
                    if (result > 0)
                    {
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.success('Record saved successfully');", true);
                        PopulateMenu();
                        drpGroup.SelectedIndex = 0;
                        BindUserRights();
                        ClearChecked(chkFeatures);

                    }
                }
                else
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('To save a group rights please select atleast one option in feature and form tab');", true);
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "btnSave_Click", 0, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo()));
                //lblError.Text = ex.Message;
                //pnlError.Visible = true;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "btnSave_Click", 1, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                    pnlError.Visible = true;

                }
                else
                {
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;

                }
            }
        }

        /// <summary>
        /// Clear all control on Group Pemission
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            GetGroups();
            PopulateMenu();
            BindUserRights();
        }



        /// <summary>
        /// Bind the repeater user rights control in item data bound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptUserRights_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                try
                {
                    DataRowView dataRowView = (DataRowView)e.Item.DataItem;

                    HiddenField hdnRowID = ((HiddenField)e.Item.FindControl("hdnRowID"));
                    DropDownList ddlServices = ((DropDownList)e.Item.FindControl("ddlServices"));

                    hdnRowID.Value = dataRowView["RowID"].ToString();
                    ddlServices.DataSource = (DataTable)ViewState["AllServies"];
                    ddlServices.DataTextField = "Title";
                    ddlServices.DataValueField = "ServiceID";
                    ddlServices.DataBind();


                    ddlServices.SelectedValue = dataRowView["ServiceID"].ToString();

                    CheckBox chkDeliveryDate = (CheckBox)e.Item.FindControl("chkDeliveryDate");
                    if (chkDeliveryDate != null && !Convert.IsDBNull(dataRowView["IsEditDeliveryDate"]) && !string.IsNullOrEmpty(Convert.ToString(dataRowView["IsEditDeliveryDate"])))
                        chkDeliveryDate.Checked = Convert.ToBoolean(dataRowView["IsEditDeliveryDate"].ToString());

                }
                catch (Exception ex)
                {

                    //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "rptUserRights_ItemDataBound", 0, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo()));
                    //lblError.Text = ex.Message;
                    //pnlError.Visible = true;

                    string errorCode = string.Empty;
                    errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "rptUserRights_ItemDataBound", 1, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo())).ToString();
                    if (ConfigurationHelper.IsShowGeneralMsg)
                    {
                        lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                        pnlError.Visible = true;

                    }
                    else
                    {
                        lblError.Text = ex.Message;
                        pnlError.Visible = true;

                    }
                }
            }
            else if (e.Item.ItemType == ListItemType.Footer)
            {
                this.SetPagingControl(e);
            }
        }



        private DataTable GetFeaturesMngntPermittedMenu(CheckBoxList chklst)
        {
            DataRow dr;
            DataTable dt = new DataTable();
            dt.Columns.Add("GroupID", typeof(string));
            dt.Columns.Add("AppFeatureID", typeof(string));
            dt.Columns.Add("AppObjectID", typeof(string));

            foreach (ListItem litem in chklst.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dt.NewRow();
                    dr["GroupID"] = 0;
                    dr["AppFeatureID"] = litem.Value;
                    dr["AppObjectID"] = 0;
                    dt.Rows.Add(dr);
                }
            }

            return dt;

        }

        #endregion

        #region "Set Paging Method"

        private void SetPagingControl(RepeaterItemEventArgs e)
        {
            try
            {
                DataRowView rptRow = (DataRowView)e.Item.DataItem;
                DataTable dt = new DataTable();
                dt.Columns.Add("Value");

                //Display only PageNumber upto PagingSize            
                if ((PageStart + (PagingSize - 1)) <= PageCount)
                {
                    for (int i = PageStart; i <= PageStart + (PagingSize - 1); i++)
                        dt.Rows.Add(i);
                }
                else
                {
                    for (int i = PageStart; i <= PageCount; i++)
                        dt.Rows.Add(i);
                }

                Repeater rptPaging = (Repeater)e.Item.FindControl("rptPaging");
                rptPaging.DataSource = dt;
                rptPaging.DataBind();

                if (PageNumber == 0 || PageStart == 1)
                    ((LinkButton)e.Item.FindControl("lbtnPrevious")).Enabled = false;


                if (PageNumber == PageCount - 1 || (PageStart + PagingSize - 1) > PageCount)
                    ((LinkButton)e.Item.FindControl("lbtnNext")).Enabled = false;

                Label lbl = (Label)e.Item.FindControl("lblDisplayingRecords");
                if (TotalRecords != 0)
                {
                    if (TotalRecords > (PageNumber * PageSize + PageSize))
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + (PageNumber * PageSize + PageSize) + " of " + TotalRecords + " records";
                    else
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + TotalRecords + " of " + TotalRecords + " records";
                }
                else
                {
                    lbl.Text = "Showing 0 to 0 of 0 records";
                }
            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "SetPagingControl", 0, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo()));
                //lblError.Text = ex.Message;
                //pnlError.Visible = true;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "SetPagingControl", 1, PageNames.GroupPermission, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    lblError.Text = ConfigurationHelper.GeneralMsg + errorCode;
                    pnlError.Visible = true;

                }
                else
                {
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;

                }
            }
        }

        #endregion
    }
}