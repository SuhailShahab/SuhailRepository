﻿
using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups.RightsManager;
using PITB.PFSA.Modules.BusinessLogicLayer;
using PITB.PFSA.Modules.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <7/12/2014 2:07:32 AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time      Desription
// CR:001       Muhammad Hammad Shahid      19-03-2015 03:05:19PM   Add service data posting checkbox
// CR:002       Syed Zeeshan Aqil           06-07-2015 04:21:08PM   Add new operational rights "File attachment", Residential history, Personal info  and show address info Paneel
// =================================================================================================================================
namespace PITB.PFSA.ControlTemplates.PITBFC.RightsManager
{
    public partial class ucGroupPermission : UserControl
    {
        #region "Paging Variable and Paging Properties"

        int PageSize = 25;
        int PagingSize = 5;
        int TotalRecords = 0;

        public int PageNumber
        {
            get
            {
                int val = 0;
                if (ViewState["PageNumber"] != null)
                    val = Convert.ToInt32(ViewState["PageNumber"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageNumber"] = value;
                else
                    ViewState["PageNumber"] = null;
            }
        }
        public int PageStart
        {
            get
            {
                int val = 1;
                if (ViewState["PageStart"] != null)
                    val = Convert.ToInt32(ViewState["PageStart"].ToString());
                return val;
            }
            set
            {
                if (value != -1)
                    ViewState["PageStart"] = value;
                else
                    ViewState["PageStart"] = null;
            }
        }
        public int PageCount
        {
            get
            {
                int val = 1;
                if (this.hidPageCount.Value != string.Empty)
                    val = Convert.ToInt32(this.hidPageCount.Value);
                return val;
            }
            set
            {
                if (value >= 1)
                {
                    this.hidPageCount.Value = value.ToString();
                }
            }
        }

        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            pnlError.Visible = false;

            if (!IsPostBack)
            {
                try
                {
                   
                    GetGroups();
                    PopulateMenu();
                    PopulateCSRMenu();
                }
                catch (Exception ex)
                {
                   new Common().AddErrorLog(new ErrorLogModel(ex, "Page_Load", 0,  PageNames.GroupPermission));
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
            }
        }

        #region "Methods"

        /// <summary>
        /// Bind the Group Control with Database Info
        /// </summary>
        private void GetGroups()
        {
            

            drpGroup.DataSource = new GroupBLL().GetAppGroups();
            drpGroup.DataValueField = "ID";
            drpGroup.DataTextField = "Title";
            drpGroup.DataBind();
            drpGroup.Items.Insert(0, new ListItem("Select Group", "0"));
        }

     

        


        /// <summary>
        /// Bind the Menu Feature Repeater with Current Menu Data
        /// </summary>
        private void PopulateMenu()
        {
           
            try
            {
                /*
                DataTable dt = new MenuBLL().GetFeatures(1);
                dt.Columns.Add(new DataColumn("Select", typeof(bool)));

                foreach (DataRow dr in dt.Rows)
                {
                    dr["Select"] = false;
                    dr.AcceptChanges();
                }

                rptFeature.DataSource = dt;
                rptFeature.DataBind();*/
                List<ApplicationFeaturesModel> appFeatures = new MenuBLL().GetAppFeatures(1);
                rptFeature.DataSource = appFeatures;
                rptFeature.DataBind();
            }
            catch (Exception ex)
            {
                //new Common().AddErrorLog(ex, "Page_Load", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.GroupPermission);
               // Common.AddErrorLog(new ErrorLogModel(ex, "Page_Load",0,  PageNames.GroupPermission));
                ThreadSafeLazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.GroupPermission));
               //new Common().AddErrorLog("PopulateMenu", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                throw ex;
            }
        }

        private void PopulateCSRMenu()
        {
           
           
            this.chkFeatures.DataSource = new MenuBLL().GetAppFeatures(2); ;
            this.chkFeatures.DataTextField = "Name";
            this.chkFeatures.DataValueField = "ID";
            this.chkFeatures.DataBind();
            this.chkFeatures.Items.Insert(0, new ListItem("Select All", "0"));
        }
        private void SetChecked(DataTable dtStatuses, CheckBoxList chklStatues)
        {
            this.ClearChecked(chklStatues);
            foreach (DataRow dr in dtStatuses.Rows)
            {
                foreach (ListItem item in chklStatues.Items)
                {
                    if (item.Value == dr["FeatureID"].ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// // CR: 003
        /// Bind the user rights datatable in repeater
        /// </summary>
        /// <param name="dt2">Get the data table of user rights</param>
        private void BindUserRightsRepeater(DataTable dt2)
        {

            DataColumn dc = new DataColumn("RowID", typeof(int));
            dt2.Columns.Add(dc);

            for (int i = 0; i < dt2.Rows.Count; i++)
            {
                dt2.Rows[i]["RowID"] = i + 1;
            }

            ViewState["dtUserRights"] = dt2;
            this.rptUserRights.DataSource = dt2;

            this.rptUserRights.DataBind();
        }

        private void SetChecked(DataTable dt, CheckBoxList chklStatues,string fieldName)
        {
            this.ClearChecked(chklStatues);
            if (dt!=null)
            foreach (DataRow dr in dt.Rows)
            {
                foreach (ListItem item in chklStatues.Items)
                {
                    if (item.Value == dr[fieldName].ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }
        private DataTable GetCSRPermittedMenu(CheckBoxList chklStatues)
        {
            DataRow dr;
            DataTable dt = new DataTable();
            dt.Columns.Add("GroupID", typeof(string));
            dt.Columns.Add("AppFeatureID", typeof(string));
            dt.Columns.Add("AppObjectID", typeof(string));

            foreach (ListItem litem in chklStatues.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dt.NewRow();
                    dr["GroupID"] = 0;
                    dr["AppFeatureID"] = litem.Value;
                    dr["AppObjectID"] = 0;
                    dt.Rows.Add(dr);
                }
            }

            return dt;

        }
        private DataTable GetGroupRightTable(CheckBoxList chklStatues)
        {
           

            DataRow dr;
           
            DataTable dt = GetGroupRightTable();

            foreach (ListItem litem in chklStatues.Items)
            {
                if (litem.Selected && litem.Value != "0")
                {
                    dr = dt.NewRow();                   
                    dr["ID"] = litem.Value;
                    dr["IsActive"] = litem.Selected ?1:0;
                    dt.Rows.Add(dr);
                }
            }

            return dt;
        }
        /// <summary>
        /// // CR: 006 
        /// Fill the user rights table from user rights repeater
        /// </summary>
        /// <returns></returns>
        private DataTable GetDeliveryDateRightTable()
        {

            DataTable dt = GetGroupRightTable();

            foreach (RepeaterItem aItem in rptUserRights.Items)
            {
                string ddlServiceValue = ((DropDownList)aItem.FindControl("ddlServices")).SelectedValue;
                bool isEditDeliveryDate = ((CheckBox)aItem.FindControl("chkDeliveryDate")).Checked ? true : false;

                DataRow dr = null;
                dr = dt.NewRow();
                dr["ID"] = ddlServiceValue;
                dr["IsActive"] = isEditDeliveryDate ? 1 : 0;
                dt.Rows.Add(dr);
            }
            return dt;
        }

        private static DataTable GetGroupRightTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("IsActive", typeof(int));
            return dt;
        }
        protected void ClearChecked(CheckBoxList chklist)
        {

            foreach (ListItem item in chklist.Items)
            {

                item.Selected = false;

            }

        }
        private void Reset()
        {           
           
            ViewState["dtUserRights"] = null;           
            this.rptUserRights.DataSource = null ;
            this.rptUserRights.DataBind();
        }

        /// <summary>
        /// // CR: 004 
        /// Add  new row in user rights table and bind it with user right repeater
        /// </summary>
        private void AddNewTableRowInUserRights()
        {

            DataTable dt = new DataTable();
            DataColumn dc = new DataColumn("ServiceID", typeof(int));
            dt.Columns.Add(dc);
            DataColumn dc1 = new DataColumn("IsEditDeliveryDate", typeof(bool));
            dt.Columns.Add(dc1);

            DataColumn dc2 = new DataColumn("RowID", typeof(int));
            dt.Columns.Add(dc2);

            foreach (RepeaterItem aItem in rptUserRights.Items)
            {
                string ddlServiceValue = ((DropDownList)aItem.FindControl("ddlServices")).SelectedValue;
                bool isEditDeliveryDate = ((CheckBox)aItem.FindControl("chkDeliveryDate")).Checked ? true : false;

                DataRow dr = null;
                dr = dt.NewRow();
                dr["ServiceID"] = ddlServiceValue;
                dr["IsEditDeliveryDate"] = isEditDeliveryDate;
                dt.Rows.Add(dr);
            }

            int len = dt.Rows.Count;

            DataRow dr1 = null;
            dr1 = dt.NewRow();
            if (len < 1)
            {
                dr1["RowID"] = len + 1;
                dr1["ServiceID"] = 0;
                dr1["IsEditDeliveryDate"] = 0;
            }
            else
                dr1["RowID"] = len + 1;


            dt.Rows.Add(dr1);

            this.rptUserRights.DataSource = dt;
            this.rptUserRights.DataBind();
            ViewState["dtUserRights"] = dt;
        }

        #endregion

        #region "Dropdown Events"

        /// <summary>
        /// Thsi event Bind the Menu Selected Info of Current Group
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void drpGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PopulateMenu();
                this.ClearChecked(this.chkFeatures);
                this.Reset();
                DataSet ds = new GroupBLL().GetGroupRights(Convert.ToInt32(drpGroup.SelectedValue));
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ds.Tables[0].DefaultView.Sort = "Sort";
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        foreach (RepeaterItem Item in rptFeature.Items)
                        {
                            CheckBox chkSelectFeature = (CheckBox)Item.FindControl("chkSelectFeature");
                            HiddenField hdnFeatureID = (HiddenField)Item.FindControl("hdnFeatureID");
                            Repeater rptObject = (Repeater)Item.FindControl("rptObject");

                            if (Convert.ToInt32(hdnFeatureID.Value) == Convert.ToInt32(dr["FeatureID"].ToString()))
                            {
                                chkSelectFeature.Checked = true;

                                //Get Feature Object against Group
                                DataRow[] drObjects = ds.Tables[1].Select("AppFeatureID = " + dr["FeatureID"].ToString());
                                if (drObjects.Length > 0)
                                {
                                    foreach (DataRow drObject in drObjects)
                                    {
                                        foreach (RepeaterItem oItem in rptObject.Items)
                                        {
                                            CheckBox chkSelectObject = (CheckBox)oItem.FindControl("chkSelectObject");
                                            HiddenField hdnObjectID = (HiddenField)oItem.FindControl("hdnObjectID");

                                            if (Convert.ToInt32(hdnObjectID.Value) == Convert.ToInt32(drObject["ObjectID"].ToString()))
                                            {
                                                chkSelectObject.Checked = true;
                                                break;
                                            }
                                        }
                                    }
                                }

                                break;
                            }
                        }
                    }

                   

                    FillGroupRights(ds);

                }
                else
                {
                    FillGroupRights(ds);
                }
               
               
            }
            catch (Exception ex)
            {
                //new Common().AddErrorLog(ex, "drpGroup_SelectedIndexChanged", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.GroupPermission);
               // Common.AddErrorLog(new ErrorLogModel(ex, "drpGroup_SelectedIndexChanged",0, PageNames.GroupPermission));
                ThreadSafeLazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "drpGroup_SelectedIndexChanged", 0, PageNames.GroupPermission));
               //new Common().AddErrorLog("drpGroup_SelectedIndexChanged", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                lblError.Text = ex.Message;
                pnlError.Visible = true;
            }
        }

        private void FillGroupRights(DataSet ds)
        {
            //------------Set Check for CSR Menu-----------------
            this.SetChecked(ds.Tables[0], this.chkFeatures);
            //-----------Set Check for Services------------------          

            DataTable dtGorpLevelPermission = ds.Tables[TableName.tblGroup.ToString()];
            if (dtGorpLevelPermission != null && dtGorpLevelPermission.Rows.Count > 0 && !Convert.IsDBNull(dtGorpLevelPermission.Rows[0]["AllowFileRemove"]))
            {
                this.chkAllowFileRemove.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowFileRemove"]);
                this.chkAllowFileView.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowFileView"]);
                this.chkAllowFileDownload.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowFileDownload"]);
                this.chkAllowServiceDataPosting.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowServiceDataPosting"]);
                this.chkAllowDataUpdate.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowDataUpdate"]);

                this.chkAllowAccessOutSideLocation.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowAccessOutSideLocation"]);
                this.chkAllowFileAttachment.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowFileAttachment"]);// CR:002
                this.chkAllowResidenceHistory.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowResidenceHistory"]);// CR:002
                this.chkAllowPersonalInfo.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowPersonalInfo"]);// CR:002
                this.chkAllowAddressInfo.Checked = Convert.ToBoolean(dtGorpLevelPermission.Rows[0]["AllowAddressInfo"]);// CR:002
            }
            else
            {
                this.chkAllowFileRemove.Checked = false;
                this.chkAllowFileView.Checked = false;
                this.chkAllowFileDownload.Checked = false;
            }
        }

        #endregion

        #region "Repeater Event"

        /// <summary>
        /// Bind the Current Selected Main Menu Info
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptFeature_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            /*
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
              

                try
                {
                    DataRowView _DataRowView = (DataRowView)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnFeatureID")).Value = _DataRowView["AppFeatureID"].ToString();
                    ((CheckBox)e.Item.FindControl("chkSelectFeature")).Checked = Convert.ToBoolean(_DataRowView["Select"].ToString());
                    ((Label)e.Item.FindControl("lblFeature")).Text = _DataRowView["Name"].ToString();

                    ImageButton IbFeature = ((ImageButton)e.Item.FindControl("IbFeature"));
                    HtmlGenericControl pnlObject = ((HtmlGenericControl)e.Item.FindControl("pnlObject"));
                    CheckBox chkSelectFeature = (CheckBox)e.Item.FindControl("chkSelectFeature");

                    IbFeature.Attributes.Add("onclick", "return ExpandCollapseNode('" + IbFeature.ClientID + "','" + pnlObject.ClientID + "')");
                    chkSelectFeature.Attributes.Add("onclick", "return CheckChildNode('" + chkSelectFeature.ClientID + "','" + pnlObject.ClientID + "')");

                    // get object of selected feature
                    DataTable dt = new MenuBLL().GetObjectsByFeature(Convert.ToInt32(_DataRowView["AppFeatureID"].ToString()));
                    dt.Columns.Add(new DataColumn("Select", typeof(bool)));
                    foreach (DataRow dr in dt.Rows)
                    {
                        dr["Select"] = false;
                    }

                    if (dt.Rows.Count == 0)
                        IbFeature.Visible = false;

                    Repeater rptObject = (Repeater)e.Item.FindControl("rptObject");
                    rptObject.DataSource = dt;
                    rptObject.DataBind();
                }
                catch (Exception ex)
                {
                    new Common().AddErrorLog(ex, "rptFeature_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.GroupPermission);
                    //new Common().AddErrorLog("rptFeature_ItemDataBound", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
              */

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {


                try
                {
                    ApplicationFeaturesModel appFeature = (ApplicationFeaturesModel)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnFeatureID")).Value = appFeature.ID.ToString();
                    ((CheckBox)e.Item.FindControl("chkSelectFeature")).Checked = appFeature.Select; // Convert.ToBoolean(appFeature["Select"].ToString());
                    ((Label)e.Item.FindControl("lblFeature")).Text = appFeature.Name;// appFeature["Name"].ToString();
                   

                    ImageButton IbFeature = ((ImageButton)e.Item.FindControl("IbFeature"));
                    HtmlGenericControl pnlObject = ((HtmlGenericControl)e.Item.FindControl("pnlObject"));
                    CheckBox chkSelectFeature = (CheckBox)e.Item.FindControl("chkSelectFeature");

                    IbFeature.Attributes.Add("onclick", "return ExpandCollapseNode('" + IbFeature.ClientID + "','" + pnlObject.ClientID + "')");
                    chkSelectFeature.Attributes.Add("onclick", "return CheckChildNode('" + chkSelectFeature.ClientID + "','" + pnlObject.ClientID + "')");

                    // get object of selected feature
                    //DataTable dt = new MenuBLL().GetObjectsByFeature(Convert.ToInt32(appFeature.ID.ToString()));
                    List<ApplicationFeaturesModel> appFeatures = new MenuBLL().GetAppObjectsByFeature(appFeature.ID.Value);
                    //dt.Columns.Add(new DataColumn("Select", typeof(bool)));
                    //foreach (DataRow dr in dt.Rows)
                    //{
                    //    dr["Select"] = false;
                    //}

                    if (appFeatures == null ||appFeatures.Count == 0)
                        IbFeature.Visible = false;

                    Repeater rptObject = (Repeater)e.Item.FindControl("rptObject");
                    rptObject.DataSource = appFeatures;
                    rptObject.DataBind();
                }
                catch (Exception ex)
                {
                    //new Common().AddErrorLog(ex, "rptFeature_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.GroupPermission);
                   // Common.AddErrorLog(new ErrorLogModel(ex, "rptFeature_ItemDataBound", 0,  PageNames.GroupPermission));
                    ThreadSafeLazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "rptFeature_ItemDataBound", 0, PageNames.GroupPermission));
                    //new Common().AddErrorLog("rptFeature_ItemDataBound", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
            }
        }

        /// <summary>
        /// Bind the Curent Selected Sub Menu Info 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptObject_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            /*
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
               

                try
                {
                    DataRowView _DataRowView = (DataRowView)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnObjectID")).Value = _DataRowView["AppObjectID"].ToString();
                    ((CheckBox)e.Item.FindControl("chkSelectObject")).Checked = Convert.ToBoolean(_DataRowView["Select"].ToString());
                    ((Label)e.Item.FindControl("lblObject")).Text = _DataRowView["Name"].ToString();

                    // get parant controls
                    CheckBox chkSelectFeature = (CheckBox)e.Item.Parent.Parent.Parent.FindControl("chkSelectFeature");
                    HtmlGenericControl pnlObject = ((HtmlGenericControl)e.Item.Parent.Parent.Parent.FindControl("pnlObject"));
                    CheckBox chkSelectObject = (CheckBox)e.Item.FindControl("chkSelectObject");

                    chkSelectObject.Attributes.Add("onclick", "return CheckParentNode('" + chkSelectFeature.ClientID + "','" + pnlObject.ClientID + "','" + chkSelectObject.ClientID + "')");
                }
                catch (Exception ex)
                {
                    new Common().AddErrorLog(ex, "rptObject_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.GroupPermission);
                    //new Common().AddErrorLog("rptObject_ItemDataBound", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
            }
             * */

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {


                try
                {
                    ApplicationFeaturesModel appFeatuer = (ApplicationFeaturesModel)e.Item.DataItem;

                    ((HiddenField)e.Item.FindControl("hdnObjectID")).Value = appFeatuer.ID.ToString() ;//["AppObjectID"].ToString();
                    ((CheckBox)e.Item.FindControl("chkSelectObject")).Checked = appFeatuer.Select;// Convert.ToBoolean(appFeatuer["Select"].ToString());
                    ((Label)e.Item.FindControl("lblObject")).Text = appFeatuer.Name ;//["Name"].ToString();

                    // get parant controls
                    CheckBox chkSelectFeature = (CheckBox)e.Item.Parent.Parent.Parent.FindControl("chkSelectFeature");
                    HtmlGenericControl pnlObject = ((HtmlGenericControl)e.Item.Parent.Parent.Parent.FindControl("pnlObject"));
                    CheckBox chkSelectObject = (CheckBox)e.Item.FindControl("chkSelectObject");

                    chkSelectObject.Attributes.Add("onclick", "return CheckParentNode('" + chkSelectFeature.ClientID + "','" + pnlObject.ClientID + "','" + chkSelectObject.ClientID + "')");
                }
                catch (Exception ex)
                {
                    //new Common().AddErrorLog(ex, "rptObject_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.GroupPermission);
                    //Common.AddErrorLog(new ErrorLogModel(ex, "rptObject_ItemDataBound", 0, PageNames.GroupPermission));
                    ThreadSafeLazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "rptObject_ItemDataBound", 0, PageNames.GroupPermission));
                    //new Common().AddErrorLog("rptObject_ItemDataBound", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
            }
        }

        #endregion

        #region "Button Click Events"

        /// <summary>
        /// Save the selected Menu Info  on the basis of Selected Group
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSave_Click(object sender, EventArgs e)
        {
            

            try
            {
                DataTable dt = new DataTable();
                DataRow dr;
                dt.Columns.Add(new DataColumn("GroupID", typeof(string)));
                dt.Columns.Add(new DataColumn("AppFeatureID", typeof(string)));
                dt.Columns.Add(new DataColumn("AppObjectID", typeof(string)));

                foreach (RepeaterItem item in rptFeature.Items)
                {
                    CheckBox chkSelectFeature = (CheckBox)item.FindControl("chkSelectFeature");
                    HiddenField hdnFeatureID = (HiddenField)item.FindControl("hdnFeatureID");
                    Label lblFeature = (Label)item.FindControl("lblFeature");
                    Repeater rptObject = (Repeater)item.FindControl("rptObject");

                    if (chkSelectFeature.Checked == true)
                    {
                        if (rptObject.Items.Count > 0)
                        {
                            foreach (RepeaterItem oItem in rptObject.Items)
                            {
                                CheckBox chkSelectObject = (CheckBox)oItem.FindControl("chkSelectObject");
                                HiddenField hdnObjectID = (HiddenField)oItem.FindControl("hdnObjectID");

                                if (chkSelectObject.Checked == true)
                                {
                                    dr = dt.NewRow();
                                    dr["GroupID"] = drpGroup.SelectedValue;
                                    dr["AppFeatureID"] = hdnFeatureID.Value;
                                    dr["AppObjectID"] = hdnObjectID.Value;
                                    dt.Rows.Add(dr);
                                }
                            }
                        }
                        else
                        {
                            dr = dt.NewRow();
                            dr["GroupID"] = drpGroup.SelectedValue;
                            dr["AppFeatureID"] = hdnFeatureID.Value;
                            dr["AppObjectID"] = 0;
                            dt.Rows.Add(dr);
                        }
                    }
                }
                
               
               

                DataTable csrRight = this.GetCSRPermittedMenu(this.chkFeatures);
                csrRight.TableName = TableName.tblAppFeatures.ToString();

               


                DataSet dsAllTable = new DataSet();
                dsAllTable.Tables.Add(dt);
                dsAllTable.Tables.Add(csrRight);
               
               

                if (dt.Rows.Count > 0 || csrRight.Rows.Count > 0)
                {
                    //int result = new GroupBLL().SaveGroupRights(Convert.ToInt32(drpGroup.SelectedValue), dt, csrRight);
                    int result = new GroupBLL().SaveGroupRights(Convert.ToInt32(drpGroup.SelectedValue));
                    if (result > 0)
                    {
                        ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.success('Record saved successfully');", true);
                        PopulateMenu();
                        drpGroup.SelectedIndex = 0;
                       // this.ClearChecked(this.chkFeatures);
                        this.Reset();
                    }
                }
                else
                    ScriptManager.RegisterClientScriptBlock(this.Page, this.Page.GetType(), "RegisterScripts", "toastr.info('To save a group rights please select atleast one option in feature and form tab');", true);
            }
            catch (Exception ex)
            {
                //new Common().AddErrorLog(ex, "btnSave_Click", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.GroupPermission);
               // Common.AddErrorLog(new ErrorLogModel(ex, "btnSave_Click", 0, PageNames.GroupPermission));
                ThreadSafeLazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "btnSave_Click", 0, PageNames.GroupPermission));
                //new Common().AddErrorLog("btnSave_Click", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                lblError.Text = ex.Message;
                pnlError.Visible = true;
            }
        }

        /// <summary>
        /// Clear all control on Group Pemission
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            GetGroups();
            PopulateMenu();
          
        }

      
        /// <summary>
        /// // CR: 005 
        /// Add new row in user rights repeater
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void AddNewRow_Click(object sender, EventArgs e)
        {
            this.AddNewTableRowInUserRights();
        }
       

        /// <summary>
        /// Bind the repeater user rights control in item data bound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptUserRights_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                try
                {
                    DataRowView dataRowView = (DataRowView)e.Item.DataItem;
                    // ServiceUserRights model = (ServiceUserRights)e.Item.DataItem;
                    HiddenField hdnRowID = ((HiddenField)e.Item.FindControl("hdnRowID"));
                    DropDownList ddlServices = ((DropDownList)e.Item.FindControl("ddlServices"));

                    ///hdnRowID.Value = model.RowID.ToString();   // dataRowView["RowID"].ToString();
                    hdnRowID.Value = dataRowView["RowID"].ToString();
                    ddlServices.DataSource = (DataTable)ViewState["AllServies"];
                    ddlServices.DataTextField = "Title";
                    ddlServices.DataValueField = "ServiceID";
                    ddlServices.DataBind();

                    //ddlServices.SelectedValue = model.ServiceID.ToString(); // dataRowView["ServiceID"].ToString();
                    ddlServices.SelectedValue = dataRowView["ServiceID"].ToString();

                    //((CheckBox)e.Item.FindControl("chkDeliveryDate")).Checked = model.EnableDeliveryDateEditing;         //dataRowView["IsEditDeliveryDate"] != null ? Convert.ToBoolean(dataRowView["IsEditDeliveryDate"].ToString()) : false;
                    CheckBox chkDeliveryDate = (CheckBox)e.Item.FindControl("chkDeliveryDate");
                    if (chkDeliveryDate != null && !Convert.IsDBNull(dataRowView["IsEditDeliveryDate"]) && !string.IsNullOrEmpty(Convert.ToString(dataRowView["IsEditDeliveryDate"])))
                        chkDeliveryDate.Checked = Convert.ToBoolean(dataRowView["IsEditDeliveryDate"].ToString());
                    
                   // ((CheckBox)e.Item.FindControl("chkDeliveryDate")).Checked = dataRowView["IsEditDeliveryDate"] != null ? Convert.ToBoolean(dataRowView["IsEditDeliveryDate"].ToString()) : false;
                }
                catch (Exception ex)
                {

                    //new Common().AddErrorLog(ex, "rptUserRights_ItemDataBound", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.Users);
                   // Common.AddErrorLog(new ErrorLogModel(ex, "rptUserRights_ItemDataBound", 0,  PageNames.GroupPermission));
                    ThreadSafeLazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "rptUserRights_ItemDataBound", 0, PageNames.GroupPermission));
                    lblError.Text = ex.Message;
                    pnlError.Visible = true;
                }
            }
            else if (e.Item.ItemType == ListItemType.Footer)
            {
                this.SetPagingControl(e);
            }
        }

        /// <summary>
        /// Call the event of user rights repater control
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void rptUserRights_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            if (e.CommandName == "DeleteRow")
            {
                string hdnRowID = ((HiddenField)e.Item.FindControl("hdnRowID")).Value;
                string str = "RowID =" + hdnRowID;

                DataTable dt = (DataTable)ViewState["dtUserRights"];
                DataRow[] rows = dt.Select(str);
                foreach (DataRow r in rows)
                {
                    dt.Rows.Remove(r);
                }


                ViewState["dtUserRights"] = dt;
                this.rptUserRights.DataSource = dt;
                this.rptUserRights.DataBind();
            }
        }
        #endregion

        #region "Set Paging Method"

        private void SetPagingControl(RepeaterItemEventArgs e)
        {
            try
            {
                DataRowView rptRow = (DataRowView)e.Item.DataItem;
                DataTable dt = new DataTable();
                dt.Columns.Add("Value");

                //Display only PageNumber upto PagingSize            
                if ((PageStart + (PagingSize - 1)) <= PageCount)
                {
                    for (int i = PageStart; i <= PageStart + (PagingSize - 1); i++)
                        dt.Rows.Add(i);
                }
                else
                {
                    for (int i = PageStart; i <= PageCount; i++)
                        dt.Rows.Add(i);
                }

                Repeater rptPaging = (Repeater)e.Item.FindControl("rptPaging");
                rptPaging.DataSource = dt;
                rptPaging.DataBind();

                if (PageNumber == 0 || PageStart == 1)
                    ((LinkButton)e.Item.FindControl("lbtnPrevious")).Enabled = false;


                if (PageNumber == PageCount - 1 || (PageStart + PagingSize - 1) > PageCount)
                    ((LinkButton)e.Item.FindControl("lbtnNext")).Enabled = false;

                Label lbl = (Label)e.Item.FindControl("lblDisplayingRecords");
                if (TotalRecords != 0)
                {
                    if (TotalRecords > (PageNumber * PageSize + PageSize))
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + (PageNumber * PageSize + PageSize) + " of " + TotalRecords + " records";
                    else
                        lbl.Text = "Showing " + (PageNumber * PageSize + 1) + " to " + TotalRecords + " of " + TotalRecords + " records";
                }
                else
                {
                    lbl.Text = "Showing 0 to 0 of 0 records";
                }
            }
            catch (Exception ex)
            {
                //new Common().AddErrorLog(ex, "SetPagingControl", 0, Modules.CustomEnums.ServiceCodes.none, PageNames.Users);
               // Common.AddErrorLog(new ErrorLogModel(ex, "SetPagingControl", 0, ServiceCodes.none, PageNames.GroupPermission));
                ThreadSafeLazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "SetPagingControl", 0, PageNames.GroupPermission));
                lblError.Text = ex.Message;
                pnlError.Visible = true;
            }
        }

        #endregion
    }
}
