﻿var app = angular.module('evidenceApp', ['ui.bootstrap']);  
  
app.controller('evidenceCtrl', function ($scope, $http) {  
        $scope.orderByField = 'CaseNo';
        $scope.reverseSort = false;

        $scope.maxSize = 5;     // Limit number for pagination display number.  
        $scope.totalCount = 0;  // Total number of items in all pages. initialize as a zero  
        $scope.pageIndex = 1;   // Current page number. First page is 1.-->  
        $scope.pageSizeSelected = 5; // Maximum number of items per page.  
     
        $scope.getCaseList = function () {
            $http.post('index.aspx / GetAllEvidenceInformation1', { id: $scope.searchText, pageIdex: $scope.pageIndex, pageSize: $scope.pageSizeSelected })
                 .success(function (data, status, headers) {
                     if (data.d.Evidences != null) {
                         if (NotifyMe(data.d.Notification)) {

                             $scope.Evidences = data.d.Evidences;
                             $scope.totalCount = data.d.TotalCount;
                         }
                     }

                 })
          .error(function (data, status, headers) {
              $scope.status = status;
          });
        }
       //Loading employees list on first time  
        $scope.getCaseList();
      
       //This method is calling from pagination number  
        $scope.pageChanged = function () {  
            $scope.getCaseList();
            };  
      
        //This method is calling from dropDown  
        $scope.changePageSize = function () {  
                $scope.pageIndex = 1;  
                $scope.getCaseList();
           };  
     
    });   
