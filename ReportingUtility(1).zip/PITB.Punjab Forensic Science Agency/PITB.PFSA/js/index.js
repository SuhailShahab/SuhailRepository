﻿
$(document).ready(function () {
    $(".loginName").html("<i class='fa fa-user'></i> " + $(".loginName").html());

    $(".username, .password").on('keypress', function (e) {
        if ($(".username").val().trim() != "" && $(".password").val().trim() != "") {
            if (e.keyCode === 13)
                logIN();
        }
        return true;
    });

    $(".btnLogined").click(function () {
        logIN();
    });


    $(".btnReset").click(function () {
        //if ($(".userid").val().trim() != "" && $(".oldpassword").val().trim() != "" && $(".newpassword").val().trim() != "" && $(".reppassword").val().trim() != "") {
        if ($("input[type='hidden'][id*=hdnUserID]").val() != "" && $(".oldpassword").val().trim() != "" && $(".newpassword").val().trim() != "" && $(".reppassword").val().trim() != "") {
            if ($(".reppassword").val().trim() == $(".newpassword").val().trim()) {
                $.ajax({
                    url: "index.aspx/ResetPassword",
                    type: 'POST',
                    data: "{loginName:\"" + $("input[type='hidden'][id*=hdnUserID]").val() + "\", oldPassword:\"" + $(".oldpassword").val().trim() + "\", newPassword:\"" + $(".newpassword").val().trim() + "\"}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        if (data.d != null && data.d != "") {
                            window.location.href = "index.aspx"
                            $('#passwordModal').modal('hide');
                            NotifyMe("success|Your password has been changed successfully. please login again.");
                        }
                        else {
                            NotifyMe("error|Invalid login name or password.");
                        }

                    },
                    error: function (request) {
                    }
                });
            }
            else {
                NotifyMe("warning|Password does not match each others.");
            }
        }
        else {
            alert("Please provide full credentials.");
        }
    });

    $(document).on('click', '.advance-search-btn', function () {
        $('.advance-search-box').slideToggle('slow');
        $(this).find('i').toggleClass('fa-arrow-down fa-arrow-up');
    });
    $(document).on('click', '.advance-search-close-btn', function () {
        $('.advance-search-box').slideUp('slow');
    });

});

function logIN() {
    if ($(".username").val().trim() != "" && $(".password").val().trim() != "") {
        $.ajax({
            url: "index.aspx/ValidateUser",
            type: 'POST',
            data: "{loginName:\"" + $(".username").val().trim() + "\", password:\"" + $(".password").val().trim() + "\"}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d)) {
                    if (data.d != null && data.d != "") {
                        window.location.href = data.d;
                    }
                }
            },
            error: function (request) {
            }
        });
    }
}

///  Angular Code Start

//var app = angular.module("myApp", ['angularUtils.directives.dirPagination']);
var app = angular.module("myApp", ['angularUtils.directives.dirPagination','ui.bootstrap']);

app.controller("documentsContoller", function ($scope, $http) {
    $scope.searchText = "";
    $scope.Cases = [];
    $scope.Agencies = [];
    $scope.Statuses = [];
    $scope.Provinces = [];
    $scope.Districts = [];
    $scope.PoliceStations = [];
    $scope.Documents = [];
    $scope.verify = "";

    $scope.orderByField = 'CaseNo';
    $scope.reverseSort = false;
    //=========Paging =====================
    $scope.maxSize = 5;     // Limit number for pagination display number.  
    $scope.totalCount = 0;  // Total number of items in all pages. initialize as a zero  
    $scope.pageIndex = 1;   // Current page number. First page is 1.-->  
    $scope.pageSizeSelected = 5; // Maximum number of items per page.  
    //====================================

    //$scope.getCase = function () {
    //    $http.post('index.aspx/GetAllEvidenceInformation', { id: $scope.searchText })
    //     .success(function (data, status, headers) {
    //         if (data.d.Evidences != null) {

    //             if (NotifyMe(data.d.Notification)) {
    //                 $.each(data.d.Evidences, function (idx, itm) {
    //                     itm.RowNo = idx + 1;
    //                 });
    //             }
    //         }
    //         $scope.Cases = data.d.Evidences;
    //     })
    //     .error(function (data, status, headers) {
    //         $scope.status = status;
    //     });
    //};

    
    /*
    $http.post('index.aspx/GetAllEvidenceInformation', { id: $scope.searchText })
         .success(function (data, status, headers) {
             if (data.d.Evidences != null) {
                 $.each(data.d.Evidences, function (idx, itm) {
                     itm.RowNo = idx + 1;
                 });
             }
             $scope.Cases = data.d.Evidences;
         })
         .error(function (data, status, headers) {
             $scope.status = status;
         });
        */
    //$http.post('index.aspx/GetAllEvidenceInformation1', { id: $scope.searchText, pageIdex: $scope.pageIndex, pageSize: $scope.pageSizeSelected })
    //  .success(function (data, status, headers) {
    //      if (data.d.Evidences != null) {
    //          $scope.Evidences = data.d.Evidences;
    //          $scope.totalCount = data.d.TotalCount;
    //          $.each(data.d.Evidences, function (idx, itm) {
    //              itm.RowNo = idx + 1;
                  
    //          });
    //      }
    //      $scope.Cases = data.d.Evidences;
    //  })
    //  .error(function (data, status, headers) {
    //      $scope.status = status;
    //  });


    $scope.clearCase = function () {
        $scope.searchText = "";
        if ($scope.ddlAgencies!=undefined)
            $scope.ddlAgencies.ID = 0
        if ($scope.ddlStatus != undefined)
            $scope.ddlStatus.ID = 0
        if ($scope.ddlProvince != undefined)
            $scope.ddlProvince.ID = 0
        if ($scope.ddlDistrict != undefined)
            $scope.ddlDistrict.ID = 0
        if ($scope.ddlPoliceStation != undefined)
            $scope.ddlPoliceStation.ID = 0

        var param = {
            ID: $scope.searchText,
            PageIndex: $scope.pageIndex,
            PageSize: $scope.pageSizeSelected,
            AgencyID: null,
            StatusID: null,
            DistrictID: null,
            ProvinceID: null,
            StationID: null,
            IsLoad: false
        };
        //  $http.post('index.aspx/GetAllEvidenceInformation1', { id: $scope.searchText })
        var jsonStr = JSON.stringify(param);
        $http.post('index.aspx/GetAllEvidenceInformation1', { paramObject: jsonStr })
         .success(function (data, status, headers) {
             if (data.d.Evidences != null) {
                 $scope.Evidences = data.d.Evidences;
                 $scope.totalCount = data.d.TotalCount;
                 $.each(data.d.Evidences, function (idx, itm) {
                     itm.RowNo = idx + 1;
                 });
             }
             else {
                 $scope.Evidences = null;
                 $scope.totalCount = null;
             }
         })
         .error(function (data, status, headers) {
             $scope.status = status;
         });
    };
    //==========================
    //$scope.getCaseList = function (IsLoad, AgencyID, StatusID, ProvinceID, DistrictID, StationID) {
    $scope.getCaseList = function (IsLoad) {
        var agencyID = null, statusID = null, provinceID = null, districtID = null, stationID = null;
        if ($scope.ddlAgencies != undefined)
            agencyID = $scope.ddlAgencies.ID 
        if ($scope.ddlStatus != undefined)
            statusID =  $scope.ddlStatus.ID
        if ($scope.ddlProvince != undefined)
            provinceID = $scope.ddlProvince.ID 
        if ($scope.ddlDistrict != undefined)
            districtID = $scope.ddlDistrict.ID 
        if ($scope.ddlPoliceStation != undefined)
            stationID = $scope.ddlPoliceStation.ID

        var param = {
            ID: $scope.searchText,
            PageIndex: $scope.pageIndex,
            PageSize: $scope.pageSizeSelected,
            AgencyID: agencyID,
            StatusID: statusID,
            DistrictID: districtID,
            ProvinceID: provinceID,
            StationID: stationID,
            IsLoad: IsLoad
        };

      var jsonStr = JSON.stringify(param);
      $http.post('index.aspx/GetAllEvidenceInformation1', { paramObject: jsonStr})
     .success(function (data, status, headers) {
         if (data.d.Evidences != null) {
             $scope.Evidences = data.d.Evidences;
             $scope.totalCount = data.d.TotalCount;
             $.each(data.d.Evidences, function (idx, itm) {
                 itm.RowNo = idx + 1;
             });
         }
         else
         {
             $scope.Evidences = null;
             $scope.totalCount = null;
         }

        // $scope.Cases = data.d.Evidences;
         if (IsLoad == true)
         {
             $scope.Agencies = data.d.Agencies;
             $scope.Statuses = data.d.CaseStatuses;
             $scope.Provinces = data.d.Provinces;
             $scope.Districts = data.d.Districts;
             $scope.PoliceStations = data.d.PoliceStations;
         }
         $scope.UserTypeID = data.d.UserTypeID;
     })
     .error(function (data, status, headers) {
         $scope.status = status;
     });
     

    }

    $scope.getProvinceDistricts = function (provinceID) {
        $scope.districtList = [];
        for (var i in $scope.Districts) {
            if ($scope.Districts[i].ProvinceID == provinceID)
                $scope.districtList.push($scope.Districts[i]);
        }
    }

    $scope.getDistrictStations = function (districtID) {
        $scope.stationList = [];
        for (var i in $scope.PoliceStations) {
            if ($scope.PoliceStations[i].DistrictID == districtID)
                $scope.stationList.push($scope.PoliceStations[i]);
        }
    }

    //Loading employees list on first time  
    $scope.getCaseList(true);

    //This method is calling from pagination number  
    $scope.pageChanged = function () {
        $scope.getCaseList(false);
    };

    //This method is calling from dropDown  
    $scope.changePageSize = function () {
        $scope.pageIndex = 1;
        $scope.getCaseList(false);
    };
    //==========================

   

    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    };

    $scope.removeDocument = function (obj, idx) {
        if (confirm('Are you sure you want to delete this document?')) {
           var objIP = getHostnameIP();
            $http.post('index.aspx/DeleteDocument', { ipAddress: objIP.ip, computerName: objIP.hostName, documentURL: obj.Url, documentTitle: obj.Title, documentFileName: obj.FileName, caseID: obj.CaseID })
             .success(function (data, status, headers) {
                 $scope.Documents.splice(idx, 1);
                 //var index = $scope.bdays.indexOf(obj);
                 //$scope.Documents.splice(index, 1);
                 toastr.success('Document has been removed successfully.');
             })
             .error(function (data, status, headers) {
                 $scope.status = status;
             });
        }
    };

    $scope.viewDocument = function (obj) {
        $scope.Documents = [];
        $http.post('index.aspx/GetAllEvidenceData', { id: obj.CaseID }).success(function (data, status, headers)
        {
            $scope.Documents = data.d.Documents;
           
            if (data.d != null) {
                if (data.d.Notification != null) {
                    NotifyMe(data.d.Notification);
                }
                else {
                   
                    if (!data.d.IsWithinPremesis) {
                        SendSMSAPI(data.d.URL, data.d.CellNumber, data.d.PinNumber);
                    }

                    $scope.caseIDForVerify = obj.CaseID;
                    $('#' + data.d.ModelName).modal('show');
                }
            }
            else {
                toastr.info('No documents have been attached.');
            }
 
         })
         .error(function (data, status, headers) {
             $scope.status = status;

         });
    }; 

    $scope.Resend = function () {
        $http.post('index.aspx/Resend', { id: $scope.searchText }).success(function (data, status, headers) {
            if (data.d != null)    
                    if (!data.d.IsWithinPremesis)
                    {
                        SendSMSAPI(data.d.URL, data.d.CellNumber, data.d.PinNumber);
                    }
        })
         .error(function (data, status, headers) {
             $scope.status = status;
         });
        $scope.verify = "";
    };

    $scope.Verify = function () {
        //if ($('form').validationEngine('validate')) {
        $scope.Documents = [];
            $http.post('index.aspx/GetDataForVerification', { pinNumber: $scope.verify, caseIDForVerify: $scope.caseIDForVerify }).success(function (data, status, headers) {
                if (data.d != null && data.d.VerifyResult > 0) {
                    $scope.Documents = data.d.Documents;
                    $('#' + data.d.ModelName).modal('show');
            }
            else {
                    toastr.info('Pin Number not match.');
            }
        })
         .error(function (data, status, headers) {
             $scope.status = status;
         });
            $scope.verify = "";
        //}
        //toastr.info('Pin Number is required.');
    };
  
    $scope.saveSecreteInfo = function (doc, statisID) {
        var objIP = getHostnameIP();
        $http.post('index.aspx/SaveInfo', { ipAddress: objIP.ip, computerName: objIP.hostName, documentFileName: doc.Title, caseID: doc.CaseID, fileProcessStatusID: statisID })
        .success(function (data, status, headers) {
            //$scope.Documents = data.d;
            if (data.d != null && data.d != '') {
            }
            else {
                toastr.info('No documents have been attached.');
            }
        })
        .error(function (data, status, headers) {
            $scope.status = status;
        });
    };
});


/*
app.controller('evidenceCtrl', function ($scope, $http) {

    $scope.maxSize = 5;     // Limit number for pagination display number.  
    $scope.totalCount = 0;  // Total number of items in all pages. initialize as a zero  
    $scope.pageIndex = 1;   // Current page number. First page is 1.-->  
    $scope.pageSizeSelected = 5; // Maximum number of items per page.  

    $scope.getCaseList = function () {
        $http.post('index.aspx / GetAllEvidenceInformation1', { id: $scope.searchText, pageIdex: $scope.pageIndex, pageSize: $scope.pageSizeSelected })
             .success(function (data, status, headers) {
                 if (data.d.Evidences != null) {
                     if (NotifyMe(data.d.Notification)) {

                         $scope.Evidences = data.d.Evidences;
                         $scope.totalCount = data.d.TotalCount;
                     }
                 }

             })
      .error(function (data, status, headers) {
          $scope.status = status;
      });
    }
    //Loading employees list on first time  
    $scope.getCaseList();

    //This method is calling from pagination number  
    $scope.pageChanged = function () {
        $scope.getCaseList();
    };

    //This method is calling from dropDown  
    $scope.changePageSize = function () {
        $scope.pageIndex = 1;
        $scope.getCaseList();
    };

});

*/
