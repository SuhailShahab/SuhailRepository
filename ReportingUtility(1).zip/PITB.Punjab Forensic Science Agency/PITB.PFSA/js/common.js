﻿var privateIPUrl = "http://221.120.210.110:1337/server.js";

function getConfirmation(msg) {
    var baseMsg = "Are you sure you want to block this record?";
    return confirm(msg || baseMsg);
}

function getHostnameIP() {
    var ret = { ip: '', hoseName: ''};
    //example
    //ret.ip = '12.12.12.12';
    //ret.hostName = '12.12.12.12';
    //return ret;
    /*
    $.ajax({
        url: privateIPUrl,
        type: 'get',
        async: false,
        success: function (data) {
            ret.ip = data;
        },
        error: function () {
            ret.ip = '';
            ret.hostName = '';
            return ret;
        }
    });
    return ret; */
    var result = null;
    if (localStorage.getItem("ClientIPAddress") != null && localStorage.getItem("ClientIPAddress") != '') {
        result = localStorage.getItem("ClientIPAddress");
        return result;
    }
    return "Not Access";
}

$(window).load(function() {
		// Animate loader off screen
		$("#overlay").fadeOut("slow");
});


//========Send SMS ====================
function SendSMSAPI(url, appContactNo, pin) {

   
    if (pin != "" && pin != null) {
        
        ///////---------------------------------
        if (appContactNo != "") {

            var model = {
                "PhoneNo": appContactNo,
                "SMSMessage": 'From (PFSA).Your Requested Pin is ' + pin
            }

            $.ajax({
                url: url,
                type: 'POST',
                dataType: "json",
                data: JSON.stringify(model),
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    console.log('send request successfully');
                    toastr.info('Please check your email or mobile for Pin number.');
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    console.log(XMLHttpRequest);
                }
            });


            ///////////////////--------------------------



        }

    }//Message Empty Check End

    //$.ajax({ type: "GET", url: URL });
}
