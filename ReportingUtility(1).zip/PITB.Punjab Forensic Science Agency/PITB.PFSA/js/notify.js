﻿function NotifyMe(notification) {
    var ret = true;
    if (notification != null) {
        var notification_type = notification.indexOf("|") >= 0 ? notification.split("|")[0].toLowerCase() || 'success' : notification;
        var notification_message = notification.indexOf("|") >= 0 ? notification.split("|")[1] || 'Error occured during operation' : '';

        switch (notification_type) {
            case 'success':
                toastr.success(notification_message);
                break;
            case 'info':
                toastr.info(notification_message);
                break;
            case 'warning':
                toastr.warning(notification_message);
                break;
            case 'error':
                toastr.error(notification_message);
                ret = false;
                break;
            case 'Gen_error':
                toastr.error("There is some thing wrong.Please contact with administrator.");
                ret = false;
                break;
        }
    }
    return ret;
}