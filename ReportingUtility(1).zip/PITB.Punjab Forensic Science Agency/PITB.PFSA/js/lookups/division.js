﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];
var ref_all_Provicnes = [];
ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    //self.Provinces = ko.observableArray();

    //ref_all_Provicnes = [];
    if (items != null) {

        //if (ko.utils.unwrapObservable(items.Provinces) != null) {
        //    ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Provinces), function (rec) {
        //        self.Provinces.push(new CommonModel(rec));
        //        ref_all_Provicnes.push(new CommonModel(rec));
        //    });
        //}

        ref_all_rec = [];
        if (ko.utils.unwrapObservable(items.Divisions) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Divisions), function (item) {
                self.allRecords.push(new DivisionModel(item));
                ref_all_rec.push(new DivisionModel(item));
            });
        }
        self.PageSize(25);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new DivisionModel(item);
        if (ref_all_Provicnes != '') {
            ko.utils.arrayForEach(ref_all_Provicnes, function (itm) {
                if (ko.utils.unwrapObservable(itm.Status) || ((ko.utils.unwrapObservable(itm.ID) == ko.utils.unwrapObservable(item.ProvinceID)) && !ko.utils.unwrapObservable(itm.Status))) {
                    refModel.Provinces.push(itm);
                }
            });
        }
        self.editModel(refModel);
        self.allRecords.remove(item);
        self.isEdit(true);
    };

    self.cancelRecord = function () {
        self.editModel(new DivisionModel(null));
        self.Provinces = (ref_all_Provicnes);
        self.allRecords.push(refModel);
        self.isEdit(false);
    };

    self.removeRecord = function (item) {
        if (getConfirmation()) {
            $.ajax({
                url: "Division.aspx/RemoveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(item) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.d == "true") {
                        item.Status(false);
                        NotifyMe("inactivesuccess");
                    }
                    else if (data.d != "true" && data.d != "false") {
                        NotifyMe(data.d);
                    }
                },
                error: function (request) {
                    alert(Error);
                }
            });
        }
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "Division.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                    if (data.d.ID > 0) {
                        var mod = new DivisionModel(data.d);
                        self.allRecords.unshift(mod);                        
                        mod.Provinces(ref_all_Provicnes);
                        self.editModel(mod);
                        self.isEdit(false);
                        toastr.success("Record has been sved successfully.");
                        LoadRecord();
                    }
                  }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
                //error: function (request) {
                //    toastr.error("Something bad happened while saving. Please try again.");
                //}
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                if (item.Description != "") {
                    return item.Code().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                        item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                        item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                }
                else
                    return item.Code().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
                        item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;

                // return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Code().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }
}

function DivisionModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.StaticName = ko.observable(ko.utils.unwrapObservable(item.StaticName));
        self.TitleUrdu = ko.observable(ko.utils.unwrapObservable(item.TitleUrdu));
        self.Code = ko.observable(ko.utils.unwrapObservable(item.Code));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.ProvinceID = ko.observable(ko.utils.unwrapObservable(item.ProvinceID));
        self.ProvinceName = ko.observable(ko.utils.unwrapObservable(item.ProvinceName));

    }
    else {
        self.ID = ko.observable(null);
        self.Code = ko.observable();
        self.Title = ko.observable();
        self.StaticName = ko.observable('');
        self.TitleUrdu = ko.observable();
        self.Description = ko.observable('');
        self.Status = ko.observable(true);
        self.ProvinceID = ko.observable();
        self.ProvinceName = ko.observable('');

    }
    self.Provinces = ko.observableArray();
}

function CommonModel(rec) {
    var self = this;
    self.ID = ko.observable(rec.ID);
    self.Title = ko.observable(rec.Title);
    self.Status = ko.observable(rec.Status);


}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine({ promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "Division.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new wrapperModel(data.d));
            viewModel.main().editModel(new DivisionModel(null));
            if (data.d.Provinces != null) {
                viewModel.main().editModel().Provinces([]);
                ref_all_Provicnes = [];
                ko.utils.arrayForEach(data.d.Provinces, function (province) {
                    if (province.Status)
                        viewModel.main().editModel().Provinces.push(new CommonModel(province));
                    ref_all_Provicnes.push(new CommonModel(province));
                });
            }
        },
        error: function (request) {
        }
    });
}