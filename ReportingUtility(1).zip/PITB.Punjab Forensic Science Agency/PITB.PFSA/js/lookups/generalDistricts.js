﻿
// CR:                  Usman Mirza             10-Jun-2015            Addition of Dropdown for mapping FC District ID 


var viewModel = new ViewModel();
var all_provinces = [];
var all_division = [];
var refModel = null;
var ref_all_rec = [];
//var all_Mapdistricts = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    //self.allServices = ko.observableArray();
    self.AllActiveDistricts = ko.observableArray();
    self.Provinces = ko.observableArray();

    if (items != null) {
        if (items.Districts != null) {
            ref_all_rec = [];
            ko.utils.arrayForEach(items.Districts, function (item) {
                self.allRecords.push(new GeneralDistrictModel(item));
                ref_all_rec.push(new GeneralDistrictModel(item));
            });
        }
        self.PageSize(20);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }


    self.editRecord = function (item) {
        refModel = new GeneralDistrictModel(item);
        var mod = new GeneralDistrictModel(item);

        if (all_division != '') {
            ko.utils.arrayForEach(all_division, function (itm) {
                if (ko.utils.unwrapObservable(itm.Status) || ((ko.utils.unwrapObservable(itm.ID) == ko.utils.unwrapObservable(item.DivisionID)) && !ko.utils.unwrapObservable(itm.Status))) {
                    mod.allDivision.push(itm);
                }
            });
        }
       // mod.allDivision(all_division);
      //  mod.allMapFCDistrict(all_Mapdistricts);
        self.editModel(mod);
        self.allRecords.remove(item);
        self.isEdit(true);
    }

    self.cancelRecord = function () {
        var mod = new GeneralDistrictModel(null);
        mod.allDivision(all_division);
      //  mod.allMapFCDistrict(all_Mapdistricts);
        self.editModel(mod);
        self.allRecords.push(refModel);
        self.isEdit(false);
    }

    self.removeRecord = function (item) {
        if (getConfirmation()) {
            $.ajax({
                url: "GeneralDistrict.aspx/RemoveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(item) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        if (data.d == "true") {
                            item.Status(false);
                            NotifyMe("inactivesuccess");
                        }
                        else if (data.d != "true" && data.d != "false") {
                            NotifyMe(data.d);
                        }
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("error|" + er.statusText);
                }
            });
        }
    }

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "GeneralDistrict.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    //if (NotifyMe(data.d.Notification)) {
                    if (data.d.ID > 0) {
                        var mod = new GeneralDistrictModel(data.d);
                        mod.DivisionName(getDivisionNamebyID(mod));
                        self.allRecords.unshift(mod);
                        mod = new GeneralDistrictModel(null);
                        mod.allDivision(all_division);
                        self.editModel(mod);
                        self.isEdit(false);
                        toastr.success("Record has been sved successfully.")
                        LoadRecord();
                        // NotifyMe("saverecordSuccess");
                    }
                    //}
                },
                error: function (request) {
                    toastr.error("Something bad happened while saving. Please try again.");
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                if (item.Description != "") {
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                }
                else
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;


                //return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Description().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    }

    self.Reload = function () {
        LoadRecord();
    }

    self.getThirdpartyData = function () {
        ///
        // TODO: $.ajax to Driving lisence.
        ///
        var URL = ThirdPartyServiceURL + "GetDistrict/" + self.editModel().ServiceID();
        $.ajax({
            url: URL,
            type: 'GET',
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (data.Notification != null) {
                    NotifyMe(data.Notification);
                }
                $.ajax({
                    url: "GeneralDistrict.aspx/GetMappedData",
                    type: 'POST',
                    data: "{jsonModel : '" + ko.toJSON(data) + "', serviceID : '" + ko.toJSON(self.editModel().ServiceID()) + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        self.editModel().ThirdPartyRecord([]);
                        if (data.d != null) {
                            ko.utils.arrayForEach(data.d, function (item) {
                                self.editModel().ThirdPartyRecord.push(new ThirdPartyModel(item));
                            });
                        }
                        else {
                            self.editModel().ThirdPartyRecord.push(new ThirdPartyModel(null));
                        }
                    }
                });
            },
            error: function (error) {
                alert('There is some error in getting data from Third party service.');
                $.ajax({
                    url: "GeneralDistrict.aspx/GetMappedData",
                    type: 'POST',
                    data: "{jsonModel : '" + null + "', serviceID : '" + ko.toJSON(self.editModel().ServiceID()) + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        self.editModel().ThirdPartyRecord([]);
                        if (data.d != null) {
                            ko.utils.arrayForEach(data.d, function (item) {
                                self.editModel().ThirdPartyRecord.push(new ThirdPartyModel(item));
                            });
                        }
                        else {
                            self.editModel().ThirdPartyRecord.push(new ThirdPartyModel(null));
                        }
                    }
                });
            }
        });

    }

    self.resetThirdpartyData = function () {
        self.editModel().ThirdPartyRecord([]);
        self.editModel().ServiceID(undefined);
    }
}

function GeneralDistrictModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.DivisionID = ko.observable(ko.utils.unwrapObservable(item.DivisionID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.DivisionName = ko.observable(ko.utils.unwrapObservable(item.DivisionName));
        self.StaticName = ko.observable(ko.utils.unwrapObservable(item.StaticName));
        self.TitleUrdu = ko.observable(ko.utils.unwrapObservable(item.TitleUrdu));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.ServiceTitle = ko.observable(ko.utils.unwrapObservable(item.ServiceTitle));
        self.MapFCDistrictID = ko.observable(ko.utils.unwrapObservable(item.MapFCDistrictID));
        self.ThirdPartyRecord = ko.observableArray();
        self.MapDistrictName = ko.observable(ko.utils.unwrapObservable(item.MapDistrictName));
        self.Code = ko.observable(ko.utils.unwrapObservable(item.Code));
        if (ko.utils.unwrapObservable(item.ThirdPartyRecord) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(item.ThirdPartyRecord), function (rec) {
                self.ThirdPartyRecord.push(new ThirdPartyModel(rec));
            });
        }

    }
    else {
        self.ID = ko.observable(null);
        self.DivisionID = ko.observable(null);
        self.MapFCDistrictID = ko.observable();
        self.DivisionName = ko.observable('');
        self.Title = ko.observable();
        self.StaticName = ko.observable('');
        self.TitleUrdu = ko.observable();
        self.Description = ko.observable('');
        self.Status = ko.observable(true);
       // self.allMapFCDistrict = ko.observable(null);
        self.ServiceTitle = ko.observable();
        self.ThirdPartyRecord = ko.observableArray([]);
        self.MapDistrictName = ko.observable();
        self.Code = ko.observable();

    }

    self.ServiceID = ko.observable();
    self.allDivision = ko.observableArray();
   // self.allMapFCDistrict = ko.observableArray();

    self.removeThirdparty = function (item) {
        if (!this.IsThirdParty()) {
            if (confirm('Are you sure you want to delete this item?')) {
                $.ajax({
                    url: "GeneralDistrict.aspx/RemoveThirdPartyRecord",
                    type: 'POST',
                    data: "{itemID : '" + ko.toJSON(this.SelectedDistrictID()) + "', serivceID : '" + ko.toJSON(self.ServiceID()) + "'}",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        self.ThirdPartyRecord.remove(item);
                        refModel = null;
                        refModel = new ThirdPartyModel(self);
                    },
                    error: function (request) {
                        alert(Error);
                    }
                });
            }
        }
        else {
            self.ThirdPartyRecord.remove(this);
        }
    }

    self.addThirdparty = function () {
        self.ThirdPartyRecord.push(new ThirdPartyModel(null));
    }

}

function ThirdPartyModel(item) {
    var self = this;
    if (item != null) {
        self.ThirdPartyID = ko.observable(ko.utils.unwrapObservable(item.ThirdPartyID));
        self.ThirdPartyTitle = ko.observable(ko.utils.unwrapObservable(item.ThirdPartyTitle));
        self.IsActive = ko.observable(ko.utils.unwrapObservable(item.IsActive));
        self.IsThirdParty = ko.observable(ko.utils.unwrapObservable(item.IsThirdParty));
        self.SelectedDistrictID = ko.observable(ko.utils.unwrapObservable(item.SelectedDistrictID));
    }
    else {
        self.ThirdPartyID = ko.observable('');
        self.ThirdPartyTitle = ko.observable('');
        self.IsActive = ko.observable(true);
        self.IsThirdParty = ko.observable(true);
        self.SelectedDistrictID = ko.observable();
    }

    self.Districts = ko.observableArray(viewModel.main() != undefined ? viewModel.main().AllActiveDistricts() : []);
}


function activeDistrictModel(item) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
}

function DistrictModel(item) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
}


function serviceModel(service) {
    var self = this;
    self.ServiceID = ko.observable(service.ID);
    self.ServiceCode = ko.observable(service.Code);
    self.Title = ko.observable(service.Title);
}

function divisionModel(model) {
    var self = this;
    self.ID = ko.observable(model.ID);
    self.Title = ko.observable(model.Title);
    self.Status = ko.observable(model.Status);
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine({ promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "GeneralDistrict.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new wrapperModel(data.d));
            viewModel.main().editModel(new GeneralDistrictModel(null));
            if (data.d.Divisions != null) {
                viewModel.main().editModel().allDivision([]);
                all_division = [];
                ko.utils.arrayForEach(data.d.Divisions, function (division) {
                    if (division.Status)
                        viewModel.main().editModel().allDivision.push(new divisionModel(division));
                    all_division.push(new divisionModel(division));
                });
            }

            // Services 
            if (data.d.Services != null) {
                ko.utils.arrayForEach(data.d.Services, function (Service) {
                    viewModel.main().allServices.push(new serviceModel(Service));
                });
            }
            // debugger;
            if (data.d.AllActiveDistricts != null) {
                ko.utils.arrayForEach(data.d.AllActiveDistricts, function (items) {
                    viewModel.main().AllActiveDistricts.push(new activeDistrictModel(items));
                });
            }
            //if (data.d.MappedFCDistricts != null) {
            //    ko.utils.arrayForEach(data.d.MappedFCDistricts, function (item) {
            //        viewModel.main().editModel().allMapFCDistrict.push(new DistrictModel(item));
            //    });
            //    all_Mapdistricts = viewModel.main().editModel().allMapFCDistrict();
            //}
        },
        error: function (request) {

        }
    });
}

function getDivisionNamebyID(mod) {
    var ret = ko.utils.arrayFilter(all_division, function (item) {
        return item.ID() == mod.DivisionID();
    });
    return ret[0] != undefined ? ret[0].Title() : '-';
}