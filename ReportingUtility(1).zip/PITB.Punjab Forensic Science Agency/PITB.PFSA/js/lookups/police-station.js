﻿
//var apostrophyRegx = new RegExp("'", "g");

var viewModel = new ViewModel();
var refModel = null;
var all_Distrinct = [];
var ref_all_rec = [];

ko.bindingHandlers.valid = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($("#main"))) {
            $(element).validationEngine('validate');
        }
    }
};


function ViewModel() {

    var self = this;
    self.main = ko.observable();
}


function WrapperModel(item) {

    var self = this;
    self.Division = ko.observableArray();
    self.District = ko.observableArray();
    self.allRecords = ko.observableArray();
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.isEdit = ko.observable(false);

    if (item.PoliceStation != null) {
        ref_all_rec = [];
        ko.utils.arrayForEach(item.PoliceStation, function (item) {
            self.allRecords.push(new PoliceStationModel(item));
            ref_all_rec.push(new PoliceStationModel(item))
        });
    }


    self.PageSize(20);
    var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {

                return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.DistrictName().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;

            });
            self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.editRecord = function (item) {
        refModel = new PoliceStationModel(item);
        var mod = new PoliceStationModel(item);

        //Filtering disabled items

        viewModel.main().District([]);
        if (all_Distrinct != '') {
            ko.utils.arrayForEach(all_Distrinct, function (itm) {
                //if (ko.utils.unwrapObservable(itm.Status) || ((ko.utils.unwrapObservable(itm.DivisionID) == ko.utils.unwrapObservable(item.DivisionID)) && !ko.utils.unwrapObservable(itm.Status))) {
                if (ko.utils.unwrapObservable(itm.DivisionID) == ko.utils.unwrapObservable(item.DivisionID)) {
                    viewModel.main().District.push(new DistrictModel(itm));
                }
            });
        }
        self.editModel(mod);
        self.allRecords.remove(item);
        self.isEdit(true);
    }

    self.Reload = function () {
        GetRecords();
    }

    self.removeRecord = function (item) {
        if (getConfirmation()) {
            $.ajax({
                url: "PoliceStation.aspx/RemoveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(item) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.d == "true") {
                        item.Status(false);
                        NotifyMe("inactivesuccess");
                    }
                    else if (data.d != "true" && data.d != "false") {
                        NotifyMe(data.d);
                    }
                },
                error: function (request) {
                    alert(Error);
                }
            });
        }
    };
}


function PoliceStationModel(item) {

    var self = this;

    if (item != null) {

        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.DivisionID = ko.observable(ko.utils.unwrapObservable(item.DivisionID));
        self.DistrictID = ko.observable(ko.utils.unwrapObservable(item.DistrictID));
        self.TitleUrdu = ko.observable(ko.utils.unwrapObservable(item.TitleUrdu));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Code = ko.observable(ko.utils.unwrapObservable(item.Code || ''));
        self.AddressUrdu = ko.observable(ko.utils.unwrapObservable(item.AddressUrdu));
        self.Address = ko.observable(ko.utils.unwrapObservable(item.Address));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.DivisionName = ko.observable(ko.utils.unwrapObservable(item.DivisionName));
        self.DistrictName = ko.observable(ko.utils.unwrapObservable(item.DistrictName));
    }
    else {

        self.ID = ko.observable();
        self.DivisionID = ko.observable();
        self.DistrictID = ko.observable();
        self.TitleUrdu = ko.observable();
        self.Title = ko.observable();
        self.Code = ko.observable();
        self.AddressUrdu = ko.observable();
        self.Address = ko.observable();
        self.Status = ko.observable(true);
        self.DivisionName = ko.observable();
        self.DistrictName = ko.observable();
    }



    self.DivisionID.subscribe(function (newValue) {

        var filter_district = [];
        filter_district.length = 0;

        filter_district = ko.utils.arrayFilter(all_Distrinct, function (district) {
            return ko.utils.unwrapObservable(district.DivisionID()) == newValue && district.Status();
        });

        viewModel.main().District([]);
        viewModel.main().District(filter_district);
    });




    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            var jsonStr = ko.toJSON(viewModel.main().editModel());

            $.ajax({
                url: "PoliceStation.aspx/SaveRecord",
                type: 'POST',
                dataType: "json",
                data: "{jsonModel : '" + jsonStr + "'}",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.d != null) {
                        if (data.d.Notification == null) {
                            toastr.success("Record has been saved successfully.")
                            GetRecords();
                        }
                        else
                            alert(data.d.Notification);
                    }
                },
                error: function () {
                    toastr.error("Something bad happened while saving. Please try again.");
                }
            });
        }
    }

    self.cancelRecord = function () {

        viewModel.main().editModel(new PoliceStationModel(null));
        viewModel.main().allRecords.push(refModel);
        viewModel.main().isEdit(false);

    }
}



function DivisionModel(item) {

    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));

}


function DistrictModel(item) {

    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
    self.DivisionID = ko.observable(ko.utils.unwrapObservable(item.DivisionID));

    self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
    //self.MapFCDistrictID = ko.observable(ko.utils.unwrapObservable(item.MapFCDistrictID));
}


$(document).ready(function () {
    $('form').validationEngine({ promptPostion: 'bottomLeft' });
    GetRecords();
    ko.applyBindings(viewModel);
});


function GetRecords() {

    $.ajax({
        url: "PoliceStation.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {

            viewModel.main(new WrapperModel(data.d));
            viewModel.main().editModel(new PoliceStationModel(null));

            if (data.d.Divisions != null) {

                ko.utils.arrayForEach(data.d.Divisions, function (item) {
                    viewModel.main().Division.push(new DivisionModel(item));
                });
            }

            if (data.d.Districts != null) {

                all_Distrinct.length = 0;

                ko.utils.arrayForEach(data.d.Districts, function (item) {
                    //if (ko.utils.unwrapObservable(item.Status) || ((ko.utils.unwrapObservable(item.ID) == ko.utils.unwrapObservable(item.DistrictID)) && !ko.utils.unwrapObservable(item.Status)))
                    //    viewModel.main().District.push(new DistrictModel(item));
                    all_Distrinct.push(new DistrictModel(item));
                });
            }
        },
        error: function (request) {
        }
    });
}
