﻿var viewModel = new ViewModel();
var refModel = null;
var ref_all_rec = [];

ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;
    self.isEdit = ko.observable(false);
    self.PageSize = ko.observable(5);
    self.editModel = ko.observable();
    self.allRecords = ko.observableArray();
    

    
    if (items != null) {

    

        ref_all_rec = [];
        //if (ko.utils.unwrapObservable(items.Divisions) != null) {
        //    ko.utils.arrayForEach(ko.utils.unwrapObservable(items.Divisions), function (item) {
        //        self.allRecords.push(new SubmittedAgencyModel(item));
        //        ref_all_rec.push(new SubmittedAgencyModel(item));
        //    });
        //}

        //ref_all_rec = [];
        // Filling of array for grid
        ko.utils.arrayForEach(items, function (item) {
            self.allRecords.push(new SubmittedAgencyModel(item));
            ref_all_rec.push(new SubmittedAgencyModel(item));
        });


        self.PageSize(25);
        var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.allRecords(), null, self.PageSize());
    }

    self.editRecord = function (item) {
        refModel = new SubmittedAgencyModel(item);
        self.editModel(new SubmittedAgencyModel(item));
        self.allRecords.remove(item);
        self.isEdit(true);
    };

    self.cancelRecord = function () {
        self.editModel(new SubmittedAgencyModel(null));
        self.allRecords.push(refModel);
        self.isEdit(false);
    };

    self.removeRecord = function (item) {
        if (getConfirmation()) {
            $.ajax({
                url: "SubmittedAgency.aspx/RemoveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(item) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.d == "true") {
                        item.Status(false);
                        NotifyMe("inactivesuccess");
                    }
                    else if (data.d != "true" && data.d != "false") {
                        NotifyMe(data.d);
                    }
                },
                error: function (request) {
                    alert(Error);
                }
            });
        }
    };

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            $.ajax({
                url: "SubmittedAgency.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + ko.toJSON(viewModel.main().editModel()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    //if (NotifyMe(data.d.Notification)) {
                    if (data.d.ID > 0) {
                        var mod = new SubmittedAgencyModel(data.d);
                        self.allRecords.unshift(mod);
                        self.editModel(new SubmittedAgencyModel(null));
                        self.isEdit(false);
                    }
                    //}
                },
                error: function (request) {
                }
            });
        }
    };

    self.Filter = function () {
        if ($('.search').val().trim() != '') {
            var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {
                if (item.Email() != null && item.Email() != "" && item.Email() != "undefined")
                    return item.Email().toString().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 || item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                else
                    return item.Title().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
                     
              
            });
           self.allRecords(rList);
        }
        else {
            self.allRecords(ref_all_rec);
        }
        return true;
    };

    self.Reload = function () {
        LoadRecord();
    }
}

function SubmittedAgencyModel(item) {
    var self = this;

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Code = ko.observable(ko.utils.unwrapObservable(item.Code));
        self.Description = ko.observable(ko.utils.unwrapObservable(item.Description));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.Email = ko.observable(ko.utils.unwrapObservable(item.Email));

    }
    else {
        self.ID = ko.observable(null);
        self.Code = ko.observable();
        self.Title = ko.observable();
        
        self.Description = ko.observable('');
        self.Status = ko.observable(true);
        self.Email = ko.observable();

    }
}

function CommonModel(rec) {
    var self = this;
    self.ID = ko.observable(rec.ID);
    self.Title = ko.observable(rec.Title);

}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine({ promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "SubmittedAgency.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new wrapperModel(data.d));
            viewModel.main().editModel(new SubmittedAgencyModel(null));
        },
        error: function (request) {
        }
    });
}