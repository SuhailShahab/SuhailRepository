﻿var viewModel = new ViewModel();
var refModel = null;
var ref_district = [];
var ref_province = [];
var ref_agencies = [];
var ref_countries = [];
var ref_caseStatuses = [];
var ref_policeStations = [];
var ref_all_rec = [];
var sel_all_EmailAgencies = [];
var refSearchText = '';


ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};
//** Validation Engine Custom binding **\\
ko.bindingHandlers.valid = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        $('form').validationEngine('attach');
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().checked || allBindingsAccessor().datepicker || allBindingsAccessor().value || {};
        if (text() != undefined && !!ko.dataFor($("#main"))) {
            $(element).validationEngine('validate');
        }
    }
};

//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};

function wrapperModel(item) {
    var self = this;
    self.isEdit = ko.observable(false);

    self.AllowFileDownload = ko.observable(false);
    self.AllowFileRemoved = ko.observable(false);
    self.AllowFileView = ko.observable(false);

    ///  self.PageSize = ko.observable(10);

    self.PageSize = ko.observable(5);
    self.PageNo = ko.observable(1);
    self.TotalResults = ko.observable(0);
    self.SearchText = ko.observable(refSearchText);

    self.editModel = ko.observable(new EvidenceModel(null));
    self.filterModel = ko.observable(new FilterModel(null));
    self.SelectedEvidenceItem = ko.observable(new EvidenceEmailModel(null));
    self.Evidences = ko.observableArray();
    self.SelectedAgencyID = ko.observable(null);
    self.IsAttachedDocument = ko.observable(false);
    self.SelectAllEmails = ko.observable(false);
    self.EmailsList = ko.observableArray();
    self.EmailLogs = ko.observableArray();
    // for filters
    self.AgenciesFilter = ko.observableArray();
    self.CaseStatusesFilter = ko.observableArray();
    self.ProvincesFilter = ko.observableArray();
    self.DistrictsFilter = ko.observableArray();
    self.PoliceStationsFilter = ko.observableArray();

    if (item != null) {
        if (item.Evidences != null) {
            self.Evidences([]);
            ref_all_rec = [];
            ko.utils.arrayForEach(item.Evidences, function (evd) {
                self.Evidences.push(new EvidenceModel(evd));
                ref_all_rec.push(new EvidenceModel(evd));
            });

            self.PageSize(item.PageSize || 2);
            self.PageNo(item.PageNo == 0 ? 1 : item.PageNo);
            self.TotalResults(item.TotalCount);

            //self.PageSize(10);
            //var clientpager = new ko.bindingHandlers.pagedForeach.ClientPager(self.Evidences(), null, self.PageSize());
        }

        self.Pager = ko.pager(self.TotalResults, self.PageSize);
        self.Pager().CurrentPage(self.PageNo());



        self.AllowFileDownload(item.AllowFileDownload);
        self.AllowFileRemoved(item.AllowFileRemoved);
        self.AllowFileView(item.AllowFileView);

        // Get all agency email addresses
        self.AgencyEmails = ko.observableArray();
    }

    // Filter the Record from Title and Description
    self.Filter = function (data, event) {
        //if ($('.search').val().trim() != '') {
        self.SearchText($('.search').val());
        refSearchText = $('.search').val();
        viewModel.main().PageNo(0);
        LoadRecord(viewModel.main(), false);

        //}
        //else {
        //    NotifyMe("info|Please type something in search box");
        //}
        event.preventDefault();
        event.stopPropagation();

        //if ($('.search').val().trim() != '') {
        //    var rList = ko.utils.arrayFilter(ref_all_rec, function (item) {
        //        return item.CaseID().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
        //               item.CaseNo().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
        //               item.OldCaseNo().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
        //               item.FIRNo().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
        //               item.PoliceStationTitle().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
        //               item.District().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
        //               item.CaseStatusTitle().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0 ||
        //               item.SubmittedAgency().toLowerCase().indexOf($('.search').val().trim().toLowerCase()) >= 0;
        //    });
        //    self.Evidences(rList);
        //}
        //else {
        //    self.Evidences(ref_all_rec);
        //}
        //return true;
    }

    self.Reload = function () {
        //refSearchText = '';
        //LoadRecord();


        refSearchText = '';
        if ($('.search').val().trim() != '')
            self.SearchText($('.search').val());
        else
            self.SearchText('');
        viewModel.main().PageNo(0);
        LoadRecord(viewModel.main(), false);

    }

    self.getPageData = function (currentPage, nextPrev) {
        nextPrev == 'next' ? currentPage(ko.utils.unwrapObservable(currentPage()) + 1) : nextPrev == 'prev' ? currentPage(ko.utils.unwrapObservable(currentPage) - 1) : 0;
        self.PageNo(ko.utils.unwrapObservable(currentPage));
        LoadRecord(viewModel.main(), false);
    };

    self.editRecord = function (item) {
        refModel = new EvidenceModel(item);
        var mod = new EvidenceModel(item);

        //Filtering disabled items
        if (ref_countries != '') {
            ko.utils.arrayForEach(ref_countries, function (itm) {
                if (ko.utils.unwrapObservable(itm.Status) || ((ko.utils.unwrapObservable(itm.ID) == ko.utils.unwrapObservable(item.CountryID)) && !ko.utils.unwrapObservable(itm.Status))) {
                    mod.Countries.push(new CommonModel(itm));
                }
            });
        }

        if (ref_province != '') {
            ko.utils.arrayForEach(ref_province, function (itm) {
                if (ko.utils.unwrapObservable(itm.Status) || ((ko.utils.unwrapObservable(itm.ID) == ko.utils.unwrapObservable(item.ProvinceID)) && !ko.utils.unwrapObservable(itm.Status))) {
                    mod.Provinces.push(new CommonModel(itm));
                }
            });
        }

        if (ref_district != '') {
            ko.utils.arrayForEach(ref_district, function (itm) {
                if (ko.utils.unwrapObservable(itm.Status) || ((ko.utils.unwrapObservable(itm.ID) == ko.utils.unwrapObservable(item.DistrictID)) && !ko.utils.unwrapObservable(itm.Status))) {
                    mod.Districts.push(new DistrictModel(itm));
                }
            });
        }

        if (ref_agencies != '') {
            ko.utils.arrayForEach(ref_agencies, function (itm) {
                if (ko.utils.unwrapObservable(itm.Status) || ((ko.utils.unwrapObservable(itm.ID) == ko.utils.unwrapObservable(item.AgencyID)) && !ko.utils.unwrapObservable(itm.Status))) {
                    mod.Agencies.push(new CommonModel(itm));
                }
            });
        }

        if (ref_policeStations != '') {
            ko.utils.arrayForEach(ref_policeStations, function (itm) {
                if (ko.utils.unwrapObservable(itm.Status) || ((ko.utils.unwrapObservable(itm.ID) == ko.utils.unwrapObservable(item.PoliceStationID)) && !ko.utils.unwrapObservable(itm.Status))) {
                    mod.PoliceStations.push(new PoliceStationModel(itm));
                }
            });
        }

        if (ref_caseStatuses != '') {
            ko.utils.arrayForEach(ref_caseStatuses, function (itm) {
                if (ko.utils.unwrapObservable(itm.Status) || ((ko.utils.unwrapObservable(itm.ID) == ko.utils.unwrapObservable(item.CaseStatusID)) && !ko.utils.unwrapObservable(itm.Status))) {
                    mod.CaseStatuses.push(new CommonModel(itm));
                }
            });
        }

        // mod.Districts(ref_district);
        // mod.Provinces(ref_province);
        self.editModel(mod);

        self.Evidences.remove(item);
        self.isEdit(true);
    }

    self.Reset = function () {
        viewModel.main().PageNo(0);
        LoadRecord(viewModel.main(), false);
    };
    self.SendEmail = function (item) {
        refModel = new EvidenceEmailModel(item);
        var jsonStr = ko.toJSON(refModel);
        var isAttachment = false;

        ConfirmDialogYesNo('Confirmation Required!', 'Do you want to attach documents with email?', function (rResult) {
            isAttachment = rResult;
            $.ajax({
                url: "EvidenceSubmision.aspx/SendEmail",
                type: 'POST',
                //data: "{caseID : '" + refModel.CaseID() + "', caseNo : '" + refModel.CaseNo() + "', email : '" + refModel.Email() + "', submittingAgency : '" + refModel.SubmittedAgency() + "', documentTitle : '" + refModel.Documents()[0].Title() + "', documentUrl : '" + refModel.Documents()[0].Url() + "' }",
                data: "{jsonModel : '" + jsonStr + "', isAttachment : '" + isAttachment + "'}",
                dataType: "json",
                async: false,
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    NotifyMe("success|Email has been sent successfully on (" + refModel.Email() + ")");
                },
                error: function (er, _rr) {
                    NotifyMe("Gen_error|" + er.statusText);
                }
                //error: function (textStatus, errorThrown) {
                //    //NotifyMe("error|Error on sending Email");
                //    NotifyMe(textStatus + " --- " + errorThrown);
                //}
            });
        });
    };

    self.agencyEmails = function (rowIndex, item) {
        viewModel.main().AgencyEmails([]);
        if (viewModel.main().SelectedAgencyID() == null || viewModel.main().SelectedEvidenceItem == null) {
            viewModel.main().SelectedAgencyID(item.AgencyID());
        }
        viewModel.main().SelectedEvidenceItem(new EvidenceEmailModel(item));
        viewModel.main().SelectedEvidenceItem().RowIndex(rowIndex);
        viewModel.main().IsAttachedDocument(false);

        //  }
        viewModel.main().editModel().AgencyID(null);
        // viewModel.main().EvidenceModel.AgencyID(0);
        viewModel.main().SelectAllEmails(false);
        // alert($index() + 1);
        // alert(rowIndex);
        $.ajax({
            url: "EvidenceSubmision.aspx/GetAgencyEmails",
            type: 'POST',
            data: "{agencyID : '" + ko.utils.unwrapObservable(item.AgencyID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (data.d.EmailAgencies != null) {

                        viewModel.main().AgencyEmails([]);
                        sel_all_EmailAgencies = [];
                        ko.utils.arrayForEach(data.d.EmailAgencies, function (emailAgency) {
                            viewModel.main().AgencyEmails.push(new AgencyEmailModel(emailAgency));
                            sel_all_EmailAgencies.push(new AgencyEmailModel(emailAgency));
                            //all_EmailAgencies.push(new AgencyEmailModel(emailAgency))
                        });

                    }
                    // viewModel.main().AgencyEmails(all_EmailAgencies);
                }
            },
            error: function (er, _rr) {
                NotifyMe("Gen_error|" + er.statusText);
            }
        });

    };
    self.agencyEmails_changed = function (item) {
        viewModel.main().AgencyEmails([]);
        //if (viewModel.main().SelectedAgencyID() == null || viewModel.main().SelectedEvidenceItem == null) {
        //    viewModel.main().SelectedAgencyID(item.AgencyID());
        //    viewModel.main().SelectedEvidenceItem(new EvidenceEmailModel(item));
        //    viewModel.main().SelectedEvidenceItem().RowIndex(rowIndex);
        //    viewModel.main().IsAttachedDocument(true);
        //    viewModel.main().SelectAllEmails(false);
        // }
        // alert($index() + 1);
        // alert(rowIndex);
        if (ko.utils.unwrapObservable(item.AgencyID()) == undefined) {
            viewModel.main().AgencyEmails(sel_all_EmailAgencies);
        }

        $.ajax({
            url: "EvidenceSubmision.aspx/GetAgencyEmails",
            type: 'POST',
            data: "{agencyID : '" + ko.utils.unwrapObservable(item.AgencyID()) + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (data.d.EmailAgencies != null) {

                        viewModel.main().AgencyEmails([]);
                        ko.utils.arrayForEach(data.d.EmailAgencies, function (emailAgency) {
                            viewModel.main().AgencyEmails.push(new AgencyEmailModel(emailAgency));

                        });



                    }

                    // viewModel.main().AgencyEmails(all_EmailAgencies);
                }
            },
            error: function (er, _rr) {
                NotifyMe("Gen_error|" + er.statusText);
            }
        });

    };
    self.getEmailLogs = function (item) {
        viewModel.main().EmailLogs([]);


        viewModel.main().SelectedAgencyID(item.AgencyID());
        viewModel.main().SelectedEvidenceItem(new EvidenceEmailModel(item));
        viewModel.main().IsAttachedDocument(true);
        var evidenceID = viewModel.main().SelectedEvidenceItem().ID()
        /*model.AgencyID(self.SelectedAgencyID());
        model.CaseNo(viewModel.main().SelectedEvidenceItem().CaseNo());
        model.CaseID(viewModel.main().SelectedEvidenceItem().CaseID());
        model.EvidenceID(viewModel.main().SelectedEvidenceItem().ID());*/
        $.ajax({
            url: "EvidenceSubmision.aspx/GetEmailsLogs",
            type: 'POST',
            data: "{evidenceID: '" + evidenceID + "'}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                if (NotifyMe(data.d.Notification)) {
                    if (data.d.EmailLogs != null) {
                        viewModel.main().EmailLogs([]);
                        ko.utils.arrayForEach(data.d.EmailLogs, function (emailLog) {
                            viewModel.main().EmailLogs.push(new EmailLogsModel(emailLog));
                        });
                    }
                }
            },
            error: function (er, _rr) {
                NotifyMe("Gen_error|" + er.statusText);
            }
        });

    };

    //populate final list for sending emails
    self.buildFinalList = function () {
        ko.utils.arrayForEach(self.AgencyEmails(), function (emailAgency) {
            if (emailAgency.IsChecked()) {
                if (!FindEmailfromList(emailAgency.Email)) {
                    emailAgency.RowNumber = viewModel.main().EmailsList().length + 1;
                    viewModel.main().EmailsList.push(new AgencyEmailModel(emailAgency));
                }
            }
        });
        //ko.utils.arrayForEach(self.AgencyEmails(), function (emailAgency2) {
        //    if (emailAgency2.IsChecked()) {
        //        self.AgencyEmails.remove(emailAgency2);
        //    }

        //});
    }

    self.sendEmails = function (item) {

        // alert(self.SelectedAgencyID());
        // alert(self.AgencyEmails().length);
        // alert(viewModel.main().SelectedEvidenceItem().CaseNo());
        // alert(viewModel.main().IsAttachedDocument());
        var model = new SaveAgencyEmailModel(null);



        model.AgencyID(self.SelectedAgencyID());
        model.CaseNo(viewModel.main().SelectedEvidenceItem().CaseNo());
        model.CaseID(viewModel.main().SelectedEvidenceItem().CaseID());
        model.EvidenceID(viewModel.main().SelectedEvidenceItem().ID());
        model.UMSTrackNo(viewModel.main().SelectedEvidenceItem().UMSTrackNo());
        model.FIRNo = ko.observable(viewModel.main().SelectedEvidenceItem().FIRNo());
        model.PoliceStationTitle = ko.observable(viewModel.main().SelectedEvidenceItem().PoliceStationTitle());
        model.District = ko.observable(viewModel.main().SelectedEvidenceItem().District());
        model.FIMSDistrictID(viewModel.main().SelectedEvidenceItem().FIMSDistrictID());
        model.FIMSPoliceStationID(viewModel.main().SelectedEvidenceItem().FIMSPoliceStationID());
        ko.utils.arrayForEach(self.EmailsList(), function (emailAgency) {
            //if (emailAgency.IsChecked())
            //{
            model.EmailAgencies.push(new EmailItemModel(emailAgency));
            //}          

        });

        model.IsAttachedDocument(viewModel.main().IsAttachedDocument());
        if (viewModel.main().IsAttachedDocument()) {
            model.Documents(viewModel.main().SelectedEvidenceItem().Documents);
        }

        var jsonStr = ko.toJSON(model);

        if (model.EmailAgencies().length > 0) {
            $.ajax({
                url: "EvidenceSubmision.aspx/SendEmails",
                type: 'POST',
                data: "{jsonModel : '" + jsonStr + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        NotifyMe("success|Email sent successfully!")
                        if (viewModel.main().SelectedEvidenceItem() != undefined && viewModel.main().SelectedEvidenceItem() != null) {
                            // viewModel.main().SelectedEvidenceItem().IsSendEmail(true);
                            viewModel.main().Evidences()[viewModel.main().SelectedEvidenceItem().RowIndex()].IsSendEmail(true);
                        }

                        //item.IsSendEmail(true);
                        //alert(item.RowNo());
                        //viewModel.main().Evidences()[item.RowNo()].IsSendEmail(true);
                    }
                },
                error: function (er, _rr) {
                    NotifyMe("Gen_error|" + er.statusText);
                }
            });
            viewModel.main().EmailsList([]);
            model = null;
        }
        else {
            NotifyMe("info|No email is send. Please selcet at least one emial address")
        }

    };

    self.clickSelectAllEmails = function (itm) {
        //alert(self.SelectAllEmails());

        ko.utils.arrayForEach(viewModel.main().AgencyEmails(), function (itm) {

            itm.IsChecked(self.SelectAllEmails());

        });
        return true;
    }

    self.cancelRecord = function () {
        LoadRecord();
    }

    self.saveRecord = function () {
        if ($('form').validationEngine('validate')) {
            var jsonStr = ko.toJSON(viewModel.main().editModel());
            // jsonStr = jsonStr.replace(apostrophyRegx, "\\\'");

            $.ajax({
                url: "EvidenceSubmision.aspx/SaveRecord",
                type: 'POST',
                data: "{jsonModel : '" + jsonStr + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (NotifyMe(data.d.Notification)) {
                        var caseID = data.d.CaseID;
                        if (viewModel.main().editModel().Documents().length > 0) {
                            setTimeout(function () { $("#overlay").show(); }, 700);
                            $.ajax({
                                url: "EvidenceSubmision.aspx",
                                type: "POST",
                                contentType: false,
                                processData: false,
                                data: function () {
                                    var index = 0;
                                    // bind the control values to access in the server side
                                    var data = new FormData();
                                    var objIP = getHostnameIP();
                                    if (objIP != null) {
                                        data.append("IPAddress", objIP.ip);
                                        data.append("hostName", objIP.hostName);
                                    }
                                    else {
                                        data.append("IPAddress", "Not Found");
                                        data.append("hostName", "Not Found");
                                    }
                                    data.append("CaseID", caseID);

                                    for (var i = 0; i < viewModel.main().editModel().Documents().length; i++) {
                                        if ((viewModel.main().editModel().Documents()[i].ID() == null || viewModel.main().editModel().Documents()[i].ID() == 'null' || viewModel.main().editModel().Documents()[i].ID() == undefined)) {
                                            data.append("Type" + index, viewModel.main().editModel().Documents()[i].Type())
                                            data.append("Title" + index, viewModel.main().editModel().Documents()[i].Title());
                                            data.append("FileNames" + index, "");

                                            var Item = viewModel.main().editModel().Documents()[i].File();
                                            data.append("chosenFile", Item);
                                            index++;
                                        }
                                    }
                                    return data;
                                }(),
                                error: function (_, textStatus, errorThrown) {
                                },
                                success: function (response, textStatus) {
                                    $("#overlay").hide();
                                    NotifyMe("success|Your record has been saved successfully");
                                    NotifyMe("success|Document(s) has been saved successfully.");

                                    //LoadRecord();
                                    //LoadRecord(viewModel.main(), true);
                                    LoadRecord(new wrapperModel(null), false);

                                }
                            });
                        }
                        else {
                            NotifyMe("success|Your record has been saved successfully");
                        }

                        self.editModel().CaseID(caseID);
                        self.Evidences.unshift(new EvidenceModel(self.editModel()));
                        self.editModel(new EvidenceModel(null));
                        //LoadRecord();
                        //LoadRecord(viewModel.main(), true);
                        LoadRecord(new wrapperModel(null), false);
                    }
                },
                //error: function (error, dr) {
                //    alert(error);
                //}
                error: function (error, dr) {
                    // NotifyMe("error|" + error.statusText);
                    NotifyMe("Gen_error|" + error.statusText);
                }
            });
        }
        else {
            NotifyMe("info|Please fill all mandatory (e.g. having *) fields.");
        }

    }

    //self.closePopUp = function () {
    //    self.ContactCurrentPage(1);
    //    self.ContactCount(0);
    //    $(".searchlookup").val('');
    //}
    //self.removeEmailListItemss = function () {
    //    self.EmailsList([]);
    //};

    self.emptyEmailList = function () {
        self.EmailsList([]);
    };
}

function FindEmailfromList(email) {
    var recordExists = false;
    if (viewModel.main().EmailsList().length > 0) {
        for (var i = 0; i < viewModel.main().EmailsList().length; i++) {
            if (viewModel.main().EmailsList()[i].Email() == email()) {
                recordExists = true;
                break;
            } else {
                recordExists = false;
            }
        }
    }
    return recordExists;
}

function AgencyEmailModel(item) {
    var self = this;
    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.AgencyEmailID));
        self.RowNumber = ko.observable(ko.utils.unwrapObservable(item.RowNumber));
        self.Title = ko.observable(ko.utils.unwrapObservable(item.Title));
        self.Email = ko.observable(ko.utils.unwrapObservable(item.Email));
        self.IsChecked = ko.observable(ko.utils.unwrapObservable(item.IsChecked));
        self.AgencyID = ko.observable(ko.utils.unwrapObservable(item.AgencyID));
    }
    else {
        self.ID = ko.observable(null);
        self.RowNumber = ko.observable(null);
        self.Title = ko.observable(null);
        self.Email = ko.observable(null);
        self.IsChecked = ko.observable(false);
        self.AgencyID = ko.observable(false);
    }

    self.removeEmailListItem = function (item) {
        viewModel.main().EmailsList.remove(item);
    };
}

function EmailItemModel(item) {
    var self = this;
    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Email = ko.observable(ko.utils.unwrapObservable(item.Email));
        self.AgencyID = ko.observable(ko.utils.unwrapObservable(item.AgencyID));
    }
    else {
        self.ID = ko.observable(null);
        self.Email = ko.observable(null);
        self.AgencyID = ko.observable(null);
    }
}

function SaveAgencyEmailModel(item) {
    var self = this;
    self.AgencyID = ko.observable(null)
    self.EmailAgencies = ko.observableArray();
    self.Documents = ko.observableArray();
    self.IsAttachedDocument = ko.observableArray(false);
    self.CaseID = ko.observable(null);
    self.CaseNo = ko.observable(null);
    self.EvidenceID = ko.observable(null);
    self.UMSTrackNo = ko.observable(null);
    self.FIMSDistrictID = ko.observable(null);
    self.FIMSPoliceStationID = ko.observable(null);

}

function EmailLogsModel(item) {
    var self = this;
    if (item != null) {
        self.RowNumber = ko.observable(ko.utils.unwrapObservable(item.RowNumber));
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.Agency = ko.observable(ko.utils.unwrapObservable(item.Agency));
        self.CaseID = ko.observable(ko.utils.unwrapObservable(item.CaseID));
        self.CaseNo = ko.observable(ko.utils.unwrapObservable(item.CaseNo));
        self.EvidenceID = ko.observable(ko.utils.unwrapObservable(item.EvidenceID));
        self.EmailSentTo = ko.observable(ko.utils.unwrapObservable(item.EmailSentTo));
        self.UserID = ko.observable(ko.utils.unwrapObservable(item.UserID));
        self.SendingDate = ko.observable(ko.utils.unwrapObservable(item.SendingDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.SendingDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.SendingDate));
        self.HasAttachment = ko.observable(ko.utils.unwrapObservable(item.HasAttachment));
        self.AgencyTo = ko.observable(ko.utils.unwrapObservable(item.AgencyTo));
    }
    else {
        self.RowNumber = ko.observable(null);
        self.ID = ko.observable(null);
        self.Agency = ko.observable(null);
        self.CaseID = ko.observable(null);
        self.CaseNo = ko.observable(null);
        self.EvidenceID = ko.observable(null);
        self.EmailSentTo = ko.observable(null);
        self.UserID = ko.observable(null);
        self.SendingDate = ko.observable(null);
        self.HasAttachment = ko.observable(null);
        self.AgencyTo = ko.observable(null);
    }
}

function FilterModel(item) {
    var self = this;

    self.AgencyID = ko.observable('');
    self.CaseStatusID = ko.observable('');
    self.ProvinceID = ko.observable('');
    self.DistrictID = ko.observable('');
    self.PoliceStationID = ko.observable('');

    self.ProvinceID.subscribe(function (newValue) {
        if (newValue != undefined && newValue != null) {

            var filter_district = [];
            filter_district = ko.utils.arrayFilter(ref_district, function (item) {
                return item.ProvinceID() == newValue && item.Status();
            });
            viewModel.main().DistrictsFilter([]);
            viewModel.main().DistrictsFilter(filter_district);

        }
        else {
            viewModel.main().DistrictsFilter([]);
        }
    });

    self.DistrictID.subscribe(function (newValue) {
        if (newValue != undefined && newValue != null) {

            var filter_policeStations = [];
            filter_policeStations = ko.utils.arrayFilter(ref_policeStations, function (item) {
                return item.DistrictID() == newValue && item.Status();
            });
            viewModel.main().PoliceStationsFilter([]);
            viewModel.main().PoliceStationsFilter(filter_policeStations);

        }
        else {
            viewModel.main().PoliceStationsFilter([]);
        }
    });
}
function EvidenceModel(item) {
    var self = this;
    if (item != null) {

        self.RowNo = ko.observable(ko.utils.unwrapObservable(item.RowNo));
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.CaseID = ko.observable(ko.utils.unwrapObservable(item.CaseID) || '');
        self.CaseNo = ko.observable(ko.utils.unwrapObservable(item.CaseNo) || '');
        self.OldCaseNo = ko.observable(ko.utils.unwrapObservable(item.OldCaseNo) || '');
        self.FIRNo = ko.observable(ko.utils.unwrapObservable(item.FIRNo) || '');
        self.LetterNo = ko.observable(ko.utils.unwrapObservable(item.LetterNo) || '');
        self.CaseDate = ko.observable(ko.utils.unwrapObservable(item.CaseDate).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.CaseDate).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.CaseDate));
        self.SubmittedAgency = ko.observable(ko.utils.unwrapObservable(item.SubmittedAgency));
        self.AgencyID = ko.observable(ko.utils.unwrapObservable(item.AgencyID));
        self.CountryID = ko.observable(ko.utils.unwrapObservable(item.CountryID));
        self.PoliceStationID = ko.observable(ko.utils.unwrapObservable(item.PoliceStationID));
        self.CaseStatusID = ko.observable(ko.utils.unwrapObservable(item.CaseStatusID));
        self.CaseStatusTitle = ko.observable(ko.utils.unwrapObservable(item.CaseStatusTitle) || '');
        self.Province = ko.observable(ko.utils.unwrapObservable(item.Province));
        self.ProvinceID = ko.observable(ko.utils.unwrapObservable(item.ProvinceID));
        self.District = ko.observable(ko.utils.unwrapObservable(item.District));
        self.DistrictID = ko.observable(ko.utils.unwrapObservable(item.DistrictID));
        self.SubmittedAgencyPhone = ko.observable(ko.utils.unwrapObservable(item.SubmittedAgencyPhone));
        self.InvestOfficerName = ko.observable(ko.utils.unwrapObservable(item.InvestOfficerName));
        self.InvestOfficerPhone = ko.observable(ko.utils.unwrapObservable(item.InvestOfficerPhone));
        self.SubmittedPersonName = ko.observable(ko.utils.unwrapObservable(item.SubmittedPersonName));
        self.SubmittedPersonPhone = ko.observable(ko.utils.unwrapObservable(item.SubmittedPersonPhone));
        self.SubmittedPersonBelt = ko.observable(ko.utils.unwrapObservable(item.SubmittedPersonBelt));
        self.VersionNo = ko.observable(ko.utils.unwrapObservable(item.VersionNo));
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.PoliceStationTitle = ko.observable(ko.utils.unwrapObservable(item.PoliceStationTitle || ''));
        self.Email = ko.observable(ko.utils.unwrapObservable(item.Email || ''));
        self.IsSendEmail = ko.observable(ko.utils.unwrapObservable(item.IsSendEmail));
        self.UMSTrackNo = ko.observable(ko.utils.unwrapObservable(item.UMSTrackNo));//CR:005
        self.FIMSDistrictID = ko.observable(ko.utils.unwrapObservable(item.FIMSDistrictID));
        self.FIMSPoliceStationID = ko.observable(ko.utils.unwrapObservable(item.FIMSPoliceStationID));
        self.Countries = ko.observableArray();
        self.Provinces = ko.observableArray();
        self.Districts = ko.observableArray();

        self.PoliceStations = ko.observableArray();
        self.Agencies = ko.observableArray();
        self.CaseStatuses = ko.observableArray();

        self.Documents = ko.observableArray();

        if (ko.utils.unwrapObservable(item.Documents) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(item.Documents), function (doc) {
                self.Documents.push(new DocumentModel(doc));
            });
        }

        //if (ko.utils.unwrapObservable(item.Districts) != null) {
        //    self.Districts([]);
        //    ko.utils.arrayForEach(ko.utils.unwrapObservable(item.Districts), function (doc) {
        //        self.Districts.push(new CommonModel(doc));
        //    });
        //}

        //if (ko.utils.unwrapObservable(item.Provinces) != null) {
        //    self.Provinces([]);
        //    ko.utils.arrayForEach(ko.utils.unwrapObservable(item.Provinces), function (doc) {
        //        self.Provinces.push(new CommonModel(doc));
        //    });
        //}
        /**************************************************************/
        //self.UserID = ko.observable(item.UserID);
        //self.UserTypeID = ko.observable(item.UserTypeID);
        /**************************************************************/

    }
    else {
        /**************************************************************/
        //self.UserTypeID = ko.observable();
        //self.UserID = ko.observable();
        /**************************************************************/
        self.RowNo = ko.observable(null);
        self.ID = ko.observable(null);
        self.CaseID = ko.observable('');
        self.CaseNo = ko.observable('');
        self.OldCaseNo = ko.observable('');
        self.FIRNo = ko.observable('');
        self.LetterNo = ko.observable('');
        self.CaseDate = ko.observable('');
        self.SubmittedAgency = ko.observable('');
        self.AgencyID = ko.observable('');
        self.CountryID = ko.observable('');
        self.PoliceStationID = ko.observable('');
        self.CaseStatusID = ko.observable('');
        self.Province = ko.observable('');
        self.ProvinceID = ko.observable('1');
        self.District = ko.observable('');
        self.DistrictID = ko.observable('1');
        self.SubmittedAgencyPhone = ko.observable('');
        self.InvestOfficerName = ko.observable('');
        self.InvestOfficerPhone = ko.observable('');
        self.SubmittedPersonName = ko.observable('');
        self.SubmittedPersonPhone = ko.observable('');
        self.SubmittedPersonBelt = ko.observable('');
        self.VersionNo = ko.observable(0);
        self.CaseStatusTitle = ko.observable('');
        self.PoliceStationTitle = ko.observable('');
        self.UMSTrackNo = ko.observable('');//CR:005
        self.FIMSDistrictID = ko.observable(null);
        self.FIMSPoliceStationID = ko.observable(null);
        self.Countries = ko.observableArray();
        self.Provinces = ko.observableArray();
        self.Districts = ko.observableArray();

        self.PoliceStations = ko.observableArray();
        self.Agencies = ko.observableArray();
        self.CaseStatuses = ko.observableArray();

        self.Documents = ko.observableArray();
        self.Status = ko.observable(true);
    }

    //self.DistrictID.subscribe(function (newValue) {
    //    if (newValue != undefined && newValue != null) {
    //        var filterObj = ko.utils.arrayFilter(ref_policeStations, function (p) {
    //            return p.DistrictID() == newValue;
    //        });
    //        return filterObj != null && filterObj.length > 0 && filterObj != '' ? self.District(filterObj[0].Title()) : '';
    //    }
    //});


    self.ProvinceID.subscribe(function (newValue) {
        if (newValue != undefined && newValue != null) {

            var filter_district = [];
            filter_district = ko.utils.arrayFilter(ref_district, function (item) {
                return item.ProvinceID() == newValue && item.Status();
            });
            viewModel.main().editModel().Districts([]);
            viewModel.main().editModel().Districts(filter_district);

        }
        else {
            viewModel.main().editModel().Districts([]);
        }
    });

    self.DistrictID.subscribe(function (newValue) {
        if (newValue != undefined && newValue != null) {

            var filter_policeStations = [];
            filter_policeStations = ko.utils.arrayFilter(ref_policeStations, function (item) {
                return item.DistrictID() == newValue && item.Status();
            });
            viewModel.main().editModel().PoliceStations([]);
            viewModel.main().editModel().PoliceStations(filter_policeStations);

        }
        else {
            viewModel.main().editModel().PoliceStations([]);
        }
    });

    self.attachment = ko.observable(new DocumentModel(null));

    self.changeFile = function (file, title) {
        if (ValidateSameFile(file.name)) {
            var mod = new DocumentModel(null);

            mod.Size(file.size);
            mod.Type(file.type);
            mod.Title(title);
            mod.File(file);
            mod.FileName(file.name);

            self.Documents.push(mod);
        }
        else {
            NotifyMe("info|Document has been attached already.");
        }
        self.attachment(new DocumentModel(null));
    }

    self.removeFile = function (mod) {


        if (mod.Url() != null && mod.Url() != '' && mod.Url() != undefined) {
            var objIP = getHostnameIP();
            $.ajax({
                url: "EvidenceSubmision.aspx/DeleteDocument",
                type: 'POST',
                data: "{ipAddress:\"" + objIP.ip + "\", computerName:\"" + objIP.hostName + "\",  documentURL:\"" + mod.Url() + "\", documentTitle:\"" + mod.Title() + "\", documentFileName:\"" + mod.FileName() + "\", caseID:\"" + viewModel.main().editModel().CaseID() + "\"}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    //if (NotifyMe(data.d.Notification)) {
                    viewModel.main().editModel().Documents.remove(mod);
                    //}
                },
                error: function (er, _rr) {
                    // NotifyMe("error|" + er.statusText);
                    NotifyMe("Gen_error|" + error.statusText);
                }
            });
        }
        else {
            self.Documents.remove(this);
        }
    }

    self.downloadFile = function (mod) {

        var objIP = getHostnameIP();
        var downloadStatusID = 2;

        $.ajax({
            url: "EvidenceSubmision.aspx/SaveInfo",
            type: 'POST',
            data: "{ipAddress:\"" + objIP.ip + "\",computerName:\"" + objIP.hostName + "\", documentFileName:\"" + mod.Title() + "\", caseID:\"" + viewModel.main().editModel().CaseID() + "\", fileProcessStatusID:\"" + downloadStatusID + "\"}",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                //if (NotifyMe(data.d.Notification)) {
                //    window.location.href = '../Download.aspx?SourceUrl=' + mod.Url();
                //}
                window.location.href = '../Download.aspx?SourceUrl=' + mod.Url();
            },
            error: function (request) {

            }
        });
    }
}
function EvidenceEmailModel(item) {
    var self = this;
    self.RowIndex = ko.observable(0);
    //alert(ko.utils.unwrapObservable(item.FIRNo));
    // alert(ko.utils.unwrapObservable(item.PoliceStationTitle));
    // alert(ko.utils.unwrapObservable(item.Districts));

    // var b = ko.utils.unwrapObservable(item.PoliceStationTitle);
    // var c = ko.utils.unwrapObservable(item.Districts);

    if (item != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));
        self.CaseID = ko.observable(ko.utils.unwrapObservable(item.CaseID) || '');
        self.CaseNo = ko.observable(ko.utils.unwrapObservable(item.CaseNo) || '');
        self.Email = ko.observable(ko.utils.unwrapObservable(item.Email || ''));
        self.UMSTrackNo = ko.observable(ko.utils.unwrapObservable(item.UMSTrackNo || ''));
        self.FIRNo = ko.observable(ko.utils.unwrapObservable(item.FIRNo));
        self.PoliceStationTitle = ko.observable(ko.utils.unwrapObservable(item.PoliceStationTitle || '--'));
        self.District = ko.observable(ko.utils.unwrapObservable(item.District || '--'));

        self.FIMSDistrictID = ko.observable(ko.utils.unwrapObservable(item.FIMSDistrictID || null));
        self.FIMSPoliceStationID = ko.observable(ko.utils.unwrapObservable(item.FIMSPoliceStationID || null));

        self.SubmittedAgency = ko.observable(ko.utils.unwrapObservable(item.SubmittedAgency));
        self.Documents = ko.observableArray();

        if (ko.utils.unwrapObservable(item.Documents) != null) {
            ko.utils.arrayForEach(ko.utils.unwrapObservable(item.Documents), function (doc) {
                self.Documents.push(new DocumentModel(doc));
            });
        }
    }
    else {
        self.ID = ko.observable(null);
        self.CaseID = ko.observable(null);
        self.CaseNo = ko.observable(null);
        self.Email = ko.observable(null);
        self.UMSTrackNo = ko.observable(null);
        self.FIRNo = ko.observable(null);
        self.PoliceStationTitle = ko.observable(null);
        self.District = ko.observable(null);
        self.SubmittedAgency = ko.observable();
        self.Documents = ko.observableArray();

    }


}
function CommonModel(itm) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(itm.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(itm.Title));
    self.Status = ko.observable(ko.utils.unwrapObservable(itm.Status));
    self.DistrictID = ko.observable(ko.utils.unwrapObservable(itm.DistrictID) || 0);
}



function DistrictModel(itm) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(itm.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(itm.Title));
    self.ProvinceID = ko.observable(ko.utils.unwrapObservable(itm.ProvinceID));
    self.Status = ko.observable(ko.utils.unwrapObservable(itm.Status));
}


function PoliceStationModel(itm) {
    var self = this;
    self.ID = ko.observable(ko.utils.unwrapObservable(itm.ID));
    self.Title = ko.observable(ko.utils.unwrapObservable(itm.Title));
    self.DistrictID = ko.observable(ko.utils.unwrapObservable(itm.DistrictID));
    self.Status = ko.observable(ko.utils.unwrapObservable(itm.Status));
}

function DocumentModel(doc, file) {
    var self = this;
    if (doc != null) {
        self.ID = ko.observable(ko.utils.unwrapObservable(doc.ID));
        self.Title = ko.observable(ko.utils.unwrapObservable(doc.Title));
        self.Url = ko.observable(ko.utils.unwrapObservable(doc.Url));
        self.Status = ko.observable(ko.utils.unwrapObservable(doc.Status));
        self.Type = ko.observable(ko.utils.unwrapObservable(doc.Type));
        self.Size = ko.observable(ko.utils.unwrapObservable(doc.Size));
        self.File = ko.observable(file);
        self.FileRef = ko.observable(ko.utils.unwrapObservable(doc.FileRef || ''));
        self.FileName = ko.observable(ko.utils.unwrapObservable(doc.FileName || ''));
    }
    else {
        self.ID = ko.observable();
        self.Title = ko.observable('');
        self.Url = ko.observable();
        self.Status = ko.observable();
        self.Type = ko.observable();
        self.Size = ko.observable();
        self.File = ko.observable();
        self.FileRef = ko.observable();
        self.FileName = ko.observable('');
    }
}

function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

function LoadRecord(mod, isLoad) {
    //  isLoad = isLoad || false;
    var searchText = mod != undefined ? mod.SearchText() || "" : "";
    var agencyID = null, statusID = null, provinceID = null, districtID = null, stationID = null;

    var agencyID = mod != undefined ? mod.filterModel().AgencyID() || "" : "";
    var statusID = mod != undefined ? mod.filterModel().CaseStatusID() || "" : "";
    var provinceID = mod != undefined ? mod.filterModel().ProvinceID() || "" : "";
    var districtID = mod != undefined ? mod.filterModel().DistrictID() || "" : "";
    var stationID = mod != undefined ? mod.filterModel().PoliceStationID() || "" : "";

    var pageNo = mod != undefined ? mod.PageNo() || "1" : "1";

    var param = {
        ID: searchText,
        PageIndex: pageNo,
        // PageSize: $scope.pageSizeSelected,
        AgencyID: agencyID,
        StatusID: statusID,
        DistrictID: districtID,
        ProvinceID: provinceID,
        StationID: stationID,
        IsLoad: isLoad
    };
    var jsonStr = ko.toJSON(param);
    $.ajax({
        url: "EvidenceSubmision.aspx/GetRecords",
        type: 'POST',
        //data: "{pageNo : '" + pageNo + "', searchText : '" + searchText + "'}",
        data: "{paramObject : '" + jsonStr + "'}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (NotifyMe(data.d.Notification)) {
                viewModel.main(new wrapperModel(data.d));
                viewModel.main().editModel(new EvidenceModel(null));
                //if (!isLoad) {
                if (ko.utils.unwrapObservable(data.d.Countries) != null) {
                    viewModel.main().editModel().Countries([]);
                    ref_countries = [];
                    ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Countries), function (doc) {
                        if (doc.Status)
                            viewModel.main().editModel().Countries.push(new CommonModel(doc));
                        ref_countries.push(new CommonModel(doc));
                    });
                }
                else {
                    viewModel.main().editModel().Countries(ref_countries);
                }

                if (ko.utils.unwrapObservable(data.d.Agencies) != null) {
                    viewModel.main().editModel().Agencies([]);
                    ref_agencies = [];
                    ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Agencies), function (doc) {
                        if (doc.Status) {
                            viewModel.main().editModel().Agencies.push(new CommonModel(doc));
                            viewModel.main().AgenciesFilter.push(new CommonModel(doc));
                        }
                        ref_agencies.push(new CommonModel(doc));
                    });
                }
                else {
                    viewModel.main().editModel().Agencies(ref_agencies);
                    viewModel.main().AgenciesFilter(ref_agencies);
                }

                if (ko.utils.unwrapObservable(data.d.CaseStatuses) != null) {
                    viewModel.main().editModel().CaseStatuses([]);
                    ref_caseStatuses = [];
                    ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.CaseStatuses), function (doc) {
                        if (doc.Status) {
                            viewModel.main().editModel().CaseStatuses.push(new CommonModel(doc));
                            viewModel.main().CaseStatusesFilter.push(new CommonModel(doc));
                        }
                        ref_caseStatuses.push(new CommonModel(doc));
                    });
                }
                else {
                    viewModel.main().editModel().CaseStatuses(ref_caseStatuses);
                    viewModel.main().CaseStatusesFilter(ref_caseStatuses);
                }

                if (ko.utils.unwrapObservable(data.d.Districts) != null) {
                    viewModel.main().editModel().Districts([]);
                    ref_district = [];
                    ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Districts), function (doc) {
                        //if (doc.Status)
                        //    viewModel.main().editModel().Districts.push(new DistrictModel(doc));
                        ref_district.push(new DistrictModel(doc));
                    });
                }

                if (ko.utils.unwrapObservable(data.d.Provinces) != null) {
                    viewModel.main().editModel().Provinces([]);
                    ref_province = [];
                    ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.Provinces), function (doc) {
                        if (doc.Status) {
                            viewModel.main().editModel().Provinces.push(new CommonModel(doc));
                            viewModel.main().ProvincesFilter.push(new CommonModel(doc));
                        }
                        ref_province.push(new CommonModel(doc));
                    });
                }
                else {
                    viewModel.main().editModel().Provinces(ref_province);
                    viewModel.main().ProvincesFilter(ref_province);
                }

                if (ko.utils.unwrapObservable(data.d.PoliceStations) != null) {
                    viewModel.main().editModel().PoliceStations([]);
                    ref_policeStations = [];
                    ko.utils.arrayForEach(ko.utils.unwrapObservable(data.d.PoliceStations), function (doc) {
                        //if (doc.Status)
                        //    viewModel.main().editModel().PoliceStations.push(new PoliceStationModel(doc));
                        ref_policeStations.push(new PoliceStationModel(doc));
                    });
                }

                //}
                //else {

                //}

                viewModel.main().editModel().CountryID(160);
                viewModel.main().filterModel().AgencyID(agencyID);
                // viewModel.main().filterModel().CaseStatusID(statusID);
                viewModel.main().editModel().CaseStatusID(3);
                // viewModel.main().filterModel().ProvinceID(provinceID);
                viewModel.main().editModel().ProvinceID(1);
                viewModel.main().filterModel().DistrictID(districtID);
                // viewModel.main().filterModel().PoliceStationID(stationID);
                viewModel.main().editModel().PoliceStationID(3);
            }
        },
        error: function (error, dr) {
            //  NotifyMe("error|" + error.statusText);
            NotifyMe("Gen_error|" + error.statusText);
        }
        //error: function (request) {
        //}
    });
}



$(document).ready(function () {
    if ($("input[type='hidden'][id*=hdnUserType]").val() != "4") {
        $(".btnSave").prop("disabled", true);
    }
    $('form').validationEngine({ promptPostion: 'bottomLeft' });
    //LoadRecord();
    LoadRecord(new wrapperModel(null), true);
    //viewModel.main(new wrapperModel(null));
    ko.applyBindings(viewModel);
});

function ValidateSameFile(name) {
    var ret = true;
    if (viewModel.main().editModel().Documents().length > 0) {
        var filter_msg = ko.utils.arrayFilter(viewModel.main().editModel().Documents(), function (fil) {
            return ko.utils.unwrapObservable(fil.FileName) == ko.utils.unwrapObservable(name);
        });
        ret = filter_msg != null && filter_msg.length > 0 && filter_msg != '' ? false : true;
    }
    return ret;
}

