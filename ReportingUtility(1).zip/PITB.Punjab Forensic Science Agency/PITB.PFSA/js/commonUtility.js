﻿var imported = document.createElement("script");
imported.src = "../../plugins/jLoader/jquery.confirm.min.js";
document.getElementsByTagName("head")[0].appendChild(imported);

//------- Confirmation Dialog ----------
function ConfirmDialogYesNo(title, text, callback) {
    var result = false;
    $.confirm({
        title: title,
        text: text,
        confirmButton: 'Yes',
        cancelButton: 'No',
        confirm: function () {
            callback(true);
        },
        cancel: function () {
            callback(false);
        }
    });
}
