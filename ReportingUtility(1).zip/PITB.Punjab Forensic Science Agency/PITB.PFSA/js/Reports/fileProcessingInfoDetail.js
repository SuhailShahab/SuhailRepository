﻿
// CR:                  Usman Mirza             10-Jun-2015            Addition of Dropdown for mapping FC District ID 


var viewModel = new ViewModel();
var all_division = [];

ko.bindingHandlers.datepickerMinDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "minDate", value);
    }
};

ko.bindingHandlers.datepickerMaxDate = {
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        current = $(element).datepicker("option", "maxDate", value);
    }
};
//** DatePicker Custom binding **\\
ko.bindingHandlers.datepicker = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var $el = $(element);
        //initialize datepicker with some optional options
        var options = allBindingsAccessor().datepickerOptions || {};
        //  .timepickerOptions || { 'timeFormat': 'h:i A' }

        $el.datepicker(options);
        //handle the field changing
        ko.utils.registerEventHandler(element, "change", function () {
            var observable = valueAccessor();
            observable($el.datepicker("getDate"));
        });
        //handle disposal (if KO removes by the template binding)
        ko.utils.domNodeDisposal.addDisposeCallback(element, function () {
            $el.datepicker("destroy");
        });
    },
    update: function (element, valueAccessor) {
        var value = ko.utils.unwrapObservable(valueAccessor()),
        $el = $(element),
        current = $el.datepicker("getDate");
        if (value.toString().indexOf("Date") > 0) {
            value = new Date(parseInt(value.substring(6, 19)));
        }
        if (value - current !== 0) {
            $el.datepicker("setDate", value);
            valueAccessor()($el.datepicker("getDate"));
        }
    }
};
ko.bindingHandlers.validate = {
    init: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        ko.utils.registerEventHandler(element, "blur", function () {
            $(element).validationEngine('validate');
        });
    },
    update: function (element, valueAccessor, allBindingsAccessor) {
        var text = allBindingsAccessor().value || {};
        if (text() != undefined) {
            $(element).validationEngine('validate');
        }
    }
};

function wrapperModel(items) {
    var self = this;

    self.editModel = ko.observable();

    self.Reload = function () {
        LoadRecord();
    }




}

function fileProcessingViwModel(item) {
    var self = this;

    if (item != null) {
        //self.ID = ko.observable(ko.utils.unwrapObservable(item.ID));     
        self.Status = ko.observable(ko.utils.unwrapObservable(item.Status));
        self.DepartmentID = ko.observable(ko.utils.unwrapObservable(item.DepartmentID));
        self.FileProcessStatusID = ko.observable(ko.utils.unwrapObservable(item.FileProcessStatusID));
        self.UserID = ko.observable(ko.utils.unwrapObservable(item.UserID));
        self.dtpFrom = ko.observable(ko.utils.unwrapObservable(item.dtpFrom).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.dtpFrom).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.dtpFrom));
        self.dtpTo = ko.observable(ko.utils.unwrapObservable(item.dtpTo).toString().indexOf('/Date(') == 0 ? new Date(parseInt(ko.utils.unwrapObservable(item.dtpTo).substring(6, 19))).format('d/M/yyyy') : ko.utils.unwrapObservable(item.dtpTo));
        self.ReportUrl = ko.observable(ko.utils.unwrapObservable(item.ReportUrl));
        self.LoginName = ko.observable(ko.utils.unwrapObservable(item.LoginName));
        self.ReportTypeName = ko.observable(ko.utils.unwrapObservable(item.ReportTypeName));
        self.CaseNo = ko.observable(ko.utils.unwrapObservable(item.CaseNo));
    }
    else {

        self.DepartmentID = ko.observable(-1);
        self.FileProcessStatusID = ko.observable(-1);
        self.UserID = ko.observable(-1);
        self.Status = ko.observable(true);
        self.dtpFrom = ko.observable('');
        self.dtpTo = ko.observable('');
        self.ReportUrl = ko.observable('');
        self.LoginName = ko.observable('');
        self.ReportTypeName = ko.observable('');
        self.CaseNo = ko.observable('');

    }


    //self.allDivision = ko.observableArray();
    self.Departments = ko.observableArray();
    self.FilteProcessStatues = ko.observableArray();
    self.Users = ko.observableArray();

    self.showReport = function () {

        var reportUrl = self.ReportUrl();      
        var loginName = self.LoginName();        
        var loginID = self.UserID();
       // var caseNo = self.CaseNo();
       
        // alert(loginID);
        var dtForm, dtTo, uid, fpsid, dpid;
        if (self.DepartmentID() == undefined) {
            dpid = '';
        }
        else {
            dpid = self.DepartmentID();
        }
        if (self.dtpFrom() == undefined) {
            dtForm = '';
        }
        else {
            dtForm = new Date(self.dtpFrom()).format("d/M/yyyy");
        }
        if (self.dtpTo() == undefined) {
            dtTo = '';
        }
        else {
            dtTo = new Date(self.dtpTo()).format("d/M/yyyy");
        }
        if (self.UserID() == undefined) {
            uid = '';
        }
        else {
            uid = self.UserID();
        }
        if (self.FileProcessStatusID() == undefined) {
            fpsid = '';
        }
        else {
            fpsid = self.FileProcessStatusID();
        }


        reportUrl = reportUrl + "rptFileProcessing.aspx?DepartmentID=";
        // $("#rptframe").attr("src", "http://localhost:63678/rptFileProcessing.aspx?DepartmentID=" + dptID + "&UserID=" + userID + "&FileActionID=" + fileActionID + "&IsIncludeDate=" + IsIncludeDate+"&IsShowReport=true");
        var url = reportUrl + dpid + "&UserID=" + uid + "&FileActionID=" + fpsid + "&IsShowReport=true&FromDate=" + dtForm + "&ToDate=" + dtTo + "&LoginName=" + loginName + "&LoginID=" + loginID + "&rptTypeName=" + self.ReportTypeName() + "&caseNo=" + self.CaseNo();
       //alert(url);
        $("#rptframe").attr("src", url);

        return false;

    }



    self.getUserByDeptID = function () {
        // alert('Get user')
        // alert(self.DepartmentID())
        if (self.DepartmentID() > 0) {
            $.ajax({
                url: "FileProcessingInfoDetail.aspx/GetUsersByDepartmentID",
                type: 'POST',
                data: "{departmentID : '" + ko.toJSON(self.DepartmentID()) + "'}",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    //viewModel.main(new wrapperModel(data.d));
                    self.Users([]);
                    if (data.d.Users != null) {
                        // viewModel.main().editModel().Users([]);

                        ko.utils.arrayForEach(data.d.Users, function (item) {
                            self.Users.push(new commonModel(item));

                        });
                    }

                },
                error: function (request) {

                }
            });
        }
        else { self.Users([]); }
    }

}


function commonModel(model) {
    var self = this;
    self.ID = ko.observable(model.ID);
    self.Title = ko.observable(model.Title);
    self.UserID = ko.observable(model.UserID || 0);
    self.EmployeeName = ko.observable(model.EmployeeName || null);
}


function ViewModel() {
    var self = this;
    self.main = ko.observable();
}

$(document).ready(function () {
    $('form').validationEngine({ promptPostion: 'bottomLeft' });
    LoadRecord();
    ko.applyBindings(viewModel);
});

function LoadRecord() {
    $.ajax({
        url: "FileProcessingInfoDetail.aspx/GetRecords",
        type: 'POST',
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            viewModel.main(new wrapperModel(data.d));
            viewModel.main().editModel(new fileProcessingViwModel(null));


            viewModel.main().editModel().Departments([]);
            viewModel.main().editModel().LoginName(data.d.LoginName);
            viewModel.main().editModel().ReportTypeName(data.d.ReportTypeName);
            viewModel.main().editModel().ReportUrl(data.d.ReportUrl);

            ko.utils.arrayForEach(data.d.Departments, function (item) {
                if (data.d.Departments != null)
                    viewModel.main().editModel().Departments.push(new commonModel(item));

            });

            ko.utils.arrayForEach(data.d.FilteProcessStatues, function (item) {
                if (data.d.FilteProcessStatues != null)
                    viewModel.main().editModel().FilteProcessStatues.push(new commonModel(item));

            });




        },
        error: function (request) {

        }
    });
}
