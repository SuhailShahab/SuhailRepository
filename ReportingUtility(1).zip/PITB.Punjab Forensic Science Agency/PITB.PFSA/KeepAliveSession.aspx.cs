﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA
{
    public partial class KeepAliveSession : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        /// <summary>
        /// Logout Session 
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static string Logout()
        {
            HttpCookie aCookie;
            string cookieName;
            int limit = HttpContext.Current.Request.Cookies.Count;
            for (int i = 0; i < limit; i++)
            {
                cookieName = HttpContext.Current.Request.Cookies[i].Name;
                aCookie = new HttpCookie(cookieName);
                aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                HttpContext.Current.Response.Cookies.Add(aCookie); // overwrite it
            }
            HttpContext.Current.Session.Abandon();
            
            return "index.aspx";
        }

        /// <summary>
        /// Maintain Session 
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static void MaintainSession()
        {
            if (CurrentUser.LoginName != null)
            {
                UserModel currentUser = new UserBLL().GeLoginUserInfoByLogin(CurrentUser.LoginName);
                if (currentUser != null)
                {

                    //HttpContext.Current.Response.Cookies["LoginID"].Value = currentUser.UserID.ToString();
                    //HttpContext.Current.Response.Cookies["LoginID"].Expires = DateTime.Now.AddDays(1);
                    //HttpContext.Current.Response.Cookies["UserName"].Value = currentUser.UserName.ToString();
                    //HttpContext.Current.Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(1);
                    HttpContext.Current.Session["CurrentUser"] = currentUser;
                    HttpContext.Current.Session["LoginID"] = currentUser.UserID;
                    HttpContext.Current.Session["EmployeeName"] = currentUser.EmployeeName;
                }
            }
        }
    }
}