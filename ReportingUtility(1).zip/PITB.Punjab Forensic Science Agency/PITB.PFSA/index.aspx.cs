﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.Inquiry;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.CustomExceptions;
using PITB.PFSA.BLL.EvidenceForms;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;

namespace PITB.PFSA.Layouts
{
    public partial class index : PageBase
    {

        /// <summary>
        /// Page Load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                
                //string a = Request.UserHostAddress;
                //string b = Request.UserHostName;
                //string c = System.Net.Dns.GetHostEntry(Request.UserHostAddress).HostName;
                if (!string.IsNullOrEmpty(CurrentUser.LoginName))
                {
                    hdnUserID.Value = CurrentUser.LoginName.ToString();
                    hdnUserTypeID.Value = CurrentUser.UserTypeID.ToString();
                }
               
                if (!IsPostBack)
                {

                    //under pageload of logout.aspx
                    if (Request.QueryString["action"] != null)
                    {
                        // Session.Abandon();
                        // // Session.Clear();
                        // HttpCookie aCookie;
                        // string cookieName;
                        // int limit = Request.Cookies.Count;

                        //// Response.Cookies.Clear();

                        // for (int i = 0; i < limit; i++)
                        // {
                        //     cookieName = Request.Cookies[i].Name;
                        //     aCookie = new HttpCookie(cookieName);
                        //     aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                        //     //aCookie.Expires = DateTime.Now.AddSeconds(-1); // make it expire yesteday
                        //     //aCookie.Value = DateTime.Now.AddDays(-1).ToString();
                        //     Response.Cookies.Add(aCookie); // overwrite it
                        //     //Response.Cookies.Set(aCookie);
                        //     //Response.Cookies.Remove(cookieName);
                        // }
                    }
                }
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "Page_Load", 0, PageNames.Home, CurrentUser.GetSessionUserInfo()));
            }
        }


        [WebMethod(EnableSession = true)]
        public static string ValidateUser(string loginName, string password)
        {
            string url = "index.aspx";
            try
            {

                // new ADMethod().ValidateCredentialsloginName, password);

                // if (true)
                if (AuthenticationAD(loginName, password))
                {
                    UserModel currentUser = new UserBLL().GeLoginUserInfoByLogin(loginName);
                    if (currentUser != null)
                    {

                        //HttpContext.Current.Response.Cookies["LoginID"].Value = currentUser.UserID.ToString();
                        //HttpContext.Current.Response.Cookies["LoginID"].Expires = DateTime.Now.AddDays(1);
                        //HttpContext.Current.Response.Cookies["UserName"].Value = currentUser.UserName.ToString();
                        //HttpContext.Current.Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(1);
                        HttpContext.Current.Session["CurrentUser"] = currentUser;
                        HttpContext.Current.Session["SessionID"] = HttpContext.Current.Session.SessionID;
                        HttpContext.Current.Session["LoginID"] = currentUser.UserID;
                        HttpContext.Current.Session["EmployeeName"] = currentUser.EmployeeName;
                        //  HttpContext.Current.Session["IsWithinPremesis"] = currentUser.IsWithinPremesis; ;
                        if (!currentUser.Url.Contains("index"))
                        {
                            url = currentUser.Url;

                        }
                        //  HttpContext.Current.Response.Redirect(currentUser.Url, false);




                    }
                    else
                    {
                        //User is not registered.Please contact with administrator.
                        url = "error|User is not registered.Please contact with administrator.";
                    }

                }
                else
                {
                    //Invalid password or login.
                    url = "error|Invalid password or login.";
                    // System.Web.UI.ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.WebControls.Button), "Message", "alert('" + CutomMessage.InvalidLogin + "');", true);
                }
            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "ValidateUser", 0, PageNames.Home, CurrentUser.GetSessionUserInfo()));
            }
            return url;
        }


        [WebMethod(EnableSession = true)]
        public static string ResetPassword(string loginName, string oldPassword, string newPassword)
        {
            string url = string.Empty;
            try
            {

                int ret = new UserBLL().ResetPassword(loginName, oldPassword, newPassword, CurrentUser.LoginID, CurrentUser.UserTypeID);
                if (ret > 0)
                {
                    //if (CurrentUser.LoginID != 1)
                    //{
                    //    HttpCookie aCookie;
                    //    string cookieName;
                    //    int limit = HttpContext.Current.Request.Cookies.Count;
                    //    for (int i = 0; i < limit; i++)
                    //    {
                    //        cookieName = HttpContext.Current.Request.Cookies[i].Name;
                    //        aCookie = new HttpCookie(cookieName);
                    //        aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                    //        HttpContext.Current.Response.Cookies.Add(aCookie); // overwrite it
                    //    }
                    //}
                    HttpContext.Current.Session.Abandon();
                    url = Convert.ToString(ret);
                }
            }
            catch (BusinessException ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "ResetPassword", 1, PageNames.Home, CurrentUser.LoginID));
                return LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message);

            }
            catch (Exception ex)
            {
                LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "ResetPassword", 1, PageNames.Home, CurrentUser.LoginID));
                return LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message);

            }
            return url;
        }

        /// <summary>
        /// Get Records info 
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static PremesisDocument GetAllEvidenceData(string id)
        {
            List<DocumentModel> documents = null;
            PremesisDocument premesisDocument = new PremesisDocument();
            UserModel userInfo = CurrentUser.GetSessionUserInfo();
            try
            {
                if (userInfo != null)
                {
                    if (userInfo.IsWithinPremesis == null)
                    {
                        userInfo.IsWithinPremesis = false;
                    }
                    // If Login user Is Within Premesis
                    if (Convert.ToBoolean(userInfo.IsWithinPremesis))
                    {
                        // If Login user Open the Page
                        if (userInfo != null && userInfo.UserID.HasValue)
                        {
                            // show all Documents of Created person and His Given District Base
                            if (string.IsNullOrEmpty(id))
                                documents = new EvidenceInformationBLL().GetEvidenceDataByUserID(userInfo);
                            else
                                documents = new EvidenceInformationBLL().GetEvidenceFormDataByID(id, userInfo); // Show all document of Case Id Base
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(id)) // Show document on case ID Base
                                documents = new EvidenceInformationBLL().GetEvidenceFormDataByID(id, userInfo);
                        }

                        premesisDocument.Documents = documents;
                        premesisDocument.ModelName = "documentsModal";
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(userInfo.CellNumber))
                        {
                            premesisDocument.ModelName = "documentsModalPremesis";
                            premesisDocument.IsWithinPremesis = userInfo.IsWithinPremesis;
                            premesisDocument.CellNumber = userInfo.CellNumber;
                            int? pinNumber = premesisDocument.PinNumber = GetPinNumber();
                            premesisDocument.URL = ConfigurationHelper.APIUrl;
                            int? userID = userInfo.UserID;
                            string emailAddress = userInfo.EMail;

                            int data = new EvidenceInformationBLL().SavePinNumber(userID, pinNumber);

                            string subject = "Punjab Forensic Science Agency (Pin Number)";
                            string body = "<div>Dear " + userInfo.EmployeeName + ", <br /><br />  Your requested Pin Number is " + pinNumber + ".<br /><br /> Best Regards. <br /> PFSA </div>";
                            try
                            {
                                if (!string.IsNullOrEmpty(userInfo.EMail) && Convert.ToBoolean(ConfigurationHelper.EnableEmail))
                                    LazyMultiton<SendEmail>.Instance().MailSend(subject, body, emailAddress);
                            }
                            catch (Exception ex)
                            {
                               // LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetAllEvidenceData", 1, PageNames.Home, CurrentUser.LoginID));
                                //  premesisDocument.Notification = "error|" + ex.Message;
                                string errorCode = string.Empty;
                                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllEvidenceData", 1, PageNames.Home, userInfo)).ToString();
                                if (ConfigurationHelper.IsShowGeneralMsg)
                                {
                                    premesisDocument = new PremesisDocument("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                                }
                                else
                                {
                                    premesisDocument = new PremesisDocument("error|" + ex.Message);
                                }

                            }
                        }
                        else
                        {
                            premesisDocument.Notification = "info| Please contact with administrator. Register your phone number and email address.";

                        }

                    }
                }
                else
                {
                    premesisDocument.Notification = "info| Please contact with admin. You are not register user.";
                }

            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetAllEvidenceData", 1, PageNames.Home, CurrentUser.LoginID));
                //premesisDocument.Notification = "error|" + ex.Message;

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllEvidenceData", 1, PageNames.Home, userInfo)).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    premesisDocument = new PremesisDocument("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    premesisDocument = new PremesisDocument("error|" + ex.Message);
                }
            }

            return premesisDocument;
        }

        /// <summary>
        /// Get Records info 
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static PremesisDocument Resend(string id)
        {
            PremesisDocument premesisDocument = new PremesisDocument();
            UserModel userInfo = CurrentUser.GetSessionUserInfo();
            try
            {
                if (userInfo != null)
                {
                    // If Login user Is Within Premesis

                    if (!string.IsNullOrEmpty(userInfo.CellNumber) && !string.IsNullOrEmpty(userInfo.EMail))
                    {
                        premesisDocument.CellNumber = userInfo.CellNumber;

                        int? pinNumber = premesisDocument.PinNumber = GetPinNumber();
                        premesisDocument.URL = ConfigurationHelper.APIUrl;
                        int? userID = userInfo.UserID;
                        string emailAddress = userInfo.EMail;

                        int data = new EvidenceInformationBLL().SavePinNumber(userID, pinNumber);

                        string subject = "Punjab Forensic Science Agency ( Pin Number )";
                        string body = "<div>Dear " + userInfo.EmployeeName + ", <br /><br />  Your requested Pin Number is " + pinNumber + ".<br /><br /> Best Regards. <br /> PFSA </div>";
                        try
                        {
                            if (!string.IsNullOrEmpty(userInfo.EMail) && Convert.ToBoolean(ConfigurationHelper.EnableEmail))
                                LazyMultiton<SendEmail>.Instance().MailSend(subject, body, emailAddress);
                        }
                        catch (Exception ex)
                        {
                            string errorCode = string.Empty;
                            errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Resend", 1, PageNames.Home, userInfo)).ToString();
                            if (ConfigurationHelper.IsShowGeneralMsg)
                            {
                                premesisDocument = new PremesisDocument("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                            }
                            else
                            {
                                premesisDocument = new PremesisDocument("error|" + ex.Message);
                            }
                           // LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "Resend", 1, PageNames.Home, CurrentUser.LoginID));

                        }

                    }
                    else
                    {
                        premesisDocument.Notification = "info| Please contact with administrator. Register your phone number and email address.";

                    }


                }

            }
            catch (Exception ex)
            {
                // LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetAllUserData", 1, PageNames.Home, CurrentUser.LoginID));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "Resend", 1, PageNames.Home, userInfo)).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    premesisDocument = new PremesisDocument("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    premesisDocument = new PremesisDocument("error|" + ex.Message);
                }
            }

            return premesisDocument;
        }

        /// <summary>
        /// Get Records info 
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static PremesisDocument GetDataForVerification(int? pinNumber, string caseIDForVerify)
        {
            List<DocumentModel> documents = null;
            PremesisDocument premesisDocument = new PremesisDocument();
            UserModel userInfo = CurrentUser.GetSessionUserInfo();
            try
            {
                if (userInfo != null)
                {
                    int? userID = userInfo.UserID;
                    premesisDocument.VerifyResult = new EvidenceInformationBLL().GetVerifyPinNumber(userID, pinNumber);

                    if (premesisDocument.VerifyResult > 0)
                    {

                        if (userInfo != null && userInfo.UserID.HasValue)
                        {
                            if (string.IsNullOrEmpty(caseIDForVerify))
                                documents = new EvidenceInformationBLL().GetEvidenceDataByUserID(userInfo);
                            else
                                documents = new EvidenceInformationBLL().GetEvidenceFormDataByID(caseIDForVerify, userInfo); // Show all document of Case Id Base
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(caseIDForVerify)) // Show document on case ID Base
                                documents = new EvidenceInformationBLL().GetEvidenceFormDataByID(caseIDForVerify, userInfo);
                        }

                        premesisDocument.Documents = documents;
                        premesisDocument.ModelName = "documentsModal";
                    }
                }

            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetDataForVerification", 1, PageNames.Home, CurrentUser.LoginID));
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetDataForVerification", 1, PageNames.Home, userInfo)).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    premesisDocument = new PremesisDocument("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    premesisDocument = new PremesisDocument("error|" + ex.Message);
                }
            }

            return premesisDocument;
        }
        /// <summary> 
        /// Get Records info 
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static EvidenceModelView GetAllEvidenceInformation(string id)
        {
            // List<EvidenceModel> evidenceModel = new List<EvidenceModel>();
            EvidenceModelView model = new EvidenceModelView();
            UserModel userInfo = CurrentUser.GetSessionUserInfo();
            try
            {
                // If Login user Open the Page
                if (userInfo != null && userInfo.UserID.HasValue && userInfo.UserTypeID.HasValue)
                {

                    // show all evidences of Created person and His Given District Base
                    if (string.IsNullOrEmpty(id))
                        model.Evidences = new EvidenceInformationBLL().GetAllEvidenceInformationByID(userInfo.UserID.Value, userInfo.DistrictID.Value, userInfo.UserTypeID.Value);
                    else
                        model.Evidences = new EvidenceInformationBLL().GetEvidenceInformationByID(id, userInfo.UserID.Value, userInfo.DistrictID.Value);
                }
                else
                {
                    model.Notification = "info| Please contact with administrator. You are not register user.";

                }

            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllEvidenceInformation", 1, PageNames.Home, userInfo)).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new EvidenceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new EvidenceModelView("error|" + ex.Message);
                }
                // LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetAllEvidenceInformation", 1, PageNames.Home, CurrentUser.LoginID));
            }

            return model;
        }

        [WebMethod]
        //public static EvidenceModelView GetAllEvidenceInformation1(string id, int? pageIdex, int pageSize, int agencyID, int statusID, int provinceID, int districtID, int stationID)
        public static EvidenceModelView GetAllEvidenceInformation1(string paramObject )
        {
            IndexSearchModel paramModel = null;
            paramModel = new JavaScriptSerializer().Deserialize<IndexSearchModel>(paramObject);
            EvidenceModelView model = new EvidenceModelView();

            UserModel userInfo = CurrentUser.GetSessionUserInfo();
            try
            {


                // If Login user Open the Page
                if (userInfo != null && userInfo.UserID.HasValue && userInfo.UserTypeID.HasValue)
                {
                    paramModel.UserID = userInfo.UserID;
                    paramModel.UserTypeID = userInfo.UserTypeID;
                    model = LazyBaseSingleton<EvidenceInformationBLL>.Instance.GetEvidencePagingDataBySearch(paramModel);
                    if (paramModel.IsLoad == true)
                    {
                        if (userInfo.UserTypeID != UserTypeNames.Department.GetHashCode())
                        {
                            model.Agencies = LazyBaseSingleton<SubmittedAgencyBLL>.Instance.GetAllAgencies().OrderBy(p => p.Title).ToList();
                            model.CaseStatuses = LazyBaseSingleton<CaseStatusBLL>.Instance.GetAllStatues();
                            model.Provinces = new ProvinceBLL().GetAllActiveProvinces();
                            model.PoliceStations = LazyBaseSingleton<PoliceStationBLL>.Instance.GetAllPoliceStationsByDistrictID(null);

                            if (userInfo.UserTypeID == UserTypeNames.Admin.GetHashCode() || userInfo.UserTypeID == UserTypeNames.CompetentAuthority.GetHashCode())
                            {
                                model.Districts = new GeneralDistrictBLL().GetAllGeneralDistrictsByUserID(userInfo.UserID).ToList();
                            }
                            else
                                model.Districts = new GeneralDistrictBLL().GetAllGeneralDistricts().ToList();
                        }
                    }
                }
                else
                {
                    model.Notification = "info| Please contact with administrator. You are not register user.";

                }

            }
            catch (Exception ex)
            {

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllEvidenceInformation", 1, PageNames.Home, userInfo)).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new EvidenceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new EvidenceModelView("error|" + ex.Message);
                }
                // LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetAllEvidenceInformation", 1, PageNames.Home, CurrentUser.LoginID));
            }

            return model;
        }
        [WebMethod]
        public static EvidenceModelView GetAllEvidenceInformationSearch(string id, string pageNo, string searchText)
        {
            EvidenceModelView evidenceModelView = new EvidenceModelView();

            UserModel userInfo = CurrentUser.GetSessionUserInfo();
            try
            {
                // If Login user Open the Page
                if (userInfo != null && userInfo.UserID.HasValue && userInfo.UserTypeID.HasValue)
                {

                    #region "Set Page Size"
                    int PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["PageSize"].ToString());
                    #endregion


                    evidenceModelView = new EvidenceModelView();
                    int PageNo = Convert.ToInt32(pageNo);

                    if (PageNo != 0)

                        evidenceModelView.PageNo = PageNo;
                    else
                    {
                        evidenceModelView.PageNo = 1;
                        PageNo = 1;
                    }


                    List<EvidenceModel> evidenceModel = new List<EvidenceModel>();

                    // show all evidences of Created person and His Given District Base
                    if (string.IsNullOrEmpty(id))
                        evidenceModel = new EvidenceInformationBLL().GetAllEvidenceInfromationByIdDBP(userInfo.UserID.Value, userInfo.DistrictID.Value, userInfo.UserTypeID.Value, PageNo, PageSize, searchText);
                    else
                        evidenceModel = new EvidenceInformationBLL().GetEvidenceInfromationByIDForDashBoardDBP(userInfo.UserID.Value, userInfo.DistrictID.Value, PageNo, PageSize, searchText);


                    evidenceModelView.Evidences = new List<EvidenceModel>();
                    evidenceModelView.Evidences = evidenceModel;

                    if (evidenceModelView.Evidences.Count > 0)
                        evidenceModelView.TotalCount = evidenceModelView.Evidences[0].RESULT_COUNT.Value;

                }

            }
            catch (Exception ex)
            {
                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllEvidenceInformation", 1, PageNames.Home, userInfo)).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    evidenceModelView = new EvidenceModelView("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    evidenceModelView = new EvidenceModelView("error|" + ex.Message);
                }
                // LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "GetAllEvidenceInformation", 1, PageNames.Home, CurrentUser.LoginID));
            }

            return evidenceModelView;
        }

        /// <summary>
        /// Delete  Documents
        /// </summary>
        /// <param name="documentURL">Document URL</param>
        /// <param name="documentID">Document ID</param>
        /// <param name="caseID">Selected Case ID</param>
        /// <returns></returns>

        [WebMethod]
        public static DocumentModel DeleteDocument(string ipAddress, string computerName, string documentURL, string documentTitle, string documentFileName, string caseID)
        {
            DocumentModel model = new DocumentModel();

            try
            {
                model.Notification = Common.DeleteDocuments(documentURL, documentTitle, documentTitle, caseID, TableName.tblEvidenceInformations);
                FileProcessingInfoModel fileModel = new FileProcessingInfoModel()
                {
                    CaseID = caseID,
                    CreatedBy = CurrentUser.LoginID,
                    FileProcessStatusID = FileProcessName.FileDelete.GetHashCode(),
                    FileName = documentFileName,
                    ClientIPAddress = ipAddress,
                    ComputerName = computerName
                };

                //Add User Information for file delete
                if (model.Notification.Contains("success|"))
                {
                    int? result = LazyBaseSingleton<FileProcessingInfoBLL>.Instance.AddFileProcessingInfo(fileModel);
                }



            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "DeleteDocument Case ID:" + caseID, 1, PageNames.Home, CurrentUser.GetSessionUserInfo()));
                //model.Notification = LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message + "Case ID" + caseID);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllEvidenceInformation", 1, PageNames.Home, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new DocumentModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new DocumentModel("error|" + ex.Message);
                }
            }

            LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            return model;
        }

        [WebMethod]
        public static FileProcessingInfoModel SaveInfo(string ipAddress, string computerName, string documentFileName, string caseID, string fileProcessStatusID)
        {
            FileProcessingInfoModel model = null;

            try
            {

                model = new FileProcessingInfoModel()
               {
                   CaseID = caseID,
                   CreatedBy = CurrentUser.LoginID,
                   FileProcessStatusID = string.IsNullOrEmpty(fileProcessStatusID) ? FileProcessName.None.GetHashCode() : Convert.ToInt32(fileProcessStatusID),
                   FileName = documentFileName,
                   ClientIPAddress = ipAddress,
                   ComputerName = computerName
               };

                //Add User Information for file delete
                int? result = LazyBaseSingleton<FileProcessingInfoBLL>.Instance.AddFileProcessingInfo(model);


            }
            catch (Exception ex)
            {
                //LazyBaseSingleton<CommonBLL>.Instance.SaveErrorLog(new ErrorLogModel(ex, "DeleteDocument Case ID:" + caseID, 1, PageNames.Home, CurrentUser.GetSessionUserInfo()));
                //if (model == null)
                //    model = new FileProcessingInfoModel();
                //model.Notification = LazyBaseSingleton<CommonBLL>.Instance.NotificationErrorMsg(ex.Message + "Case ID" + caseID);

                string errorCode = string.Empty;
                errorCode = LazyBaseSingleton<CommonBLL>.Instance.AddErrorLogs(new ErrorLogModel(ex, "GetAllEvidenceInformation", 1, PageNames.Home, CurrentUser.GetSessionUserInfo())).ToString();
                if (ConfigurationHelper.IsShowGeneralMsg)
                {
                    model = new FileProcessingInfoModel("error|" + ConfigurationHelper.GeneralMsg + "<br/>" + errorCode);
                }
                else
                {
                    model = new FileProcessingInfoModel("error|" + ex.Message);
                }
            }

            LazyBaseSingleton<CommonBLL>.Instance.NotificationSuccess(model, CutomMessage.SavedSuccessfully);
            return model;
        }



        #region Private method
        public static int GetPinNumber()
        {
            Random random = new Random();
            int key = random.Next(1000, 2000);
            return key;
            //  premesisDocument.PinNumber = key;
        }

        #endregion




        #region User Validation
        internal static bool AuthenticationAD(string userName, string password)
        {
            bool isvalidate = false;

            try
            {
                if (ConfigurationHelper.IsByPassActiveDiretory)
                {
                    //Validate User form databae
                    UserBLL userBLL = new UserBLL();
                    isvalidate = userBLL.IsValidateUser(userName, password);
                }
                else
                {
                    //Validate User form Active Directory
                    isvalidate = new ADMethod().ValidateCredentials(userName, password);
                }

            }
            catch (Exception ex)
            {
                throw ex;

            }
            return isvalidate;
        }
        //internal static bool AuthenticationAD(string userName, string password)
        //{
        //    bool isvalidate = false ;
        //    //"LDAP://" + Domain + "/" + DomainDC
        //  //  DirectoryEntry entry = new DirectoryEntry("LDAP://" + ConfigurationHelper.DomainName + "/" + ConfigurationHelper.ActiveDirectoryDC , userName, pasword);

        //    string userNameWithDomainName = ConfigurationHelper.DomainName + @"\" + userName;
        //    DirectoryEntry entry = new DirectoryEntry("LDAP://" + ConfigurationHelper.DomainName, userNameWithDomainName, password);
        //    try
        //    {
        //        if (ConfigurationHelper.IsByPassActiveDiretory)
        //        {
        //            //            //Validate User form databae
        //            UserBLL userBLL = new UserBLL();
        //            isvalidate = userBLL.IsValidateUser(userName, password);
        //        }
        //        else
        //        {
        //            //Validate User form Active Directory
        //            object obj = entry.NativeObject;
        //            DirectorySearcher search = new DirectorySearcher(entry);
        //            search.Filter = "(SAMAccountName=" + userName + ")";
        //            search.PropertiesToLoad.Add("cn");
        //            SearchResult result = search.FindOne();


        //            if (result == null)
        //            {
        //                isvalidate = false;
        //            }
        //            else
        //            {
        //                isvalidate = true;
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;

        //    }
        //    return isvalidate;
        //}


        //private static bool AuthenticationAD(string userName, string password)
        //{
        //    bool isvalidate = true;
        //    try
        //    {
        //        if (ConfigurationHelper.IsByPassActiveDiretory)
        //        {
        //            //Validate User form databae
        //            UserBLL userBLL = new UserBLL();
        //            isvalidate = userBLL.IsValidateUser(userName, password);

        //        }
        //        else
        //        {
        //            //Validate User form Active Directory
        //            using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, ConfigurationHelper.DomainName, "ABUNDANTCODEDOMAIN"))
        //            {
        //                isvalidate = pc.ValidateCredentials(userName, password);
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        isvalidate = false;
        //        throw ex;

        //    }
        //    return isvalidate;
        //}

        //public static bool fnValidateUser()
        //{
        //    bool validation;
        //    try
        //    {
        //        LdapConnection lcon = new LdapConnection
        //                (new LdapDirectoryIdentifier((string)null, false, false));
        //        NetworkCredential nc = new NetworkCredential(Environment.UserName,
        //                               "MyPassword", Environment.UserDomainName);
        //        lcon.Credential = nc;
        //        lcon.AuthType = AuthType.Negotiate;
        //        // user has authenticated at this point,
        //        // as the credentials were used to login to the dc.
        //        lcon.Bind(nc);
        //        validation = true;
        //    }
        //    catch (LdapException)
        //    {
        //        validation = false;
        //    }
        //    return validation;
        //}


        //protected void Page_Init(object sender, EventArgs e)
        //{
        //    try
        //    {

        //    }
        //    catch
        //    {
        //    }

        //}

        //protected override void OnUnload(EventArgs e)
        //{
        //    base.OnUnload(e);


        //}


        protected void btnAuthenticate_Click(object sender, EventArgs e)
        {

        }
        #endregion
    }

   
}