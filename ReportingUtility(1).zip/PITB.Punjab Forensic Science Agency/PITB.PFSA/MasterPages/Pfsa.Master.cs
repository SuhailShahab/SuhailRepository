﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BLL.RightsManager.BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.MasterPages
{
    public partial class Pfsa : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                // Build Magement Level Menus 
                BuildManagementMenus();

                if (!IsPostBack)
                {
                    this.SetVisibility();
                   
                }
            }
            catch(Exception ex)
            {

                throw ex;
            }
            
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            try
            {
                btnLogin.Visible = true;
                btnLogout.Visible = false;
                Session.Abandon();
                HttpCookie aCookie;
                string cookieName;
                int limit = Request.Cookies.Count;
                for (int i = 0; i < limit; i++)
                {
                    cookieName = Request.Cookies[i].Name;
                    aCookie = new HttpCookie(cookieName);
                    aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                    Response.Cookies.Add(aCookie); // overwrite it
                }
                Response.Redirect("index.aspx", false);
            }
            catch (Exception ex)
            {

            }
            
        }

        #region Custom Methods

        /// <summary>
        /// Set the visibility of controls
        /// Set Url of Management link according to user type
        /// </summary>
        internal void SetVisibility()
        {
            btnLogout.Visible =(CurrentUser.LoginID.HasValue && CurrentUser.LoginID>0);
            btnLogin.Visible = !btnLogout.Visible;
            btnResetPassword.Visible = btnLogout.Visible;
            lblUserName.Visible = btnLogout.Visible;
            rptSubMenu.Visible = btnLogout.Visible;

            if (rptSubMenu.Visible)
            {
                lblUserName.Text = CurrentUser.UserDisplayName + "<span class='caret'></span>";                
            }
            else 
            {
                lblUserName.Text = CurrentUser.UserDisplayName;
            }

           
        }

        private void BuildManagementMenus()
        {
            if ( CurrentUser.LoginID.HasValue && CurrentUser.LoginID != null)
            {
                DataTable dtPermitedMenus = new MenuBLL().GetMagementMenuByUser(CurrentUser.LoginID.Value);
                rptSubMenu.DataSource = dtPermitedMenus;
                rptSubMenu.DataBind();
            }
        }

       
        #endregion 
    }
}