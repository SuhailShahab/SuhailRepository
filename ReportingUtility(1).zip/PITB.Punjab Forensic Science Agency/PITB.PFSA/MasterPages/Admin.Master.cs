﻿using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.MasterPages
{
    public partial class Admin : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    
                    if (CurrentUser.LoginID.HasValue)
                    {
                        string staticPageName = System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath);

                        if (LazyBaseSingleton<CommonBLL>.Instance.GetUserPageAccess(CurrentUser.LoginID, staticPageName) == false)
                        {
                            //System.Web.UI.ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.WebControls.Button), "Message", "alert('" + CutomMessage.InvalidUserRights  + "');", true);
                           Response.Redirect("../../Layouts/Error.aspx", false);
                        }


                    }
                    else
                    {
                        //System.Web.UI.ScriptManager.RegisterStartupScript(this, typeof(System.Web.UI.WebControls.Button), "Message", "alert('" + CutomMessage.InvalidRegisterUser + "');", true);
                        Response.Redirect("../../index.aspx", false);
                    }
                     
                     
                }
               
                if (CurrentUser.LoginID.HasValue)
                {

                    //if (!CurrentUser.Url.Contains("index"))
                    //{
                    //    Response.Redirect("EvidenceSubmision.aspx", false);
                    //}
                    //else
                    //{
                        BuildMenu(CurrentUser.LoginID);
                        lblLoginUserName.Text = CurrentUser.UserDisplayName;
                    //}

                }
            }
            catch (Exception ex)
            {

            }

        }

        #region "Methods"

        protected void lnkLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            /*
           // HttpCookie aCookie;
            string cookieName;
            int limit = Request.Cookies.Count;
            for (int i = 0; i < limit; i++)
            {
                cookieName = Request.Cookies[i].Name;
                aCookie = new HttpCookie(cookieName);
                aCookie.Expires = DateTime.Now.AddDays(-1); // make it expire yesterday
                Response.Cookies.Add(aCookie); // overwrite it
            }*/

           /// Response.Redirect(Request.ApplicationPath.ToString() + "/index.aspx");
            //try
            //{

                //if ( Request.ApplicationPath!="/PITB.PFSA")
                    Response.Redirect("../../index.aspx", false);
               // else
               //     Response.Redirect("index.aspx", false);
            //}
            //catch
            //{ }



          
        }

        private void ValidateUser(string UserName)
        {
            DataSet ds = new UserBLL().GetUserByLogin(UserName.ToLower());
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataTable dt = ds.Tables[0];
                string userType = Convert.ToString(dt.Rows[0]["UserType"]);
                if (Convert.ToBoolean(dt.Rows[0]["IsActive"].ToString()) == false)
                {
                    Response.Redirect("../../PITBFC/Error/Error.aspx?Key=UserInactive", false);
                }
                else
                {
                    HyperLink brand = (HyperLink)this.FindControl("lnkbrand");
                    //string url = Request.ApplicationPath.ToString() + Convert.ToString(dt.Rows[0]["NavigateUrl"]);
                    string url = "../../" + Convert.ToString(dt.Rows[0]["NavigateUrl"]);



                    brand.NavigateUrl = url;
                    //contain current login user information like users's id, department, section, sub section etc
                    Session["UserTable"] = dt;
                    Session["UserPermittedServices"] = ds.Tables[1];    // contain current login allowd services on dashboard

                    // set login user employee name
                    ((Label)this.FindControl("lblLoginUserName")).Text = dt.Rows[0]["EmployeeName"].ToString();
                }

                BuildMenu(1);
            }
            else
            {
                Response.Redirect("../../PITBFC/Error/Error.aspx?Key=UserNotRegister", false);
            }
        }

        private void BuildMenu(int? LoginID)
        {
            Panel pnlMenu = (Panel)this.FindControl("pnlMenu");
            StringBuilder menu = new StringBuilder();

            try
            {
                DataSet ds = new MenuBLL().GetMenuByUser(LoginID.Value);
                DataTable dt = ds.Tables[0];
                if (dt.Rows.Count > 0)
                {
                    dt.DefaultView.Sort = "Sort";

                    menu.AppendLine("<div id='sidebar' class='nav-collapse collapse'><ul class='sidebar-menu'>");

                    foreach (DataRow dr in dt.Rows)     //loop for Features
                    {
                        menu.AppendLine("<li class='sub-menu'>");

                        if (Convert.ToBoolean(dr["HasChild"].ToString()) == true)
                        {
                            menu.AppendLine("<a href='javascript:;' class=''><i class='fa fa-chevron-right'></i>");
                            menu.AppendLine("<span>" + dr["MenuName"].ToString() + "</span><span class='arrow'></span></a>");
                            menu.AppendLine("<ul class='sub'>");

                            DataRow[] drObjects = ds.Tables[1].Select("AppFeatureID = " + dr["FeatureID"].ToString());
                            foreach (DataRow odr in drObjects)   // loop for Objects
                            {
                                menu.AppendLine("<li><a class='' href='" + odr["URL"] + "'>" + odr["Name"].ToString() + "</a></li>");
                            }   //end objects loop

                            menu.AppendLine("</ul></li>");
                        }
                        else
                            menu.AppendLine("<a class='' href='" + dr["URL"] + "' title='" + dr["MenuName"] + "'><i class='fa fa-dashboard'></i><span>" + dr["Name"].ToString() + "</span></a></li>");

                    }   //end features loop

                    menu.AppendLine("</ul></div>");

                    pnlMenu.Controls.Add(new LiteralControl(menu.ToString()));
                }
            }
            catch (Exception ex)
            {
                pnlMenu.Controls.Add(new LiteralControl("<span>" + ex.Message + "</span>"));
            }
        }

        #endregion
    }
}