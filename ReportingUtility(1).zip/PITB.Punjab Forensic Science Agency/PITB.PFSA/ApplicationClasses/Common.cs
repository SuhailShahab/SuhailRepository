﻿
using Microsoft.SharePoint;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.Inquiry;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;

namespace PITB.PFSA.ApplicationClasses
{

  public  class Common
    {
        /// <summary>
        /// Save Error Log Info
        /// </summary>
        /// <param name="erroLog"></param>
        /// <returns></returns>
        public  int AddErrorLog(ErrorLogModel erroLog)
        {
            return new CommonBLL().SaveErrorLog(erroLog);
        }
        
        /// <summary>
        /// Upload attached documents to common document library and Update in DB its URL
        /// </summary>
        /// <param name="request"></param>
        public void UpdateFiles(HttpRequest request,TableName tableName)
        {
            string caseID = request.Form["CaseID"].ToString();

           // DataTable dtUser = Common.GetSessionUserTable();
            DataTable dtUser = new DataTable();
      
            List<string> Urls = null;
            List<string> Titles = null;
            List<string> FileNames = null;

            if (request.Files.Count > 0)
            {
                try
                {
                    List<DocumentModel> collection = new List<DocumentModel>();

                    // fetch all documents and add into model collection
                    for (int i = 0; i < request.Files.Count; i++)
                    {
                        HttpPostedFile postFile = request.Files[i];
                        byte[] FileBytes = new Common().GetFileContent(postFile.InputStream);

                        DocumentModel dm = new DocumentModel();
                        dm.FileRef = System.IO.Path.GetFileName(postFile.FileName);
                        dm.Title = request.Form["Title" + i].ToString();
                        dm.Type = request.Form["Type" + i].ToString();
                        dm.FileBytes = FileBytes;
                        collection.Add(dm);
                    }

                    // ============================================================================================================== //
                    // ========================= upload  document in Document Center site - Start ============================= //
                    if (string.IsNullOrEmpty(caseID) == false)
                    {
                        Urls = UploadDocuments(caseID, collection, dtUser);
                        Titles = DocumentsTitles(collection);
                        FileNames = DocumentsFileName(collection);
                    }
                    
                    // =========================== upload  document in Document Center site - End ============================= //
                    // ============================================================================================================== //

                    // ============================================================================================================== //
                    // ============================== save  document urls to database - End =================================== //
                    string documentURLs = string.Join("|", Urls.ToArray());
                    string documentTitles = string.Join("|", Titles.ToArray());
                    string documentFileNames = string.Join("|", FileNames.ToArray());
                    if (string.IsNullOrEmpty(documentURLs) == false)
                        new CommonBLL().SaveDocumentsURL(tableName, caseID, documentURLs, documentTitles, documentFileNames);
                }
                catch (Exception ex)
                {
                    //Common.AddErrorLog(new ErrorLogModel(ex, "UpdateFiles", 0, ServiceCodes.none, pageName));
                    throw ex;
                }
            }
        }
        public void UpdateFiles(HttpRequest request, TableName tableName,string ipAddress,string hostName)
        {
            string caseID = request.Form["CaseID"].ToString();

            // DataTable dtUser = Common.GetSessionUserTable();
            DataTable dtUser = new DataTable();

            List<string> Urls = null;
            List<string> Titles = null;
            List<string> FileNames = null;

            if (request.Files.Count > 0)
            {
                try
                {
                    List<DocumentModel> collection = new List<DocumentModel>();
                    
                    // fetch all documents and add into model collection
                    for (int i = 0; i < request.Files.Count; i++)
                    {
                        HttpPostedFile postFile = request.Files[i];
                        byte[] FileBytes = new Common().GetFileContent(postFile.InputStream);

                        DocumentModel dm = new DocumentModel();
                        dm.FileRef = System.IO.Path.GetFileName(postFile.FileName);
                        dm.Title = request.Form["Title" + i].ToString();
                        dm.Type = request.Form["Type" + i].ToString();
                        dm.FileBytes = FileBytes;
                        collection.Add(dm);
                    }

                    // ============================================================================================================== //
                    // ========================= upload  document in Document Center site - Start ============================= //
                    if (string.IsNullOrEmpty(caseID) == false)
                    {
                        Urls = UploadDocuments(caseID, collection, dtUser);
                        Titles = DocumentsTitles(collection);
                        FileNames = DocumentsFileName(collection);
                    }

                    // =========================== upload  document in Document Center site - End ============================= //
                    // ============================================================================================================== //

                    // ============================================================================================================== //
                    // ============================== save  document urls to database - End =================================== //
                    string documentURLs = string.Join("|", Urls.ToArray());
                    string documentTitles = string.Join("|", Titles.ToArray());
                    string documentFileNames = string.Join("|", FileNames.ToArray());
                    if (string.IsNullOrEmpty(documentURLs) == false)
                    {
                        // new CommonBLL().SaveDocumentsURL(tableName, caseID, documentURLs, documentTitles, documentFileNames);
                        DocumentParametes parameters = new DocumentParametes();
                        parameters.TableName = tableName;
                        parameters.ID = caseID;
                        parameters.DocumentURL = documentURLs;
                        parameters.DocumentTitles = documentTitles;
                        parameters.DocumentFileNames = documentFileNames;
                        parameters.DocumentInfo = collection;
                        parameters.FileProcessingInfoModel = new BE.Lookups.FileProcessingInfoModel();
                        parameters.FileProcessingInfoModel.ClientIPAddress = ipAddress;
                        parameters.FileProcessingInfoModel.ComputerName = hostName;
                        parameters.FileProcessingInfoModel.CreatedBy = CurrentUser.LoginID;
                        parameters.FileProcessingInfoModel.CaseID = caseID;
                        parameters.FileProcessingInfoModel.FileProcessStatusID = FileProcessName.FileUpload.GetHashCode();
                        LazyBaseSingleton<CommonBLL>.Instance.SaveDocumentsURL(parameters);
                    }
                       
                }
                catch (Exception ex)
                {
                    //Common.AddErrorLog(new ErrorLogModel(ex, "UpdateFiles", 0, ServiceCodes.none, pageName));
                    throw ex;
                }
            }
        }

        /// <summary>
        /// CR:006
        /// <summary>
        /// Get bytes of provided file
        /// </summary>
        /// <param name="inputstm">File Streem</param>
        /// <returns>Return Curernt Bytes</returns>
        public Byte[] GetFileContent(System.IO.Stream inputstm)
        {
            Stream fs = inputstm;
            BinaryReader br = new BinaryReader(fs);
            Int32 lnt = Convert.ToInt32(fs.Length);

            byte[] bytes = br.ReadBytes(lnt);

            return bytes;
        }

        /// <summary>
        /// Upload documents to document center site
        /// </summary>
        /// <param name="caseID">Selected CaseID</param>
        /// <param name="Documents">Selected Documents </param>
        /// <param name="dtUser">Current Login User</param>
        /// <returns></returns>
        private static List<string> UploadDocuments(string caseID, List<DocumentModel> Documents, DataTable dtUser)
        {

            string gFileName = string.Empty;
            List<string> URLs = new List<string>();
            if (Documents.Count > 0)
            {
                SPList lstDocument = null;
                SPFolder folder = null;

                SPSecurity.RunWithElevatedPrivileges(delegate()
                {

                    using (SPSite site = new SPSite(ConfigurationManager.AppSettings["DocumentDownloadURL"].ToString()))     // open document center site
                    {
                        site.AllowUnsafeUpdates = true;

                        using (SPWeb web = site.OpenWeb())
                        {
                            web.AllowUnsafeUpdates = true;


                            SPGroup groups = web.Groups[ConfigurationManager.AppSettings["DocumentCenterGroup"].ToString()];
                            SPUser user = null;
                           // string LoginName = GetLoginClaim();
                           // string LoginName = web.EnsureUser(CurrentUser.LoginName).LoginName;
                            string LoginName = web.EnsureUser("pfsa.admin").LoginName;

                            try
                            {
                                user = groups.Users[LoginName];
                            }
                            catch (Exception ex)
                            {
                                // new Common().AddErrorLog(ex, "DeleteDocument", 1, ServiceCodes.ArmLicense, PageNames.ArmsLicense);
                                //new Common().AddErrorLog("DeleteDocument", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                                // result = "error|" + ex.Message;
                                throw ex;
                            }
                            
                            try
                            {
                                lstDocument = web.Lists[ConfigurationManager.AppSettings["CommonDocuments"].ToString()];
                                string folderURL = lstDocument.RootFolder + "/" + caseID;

                                folder = web.GetFolder(folderURL);

                                // create cnic folder if folder not exist in block common documents libraries
                                if (!folder.Exists)
                                {
                                    SPFolder spFolder = lstDocument.RootFolder;

                                    // create folder
                                    SPListItem itm = lstDocument.Items.Add(site.Url + "/" + spFolder.ToString(), SPFileSystemObjectType.Folder, caseID);
                                   // itm["caseID"] = caseID;
                                    itm["Title"] = caseID;
                                    itm["Author"] = 1;
                                    itm["Editor"] = 1;
                                    itm.Update();

                                    folder = web.GetFolder(folderURL);
                                }

                                foreach (DocumentModel dm in Documents)
                                {

                                    // ========================================================================================== //
                                    // ===================== upload document to the exists folder - Start ======================= //
                                    SPFileCollection spFileCollection = lstDocument.RootFolder.Files;

                                    gFileName = string.Empty;
                                    string[] splitFileName = dm.FileRef.Split('.');
                                    gFileName = splitFileName[0].ToString() + "_" + caseID + "." + splitFileName[1].ToString();

                                   // string fileURL = folder.ServerRelativeUrl + "/" + dm.FileRef;
                                    string fileURL = folder.ServerRelativeUrl + "/" + gFileName;

                                    // attach the file in current selected folder
                                    SPFile spAddFile = spFileCollection.Add(fileURL, dm.FileBytes,true);
                                    SPListItem itm = spAddFile.Item;
                                    itm["FileLeafRef"] = dm.FileRef;
                                    itm["Title"] = dm.Title;
                                    itm["Name"] = gFileName;  
                                    itm["Author"] = user.ID;
                                    itm["Editor"] = user.ID;
                                    itm["Created"] = DateTime.Now;

                                    if (!URLs.Any(item => item == fileURL))
                                        URLs.Add(fileURL);

                                    /// Update SP List
                                    itm.Update();

                                    // ===================== upload document to the exists folder - End ========================= //
                                    // ========================================================================================== //

                                }   // end of foreach loop
                            }
                            catch (Exception ex)
                            {
                               // new Common().AddErrorLog(ex, "DeleteDocument", 1, ServiceCodes.ArmLicense, PageNames.ArmsLicense);
                                //new Common().AddErrorLog("DeleteDocument", ex.Message, ex.StackTrace, ex.Source, 1, DateTime.Now);
                               // result = "error|" + ex.Message;
                                throw ex;
                            }
                            web.AllowUnsafeUpdates = false;
                        }

                        site.AllowUnsafeUpdates = false;
                    }
                });
            }

            return URLs;
        }

        /// <summary>
        /// Get Documents Titles
        /// </summary>
        /// <param name="Documents">Documents List</param>
        /// <returns></returns>
        private static List<string> DocumentsTitles( List<DocumentModel> Documents)
        {
            List<string> Titles = new List<string>();
            if (Documents.Count > 0)
            {
                try
                {
                    foreach (DocumentModel dm in Documents)
                    {
                        Titles.Add(dm.Title);
                    }   // end of foreach loop
                }
                catch (Exception ex)
                {
                    throw ex;

                }    
            }
            return Titles;
        }


        /// <summary>
        /// Get Documents File Names
        /// </summary>
        /// <param name="Documents">Documents List</param>
        /// <returns></returns>
        private static List<string> DocumentsFileName(List<DocumentModel> Documents)
        {
            List<string> FileNames = new List<string>();
            if (Documents.Count > 0)
            {
                try
                {
                    foreach (DocumentModel dm in Documents)
                    {
                        FileNames.Add(dm.FileRef);
                    }   // end of foreach loop
                }
                catch (Exception ex)
                {
                    throw ex;

                }
            }
            return FileNames;
        }


        /// <summary>
        /// Delete the Documents from Sharepoint Document Library
        /// </summary>
        /// <param name="documentURL">Document URL</param>
        /// <param name="documentID">Selected Document ID</param>
        /// <param name="id">selected  ID</param>
        /// <param name="tableName">Table Name</param>
        /// <param name="dtUser">Current Login User Info</param>
        /// <returns></returns>
        public static string DeleteDocuments(string documentURL, string documentTitle, string documentFileName, string id, TableName tableName)
        {        
            string result = "";
            string documentsURL = string.Empty;
            string documentsTitle = string.Empty;
            string documentsFileName = string.Empty;

            try
            {
                DataTable dtItems = new DataTable();
                dtItems = new CommonBLL().GetDocuments(tableName.ToString(), id);            // get documentsURL and documentIDs from district level db
              
                if (dtItems.Rows.Count > 0)
                {
                    DataRow dtRow = dtItems.Rows[0];
                    string[] arrDocumentURL = dtRow["DocumentURL"].ToString().Split('|');
                    string[] arrDocumentTitle = dtRow["DocumentTitle"].ToString().Split('|');
                    string[] arrDocumentFileName = dtRow["DocumentFileName"].ToString().Split('|');
                   
             
                    documentsURL = BuildDocumentsURL(documentURL, arrDocumentURL);
                    documentsTitle = BuildDocumentsTitle(documentTitle, arrDocumentTitle);
                    documentsFileName = BuildDocumentsTitle(documentFileName, arrDocumentFileName);

                    int? ret = new CommonBLL().UpdateDocuments(documentsURL, documentsTitle, documentsFileName, tableName.ToString(), id);
                    if (ret != null && ret > 0)
                        result = "success|Document deleted successfully";
                }

               // SPWeb currentWeb = SPContext.Current.Web;
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {

                    #region "Document Center"
                    using (SPSite site = new SPSite(ConfigurationManager.AppSettings["DocumentCenterURL"].ToString()))     // open document center site
                    {
                        site.AllowUnsafeUpdates = true;

                        using (SPWeb web = site.OpenWeb())
                        {

                            web.AllowUnsafeUpdates = true;
                            SPGroup groups = web.Groups[ConfigurationManager.AppSettings["DocumentCenterGroup"].ToString()];
                            SPUser user = null;
                            //string LoginName = web.EnsureUser(CurrentUser.LoginName).LoginName;
                            string LoginName = web.EnsureUser("pfsa.admin").LoginName;

                            try
                            {
                                user = groups.Users[LoginName];
                            }
                            catch
                            { }

                            documentURL = documentURL.Replace(ConfigurationManager.AppSettings["DocumentCenterURL"].ToString(), "");
                            
                            // Get document from library against provided url
                            SPFile file = web.GetFile(documentURL);
                            if (file.Exists)
                            {
                                file.Delete();
                            }

                            web.AllowUnsafeUpdates = false;
                        }

                        site.AllowUnsafeUpdates = false;
                    }
                    #endregion
                });
            }
            catch (Exception ex)
            {
                // Common.AddErrorLog(new ErrorLogModel(ex, "DeleteDocument", 0, serviceName, pageName));
                result = "error|" + ex.Message;
            }

            return result;
        }

        /// <summary>
        /// Build Documents URL
        /// </summary>
        /// <param name="documentURL">Current Deleted Document URL</param>
        /// <param name="arrDocumentUrls">Document url list</param>
        /// <returns></returns>
        private static string BuildDocumentsURL(string documentURL, string[] arrDocumentUrls)
        {
            string DocumentsURL;
            List<string> DocumentURLs = new List<string>();

            for (int i = 0; i < arrDocumentUrls.Length; i++)
            {
                string url = "";

                documentURL = documentURL.Replace(ConfigurationManager.AppSettings["DocumentCenterURL"].ToString() + "/", "");              //ConfigurationManager.AppSettings["DocumentCenterURL"].ToString()

                if (arrDocumentUrls[i].Substring(0, 1) == "/")
                    url = arrDocumentUrls[i].Substring(1, arrDocumentUrls[i].Length - 1);
                else
                    url = arrDocumentUrls[i];

                if (url != documentURL)
                {
                    DocumentURLs.Add(arrDocumentUrls[i]);
                }
            }

            DocumentsURL = string.Join("|", DocumentURLs);
            return DocumentsURL;
        }

        /// <summary>
        /// Build Documents Title
        /// </summary>
        /// <param name="documentURL">Current Deleted Document Title</param>
        /// <param name="arrDocumentTitles">Document Title list</param>
        /// <returns></returns>
        private static string BuildDocumentsTitle(string documentTitle, string[] arrDocumentTitles)
        {
            string DocumentsTitle;
            List<string> DocumentTitles = new List<string>();

            for (int i = 0; i < arrDocumentTitles.Length; i++)
            {
                string title = "";

                if (arrDocumentTitles[i].Substring(0, 1) == "/")
                    title = arrDocumentTitles[i].Substring(1, arrDocumentTitles[i].Length - 1);
                else
                    title = arrDocumentTitles[i];

                if (title != documentTitle)
                {
                    DocumentTitles.Add(arrDocumentTitles[i]);
                }
            }

            DocumentsTitle = string.Join("|", DocumentTitles);
            return DocumentsTitle;
        }

        /// <summary>
        /// Convert DateFormate
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public DateTime? ConvertDateFormat(string value)
        {
            DateTime Date = new DateTime();

            string[] arrValue = value.Split('/');
            if (arrValue.Length == 3)
            {
                Date = new DateTime(Convert.ToInt32(arrValue[2]), Convert.ToInt32(arrValue[1]), Convert.ToInt32(arrValue[0]));
            }

            return Date;
        }
      
    }
}