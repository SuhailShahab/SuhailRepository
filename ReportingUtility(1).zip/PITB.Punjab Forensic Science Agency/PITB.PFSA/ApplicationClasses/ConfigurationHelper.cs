﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace PITB.PFSA.ApplicationClasses
{
    public class ConfigurationHelper
    {


        public static string DomainName
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["DomainName"];

            }

        }

        public static bool IsByPassActiveDiretory
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["ByPassActiveDiretory"]);

            }

        }

        public static string ActiveDirectoryDC
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["ActiveDirectoryDC"];

            }
        }

        public static string DefaultOU
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["DefaultOU"];

            }
        }

        public static string DefaultRootOU
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["DefaultRootOU"];

            }
        }

        public static string ServiceUser
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["ServiceUser"];

            }
        }

        public static string ServicePassword
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["ServicePassword"];

            }
        }

        public static string ReportUrl
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["ReportUrl"];

            }
        }

        public static string CommonReportUrl
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["CommonReportUrl"];

            }
        }
        public static string APIUrl
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["APIUrl"];

            }
        }
        public static bool IsShowGeneralMsg
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["IsShowGeneralMsg"]);
            }
        }

        public static string GeneralMsg
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["GeneralMsg"];

            }
        }

        #region Email Configuration
        public static string EMailSenderAddress
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["EMailSenderAddress"];

            }
        }
        public static string EMailSenderPassword
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["EMailSenderPassword"];

            }
        }
        public static string SMTPServer
        {
            get
            {
                return System.Web.Configuration.WebConfigurationManager.AppSettings["SMTPServer"];

            }
        }
        public static int SMTPServerPort
        {
            get
            {
                return Convert.ToInt32(System.Web.Configuration.WebConfigurationManager.AppSettings["SMTPServerPort"]);

            }
        }
        public static bool? SMTPEnableSSL
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["SMTPEnableSSL"]);

            }
        }
        public static bool? EnableEmail
        {
            get
            {
                return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["EnableEmail"]);

            }
        }
        public static bool? EnablePoliceDataPosting
        {
            get
            {
                if (ConfigurationManager.AppSettings.AllKeys.Contains("EnablePoliceDataPosting"))
                    return Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["EnablePoliceDataPosting"]);
                else
                    return false;
            }
        }

        public static string PunjabPoliceAPIURL
        {
            get
            {
                if (ConfigurationManager.AppSettings.AllKeys.Contains("PunjabPoliceAPIURL"))
                    return System.Web.Configuration.WebConfigurationManager.AppSettings["PunjabPoliceAPIURL"];
                else
                    return "https://fir.punjabpolice.gov.pk/Checkapi/pfsa_case_request";
            }
        }
        #endregion

    }
}