﻿using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PITB.PFSA.ApplicationClasses
{
    public static class CurrentUser
    {
       

        public static int? LoginID
        {
            get
            {
                if (HttpContext.Current.Session["LoginID"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel==null)
                    {
                        return null;
                    }
                    return userModel.UserID;
                  
                }
                else
                {

                    return Convert.ToInt32(HttpContext.Current.Session["LoginID"]);
                }
            }

        }
        public static string  UserDisplayName
        {
            get
            {
                if (HttpContext.Current.Session["EmployeeName"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.EmployeeName;
                  

                }
                else
                {

                    return Convert.ToString(HttpContext.Current.Session["EmployeeName"]);
                }
            }

        }
        public static string LoginName
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.UserName;                 
               
            }

        }

        public static int? DistrictID
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.DistrictID;

            }

        }

        public static UserModel CurrentUserInfo
        {
            get
            {
                return GetSessionUserInfo();
            }

        }


        public static string Url
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.Url;

            }
        }

        public static string DistrictCode
        {
            get
            {

                UserModel userModel = GetSessionUserInfo();
                if (userModel == null)
                {
                    return null;
                }
                return userModel.DistrictCode;

            }
        }

        public static int? UserTypeID
        {
            get
            {
                if (HttpContext.Current.Session["UserTypeID"] == null)
                {
                    UserModel userModel = GetSessionUserInfo();
                    if (userModel == null)
                    {
                        return null;
                    }
                    return userModel.UserTypeID;
                }
                else
                {
                    return Convert.ToInt32(HttpContext.Current.Session["UserTypeID"]);
                }
            }

        }

        public static UserModel GetSessionUserInfo()
        {
            UserModel moedel = null;

            if (HttpContext.Current.Session["CurrentUser"] == null && HttpContext.Current.Session["SessionID"]!=null &&  HttpContext.Current.Session["SessionID"].Equals(HttpContext.Current.Session.SessionID))
            {
                /*
                if (HttpContext.Current.Request.Cookies["LoginID"] != null)
                {

                    int loingID = Convert.ToInt32(HttpContext.Current.Request.Cookies["LoginID"].Value);
                    moedel = new UserBLL().GeLoginUserInfoByLogin(loingID);
                    if (moedel != null)
                    {

                        //HttpContext.Current.Response.Cookies["LoginID"].Value = moedel.UserID.ToString();
                        //HttpContext.Current.Response.Cookies["LoginID"].Expires = DateTime.Now.AddDays(1);
                        //HttpContext.Current.Response.Cookies["UserName"].Value = moedel.UserName.ToString();
                        //HttpContext.Current.Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(1);
                        HttpContext.Current.Session["CurrentUser"] = moedel;
                        HttpContext.Current.Session["LoginID"] = moedel.UserID;
                        HttpContext.Current.Session["EmployeeName"] = moedel.EmployeeName;
                        HttpContext.Current.Session["UserTypeID"] = moedel.UserTypeID;
                        HttpContext.Current.Session["IsWithinPremesis"] = moedel.IsWithinPremesis;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }
                 */
                   return null;

            }
            else
            {
                moedel = (UserModel)(HttpContext.Current.Session["CurrentUser"]);
            }

            return moedel;
        }

       
    }
}