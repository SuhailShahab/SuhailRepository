﻿using PITB.PFSA.BE.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace PITB.PFSA.BLL.CommonUtility
{
   public  class CommonBuildModel
    {
       public  IList<T> BuildModel<T>(DataTable dt, T objectType)
       {
           Type handlerType = objectType.GetType();
           if (dt != null && dt.Rows.Count > 0)
           {
               IList<T> genList = new List<T>();
               foreach (DataRow dr in dt.Rows)
               {
                   T item = (T)Activator.CreateInstance(handlerType);
                   foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                   {
                       foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                       {
                           MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                           if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                           {
                               propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                               break;
                           }
                       }

                   }
                   genList.Add(item);
               }
               return genList;
           }

           return null;

       }

       public DataTable ToDataTable<T>(IList<T> list)
       {
           PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(T));
           DataTable table = new DataTable();
           for (int i = 0; i < props.Count; i++)
           {
               PropertyDescriptor prop = props[i];
               table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
           }
           object[] values = new object[props.Count];
           foreach (T item in list)
           {
               for (int i = 0; i < values.Length; i++)
                   values[i] = props[i].GetValue(item) ?? DBNull.Value;
               table.Rows.Add(values);
           }
           return table;
       }
       public List<T> BuildModelList<T>(DataTable dt)
       {

           if (dt != null && dt.Rows.Count > 0)
           {
               List<T> genList = new List<T>();
               foreach (DataRow dr in dt.Rows)
               {
                   T item = Activator.CreateInstance<T>();
                   foreach (PropertyInfo propertyInfo in item.GetType().GetProperties())
                   {
                       foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                       {
                           MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                           if (dt.Columns.Contains(mappingInfoAttribute.ColumnName) && !Convert.IsDBNull(dr[mappingInfoAttribute.ColumnName]))
                           {
                               propertyInfo.SetValue(item, dr[mappingInfoAttribute.ColumnName]);
                               break;
                           }
                       }

                   }
                   genList.Add(item);
               }
               return genList;
           }

           return null;

       }
    }
}
