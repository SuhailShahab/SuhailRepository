﻿
using PITB.PFSA.BE;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.Inquiry;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.DAL;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.DAL.Lookups.RightsManagers;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Reflection;
using System.Text;
using System.Linq;
using PITB.PFSA.DAL.Lookups;

// =================================================================================================================================
// Create by:	<>
// Create date: <>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By             Modified Date/Time      Desription

// =================================================================================================================================
namespace PITB.PFSA.BLL.CommonUtility
{
    public class CommonBLL
    {
        private string districtCode = string.Empty;

        #region "Constructors"

        public CommonBLL()
        {

        }

        #endregion

        #region "OLD Code"


        public bool IsExist(TableName tblName, ColumnName clolumnName, string value, string caluse)
        {

            return new CommonDAL().GetDuplication(tblName.ToString(), clolumnName.ToString(), value, caluse);
          
        }

        public bool IsExist(TableName tblName, string caluse)
        {

            return new CommonDAL().GetDuplicationWithCaluseOnly(tblName.ToString(), caluse);

        }

        public string GetClause1(ColumnName columnName, int id)
        {
            StringBuilder sbClause = new StringBuilder();
            sbClause.Append(columnName.ToString());
            sbClause.Append(" Not IN (");
            sbClause.Append(id);
            sbClause.Append(")");
            return sbClause.ToString();
        }

        public string GetClause(ColumnName columnName, int id)
        {
            StringBuilder sbClause = new StringBuilder();
            sbClause.Append(columnName.ToString());
            sbClause.Append(" Not IN (");
            sbClause.Append(id);
            sbClause.Append(")");
            return sbClause.ToString();
        }
        public string GetClauses(ColumnName columnName, int id)
        {
            StringBuilder sbClause = new StringBuilder();
            sbClause.Append(columnName.ToString());
            sbClause.Append(" IN (");
            sbClause.Append(id);
            sbClause.Append(")");
            return sbClause.ToString();
        }
        public string GetEqualClause(ColumnName columnName, int id)
        {
            StringBuilder sbClause = new StringBuilder();
            sbClause.Append(columnName.ToString());
            sbClause.Append(" = (");
            sbClause.Append(id);
            sbClause.Append(")");
            return sbClause.ToString();
        }

        public string GetClause(Hashtable coloums, ColumnName? columnName, int? id)
        {
            StringBuilder sbClause = new StringBuilder();

            foreach (DictionaryEntry entry in coloums)
            {
                sbClause.Append(entry.Key);
                sbClause.Append(" = ");
                sbClause.Append(entry.Value.ToString());
                sbClause.Append(" AND ");
            }
            if (id.HasValue)
            {
                sbClause.Append(GetClause(columnName.Value, id.Value));
            }
            else
                sbClause.Append(" 1 = 1 ");
            return sbClause.ToString();
        }


        #endregion

        public int SaveErrorLog(ErrorLogModel erroLog)
        {
            FillErrorLogData(erroLog);
            return new CommonDAL().SaveErrorLog(erroLog);
        }
        public int AddErrorLog(ErrorLogModel erroLog)
        {
            FillErrorLogData(erroLog);
            return new CommonDAL().SaveErrorLog(erroLog);
        }
        public string AddErrorLogs(ErrorLogModel model)
        {
            FillErrorLogData(model);
            int id = LazyBaseSingleton<CommonDAL>.Instance.SaveErrorLog(model);
            return "(" + id.ToString() + "-" + DateTime.Now.Day + DateTime.Now.Month + DateTime.Now.Year + ")";

        }
        public bool SelectRecordVerification(string Table, string Column, string Value, string Clause)
        {
            return new ServicesDAL().SelectRecordVerification(Table, Column, Value, Clause);
        }
        public bool SelectRecordVerifications(string Table, string Column, string Value, string Clause, string Clause2)
        {
            return new ServicesDAL().SelectRecordVerifications(Table, Column, Value, Clause, Clause2);
        }
        private static void FillErrorLogData(ErrorLogModel ErrorLog)
        {
            // DataTable dtUser = GetSessionUserTable();

            //if (dtUser != null)
            //{


            //    if (dtUser.Columns.Contains("FCLocationCode") && !Convert.IsDBNull(dtUser.Rows[0]["FCLocationCode"]))
            //    {
            //        ErrorLog.LocationCode = Convert.ToString(dtUser.Rows[0]["FCLocationCode"]);
            //    }

            //    if (ErrorLog.Service.GetHashCode() > 0)
            //    {
            //        ErrorLog.ServiceCode = StringEnum.GetCode(ErrorLog.Service);

            //    }

            //    if (dtUser.Columns.Contains("DivisionID") && !Convert.IsDBNull(dtUser.Rows[0]["DivisionID"]))
            //    {
            //        ErrorLog.DivisionID = Convert.ToInt32(dtUser.Rows[0]["DivisionID"]);
            //    }

            //    if (dtUser.Columns.Contains("MainDistrictID") && !Convert.IsDBNull(dtUser.Rows[0]["MainDistrictID"]))
            //    {
            //        ErrorLog.DistrictID = Convert.ToInt32(dtUser.Rows[0]["MainDistrictID"]);
            //    }


            //}

            //ErrorLog.WebMethod = WebMethod;
            if (ErrorLog.CustomException.Message != "") ErrorLog.Message = ErrorLog.GetaAllMessages();//ErrorLog.g //ErrorLog.CustomException.Message;
            if (ErrorLog.CustomException.StackTrace != "") ErrorLog.StackTrace = ErrorLog.CustomException.StackTrace;
            if (ErrorLog.CustomException.Source != "") ErrorLog.Source = ErrorLog.CustomException.Source;
          

        }

        public bool GetUserPageAccess(int? loginID, string page, int level = 2)
        {
           try
           {
               return LazyBaseSingletonDAL<CommonDAL>.Instance.GetUserPageAccess(loginID, page, level);
              // return new CommonDAL().GetUserPageAccess(LoginID, Page, Level);
           }
            catch(Exception ex)
           {
               throw ex;
           }
            
        }

        public  string NotificationErrorMsg(string errorMsg)
        {
            return "error|" + errorMsg;
        }

        /// <summary>
        ///  CR: 013
        /// this method use to Shwo the Error Message
        /// </summary>
        /// <param name="model">Genericl base Model</param>
        /// <param name="ex">Exception Which Need to be Show</param>
        /// <returns>return the BaseModel With Notification Prpoerty</returns>
        public  BaseModel NotificationErrorMsg(BaseModel model, string errorMsg)
        {
            if (model == null)
            {
                Type typ = model.GetType();
                model = (BaseModel)Activator.CreateInstance(typ);
            }

            model.Notification = "error|" + errorMsg;
            return model;
        }

        public  BaseModel NotificationInfo(BaseModel model, string errorMsg)
        {
            if (model == null)
            {
                Type typ = model.GetType();
                model = (BaseModel)Activator.CreateInstance(typ);
            }

            model.Notification = "info|" + errorMsg;
            return model;
        }

        public BaseModel NotificationSuccess(BaseModel model, string successMsg)
        {
            if (model == null)
            {
                Type typ = model.GetType();
                model = (BaseModel)Activator.CreateInstance(typ);
            }

            model.Notification = "success|" + successMsg;
            return model;
        }

        public  BaseModel NotificationMsg(BaseModel model, string errorMsg, Type typ)
        {
            if (model == null)
            {
                model = (BaseModel)Activator.CreateInstance(typ);
            }

            model.Notification = "Error|" + errorMsg;
            return model;
        }


        /// <summary>
        /// Get applicant id against provided service code and center
        /// </summary>
        /// <param name="fcCenter"></param>
        /// <param name="serviceCode"></param>
        /// <returns></returns>
        public static string GetCaseIDKey(string districtCode)
        {
            StringBuilder sbCode = new StringBuilder();

            sbCode.Append(districtCode.Trim());
            sbCode.Append("-");
            sbCode.Append(DateTime.Now.Day.ToString().PadLeft(2, '0'));
            sbCode.Append(DateTime.Now.ToString("MM"));
            sbCode.Append(DateTime.Now.ToString("yy"));
            sbCode.Append("-");

            int? counter = new CommonDAL().GetCaseID(districtCode, DateTime.Now.Year.ToString());
            if (counter.HasValue && counter.Value > 0)
            {
                sbCode.Append(counter.Value.ToString().PadLeft(6, '0'));
                return sbCode.ToString();
            }
            return null;

        }


        /// <summary>
        /// Save Document URLs
        /// </summary>
        /// <param name="caseID">Selected Case ID</param>
        /// <param name="Body">Url Body info</param>
        /// <returns></returns>
        public int SaveDocumentsURL(TableName tableName, string id, string documentURL, string documentTitles, string documentFileNames)
        {
            int ret = 0;
            //string tbaleName = "tblEvidenceInformation";
            ret = new CommonDAL().SaveDocumentsURL(tableName.ToString(), id, documentURL, documentTitles, documentFileNames);
            return ret;
        }

        public int SaveDocumentsURL(DocumentParametes parameters)
        {
            int ret = 0;
            //string tbaleName = "tblEvidenceInformation";
            ret = new CommonDAL().SaveDocumentsURL(parameters.TableName.ToString(), parameters.ID, parameters.DocumentURL, parameters.DocumentTitles, parameters.DocumentFileNames);

            DataTable dt = LazyBaseSingleton<CommonBLL>.Instance.ToDataTable((from item in parameters.DocumentInfo

                                                                              select new
                                                                              { item.Title,
               
                                                                              
                                                                              }).ToList());
            LazyBaseSingletonDAL<FileProcessingInfoDAL>.Instance.Add(parameters.FileProcessingInfoModel, dt);

            return ret;
        }



        public DataTable GetDocuments(string tableName, string id)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = new CommonDAL().GetDocuments(tableName, id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }


        public int? UpdateDocuments(string documentsURL, string documentsTitle,string documentFileName, string tblName, string id)
        {
            int? result = null;
            try
            {
                result = new CommonDAL().UpdateDocuments(documentsURL, documentsTitle, documentFileName,tblName, id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }

        public  DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }



        public object item { get; set; }
    }
}

