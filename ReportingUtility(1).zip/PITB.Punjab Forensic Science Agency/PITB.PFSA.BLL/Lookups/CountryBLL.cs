﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BLL.Lookups
{
   public  class CountryBLL
    {
       public List<CountryModel> GetAllCountries()
       {
           List<CountryModel> lists = null;
           try
           {

               DataTable dt = LazyBaseSingletonDAL<CountryDAL>.Instance.SelectAllByID();
               if (dt.Rows.Count > 0)
                   lists = (List<CountryModel>)LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel(dt, new CountryModel());

               return lists;

           }
           catch (Exception ex)
           {
               throw ex;
           }
       }
    }
}
