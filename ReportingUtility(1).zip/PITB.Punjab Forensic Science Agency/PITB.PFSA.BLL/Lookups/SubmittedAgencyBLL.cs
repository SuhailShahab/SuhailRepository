﻿using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.DAL.Lookups;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BLL.Lookups
{
   public  class SubmittedAgencyBLL
    {
       public int Delete(SubmittedAgencyModel model)
       {
           try
           {
               return LazyBaseSingleton<SubmittedAgencyDAL>.Instance.Delete(new SubmittedAgencyModel (model.ID));
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public int? Save(SubmittedAgencyModel model)
       {
           CommonBLL commonBLL = new CommonBLL();
           if (model.ID.HasValue && model.ID.Value > 0)
           {

               if (commonBLL.IsExist(TableName.tblSubmittedAgency, ColumnName.Code, model.Code, commonBLL.GetClause(ColumnName.SubmittedAgencyID, model.ID.Value)))
               {
                   throw new Exception(CustomMsg.DuplicateCode);
               }
               else
                   if (commonBLL.IsExist(TableName.tblSubmittedAgency, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.SubmittedAgencyID, model.ID.Value)))
                   {
                       throw new Exception(CustomMsg.DuplicateTitle);
                   }
               return new SubmittedAgencyDAL().Edit(model);
           }
           else if (commonBLL.IsExist(TableName.tblSubmittedAgency, ColumnName.Title, model.Title, null))
           {
               throw new Exception(CustomMsg.DuplicateTitle);
           }
           else if (commonBLL.IsExist(TableName.tblSubmittedAgency, ColumnName.Code, model.Code, null))
           {
               throw new Exception(CustomMsg.DuplicateCode);
           }
           else
               return new SubmittedAgencyDAL().Add(model);
       }


       public List<SubmittedAgencyModel> GetAllAgencies()
       {
           List<SubmittedAgencyModel> lists = null;
           try
           {

               DataTable dt = LazyBaseSingletonDAL<SubmittedAgencyDAL>.Instance.SelectAll();
               if (dt.Rows.Count > 0)
                   lists = (List<SubmittedAgencyModel>)LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel(dt, new SubmittedAgencyModel());

               return lists;

           }
           catch (Exception ex)
           {
               throw ex;
           }
       }
    }
}
