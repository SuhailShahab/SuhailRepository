﻿using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.DAL.Lookups;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;

// =================================================================================================================================
// Create by:	<Suhail Shahab>
// Create date: <18-01-2016 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time                  Desription
// CR:001       Muhammad Hammad Shahid      21-01-2016 05:44:31PM               Add record save, edit and GetAll related mehtods
// =================================================================================================================================
namespace PITB.PFSA.BLL.Lookups
{
    public class PoliceStationBLL
    {
        /// <summary>
        /// Add/Update police station record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(PoliceStationModel model)
        {
            try
            {
                Hashtable htbWhere = new Hashtable();
                htbWhere.Add(ColumnName.DivisionID.ToString(), model.DivisionID);
                htbWhere.Add(ColumnName.DistrictID.ToString(), model.DistrictID);

                CommonBLL commonBLL = new CommonBLL();

                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblPoliceStation, ColumnName.Title, model.Title,commonBLL.GetClause(htbWhere, ColumnName.PoliceStationID, Convert.ToInt32(model.ID))))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }

                    return new PoliceStationDAL().Edit(model);
                }

                else if (commonBLL.IsExist(TableName.tblPoliceStation, ColumnName.Title, model.Title, commonBLL.GetClause(htbWhere,null, null)))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }
                else if (commonBLL.IsExist(TableName.tblPoliceStation, ColumnName.Code, model.Code, null))
                {
                    throw new Exception(CustomMsg.DuplicateCode);
                }
               
                else
                    return new PoliceStationDAL().Add(model);


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int Delete(PoliceStationModel model)
        {
            try
            {
                return LazyBaseSingleton<PoliceStationDAL>.Instance.Delete(new PoliceStationModel(model.ID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<PoliceStationModel> GetPoliceStations()
        {
            List<PoliceStationModel> colPoliceStations = null;

            try
            {
                DataTable dt = new PoliceStationDAL().SelectAll();
                if (dt.Rows.Count > 0)
                    colPoliceStations = (List<PoliceStationModel>)LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel(dt, new PoliceStationModel());

                return colPoliceStations;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<PoliceStationModel> GetAllPoliceStationsByDistrictID(int? districtID)
        {
            List<PoliceStationModel> lists = null;

            try
            {
                DataTable dt = LazyBaseSingletonDAL<PoliceStationDAL>.Instance.SelectAllByIDs(districtID);
                if (dt.Rows.Count > 0)
                    lists = (List<PoliceStationModel>)LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel(dt, new PoliceStationModel());

                return lists;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
