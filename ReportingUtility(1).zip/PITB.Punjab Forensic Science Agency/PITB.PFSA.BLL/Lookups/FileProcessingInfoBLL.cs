﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.Reports;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BLL.Lookups
{
   public  class FileProcessingInfoBLL
    {

       public int? AddFileProcessingInfo(FileProcessingInfoModel model)
       {
           int? result = null;
           try
           {
               result = LazyBaseSingletonDAL<FileProcessingInfoDAL>.Instance.Add(model);
           }
           catch(Exception ex)
           {
               throw ex;
           }

           return result;
       }

      

        #region Report Methods
       public DataTable GetrptFileProcessingActivityData(FileProcessingRptParameters fileInfo)
       {
           DataTable dt = new DataTable();
           try
           {
               dt = LazyBaseSingletonDAL<FileProcessingInfoDAL>.Instance.GetrptFileProcessingActivityData(fileInfo);
           }
           catch (Exception ex)
           {
               throw ex;
           }
           return dt;
       }
       public DataTable GetrptFileProcessingDetail(FileProcessingRptParameters fileInfo)
       {
           DataTable dt = new DataTable();
           try
           {
               dt = LazyBaseSingletonDAL<FileProcessingInfoDAL>.Instance.GetrptFileProcessingDetail(fileInfo);
           }
           catch (Exception ex)
           {
               throw ex;
           }
           return dt;
       }
        #endregion 
    }
}
