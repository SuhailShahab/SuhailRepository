﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BLL.Lookups
{
   public class CaseStatusBLL
    {
       public List<CaseStatusModel> GetAllStatues()
       {
           List<CaseStatusModel> lists = null;
           try
           {

               DataTable dt = LazyBaseSingletonDAL<CaseStatusDAL>.Instance.SelectAll();
               if (dt.Rows.Count > 0)
                   lists = (List<CaseStatusModel>)LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel(dt, new CaseStatusModel());

               return lists;

           }
           catch (Exception ex)
           {
               throw ex;
           }
       }
    }
}
