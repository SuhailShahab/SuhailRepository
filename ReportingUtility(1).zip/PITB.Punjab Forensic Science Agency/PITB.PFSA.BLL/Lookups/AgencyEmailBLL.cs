﻿using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.CustomExceptions;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.DAL.Lookups;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BLL.Lookups
{
   public  class AgencyEmailBLL
    {
       public int Delete(int agencyID)
       {
           try
           {
               return LazyBaseSingleton<AgencyEmailDAL>.Instance.Delete(new AgencyEmailModel(agencyID));
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public int? Save(AgencyEmailModel model)
       {
           CommonBLL commonBLL = new CommonBLL();
           if (model.ID.HasValue && model.ID.Value > 0)
           {
               //commonBLL.GetClause(ColumnName.AgencyEmailID, model.ID.Value), commonBLL.GetEqualClause(ColumnName.AgencyID, model.AgencyID)))
               if (commonBLL.SelectRecordVerification(TableName.tblAgencyEmail.ToString(), ColumnName.Email.ToString(), model.Email, "AgencyID = " + model.AgencyID + "and "  + "agencyemailID <> " + model.ID.Value))
               {
                   throw new BusinessException(CustomMsg.DuplicateEmail);
               }

               return new AgencyEmailDAL().Edit(model);
           }
           else if (commonBLL.IsExist(TableName.tblAgencyEmail, ColumnName.Email, model.Email, commonBLL.GetClauses(ColumnName.AgencyID, model.AgencyID)))
           {
               throw new BusinessException(CustomMsg.DuplicateEmail);
           }
           
           else
               return new AgencyEmailDAL().Add(model);
       }


       public List<AgencyEmailModel> GetAllAgencies()
       {
           List<AgencyEmailModel> lists = null;
           try
           {

               DataTable dt = LazyBaseSingletonDAL<AgencyEmailDAL>.Instance.SelectAll();
               if (dt.Rows.Count > 0)
                   lists = (List<AgencyEmailModel>)LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel(dt, new AgencyEmailModel());

               return lists;

           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public List<AgencyEmailModel> GetAgencyEmails(int agencyID)
       {
           List<AgencyEmailModel> lists = null;
           try
           {

               DataTable dt = LazyBaseSingletonDAL<AgencyEmailDAL>.Instance.GetAgencyEmailsByID(agencyID);
               if (dt.Rows.Count > 0)
                   lists = (List<AgencyEmailModel>)LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel(dt, new AgencyEmailModel());

               return lists;

           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public List<EmailLogs> GetEmailsLogs(int evidenceID)
       {
           List<EmailLogs> lists = null;
           try
           {

               DataTable dt = LazyBaseSingletonDAL<AgencyEmailDAL>.Instance.GetEmailsLogs(evidenceID);
               if (dt.Rows.Count > 0)
                   lists = (List<EmailLogs>)LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel(dt, new EmailLogs());

               return lists;

           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

    }
}
