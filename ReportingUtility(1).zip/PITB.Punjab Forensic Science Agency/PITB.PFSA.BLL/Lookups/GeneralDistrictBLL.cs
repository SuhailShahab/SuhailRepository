﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Collections;
using PITB.PFSA.RightsManager.CustomEnums;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.DataAccessLayer;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.DAL.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BE.CustomEnums;

namespace PITB.PFSA.BLL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <26-12-2014 08:30PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time      Desription
    // 001          Muhammad Usman              30-Sep-2015             Add Method Get Permitted Districts 
    // 002          Sajjad Aslam                07-July-2017            Add Method Get Districts By User ID
    // =================================================================================================================================

    public class GeneralDistrictBLL
    {

        /// <summary>
        /// Save General District Information
        /// </summary>
        /// <param name="districtModel"></param>
        /// <returns></returns>
        public int? Save(GeneralDistrictModel districtModel)
        {


            try
            {
                CommonBLL commonBLL = new CommonBLL();
                if (!string.IsNullOrEmpty(districtModel.Title))
                {

                    Hashtable htbWhere = new Hashtable();
                    htbWhere.Add(ColumnName.DivisionID.ToString(), districtModel.DivisionID);
                    if (districtModel.ID.HasValue && districtModel.ID.Value > 0)
                    {
                        if (commonBLL.IsExist(TableName.tblGeneralDistricts, ColumnName.Title, districtModel.Title, commonBLL.GetClause(ColumnName.DistrictID, districtModel.ID.Value)))
                        {
                            throw new Exception(CustomMsg.DuplicateTitle);
                        }
                        return new GeneralDistrictDAL().Edit(districtModel);
                    }
                    else if (commonBLL.IsExist(TableName.tblGeneralDistricts, ColumnName.Title, districtModel.Title, commonBLL.GetClause(htbWhere, null, null)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    else
                        return new GeneralDistrictDAL().Add(districtModel);
                }
                // DataTable dtServcieDistrict = GetServiceDistrictTable(districtModel.ThirdPartyRecord, districtModel.ServiceID);
                //if (dtServcieDistrict != null && dtServcieDistrict.Rows.Count > 0)
                //{

                // return new GeneralDistrictDAL().SaveServiceDistrict(dtServcieDistrict, districtModel.CreatedBy);
                // }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        /// <summary>
        /// Disable General District Information
        /// </summary>
        /// <param name="id"></param>
        /// <param name="modifiedBy"></param>
        /// <returns></returns>
        public int Delete(int id, string modifiedBy)
        {
            return new GeneralDistrictDAL().Delete(id, modifiedBy);
        }

        /// <summary>
        /// Get All Districts with out isA
        /// </summary>
        /// <returns></returns>
        public List<GeneralDistrictModel> GetDistricts(int? districtID)
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().GeneralDistricts(districtID);
            return BuildModel(dt);
        }
        /// <summary>
        /// Get Permitted Districts against user id or group ID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public List<GeneralDistrictModel> GetPermittedDistrict(int userID)
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().GetPermittedDistricts(userID);
            return BuildModel(dt);
        }
       
       

        /// <summary>
        /// Get All District Data from DB
        /// </summary>
        /// <returns>return the District Model with District Data</returns>
        public List<GeneralDistrictModel> GetAllGeneralDistricts()
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().All();
            return BuildModel(dt);
        }


        /// <summary>
        /// Get All District Data By User ID from DB
        /// CR: 002
        /// <param UserID></param>
        /// </summary>
        /// <returns>return the District Model with District Data</returns>
        public List<GeneralDistrictModel> GetAllGeneralDistrictsByUserID(int? userID)
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().GetAllGeneralDistrictsByUserID(userID);
            return BuildModel(dt);
        }

        /// <summary>
        /// CR: 003
        /// Get District Data from DB on the basis od Division ID
        /// </summary>
        /// <returns>return the District Model with District Data</returns>
        public List<GeneralDistrictModel> GetDistrictsByDivisionID(int DivisionID)
        {
            DataTable dt = null;
            dt = new GeneralDistrictDAL().GetDistrictsByDivisionID(DivisionID);
            return BuildModel(dt);
        }





        #region "Private Methods"

        internal List<GeneralDistrictModel> BuildModel(DataTable dt)
        {
            List<GeneralDistrictModel> districts = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                districts = new List<GeneralDistrictModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    GeneralDistrictModel GeneralDistrictModel = new GeneralDistrictModel();
                    if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                        GeneralDistrictModel.ID = Convert.ToInt32(dr["DistrictID"]);
                    if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                        GeneralDistrictModel.DivisionID = Convert.ToInt32(dr["DivisionID"]);
                    if (dt.Columns.Contains("DivisionName") && !Convert.IsDBNull(dr["DivisionName"]))
                        GeneralDistrictModel.DivisionName = Convert.ToString(dr["DivisionName"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        GeneralDistrictModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                        GeneralDistrictModel.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        GeneralDistrictModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        GeneralDistrictModel.Code = Convert.ToString(dr["Code"]);
                    if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                        GeneralDistrictModel.StaticName = Convert.ToString(dr["StaticName"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        GeneralDistrictModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    if (dt.Columns.Contains("ProvinceID") && !Convert.IsDBNull(dr["ProvinceID"]))
                        GeneralDistrictModel.ProvinceID = Convert.ToInt32(dr["ProvinceID"]);

                    districts.Add(GeneralDistrictModel);
                }

                districts.TrimExcess();
            }

            return districts;
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal GeneralDistrictModel BuildGeneralDistrictModel(DataTable dt)
        {
            GeneralDistrictModel model = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];

                model = new GeneralDistrictModel();

                if (dt.Columns.Contains("DistrictID") && !Convert.IsDBNull(dr["DistrictID"]))
                    model.ID = Convert.ToInt32(dr["DistrictID"]);
                if (dt.Columns.Contains("DivisionID") && !Convert.IsDBNull(dr["DivisionID"]))
                    model.DivisionID = Convert.ToInt32(dr["DivisionID"]);
                if (dt.Columns.Contains("DivisionName") && !Convert.IsDBNull(dr["DivisionName"]))
                    model.DivisionName = Convert.ToString(dr["DivisionName"]);
                if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                    model.Title = Convert.ToString(dr["Title"]);
                if (dt.Columns.Contains("TitleUrdu") && !Convert.IsDBNull(dr["TitleUrdu"]))
                    model.TitleUrdu = Convert.ToString(dr["TitleUrdu"]);
                if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                    model.Description = Convert.ToString(dr["Description"]);
                if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                    model.Code = Convert.ToString(dr["Code"]);
                if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                    model.StaticName = Convert.ToString(dr["StaticName"]);
                if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                    model.Code = Convert.ToString(dr["Code"]);
                if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    model.Status = Convert.ToBoolean(dr["IsActive"]);

            }

            return model;
        }
        #endregion

      
    }
}

