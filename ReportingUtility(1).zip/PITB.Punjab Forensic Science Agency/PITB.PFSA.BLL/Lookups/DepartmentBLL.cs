﻿using System;
using System.Data;
using System.Collections.Generic;
using PITB.PFSA.RightsManager.DataAccessLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.DAL.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BE.CustomEnums;

namespace PITB.PFSA.BLL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:30AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class DepartmentBLL
    {
        public int Save(DepartmentModel model)
        {
            CommonBLL commonBLL = new CommonBLL();
            try
            {
                if (model.ID > 0)
                {
                    if (commonBLL.IsExist(TableName.tblDepartments, ColumnName.Code, model.Code, commonBLL.GetClause(ColumnName.DepartmentID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateCode);
                    }
                    else if (commonBLL.IsExist(TableName.tblDepartments, ColumnName.Title, model.Title, commonBLL.GetClause(ColumnName.DepartmentID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateTitle);
                    }
                    return new DepartmentDAL().Edit(model);
                }
                else if (commonBLL.IsExist(TableName.tblDepartments, ColumnName.Code, model.Code, null))
                {
                    throw new Exception(CustomMsg.DuplicateCode);
                }
                else if (commonBLL.IsExist(TableName.tblDepartments, ColumnName.Title, model.Title, null))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }

                else
                    return new DepartmentDAL().Add(model);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                commonBLL = null;

            }

        }
        public List<DepartmentModel> GetDepartments()
        {
            DataTable dt = null;
            dt = new DepartmentDAL().GetAll();
            return BuildModel(dt);
        }
        public List<DepartmentModel> GetDepartment()
        {
            DataTable dt = null;
            dt = new DepartmentDAL().SelectDepartments();
            return BuildModel(dt);
        }

        public int Delete(int id, int modifiedBy)
        {
            DepartmentDAL departmentDAL = new DepartmentDAL();
            int result = departmentDAL.Delete(id, modifiedBy);
            departmentDAL = null;
            return result;
        }

        #region "Private Methods"

        internal List<DepartmentModel> BuildModel(DataTable dt)
        {
            List<DepartmentModel> departments = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                departments = new List<DepartmentModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    DepartmentModel departmentModel = new DepartmentModel();

                    departmentModel.ID = Convert.ToInt32(dr["DepartmentID"]);
                    if (dt.Columns.Contains("Code") && !Convert.IsDBNull(dr["Code"]))
                        departmentModel.Code = Convert.ToString(dr["Code"]);
                    if (dt.Columns.Contains("Title") && !Convert.IsDBNull(dr["Title"]))
                        departmentModel.Title = Convert.ToString(dr["Title"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        departmentModel.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                    departmentModel.Status = Convert.ToBoolean(dr["IsActive"]);
                    departments.Add(departmentModel);
                }

                departments.TrimExcess();
            }

            return departments;
        }

        #endregion
    }
}
