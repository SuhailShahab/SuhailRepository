﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.DAL.Lookups;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BLL.Lookups
{
    public class FileProcessStatusBLL
    {
        public List<FileProcessStatusModel> GetAllFileProcessStatuses()
        {
            DataTable dt = new DataTable();
            List<FileProcessStatusModel> fileProcessStatuses = null;
            try
            {
                dt = LazyBaseSingletonDAL<FileProcessStatusDAL>.Instance.GetAll();
                if(dt.Rows.Count>0)
                fileProcessStatuses = LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel<FileProcessStatusModel>(dt, new FileProcessStatusModel()).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return fileProcessStatuses;
        }
    }
}
