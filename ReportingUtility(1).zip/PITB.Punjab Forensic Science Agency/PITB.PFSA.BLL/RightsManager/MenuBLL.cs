﻿using System;
using System.Data;
using System.Collections.Generic;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.DAL.Lookups.RightsManagers;

namespace PITB.PFSA.BLL.RightsManager.BusinessLogicLayer
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil >
    // Create date: <7/11/2014 2:07:32 AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class MenuBLL
    {
        public DataTable GetFeatures(int menuType)
        {
            return new MenuDAL().GetFeatures(menuType);
        }
        public List<ApplicationFeaturesModel> GetAppFeatures(int menuType)
        {
            DataTable dt = new MenuDAL().GetFeatures(menuType);
            return this.BuildModel(dt);
        }
        public DataTable GetObjectsByFeature(int featureID)
        {
            return new MenuDAL().GetObjectsByFeature(featureID);
        }
        public List<ApplicationFeaturesModel> GetAppObjectsByFeature(int featureID)
        {
            DataTable dt =new MenuDAL().GetObjectsByFeature(featureID);
            return BuildModel(dt);
        }
        public DataSet GetMenuByUser(string Login)
        {
            return new MenuDAL().GetMenuByUser(Login);
        }

        public DataSet GetMenuByUser(int LoginID)
        {
            return new MenuDAL().GetMenuByUser(LoginID);
        }

        /// <summary>
        /// Get Magement Level menus info
        /// </summary>
        /// <param name="LoginID"></param>
        /// <returns></returns>
        public DataTable GetMagementMenuByUser(int LoginID)
        {
            return new MenuDAL().GetManagementMenuByUser(LoginID);
        }

        #region Build Model
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<ApplicationFeaturesModel> BuildModel(DataTable dt)
        {
            List<ApplicationFeaturesModel> appFeatures = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                appFeatures = new List<ApplicationFeaturesModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    ApplicationFeaturesModel appFeature = new ApplicationFeaturesModel();
                    if (dt.Columns.Contains("AppFeatureID") && !Convert.IsDBNull(dr["AppFeatureID"]))
                        appFeature.ID = Convert.ToInt32(dr["AppFeatureID"]);
                    if (dt.Columns.Contains("MenuName") && !Convert.IsDBNull(dr["MenuName"]))
                        appFeature.MenuName = Convert.ToString(dr["MenuName"]);
                    if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                        appFeature.Name = Convert.ToString(dr["Name"]);
                    if (dt.Columns.Contains("URL") && !Convert.IsDBNull(dr["URL"]))
                        appFeature.URL = Convert.ToString(dr["URL"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        appFeature.Description = Convert.ToString(dr["Description"]);                   
                    if (dt.Columns.Contains("HasChild") && !Convert.IsDBNull(dr["HasChild"]))
                        appFeature.HasChild = Convert.ToBoolean(dr["HasChild"]);
                    if (dt.Columns.Contains("AppObjectID") && !Convert.IsDBNull(dr["AppObjectID"]))
                        appFeature.ID = Convert.ToInt32(dr["AppObjectID"]);
                    if (dt.Columns.Contains("Sort") && !Convert.IsDBNull(dr["Sort"]))
                        appFeature.Sort = Convert.ToInt32(dr["Sort"]);              
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        appFeature.IsActive = Convert.ToBoolean(dr["IsActive"]);                  
                    appFeatures.Add(appFeature);
                }

                appFeatures.TrimExcess();
            }

            return appFeatures;
        }
        #endregion 

    }
}
