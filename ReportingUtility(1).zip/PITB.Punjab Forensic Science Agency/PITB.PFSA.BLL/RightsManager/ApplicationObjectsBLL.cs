﻿using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.DAL.Lookups;
using PITB.PFSA.RightsManager.BusinessLogicLayer;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BLL.RightsManager.BusinessLogicLayer
{
    public class ApplicationObjectsBLL
    {
        /// <summary>
        /// Save Record
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Save(ApplicationObjectsModel model)
        {
            CommonBLL commonBLL = LazyBaseSingleton<CommonBLL>.Instance;
            if (model.ID > 0)
            {

                if (commonBLL.IsExist(TableName.tblAppObjects, ColumnName.Name, model.Name, commonBLL.GetClause(ColumnName.AppObjectID, model.ID)))
                {
                    throw new Exception(CustomMsg.DuplicateTitle);
                }
                return new ApplicationObjectsDAL().Edit(model);
            }
            else if (commonBLL.IsExist(TableName.tblAppObjects, ColumnName.Name, model.Name, null))
            {
                throw new Exception(CustomMsg.DuplicateTitle);
            }

            else

                return new ApplicationObjectsDAL().Add(model);
        }

        /// <summary>
        /// Getting All Record for 
        /// </summary>
        /// <returns></returns>
        public List<ApplicationObjectsModel> GetAppObject()
        {
            DataTable dt = null;
            dt = new ApplicationObjectsDAL().GetAppObject();
            return BuildModel(dt);
        }

        /// <summary>
        /// Build Model
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        internal List<ApplicationObjectsModel> BuildModel(DataTable dt)
        {
            List<ApplicationObjectsModel> ApplicationObjectes = null;

            if (dt != null && dt.Rows.Count > 0)
            {
                ApplicationObjectes = new List<ApplicationObjectsModel>();
                foreach (DataRow dr in dt.Rows)
                {
                    ApplicationObjectsModel model = new ApplicationObjectsModel();
                    if (dt.Columns.Contains("AppObjectID") && !Convert.IsDBNull(dr["AppObjectID"]))
                        model.ID = Convert.ToInt32(dr["AppObjectID"]);
                    if (dt.Columns.Contains("AppFeatureID") && !Convert.IsDBNull(dr["AppFeatureID"]))
                        model.AppFeatureID = Convert.ToInt32(dr["AppFeatureID"]);
                    if (dt.Columns.Contains("StaticName") && !Convert.IsDBNull(dr["StaticName"]))
                        model.StaticName = Convert.ToString(dr["StaticName"]);
                    if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dr["Name"]))
                        model.Name = Convert.ToString(dr["Name"]);
                    if (dt.Columns.Contains("URL") && !Convert.IsDBNull(dr["URL"]))
                        model.URL = Convert.ToString(dr["URL"]);
                    if (dt.Columns.Contains("Description") && !Convert.IsDBNull(dr["Description"]))
                        model.Description = Convert.ToString(dr["Description"]);
                    if (dt.Columns.Contains("HasChild") && !Convert.IsDBNull(dr["HasChild"]))
                        model.HasChild = Convert.ToInt32(dr["HasChild"]) == 1 ? true : false;

                    if (dt.Columns.Contains("Sort") && !Convert.IsDBNull(dr["Sort"]))
                        model.Sort = Convert.ToInt32(dr["Sort"]);
                    if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dr["IsActive"]))
                        model.IsActive = Convert.ToBoolean(dr["IsActive"]);

                    ApplicationObjectes.Add(model);
                }

                ApplicationObjectes.TrimExcess();
            }

            return ApplicationObjectes;
        }
    }
}
