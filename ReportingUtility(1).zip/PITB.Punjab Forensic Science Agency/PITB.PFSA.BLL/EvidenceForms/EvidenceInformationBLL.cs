﻿using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.Inquiry;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.DAL.EvidenceForms;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BLL.CommonUtility;

namespace PITB.PFSA.BLL.EvidenceForms
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <17-09-2015 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time          Desription
    // =================================================================================================================================
    public class EvidenceInformationBLL
    {
        /// <summary>
        /// Save evidence Form Data
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int? Save(EvidenceModel model)
        {
            try
            {
                CommonBLL commonBLL = LazyBaseSingletonDAL<CommonBLL>.Instance;
                /// model.District = string.Empty;
                /// model.PoliceStationTitle = string.Empty;

                if (model.IsEdit)
                {
                    // model.SubmittedAgency = null;
                    if (commonBLL.IsExist(TableName.tblEvidenceInformations, ColumnName.CaseNo, model.CaseNo, commonBLL.GetClause(ColumnName.ID, model.ID.Value)))
                    {
                        throw new Exception(CustomMsg.DuplicateCaseNo);
                    }
                    return LazyBaseSingletonDAL<EvidenceInformationDAL>.Instance.Edit(model);

                }
                else if (commonBLL.IsExist(TableName.tblEvidenceInformations, ColumnName.CaseNo, model.CaseNo, null))
                {
                    throw new Exception(CustomMsg.DuplicateCaseNo);
                }
                else
                    return LazyBaseSingletonDAL<EvidenceInformationDAL>.Instance.Add(model);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return null;

        }


        public int SavePinNumber(int? userID,int? pinNumber)
        {
            try
            {

                return LazyBaseSingletonDAL<EvidenceInformationDAL>.Instance.SavePinNumber(userID,pinNumber);

            }
            catch (Exception ex)
            {
                throw ex;
            }

         //   return null;

        }


        public int GetVerifyPinNumber(int? userID, int? pinNumber)
        {
            try
            {

                return LazyBaseSingletonDAL<EvidenceInformationDAL>.Instance.GetVerifyPinNumber(userID,pinNumber);

            }
            catch (Exception ex)
            {
                throw ex;
            }

            //   return null;

        }
        /// <summary>
        /// Get Evidence Form data by ID
        /// </summary>
        /// <param name="ID">Selected ID</param>
        /// <returns></returns>
        public List<DocumentModel> GetEvidenceFormDataByID(string ID, UserModel userInfo)
        {
            try
            {
                List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetEvidenceFormDataByID(ID));
                return BindDocumentList(list, userInfo, false);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get Evidence Form data by ID
        /// </summary>
        /// <returns></returns>
        public List<DocumentModel> GetAllEvidenceData()
        {
            UserModel userInfo = null;
            List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetAllEvidenceData());
            return BindDocumentList(list, userInfo, false);
        }

        /// <summary>
        /// Get Evidence data from DB by user id and District
        /// </summary>
        /// <param name="createdBY">Created Person ID</param>
        /// <param name="districtID">Created Person District</param>
        /// <returns></returns>
        public List<DocumentModel> GetEvidenceDataByUserID(UserModel userInfo)
        {

            List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetEvidenceDataByUserID(userInfo.UserID.Value, userInfo.DistrictID.Value));
            return BindDocumentList(list, userInfo, true);
        }

        /// <summary>
        /// Get Evidence Data
        /// </summary>
        /// <returns></returns>
        public List<EvidenceModel> GetEvidenceFormData(UserModel userInfo)
        {
            List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetEvidenceFormData(userInfo.UserID.Value, userInfo.DistrictID.Value));
            return BindDocument(list);
        }

        /// <summary>
        /// Bind Data in Database
        /// </summary>
        /// <param name="dt">Data Table</param>
        /// <returns></returns>
        private List<EvidenceModel> BindData(DataTable dt)
        {
            List<EvidenceModel> lists = new List<EvidenceModel>();
            if (dt.Rows.Count > 0)
                lists = (List<EvidenceModel>)LazyBaseSingleton<CommonBuildModel>.Instance.BuildModel(dt, new EvidenceModel());

            return lists;
        }

        /// <summary>
        /// Bind Documents  List
        /// </summary>
        /// <param name="models">Evidence Model </param>
        /// <returns></returns>
        private List<EvidenceModel> BindDocument(List<EvidenceModel> models)
        {
            string[] fileReqArry = null;
            foreach (EvidenceModel model in models)
            {
                model.Documents = new List<DocumentModel>();
                if (model.DocumentURL != null && model.DocumentURL != "")
                {
                    string[] strURLs = model.DocumentURL.Split('|');
                    string[] strTitles = model.DocumentTitle.Split('|');
                    string[] strFileNames = model.DocumentFileName != null ? model.DocumentFileName.Split('|') : null;
                    for (int i = 0; i < strURLs.Length; i++)
                    {
                        DocumentModel document = new DocumentModel();
                        document.Title = strTitles != null && i < strTitles.Length ? Convert.ToString(strTitles[i]) : "";
                        document.FileName = strFileNames != null && i < strFileNames.Length ? Convert.ToString(strFileNames[i]) : "";
                        document.Url = ConfigurationManager.AppSettings["DocumentCenterURL"].ToString() + Convert.ToString(strURLs[i]);
                        document.DownloadUrl = Convert.ToString(strURLs[i]);
                        document.CaseID = model.CaseID;
                        if (!string.IsNullOrEmpty(strURLs[i]))
                        {
                            fileReqArry = strURLs[i].Split('/');
                            document.FileRef = fileReqArry[fileReqArry.Length - 1];
                        }

                        model.Documents.Add(document);
                    }
                }
            }
            return models;

        }

        /// <summary>
        /// Get All Evidence Data By ID
        /// </summary>
        /// <returns></returns>
        public List<EvidenceModel> GetAllEvidenceInformationByID(int createdBY, int? districtID, int? UserTypeID)
        {
            List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetAllEvidenceInformationByID(createdBY, districtID, UserTypeID));
            return BindDocument(list);
        }

        public EvidenceModelView GetEvidencePagingData(int? pageIndex, int? pageSize, int? createdBy, int? districtID, int? UserTypeID)
        {
            DataSet ds = null;
            EvidenceModelView evidence = new EvidenceModelView();
            try
            {
                ds = LazyBaseSingletonDAL<EvidenceInformationDAL>.Instance.GetEvidencePagingData(pageIndex, pageSize, createdBy, districtID, UserTypeID);
                evidence.TotalCount = Convert.ToInt32(ds.Tables[1].Rows[0][0]);

                evidence.Evidences = LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<EvidenceModel>(ds.Tables[0]);
                BindDocument(evidence.Evidences);

            }
            catch(Exception ex)
            {
                throw ex;
            }
            return evidence;
        }

        public EvidenceModelView GetEvidencePagingDataBySearch(IndexSearchModel paramModel)
        {
            DataSet ds = null;
            EvidenceModelView evidence = new EvidenceModelView();
            try
            {
                
                ds = LazyBaseSingletonDAL<EvidenceInformationDAL>.Instance.GetEvidencePagingDataBySearch(paramModel);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    evidence.TotalCount = Convert.ToInt32(ds.Tables[1].Rows[0][0]);

                    evidence.Evidences = LazyBaseSingleton<CommonBuildModel>.Instance.BuildModelList<EvidenceModel>(ds.Tables[0]);
                    BindDocument(evidence.Evidences);
                }
                

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return evidence;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="createdBY"></param>
        /// <param name="districtID"></param>
        /// <param name="UserTypeID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<EvidenceModel> GetAllEvidenceInfromationByIdDBP(int createdBY, int? districtID, int? UserTypeID, int pageNo, int pageSize, string searchText)
        {
            List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetAllEvidenceInfromationByIdDBP(createdBY, districtID, UserTypeID, pageNo, pageSize, searchText));
            return BindDocument(list);
        }




        /// <summary>
        /// 
        /// </summary>
        /// <param name="createdBY"></param>
        /// <param name="districtID"></param>
        /// <param name="UserTypeID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<EvidenceModel> GetAllEvidenceSubmissionsDBP(IndexSearchModel paramModel)
        {
            List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetAllEvidenceSubmissionsDBP(paramModel));
            return BindDocument(list);
        }


        /// <summary>
        /// Get Evidence Infoby ID
        /// </summary>
        /// <param name="ID">Selected ID</param>
        /// <returns></returns>
        public List<EvidenceModel> GetEvidenceInformationByID(string ID, int? UserID, int? DistrictID)
        {
            try
            {
                List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetEvidenceFormDataByID(ID, UserID, DistrictID));
                return BindDocument(list);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public List<EvidenceModel> GetEvidenceInformationByID(string ID, UserModel userInfo)
        {
            try
            {
                List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetEvidenceFormDataByID(ID, userInfo));
                return BindDocument(list);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="DistrictID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public List<EvidenceModel> GetEvidenceInfromationByIDForDashBoardDBP(int? UserID, int? DistrictID, int pageNo, int pageSize, string searchText)
        {
            try
            {
                List<EvidenceModel> list = BindData(new EvidenceInformationDAL().GetEvidenceInfromationByIDForDashBoardDBP(UserID, DistrictID, pageNo, pageSize, searchText));
                return BindDocument(list);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        ///// <summary>
        ///// Bind the Document list
        ///// </summary>
        ///// <param name="models">Evedence Models List</param>
        ///// <returns></returns>
        //private List<DocumentModel> BindDocumentList(List<EvidenceModel> models)
        //{
        //    List<DocumentModel> Documents = new List<DocumentModel>();

        //    foreach (EvidenceModel model in models)
        //    {
        //        if (!string.IsNullOrEmpty(model.DocumentURL))
        //        {
        //            string[] strURL = model.DocumentURL.Split('|');
        //            string[] strTitle = model.DocumentTitle.Split('|');
        //            for (int i = 0; i < strURL.Length; i++)
        //            {
        //                DocumentModel Document = new DocumentModel();
        //                Document.Title = Convert.ToString(strTitle[i]);
        //                Document.Url = ConfigurationManager.AppSettings["DocumentCenterURL"].ToString() + Convert.ToString(strURL[i]);
        //                Document.DownloadUrl = Convert.ToString(strURL[i]);
        //                Document.CaseID = model.CaseID;
        //                Document.CaseNo = model.CaseNo;
        //                Document.District = model.District;
        //                Document.AllowFileRemoved = false;
        //                Document.AllowFileDownload = true;
        //                Document.AllowFileView = true;
        //                Document.AllowFileAttachment = false;
        //                Documents.Add(Document);
        //            }
        //        }
        //    }
        //    return Documents;

        //}

        /// <summary>
        /// Bind the Document list
        /// </summary>
        /// <param name="models">Evedence Models List</param>
        /// <returns></returns>
        private List<DocumentModel> BindDocumentList(List<EvidenceModel> models, UserModel userInfo, bool type)
        {
            List<DocumentModel> Documents = new List<DocumentModel>();

            foreach (EvidenceModel model in models)
            {
                if (!string.IsNullOrEmpty(model.DocumentURL))
                {
                    string[] strURL = model.DocumentURL.Split('|');
                    string[] strTitle = model.DocumentTitle.Split('|');
                    string[] strFileNames = model.DocumentFileName != null ? model.DocumentFileName.Split('|') : null;

                    for (int i = 0; i < strURL.Length; i++)
                    {
                        DocumentModel Document = new DocumentModel();
                        Document.Title = Convert.ToString(strTitle[i]);
                        Document.Url = ConfigurationManager.AppSettings["DocumentCenterURL"].ToString() + Convert.ToString(strURL[i]);
                        Document.DownloadUrl = Convert.ToString(strURL[i]);
                        Document.CaseID = model.CaseID;
                        Document.CaseNo = model.CaseNo;
                        Document.FIRNo = model.FIRNo;
                        Document.District = model.District;
                        Document.CaseStatusTitle = model.CaseStatusTitle;
                        Document.PoliceStationTitle = model.PoliceStationTitle;
                        Document.FileName = strFileNames != null ? Convert.ToString(strFileNames[i]) : "";

                        //if (type)
                        //{
                        Document.AllowFileRemoved = userInfo.AllowFileRemoved;
                        Document.AllowFileDownload = userInfo.AllowFileDownload;
                        Document.AllowFileView = userInfo.AllowFileView;
                        Document.AllowFileAttachment = userInfo.AllowFileAttachment;
                        //}
                        //else
                        //{
                        //    Document.AllowFileRemoved = false;
                        //    Document.AllowFileDownload = true;
                        //    Document.AllowFileView = true;
                        //    Document.AllowFileAttachment = false;
                        //}
                        Documents.Add(Document);
                    }
                }
            }
            return Documents;

        }

        /// <summary>
        /// Update IsSendEmail
        /// </summary>
        /// <returns></returns>
        public int? SaveEmailLog(AgencyEmail model, int? userID)
        {
            DataTable dtDTL = null;
            try
            {
                 CommonBLL commonBLL = LazyBaseSingletonDAL<CommonBLL>.Instance;

                 if (model.EmailAgencies != null && model.EmailAgencies.Count > 0)
                 {
                  //   CommonBuildModel o = new CommonBuildModel();
                     dtDTL = LazyBaseSingletonDAL<CommonBuildModel>.Instance.ToDataTable((from item in model.EmailAgencies
                                                                                 select new
                                                                                 {
                                                                                     item.Email,
                                                                                     item.AgencyID
                                                                                 }).ToList());

                     //dtDTL = o.ToDataTable((from item in model.EmailAgencies
                     //                       select new
                     //                       {
                     //                           item.Email
                     //                       }).ToList());
                 }
                 return LazyBaseSingletonDAL<EvidenceInformationDAL>.Instance.saveEmailLog(model,dtDTL, userID);
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
                return null;

        }

        /// <summary>
        /// Update IsSendEmail
        /// </summary>
        /// <returns></returns>
        public int? SaveRequestToPoliceAPILogs(PoliceRequestData model, int? userID)
        {
            
            try
            {
                CommonBLL commonBLL = LazyBaseSingletonDAL<CommonBLL>.Instance;

                return LazyBaseSingletonDAL<EvidenceInformationDAL>.Instance.SaveRequestToPoliceAPILogs(model, userID);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return null;

        }
    }
}
