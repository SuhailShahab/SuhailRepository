﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.CustomEnums
{
    public enum FileProcessName : int
    {
        None = 0,
        FileUpload = 1,
        FileDownload = 2,
        FileDelete = 3
    }
}
