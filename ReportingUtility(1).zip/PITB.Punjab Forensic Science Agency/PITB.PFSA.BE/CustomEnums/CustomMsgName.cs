﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.CustomEnums
{
    public enum CustomMsgName : int
    {
         none = 0,
        [StrValue("Title already exist.")]
        DuplicateTite = 1,
        [StrValue("Report Name is missing.")]
        MissingRptName = 2,
        [StrValue("Code already exist.")]
        DuplicateCode = 3,
        [StrValue("Service can only be edit not add.")]
        ServiceNotAdd = 4,
        [StrValue("CaseNo already exist.")]
        DuplicateCaseNo = 5,
        [StrValue("Email already exists.")]
        DuplicateEmail = 6,
        [StrValue("CNIC already exists.")]
        DuplicateCNIC = 7,
        [StrValue("Login name already exists.")]
        DuplicateLoginName = 8,
    
    }
    public class StrValue : System.Attribute
    {
        private string strValue;

        public StrValue(string value)
        {
            strValue = value;
        }

        public string Value
        {
            get { return strValue; }
        }

    }

    public static class CustomMsg
    {
        public static string DuplicateTitle
        {
            get
            {
                return StringEnum.GetCode(CustomMsgName.DuplicateTite);
            }
        }
        public static string DuplicateEmail
        {
            get
            {
                return StringEnum.GetCode(CustomMsgName.DuplicateEmail);
            }
        }
        public static string DuplicateCNIC
        {
            get
            {
                return StringEnum.GetCode(CustomMsgName.DuplicateCNIC);
            }
        }
        public static string DuplicateLoginName
        {
            get
            {
                return StringEnum.GetCode(CustomMsgName.DuplicateLoginName);
            }
        }
       
        public static string DuplicateCode
        {
            get
            {
                return StringEnum.GetCode(CustomMsgName.DuplicateCode);
            }
        }
        public static string MissingReportName
        {
            get
            {
                return StringEnum.GetCode(CustomMsgName.MissingRptName);
            }
        }

        public static string ServiceNotAdd
        {
            get
            {
                return StringEnum.GetCode(CustomMsgName.ServiceNotAdd);
            }
        }

        public static string DuplicateCaseNo
        {
            get
            {
                return StringEnum.GetCode(CustomMsgName.DuplicateCaseNo);
            }
        }


    }
    public static class StringEnum
    {
        public static string GetCode(Enum value)
        {
            string output = null;
            Type type = value.GetType();

            //Check first in our cached results...

            //Look for our 'StringValueAttribute' 

            //in the field's custom attributes

            FieldInfo fi = type.GetField(value.ToString());
            StrValue[] attrs =
               fi.GetCustomAttributes(typeof(StrValue),
                                       false) as StrValue[];
            if (attrs.Length > 0)
            {
                output = attrs[0].Value;
            }

            return output;
        }
       
    }

}
