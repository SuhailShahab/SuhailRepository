﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.CustomEnums
{
   public enum   ReportTypeName:int
    {
       none=0,
       FileProcessingInfo=1,
       FileProcessingInfoDetail=2,
    }
}
