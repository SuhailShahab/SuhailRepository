﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.CustomEnums
{
   public  class PageNames
    {
        /// <summary>
        /// Value is MenuName for Table Feature table
        /// Value is StaticName for Table AppObjects
        /// Note Very Important
        ///Use values of MenuName for Feature table 
        ///Use values are StaticName for AppObjects
        /// </summary>
       public const string ApplicationFeature = "ApplicationFeature";
       public const string ApplicationObjects = "ApplicationObjects";
       public const string GroupPermission = "GroupPermission";
       public const string Users = "user";
       public const string EvidenceInformation = "EvidenceSubmision";
       public const string EvidenceInformation1 = "EvidenceSubmision1";
       public const string Division = "Division";
       public const string ErrorLog = "ErrorLog";
       public const string Home = "index";
       public const string Department = "Department";
       public const string GeneralDistrict = "GeneralDistrict";
       public const string AgencyEmail = "AgencyEmail";
       public const string SubmittedAgency = "SubmittedAgency";
       public const string PoliceStation = "PoliceStation";
       public const string Province = "Province";
       public const string AdminDashboard = "AdminDashboard";
       public const string FileProcessingInfo = "FileProcessingInfo";
       public const string FileProcessingInfoDetail = "FileProcessingInfoDetail";
       public const string FileProcessingActivityReport = "RptFileProcessingActivityReport";
       public const string FileProcessingDetail = "RptFileProcessingDetail";
       /*

       
        public const string TestServerReport = "TestServerReport";
        public const string ActiveDirectory = "ActiveDirectory";
        public const string ChangePassword = "Change Password";
       
        



        public const string ManagerDashBoard = "DasboardManager";
        public const string DashboardDepartment = "Dashboard Department";
        public const string DasboardCSR = "Dasboard CSR";
        public const string Dashboard = "Dashboard";
        public const string DashboardCompetentAuthority = "DashboardCompetentAuthority";

        //Lookups
        public const string ApplicationType = "ApplicationType";
        public const string City = "City";
        public const string DefaultSettings = "DefaultSettings";
        public const string Department = "Department";
        public const string District = "District";
        
        
        public const string DivorceStatus = "DivorceStatus";
        public const string FCLocation = "FC Location";
        public const string Gender = "Gender";
        public const string Group = "Group";
        public const string MaritalStatus = "Marital Status";
        public const string PermitType = "PermitType";
        public const string Relation = "Relation";
        public const string Religion = "Religion";
        public const string Service = "Service";
        public const string StatusProcessTrack = "StatusProcessTrack";
        public const string TaskStatus = "Task Status";
        public const string Tehsil = "Tehsil";
        public const string UnionCouncil = "Union Council";
        public const string VehicleType = "VehicleType";
        public const string ObjectionTypes = "ObjectionTypes";
        public const string DriverType = "DriverType";
        public const string BloodGroup = "BloodGroup";
        public const string CitizenType = "CitizenType";
        public const string ManageFormRights = "ManageFormRights";
        public const string SmsConfiguration = "SMSConfiguration";
        public const string SmsSending = "SMSSending";
        public const string DocumentType = "DocumentType";
        public const string CommonDocumentLibrary = "CommonDocumentLibrary";
        public const string CommonClass = "CommonClass";
        public const string ErrorLog = "ErrorLog";
        public const string ViewCompleteStatistics = "ViewCompleteStatistics";
        public const string ApplicationConfigurationManager = "ApplicationConfiguration";
        public const string DeliveryType = "DeliveryType";
        public const string ServiceType = "ServiceType";


          //Added By Sohail Kamran 20.08.2015
          //   //   //   //
        public const string ServiceConfigPosting = "ServiceConfigPosting";  //Added By Sohail Kamran 25.08.2015
        public const string ServiceFormConfiguration = "ServiceFormConfiguration"; //Added By Sohail Kamran 27.08.2015


        //Added by Sohail Kamran
        /// <summary>
        /// Certificates Page Listing
        /// </summary>
        public const string BirthCertificate = "BirthCertificate";
        public const string CharacterCertificate = "CharacterCertificate";
        public const string DeathCertificate = "DeathCertificate";
        public const string DivorceCertificate = "DivorceCertificate";
        public const string DomicileCertificate = "DomicileCertificate";
        public const string MarriageCertificate = "MarriageCertificate";
        public const string CharacterCertificatePP = "CharacterCertificatePP";
        public const string RecordRoomDirectory = "RecordRoomDirectory";
        //Added by Sohail Kamran
        /// <summary>
        /// FC Services Page Listing 
        /// </summary>
        public const string ArmsLicense = "ArmsLicense";
        public const string CNICCard = "CNICCard";
        public const string DrivingLicense = "DrivingLicense";
        public const string IssuanceFard = "IssuanceFard";
        public const string IssuancePassport = "IssuancePassport";
        public const string MotorVehicle = "MotorVehicle";
        public const string NADRAKiosks = "NADRAKiosks";
        public const string RoutePermit = "RoutePermit";
        public const string TokenTax = "TokenTax";
        public const string VehicleTransfer = "VehicleTransfer";
        public const string ESahulat = "ESahulat";



        public const string RptFCAcitvityReport = "FCActivityReport";
        public const string RptFCUsersReport = "FCUsersReport";

        public const string RptServiceDataPosting = "ServiceDataPostingReport";

        public const string RptServiceStatusesSummary = "ServiceStatusesSummary";

        public const string RptCitizenBiometricsReg = "CitizenBiometricsRegistrationReport";
        public const string CitizenSMSSending = "CitizenSMSSending";
        public const string RptCitizenFeedback = "CitizenFeedback";
         */
    }
}
