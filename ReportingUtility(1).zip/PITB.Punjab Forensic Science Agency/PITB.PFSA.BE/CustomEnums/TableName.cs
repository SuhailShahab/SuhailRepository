﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.RightsManager.CustomEnums
{
    public enum TableName : byte
    {
        tblUsers=1,
        tblDepartments = 2,
        tblAppFeatures = 3,
        tblDistricts = 4,
        tblDivisions = 5,
        tblEvidenceInformations =6,
        tblProvinces=7,
        tblGeneralDistricts = 8,
        tblGroups = 9,
        tblGroupRights = 10,
        tblAppObjects = 11,
        tblUserDistricts =12,
        tblSubmittedAgency = 13,
        tblPoliceStation = 14,
        tblAgencyEmail = 15
        
    }
}
