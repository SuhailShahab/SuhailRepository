﻿using PITB.PFSA.BE;
using System;
using System.Text;

namespace PITB.PFSA.BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <7/10/2014 1:04:04 AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class GroupModel : BaseModel
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        //public bool Status { get; set; }
    }
}