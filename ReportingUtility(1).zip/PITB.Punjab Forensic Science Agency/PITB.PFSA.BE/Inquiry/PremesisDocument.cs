﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Inquiry
{
   public class PremesisDocument
    {
       public List<DocumentModel> Documents { get; set; }
       public string Notification { get; set; }
       public string ModelName { get; set; }
       public bool? IsWithinPremesis { get; set; }
       public int PinNumber { get; set; }
       public string URL { get; set; }
       public string CellNumber { get; set; }
       public int VerifyResult { get; set; }
       

        public PremesisDocument()
        {
                
        }

        public PremesisDocument(string Notification)
        {
            this.Notification = Notification;
        }
    }
}
