﻿using PITB.PFSA.BE.Common;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.RigthManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
=============================================
-- SR#			Modified By                 Modified Date/Time	    Description      
-- 001          Sajjad Aslam				23/May/2017			    Add Email in Evidences Model	
-- 002          Suhail Shahab               06/July/2021            Add UMS Tracking No
-- --------------------------------------------------------------------------------------------------------------------------------------
*/
namespace PITB.PFSA.BE.Inquiry
{
    [ClassMapping(TableName = "tblEvidenceInformations", Identifier = "ID")]
    [Serializable]
    public class EvidenceModel : ManageGroupBaseRight
    {
        public List<DocumentModel> Documents { get; set; }

        public EvidenceModel()
        {
        }
        public EvidenceModel(int? id)
        {
            this.ID = id;
        }
        public EvidenceModel(string notification)
        {
            this.Notification = notification;
        }


        #region Properties


        [MappingInfo(ColumnName = "ID", IdentitySpecification = true)]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "CaseID", IdentitySpecification = false)]
        public string CaseID { get; set; }

        [MappingInfo(ColumnName = "CaseNo", IdentitySpecification = true)]
        public string CaseNo { get; set; }

        [MappingInfo(ColumnName = "OldCaseNo", IdentitySpecification = false)]
        public string OldCaseNo { get; set; }

        [MappingInfo(ColumnName = "FIRNo", IdentitySpecification = false)]
        public string FIRNo { get; set; }

        [MappingInfo(ColumnName = "LetterNo", IdentitySpecification = false)]
        public string LetterNo { get; set; }

        [MappingInfo(ColumnName = "SubmittedAgency", Transient = true)]
        public string SubmittedAgency { get; set; }

        [MappingInfo(ColumnName = "Province", IdentitySpecification = false)]
        public string Province { get; set; }

        [MappingInfo(ColumnName = "ProvinceID", IdentitySpecification = false)]
        public int? ProvinceID { get; set; }



        [MappingInfo(ColumnName = "DistrictID", IdentitySpecification = false)]
        public int? DistrictID { get; set; }


        [MappingInfo(ColumnName = "SubmittedAgencyPhone"), MappingInfo(Transient = true)]
        public string SubmittedAgencyPhone { get; set; }

        [MappingInfo(ColumnName = "InvestOfficerName", IdentitySpecification = false)]
        public string InvestOfficerName { get; set; }

        [MappingInfo(ColumnName = "InvestOfficerPhone", IdentitySpecification = false)]
        public string InvestOfficerPhone { get; set; }

        [MappingInfo(ColumnName = "SubmittedPersonName", IdentitySpecification = false)]
        public string SubmittedPersonName { get; set; }

        [MappingInfo(ColumnName = "SubmittedPersonPhone", IdentitySpecification = false)]
        public string SubmittedPersonPhone { get; set; }

        [MappingInfo(ColumnName = "SubmittedPersonBelt", IdentitySpecification = false)]
        public string SubmittedPersonBelt { get; set; }

        [MappingInfo(ColumnName = "DocumentTitle", IdentitySpecification = false)]
        public string DocumentTitle { get; set; }

        [MappingInfo(ColumnName = "DocumentURL", IdentitySpecification = false)]
        public string DocumentURL { get; set; }

        [MappingInfo(ColumnName = "DocumentFileName", IdentitySpecification = false)]
        public string DocumentFileName { get; set; }

        [MappingInfo(ColumnName = "CaseDate", IdentitySpecification = false)]
        public DateTime CaseDate { get; set; }

        [MappingInfo(ColumnName = "CaseStatusID", IdentitySpecification = false)]
        public int? CaseStatusID { get; set; }
        [MappingInfo(ColumnName = "CountryID", IdentitySpecification = false)]
        public int? CountryID { get; set; }
        [MappingInfo(ColumnName = "PoliceStationID", IdentitySpecification = false)]
        public int? PoliceStationID { get; set; }
        [MappingInfo(ColumnName = "SubmittedAgencyID", IdentitySpecification = false)]
        public int? AgencyID { get; set; }
        //[MappingInfo(ColumnName = "DistrictTitle"), MappingInfo(Transient = true)]
        //public string DistrictTitle { get; set; }
        [MappingInfo(ColumnName = "PoliceStationTitle", Transient = true)]
        public string PoliceStationTitle { get; set; }

        [MappingInfo(ColumnName = "Email", Transient = true)] // 001
        public string Email { get; set; }

        [MappingInfo(ColumnName = "IsSendEmail", Transient = true)] // 001
        public Boolean IsSendEmail { get; set; }

        [MappingInfo(ColumnName = "District", Transient = true)]
        public string District { get; set; }

        [MappingInfo(ColumnName = "CaseStatusTitle", Transient = true)]
        public string CaseStatusTitle { get; set; }

        [MappingInfo(ColumnName = "RESULT_COUNT"), MappingInfo(Transient = true)]
        public int? RESULT_COUNT { get; set; }

        /////////////////////////////////////


        //[MappingInfo(ColumnName = "UserTypeID",Transient = true)]
        //public int ? UserTypeID { get; set; }

        //[MappingInfo(ColumnName = "UserID", Transient = true)]
        //public int ? UserID { get; set; }

        /////////////////////////////////////


        #endregion
        [MappingInfo(ColumnName = "RowNumber", Transient = true)]
        public Int64? RowNo { get; set; }
        [MappingInfo(ColumnName = "UMSTrackNo")]
        public string UMSTrackNo { get; set; }

        [MappingInfo(ColumnName = "PFSADistrictID", Transient = true)]
        public int? PFSADistrictID { get; set; }

        [MappingInfo(ColumnName = "PFSAPoliceStationID", Transient = true)]
        public int? PFSAPoliceStationID { get; set; }
    }

    public class EvidenceModelView : EvidenceModel
    {
        public List<EvidenceModel> Evidences { get; set; }
        public List<GeneralDistrictModel> Districts { get; set; }
        public List<ProvinceModel> Provinces { get; set; }
        public List<PoliceStationModel> PoliceStations { get; set; }
        public List<CaseStatusModel> CaseStatuses { get; set; }
        public List<CountryModel> Countries { get; set; }
        public List<SubmittedAgencyModel> Agencies { get; set; }
        //public string PageSize { get; set; }
        public bool isEdit { get; set; }

        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public int TotalCount { get; set; }

        public EvidenceModelView()
        {
        }
        public EvidenceModelView(string notification)
        {
            this.Notification = notification;
        }
    }
}
