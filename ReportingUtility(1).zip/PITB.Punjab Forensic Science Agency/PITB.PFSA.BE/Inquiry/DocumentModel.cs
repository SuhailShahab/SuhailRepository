﻿using PITB.PFSA.BE.Common;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.RightsManager.CustomEnums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Inquiry
{
    public class DocumentModel :ManageGroupBaseRight//: BaseModel
    {
        #region Properties
        public int RowNo { get; set; }
        public string CaseID { get; set; }
        public string CaseNo { get; set; }
        public int ID { get; set; }
        public string Title { get; set; }
        public string Url { get; set; }
        public string DownloadUrl { get; set; }
        //public bool Status { get; set; }
        public string FIRNo { get; set; }
        public string Type { get; set; }
        public string Size { get; set; }
        public string FileRef { get; set; }
        public string FileName { get; set; }
        public byte[] FileBytes { get; set; }
        public string District { get; set; }
        public string CaseStatusTitle { get; set; }
        public string PoliceStationTitle { get; set; }
      
        //public bool? FileRemove { get; set; }
        //public bool? FileDownload { get; set; }
        //public bool? FileView { get; set; }
        //public bool? FileAdd { get; set; }
        #endregion

        public DocumentModel()
        { 
        }
         public DocumentModel(string notification)
        {
            this.Notification = notification;
        }
    }

    public class DocumentParametes
    {
        public TableName TableName { get; set; }
        public string ID { get; set; }
        public string DocumentURL { get; set; }
        public string DocumentTitles { get; set; }
        public string DocumentFileNames { get; set; }
        public int? CreatedBY { get; set; }
        public FileProcessingInfoModel FileProcessingInfoModel { get; set; }
        public List<DocumentModel> DocumentInfo { get; set; }
      
       
    }
}
