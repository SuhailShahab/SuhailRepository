﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Lookups
{
   public class IndexSearchModel
    {
        public string ID { get; set; }
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int? AgencyID { get; set; }
        public int? StatusID { get; set; }
        public int? DistrictID { get; set; }
        public int? ProvinceID { get; set; }
        public int? StationID { get; set; }
        public bool? IsLoad { get; set; }
        public int? UserID { get; set; }
        public int? UserTypeID { get; set; }
    }
}
