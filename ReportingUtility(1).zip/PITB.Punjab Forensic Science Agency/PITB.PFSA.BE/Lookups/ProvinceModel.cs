﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Lookups
{
    public class ProvinceModel  :  BaseModel
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        
        //public bool Status { get; set; }
        public ProvinceModel()
        { 
        }
        public ProvinceModel(string notification)
        {
            this.Notification = notification;
        }
    }
}
