﻿using PITB.PFSA.BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Lookups
{
    [ClassMapping(TableName = "tblFileProcessStatus", Identifier = "ProcessStatusID")]
    [Serializable]
   public  class FileProcessStatusModel:BaseModel
    {
         [MappingInfo(ColumnName = "ProcessStatusID", IdentitySpecification = false)]
        public int? ID { get; set; }
         [MappingInfo(ColumnName = "Title")]
        public string  Title { get; set; }
    }
}
