﻿using PITB.PFSA.BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <18-01-2016 10:01AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblSubmittedAgency", Identifier = "SubmittedAgencyID")]
    [Serializable]
    public class SubmittedAgencyModel : BaseModel
    {

        public SubmittedAgencyModel()
        { 
        }
        public SubmittedAgencyModel(string notification)
        {
            this.Notification = notification;
        }
        public SubmittedAgencyModel(int? id)
        {
            this.ID = id;
            
        }

        [MappingInfo(ColumnName = "SubmittedAgencyID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }
        [MappingInfo(ColumnName = "Email")]
        public string Email { get; set; }
        //[MappingInfo(ColumnName = "IsActive")]
        //public bool Status { get; set; }
    }
}
