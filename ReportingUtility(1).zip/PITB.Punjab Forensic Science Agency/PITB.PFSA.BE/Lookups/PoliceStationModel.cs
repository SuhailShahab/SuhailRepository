﻿using PITB.PFSA.BE.Common;
using System.Collections.Generic;
using System;

namespace PITB.PFSA.BE.Lookups
{
    public class PoliceStationModel : BaseModel
    {
         public PoliceStationModel()
        {

        }

         public PoliceStationModel(string Notification)
        {
            this.Notification = Notification;
        }
        public PoliceStationModel(int? id)
        {
            this.ID = id;

        }

        [MappingInfo(ColumnName = "PoliceStationID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "DivisionID")]
        public int? DivisionID { get; set; }
        [MappingInfo(ColumnName = "DistrictID")]
        public int? DistrictID { get; set; }
        [MappingInfo(ColumnName = "Code")]
        public string Code { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "TitleUrdu")]
        public string TitleUrdu { get; set; }
        [MappingInfo(ColumnName = "Address")]
        public string Address { get; set; }
        [MappingInfo(ColumnName = "AddressUrdu")]
        public string AddressUrdu { get; set; }
        [MappingInfo(ColumnName = "Division")]
        public string DivisionName { get; set; }
        [MappingInfo(ColumnName = "District")]
        public string DistrictName { get; set; }
    }

    public class PoliceStationModelView
    {
        public List<PoliceStationModel> PoliceStation { get; set; }
        public List<DivisionModel> Divisions { get; set; }
        public List<GeneralDistrictModel> Districts { get; set; }
        public string Notification { get; set; }

        #region "Constructors"

        public PoliceStationModelView()
        {

        }

        public PoliceStationModelView(string Notification)
        {
            this.Notification = Notification;
        }

        #endregion
    }
}
