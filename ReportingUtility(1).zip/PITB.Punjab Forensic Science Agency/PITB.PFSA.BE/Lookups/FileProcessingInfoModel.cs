﻿using PITB.PFSA.BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <18-08-2016 10:01AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblFileProcessingInfo", Identifier = "FileProcessingID")]
    [Serializable]
    public class FileProcessingInfoModel : BaseModel
    {
        [MappingInfo(ColumnName = "FileProcessingID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "CaseID")]
        public string CaseID { get; set; }
        [MappingInfo(ColumnName = "ClientIPAddress")]
        public string ClientIPAddress { get; set; }
        [MappingInfo(ColumnName = "ComputerName")]
        public string ComputerName { get; set; }
        [MappingInfo(ColumnName = "FileName")]
        public string FileName { get; set; }
        [MappingInfo(ColumnName = "FileProcessStatusID")]
        public int? FileProcessStatusID { get; set; }
        
       public FileProcessingInfoModel()
        { 
        }
       public FileProcessingInfoModel(string notification)
        {
            this.Notification = notification;
        }

    }
}
