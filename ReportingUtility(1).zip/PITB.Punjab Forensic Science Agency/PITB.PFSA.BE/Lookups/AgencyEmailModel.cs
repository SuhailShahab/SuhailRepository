﻿using PITB.PFSA.BE.Common;
using PITB.PFSA.BE.Inquiry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Lookups
{
    [ClassMapping(TableName = "tblAgencyEmail", Identifier = "AgencyEmailID")]
    [Serializable]
    public class AgencyEmailModel : BaseModel
    {
        [MappingInfo(ColumnName = "RowNumber")]
        public int? RowNumber { get; set; }
        [MappingInfo(ColumnName = "AgencyEmailID")]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "AgencyID")]
        public int AgencyID { get; set; }
        [MappingInfo(ColumnName = "Email")]
        public string Email { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }


        public AgencyEmailModel()
        {

        }
        public AgencyEmailModel(string notification)
        {
            this.Notification = notification;
        }
        public AgencyEmailModel(int id)
        {
            this.AgencyID = id;

        }

    }

    public class AgencyEmailModelView : BaseModel
    {
        public List<SubmittedAgencyModel> Agencies { get; set; }

        public List<AgencyEmailModel> EmailAgencies { get; set; }

        public List<EmailLogs> EmailLogs { get; set; }

        public AgencyEmailModelView()
        {

        }
        public AgencyEmailModelView(string notification)
        {
            this.Notification = notification;
        }
    }

    public class AgencyEmail : BaseModel
    {
        public int AgencyID { get; set; }
        public string CaseNo { get; set; }
        public string CaseID { get; set; }
        public string UMSTrackNo { get; set; }
        public string FIRNo { get; set; }
        public string PoliceStationTitle { get; set; }
        public string District { get; set; }
        public int? EvidenceID { get; set; }
        public bool? IsAttachedDocument { get; set; }
        public List<AgencyEmailModel> EmailAgencies { get; set; }
        public List<DocumentModel> Documents { get; set; }
        public int? FIMSDistrictID { get; set; }
        public int? FIMSPoliceStationID { get; set; }
    }

    public class EmailLogs : BaseModel
    {
        [MappingInfo(ColumnName = "RowNumber")]
        public Int64 RowNumber { get; set; }

        [MappingInfo(ColumnName = "ID")]
        public int? ID { get; set; }

        [MappingInfo(ColumnName = "Agency")]
        public string Agency { get; set; }

        [MappingInfo(ColumnName = "EvidenceID")]
        public int EvidenceID { get; set; }

        [MappingInfo(ColumnName = "CaseID")]
        public string CaseID { get; set; }

        [MappingInfo(ColumnName = "CaseNo")]
        public string CaseNo { get; set; }

        [MappingInfo(ColumnName = "EmailSentTo")]
        public string EmailSentTo { get; set; }

        [MappingInfo(ColumnName = "UserID")]
        public int? UserID { get; set; }

        [MappingInfo(ColumnName = "SendingDate")]
        public DateTime? SendingDate { get; set; }

        [MappingInfo(ColumnName = "HasAttachment")]
        public bool? HasAttachment { get; set; }

        [MappingInfo(ColumnName = "AgencyTo")]
        public string AgencyTo { get; set; }
    }

    public class PoliceRequestData : BaseModel
    {
        public string CaseNo { get; set; }
        public string UMSTrackNo { get; set; }
        public string FIRNo { get; set; }
        public string PoliceStationTitle { get; set; }
        public string District { get; set; }
        public int? EvidenceID { get; set; }
        public int? FIMSDistrictID { get; set; }
        public int? FIMSPoliceStationID { get; set; }
    }
    public class ResponseModel
    {
        [MappingInfo(ColumnName = "status")]
        public bool status { get; set; }

        [MappingInfo(ColumnName = "Message")]
        public string Message { get; set; }
    }
}