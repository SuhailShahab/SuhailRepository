﻿using PITB.PFSA.BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <19-01-2016 10:01AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    [ClassMapping(TableName = "tblCountry", Identifier = "CountryID")]
    [Serializable]
    public class CountryModel : BaseModel
    {
        [MappingInfo(ColumnName = "CountryID", IdentitySpecification = true)]
        public int? ID { get; set; }
        [MappingInfo(ColumnName = "TitleUrdu")]
        public string TitleUrdu { get; set; }
        [MappingInfo(ColumnName = "Title")]
        public string Title { get; set; }
        [MappingInfo(ColumnName = "Description")]
        public string Description { get; set; }
        //[MappingInfo(ColumnName = "IsActive")]
        //public bool Status { get; set; }

    }
}
