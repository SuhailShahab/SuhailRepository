﻿using PITB.PFSA.BE.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Inquiry
{
    public class EvidenceModel : BaseModel
    {
        #region Properties


        [MappingInfo(ColumnName = "CaseID", IdentitySpecification=true)]
        public int? CaseID { get; set; }

        [MappingInfo(ColumnName = "CaseNo", IdentitySpecification = false)]
        public string CaseNo { get; set; }

        [MappingInfo(ColumnName = "OldCaseNo", IdentitySpecification = false)]
        public string OldCaseNo { get; set; }

        [MappingInfo(ColumnName = "FIRNo", IdentitySpecification = false)]
        public string FIRNo { get; set; }

        [MappingInfo(ColumnName = "LetterNo", IdentitySpecification = false)]
        public string LetterNo { get; set; }


        [MappingInfo(ColumnName = "SubmittedAgency", IdentitySpecification = false)]
        public string SubmittedAgency { get; set; }

        [MappingInfo(ColumnName = "Province", IdentitySpecification = false)]
        public string Province { get; set; }

        [MappingInfo(ColumnName = "ProvinceID", IdentitySpecification = false)]
        public int? ProvinceID { get; set; }

        [MappingInfo(ColumnName = "District", IdentitySpecification = false)]
        public string District { get; set; }

        [MappingInfo(ColumnName = "DistrictID", IdentitySpecification = false)]
        public int? DistrictID { get; set; }

        [MappingInfo(ColumnName = "SubmittedAgencyPhone", IdentitySpecification = false)]
        public string SubmittedAgencyPhone { get; set; }

        [MappingInfo(ColumnName = "InvestOfficerName", IdentitySpecification = false)]
        public string InvestOfficerName { get; set; }

        [MappingInfo(ColumnName = "InvestOfficerPhone", IdentitySpecification = false)]
        public string InvestOfficerPhone { get; set; }

        [MappingInfo(ColumnName = "SubmittedPersonName", IdentitySpecification = false)]
        public string SubmittedPersonName { get; set; }

        [MappingInfo(ColumnName = "SubmittedPersonPhone", IdentitySpecification = false)]
        public string SubmittedPersonPhone { get; set; }

        [MappingInfo(ColumnName = "SubmittedPersonBelt", IdentitySpecification = false)]
        public string SubmittedPersonBelt { get; set; }

        [MappingInfo(ColumnName = "DocumentTitle", IdentitySpecification = false)]
        public string DocumentTitle { get; set; }

        [MappingInfo(ColumnName = "DocumentURL", IdentitySpecification = false)]
        public string DocumentURL { get; set; }

        

        #endregion


       
    }

    public class EvidenceModelView : EvidenceModel
    {
        public List<EvidenceModel> Evidences { get; set; }
        public string PageSize { get; set; }
        public bool isEdit { get; set; }

    }
}
