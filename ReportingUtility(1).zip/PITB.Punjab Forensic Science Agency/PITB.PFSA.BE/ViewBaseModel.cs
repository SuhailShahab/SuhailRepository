﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE
{
   public class ViewBaseModel
    {
        public string  CumtomMessage { get; set; }
    }
}
