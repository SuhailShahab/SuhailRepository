﻿
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.RigthManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.LogManager
{
    public class ErrorLogModel:BaseModel 
    {
        public int? logID { get; set; }
        public string ErrorCode { get; set; }
        public int? DistrictID { get; set; }
        public string Method { get; set; }
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public string Source { get; set; }
        public int IsWebMethod { get; set; }
        public DateTime Created { get; set; }
        public string PageName { get; set; }
        public string PageStaticName { get; set; }
        public Exception CustomException { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        
        // public  DataTable DataUser{ get; set; }




        public ErrorLogModel()
        {

        }
       public ErrorLogModel(Exception ex, string methodName, int webMethod, string PageName,int? createdBy)
        {
            this.CustomException = ex;
            this.Method = methodName;
            this.IsWebMethod = webMethod;

            this.PageName = PageName;
            this.ErrorCode = "0";
            this.CreatedBy = createdBy;
        }

       public ErrorLogModel(Exception ex, string methodName, int webMethod, string PageName, string errorCode, int? createdBy)
        {
            this.CustomException = ex;
            this.Method = methodName;
            this.IsWebMethod = webMethod;

            this.PageName = PageName;
            this.ErrorCode = errorCode;
            this.CreatedBy = createdBy;
        }

       public ErrorLogModel(Exception ex, string methodName, int webMethod, string PageName, string errorCode, UserModel CurrentUser)
       {
           this.CustomException = ex;
           this.Method = methodName;
           this.IsWebMethod = webMethod;

           this.PageName = PageName;
           this.ErrorCode = errorCode;
           this.CreatedBy = CurrentUser.UserID;
           this.DistrictID = CurrentUser.DistrictID;
       }

       public ErrorLogModel(Exception ex, string methodName, int webMethod, string PageName, UserModel CurrentUser)
       {
           if (CurrentUser!=null)
           {
               this.CreatedBy = CurrentUser.UserID;
               this.DistrictID = CurrentUser.DistrictID;
           }
           this.CustomException = ex;
           this.Method = methodName;
           this.IsWebMethod = webMethod;
           this.PageName = PageName;          
          
       }


        public string GetaAllMessages()
        {
            string message = string.Empty;
            Exception innerException = this.CustomException;

            do
            {
                message = message + (string.IsNullOrEmpty(innerException.Message) ? string.Empty : innerException.Message);
                innerException = innerException.InnerException;
            }
            while (innerException != null);

            return message;
        }


    }

    public class ErrorLogModelView : BaseModel 
    {
        //public List<LocationModel> Locations { get; set; }
        public List<PageNameModel> PageNames { get; set; }
        //public List<DivisionModel> Divisions { get; set; }
        public List<GeneralDistrictModel> Districts { get; set; }
        //public List<ServiceModel>  Services  { get; set; }
        public List<ErrorLogModel> ErrorLogs { get; set; }
        public ErrorLogModelView()
        { 
        }
        public ErrorLogModelView(string notification)
        {
            this.Notification = notification;
        }
    }
}
