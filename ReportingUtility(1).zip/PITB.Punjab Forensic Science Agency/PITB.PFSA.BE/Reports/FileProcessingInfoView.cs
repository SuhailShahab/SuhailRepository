﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.RigthManager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.BE.Reports
{
   public class FileProcessingInfoView:BaseModel
    {
        public List<FileProcessStatusModel> FilteProcessStatues { get; set; }
        public List<DepartmentModel> Departments { get; set; }
        public List<UserModel> Users { get; set; }
        public int? DepartmentID { get; set; }
        public int? UserID { get; set; }
        public int? FileProcessStatusID { get; set; }
        public string ReportUrl { get; set; }
        public string LoginName { get; set; }
        public string ReportTypeName { get; set; }
        public string CaseNo { get; set; }
        
        public FileProcessingInfoView()
        { 
        }
        public FileProcessingInfoView(string notification)
        {
            this.Notification = notification;
        }
        //public List<GeneralDistrictModel> AllActiveDistricts { get; set; }
        //public List<GeneralDistrictModel> Districts { get; set; }  
    }

    public class FileProcessingRptParameters:BaseModel
    {
        //int? departmentID, int? userID, int? fileActionID, string fromDate, string toDate, string loginName
        public int? DepartmentID { get; set; }
        public int? UserID { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public int? FileActionID { get; set; }
        public string  LoginName { get; set; }
       // public string PFSAID { get; set; }
        //Case no is actually PFSA ID
        public string CaseNo { get; set; }
    }
}
