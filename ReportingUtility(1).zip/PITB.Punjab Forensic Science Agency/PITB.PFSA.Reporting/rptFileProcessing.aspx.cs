﻿using Microsoft.Reporting.WebForms;
using PITB.PFSA.ApplicationClasses;
using PITB.PFSA.BE.CustomEnums;
using PITB.PFSA.BE.LogManager;
using PITB.PFSA.BE.Reports;
using PITB.PFSA.BLL.CommonUtility;
using PITB.PFSA.BLL.Lookups;
using PITB.PFSA.Reporting.ApplcationClasses;
using PITB.PFSA.UserControl.Reports;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PITB.PFSA.Reporting
{
    public partial class rptFileProcessing : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int? loginID = null;
            try
            {
                //int? departmentID =2, userID= 2, fileActionID=1;
               
                string formDate = string.Empty, toDate = string.Empty, loginName = string.Empty, reportType = string.Empty;
                // lblMessage.Text = "In the name of Allah";
                lblMessage.Text = string.Empty;

                FileProcessingRptParameters parameter = new FileProcessingRptParameters();

                if (Request.QueryString["IsShowReport"] != null && Convert.ToBoolean(Request.QueryString["IsShowReport"]))
                {


                    if (Request.QueryString["DepartmentID"] != null && !string.IsNullOrEmpty(Request.QueryString["DepartmentID"]))
                    {                        
                        parameter.DepartmentID = Convert.ToInt32(Request.QueryString["DepartmentID"]);
                    }

                    if (Request.QueryString["UserID"] != null && !string.IsNullOrEmpty(Request.QueryString["UserID"]))
                    {
                        parameter.UserID = Convert.ToInt32(Request.QueryString["UserID"]);
                        loginID =parameter.UserID;
                    }

                    if (Request.QueryString["FileActionID"] != null && !string.IsNullOrEmpty(Request.QueryString["FileActionID"]))
                    {
                        parameter.FileActionID = Convert.ToInt32(Request.QueryString["FileActionID"]);
                    }


                    formDate = Convert.ToString(Request.QueryString["FromDate"]);
                    toDate = Convert.ToString(Request.QueryString["ToDate"]);

                    if (!string.IsNullOrEmpty(formDate) && !string.IsNullOrEmpty(toDate))
                    {
                        parameter.FromDate = LazyBaseSingletonUI<CommonUtility>.Instance.ConvertDateFormat(formDate);
                        parameter.ToDate = LazyBaseSingletonUI<CommonUtility>.Instance.ConvertDateFormat(toDate);
                    }

                    parameter.LoginName = Convert.ToString(Request.QueryString["LoginName"]);

                    reportType = Convert.ToString(Request.QueryString["rptTypeName"]);

                    // ReportTypeName obje = ReportTypeName.FileProcessingInfoDetail ;
                    // MyEnum myValueAsEnum = (MyEnum)myValueToCast; 
                    ReportTypeName rptType = (ReportTypeName)Enum.Parse(typeof(ReportTypeName), reportType.ToString());


                    switch (rptType)
                    {
                        case ReportTypeName.FileProcessingInfo:
                            this.ShowReport(parameter);
                            break;
                        case ReportTypeName.FileProcessingInfoDetail:
                            string caseNo = Convert.ToString(Request.QueryString["caseNo"]);
                            if (!string.IsNullOrEmpty(caseNo))
                                parameter.CaseNo = caseNo;
                            this.ShowFileProcessingInfoDetail(parameter);
                            break;
                        // default:

                    }


                }
                //loginID = Convert.ToInt32(Request.QueryString["LoginID"]);
            }
            catch (Exception ex)
            {
                if(loginID.HasValue)
                LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 0, PageNames.FileProcessingActivityReport, loginID));
                else
                    LazyBaseSingleton<CommonBLL>.Instance.AddErrorLog(new ErrorLogModel(ex, "GetRecords", 0, PageNames.FileProcessingActivityReport, 0));
                lblMessage.Text = ex.Message;
            }
        }

        public void ShowReport(FileProcessingRptParameters fileInfo)
        {
            
            string dateRange = string.Empty;

            if (fileInfo.FromDate.HasValue && fileInfo.ToDate.HasValue)
            {                
                dateRange = "From Date:" + fileInfo.FromDate + "  To Date:" + fileInfo.ToDate;
            }


            DataTable dt = LazyBaseSingleton<FileProcessingInfoBLL>.Instance.GetrptFileProcessingActivityData(fileInfo);

            UserControl.Reports.ucReportViewer viewer = (ucReportViewer)this.ucReportViewer;
            viewer.ReportName = PageNames.FileProcessingActivityReport;

            #region "add the parameters"
            List<ReportParameter> parameters = null;
            parameters = new List<ReportParameter>();

            parameters.Add(new ReportParameter("UserName", fileInfo.LoginName));
            parameters.Add(new ReportParameter("DateRange", dateRange));
            if (dt.Rows.Count > 0)
                parameters.Add(new ReportParameter("CheckRecord", ""));
            else
                parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));


            #endregion

            // add the data sources
            List<ReportDataSource> datasources = null;
            datasources = new List<ReportDataSource>();
            datasources.Add(new ReportDataSource("dsActionTaskPerform", dt));

            viewer.DataSourceList = datasources;

            // add the parameters
            viewer.ParamList = parameters;

            // load the local report (RDLC)
            viewer.LoadLocalReport();
            // this.ShowReport();
            
        }
        public void ShowFileProcessingInfoDetail(FileProcessingRptParameters fileInfo)
        {
           
            string dateRange = string.Empty;

            if (fileInfo.FromDate.HasValue  && fileInfo.ToDate.HasValue)
            {
              //  dtfromDate = LazyBaseSingletonUI<CommonUtility>.Instance.ConvertDateFormat(fileInfo.FromDate);
              //  dttoDate = LazyBaseSingletonUI<CommonUtility>.Instance.ConvertDateFormat(fileInfo.ToDate);
                dateRange = "From Date:" + fileInfo.FromDate + "  To Date:" + fileInfo.ToDate;
            }


            DataTable dt = LazyBaseSingleton<FileProcessingInfoBLL>.Instance.GetrptFileProcessingDetail(fileInfo);

            UserControl.Reports.ucReportViewer viewer = (ucReportViewer)this.ucReportViewer;
            viewer.ReportName = PageNames.FileProcessingDetail;

            #region "add the parameters"
            List<ReportParameter> parameters = null;
            parameters = new List<ReportParameter>();

            parameters.Add(new ReportParameter("UserName", fileInfo.LoginName));
            parameters.Add(new ReportParameter("DateRange", dateRange));
            if (dt.Rows.Count > 0)
                parameters.Add(new ReportParameter("CheckRecord", ""));
            else
                parameters.Add(new ReportParameter("CheckRecord", "NORECORD"));


            #endregion

            // add the data sources
            List<ReportDataSource> datasources = null;
            datasources = new List<ReportDataSource>();
            datasources.Add(new ReportDataSource("dsActionTaskPerform", dt));

            viewer.DataSourceList = datasources;

            // add the parameters
            viewer.ParamList = parameters;

            // load the local report (RDLC)
            viewer.LoadLocalReport();
            // this.ShowReport();

        }
    }
}