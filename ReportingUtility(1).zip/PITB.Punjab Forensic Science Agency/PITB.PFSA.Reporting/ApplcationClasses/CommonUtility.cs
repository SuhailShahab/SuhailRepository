﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PITB.PFSA.Reporting.ApplcationClasses
{
    public class CommonUtility
    {
        /// <summary>
        /// Convert DateFormate
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public DateTime? ConvertDateFormat(string value)
        {
            DateTime Date = new DateTime();

            string[] arrValue = value.Split('/');
            if (arrValue.Length == 3)
            {
                Date = new DateTime(Convert.ToInt32(arrValue[2]), Convert.ToInt32(arrValue[1]), Convert.ToInt32(arrValue[0]));
            }

            return Date;
        }
    }
}