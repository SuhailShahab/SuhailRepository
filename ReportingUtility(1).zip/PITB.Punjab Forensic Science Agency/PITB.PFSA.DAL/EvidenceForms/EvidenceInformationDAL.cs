﻿using PITB.PFSA.BE.Inquiry;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PITB.PFSA.BE.Lookups;

namespace PITB.PFSA.DAL.EvidenceForms
{
// =================================================================================================================================
// Create by:	<Syed Zeeshan Aqil>
// Create date: <17-09-2015 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time          Desription
// =================================================================================================================================
    public class EvidenceInformationDAL : DALBase
    {


       /// <summary>
       /// Add Evidence Information 
       /// </summary>
       /// <param name="model">Evidence Model</param>
       /// <returns></returns>
        public int Add(EvidenceModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddEvidenceInformation";
                

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);


                //sqlCmd.Parameters.Add(new SqlParameter("@CaseID", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@CaseID"].Value = model.CaseID;

                //sqlCmd.Parameters.Add(new SqlParameter("@CaseNo", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@CaseNo"].Value = model.CaseNo;

                //sqlCmd.Parameters.Add(new SqlParameter("@OldCaseNo", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@OldCaseNo"].Value = model.OldCaseNo;

                //sqlCmd.Parameters.Add(new SqlParameter("@FIRNo", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@FIRNo"].Value = model.FIRNo;

                //sqlCmd.Parameters.Add(new SqlParameter("@LetterNo", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@LetterNo"].Value = model.LetterNo;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedAgency", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedAgency"].Value = model.SubmittedAgency;

                //sqlCmd.Parameters.Add(new SqlParameter("@ProvinceID", SqlDbType.Int));
                //sqlCmd.Parameters["@ProvinceID"].Value = model.ProvinceID;

                //sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                //sqlCmd.Parameters["@DistrictID"].Value = model.DistrictID;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedAgencyPhone", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedAgencyPhone"].Value = model.SubmittedAgencyPhone;

                //sqlCmd.Parameters.Add(new SqlParameter("@InvestOfficerName", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@InvestOfficerName"].Value = model.InvestOfficerName;

                //sqlCmd.Parameters.Add(new SqlParameter("@InvestOfficerPhone", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@InvestOfficerPhone"].Value = model.InvestOfficerPhone;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedPersonName", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedPersonName"].Value = model.SubmittedPersonName;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedPersonPhone", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedPersonPhone"].Value = model.SubmittedPersonPhone;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedPersonBelt", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedPersonBelt"].Value = model.SubmittedPersonBelt;

                //sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@CreatedBy"].Value = model.CreatedBy;

                //sqlCmd.Parameters.Add(new SqlParameter("@CaseDate", SqlDbType.DateTime));
                //sqlCmd.Parameters["@CaseDate"].Value = model.CaseDate;

                result = sqlCmd.ExecuteScalar();
                if (con.State == ConnectionState.Open)
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }


        /// <summary>
        /// Add PinNumber Information 
        /// </summary>
        /// <param name="model">Evidence Model</param>
        /// <returns></returns>
        public int SavePinNumber(int? userID,int? pinNumber)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddPinNumber ";

                sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlCmd.Parameters["@UserID"].Value = userID;

                sqlCmd.Parameters.Add(new SqlParameter("@PinNumber", SqlDbType.Int));
                sqlCmd.Parameters["@PinNumber"].Value = pinNumber;


                result = sqlCmd.ExecuteScalar();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Verify PinNumber Information 
        /// </summary>
        /// <param name="model">Evidence Model</param>
        /// <returns></returns>
        public int GetVerifyPinNumber(int? userID,int? pinNumber)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spGetPinNumber ";

                sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlCmd.Parameters["@UserID"].Value = userID;

                sqlCmd.Parameters.Add(new SqlParameter("@PinNumber", SqlDbType.Int));
                sqlCmd.Parameters["@PinNumber"].Value = pinNumber;


                result = sqlCmd.ExecuteScalar();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }
      
        /// <summary>
        /// Edit Evidence Information 
        /// </summary>
        /// <param name="model">Evidence Model</param>
        /// <returns></returns>
        public int Edit(EvidenceModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditEvidenceInformation";


                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                //sqlCmd.Parameters.Add(new SqlParameter("@CaseID", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@CaseID"].Value = model.CaseID;


                //sqlCmd.Parameters.Add(new SqlParameter("@CaseNo", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@CaseNo"].Value = model.CaseNo;

                //sqlCmd.Parameters.Add(new SqlParameter("@OldCaseNo", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@OldCaseNo"].Value = model.OldCaseNo;

                //sqlCmd.Parameters.Add(new SqlParameter("@FIRNo", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@FIRNo"].Value = model.FIRNo;

                //sqlCmd.Parameters.Add(new SqlParameter("@LetterNo", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@LetterNo"].Value = model.LetterNo;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedAgency", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedAgency"].Value = model.SubmittedAgency;

                //sqlCmd.Parameters.Add(new SqlParameter("@ProvinceID", SqlDbType.Int));
                //sqlCmd.Parameters["@ProvinceID"].Value = model.ProvinceID;

                //sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                //sqlCmd.Parameters["@DistrictID"].Value = model.DistrictID;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedAgencyPhone", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedAgencyPhone"].Value = model.SubmittedAgencyPhone;

                //sqlCmd.Parameters.Add(new SqlParameter("@InvestOfficerName", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@InvestOfficerName"].Value = model.InvestOfficerName;

                //sqlCmd.Parameters.Add(new SqlParameter("@InvestOfficerPhone", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@InvestOfficerPhone"].Value = model.InvestOfficerPhone;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedPersonName", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedPersonName"].Value = model.SubmittedPersonName;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedPersonPhone", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedPersonPhone"].Value = model.SubmittedPersonPhone;

                //sqlCmd.Parameters.Add(new SqlParameter("@SubmittedPersonBelt", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@SubmittedPersonBelt"].Value = model.SubmittedPersonBelt;

                ////_sqlCmd.Parameters.Add(new SqlParameter("@DocumentTitle", SqlDbType.NVarChar));
                ////_sqlCmd.Parameters["@DocumentTitle"].Value = model.DocumentTitle;

                ////_sqlCmd.Parameters.Add(new SqlParameter("@DocumentURL", SqlDbType.NVarChar));
                ////_sqlCmd.Parameters["@DocumentURL"].Value = model.DocumentURL;

                //sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                //sqlCmd.Parameters["@CreatedBy"].Value = model.CreatedBy;

                //sqlCmd.Parameters.Add(new SqlParameter("@VersionNo", SqlDbType.Int));
                //sqlCmd.Parameters["@VersionNo"].Value = model.VersionNo;

                //sqlCmd.Parameters.Add(new SqlParameter("@CaseDate", SqlDbType.DateTime));
                //sqlCmd.Parameters["@CaseDate"].Value = model.CaseDate;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Edit Evidence Information 
        /// </summary>
        /// <param name="model">Evidence Model</param>
        /// <returns></returns>
        public int saveEmailLog(AgencyEmail model, DataTable dtDTL, int? userID)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.CommandText = "spUpdateIsSendEmail";
                sqlCmd.CommandText = "spAddtAgencyEmailLog";
                                
                sqlCmd.Parameters.Add(new SqlParameter("@AgencyID", SqlDbType.Int));
                sqlCmd.Parameters["@AgencyID"].Value = model.AgencyID;
                sqlCmd.Parameters.Add(new SqlParameter("@EvidenceID", SqlDbType.Int));
                sqlCmd.Parameters["@EvidenceID"].Value = model.EvidenceID;

                sqlCmd.Parameters.Add(new SqlParameter("@EmailSentTo", SqlDbType.Structured));
                sqlCmd.Parameters["@EmailSentTo"].Value = dtDTL;
                sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlCmd.Parameters["@UserID"].Value = userID;
                sqlCmd.Parameters.Add(new SqlParameter("@HasAttachment", SqlDbType.Bit));
                sqlCmd.Parameters["@HasAttachment"].Value = model.IsAttachedDocument;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Edit Evidence Information 
        /// </summary>
        /// <param name="model">Evidence Model</param>
        /// <returns></returns>
        public int SaveRequestToPoliceAPILogs(PoliceRequestData model, int? userID)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.CommandText = "spUpdateIsSendEmail";
                sqlCmd.CommandText = "spSaveRequestToPoliceAPILogs";

                sqlCmd.Parameters.Add(new SqlParameter("@EvidenceID", SqlDbType.Int));
                sqlCmd.Parameters["@EvidenceID"].Value = model.EvidenceID;
                sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlCmd.Parameters["@UserID"].Value = userID;
                sqlCmd.Parameters.Add(new SqlParameter("@CaseNo", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CaseNo"].Value = model.CaseNo;
                sqlCmd.Parameters.Add(new SqlParameter("@FIRNo", SqlDbType.NVarChar));
                sqlCmd.Parameters["@FIRNo"].Value = model.FIRNo;
                sqlCmd.Parameters.Add(new SqlParameter("@PoliceStationTitle", SqlDbType.NVarChar));
                sqlCmd.Parameters["@PoliceStationTitle"].Value = model.PoliceStationTitle;
                sqlCmd.Parameters.Add(new SqlParameter("@District", SqlDbType.NVarChar));
                sqlCmd.Parameters["@District"].Value = model.District;
                sqlCmd.Parameters.Add(new SqlParameter("@UMSTrackNo", SqlDbType.NVarChar));
                sqlCmd.Parameters["@UMSTrackNo"].Value = model.UMSTrackNo;
                
                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Get  All Evidence Submitted Form Data
        /// </summary>
        /// <returns></returns>
        public DataTable GetEvidenceFormData(int createdBY, int? districtID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEvidenceInfromation", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBY", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@CreatedBY"].Value = createdBY;

                if (districtID.HasValue && districtID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                }
                

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        ///Get  Evidence Submitted Form Data By Case ID
        /// </summary>
        /// <returns></returns>
        public DataTable GetEvidenceFormDataByID(string id)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEvidenceInfromationByID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@ID"].Value = id;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        ///Get  Evidence Submitted Form Data By Case ID
        /// </summary>
        /// <returns></returns>
        public DataTable GetEvidenceFormDataByID(string id, int? UserID, int? DistrictID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEvidenceInfromationByIDForDashBoard", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@ID"].Value = id;

                if (DistrictID.HasValue && DistrictID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;
                }
                if (UserID.HasValue && UserID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = UserID;
                }

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable GetEvidenceFormDataByID(string id, UserModel userInfo)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEvidenceInfromationByIDForDashBoard1", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@ID"].Value = id;

                if (userInfo.DistrictID.HasValue && userInfo.DistrictID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = userInfo.DistrictID;
                }
                if (userInfo.UserID.HasValue && userInfo.UserID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userInfo.UserID;
                }

                if (userInfo.UserID.HasValue && userInfo.UserID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserTypeID"].Value = userInfo.UserTypeID;
                }

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataTable GetEvidenceInfromationByIDForDashBoardDBP(int? UserID, int? DistrictID,  int pageNo, int pageSize, string searchText)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEvidenceInfromationByIDForDashBoardDBP", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                //sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                //sqlDadp.SelectCommand.Parameters["@ID"].Value = id;

                if (DistrictID.HasValue && DistrictID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;
                }
                if (UserID.HasValue && UserID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = UserID;
                }


                /*************************************************************************************/
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                //if (!string.IsNullOrEmpty(searchText))
                //{
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.Text));
                    sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                //}
                /*************************************************************************************/



                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        ///Get  Evidence Submitted Form Data 
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllEvidenceData()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllEvidenceData", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
              
        /// <summary>
       /// Get Evidence data from DB by user id and District
       /// </summary>
       /// <param name="createdBY">Created Person ID</param>
       /// <param name="districtID">Created Person District</param>
       /// <returns></returns>
        public DataTable GetEvidenceDataByUserID(int createdBY,int? districtID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEvidenceInfromationByUserID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBY", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@CreatedBY"].Value = createdBY;

                if(districtID.HasValue && districtID.Value >0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                }
                

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get All Evidence Info By ID
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllEvidenceInformationByID(int createdBY, int? districtID, int? UserTypeID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllEvidenceInfromationByID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBY", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@CreatedBY"].Value = createdBY;

                if (districtID.HasValue && districtID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                }
                if (UserTypeID.HasValue && UserTypeID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserTypeID"].Value = UserTypeID;
                }

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetEvidencePagingData(int? pageIndex, int? pageSize, int? createdBY, int? districtID, int? UserTypeID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    using (SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEvidencepagingData", con))
                    {
                        sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageIndex", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@PageIndex"].Value = pageIndex;

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBY", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CreatedBY"].Value = createdBY;

                        if (districtID.HasValue && districtID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                        }
                        if (UserTypeID.HasValue && UserTypeID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@UserTypeID"].Value = UserTypeID;
                        }

                        sqlDadp.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataSet GetEvidencePagingDataBySearch(IndexSearchModel paramObject)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    using (SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEvidenceInfoPagingBySearchAdvanced", con))
                    {
                        sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;


                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageIndex", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@PageIndex"].Value = paramObject.PageIndex;

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@PageSize"].Value = paramObject.PageSize;

                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBY", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@CreatedBY"].Value = paramObject.UserID;

                        if (!string.IsNullOrEmpty(paramObject.ID))
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.NVarChar));
                            sqlDadp.SelectCommand.Parameters["@ID"].Value = paramObject.ID;
                        }
                        if (paramObject.DistrictID.HasValue && paramObject.DistrictID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = paramObject.DistrictID;
                        }
                        if (paramObject.UserTypeID.HasValue && paramObject.UserTypeID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@UserTypeID"].Value = paramObject.UserTypeID;
                        }
                        if (paramObject.AgencyID.HasValue && paramObject.AgencyID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AgencyID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@AgencyID"].Value = paramObject.AgencyID;
                        }
                        if (paramObject.StatusID.HasValue && paramObject.StatusID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@StatusID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@StatusID"].Value = paramObject.StatusID;
                        }
                        if (paramObject.ProvinceID.HasValue && paramObject.ProvinceID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ProvinceID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@ProvinceID"].Value = paramObject.ProvinceID;
                        }
                        if (paramObject.StationID.HasValue && paramObject.StationID.Value > 0)
                        {
                            sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PoliceStationID", SqlDbType.Int));
                            sqlDadp.SelectCommand.Parameters["@PoliceStationID"].Value = paramObject.StationID;
                        }

                        sqlDadp.Fill(ds);
                        return ds;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="createdBY"></param>
        /// <param name="districtID"></param>
        /// <param name="UserTypeID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public DataTable GetAllEvidenceInfromationByIdDBP(int createdBY, int? districtID, int? UserTypeID, int pageNo, int pageSize, string searchText)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllEvidenceInfromationByIdDBP", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBY", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@CreatedBY"].Value = createdBY;

                if (districtID.HasValue && districtID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                }
                if (UserTypeID.HasValue && UserTypeID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserTypeID"].Value = UserTypeID;
                }

                /*************************************************************************************/
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@PageNo"].Value = pageNo;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@PageSize"].Value = pageSize;

                if (!string.IsNullOrEmpty(searchText))
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.Text));
                    sqlDadp.SelectCommand.Parameters["@SearchText"].Value = searchText;
                }
                /*************************************************************************************/


                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="createdBY"></param>
        /// <param name="districtID"></param>
        /// <param name="userTypeID"></param>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public DataTable GetAllEvidenceSubmissionsDBP(IndexSearchModel paramModel)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllEvidenceInfromationDBP", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CreatedBY", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@CreatedBY"].Value = paramModel.UserID;

                if (paramModel.DistrictID.HasValue && paramModel.DistrictID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = paramModel.DistrictID;
                }
                if (paramModel.UserTypeID.HasValue && paramModel.UserTypeID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserTypeID"].Value = paramModel.UserTypeID;
                }
                
                /*************************************************************************************/
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNo", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@PageNo"].Value = paramModel.PageIndex;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@PageSize"].Value = paramModel.PageSize;

                if (!string.IsNullOrEmpty(paramModel.ID))
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchText", SqlDbType.Text));
                    sqlDadp.SelectCommand.Parameters["@SearchText"].Value = paramModel.ID;
                }
                /*************************************************************************************/
                if (paramModel.AgencyID.HasValue && paramModel.AgencyID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AgencyID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@AgencyID"].Value = paramModel.AgencyID;
                }
                if (paramModel.StatusID.HasValue && paramModel.StatusID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@StatusID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@StatusID"].Value = paramModel.StatusID;
                }
                if (paramModel.ProvinceID.HasValue && paramModel.ProvinceID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@ProvinceID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@ProvinceID"].Value = paramModel.ProvinceID;
                }
                if (paramModel.StationID.HasValue && paramModel.StationID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PoliceStationID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@PoliceStationID"].Value = paramModel.StationID;
                }

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        
    }
}
