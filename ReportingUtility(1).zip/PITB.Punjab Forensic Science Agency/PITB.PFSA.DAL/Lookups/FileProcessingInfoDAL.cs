﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.Reports;
using PITB.PFSA.DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.DAL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <18-08-2016 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class FileProcessingInfoDAL : DALBase
    {
        public int? Add(FileProcessingInfoModel model)
        {
            object result = 0;

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddFileProcessingInfo";

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                        result = sqlCmd.ExecuteScalar();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt32(result);
        }
        public int? Add(FileProcessingInfoModel model,DataTable dt)
        {
            object result = 0;

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {

                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddMulitpleFilesInfo";

                        LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);
                        sqlCmd.Parameters.Add(new SqlParameter("@FileTitles", SqlDbType.Structured));
                        sqlCmd.Parameters["@FileTitles"].Value = dt;

                        result = sqlCmd.ExecuteScalar();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();

                    }
                }
            }

            return Convert.ToInt32(result);
        }

        public DataTable GetrptFileProcessingActivityData(FileProcessingRptParameters fileInfo)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetRptFileProcessingActivityData", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    FillParameters(fileInfo, sqlDadp);

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static void FillParameters(FileProcessingRptParameters fileInfo, SqlDataAdapter sqlDadp)
        {
            if (fileInfo.DepartmentID.HasValue && fileInfo.DepartmentID.Value > 0)
            {
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = fileInfo.DepartmentID;
            }

            if (fileInfo.UserID.HasValue && fileInfo.UserID.Value > 0)
            {
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@UserID"].Value = fileInfo.UserID;
            }

            if (fileInfo.FileActionID.HasValue && fileInfo.FileActionID.Value > 0)
            {
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@FileProcessStatusID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@FileProcessStatusID"].Value = fileInfo.FileActionID;
            }

            if (fileInfo.FromDate.HasValue)
            {
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dtFrom", SqlDbType.DateTime));
                sqlDadp.SelectCommand.Parameters["@dtFrom"].Value = fileInfo.FromDate;
            }

            if (fileInfo.ToDate.HasValue)
            {
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@dtto", SqlDbType.DateTime));
                sqlDadp.SelectCommand.Parameters["@dtto"].Value = fileInfo.ToDate;
            }
        }
        public DataTable GetrptFileProcessingDetail(FileProcessingRptParameters fileInfo)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetRptFileProcessingDTLInfo", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    FillParameters(fileInfo, sqlDadp);

                    if (!string.IsNullOrEmpty(fileInfo.CaseNo))
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@CaseNo", SqlDbType.VarChar));
                        sqlDadp.SelectCommand.Parameters["@CaseNo"].Value = fileInfo.CaseNo;
                    }

                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
