﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.DAL.Lookups
{
    public class AgencyEmailDAL : DALBase
    {

       /// <summary>
       /// Deactivate Submitted Agency Model Information
       /// </summary>
       /// <param name="model"></param>
       /// <returns></returns>
        public int Delete(AgencyEmailModel model)
       {
           int result = 0;
           SqlConnection con = new SqlConnection(this.spConnectionString);
           SqlCommand sqlCmd = new SqlCommand();

           try
           {
               con.Open();
               sqlCmd.Connection = con;
               sqlCmd.CommandType = CommandType.StoredProcedure;
               sqlCmd.CommandText = "spDeleteAgencyEmail";
               LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);
               result = sqlCmd.ExecuteNonQuery();
               con.Close();
           }
           catch (Exception ex)
           {
               throw ex;
           }

           return result;
       }

       /// <summary>
       /// Saving Submitted Agency Model Information
       /// </summary>
       /// <param name="model"></param>
       /// <returns></returns>
       public int? Add(AgencyEmailModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddAgencyEmail";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);
                result = sqlCmd.ExecuteScalar();
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return null;

        }

       /// <summary>
       /// Modifing Submitted Agency Model Information
       /// </summary>
       /// <param name="model"></param>
       /// <returns></returns>
       public int? Edit(AgencyEmailModel model)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditAgencyEmail";


                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = sqlCmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }


       /// <summary>
       /// Get All Agencies Information
       /// </summary>
       /// <returns></returns>
       public DataTable SelectAll()
       {
           DataTable dt = new DataTable();

           try
           {
               SqlConnection con = new SqlConnection(this.spConnectionString);
               SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllAgenciesEmail", con);              
               sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

               sqlDadp.Fill(dt);
               return dt;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       /// <summary>
       /// Get All Agencies Emails
       /// </summary>
       /// <returns></returns>
       public DataTable GetAgencyEmailsByID(int agencyID)
       {
           DataTable dt = new DataTable();

           try
           {
               SqlConnection con = new SqlConnection(this.spConnectionString);
               SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllAgenciesEmailByAgencyID", con);

               sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
               sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@AgencyID", SqlDbType.NVarChar));
               sqlDadp.SelectCommand.Parameters["@AgencyID"].Value = agencyID;
               sqlDadp.Fill(dt);
               return dt;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       /// <summary>
       /// Get Sent Emails Logs by evidenceID
       /// </summary>
       /// <returns></returns>
       public DataTable GetEmailsLogs(int evidenceID)
       {
           DataTable dt = new DataTable();

           try
           {
               SqlConnection con = new SqlConnection(this.spConnectionString);
               SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetEmailLogsByEvidenceID", con);

               sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
               sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@EvidenceID", SqlDbType.NVarChar));
               sqlDadp.SelectCommand.Parameters["@EvidenceID"].Value = evidenceID;
               sqlDadp.Fill(dt);
               return dt;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

    }
}
