﻿using PITB.PFSA.DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.DAL.Lookups
{
    public class PageNameDAL:DALBase
    {
        /// <summary>
        /// Get Page Names
        /// </summary>
        /// <returns></returns>
        public DataTable GetPages()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("GetPages", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
