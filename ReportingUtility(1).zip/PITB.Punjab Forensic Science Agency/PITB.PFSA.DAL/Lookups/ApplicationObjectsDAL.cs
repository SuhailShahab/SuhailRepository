﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.DAL.Lookups
{
    public class ApplicationObjectsDAL:DALBase
    {
        
        public ApplicationObjectsDAL()
        {

        }
        public ApplicationObjectsDAL(SqlConnection con)
        {
            this.dbConnection = con;
        }
        public ApplicationObjectsDAL(SqlConnection con, SqlTransaction transaction)
        {
            this.dbConnection = con;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Add(ApplicationObjectsModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
              
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddApplicationObjects";

                sqlCmd.Parameters.Add(new SqlParameter("@AppFeatureID", SqlDbType.Int));
                sqlCmd.Parameters["@AppFeatureID"].Value = model.AppFeatureID;
                sqlCmd.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Name"].Value = model.Name;
                sqlCmd.Parameters.Add(new SqlParameter("@StaticName", SqlDbType.NVarChar));
                sqlCmd.Parameters["@StaticName"].Value = model.StaticName.Trim();
                sqlCmd.Parameters.Add(new SqlParameter("@URL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@URL"].Value = model.URL;
                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = model.Description;
                sqlCmd.Parameters.Add(new SqlParameter("@HasChild", SqlDbType.Bit));
                sqlCmd.Parameters["@HasChild"].Value = model.HasChild ? true : false;
                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = model.IsActive ? true : false;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Edit 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int Edit(ApplicationObjectsModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditApplicationObjects";
             
                sqlCmd.Parameters.Add(new SqlParameter("@AppObjectID", SqlDbType.Int));
                sqlCmd.Parameters["@AppObjectID"].Value = model.ID;
                sqlCmd.Parameters.Add(new SqlParameter("@AppFeatureID", SqlDbType.Int));
                sqlCmd.Parameters["@AppFeatureID"].Value = model.AppFeatureID;
                sqlCmd.Parameters.Add(new SqlParameter("@Name", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Name"].Value = model.Name;
                sqlCmd.Parameters.Add(new SqlParameter("@Sort", SqlDbType.Int));
                sqlCmd.Parameters["@Sort"].Value = model.Sort;
              
                sqlCmd.Parameters.Add(new SqlParameter("@URL", SqlDbType.NVarChar));
                sqlCmd.Parameters["@URL"].Value = model.URL;
                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = model.Description;
                sqlCmd.Parameters.Add(new SqlParameter("@HasChild", SqlDbType.Bit));
                sqlCmd.Parameters["@HasChild"].Value = model.HasChild ? true : false;
                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                sqlCmd.Parameters["@IsActive"].Value = model.IsActive ? true : false;
                if (!string.IsNullOrEmpty(model.StaticName))
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@StaticName", SqlDbType.NVarChar));
                    sqlCmd.Parameters["@StaticName"].Value = model.StaticName.Trim();
                }
                result = sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)                  
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }
        /// <summary>
        /// Get all Features for drop down list
        /// </summary>
        /// <returns></returns>
        public DataTable SelectFeatures()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetApplicationFeatures", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Getting all Features for grid
        /// </summary>
        /// <returns></returns>
        public DataTable GetAppObject()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetApplicationObjects", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.Fill(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }
    }
}
