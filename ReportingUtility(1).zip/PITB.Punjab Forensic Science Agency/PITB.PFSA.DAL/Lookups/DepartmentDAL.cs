﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.BE.Lookups;



namespace PITB.PFSA.DAL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Suhail Shahab>
    // Create date: <09-07-2014 10:04AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // =================================================================================================================================
    public class DepartmentDAL : DALBase
    {
        /// <summary>
        /// save Department information
        /// </summary>
        /// <param name="relationModel">Set object of DepartmentModel type</param>
        /// <returns></returns>
        public int Add(DepartmentModel departmentModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
               
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddDepartment";

              // LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameter(departmentModel, false, sqlCmd);               

                SetSqlParameters(departmentModel, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = departmentModel.CreatedBy;

                result = sqlCmd.ExecuteScalar();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }

        private static void SetSqlParameters(DepartmentModel departmentModel, SqlCommand sqlCmd)
        {
            sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Code"].Value = departmentModel.Code;

            sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Title"].Value = departmentModel.Title;

            sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
            sqlCmd.Parameters["@Description"].Value = departmentModel.Description;

            sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
            sqlCmd.Parameters["@IsActive"].Value = departmentModel.Status.Value;
        }

        /// <summary>
        /// Update Department information
        /// </summary>
        /// <param name="departmentModel">Set object of DepartmentModel type</param>
        /// <returns></returns>
        public int Edit(DepartmentModel departmentModel)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditDepartment";

                sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                sqlCmd.Parameters["@DepartmentID"].Value = departmentModel.ID;
                SetSqlParameters(departmentModel, sqlCmd);
                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = departmentModel.CreatedBy;

                result = sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// Delete Department information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, int modifiedBy)
        {
            int _result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                _sqlCmd.Connection = con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteDepartment";

                _sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                _sqlCmd.Parameters["@DepartmentID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                _sqlCmd.Parameters["@ModifiedBy"].Value = Convert.ToInt32(modifiedBy);

                _result = _sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return _result;
        }
        /// <summary>
        /// Get all Active Department
        /// </summary>
        /// <returns></returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetDepartments", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get all Department
        /// </summary>
        /// <returns></returns>
        public DataTable SelectDepartments()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetDepartment", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}
