﻿using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.BE.Lookups;


namespace PITB.PFSA.DAL.Lookups
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <26-12-2014 08:30PM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    // SR#          Modified By                 Modified Date/Time      Desription
    // 001          Muhammad Usman              30-Sep-2015             Add Method Permitted Districts
    // =================================================================================================================================

    public class GeneralDistrictDAL : DALBase
    {
        /// <summary>
        /// save GeneralDistrict information
        /// </summary>
        /// <param name="relationModel">Set object of GeneralDistrictModel type</param>
        /// <returns></returns>
        public int? Add(GeneralDistrictModel districtModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;               
                sqlCmd.CommandText = "spAddGeneralDistrict";

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@DivisionID"].Value = districtModel.DivisionID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = districtModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@TitleUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TitleUrdu"].Value = districtModel.TitleUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = districtModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                if (districtModel.Status.HasValue )
                    sqlCmd.Parameters["@IsActive"].Value = districtModel.Status.Value;
                else
                    sqlCmd.Parameters["@IsActive"].Value =00;


                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = districtModel.CreatedBy;
                

                sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.VarChar));
                sqlCmd.Parameters["@Code"].Value = districtModel.Code;


                result = sqlCmd.ExecuteNonQuery();
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return null;

        }

        /// <summary>
        /// Update District information
        /// </summary>
        /// <param name="districtModel">Set object of DistrictModel type</param>
        /// <returns></returns>
        public int? Edit(GeneralDistrictModel districtModel)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //sqlCmd.CommandText = "spEditDistrict";
                sqlCmd.CommandText = "spEditGeneralDistrict";

                sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@DistrictID"].Value = districtModel.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@DivisionID"].Value = districtModel.DivisionID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = districtModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@TitleUrdu", SqlDbType.NVarChar));
                sqlCmd.Parameters["@TitleUrdu"].Value = districtModel.TitleUrdu;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = districtModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                if (districtModel.Status.HasValue)
                {
                    sqlCmd.Parameters["@IsActive"].Value = districtModel.Status.Value ? 1 : 0;
                }
                else
                {
                    sqlCmd.Parameters["@IsActive"].Value =  0;
                }

                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = districtModel.CreatedBy;

                sqlCmd.Parameters.Add(new SqlParameter("@ProvinceID", SqlDbType.Int));
                sqlCmd.Parameters["@ProvinceID"].Value = districtModel.ProvinceID;

                sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.VarChar));
                sqlCmd.Parameters["@Code"].Value = districtModel.Code;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        /// <summary>
        /// Delete District information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, string modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                //_sqlCmd.CommandText = "spDeleteDistrict";
                _sqlCmd.CommandText = "spDeleteGeneralDistrict";

                _sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                _sqlCmd.Parameters["@DistrictID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                //_sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.VarChar));
                //_sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        ///
        /// </summary>
        /// <returns></returns>
        public DataTable GeneralDistricts(int ? districtID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                //SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrict", con);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistricts", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                if (districtID.HasValue && districtID.Value > 0)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.VarChar));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                }
                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        ///  Get All General Districts 
        /// </summary>
        /// <returns></returns>
        public DataTable All()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllGeneralDistricts", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary> 
        ///  Get All General Districts By User ID
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllGeneralDistrictsByUserID(int? userID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictsByUserID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get  districts by Division ID
        /// CR:002
        /// </summary>
        /// <returns></returns>
        public DataTable GetDistrictsByDivisionID(int DivisionID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                //SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictByDivisionID", con);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetGeneralDistrictByDivisionID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DivisionID"].Value = DivisionID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public int DeleteServiceDistrict(int id, int serviceID)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                //   sqlCmd.CommandText = "spDeleteServiceApplicationType";
                sqlCmd.CommandText = "spDeleteServiceDistrict";

                sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@DistrictID"].Value = id;

                sqlCmd.Parameters.Add(new SqlParameter("@ServiceID", SqlDbType.Int));
                sqlCmd.Parameters["@ServiceID"].Value = serviceID;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                ConCloseDisponse(con);
            }

            return result;
        }

        /// <summary>
        /// Get Permitted Districts against user id or group id  // 001     
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public DataTable GetPermittedDistricts(int userID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetPermittedDistricts", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                sqlDadp.SelectCommand.Parameters.AddWithValue("@UserID", userID);
                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
