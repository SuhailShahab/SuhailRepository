﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.DAL.Generic;
using System;
using System.Data;
using System.Data.SqlClient;

// =================================================================================================================================
// Create by:	<Suhail Shahab>
// Create date: <18-01-2016 10:04AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#          Modified By                 Modified Date/Time                  Desription
// CR:001       Muhammad Hammad Shahid      21-01-2016 05:44:31PM               Add record save, edit and GetAll related mehtods
// =================================================================================================================================
namespace PITB.PFSA.DAL.Lookups
{
    public class PoliceStationDAL : DALBase
    {
        /// <summary>
        /// Add Police Station information
        /// </summary>
        /// <param name="ps">Set object of Police Station Model type</param>
        /// <returns></returns>
        public int Add(PoliceStationModel ps)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();

                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spAddPoliceStation";

                        sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlCmd.Parameters["@DivisionID"].Value = ps.DivisionID;

                        sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlCmd.Parameters["@DistrictID"].Value = ps.DistrictID;

                        sqlCmd.Parameters.Add(new SqlParameter("@TitleUrd", SqlDbType.NVarChar));
                        sqlCmd.Parameters["@TitleUrd"].Value = string.IsNullOrEmpty(ps.TitleUrdu) ? "" : ps.TitleUrdu;

                        sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.VarChar));
                        sqlCmd.Parameters["@Title"].Value = ps.Title;

                        sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.VarChar));
                        sqlCmd.Parameters["@Code"].Value = ps.Code;

                        sqlCmd.Parameters.Add(new SqlParameter("@Address", SqlDbType.VarChar));
                        sqlCmd.Parameters["@Address"].Value = string.IsNullOrEmpty(ps.Address) ? "" : ps.Address;

                        sqlCmd.Parameters.Add(new SqlParameter("@AddressUrdu", SqlDbType.NVarChar));
                        sqlCmd.Parameters["@AddressUrdu"].Value = string.IsNullOrEmpty(ps.AddressUrdu) ? "" : ps.AddressUrdu;

                        sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                        sqlCmd.Parameters["@IsActive"].Value = ps.Status;

                        sqlCmd.Parameters.Add(new SqlParameter("@Author", SqlDbType.Int));
                        sqlCmd.Parameters["@Author"].Value = ps.CreatedBy;

                        result = sqlCmd.ExecuteScalar();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Update Police Station information
        /// </summary>
        /// <param name="ps">Set object of Police Station Model type</param>
        /// <returns></returns>
        public int Edit(PoliceStationModel ps)
        {
            int result = 0;

            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spEditPoliceStation";

                        sqlCmd.Parameters.Add(new SqlParameter("@PoliceStationID", SqlDbType.Int));
                        sqlCmd.Parameters["@PoliceStationID"].Value = ps.ID;

                        sqlCmd.Parameters.Add(new SqlParameter("@DivisionID", SqlDbType.Int));
                        sqlCmd.Parameters["@DivisionID"].Value = ps.DivisionID;

                        sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                        sqlCmd.Parameters["@DistrictID"].Value = ps.DistrictID;

                        sqlCmd.Parameters.Add(new SqlParameter("@TitleUrd", SqlDbType.NVarChar));
                        sqlCmd.Parameters["@TitleUrd"].Value = string.IsNullOrEmpty(ps.TitleUrdu) ? "" : ps.TitleUrdu;

                        sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.VarChar));
                        sqlCmd.Parameters["@Title"].Value = ps.Title;

                        sqlCmd.Parameters.Add(new SqlParameter("@Code", SqlDbType.VarChar));
                        sqlCmd.Parameters["@Code"].Value = ps.Code;

                        sqlCmd.Parameters.Add(new SqlParameter("@Address", SqlDbType.VarChar));
                        sqlCmd.Parameters["@Address"].Value = string.IsNullOrEmpty(ps.Address) ? "" : ps.Address;

                        sqlCmd.Parameters.Add(new SqlParameter("@AddressUrdu", SqlDbType.NVarChar));
                        sqlCmd.Parameters["@AddressUrdu"].Value = string.IsNullOrEmpty(ps.AddressUrdu) ? "" : ps.AddressUrdu;

                        sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                        sqlCmd.Parameters["@IsActive"].Value = ps.Status;

                        sqlCmd.Parameters.Add(new SqlParameter("@Editor", SqlDbType.Int));
                        sqlCmd.Parameters["@Editor"].Value = ps.CreatedBy;

                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }
            return result;
        }

        public int Delete(PoliceStationModel model)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spDeletePoliceStation";
                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);
                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public DataTable SelectAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllPoliceStations", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable SelectAllByIDs(int? districtID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllPoliceStationByDistrictID", con);
                if (districtID.HasValue)
                {
                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = districtID;
                }
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
