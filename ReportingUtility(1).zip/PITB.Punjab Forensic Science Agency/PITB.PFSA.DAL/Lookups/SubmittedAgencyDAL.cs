﻿using PITB.PFSA.BE.Lookups;
using PITB.PFSA.DAL.Generic;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.DAL.Lookups
{
   public  class SubmittedAgencyDAL : DALBase
    {

       /// <summary>
       /// Deactivate Submitted Agency Model Information
       /// </summary>
       /// <param name="model"></param>
       /// <returns></returns>
       public int Delete(SubmittedAgencyModel model)
       {
           int result = 0;
           SqlConnection con = new SqlConnection(this.spConnectionString);
           SqlCommand sqlCmd = new SqlCommand();

           try
           {
               con.Open();
               sqlCmd.Connection = con;
               sqlCmd.CommandType = CommandType.StoredProcedure;
               sqlCmd.CommandText = "spDeleteSubmittedAgency";
               LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);
               result = sqlCmd.ExecuteNonQuery();
               con.Close();
           }
           catch (Exception ex)
           {
               throw ex;
           }

           return result;
       }

       /// <summary>
       /// Saving Submitted Agency Model Information
       /// </summary>
       /// <param name="model"></param>
       /// <returns></returns>
       public int? Add(SubmittedAgencyModel model)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddSubmittedAgency";

                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);
                result = sqlCmd.ExecuteScalar();
                con.Close();
                return Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            return null;

        }

       /// <summary>
       /// Modifing Submitted Agency Model Information
       /// </summary>
       /// <param name="model"></param>
       /// <returns></returns>
       public int? Edit(SubmittedAgencyModel model)
        {
            int? result = null;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditSubmittedAgency";


                LazyBaseSingletonDAL<SqlUtility>.Instance.GetAddParameterExtented(model, sqlCmd);

                result = sqlCmd.ExecuteNonQuery();
                con.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }


       /// <summary>
       /// Get All Agencies Information
       /// </summary>
       /// <returns></returns>
       public DataTable SelectAll()
       {
           DataTable dt = new DataTable();

           try
           {
               SqlConnection con = new SqlConnection(this.spConnectionString);
               SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetAllGegencies", con);              
               sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

               sqlDadp.Fill(dt);
               return dt;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }
    }
}
