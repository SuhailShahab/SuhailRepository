﻿using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.BE.RigthManager;
using PITB.PFSA.RightsManager.CustomEnums;


// =================================================================================================================================
// Create by:	<Muhammad Hammad Shahid>
// Create date: <11-07-2014 10:20AM>
// =================================================================================================================================
// ===================================================== Modification History ======================================================
// SR#             Modified By            Modified Date/Time      Desription
// CR: 001  -      Syed Zeeshan Aqil      28-11-2014 10:32AM      Add  new parameter "AllowFileRemove" in database in tbluser table to set the rights on delete the attached file.
// CR: 002  -      Syed Zeeshan Aqil      10-12-2014 03:32PM      Add  datatable property dtUserRights for save user rights table
// CR: 003  -      Suhial Shahab          28-05-2015 03:32PM      Add  New Add Method  For Add User Right with new parameter FC District ID
// CR: 004  -      Suhial Shahab          28-05-2015 03:32PM      Add  New Edit Method For Add User Right with new parameter FC District ID
// CR: 005         SUHAIL SHAHAB          11-6-2015               Add Address Parameter
// CR: 006         Muhammad Usman         11-6-2015               Add New Method for getting user types
// CR: 007         Syed Zeeshan Aqil      06-07-2015 04:21:08PM   Add new operational rights "File attachment", Residential history, Personal info  and show address info Paneel
// CR: 008         SOHAIL KAMRAN         09-09-2015 04:21:08PM   Add new UserFCLocations
// =================================================================================================================================

namespace PITB.PFSA.DAL.Lookups.RightsManagers
{
    public class UserDAL : DALBase
    {



        /// <summary>
        /// CR: 003
        /// </summary>
        /// <param name="user"></param>
        /// <param name="createdBy"></param>
        /// <returns></returns>
        public int Add(UserRegistration user, int? createdBy)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddUser";

                SetUserSqlParameters(user, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar));
                sqlCmd.Parameters["@Password"].Value = CustomSecurity.EncodePasswordToBase64(user.Password);

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.Int));
                sqlCmd.Parameters["@CreatedBy"].Value = createdBy;

                result = sqlCmd.ExecuteScalar();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(result);
        }




        /// <summary>
        ///  CR: 004 
        /// </summary>
        /// <param name="user"></param>
        /// <param name="modifiedBy"></param>
        /// <returns></returns>
        public int Edit(UserRegistration user, int? modifiedBy)
        {
            //int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditUser";

                this.SetUserSqlParameters(user, sqlCmd);

                sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlCmd.Parameters["@UserID"].Value = user.UserID;



                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;



                if (user.ResignDate.HasValue)
                {
                    sqlCmd.Parameters.Add(new SqlParameter("@ResignedDate", SqlDbType.DateTime));
                    sqlCmd.Parameters["@ResignedDate"].Value = user.ResignDate;
                }



                sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return Convert.ToInt32(user.UserID); 
        }

        /// <summary>
        /// Delete user information
        /// </summary>
        /// <param name="_userID"></param>
        /// <returns></returns>
        public int Delete(int _userID)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteUser";

                _sqlCmd.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                _sqlCmd.Parameters["@UserID"].Value = _userID;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Get user information against provided user id
        /// </summary>
        /// <param name="_userID"></param>
        /// <returns></returns>
        public DataSet SelectUserByID(int _userID)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserByID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@UserID"].Value = _userID;

                sqlDadp.Fill(ds);
                ds.Tables[0].TableName = TableName.tblUsers.ToString();
               // ds.Tables[1].TableName = TableName.tblUserDistricts.ToString();

                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Get user information against provided user id
        /// </summary>
        /// <param name="_userID"></param>
        /// <returns></returns>
        public DataTable SelectDistrictByUserID(int _userID) 
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetDistrictByUserID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@UserID"].Value = _userID;

                sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        // CR: 006 
        /// <summary>
        /// Get user information against User Type and District
        /// </summary>
        /// <param name="_userID"></param>
        /// <returns></returns>
        public DataTable SelectUserByTypeID(int DistrictID, int UserTypeID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spUsersByUserType", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;
                sqlDadp.SelectCommand.Parameters["@UserTypeID"].Value = UserTypeID;

                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get all users with paging for listing
        /// </summary>
        /// <param name="_districtID"></param>
        /// <param name="_tehsilID"></param>
        /// <param name="_unionCouncilID"></param>
        /// <param name="_PageNumber"></param>
        /// <param name="_PageSize"></param>
        /// <param name="_culture"></param>
        /// <param name="_searchIn"></param>
        /// <param name="_keyword"></param>
        /// <returns></returns>
        public DataSet SelectUsers(int _districtID, Int32 _pageNumber, Int32 _pageSize, string _searchIn, string _keyword)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetUser", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = _districtID;

                //_sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@TehsilID", SqlDbType.Int));
                //_sqlDadp.SelectCommand.Parameters["@TehsilID"].Value = _tehsilID;

                //_sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UnionCouncilID", SqlDbType.Int));
                //_sqlDadp.SelectCommand.Parameters["@UnionCouncilID"].Value = _unionCouncilID;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageNumber", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@PageNumber"].Value = _pageNumber;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@PageSize", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@PageSize"].Value = _pageSize;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SearchIn", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@SearchIn"].Value = _searchIn;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Keyword", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Keyword"].Value = _keyword;

                _sqlDadp.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// get user information against provided user name
        /// </summary>
        /// <param name="login"></param>
        /// <param name="_cultureID"></param>
        /// <returns></returns>
        public DataSet SelectUserByLogin(string login)
        {
            DataSet ds = new DataSet();
            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserByUserName", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@UserName"].Value = login;

                sqlDadp.Fill(ds);

                ds.Tables[0].TableName = TableName.tblUsers.ToString();
               // ds.Tables[1].TableName = TableName.tblUserDistricts.ToString();



                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get user information against provided user id
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public DataSet SelectUserRightInfoByID(int userID)
        {
            DataSet ds = new DataSet();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserRighInfoByLoginID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                    sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserID", SqlDbType.Int));
                    sqlDadp.SelectCommand.Parameters["@UserID"].Value = userID;

                    sqlDadp.Fill(ds);

                    ds.Tables[0].TableName = TableName.tblUsers.ToString();
                    ds.Tables[1].TableName = TableName.tblUserDistricts.ToString();

                }
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public DataTable SelectUsersByFCCenterID(int locationID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUsersByLocationID", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LocationID", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@LocationID"].Value = locationID;

                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool IsValidateUser(string loginName, string password)
        {
            DataTable dt = new DataTable();


            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spIsValidateUser", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@UserName"].Value = loginName;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@Password"].Value = CustomSecurity.EncodePasswordToBase64(password);

                sqlDadp.Fill(dt);
                if (dt == null)
                {
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(dt.Rows[0]["Result"]);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public DataTable SelectUsersByFCCenter(string fcCode, string condition)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUsersByLocation", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LocationCode", SqlDbType.VarChar));
                sqlDadp.SelectCommand.Parameters["@LocationCode"].Value = fcCode;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Clause", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@Clause"].Value = condition;

                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable SelectUsersByDepartmentID(int? departmentUserID)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection con = new SqlConnection(this.spConnectionString))
                {
                    SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserByDptID", con);
                    sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;
                    if (departmentUserID.HasValue)
                    {
                        sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
                        sqlDadp.SelectCommand.Parameters["@DepartmentID"].Value = departmentUserID;
                    }                  
                    sqlDadp.Fill(dt);
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get User Listing 
        /// </summary>
        /// <param name="DistrictID"></param>
        /// <param name="FCLocationID"></param>
        /// <returns></returns>
        public DataTable GetUserListing(int DistrictID, string LocationCode, bool IsAllRecord)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter sqlDadp = new SqlDataAdapter("spGetUserListing", con);
                sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
                sqlDadp.SelectCommand.Parameters["@DistrictID"].Value = DistrictID;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LocationCode", SqlDbType.NVarChar));
                sqlDadp.SelectCommand.Parameters["@LocationCode"].Value = LocationCode;

                sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@SelectAllRecord", SqlDbType.Bit));
                sqlDadp.SelectCommand.Parameters["@SelectAllRecord"].Value = IsAllRecord;


                sqlDadp.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #region "Private Methods"

        internal void SetUserSqlParameters(UserRegistration user, SqlCommand sqlCmd)
        {
            sqlCmd.Parameters.Add(new SqlParameter("@UserDistricts", SqlDbType.Structured));
            sqlCmd.Parameters["@UserDistricts"].Value = user.UserDistricts;

            sqlCmd.Parameters.Add(new SqlParameter("@GroupFeatursPermission", SqlDbType.Structured));
            sqlCmd.Parameters["@GroupFeatursPermission"].Value = user.UserFeaturs ;

            sqlCmd.Parameters.Add(new SqlParameter("@DepartmentID", SqlDbType.Int));
            sqlCmd.Parameters["@DepartmentID"].Value = user.DepartmentID;

            sqlCmd.Parameters.Add(new SqlParameter("@DistrictID", SqlDbType.Int));
            sqlCmd.Parameters["@DistrictID"].Value = user.GeneralDistrictID;

            sqlCmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
            sqlCmd.Parameters["@UserName"].Value = user.LoginName;

            sqlCmd.Parameters.Add(new SqlParameter("@EmployeeName", SqlDbType.VarChar));
            sqlCmd.Parameters["@EmployeeName"].Value = user.EmployeeName;

            sqlCmd.Parameters.Add(new SqlParameter("@CNIC", SqlDbType.VarChar));
            sqlCmd.Parameters["@CNIC"].Value = user.CNIC;

            sqlCmd.Parameters.Add(new SqlParameter("@EMail", SqlDbType.VarChar));
            sqlCmd.Parameters["@EMail"].Value = user.EMail;

            sqlCmd.Parameters.Add(new SqlParameter("@CellNumber", SqlDbType.VarChar));
            sqlCmd.Parameters["@CellNumber"].Value = user.CellNumber;

            sqlCmd.Parameters.Add(new SqlParameter("@PermitGroupID", SqlDbType.Int));
            sqlCmd.Parameters["@PermitGroupID"].Value = user.GroupID;//g.permitGroupID;

            sqlCmd.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.VarChar));
            sqlCmd.Parameters["@UserTypeID"].Value = user.UserTypeID;

            sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
            sqlCmd.Parameters["@IsActive"].Value = user.Status;

            sqlCmd.Parameters.Add(new SqlParameter("@InActiveReason", SqlDbType.VarChar));
            sqlCmd.Parameters["@InActiveReason"].Value = user.BlockReason;


            sqlCmd.Parameters.Add(new SqlParameter("@IsEnforceRight", SqlDbType.Bit));
            sqlCmd.Parameters["@IsEnforceRight"].Value = user.EnforceRight.HasValue && user.EnforceRight.Value ? 1 : 0;

            sqlCmd.Parameters.Add(new SqlParameter("@IsWithinPremesis", SqlDbType.Bit));
            sqlCmd.Parameters["@IsWithinPremesis"].Value = user.WithinPremesis.HasValue && user.WithinPremesis.Value ? 1 : 0;

            if (user.JoinDate.HasValue)
            {
                sqlCmd.Parameters.Add(new SqlParameter("@JoiningDate", SqlDbType.DateTime));
                sqlCmd.Parameters["@JoiningDate"].Value = user.JoinDate;
            }

            if (user.AddressDivisionID.HasValue)
            {
                sqlCmd.Parameters.Add(new SqlParameter("@AddressDivisionID", SqlDbType.Int));
                sqlCmd.Parameters["@AddressDivisionID"].Value = user.AddressDivisionID;
            }

            if (user.AddressDistrictID.HasValue)
            {
                sqlCmd.Parameters.Add(new SqlParameter("@AddressDistrictID", SqlDbType.Int));
                sqlCmd.Parameters["@AddressDistrictID"].Value = user.AddressDistrictID;
            }

            if (!string.IsNullOrEmpty(user.FullAddress))
            {
                sqlCmd.Parameters.Add(new SqlParameter("@FullAddress", SqlDbType.NVarChar));
                sqlCmd.Parameters["@FullAddress"].Value = user.FullAddress;
            }

            sqlCmd.Parameters.Add(new SqlParameter("@FileAdd", SqlDbType.Bit));
            sqlCmd.Parameters["@FileAdd"].Value = user.FileAdd;

            sqlCmd.Parameters.Add(new SqlParameter("@FileView", SqlDbType.Bit));
            sqlCmd.Parameters["@FileView"].Value = user.FileView;

            sqlCmd.Parameters.Add(new SqlParameter("@FileRemove", SqlDbType.Bit));
            sqlCmd.Parameters["@FileRemove"].Value = user.FileRemove;

            sqlCmd.Parameters.Add(new SqlParameter("@FileDownload", SqlDbType.Bit));
            sqlCmd.Parameters["@FileDownload"].Value = user.FileDownload;

        }

        #endregion


        public int UpdatePassword(string loginName, string oldpassword, string newpassword, int? loginID,int? userTypeID)
        {
            object result = 0;
            using (SqlConnection con = new SqlConnection(this.spConnectionString))
            {
                using (SqlCommand sqlCmd = new SqlCommand())
                {
                    try
                    {
                        if (con.State == ConnectionState.Closed)
                            con.Open();
                        sqlCmd.Connection = con;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.CommandText = "spResetPassword";

                        sqlCmd.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar));
                        sqlCmd.Parameters["@UserName"].Value = loginName;

                        sqlCmd.Parameters.Add(new SqlParameter("@OldPassword", SqlDbType.VarChar));
                        sqlCmd.Parameters["@OldPassword"].Value = CustomSecurity.EncodePasswordToBase64(oldpassword);

                        sqlCmd.Parameters.Add(new SqlParameter("@NewPassword", SqlDbType.VarChar));
                        sqlCmd.Parameters["@NewPassword"].Value = CustomSecurity.EncodePasswordToBase64(newpassword);

                        sqlCmd.Parameters.Add(new SqlParameter("@UserTypeID", SqlDbType.Int));
                        sqlCmd.Parameters["@UserTypeID"].Value = userTypeID;

                        sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.Int));
                        sqlCmd.Parameters["@ModifiedBy"].Value = loginID;

                        result = sqlCmd.ExecuteNonQuery();
                        con.Close();
                    }
                    catch (Exception ex)
                    {

                        throw ex;
                    }
                    finally
                    {
                        if (con.State == ConnectionState.Open)
                            con.Close();
                    }
                }
            }

            return Convert.ToInt32(result);
        }
    }
}
