﻿using System;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using PITB.PFSA.DAL.Generic;


namespace PITB.PFSA.DAL.Lookups.RightsManagers
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil>
    // Create date: <07-09-2014 11:20AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // C
    // =================================================================================================================================
    public class ServicesDAL : DALBase
    {
        /// <summary>
        /// Add error detail in ErrorLog table.
        /// </summary>
        /// <param name="_method"></param>
        /// <param name="_message"></param>
        /// <param name="_stackTrace"></param>
        /// <param name="_source"></param>
        /// <param name="_webMethod"></param>
        /// <param name="_created"></param>
        /// <returns>Number of rows effected as interger</returns>
        public int SaveErrorLog(string _method, string _message, string _stackTrace, string _source, int _webMethod, DateTime _created)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spAddErrorLog";

                _sqlCmd.Parameters.Add(new SqlParameter("@Method", SqlDbType.VarChar));
                _sqlCmd.Parameters["@Method"].Value = _method;

                _sqlCmd.Parameters.Add(new SqlParameter("@Message", SqlDbType.VarChar));
                _sqlCmd.Parameters["@Message"].Value = _message;

                _sqlCmd.Parameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar));
                _sqlCmd.Parameters["@StackTrace"].Value = _stackTrace;

                _sqlCmd.Parameters.Add(new SqlParameter("@Source", SqlDbType.VarChar));
                _sqlCmd.Parameters["@Source"].Value = _source;

                _sqlCmd.Parameters.Add(new SqlParameter("@IsWebMethod", SqlDbType.Bit));
                _sqlCmd.Parameters["@IsWebMethod"].Value = 0;

                _sqlCmd.Parameters.Add(new SqlParameter("@Created", SqlDbType.DateTime));
                _sqlCmd.Parameters["@Created"].Value = _created;

                _result = _sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (_con.State == ConnectionState.Open) _con.Close();
            }

            return _result;
        }

        /// <summary>
        /// Check any record duplication and data dependances
        /// </summary>
        /// <param name="_table"></param>
        /// <param name="_column"></param>
        /// <param name="_value"></param>
        /// <param name="_caluse"></param>
        /// <returns>True when related record exist else false</returns>
        public bool SelectRecordVerification(string _table, string _column, string _value, string _caluse)
        {
            bool result = false;

            try
            {
                DataTable dt = new DataTable();
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spCheckRecords", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Table"].Value = _table;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@column", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@column"].Value = _column;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@value", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@value"].Value = _value;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@caluse", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@caluse"].Value = _caluse;

                _sqlDadp.Fill(dt);

                if (dt.Rows.Count > 0)
                    result = true;

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool SelectRecordVerifications(string _table, string _column, string _value, string _caluse, string _caluse2)
        {
            bool result = false;

            try
            {
                DataTable dt = new DataTable();
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spCheckDuplications", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Table", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Table"].Value = _table;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@column", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@column"].Value = _column;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@value", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@value"].Value = _value;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@caluse", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@caluse"].Value = _caluse;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@caluse2", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@caluse2"].Value = _caluse2;

                _sqlDadp.Fill(dt);

                if (dt.Rows.Count > 0)
                    result = true;

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// check user access right on a selected page.
        /// </summary>
        /// <param name="_user"></param>
        /// <param name="_page"></param>
        /// <returns></returns>
        public bool GetUserPageAccess(string _user, string _page)
        {
            bool result = true;

            try
            {
                DataTable dt = new DataTable();

                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetUserPageAccess", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@LoginID", SqlDbType.VarChar));
                _sqlDadp.SelectCommand.Parameters["@LoginID"].Value = _user;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@Page", SqlDbType.NVarChar));
                _sqlDadp.SelectCommand.Parameters["@Page"].Value = _page;

                _sqlDadp.Fill(dt);

                if (dt.Rows.Count == 0)
                    result = false;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
    }
}
