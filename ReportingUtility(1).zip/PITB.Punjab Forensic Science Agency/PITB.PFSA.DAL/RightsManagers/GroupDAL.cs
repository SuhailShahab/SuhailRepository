﻿using System;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using PITB.PFSA.RightsManager.CustomEnums;
using PITB.PFSA.DAL.Generic;
using PITB.PFSA.BE.Lookups;
using PITB.PFSA.BE.RigthManager;

namespace PITB.PFSA.DAL.Lookups.RightsManagers
{
    // =================================================================================================================================
    // Create by:	<Syed Zeeshan Aqil >
    // Create date: <7/10/2014 2:07:32 AM>
    // =================================================================================================================================
    // ===================================================== Modification History ======================================================
    //   SR#             Modified By            Modified Date/Time      Desription
    // CR: 001           Syed Zeeshan Aqil      06-07-2015 04:21:08PM   Add new operational rights "File attachment", Residential history, Personal info  and show address info Paneel
    // =================================================================================================================================
    public class GroupDAL : DALBase
    {
        /// <summary>
        /// Add Group information
        /// </summary>
        /// <param name="groupModel">Set object of groupModel type</param>
        /// <returns></returns>
        public int Add(GroupModel groupModel)
        {
            object result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddGroup";

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = groupModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = groupModel.Description;

                

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));
                if (groupModel.Status.HasValue) 
                    sqlCmd.Parameters["@IsActive"].Value = groupModel.Status.Value  ? 1 : 0;
                else
                    sqlCmd.Parameters["@IsActive"].Value = 0;

                sqlCmd.Parameters.Add(new SqlParameter("@CreatedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@CreatedBy"].Value = groupModel.CreatedBy;

                result = sqlCmd.ExecuteScalar();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Convert.ToInt32(result);
        }

        /// <summary>
        /// Update Group information
        /// </summary>
        /// <param name="groupModel">Set object of groupModel type</param>
        /// <returns></returns>
        public int Edit(GroupModel groupModel)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                con.Open();

                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spEditGroup";

                sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.NVarChar));
                sqlCmd.Parameters["@GroupID"].Value = groupModel.ID;

                sqlCmd.Parameters.Add(new SqlParameter("@Title", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Title"].Value = groupModel.Title;

                sqlCmd.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar));
                sqlCmd.Parameters["@Description"].Value = groupModel.Description;

                sqlCmd.Parameters.Add(new SqlParameter("@IsActive", SqlDbType.Bit));

                if (groupModel.Status.HasValue)
                    sqlCmd.Parameters["@IsActive"].Value = groupModel.Status.Value ? 1 : 0;
                else
                    sqlCmd.Parameters["@IsActive"].Value = 0;


                sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                sqlCmd.Parameters["@ModifiedBy"].Value = groupModel.CreatedBy;

                result = sqlCmd.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// Delete Group information
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public int Delete(int id, int modifiedBy)
        {
            int _result = 0;
            SqlConnection _con = new SqlConnection(this.spConnectionString);
            SqlCommand _sqlCmd = new SqlCommand();

            try
            {
                _con.Open();
                _sqlCmd.Connection = _con;
                _sqlCmd.CommandType = CommandType.StoredProcedure;
                _sqlCmd.CommandText = "spDeleteGroup";

                _sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.Int));
                _sqlCmd.Parameters["@GroupID"].Value = id;

                _sqlCmd.Parameters.Add(new SqlParameter("@ModifiedBy", SqlDbType.NVarChar));
                _sqlCmd.Parameters["@ModifiedBy"].Value = modifiedBy;

                _result = _sqlCmd.ExecuteNonQuery();
                _con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return _result;
        }

        /// <summary>
        /// Get  Groups for DropDown
        /// </summary>
        /// <returns>Group Data in dataTable</returns>
        public DataTable SelectGroups()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetGroups", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get  Groups for DropDown
        /// </summary>
        /// <returns>Group Data in dataTable</returns>
        public DataTable GetAll()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetGroups", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Add group permissions
        /// </summary>
        /// <param name="groupID"></param>
        /// <param name="dt"></param>
        /// <param name="_arrRights"></param>
        /// <returns></returns>
        public int AddGroupPermissions(int groupID, DataTable dt, DataTable csrRights)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddGroupPermissions";

                sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.Int));
                sqlCmd.Parameters["@GroupID"].Value = groupID;

                sqlCmd.Parameters.Add(new SqlParameter("@GroupPermission", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupPermission"].Value = dt;

                sqlCmd.Parameters.Add(new SqlParameter("@GroupCSRPermission", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupCSRPermission"].Value = csrRights;

                result = sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }

        public int AddGroupPermissions(int groupID, UserGroupRights gourpRights)
        {
            int result = 0;
            SqlConnection con = new SqlConnection(this.spConnectionString);
            SqlCommand sqlCmd = new SqlCommand();

            try
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                sqlCmd.Connection = con;
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "spAddGroupPermissions";

                sqlCmd.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.Int));
                sqlCmd.Parameters["@GroupID"].Value = groupID;

                sqlCmd.Parameters.Add(new SqlParameter("@FileAdd", SqlDbType.Int));
                sqlCmd.Parameters["@FileAdd"].Value = gourpRights.AllowFileAttachment;

                sqlCmd.Parameters.Add(new SqlParameter("@FileRemove", SqlDbType.Int));
                sqlCmd.Parameters["@FileRemove"].Value = gourpRights.AllowFileRemoved;

                sqlCmd.Parameters.Add(new SqlParameter("@FileDownload", SqlDbType.Int));
                sqlCmd.Parameters["@FileDownload"].Value = gourpRights.AllowFileDownload;

                sqlCmd.Parameters.Add(new SqlParameter("@FileView", SqlDbType.Int));
                sqlCmd.Parameters["@FileView"].Value = gourpRights.AllowFileView;

                sqlCmd.Parameters.Add(new SqlParameter("@GroupPermission", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupPermission"].Value = gourpRights.dsAllPermitRights.Tables[TableName.tblGroupRights.ToString()];

                sqlCmd.Parameters.Add(new SqlParameter("@GroupFeatursPermission", SqlDbType.Structured));
                sqlCmd.Parameters["@GroupFeatursPermission"].Value = gourpRights.dsAllPermitRights.Tables[TableName.tblAppFeatures.ToString()];


                result = sqlCmd.ExecuteNonQuery();
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return result;
        }
        /// <summary>
        /// Get groups permissions against selected group
        /// </summary>
        /// <param name="_groupID"></param>
        /// <returns></returns>
        public DataSet GetGroupPermissions(int _groupID)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection _con = new SqlConnection(this.spConnectionString);
                SqlDataAdapter _sqlDadp = new SqlDataAdapter("spGetGroupPermission", _con);
                _sqlDadp.SelectCommand.CommandType = CommandType.StoredProcedure;

                _sqlDadp.SelectCommand.Parameters.Add(new SqlParameter("@GroupID", SqlDbType.Int));
                _sqlDadp.SelectCommand.Parameters["@GroupID"].Value = _groupID;

                _sqlDadp.Fill(ds);
                //ds.Tables[2].TableName = TableName.tblGroupPermitServices.ToString();
                //ds.Tables[3].TableName = TableName.tblGroupPermitStatuses.ToString(); 
                //ds.Tables[4].TableName = TableName.tblGroupPermitAssigneeStatuses.ToString();
                //ds.Tables[5].TableName = TableName.tblGroupControlRights.ToString();
                ds.Tables[0].TableName = TableName.tblGroups.ToString();
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
