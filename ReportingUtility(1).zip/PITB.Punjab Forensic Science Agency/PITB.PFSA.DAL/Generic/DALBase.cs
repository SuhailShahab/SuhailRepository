﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace PITB.PFSA.DAL.Generic
{
    public class DALBase
    {
        private string m_spConnectionString = "DBConnectionString";
        
        /// Defualt constructor
        /// </summary>
        public DALBase()
        {
            this.m_spConnectionString = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString.ToString() ;            
        }
      

        protected string spConnectionString
        {
            get { return m_spConnectionString; }
        }
       
        protected  void ConCloseDisponse(SqlConnection con)
        {
            if (con.State == ConnectionState.Open)
                con.Close();
            con.Dispose();
        }
        protected void ConnectionClose(SqlConnection con)
        {
            if (con.State == ConnectionState.Open)
                con.Close();           
        }
        protected  void OpenConnection(SqlConnection con)
        {
            if (con.State == ConnectionState.Closed)
                con.Open();
        }

        protected SqlConnection  dbConnection;
        protected SqlTransaction dbTransaction;
    }
}
