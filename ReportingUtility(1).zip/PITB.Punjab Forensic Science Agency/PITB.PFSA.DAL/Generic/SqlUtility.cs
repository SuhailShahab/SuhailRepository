﻿using PITB.PFSA.BE.Common;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace PITB.PFSA.DAL.Generic
{
   public  class SqlUtility
    {
       //public List<SqlParameter> GetAddParameter(object obj)
       //{
       //    PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
       //    var sqlParams = new List<SqlParameter>();
       //    foreach (var f in fields)
       //    {
       //        foreach (Object objColumName in f.GetCustomAttributes(true))
       //        {
       //            MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;

       //            var p = f.GetValue(obj, null);
       //            if (p != null)
       //                sqlParams.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));

       //        }
       //    }
       //    return sqlParams;
       //}
       public List<SqlParameter> GetAddParameter(object obj)
       {
           PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
           var sqlParams = new List<SqlParameter>();
           foreach (var f in fields)
           {
               foreach (Object objColumName in f.GetCustomAttributes(true))
               {

                   MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;
                  
                       var p = f.GetValue(obj, null);
                       if (p != null)
                       {
                           sqlParams.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                           break;
                       }                       
                  

               }
           }
           return sqlParams;
       }


       public void GetAddParameterExtented(object obj, SqlCommand sqlCommand)
       {
           PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

           foreach (var f in fields)
           {
               foreach (Object objColumName in f.GetCustomAttributes(true))
               {

                   MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;

                   var p = f.GetValue(obj, null);
                   if (p != null && p != "" && !mappingInfoAttribute.Transient)
                   {                      
                       sqlCommand.Parameters.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                       break;
                   }




               }
           }

       }

       public void GetAddParameterExtented1(object obj, SqlCommand sqlCommand)
       {
           PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);

           foreach (var f in fields)
           {
               foreach (System.Attribute objColumName in f.GetCustomAttributes(true))
               {

                   MappingInfoAttribute mappingInfoAttribute = (MappingInfoAttribute)objColumName;

                   var p = f.GetValue(obj, null);
                   //if (p != null && p != "" && !mappingInfoAttribute.Transient && !mappingInfoAttribute.IsExclude.Equals("Y"))
                   //{
                   //    sqlCommand.Parameters.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                   //    break;
                   //}




               }
           }

       }
       public void GetAddParameter(object obj, bool isExcludeIdentity, SqlCommand sqlCommand)
       {
           PropertyInfo[] fields = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
          
           foreach (var f in fields)
           {
               foreach (Object objColumName in f.GetCustomAttributes(true))
               {

                   MappingInfoAttribute mappingInfoAttribute = objColumName as MappingInfoAttribute;
                  
                       var p = f.GetValue(obj, null);
                       if (p != null)
                       {
                           sqlCommand.Parameters.Add(new SqlParameter(mappingInfoAttribute.ColumnName, p));
                           break;
                       }
                           
                   


               }
           }
          
       }

       
    }
}
