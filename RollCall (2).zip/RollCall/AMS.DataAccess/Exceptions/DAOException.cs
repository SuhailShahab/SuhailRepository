﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace DataAccess.Exceptions
{
    /// <summary>
    /// This class is the base class for all exceptions from our
    /// repositories.
    /// </summary>
    [Serializable]
    public class DAOException : CustomDAOException
    {
        public DAOException()
        {
            this.ErrorCode = "1000";
        }
        public DAOException(string message)
            : base(message)
        {
        }

        public DAOException(string message, Exception inner)
            : base(message, inner)
        {
            this.ErrorCode = message;
        }

        protected DAOException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
