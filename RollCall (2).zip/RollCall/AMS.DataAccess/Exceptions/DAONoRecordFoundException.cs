﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.Exceptions
{
    [Serializable]
    public class DAONoRecordFoundException : CustomDAOException
    {
        public DAONoRecordFoundException()
        {
            this.ErrorCode = "3000";
        }
    }
}
