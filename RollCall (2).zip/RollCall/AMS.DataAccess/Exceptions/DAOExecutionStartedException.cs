﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.Exceptions
{
    [Serializable]
    public class DAOExecutionStartedException : CustomDAOException
    {
        public DAOExecutionStartedException()
        {
            this.ErrorCode = "DAO_EXECUTION_STARTED_EXCEPTION";
        }
    }
}
