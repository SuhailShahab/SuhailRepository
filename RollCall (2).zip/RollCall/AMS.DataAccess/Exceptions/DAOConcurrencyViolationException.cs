﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.Exceptions
{
    /// <summary>
    /// This exception is thrown when a concurrency
    /// violation is detected in the database.
    /// </summary>
    [Serializable]
    public class DAOConcurrencyViolationException : CustomDAOException
    {
        public DAOConcurrencyViolationException()
        {
            this.ErrorCode = "DAOConcurrencyViolationException";
        }


    }
}
