﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace DataAccess.Exceptions
{
    [Serializable]
    public class DAOIntegrityConstraintException : CustomDAOException
    {
        public DAOIntegrityConstraintException()
        {
            this.ErrorCode = "1001";
        }

        public DAOIntegrityConstraintException(string message)
            : base(message)
        {
            //this.ParseErrorMessage(ref message);
            this.ErrorCode = "ChildRecordFound";
        }

        public DAOIntegrityConstraintException(string message, Exception inner)
            : base(message, inner)
        {
            //this.ParseErrorMessage(ref message);
            this.ErrorCode = "ChildRecordFound";
        }

        protected DAOIntegrityConstraintException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        //private void ParseErrorMessage(ref string errorMsg)
        //{
        //    int sindex = errorMsg.IndexOf('(');
        //    int eindex = errorMsg.IndexOf(')');

        //    errorMsg = errorMsg.Substring(sindex + 1, eindex - sindex - 1);
        //    if (errorMsg.Contains("."))
        //    {
        //        int index = errorMsg.IndexOf('.');
        //        errorMsg = errorMsg.Substring(index + 1, errorMsg.Length - index - 1);
        //    }
        //}
    }
}
