﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace DataAccess.Exceptions
{
    public class CustomDAOException : System.Exception
    {
        public string ErrorCode;
        public bool IsCommittedTransaction;
        public string SystemErrorMessage;

        public CustomDAOException()
        {
            IsCommittedTransaction = false;
        }

        public CustomDAOException(string message, Exception exception, bool isCommittedTransaction)
            : base(message, exception)
        {
            IsCommittedTransaction = isCommittedTransaction;
            ErrorCode = message;
        }

        public CustomDAOException(string message)
            : base(message)
        {
        }

        public CustomDAOException(string message, Exception inner)
            : base(message, inner)
        {
        }

        protected CustomDAOException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}
