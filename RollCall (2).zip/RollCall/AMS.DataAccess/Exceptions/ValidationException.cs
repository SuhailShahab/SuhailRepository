﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccess.Exceptions
{
    public class ValidationException : CustomDAOException
    {

        public ValidationException(string ErrorCode)
        {
            this.ErrorCode = ErrorCode;
        }
    }
}
