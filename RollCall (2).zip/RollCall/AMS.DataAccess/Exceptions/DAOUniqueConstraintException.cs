﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace DataAccess.Exceptions
{
    /// <summary>
    /// This class is the base class for all exceptions from our
    /// repositories.
    /// </summary>
    [Serializable]
    public class DAOUniqueConstraintException : CustomDAOException
    {
        public DAOUniqueConstraintException()
        {
            this.ErrorCode = "1000";
        }
        public DAOUniqueConstraintException(string message)
            : base(message)
        {
            this.ParseErrorMessage(ref message);
        }

        public DAOUniqueConstraintException(string message, Exception inner)
            : base(message, inner)
        {
            this.ParseErrorMessage(ref message);
            this.ErrorCode = message;
        }

        protected DAOUniqueConstraintException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }

        private void ParseErrorMessage(ref string errorMsg)
        {
            int sindex = errorMsg.IndexOf('(');
            int eindex = errorMsg.IndexOf(')');

            errorMsg = errorMsg.Substring(sindex + 1, eindex - sindex - 1);
            if (errorMsg.Contains("."))
            {
                int index = errorMsg.IndexOf('.');
                errorMsg = errorMsg.Substring(index + 1, errorMsg.Length - index - 1);
            }
        }
    }
}
