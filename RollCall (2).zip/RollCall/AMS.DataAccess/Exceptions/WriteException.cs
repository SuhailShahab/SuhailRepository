﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace DataAccess.Exceptions
{
    public class WriteException
    {
        private static string filePaht = @"C:\testExceptionFile.txt";


        public static void WriteXmlExcption(Exception loEx, string methodName)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            DataColumn dcDate = new DataColumn("dcDate");
            DataColumn dcExceptionMsg = new DataColumn("dcExceptionMsg");
            DataColumn dcExceptionMsgDetail = new DataColumn("dcExceptionMsgDetail");

            dt.Columns.Add(dcDate);
            dt.Columns.Add(dcExceptionMsg);
            dt.Columns.Add(dcExceptionMsgDetail);

            DataRow dtRow;
            dtRow = dt.NewRow();
            dtRow[0] = DateTime.Now.ToShortDateString();
            dtRow[1] = loEx.Message;
            dtRow[2] = loEx.ToString();

            dt.Rows.Add(dtRow);
            ds.Tables.Add(dt);
            //File

            // if(
            ds.WriteXml(filePaht);

        }
    }
}
