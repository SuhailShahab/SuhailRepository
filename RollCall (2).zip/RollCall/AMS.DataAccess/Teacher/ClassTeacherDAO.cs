﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using AMS.BusinessEntities.Teacher;
using DataAccess.Generic;
using AMS.BusinessEntities.Attendance;

namespace AMS.DataAccess.Teacher
{
    public interface  IClassTeacherDAO
    {
        List<ClassTeacher>  GetClassTeacherById(int teacherId,bool? isIncharge);
        List<ClassTeacher> GetClassTeacherById(int teacherId, bool? isIncharge, int campusId, int classId, int sectionId);
        int GetRollTimeStatusByCurrentTime(DateTime currentdateTime);
        List<RollTimeAttendaceStatus> GetRollTimeStatus();

    }
    public class ClassTeacherDAO : BaseDAO<ClassTeacher>, IClassTeacherDAO
    {
           public ClassTeacherDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

           public ClassTeacherDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

           public List<ClassTeacher> GetClassTeacherById(int teacherId, bool? isIncharge)
           {
               StringBuilder query = new StringBuilder();
               # region Query
//               query.Append(@"SELECT    TR_ClassTeachers.ClassTeacherId, Config_Section.SectionId, Config_Section.Name SectionName, Config_Class.ClassId, Config_Class.Name AS ClassName
//                            FROM   Config_Section INNER JOIN
//                            TR_ClassTeachers ON Config_Section.SectionId = TR_ClassTeachers.SectionId INNER JOIN
//                             Config_Class ON TR_ClassTeachers.ClassId = Config_Class.ClassId
//                             WHERE     (TR_ClassTeachers.TeacherId = " + teacherId + ")  ");

               query.Append(@"SELECT  TR_Teachers.CampusId,  TR_ClassTeachers.ClassTeacherId, Config_Section.SectionId, Config_Section.Name SectionName, Config_Class.ClassId, Config_Class.Name AS ClassName
                            FROM   Config_Section INNER JOIN
                            TR_ClassTeachers ON Config_Section.SectionId = TR_ClassTeachers.SectionId INNER JOIN
                             Config_Class ON TR_ClassTeachers.ClassId = Config_Class.ClassId
                            INNER JOIN TR_Teachers ON TR_ClassTeachers.TeacherId = TR_Teachers.TeacherId
                             WHERE     (TR_ClassTeachers.TeacherId = " + teacherId + ")  ");

               #endregion
               if (isIncharge!=null && isIncharge.Value == true)
               {
                   query.Append(" and  (TR_ClassTeachers.IsIncharge= 1)" );
               }
               query.Append(" ORDER BY Config_Class.ClassOrder,Config_Section.SectionOrder ASC");
               //if (isActive != null)
               //{
               //    query.Append(" Where Is_Active= '" + isActive.ToString() + "'");
               //}

               List<ClassTeacher> results = new List<ClassTeacher>();

               try
               {
                   System.Data.DataSet set = FindMetaData(query.ToString());

                   System.Data.DataTable tbl = set.Tables[0];
                   ClassTeacher classTeacher;

                   foreach (System.Data.DataRow row in tbl.Rows)
                   {
                       classTeacher = new ClassTeacher();

                       classTeacher.ID = Convert.ToInt32(row["ClassTeacherId"]);
                       classTeacher.Classes = new BusinessEntities.Configuration.Classes();
                       classTeacher.Classes.Name = Convert.ToString(row["ClassName"]);
                       classTeacher.Classes.ID = Convert.ToInt32(row["ClassId"]);
                       classTeacher.Section = new BusinessEntities.Configuration.Section();
                       classTeacher.Section.Name = Convert.ToString(row["SectionName"]);
                       classTeacher.Section.ID = Convert.ToInt32(row["SectionId"]);
                       classTeacher.Campus = new BusinessEntities.Configuration.Campus();
                       classTeacher.Campus.ID = Convert.ToInt32(row["CampusId"]);
                       classTeacher.ClassSectionName = classTeacher.Classes.Name + "" + classTeacher.Section.Name;                      

                       results.Add(classTeacher);
                   }
                   return results;
               }
               catch (Exception ex)
               {
                   HandleDBException(ex);

               }

               // LogUtility.LogInfo(LoggingEvent.Information, "FillDepartment", "Leaving");

               return results;
           }

           public List<ClassTeacher> GetClassTeacherById(int teacherId, bool? isIncharge, int campusId, int classId, int sectionId)
           {
               StringBuilder query = new StringBuilder();
               # region Query
               //               query.Append(@"SELECT    TR_ClassTeachers.ClassTeacherId, Config_Section.SectionId, Config_Section.Name SectionName, Config_Class.ClassId, Config_Class.Name AS ClassName
               //                            FROM   Config_Section INNER JOIN
               //                            TR_ClassTeachers ON Config_Section.SectionId = TR_ClassTeachers.SectionId INNER JOIN
               //                             Config_Class ON TR_ClassTeachers.ClassId = Config_Class.ClassId
               //                             WHERE     (TR_ClassTeachers.TeacherId = " + teacherId + ")  ");

               query.Append(@"SELECT  TR_Teachers.CampusId,  TR_ClassTeachers.ClassTeacherId, Config_Section.SectionId, Config_Section.Name SectionName, Config_Class.ClassId, Config_Class.Name AS ClassName
                            FROM   Config_Section INNER JOIN
                            TR_ClassTeachers ON Config_Section.SectionId = TR_ClassTeachers.SectionId INNER JOIN
                             Config_Class ON TR_ClassTeachers.ClassId = Config_Class.ClassId
                            INNER JOIN TR_Teachers ON TR_ClassTeachers.TeacherId = TR_Teachers.TeacherId
                             WHERE     (TR_ClassTeachers.TeacherId = " + teacherId + ")  ");

               #endregion
               if (isIncharge != null && isIncharge.Value == true)
               {
                   query.Append(" and  (TR_ClassTeachers.IsIncharge= 1)");
               }
               if (campusId != -1 )
               {
                   query.Append(" and  TR_Teachers.CampusId = "+campusId);
               }
               if (classId != -1)
               {
                   query.Append(" and  TR_ClassTeachers.ClassId= " + classId);
               }
               if (sectionId != -1)
               {
                   query.Append(" and  TR_ClassTeachers.SectionId= " + sectionId);
               }
               query.Append(" ORDER BY Config_Class.ClassOrder,Config_Section.SectionOrder ASC");
               //if (isActive != null)
               //{
               //    query.Append(" Where Is_Active= '" + isActive.ToString() + "'");
               //}

               List<ClassTeacher> results = new List<ClassTeacher>();

               try
               {
                   System.Data.DataSet set = FindMetaData(query.ToString());

                   System.Data.DataTable tbl = set.Tables[0];
                   ClassTeacher classTeacher;

                   foreach (System.Data.DataRow row in tbl.Rows)
                   {
                       classTeacher = new ClassTeacher();

                       classTeacher.ID = Convert.ToInt32(row["ClassTeacherId"]);
                       classTeacher.Classes = new BusinessEntities.Configuration.Classes();
                       classTeacher.Classes.Name = Convert.ToString(row["ClassName"]);
                       classTeacher.Classes.ID = Convert.ToInt32(row["ClassId"]);
                       classTeacher.Section = new BusinessEntities.Configuration.Section();
                       classTeacher.Section.Name = Convert.ToString(row["SectionName"]);
                       classTeacher.Section.ID = Convert.ToInt32(row["SectionId"]);
                       classTeacher.Campus = new BusinessEntities.Configuration.Campus();
                       classTeacher.Campus.ID = Convert.ToInt32(row["CampusId"]);
                       classTeacher.ClassSectionName = classTeacher.Classes.Name + "" + classTeacher.Section.Name;

                       results.Add(classTeacher);
                   }
                   return results;
               }
               catch (Exception ex)
               {
                   HandleDBException(ex);

               }

               // LogUtility.LogInfo(LoggingEvent.Information, "FillDepartment", "Leaving");

               return results;
           }


           public List<RollTimeAttendaceStatus> GetRollTimeStatus()
           {
               StringBuilder query = new StringBuilder();

               query.Append(@"SELECT RollTimeStatusId, Name, StartingHour, EndingHour, IsActive
                              FROM   ATT_RollTime_Status Where IsActive = 1 ");
               //if (isActive != null)
               //{
               //    query.Append(" Where Is_Active= '" + isActive.ToString() + "'");
               //}

               List<RollTimeAttendaceStatus> results = new List<RollTimeAttendaceStatus>();

               try
               {
                   System.Data.DataSet set = FindMetaData(query.ToString());

                   System.Data.DataTable tbl = set.Tables[0];
                   RollTimeAttendaceStatus rollTimeAttendaceStatus;

                   foreach (System.Data.DataRow row in tbl.Rows)
                   {
                       rollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                       rollTimeAttendaceStatus.ID = Convert.ToInt32(row["RollTimeStatusId"]);
                       rollTimeAttendaceStatus.Name = Convert.ToString(row["Name"]);
                       rollTimeAttendaceStatus.StartingHour = Convert.ToInt32(row["StartingHour"]);
                       rollTimeAttendaceStatus.EndingHour = Convert.ToInt32(row["EndingHour"]);
                       results.Add(rollTimeAttendaceStatus);
                   }
                   return results;
               }
               catch (Exception ex)
               {
                   HandleDBException(ex);

               }

               // LogUtility.LogInfo(LoggingEvent.Information, "FillDepartment", "Leaving");

               return results;
           }
           public int GetRollTimeStatusByCurrentTime(DateTime currentdateTime)
           {
               StringBuilder query = new StringBuilder();

               query.Append(@"SELECT     RollTimeStatusId
                               FROM         ATT_RollTime_Status ");             

               try
               {
                   System.Data.DataSet set = FindMetaData(query.ToString());

                   System.Data.DataTable tbl = set.Tables[0];
                   if (tbl.Rows.Count > 0)
                   {
                       return Convert.ToInt32(tbl.Rows[0][0]);
                   }
                   else
                   {
                       return -1;
                   }
               }
               catch (Exception ex)
               {
                   HandleDBException(ex);

               }

               // LogUtility.LogInfo(LoggingEvent.Information, "FillDepartment", "Leaving");

               return -1;
           }


    }
}
