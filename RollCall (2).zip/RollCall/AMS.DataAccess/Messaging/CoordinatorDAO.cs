﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Messaging;
using System.Data;
using DataAccess.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace AMS.DataAccess.Messaging
{
    public interface IClassCoordinatorDAO
    {
        int InsertCoordinator(ClassCoordinator coordinator, int createdBy);
        int UpdatetCoordinator(ClassCoordinator coordinator, int createdBy);
        List<ClassCoordinator> GetAllCoordinators();

    }
    public class ClassCoordinatorDAO : BaseDAO<ClassCoordinator>, IClassCoordinatorDAO
    {
        public ClassCoordinatorDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }
        public ClassCoordinatorDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }
        public List<ClassCoordinator> GetAllCoordinators()
        {
            StringBuilder query = new StringBuilder();

            #region OLD Query
//            query.Append(@"SELECT EA.[ClassCoordinatorAssociationId]
//                          ,EA.[TeacherId],EA.[ClassId],EA.[SectionId]
//                          ,EA.[IsActive],T.FirstName,T.LastName 
//                          ,T.Email,C.Name C_Name ,S.Name S_Name
//                      FROM EMP_ClassCoordinatorAssociation EA
//                      INNER JOIN TR_Teachers T
//                      ON T.TeacherId = EA.TeacherId
//                      INNER JOIN Config_Class C
//                      ON C.ClassId = EA.ClassId
//                      INNER JOIN Config_Section S
//                      ON S.SectionId  = EA.SectionId");
//            query.Append(" Where EA.IsActive = 1  ;");
            // query.Append(" Order by MR.[ReplyDate] DESC ;");
            #endregion
            query.Append(@"SELECT EA.[ClassCoordinatorAssociationId],EA.[TeacherId],EA.[ClassId],EA.[SectionId]
                          ,T.FirstName,T.LastName,T.Email                         
                           FROM EMP_ClassCoordinatorAssociation EA
                           INNER JOIN TR_Teachers T
                           ON T.TeacherId = EA.TeacherId  ");     
            query.Append(" Where EA.IsActive = 1  ;");
            List<ClassCoordinator> results = new List<ClassCoordinator>();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    results = ConstructFactory(tbl);
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }
        private List<ClassCoordinator> ConstructFactory(DataTable dt)
        {
            List<ClassCoordinator> coordinators = new List<ClassCoordinator>();

            for (int rowIndex = 0; rowIndex < dt.Rows.Count; rowIndex++)
            {
                ClassCoordinator classCoordinator = new ClassCoordinator();
                if (dt.Columns.Contains("ClassCoordinatorAssociationId") && !Convert.IsDBNull(dt.Rows[rowIndex]["ClassCoordinatorAssociationId"]))
                {
                    classCoordinator.ID = Convert.ToInt32(dt.Rows[rowIndex]["ClassCoordinatorAssociationId"]);
                }
                classCoordinator.StudentClass = new BusinessEntities.Configuration.Classes();
                if (dt.Columns.Contains("ClassId") && !Convert.IsDBNull(dt.Rows[rowIndex]["ClassId"]))
                {                   
                    classCoordinator.StudentClass.ID = Convert.ToInt32(dt.Rows[rowIndex]["ClassId"]);
                }
                if (dt.Columns.Contains("C_Name") && !Convert.IsDBNull(dt.Rows[rowIndex]["C_Name"]))
                {
                    classCoordinator.StudentClass.Name = Convert.ToString(dt.Rows[rowIndex]["C_Name"]);
                }
                classCoordinator.Section = new BusinessEntities.Configuration.Section();
                if (dt.Columns.Contains("SectionId") && !Convert.IsDBNull(dt.Rows[rowIndex]["SectionId"]))
                {                    
                    classCoordinator.Section.ID  = Convert.ToInt32(dt.Rows[rowIndex]["SectionId"]);
                }
                if (dt.Columns.Contains("S_Name") && !Convert.IsDBNull(dt.Rows[rowIndex]["S_Name"]))
                {
                    classCoordinator.Section.Name = Convert.ToString(dt.Rows[rowIndex]["S_Name"]);
                }
                classCoordinator.Employee = new BusinessEntities.Attendance.Employee();
                if (dt.Columns.Contains("TeacherId") && !Convert.IsDBNull(dt.Rows[rowIndex]["TeacherId"]))
                {
                    classCoordinator.Employee.ID = Convert.ToInt32(dt.Rows[rowIndex]["TeacherId"]);                    
                }

                if (dt.Columns.Contains("FirstName") && !Convert.IsDBNull(dt.Rows[rowIndex]["FirstName"]))
                {
                    classCoordinator.Employee.Name = Convert.ToString(dt.Rows[rowIndex]["FirstName"]);
                }
                if (dt.Columns.Contains("LastName") && !Convert.IsDBNull(dt.Rows[rowIndex]["LastName"]))
                {
                    classCoordinator.Employee.LastName = Convert.ToString(dt.Rows[rowIndex]["LastName"]);
                }

                if (dt.Columns.Contains("Email") && !Convert.IsDBNull(dt.Rows[rowIndex]["Email"]))
                {
                    classCoordinator.Employee.EmailAddress = Convert.ToString(dt.Rows[rowIndex]["Email"]);
                }

                if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dt.Rows[rowIndex]["IsActive"]))
                {
                    classCoordinator.IsActive = Convert.ToBoolean(dt.Rows[rowIndex]["IsActive"]);
                }

                coordinators.Add(classCoordinator);

            }
            return coordinators;
        }

        public int InsertCoordinator(ClassCoordinator coordinator, int createdBy)
        {
            throw new NotImplementedException();
        }

        public int UpdatetCoordinator(ClassCoordinator coordinator, int createdBy)
        {
            throw new NotImplementedException();
        }



    }
}
