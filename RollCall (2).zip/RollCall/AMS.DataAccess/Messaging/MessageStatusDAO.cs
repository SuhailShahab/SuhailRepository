﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.Generic;
using AMS.BusinessEntities.Messaging;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;

namespace AMS.DataAccess.Messaging
{
    public interface  IMessageStatusDAO
    {
        int InsertMessageStatus(MessageStatus emailStatus, int createdBy);
        bool IsEmailSend(int rollTimeStatusId,int emailTypeId);
        bool IsSMSSend(int rollTimeStatusId, int smsTypeId, int campusId);
    }
    public class MessageStatusDAO : BaseDAO<MessageStatus>, IMessageStatusDAO
    {
        string sp_MSG_EmailStatus_Add = "MSG_MessageStatus_Add";
         public MessageStatusDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }
         public MessageStatusDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

         public int InsertMessageStatus(MessageStatus messageStatus, int createdBy)
         {
             int i = 0;
             DbCommand cmd = dbConnection.CreateCommand();
             cmd.Transaction = dbTransaction;
             cmd.CommandType = CommandType.StoredProcedure;

             DbParameter p_MessageTypeId = cmd.CreateParameter();
             p_MessageTypeId.ParameterName = "p_MessageTypeId";
             p_MessageTypeId.DbType = DbType.Int32;
             p_MessageTypeId.Value = messageStatus.MessageType.GetHashCode();
             p_MessageTypeId.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_MessageTypeId);

             DbParameter p_RollTimeStatusId = cmd.CreateParameter();
             p_RollTimeStatusId.ParameterName = "p_RollTimeStatusId";
             p_RollTimeStatusId.DbType = DbType.Int32;
             p_RollTimeStatusId.Value = messageStatus.RollTimeAttendaceStatus.ID;
             p_RollTimeStatusId.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_RollTimeStatusId);

             DbParameter p_CampusId = cmd.CreateParameter();
             p_CampusId.ParameterName = "p_CampusId";
             p_CampusId.DbType = DbType.Int32;
             p_CampusId.Value = messageStatus.CampusId;
             p_CampusId.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_CampusId);           
             try
             {
                 cmd.CommandText = sp_MSG_EmailStatus_Add;

                 object returnValue = cmd.ExecuteScalar();//.ExecuteNonQuery();

                // if (returnValue == null)
                  //   throw new DAONoRecordFoundException();
                 i = Convert.ToInt32(returnValue);

             }
             catch (Exception ex)
             {
                 HandleDBException(ex);
             }
             return i;
         }

         
         public bool IsEmailSend(int rollTimeStatusId,int emailTypeid)
         {
             StringBuilder query = new StringBuilder();
            
             #region  Query
             query.Append(@"SELECT [MessageStatusId]      
                              FROM [dbo].[MSG_MessageStatus]
                              Where  CONVERT(VARCHAR, MessageDate, 111)  = CONVERT(VARCHAR, { fn NOW() }, 111)
                              AND RollTimeStatusId = " + rollTimeStatusId);
             query.Append(" AND MessageTypeId =" + emailTypeid);
             #endregion
             try
             {
                 System.Data.DataSet set = FindMetaData(query.ToString());

                 System.Data.DataTable tbl = set.Tables[0];
                 if (tbl.Rows.Count > 0)
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }
             catch (Exception ex)
             {
                 HandleDBException(ex);

             }
             return false;
         }


         public bool IsSMSSend(int rollTimeStatusId, int smsTypeId, int campusId)
         {
              StringBuilder query = new StringBuilder();
            
             #region  Query
             query.Append(@"SELECT [MessageStatusId]      
                              FROM [dbo].[MSG_MessageStatus]
                              Where  CONVERT(VARCHAR, MessageDate, 111)  = CONVERT(VARCHAR, { fn NOW() }, 111) ");
             query.Append(" AND MessageTypeId =" + smsTypeId + " AND CampusId = " +campusId);
             #endregion
             try
             {
                 System.Data.DataSet set = FindMetaData(query.ToString());

                 System.Data.DataTable tbl = set.Tables[0];
                 if (tbl.Rows.Count > 0)
                 {
                     return true;
                 }
                 else
                 {
                     return false;
                 }
             }
             catch (Exception ex)
             {
                 HandleDBException(ex);

             }
             return false;
         }
    }
}
