﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.Generic;
using AMS.BusinessEntities.Messaging;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;
using DataAccess.Exceptions;

namespace AMS.DataAccess.Messaging
{
    public interface  IMessageResponseDAO
    {
        List<MessageResponse> GetAllMessageResponse(int campusId);
        int AddMessageResponse(MessageResponse messageResponse);
        List<MessageResponse> GetAbsentStudents(int classId, int sectionId,int campusId, int rollTimeStatusId);
        int UpdateStudentMessage(string messageid, string messageText);
        int UpdateStudentSMSReason(int studentId, int attendanceStatusId,DateTime smsSendingDate);
        string GetLoginUserCampus(int loginUserId);
               
    }
    public class MessageResponseDAO : BaseDAO<MessageResponse>, IMessageResponseDAO
    {
        string sp_Add = "MSG_Student_SMS_Add";
        string sp_Update = "MSG_Gaurdian_Message_Update";
        string sp_Reason_Update = "MSG_Student_SMS_Reason_Update";
         public MessageResponseDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }
         public MessageResponseDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }
         public string GetLoginUserCampus(int campusId)
         {
             StringBuilder query = new StringBuilder();
             string result = string.Empty;
             #region  Query
             query.Append(@"Select * from Config_Campus where campusId = " + campusId);
             #endregion
             try
             {
                 System.Data.DataSet set = FindMetaData(query.ToString());

                 System.Data.DataTable tbl = set.Tables[0];
                 if (tbl.Rows.Count > 0)
                 {
                     result = (tbl.Rows[0]["CampusName"].ToString());
                 }

             }
             catch (Exception ex)
             {
                 HandleDBException(ex);

             }
             return result;




         }
         public int UpdateStudentSMSReason(int studentId, int attendanceStatusId,DateTime smsSedingDate)
         {
             int i = 0;
             DbCommand cmd = dbConnection.CreateCommand();
             cmd.Transaction = dbTransaction;
             cmd.CommandType = CommandType.StoredProcedure;

             DbParameter p_StudentId = cmd.CreateParameter();
             p_StudentId.ParameterName = "p_StudentId";
             p_StudentId.DbType = DbType.Int32;
             p_StudentId.Value = studentId;
             p_StudentId.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_StudentId);

             DbParameter p_AttendanceStatusId = cmd.CreateParameter();
             p_AttendanceStatusId.ParameterName = "p_AttendanceStatusId";
             p_AttendanceStatusId.DbType = DbType.Int32;
             p_AttendanceStatusId.Value = attendanceStatusId;
             p_AttendanceStatusId.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_AttendanceStatusId);

             DbParameter p_smsSendingDate = cmd.CreateParameter();
             p_smsSendingDate.ParameterName = "p_smsSendingDate";
             p_smsSendingDate.DbType = DbType.DateTime;
             p_smsSendingDate.Value = smsSedingDate;
             p_smsSendingDate.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_smsSendingDate);

            

             try
             {
                 cmd.CommandText = sp_Reason_Update;

                 object returnValue = cmd.ExecuteNonQuery();

                 if (returnValue == null)
                     throw new DAONoRecordFoundException();
                 i = Convert.ToInt32(returnValue);

             }
             catch (Exception ex)
             {
                 HandleDBException(ex);
             }
             return i;
         
         }
         public int UpdateStudentMessage(string messageid, string messageText)
         {
             int i = 0;
             DbCommand cmd = dbConnection.CreateCommand();
             cmd.Transaction = dbTransaction;
             cmd.CommandType = CommandType.StoredProcedure;

             DbParameter p_MessageId = cmd.CreateParameter();
             p_MessageId.ParameterName = "p_MessageId";
             p_MessageId.DbType = DbType.String;
             p_MessageId.Value = messageid;
             p_MessageId.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_MessageId);

             DbParameter p_MessageReply = cmd.CreateParameter();
             p_MessageReply.ParameterName = "p_MessageReply";
             p_MessageReply.DbType = DbType.String;
             p_MessageReply.Value = messageText;
             p_MessageReply.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_MessageReply);

             DbParameter p_ReplyDate = cmd.CreateParameter();
             p_ReplyDate.ParameterName = "p_ReplyDate";
             p_ReplyDate.DbType = DbType.DateTime;
             p_ReplyDate.Value = DateTime.Now;
             p_ReplyDate.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_ReplyDate);

             try
             {
                 cmd.CommandText = sp_Update;

                 object returnValue = cmd.ExecuteNonQuery();

                 if (returnValue == null)
                     throw new DAONoRecordFoundException();
                 i = Convert.ToInt32(returnValue);

             }
             catch (Exception ex)
             {
                 HandleDBException(ex);
             }
             return i;
         
         
         }
         public List<MessageResponse> GetAllMessageResponse(int campusId)
         {
             StringBuilder query = new StringBuilder();
            
             #region  Old Query
//             query.Append(@"SELECT  MR.[MessageResponseId]
//                              ,MR.[StudentId]
//                              ,MR.[AttendanceStatusId]
//                              ,MR.[ReplyId]
//                              ,MR.[MessageReply]
//                              ,MR.[ReplyDate]
//                              ,MR.[SourceMobileNumber]
//                              ,MR.[DestinationMobileNumber]
//                              ,MR.[ReferenceNumber]
//                              ,ST.FirstName 
//                              ,St.LastName 
//      
//                          FROM [Attendance].[dbo].[MSG_MessageResponse] MR
//                          INNER JOIN SR_Students ST
//                          ON MR.StudentId= St.StudentId  
//                          Where ActiionPerformed =0");
//             query.Append(" Order by MR.[ReplyDate] DESC ;");
             #endregion
             #region  Query
             /*query.Append(@"SELECT  ST.FirstName, ST.LastName,ST.StudentId,MR.ActionPerformed,MR.AttendanceStatusId, SourceMobileNumber,DestinationMobileNumber,SendingDateTime,MessageReply
                          FROM  [MSG_MessageResponse] MR
                          INNER JOIN SR_Students ST ON MR.StudentId = ST.StudentId
                          
                          Where (CONVERT(VARCHAR, isnull(MR.SendingDateTime,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)");*/
             query.Append(@"SELECT  ST.FirstName, ST.LastName,ST.StudentId,MR.ActionPerformed,MR.AttendanceStatusId, SourceMobileNumber,DestinationMobileNumber,SendingDateTime,MessageReply
                          FROM  [MSG_MessageResponse] MR
                          INNER JOIN SR_Students ST ON MR.StudentId = ST.StudentId
                          
                          Where (cast(CONVERT(varchar(8), MR.SendingDateTime, 112) AS datetime) >= '2013-08-31')");

             query.Append("AND (cast(CONVERT(varchar(8), MR.SendingDateTime, 112) AS datetime) <= '2013-09-15') AND MR.ActionPerformed = 0 ");
             query.Append(" and ST.CampusId = " + campusId);
             query.Append(" Order by ST.FirstName ASC ;");
             #endregion
             List<MessageResponse> results = new List<MessageResponse>();

             try
             {
                 System.Data.DataSet set = FindMetaData(query.ToString());

                 System.Data.DataTable tbl = set.Tables[0];
                 if (tbl.Rows.Count > 0)
                 {                    
                    results =ConstructFactory(tbl);
                     return results;
                 }
                 else
                 {
                     return null;
                 }
             }
             catch (Exception ex)
             {
                 HandleDBException(ex);

             }
             return results;
         }
         private List<MessageResponse> ConstructFactory(DataTable dt)
         {
             List<MessageResponse> messageResponses = new List<MessageResponse>();

             for (int rowIndex = 0; rowIndex < dt.Rows.Count; rowIndex++)
             {
                 MessageResponse messageResponse = new MessageResponse();
                 if (dt.Columns.Contains("MessageResponseId") && !Convert.IsDBNull(dt.Rows[rowIndex]["MessageResponseId"]))
                 {
                     messageResponse.ID = Convert.ToInt32(dt.Rows[rowIndex]["MessageResponseId"]);
                 }
                 if (dt.Columns.Contains("StudentId") && !Convert.IsDBNull(dt.Rows[rowIndex]["StudentId"]))
                 {
                     messageResponse.Studnet = new BusinessEntities.Student.Student();
                     messageResponse.Studnet.ID = Convert.ToInt32(dt.Rows[rowIndex]["StudentId"]);
                     if (dt.Columns.Contains("FirstName") && !Convert.IsDBNull(dt.Rows[rowIndex]["FirstName"]))
                     {
                         messageResponse.Studnet.Name = Convert.ToString(dt.Rows[rowIndex]["FirstName"]);
                     }
                     if (dt.Columns.Contains("LastName") && !Convert.IsDBNull(dt.Rows[rowIndex]["LastName"]))
                     {
                         messageResponse.Studnet.LastName  = Convert.ToString(dt.Rows[rowIndex]["LastName"]);
                     }
                 }

                 if (dt.Columns.Contains("AttendanceStatusId") && !Convert.IsDBNull(dt.Rows[rowIndex]["AttendanceStatusId"]))
                 {
                     messageResponse.AttendacneStatus = new BusinessEntities.Attendance.AttendanceStatus();
                     messageResponse.AttendacneStatus.ID = Convert.ToInt32(dt.Rows[rowIndex]["AttendanceStatusId"]);
                     if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dt.Rows[rowIndex]["Name"]))
                     {
                         messageResponse.AttendacneStatus.Name = Convert.ToString(dt.Rows[rowIndex]["Name"]);
                     }
                 }

                 if (dt.Columns.Contains("ReplyId") && !Convert.IsDBNull(dt.Rows[rowIndex]["ReplyId"]))
                 {
                     messageResponse.ReplayId = Convert.ToString(dt.Rows[rowIndex]["ReplyId"]);
                 }

                 if (dt.Columns.Contains("MessageReply") && !Convert.IsDBNull(dt.Rows[rowIndex]["MessageReply"]))
                 {
                     messageResponse.MessageReply  = Convert.ToString(dt.Rows[rowIndex]["MessageReply"]);
                 }

                 if (dt.Columns.Contains("ReplyDate") && !Convert.IsDBNull(dt.Rows[rowIndex]["ReplyDate"]))
                 {
                     messageResponse.ReplyDate = Convert.ToDateTime(dt.Rows[rowIndex]["ReplyDate"]);
                 }
                 if (dt.Columns.Contains("SendingDateTime") && !Convert.IsDBNull(dt.Rows[rowIndex]["SendingDateTime"]))
                 {
                     messageResponse.SmsSendingDateTime = Convert.ToDateTime(dt.Rows[rowIndex]["SendingDateTime"]);
                 }

                 if (dt.Columns.Contains("SourceMobileNumber") && !Convert.IsDBNull(dt.Rows[rowIndex]["SourceMobileNumber"]))
                 {
                     messageResponse.SourceMobileNumber  = Convert.ToString(dt.Rows[rowIndex]["SourceMobileNumber"]);
                 }

                 if (dt.Columns.Contains("MobileNumber") && !Convert.IsDBNull(dt.Rows[rowIndex]["MobileNumber"]))
                 {
                     messageResponse.DestinationMobileNumber  = Convert.ToString(dt.Rows[rowIndex]["MobileNumber"]);
                 }
                 if (dt.Columns.Contains("DestinationMobileNumber") && !Convert.IsDBNull(dt.Rows[rowIndex]["DestinationMobileNumber"]))
                 {
                     messageResponse.DestinationMobileNumber = Convert.ToString(dt.Rows[rowIndex]["DestinationMobileNumber"]);
                 }
                 if (dt.Columns.Contains("ReferenceNumber") && !Convert.IsDBNull(dt.Rows[rowIndex]["ReferenceNumber"]))
                 {
                     messageResponse.DestinationMobileNumber = Convert.ToString(dt.Rows[rowIndex]["ReferenceNumber"]);
                 }
                 if (dt.Columns.Contains("ActionPerformed") && !Convert.IsDBNull(dt.Rows[rowIndex]["ActionPerformed"]))
                 {
                     messageResponse.ActionPerformed = Convert.ToBoolean(dt.Rows[rowIndex]["ActionPerformed"]);
                 }
                 
                 messageResponses.Add(messageResponse);
                 
             }
             return messageResponses;
         }


         public int AddMessageResponse(MessageResponse messageResponse)
         {

             int i = 0;
             DbCommand cmd = dbConnection.CreateCommand();
             cmd.Transaction = dbTransaction;
             cmd.CommandType = CommandType.StoredProcedure;

             DbParameter p_StudentId = cmd.CreateParameter();
             p_StudentId.ParameterName = "p_StudentId";
             p_StudentId.DbType = DbType.Int32;
             p_StudentId.Value = messageResponse.Studnet.ID;
             p_StudentId.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_StudentId);

             DbParameter p_AttendanceStatusId = cmd.CreateParameter();
             p_AttendanceStatusId.ParameterName = "p_AttendanceStatusId";
             p_AttendanceStatusId.DbType = DbType.Int32;
             p_AttendanceStatusId.Value = messageResponse.AttendacneStatus.ID;
             p_AttendanceStatusId.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_AttendanceStatusId);

             DbParameter p_MessageId = cmd.CreateParameter();
             p_MessageId.ParameterName = "p_MessageId";
             p_MessageId.DbType = DbType.String;
             p_MessageId.Value = messageResponse.TwoWayMessageId;
             p_MessageId.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_MessageId);


             DbParameter p_SendingDateTime = cmd.CreateParameter();
             p_SendingDateTime.ParameterName = "p_SendingDateTime";
             p_SendingDateTime.DbType = DbType.DateTime;
             p_SendingDateTime.Value = DateTime.Now;
             p_SendingDateTime.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_SendingDateTime);
             //DbParameter p_SourceMobileNumber = cmd.CreateParameter();
             //p_SourceMobileNumber.ParameterName = "p_SourceMobileNumber";
             //p_SourceMobileNumber.DbType = DbType.Int32;
             //p_SourceMobileNumber.Value = messageResponse.SourceMobileNumber;
             //p_SourceMobileNumber.Direction = ParameterDirection.Input;
             //cmd.Parameters.Add(p_SourceMobileNumber);

             DbParameter p_DestinationMobileNumber = cmd.CreateParameter();
             p_DestinationMobileNumber.ParameterName = "p_DestinationMobileNumber";
             p_DestinationMobileNumber.DbType = DbType.String;
             p_DestinationMobileNumber.Value = messageResponse.DestinationMobileNumber;
             p_DestinationMobileNumber.Direction = ParameterDirection.Input;
             cmd.Parameters.Add(p_DestinationMobileNumber);

             try
             {
                 cmd.CommandText = sp_Add;

                 object returnValue = cmd.ExecuteScalar();//.ExecuteNonQuery();

                 if (returnValue == null)
                     throw new DAONoRecordFoundException();
                 i = Convert.ToInt32(returnValue);

             }
             catch (Exception ex)
             {
                 HandleDBException(ex);
             }
             return i;
         }

         public List<MessageResponse> GetAbsentStudents(int classId, int sectionId,int campusId, int rollTimeStatusId)
         {
             StringBuilder query = new StringBuilder();
             #region oldQuery
//             query.Append(@"SELECT SG.MobileNumber SourceMobileNumber, ST.FirstName, ST.LastName,SA.AttendanceDate ReplyDate
//                          FROM  [ATT_Student_Attendance] SA
//                          INNER JOIN ST_StudentGaurdian SG ON SA.StudentId = SG.StudentId
//                          INNER JOIN SR_Student_Classes SC ON SA.StudentId = SC.StudentId
//                          INNER JOIN SR_Students ST ON SA.StudentId = ST.StudentId
//                          Where [AttendanceStatusId] IN (3,5,6,7,13,14,15,16,17,18,19,20) 
//                          AND CONVERT(VARCHAR, isnull(SA.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
//                          AND (SC.ClassId = " + classId + " AND SC.SectionId = " + sectionId + ") AND RollTimeStatusId = " + rollTimeStatusId);
             // query.Append(" Order by MR.[ReplyDate] DESC ;");
             #endregion
             #region old 9/5/12  Query
//             query.Append(@"SELECT  ST.FirstName, ST.LastName,SA.AttendanceDate ReplyDate,SA.StudentId,SG.MobileNumber,SA.StudentAttendanceId,ST.StudentId
//                          FROM  [ATT_Student_Attendance] SA
//                        
//                          INNER JOIN SR_Student_Classes SC ON SA.StudentId = SC.StudentId
//                          INNER JOIN SR_Students ST ON SA.StudentId = ST.StudentId
//                          INNER JOIN ST_StudentGaurdian SG ON SG.StudentId = SC.StudentId
//                          Where [AttendanceStatusId] IN (3,5,6,7,13,14,15,16,17,18,19,20) 
//                          AND CONVERT(VARCHAR, isnull(SA.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
//                          AND (SC.ClassId = " + classId + " AND SC.SectionId = " + sectionId + ") AND RollTimeStatusId = " + rollTimeStatusId);
//             query.Append(" Order by ST.FirstName ASC ;");
             #endregion
             #region  Query
             query.Append(@"SELECT  ST.FirstName, ST.LastName,SA.AttendanceStatusId,SA.AttendanceDate ReplyDate,SA.StudentId,SG.MobileNumber,SA.StudentAttendanceId,ST.StudentId
                          FROM  [ATT_Student_Attendance] SA
                        
                          INNER JOIN SR_Student_Classes SC ON SA.StudentId = SC.StudentId
                          INNER JOIN SR_Students ST ON SA.StudentId = ST.StudentId
                          INNER JOIN  Config_Terms tm ON  SC.TermId = tm.TermId
                          INNER JOIN ST_StudentGaurdian SG ON SG.StudentId = SC.StudentId
                          Where [AttendanceStatusId] = 3 
                          AND CONVERT(VARCHAR, isnull(SA.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
                          AND RollTimeStatusId = " + rollTimeStatusId + " and SC.CampusId = " + campusId);
             query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
             //IN (3,5,6,7,13,14,15,16,17,18,19,20)
             query.Append(" Order by ST.FirstName ASC ;");

             #endregion
             List<MessageResponse> results = new List<MessageResponse>();

             try
             {
                 System.Data.DataSet set = FindMetaData(query.ToString());

                 System.Data.DataTable tbl = set.Tables[0];
                 if (tbl.Rows.Count > 0)
                 {
                     results = ConstructFactory(tbl);
                     return results;
                 }
                 else
                 {
                     return null;
                 }
             }
             catch (Exception ex)
             {
                 HandleDBException(ex);

             }
             return results;
         }
    }
}
