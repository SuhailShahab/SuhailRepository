﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.Generic;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data;
using AMS.BusinessEntities.Attendance;
using AMS.BusinessEntities.CustomEnum;

namespace AMS.DataAccess.Reports
{
    public interface  IReportDAO
    {
        DataSet GetAllAbsetLateStudents(int classId, int sectionId, int campusId, bool isAllClasses,DateTime attendanceDate, int teacherId);
        DataSet GetGenderBasedAbsentStudents(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId);
        DataSet GetAllStudentsAttendance(int classId, int sectionId, int campusId, bool isAllClasses,DateTime attendanceDate, int teacherId);
        DataSet GetAllStudentsAttendance(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId, int classLevelId);
        DataTable  GetStudentAttendaceLateCountReport(int classId, int sectionId, int campusId, int roleTimeStatusId);
        DataTable GetDailyStatsReport(StudentClassAssociation statsReportData);
        DataTable GetSummaryStatsReport(StudentClassAssociation statsReportData);

    }
    public class ReportDAO : BaseDAO<ReportDAO>, IReportDAO
    {
        public ReportDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

        public ReportDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }


        DataSet IReportDAO.GetAllAbsetLateStudents(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId)
        {
            StringBuilder query = new StringBuilder();

            #region Old query
            query.Append(@"SELECT ST.FirstName,ST.LastName,CL.Name CLASS_NAME,S.Name SECTION,SU.AttendanceSymbol   
                            FROM ATT_Student_Attendance SA
                            INNER JOIN SR_Students ST
                            ON SA.StudentId =ST.StudentId
                            INNER JOIN SR_Student_Classes SC
                            ON ST.StudentId = SC.StudentId 
                            INNER JOIN  Config_Terms tm ON  SC.TermId = tm.TermId 
                            INNER JOIN TR_ClassTeachers CT
                            ON CT.ClassId =  SC.ClassId AND CT.SectionId =SC.SectionId
                            INNER JOIN Config_Class CL
                            ON SC.ClassId = CL.ClassId 
                            INNER JOIN Config_Section S
                            ON SC.SectionId = S.SectionId 
                            INNER JOIN SYS_Attendance_Status SU
                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
                            WHERE SA.AttendanceStatusId IN(3,4,5,6,7,13,14,15,16,17,18,19,20)");
            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "' ");
            query.Append(" AND  Ct.TeacherId = " + teacherId);
            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.MoringRollTimeId);
            query.Append("  AND SC.CampusId = " + campusId);
            query.Append(" AND isnull(SC.IsActive,1) =  1 ");
            query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
            //query.Append(" AND CONVERT(VARCHAR, SA.AttendanceDate, 103) >= '2013-07-15' AND CONVERT(VARCHAR, SA.AttendanceDate, 103) <= '2013-08-15' ");
            if (!isAllClasses)
            {
                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);

            }
            //query.Append(" Group by ST.FirstName,ST.LastName,CL.Name,S.Name,SU.AttendanceSymbol");
            query.Append("  Order by ST.FirstName");
            #endregion

//            query.Append(@"SELECT CL.Name CLASS_NAME,S.Name SECTION   
//                            FROM ATT_Student_Attendance SA
//                            INNER JOIN SR_Students ST
//                            ON SA.StudentId =ST.StudentId
//                            INNER JOIN SR_Student_Classes SC
//                            ON ST.StudentId = SC.StudentId 
//                            INNER JOIN  Config_Terms tm ON  SC.TermId = tm.TermId 
//                            INNER JOIN TR_ClassTeachers CT
//                            ON CT.ClassId =  SC.ClassId AND CT.SectionId =SC.SectionId
//                            INNER JOIN Config_Class CL
//                            ON SC.ClassId = CL.ClassId 
//                            INNER JOIN Config_Section S
//                            ON SC.SectionId = S.SectionId 
//                            INNER JOIN SYS_Attendance_Status SU
//                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
//                            WHERE SA.AttendanceStatusId IN(3,4,5,6,7,13,14,15,16,17,18,19,20)");
//            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "' ");
//            query.Append(" AND  Ct.TeacherId = " + teacherId);
//            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.MoringRollTimeId);
//            query.Append("  AND SC.CampusId = " + campusId);
//            query.Append(" AND isnull(SC.IsActive,1) =  1 ");
//            query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
//            if (!isAllClasses)
//            {
//                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);

//            }
//            query.Append(" Group by CL.Name,S.Name");
//            //query.Append("  Order by ST.FirstName");
           try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());
                System.Data.DataTable tbl = set.Tables[0];
                tbl.TableName = "ATT_Student_Attendance";
                return set;

            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return null;
        }
        DataSet IReportDAO.GetGenderBasedAbsentStudents(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId)
        {
            StringBuilder query = new StringBuilder();

            #region Old query
            query.Append(@"SELECT CLASS_NAME,SECTION,Count(Case (Students.Gender) WHEN 'M' THEN 1 End ) Male,Count(Case (Students.Gender) WHEN 'F' THEN 1 End ) Female 
                            from(Select ST.FirstName,ST.Gender,ST.LastName,CL.Name CLASS_NAME,S.Name SECTION,SU.AttendanceSymbol   
                            FROM ATT_Student_Attendance SA
                            INNER JOIN SR_Students ST
                            ON SA.StudentId =ST.StudentId
                            INNER JOIN SR_Student_Classes SC
                            ON ST.StudentId = SC.StudentId 
                            INNER JOIN  Config_Terms tm ON  SC.TermId = tm.TermId 
                            INNER JOIN TR_ClassTeachers CT
                            ON CT.ClassId =  SC.ClassId AND CT.SectionId =SC.SectionId
                            INNER JOIN Config_Class CL
                            ON SC.ClassId = CL.ClassId 
                            INNER JOIN Config_Section S
                            ON SC.SectionId = S.SectionId 
                            INNER JOIN SYS_Attendance_Status SU
                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
                            WHERE SA.AttendanceStatusId IN(3,4,5,6,7,13,14,15,16,17,18,19,20)");
            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "' ");
            query.Append(" AND  Ct.TeacherId = " + teacherId);
            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.MoringRollTimeId);
            query.Append("  AND SC.CampusId = " + campusId);
            query.Append(" AND isnull(SC.IsActive,1) =  1 ");
            query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
            if (!isAllClasses)
            {
                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId );

            }
            query.Append(" ) Students Group by CLASS_NAME, SECTION");
            query.Append("  Order by CLASS_NAME");
            #endregion

            //            query.Append(@"SELECT CL.Name CLASS_NAME,S.Name SECTION   
            //                            FROM ATT_Student_Attendance SA
            //                            INNER JOIN SR_Students ST
            //                            ON SA.StudentId =ST.StudentId
            //                            INNER JOIN SR_Student_Classes SC
            //                            ON ST.StudentId = SC.StudentId 
            //                            INNER JOIN  Config_Terms tm ON  SC.TermId = tm.TermId 
            //                            INNER JOIN TR_ClassTeachers CT
            //                            ON CT.ClassId =  SC.ClassId AND CT.SectionId =SC.SectionId
            //                            INNER JOIN Config_Class CL
            //                            ON SC.ClassId = CL.ClassId 
            //                            INNER JOIN Config_Section S
            //                            ON SC.SectionId = S.SectionId 
            //                            INNER JOIN SYS_Attendance_Status SU
            //                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
            //                            WHERE SA.AttendanceStatusId IN(3,4,5,6,7,13,14,15,16,17,18,19,20)");
            //            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "' ");
            //            query.Append(" AND  Ct.TeacherId = " + teacherId);
            //            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.MoringRollTimeId);
            //            query.Append("  AND SC.CampusId = " + campusId);
            //            query.Append(" AND isnull(SC.IsActive,1) =  1 ");
            //            query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
            //            if (!isAllClasses)
            //            {
            //                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);

            //            }
            //            query.Append(" Group by CL.Name,S.Name");
            //            //query.Append("  Order by ST.FirstName");
            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());
                System.Data.DataTable tbl = set.Tables[0];
                tbl.TableName = "ATT_Student_Attendance";
                return set;

            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return null;
        }

        public DataSet GetAllStudentsAttendance(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId)
        {
            StringBuilder query = new StringBuilder();


            query.Append(@"SELECT ST.FirstName,ST.LastName,CL.Name CLASS_NAME,S.Name SECTION,SU.AttendanceSymbol   
                            FROM ATT_Student_Attendance SA
                            INNER JOIN SR_Students ST
                            ON SA.StudentId =ST.StudentId
                            INNER JOIN SR_Student_Classes SC
                            ON ST.StudentId = SC.StudentId
                            INNER JOIN  Config_Terms tm ON  SC.TermId = tm.TermId 
                            INNER JOIN TR_ClassTeachers CT
                            ON CT.ClassId =  SC.ClassId AND CT.SectionId =SC.SectionId
                            INNER JOIN Config_Class CL
                            ON SC.ClassId = CL.ClassId 
                            INNER JOIN Config_Section S
                            ON SC.SectionId = S.SectionId 
                            INNER JOIN SYS_Attendance_Status SU
                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
                            WHERE SA.AttendanceStatusId IN(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)");
            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "'");
            query.Append(" AND  Ct.TeacherId = " + teacherId);
            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.MoringRollTimeId);
            query.Append("  AND SC.CampusId = " + campusId);
            query.Append(" AND isnull(SC.IsActive,1) =  1 ");
            query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");

            if (!isAllClasses)
            {
                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);
                
            }
            query.Append("  Order by ST.FirstName");
                           // AND  CONVERT(VARCHAR, SA.AttendanceDate,111) = CONVERT(VARCHAR, { fn NOW() }, 111) 
                          //  AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);


            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());
                System.Data.DataTable tbl = set.Tables[0];
                tbl.TableName = "ATT_Student_Attendance";
                return set;

            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return null;
        }

        public DataSet GetAllStudentsAttendance(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId, int classLevelId)
        {
            StringBuilder query = new StringBuilder();
            #region old query
            //            query.Append(" Select * from ( ");
            //            query.Append(@"SELECT CL.ClassLevelId,ST.FirstName,ST.LastName,CL.Name CLASS_NAME,S.Name SECTION,SU.AttendanceSymbol   
            //                            FROM ATT_Student_Attendance SA
            //                            INNER JOIN SR_Students ST
            //                            ON SA.StudentId =ST.StudentId
            //                            INNER JOIN SR_Student_Classes SC
            //                            ON ST.StudentId = SC.StudentId 
            //                            INNER JOIN TR_ClassTeachers CT
            //                            ON CT.ClassId =  SC.ClassId AND CT.SectionId =SC.SectionId
            //                            INNER JOIN Config_Class CL
            //                            ON SC.ClassId = CL.ClassId 
            //                            INNER JOIN Config_Section S
            //                            ON SC.SectionId = S.SectionId 
            //                            INNER JOIN SYS_Attendance_Status SU
            //                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
            //                            WHERE SA.AttendanceStatusId IN(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)");
            //            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "'");
            //            query.Append(" AND  Ct.TeacherId = " + teacherId);
            //            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.MoringRollTimeId);           
            //            if (!isAllClasses)
            //            {
            //                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);
            //            }
            //            query.Append("  ) A ");
            //            query.Append("  where A.ClassLevelId = " + classLevelId);
            //            query.Append("  Order by A.FirstName");
            // AND  CONVERT(VARCHAR, SA.AttendanceDate,111) = CONVERT(VARCHAR, { fn NOW() }, 111) 
            //  AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);
            #endregion
            /*query.Append(" Select A.*,B.AttendanceSymbol EarlyLeaveSymbol from ( ");
            query.Append(@"SELECT ST.StudentId, CL.ClassLevelId,ST.FirstName,ST.LastName,CL.Name CLASS_NAME,S.Name SECTION,SU.AttendanceSymbol   
                            FROM ATT_Student_Attendance SA
                            INNER JOIN SR_Students ST
                            ON SA.StudentId =ST.StudentId
                            INNER JOIN SR_Student_Classes SC
                            ON ST.StudentId = SC.StudentId 
                            INNER JOIN TR_ClassTeachers CT
                            ON CT.ClassId =  SC.ClassId AND CT.SectionId =SC.SectionId
                            INNER JOIN Config_Class CL
                            ON SC.ClassId = CL.ClassId 
                            INNER JOIN Config_Section S
                            ON SC.SectionId = S.SectionId 
                            INNER JOIN SYS_Attendance_Status SU
                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
                            WHERE SA.AttendanceStatusId IN(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)");
            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "'");
            query.Append(" AND  Ct.TeacherId = " + teacherId);
            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.MoringRollTimeId);
            if (!isAllClasses)
            {
                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);
            }
            query.Append("  ) A ");
            query.Append(@"LEFT JOIN (SELECT ST.StudentId, CL.ClassLevelId,ST.FirstName,ST.LastName,CL.Name CLASS_NAME,S.Name SECTION,SU.AttendanceSymbol   
                            FROM ATT_Student_Attendance SA
                            INNER JOIN SR_Students ST
                            ON SA.StudentId =ST.StudentId
                            INNER JOIN SR_Student_Classes SC
                            ON ST.StudentId = SC.StudentId 
                            INNER JOIN TR_ClassTeachers CT
                            ON CT.ClassId =  SC.ClassId AND CT.SectionId =SC.SectionId
                            INNER JOIN Config_Class CL
                            ON SC.ClassId = CL.ClassId 
                            INNER JOIN Config_Section S
                            ON SC.SectionId = S.SectionId 
                            INNER JOIN SYS_Attendance_Status SU
                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
                            WHERE SA.AttendanceStatusId IN(8,9,10,11,12,21)");
            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "'");
            query.Append(" AND  Ct.TeacherId = " + teacherId);
            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.EveningRollTimeId);
            if (!isAllClasses)
            {
                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);
            }
            query.Append("  ) B ");
            query.Append(" on   A.StudentId = B.StudentId ");
            query.Append("  where A.ClassLevelId = " + classLevelId);
            query.Append("  Order by A.FirstName");*/
            query.Append(" Select A.*,B.AttendanceSymbol EarlyLeaveSymbol from ( ");
            query.Append(@"SELECT ST.StudentId, CL.ClassLevelId,ST.FirstName,ST.LastName,CL.Name CLASS_NAME,S.Name SECTION,SU.AttendanceSymbol   
                            FROM ATT_Student_Attendance SA
                            INNER JOIN SR_Students ST
                            ON SA.StudentId =ST.StudentId
                            INNER JOIN SR_Student_Classes SC
                            ON ST.StudentId = SC.StudentId
                            INNER JOIN  Config_Terms tm ON  SC.TermId = tm.TermId                           
                            INNER JOIN Config_Class CL
                            ON SC.ClassId = CL.ClassId 
                            INNER JOIN Config_Section S
                            ON SC.SectionId = S.SectionId 
                            INNER JOIN SYS_Attendance_Status SU
                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
                            WHERE SA.AttendanceStatusId IN(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20)");
            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "'");           
            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.MoringRollTimeId);
            query.Append("  AND SC.CampusId = " + campusId);
            query.Append(" AND isnull(SC.IsActive,1) =  1 ");
            query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");

            if (!isAllClasses)
            {
                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);
                
            }
            query.Append("  ) A ");
            query.Append(@"LEFT JOIN (SELECT ST.StudentId, CL.ClassLevelId,ST.FirstName,ST.LastName,CL.Name CLASS_NAME,S.Name SECTION,SU.AttendanceSymbol   
                            FROM ATT_Student_Attendance SA
                            INNER JOIN SR_Students ST
                            ON SA.StudentId =ST.StudentId
                            INNER JOIN SR_Student_Classes SC
                            ON ST.StudentId = SC.StudentId
                            INNER JOIN  Config_Terms tm ON  SC.TermId = tm.TermId                            
                            INNER JOIN Config_Class CL
                            ON SC.ClassId = CL.ClassId 
                            INNER JOIN Config_Section S
                            ON SC.SectionId = S.SectionId 
                            INNER JOIN SYS_Attendance_Status SU
                            ON SA.AttendanceStatusId =SU.AttendanceStatusId  
                            WHERE SA.AttendanceStatusId IN(8,9,10,11,12,21)");
            query.Append(" AND  CONVERT(VARCHAR, SA.AttendanceDate, 103) =  '" + attendanceDate.ToString("dd/MM/yyyy") + "'");            
            query.Append(" AND RollTimeStatusId = " + RollTimeStatusName.EveningRollTimeId);
            query.Append("  AND SC.CampusId = " + campusId);
            query.Append(" AND isnull(SC.IsActive,1) =  1 ");
            query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");

            if (!isAllClasses)
            {
                query.Append(" AND  SC.ClassId = " + classId + "and SC.SectionId = " + sectionId);
                query.Append("  AND SC.CampusId = " + campusId);
            }
            query.Append("  ) B ");
            query.Append(" on   A.StudentId = B.StudentId ");
            query.Append("  where A.ClassLevelId = " + classLevelId);
            query.Append("  Order by A.FirstName");

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());
                System.Data.DataTable tbl = set.Tables[0];
                tbl.TableName = "ATT_Student_Attendance";
                return set;

            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return null;
        }
        public DataTable GetStudentAttendaceLateCountReport(int classId, int sectionId, int campusId, int roleTimeStatusId)
        {
            StringBuilder query = new StringBuilder();
           
            #region  Query
            query.Append(@"SELECT     SR_Students.StudentId, SR_Students.FirstName, SR_Students.LastName,s.Name S_Names,tm.TermNo,C.Name C_NAME,SE.Name SECTION
                      ,(Select ISNULL(TotalLate,0)  from LateCount(4,SR_Students.StudentId,tm.TermId )) TLate 
                      ,(Select ISNULL(TotalLate,0)  from AbsentCount(SR_Students.StudentId,tm.TermId )) TAbsent                     
                      FROM         SR_Student_Classes INNER JOIN
                      SR_Students ON SR_Student_Classes.StudentId = SR_Students.StudentId 
                      INNER JOIN  Config_Terms tm ON  SR_Student_Classes.TermId = tm.TermId 
                      Left JOIN  ATT_Student_Attendance ON SR_Students.StudentId = ATT_Student_Attendance.StudentId
                      and CONVERT(VARCHAR, isnull(ATT_Student_Attendance.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
                      and isnull(ATT_Student_Attendance.RollTimeStatusId," + roleTimeStatusId + ") = " + roleTimeStatusId +
                      @" Left Join SYS_Attendance_Status s ON ATT_Student_Attendance.AttendanceStatusId = s.AttendanceStatusId 
                         INNER JOIN Config_Class C
                       ON C.ClassId =SR_Student_Classes.ClassId
                       INNER JOIN Config_Section SE
                       ON SE.SectionId = SR_Student_Classes.SectionId
                       Where SR_Student_Classes.ClassId= " + classId + " and SR_Student_Classes.SectionId = " + sectionId + " and SR_Student_Classes.CampusId = " + campusId);
            query.Append(" AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
            query.Append(" AND isnull(SR_Student_Classes.IsActive,1) =  1 ");
            query.Append(" Order by SR_Students.FirstName ;");

             //,(Select ISNULL(TotalLate,0)  from YearlyLateCount(4,SR_Students.StudentId,ATT_Student_Attendance.AttendanceDate )) TYearlyLate 
             //         ,(Select ISNULL(TotalLate,0)  from YearlyAbsentCount(SR_Students.StudentId,ATT_Student_Attendance.AttendanceDate )) TYearlyAbsent
            #endregion

           

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                tbl.TableName = "Student_Late_Absent_Count";
                if (tbl.Rows.Count > 0)
                {

                    return tbl;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return null;
        }
        public DataTable GetDailyStatsReport(StudentClassAssociation statsReportData)
        {
            StringBuilder query = new StringBuilder();
            string fromDate = statsReportData.StartDate.ToString("yyyy/MM/dd");
            string ToDate = statsReportData.StartDate.ToString("yyyy/MM/dd");
            #region  Query
            query.Append(@"Select distinct cc.DeewrId ,CONVERT(VARCHAR, C.AttendanceDate, 111) AttendanceDate, 'Y'+B.Name Grade
                    ,(Select ISNULL(Enrolment_Count,0)Enrolment_Count From TM_EnrolmentCount(1,A.ClassID,'M',null,C.AttendanceDate))TotalMaleEnrolments
                    ,(Select ISNULL(Enrolment_Count,0)Enrolment_Count From TM_EnrolmentCount(1,A.ClassID,'F',null,C.AttendanceDate))TotalFemaleEnrolments
                    ,
                    (Select ISNULL(Enrolment_Count,0)Enrolment_Count From TM_EnrolmentCount(1,A.ClassID,'M','YES',C.AttendanceDate))IndigMaleEnrol
                    ,
                    (Select ISNULL(Enrolment_Count,0)Enrolment_Count From TM_EnrolmentCount(1,A.ClassID,'F','YES',C.AttendanceDate))IndigFemaleEnrol
                    ,
                    (Select ISNULL(TAttandanceCount,0)TotalAttandance_Count From CountDailyAttendance2(1,A.ClassID,'M','No',AttendanceDate,A.TermId))TotalMaleAttendance
                    ,
                    (Select ISNULL(TAttandanceCount,0)TotalAttandance_Count From CountDailyAttendance2(1,A.ClassID,'F','No',C.AttendanceDate,A.TermId))TotalFemaleAttendance
                    ,
                    (Select ISNULL(TAttandanceCount,0)TotalAttandance_Count From CountDailyAttendance2(1,A.ClassID,'M','Yes',C.AttendanceDate,A.TermId))IndigMaleAttendance
                    ,(Select ISNULL(TAttandanceCount,0)TotalAttandance_Count From CountDailyAttendance2(1,A.ClassID,'F','Yes',C.AttendanceDate,A.TermId))IndigFemaleAttendance
                    ,A.ClassID,A.TermId
                    from SR_Student_Classes A
                    Inner join Config_Class B
                    ON A.ClassId = B.ClassId 
                    Inner join ATT_Student_Attendance C
                    on A.StudentId = c.StudentId 
                    INNER JOIN Config_Campus cc
                    ON A.CampusId = cc.CampusId
                    Inner join Config_Terms t
                    ON A.TermId = t.TermId 
                    Where 
                    DATEADD(D, 0, DATEDIFF(D, 0,C.AttendanceDate)) between '" +fromDate+"' and '"+ToDate+@"'--c.AttendanceDate in('2013-04-17','2013-04-18')
                    AND C.RollTimeStatusId = 1 --AND C.AttendanceStatusId IN(2,4,7,8,9,10,11,12,16,19,21,22)
                    --AND A.CampusId =1 
                    AND t.StartingDate <='"+fromDate+"' And t.EndingDate >= '"+fromDate+@"'
                    And 0 > =(Select COUNT(HolidayId) from SYS_PublicHolidays where StartDateHoliday <='" + fromDate + "' and EndDateHoliday >= '" + fromDate + @"')
                    And DATENAME(dw, CONVERT(VARCHAR, C.AttendanceDate, 111)) NOT IN ('Saturday', 'Sunday')
                     ");
               
                   //Where  S.CampusId = ISNULL(1,S.CampusId ) And Sc.ClassId = 1 
                 //  And Sc.SectionId = 2");
           // query.Append(" AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
          //  query.Append(" AND isnull(B.IsActive,1) =  1 ");
          //  query.Append(" Order by D.FirstName ;");

            //,(Select ISNULL(TotalLate,0)  from YearlyLateCount(4,SR_Students.StudentId,ATT_Student_Attendance.AttendanceDate )) TYearlyLate 
            //         ,(Select ISNULL(TotalLate,0)  from YearlyAbsentCount(SR_Students.StudentId,ATT_Student_Attendance.AttendanceDate )) TYearlyAbsent


            if (statsReportData.Campus.ID != -1)
            {
                query.Append(" AND A.CampusId = ISNULL(" + statsReportData.Campus.ID + ",A.CampusId )");
            
            }
            if (statsReportData.StudentClass.ID != -1)
            {
                query.Append(" AND A.ClassId = " + statsReportData.StudentClass.ID);

            }
            //if (statsReportData.Section.ID != -1)
            //{
            //    query.Append(" AND Sc.SectionId = " + statsReportData.Section.ID);

            //}
            query.Append(" Group by AttendanceDate , B.Name,cc.DeewrId ,A.ClassID,A.TermId");
            #endregion



            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                tbl.TableName = "DailyStatsReport";
                if (tbl.Rows.Count > 0)
                {

                    return tbl;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return null;
        
        }

        public DataTable GetSummaryStatsReport(StudentClassAssociation statsReportData)
        {
            StringBuilder query = new StringBuilder();
            string month = (statsReportData.StartDate.Month.ToString("00"));
            string year = statsReportData.StartDate.Year.ToString("0000");
            int campusId = statsReportData.Campus.ID;
            #region old  Query
//            query.Append(@"Select distinct cc.DeewrId ,Month(C.AttendanceDate) AttendanceDate, 'Y'+B.Name Grade
//                        ,A.ClassId  
//                        ,(Select  dbo.fn_MonthlyCountEnroll(1,A.ClassId,'M','No', Month(C.AttendanceDate) )) TotalMaleEnrolments
//                        ,(Select  dbo.fn_MonthlyCountEnroll(1,A.ClassId,'F','No', Month(C.AttendanceDate) )) TotalFemaleEnrolments
//                        ,(Select  dbo.fn_MonthlyCountEnroll(1,A.ClassId,'M','Yes', Month(C.AttendanceDate) )) IndigMaleEnrol
//                        ,(Select  dbo.fn_MonthlyCountEnroll(1,A.ClassId,'F','Yes', Month(C.AttendanceDate) )) IndigFemaleEnrol
//                        ,(Select  dbo.fn_MonthlyCount(1,A.ClassId,'M','No', Month(C.AttendanceDate) )) TotalMaleAttendance
//                        ,(Select  dbo.fn_MonthlyCount(1,A.ClassId,'F','No', Month(C.AttendanceDate) )) TotalFemaleAttendance
//                        ,(Select  dbo.fn_MonthlyCount(1,A.ClassId,'M','Yes', Month(C.AttendanceDate) )) IndigMaleAttendance
//                        ,(Select  dbo.fn_MonthlyCount(1,A.ClassId,'F','Yes', Month(C.AttendanceDate) )) IndigFemaleAttendance
//                        from SR_Student_Classes A 
//                        Inner join Config_Class B ON A.ClassId = B.ClassId 
//                        Inner join ATT_Student_Attendance C on A.StudentId = c.StudentId 
//                        INNER JOIN Config_Campus cc ON A.CampusId = cc.CampusId
//
//                        Where 
//                        Month(C.AttendanceDate) = '" +month+"' AND Year(C.AttendanceDate) = '"+year+@"'
//                        AND C.RollTimeStatusId = 1 --AND C.AttendanceStatusId IN(2,4,7,8,9,10,11,12,16,19,21,22)
//                        --AND A.CampusId =1 --and s.CampusId =1 --AND A.TermId =1 AND c.
//                        AND A.TermId in(Select TermId from Config_Terms where Month(StartingDate) <= '" + month + "' and  '" + month + "' <= Month(EndingDate)and YEAR(StartingDate)='" + year + @"')
//                        And DATENAME(dw, CONVERT(VARCHAR, C.AttendanceDate, 111)) NOT IN ('Saturday', 'Sunday')
//                        ");
//           // query.Append(" AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
//          //  query.Append(" AND isnull(B.IsActive,1) =  1 ");
//         //   query.Append(" Order by D.FirstName ;");

//            //,(Select ISNULL(TotalLate,0)  from YearlyLateCount(4,SR_Students.StudentId,ATT_Student_Attendance.AttendanceDate )) TYearlyLate 
//            //         ,(Select ISNULL(TotalLate,0)  from YearlyAbsentCount(SR_Students.StudentId,ATT_Student_Attendance.AttendanceDate )) TYearlyAbsent
//            if (statsReportData.Campus.ID != -1)
//            {
//                query.Append(" AND A.CampusId = ISNULL(" + statsReportData.Campus.ID + ",A.CampusId )");

//            }
//            if (statsReportData.StudentClass.ID != -1)
//            {
//                query.Append(" AND A.ClassId = " + statsReportData.StudentClass.ID);

//            }
//            //if (statsReportData.Section.ID != -1)
//            //{
//            //    query.Append(" AND Sc.SectionId = " + statsReportData.Section.ID);

//            //}
//            query.Append(" Group by Month(C.AttendanceDate), B.Name,cc.DeewrId,A.ClassId");

            #endregion
            #region Query
            query.Append(@"Select * ,DATENAME(month, 2) AttendanceDate 
                            ,(Select dbo.fn_MonthlyCountEnroll(" + campusId + @",ClassId,'M','No', '" + month + @"',T1.TermId )) TotalMaleEnrolments
                            ,(Select dbo.fn_MonthlyCountEnroll(" + campusId + @",ClassId,'F','No','" + month + @"',T1.TermId )) TotalFemaleEnrolments
                            ,(Select dbo.fn_MonthlyCountEnroll(" + campusId + @",ClassId,'M','Yes', '" + month + @"',T1.TermId)) IndigMaleEnrol
                            ,(Select dbo.fn_MonthlyCountEnroll(" + campusId + @",ClassId,'F','Yes', '" + month + @"',T1.TermId)) IndigFemaleEnrol
                            ,(Select dbo.fn_MonthlyCount(" + campusId + @",ClassId,'M','No','" + month + @"',T1.TermId )) TotalMaleAttendance
                            ,(Select dbo.fn_MonthlyCount(" + campusId + @",ClassId,'F','No', '" + month + @"',T1.TermId )) TotalFemaleAttendance
                            ,(Select dbo.fn_MonthlyCount(" + campusId + @",ClassId,'F','Yes', '" + month + @"',T1.TermId )) IndigMaleAttendance
                            ,(Select dbo.fn_MonthlyCount(" + campusId + @",ClassId,'F','Yes', '" + month + @"',T1.TermId )) IndigFemaleAttendance
                            From (
                            Select distinct cc.DeewrId , 'Y'+B.Name Grade
                            ,A.ClassId ,A.TermId 
                            from SR_Student_Classes A 
                            Inner join Config_Class B ON A.ClassId = B.ClassId 
                            --Inner join ATT_Student_Attendance C on A.StudentId = c.StudentId 
                            INNER JOIN Config_Campus cc ON A.CampusId = cc.CampusId
                            Where 
                            A.CampusId =" + campusId + @"
                            AND A.TermId in(Select TermId from Config_Terms where Month(StartingDate) <= '" + month + "' and  '" + month + "'<= Month(EndingDate)and YEAR(StartingDate)='" + year + @"')

                            Group by B.Name,cc.DeewrId,A.ClassId,A.TermId --
                            ) T1 order by T1.ClassId ");


            #endregion
            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                tbl.TableName = "SummaryStatsReport";
                if (tbl.Rows.Count > 0)
                {

                    return tbl;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return null;
        
        }

    }
}
