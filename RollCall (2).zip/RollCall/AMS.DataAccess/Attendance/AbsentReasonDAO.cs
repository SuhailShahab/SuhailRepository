﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Attendance;
using DataAccess.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;
using DataAccess.Exceptions;

namespace AMS.DataAccess.Attendance
{
    public interface  IAbsentReasonDAO
    {
        int InsertAbsentReason(AbsentReason absentReason,int studentAttendanceId, int createdBy);
        int UpdateAbsentReason(AbsentReason absentReason, int studentAttendanceId, int createdBy);
    }
    public class AbsentReasonDAO : BaseDAO<AbsentReason>, IAbsentReasonDAO
    {
        string sp_Add = "ATT_Absent_Reason_Add";
        string sp_Update = "ATT_Absent_Reason_Update";
        public AbsentReasonDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

        public AbsentReasonDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

        public int InsertAbsentReason(AbsentReason absentReason,int studentAttendanceId, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_StartDate = cmd.CreateParameter();
            p_StartDate.ParameterName = "p_StartDate";
            p_StartDate.DbType = DbType.DateTime;
            p_StartDate.Value = absentReason.StartDate;
            p_StartDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StartDate);

            DbParameter p_EndDate = cmd.CreateParameter();
            p_EndDate.ParameterName = "p_EndDate";
            p_EndDate.DbType = DbType.DateTime;
            p_EndDate.Value = absentReason.EndingDate;
            p_EndDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_EndDate);

            DbParameter p_StudentAttendanceId = cmd.CreateParameter();
            p_StudentAttendanceId.ParameterName = "p_StudentAttendanceId";
            p_StudentAttendanceId.DbType = DbType.DateTime;
            p_StudentAttendanceId.Value = studentAttendanceId;
            p_StudentAttendanceId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_EndDate);

            DbParameter p_Reason = cmd.CreateParameter();
            p_Reason.ParameterName = "p_Reason";
            p_Reason.DbType = DbType.String;
            if (string.IsNullOrEmpty(absentReason.Reason))
            {
                p_Reason.Value = DBNull.Value;
            }
            else
            {
                p_Reason.Value = absentReason.Reason;
            }
            p_Reason.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Reason);

            try
            {
                cmd.CommandText = sp_Add;

                object returnValue = cmd.ExecuteScalar();//.ExecuteNonQuery();

                if (returnValue == null)
                    throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }

        public int UpdateAbsentReason(AbsentReason absentReason, int studentAttendanceId, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_AbsentReasonId = cmd.CreateParameter();
            p_AbsentReasonId.ParameterName = "p_AbsentReasonId";
            p_AbsentReasonId.DbType = DbType.Int32;
            p_AbsentReasonId.Value = absentReason.ID;
            p_AbsentReasonId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_AbsentReasonId);

            DbParameter p_StartDate = cmd.CreateParameter();
            p_StartDate.ParameterName = "p_StartDate";
            p_StartDate.DbType = DbType.Int32;
            p_StartDate.Value = absentReason.StartDate;
            p_StartDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StartDate);

            DbParameter p_EndDate = cmd.CreateParameter();
            p_EndDate.ParameterName = "p_EndDate";
            p_EndDate.DbType = DbType.Int32;
            p_EndDate.Value = absentReason.EndingDate;
            p_EndDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_EndDate);

            DbParameter p_Reason = cmd.CreateParameter();
            p_Reason.ParameterName = "p_Reason";
            p_Reason.DbType = DbType.String;
            if (string.IsNullOrEmpty(absentReason.Reason))
            {
                p_Reason.Value = DBNull.Value;
            }
            else
            {
                p_Reason.Value = absentReason.Reason;
            }
            p_Reason.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Reason);

            try
            {
                cmd.CommandText = sp_Update;

                object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                if (returnValue == null)
                    throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }
    }
}
