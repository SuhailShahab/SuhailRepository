﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DataAccess.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using AMS.BusinessEntities.Attendance;
using DataAccess.Exceptions;

namespace AMS.DataAccess.Attendance
{
    public interface  ILatePassDAL
    {
        int insertLatePass(int studentAttendanceId, LatePass latePass,int createdBy);
        int UpdateAttendanceStatus(int studnetAttendacneId, int attendacneStatusId, int createdBy);
        int AddEarlyLeave(StudentAttendace studentAttendance, int createdBy);
        int UpdateEarlyLeave(StudentAttendace studentAttendance, int createdBy);
        int SaveEarlyLeave(StudentAttendace studentAttendance, int createdBy);
        DataSet  GetLatePassById(int studentAttendanceId);
    }
    public class LatePassDAL : BaseDAO<LatePassDAL>, ILatePassDAL
    {
        string sp_Add = "ATT_LatePass_Add";
        string sp_Update = "ATT_Student_Attendance_Update";
        string sp_UdateAttendanceStatus = "ATT_Update_AttendanceStatus";
        string sp_AddEarlyLeave = "ATT_AddEarlyLeave";
        string sp_SaveEarlyLeave = "ATT_Add_UpdateEarlyLeave";
        public LatePassDAL(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

        public LatePassDAL(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

        public DataSet GetLatePassById(int studentAttendanceId)
        {
            StringBuilder query = new StringBuilder();


            query.Append(@"SELECT AT.StudentAttendanceId,AT.AttendanceDate ,AT.Reason,s.Name [Status], st.FirstName, st.LastName
                            FROM ATT_Student_Attendance AT
                             INNER JOIN SR_Students st
                             ON AT.StudentId = st.StudentId 
                            INNER JOIN SYS_Attendance_Status s ON 
                             s.AttendanceStatusId = AT.AttendanceStatusId
                            WHERE     (AT.StudentAttendanceId = " + studentAttendanceId + ")");


            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());
                System.Data.DataTable tbl = set.Tables[0];
                tbl.TableName = "UMS_LatePass";
                return set;
               
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return null;
        }

        public int insertLatePass(int studentAttendanceId, LatePass latePass, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_AttendanceStatusId = cmd.CreateParameter();
            p_AttendanceStatusId.ParameterName = "p_AttendanceStatusId";
            p_AttendanceStatusId.DbType = DbType.Int32;
            p_AttendanceStatusId.Value = latePass.AttendanceStatus.ID;
            p_AttendanceStatusId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_AttendanceStatusId);

            DbParameter p_StudentId = cmd.CreateParameter();
            p_StudentId.ParameterName = "p_StudentId";
            p_StudentId.DbType = DbType.Int32;
            p_StudentId.Value = latePass.Student.ID;
            p_StudentId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StudentId);

            DbParameter p_StudentAttendanceId = cmd.CreateParameter();
            p_StudentAttendanceId.ParameterName = "p_StudentAttendanceId";
            p_StudentAttendanceId.DbType = DbType.Int32;
            p_StudentAttendanceId.Value = studentAttendanceId;
            p_StudentAttendanceId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StudentAttendanceId);

            DbParameter p_CREATED_BY = cmd.CreateParameter();
            p_CREATED_BY.ParameterName = "p_CREATED_BY";
            p_CREATED_BY.DbType = DbType.Int32;
            p_CREATED_BY.Value = createdBy;
            p_CREATED_BY.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_CREATED_BY);


            try
            {
                cmd.CommandText = sp_Add;

                object returnValue = cmd.ExecuteScalar();//.ExecuteNonQuery();

                if (returnValue == null)
                    throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }


        public int UpdateAttendanceStatus(int studnetAttendacneId,int attendacneStatusId, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_StudentAttendanceId = cmd.CreateParameter();
            p_StudentAttendanceId.ParameterName = "p_StudentAttendanceId";
            p_StudentAttendanceId.DbType = DbType.Int32;
            p_StudentAttendanceId.Value = studnetAttendacneId;
            p_StudentAttendanceId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StudentAttendanceId);

            DbParameter p_LAST_MODIFIED_BY = cmd.CreateParameter();
            p_LAST_MODIFIED_BY.ParameterName = "p_LAST_MODIFIED_BY";
            p_LAST_MODIFIED_BY.DbType = DbType.Int32;
            p_LAST_MODIFIED_BY.Value = createdBy;
            p_LAST_MODIFIED_BY.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_LAST_MODIFIED_BY);

            DbParameter p_Attendance_Status_Id = cmd.CreateParameter();
            p_Attendance_Status_Id.ParameterName = "p_Attendance_Status_Id";
            p_Attendance_Status_Id.DbType = DbType.Int32;
            p_Attendance_Status_Id.Value = attendacneStatusId;
            p_Attendance_Status_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Attendance_Status_Id);

            try
            {
                cmd.CommandText = sp_Update;

                object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                if (returnValue == null)
                    throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }

        public int AddEarlyLeave(StudentAttendace studentAttendance, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_Student_Id = cmd.CreateParameter();
            p_Student_Id.ParameterName = "p_Student_Id";
            p_Student_Id.DbType = DbType.Int32;
            p_Student_Id.Value = studentAttendance.Student.ID;
            p_Student_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Student_Id);

            DbParameter p_Attendance_Status_Id = cmd.CreateParameter();
            p_Attendance_Status_Id.ParameterName = "p_Attendance_Status_Id";
            p_Attendance_Status_Id.DbType = DbType.Int32;
            p_Attendance_Status_Id.Value = studentAttendance.AttendanceStatus.ID;
            p_Attendance_Status_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Attendance_Status_Id);

            DbParameter p_RollTimeStatusId = cmd.CreateParameter();
            p_RollTimeStatusId.ParameterName = "p_RollTimeStatusId";
            p_RollTimeStatusId.DbType = DbType.Int32;
            p_RollTimeStatusId.Value = studentAttendance.RollTimeAttendaceStatus.ID;
            p_RollTimeStatusId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_RollTimeStatusId);

            DbParameter p_Reason = cmd.CreateParameter();
            p_Reason.ParameterName = "p_Reason";
            p_Reason.DbType = DbType.String;
            if(string.IsNullOrEmpty(studentAttendance.Reason))
            {
                p_Reason.Value = DBNull.Value;
            }
            else 
            {
                p_Reason.Value = studentAttendance.Reason;
            }           
            p_Reason.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Reason);

            DbParameter Remarks = cmd.CreateParameter();
            Remarks.ParameterName = "Remarks";
            Remarks.DbType = DbType.String;
            if (string.IsNullOrEmpty(studentAttendance.Remarks))
            {
                Remarks.Value = DBNull.Value;
            }
            else
            {
                Remarks.Value = studentAttendance.Remarks;
            }
            Remarks.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(Remarks);

            DbParameter p_AttendanceDate = cmd.CreateParameter();
            p_AttendanceDate.ParameterName = "p_AttendanceDate";
            p_AttendanceDate.DbType = DbType.DateTime;
            if (studentAttendance.AttendanceDate.Year == 1)
            {
                p_AttendanceDate.Value = DateTime.Now; //DBNull.Value;
            }
            else
            {
                p_AttendanceDate.Value = studentAttendance.AttendanceDate;
            }
            p_AttendanceDate.Direction = ParameterDirection.Input;           
            cmd.Parameters.Add(p_AttendanceDate);

            DbParameter p_CREATED_BY = cmd.CreateParameter();
            p_CREATED_BY.ParameterName = "p_CREATED_BY";
            p_CREATED_BY.DbType = DbType.Int32;
            p_CREATED_BY.Value = createdBy;
            p_CREATED_BY.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_CREATED_BY);

            DbParameter p_VersionNo = cmd.CreateParameter();
            p_VersionNo.ParameterName = "p_VersionNo";
            p_VersionNo.DbType = DbType.Int32;
            p_VersionNo.Value = 0;
            p_VersionNo.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_VersionNo);


            try
            {
                cmd.CommandText = sp_AddEarlyLeave;

                object returnValue = cmd.ExecuteScalar();//.ExecuteNonQuery();

                if (returnValue == null)
                    throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }


        public int SaveEarlyLeave(StudentAttendace studentAttendance, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_Student_Id = cmd.CreateParameter();
            p_Student_Id.ParameterName = "p_Student_Id";
            p_Student_Id.DbType = DbType.Int32;
            p_Student_Id.Value = studentAttendance.Student.ID;
            p_Student_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Student_Id);

            DbParameter p_Attendance_Status_Id = cmd.CreateParameter();
            p_Attendance_Status_Id.ParameterName = "p_Attendance_Status_Id";
            p_Attendance_Status_Id.DbType = DbType.Int32;
            p_Attendance_Status_Id.Value = studentAttendance.AttendanceStatus.ID;
            p_Attendance_Status_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Attendance_Status_Id);

            DbParameter p_RollTimeStatusId = cmd.CreateParameter();
            p_RollTimeStatusId.ParameterName = "p_RollTimeStatusId";
            p_RollTimeStatusId.DbType = DbType.Int32;
            p_RollTimeStatusId.Value = studentAttendance.RollTimeAttendaceStatus.ID;
            p_RollTimeStatusId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_RollTimeStatusId);

            DbParameter p_Reason = cmd.CreateParameter();
            p_Reason.ParameterName = "p_Reason";
            p_Reason.DbType = DbType.String;
            if (string.IsNullOrEmpty(studentAttendance.Reason))
            {
                p_Reason.Value = DBNull.Value;
            }
            else
            {
                p_Reason.Value = studentAttendance.Reason;
            }
            p_Reason.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Reason);

            DbParameter p_AttendanceDate = cmd.CreateParameter();
            p_AttendanceDate.ParameterName = "p_AttendanceDate";
            p_AttendanceDate.DbType = DbType.DateTime;
            if (studentAttendance.AttendanceDate.Year == 1)
            {
                p_AttendanceDate.Value = DateTime.Now; //DBNull.Value;
            }
            else
            {
                p_AttendanceDate.Value = studentAttendance.AttendanceDate;
            }
            p_AttendanceDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_AttendanceDate);

            DbParameter Remarks = cmd.CreateParameter();
            Remarks.ParameterName = "Remarks";
            Remarks.DbType = DbType.String;
            if (string.IsNullOrEmpty(studentAttendance.Remarks))
            {
                Remarks.Value = DBNull.Value;
            }
            else
            {
                Remarks.Value = studentAttendance.Remarks;
            }
            Remarks.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(Remarks);

            DbParameter p_CREATED_BY = cmd.CreateParameter();
            p_CREATED_BY.ParameterName = "p_CREATED_BY";
            p_CREATED_BY.DbType = DbType.Int32;
            p_CREATED_BY.Value = createdBy;
            p_CREATED_BY.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_CREATED_BY);

            DbParameter p_VersionNo = cmd.CreateParameter();
            p_VersionNo.ParameterName = "p_VersionNo";
            p_VersionNo.DbType = DbType.Int32;
            p_VersionNo.Value = 0;
            p_VersionNo.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_VersionNo);


            try
            {
                cmd.CommandText = sp_SaveEarlyLeave;

                object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                if (returnValue == null)
                   throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }


        public int UpdateEarlyLeave(StudentAttendace studentAttendance, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_StudentAttendanceId = cmd.CreateParameter();
            p_StudentAttendanceId.ParameterName = "p_StudentAttendanceId";
            p_StudentAttendanceId.DbType = DbType.Int32;
            p_StudentAttendanceId.Value = studentAttendance.ID;
            p_StudentAttendanceId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StudentAttendanceId);

            DbParameter p_Student_Id = cmd.CreateParameter();
            p_Student_Id.ParameterName = "p_Student_Id";
            p_Student_Id.DbType = DbType.Int32;
            p_Student_Id.Value = studentAttendance.Student.ID;
            p_Student_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Student_Id);

            DbParameter p_Attendance_Status_Id = cmd.CreateParameter();
            p_Attendance_Status_Id.ParameterName = "p_Attendance_Status_Id";
            p_Attendance_Status_Id.DbType = DbType.Int32;
            p_Attendance_Status_Id.Value = studentAttendance.AttendanceStatus.ID;
            p_Attendance_Status_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Attendance_Status_Id);

            DbParameter Remarks = cmd.CreateParameter();
            Remarks.ParameterName = "Remarks";
            Remarks.DbType = DbType.String;
            if (string.IsNullOrEmpty(studentAttendance.Remarks))
            {
                Remarks.Value = DBNull.Value;
            }
            else
            {
                Remarks.Value = studentAttendance.Remarks;
            }
            Remarks.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(Remarks);

            //DbParameter p_RollTimeStatusId = cmd.CreateParameter();
            //p_RollTimeStatusId.ParameterName = "p_RollTimeStatusId";
            //p_RollTimeStatusId.DbType = DbType.Int32;
            //p_RollTimeStatusId.Value = studentAttendance.RollTimeAttendaceStatus.ID;
            //p_RollTimeStatusId.Direction = ParameterDirection.Input;
            //cmd.Parameters.Add(p_RollTimeStatusId);

            DbParameter p_Reason = cmd.CreateParameter();
            p_Reason.ParameterName = "p_Reason";
            p_Reason.DbType = DbType.String;
            if (string.IsNullOrEmpty(studentAttendance.Reason))
            {
                p_Reason.Value = DBNull.Value;
            }
            else
            {
                p_Reason.Value = studentAttendance.Reason;
            }
            p_Reason.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Reason);

            DbParameter p_AttendanceDate = cmd.CreateParameter();
            p_AttendanceDate.ParameterName = "p_AttendanceDate";
            p_AttendanceDate.DbType = DbType.DateTime;
            if (studentAttendance.AttendanceDate.Year == 1)
            {
                p_AttendanceDate.Value = DateTime.Now; //DBNull.Value;
            }
            else
            {
                p_AttendanceDate.Value = studentAttendance.AttendanceDate;
            }
            p_AttendanceDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_AttendanceDate);

           

            DbParameter p_CREATED_BY = cmd.CreateParameter();
            p_CREATED_BY.ParameterName = "p_CREATED_BY";
            p_CREATED_BY.DbType = DbType.Int32;
            p_CREATED_BY.Value = createdBy;
            p_CREATED_BY.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_CREATED_BY);

            DbParameter p_VersionNo = cmd.CreateParameter();
            p_VersionNo.ParameterName = "p_VersionNo";
            p_VersionNo.DbType = DbType.Int32;
            p_VersionNo.Value = 0;
            p_VersionNo.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_VersionNo);


            try
            {
                cmd.CommandText = "ATT_UpdateEarlyLeave";

                int returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                //if (returnValue == null)
                //    throw new DAONoRecordFoundException();
                // i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }
    }
}
