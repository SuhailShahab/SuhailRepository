﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Attendance;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using DataAccess.Generic;
using AMS.BusinessEntities.CustomEnum;
using System.Data;
using DataAccess.Exceptions;
using AMS.BusinessEntities.Messaging;

namespace AMS.DataAccess.Attendance
{

    public interface IStudentAttendaceDAO
    {
        List<StudentAttendace> GetStudentAttendaceById(int classId, int sectionId,int campusId,int roleTimeStatusId);
        List<StudentAttendace> GetStudentAttendaceById(int classId, int sectionId, int campusId, int roleTimeStatusId,DateTime selectedDate,int loginId);
        List<StudentAttendace> GetStudentAttendaceLateCountByDate(int classId, int sectionId, int campusId, int roleTimeStatusId, DateTime selectedDate, int loginId);
        List<StudentAttendace> GetStudentAttendaceLateCount(int classId, int sectionId, int campusId, int roleTimeStatusId);
        int InsertStudentAttendace(StudentAttendace studentAttendace, int createdBy);
        int  UpdateStudentAttendace(StudentAttendace studentAttendace, int createdBy);
        int UpdateStudentAttendaceWithOutReason(StudentAttendace studentAttendace, int createdBy);
        StudentAttendace GetStudnetAttendanceByStudent(StudentAttendace studentAttendace, int teacherId);
        StudentAttendace GetStudnetAttendanceByStudent(StudentAttendace studentAttendace);
        StudentAttendace GetStudnetAttendanceByStudent(StudentAttendace studentAttendace, int classId,int sectionId, int campusId);
        List<StudentAttendace> GetLateStudentByDate(DateTime fromDate, DateTime toDate);
        List<StudentAttendace> GetUnMarkStudent(int rollTimeStatusId, int statusId);
        

    }
    public class StudentAttendaceDAO : BaseDAO<StudentAttendace>, IStudentAttendaceDAO
    {
        string sp_Add = "ATT_Student_Attendance_Add";
        string sp_Update = "ATT_Student_Attendance_Update";
        string sp_UpdateWithOutReason = "ATT_Student_Attendance_UpdateWithOutReason";
        public StudentAttendaceDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

        public StudentAttendaceDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

        
        public List<StudentAttendace> GetStudentAttendaceById(int classId, int sectionId, int campusId, int roleTimeStatusId)
        {
            StringBuilder query = new StringBuilder();
            #region OldCode
            //            query.Append(@"SELECT     SR_Students.StudentId, SR_Students.FirstName, SR_Students.LastName, SR_Students.SmallPicture,SR_Students.LargePicture, ATT_Student_Attendance.RollTimeStatusId, 
//                      ATT_Student_Attendance.AttendanceStatusId,s.Name S_Name,s.AttendanceSymbol,s.CssClass, ATT_Student_Attendance.StudentAttendanceId,ATT_Student_Attendance.Remarks
//                      ,ATT_Student_Attendance.StartDate,ATT_Student_Attendance.EndDate,ATT_Student_Attendance.Reason,ATT_Student_Attendance.AttendanceDate
//                      FROM         SR_Student_Classes INNER JOIN
//                      SR_Students ON SR_Student_Classes.StudentId = SR_Students.StudentId Left JOIN
//                      ATT_Student_Attendance ON SR_Students.StudentId = ATT_Student_Attendance.StudentId
//                      and CONVERT(VARCHAR, isnull(ATT_Student_Attendance.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
//                      and isnull(ATT_Student_Attendance.RollTimeStatusId," + roleTimeStatusId + ") =" + roleTimeStatusId +
//                    @"Left Join SYS_Attendance_Status s ON ATT_Student_Attendance.AttendanceStatusId = s.AttendanceStatusId 
            //                       Where SR_Student_Classes.ClassId=" + classId + " and SR_Student_Classes.SectionId = " + sectionId);
            #endregion 
            #region  Query
            query.Append(@"SELECT   SR_Students.CampusId,  SR_Students.StudentId, SR_Students.FirstName, SR_Students.LastName, SR_Students.SmallPicture,SR_Students.LargePicture, ATT_Student_Attendance.RollTimeStatusId, 
                      ATT_Student_Attendance.AttendanceStatusId,s.Name S_Name,s.AttendanceSymbol,s.CssClass, ATT_Student_Attendance.StudentAttendanceId,ATT_Student_Attendance.Remarks
                      ,ATT_Student_Attendance.StartDate,ATT_Student_Attendance.EndDate,ATT_Student_Attendance.Reason,ATT_Student_Attendance.AttendanceDate
                      FROM         SR_Student_Classes INNER JOIN
                      SR_Students ON SR_Student_Classes.StudentId = SR_Students.StudentId 
                      INNER JOIN  Config_Terms tm ON  SR_Student_Classes.TermId = tm.TermId 
                      Left JOIN  ATT_Student_Attendance ON SR_Students.StudentId = ATT_Student_Attendance.StudentId
                      and CONVERT(VARCHAR, isnull(ATT_Student_Attendance.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
                      and isnull(ATT_Student_Attendance.RollTimeStatusId," + roleTimeStatusId + ") =" + roleTimeStatusId +
                      @"Left Join SYS_Attendance_Status s ON ATT_Student_Attendance.AttendanceStatusId = s.AttendanceStatusId 
                       Where isnull(SR_Students.IsActive,1) = 1 and SR_Student_Classes.ClassId=" + classId + " and SR_Student_Classes.SectionId = " + sectionId + " and SR_Student_Classes.CampusId = " + campusId);
            query.Append(" AND isnull(SR_Student_Classes.IsActive,1) =  1 ");//new added check 26-05-2012
            query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
            query.Append(" Order by SR_Students.FirstName ;");
            #endregion
           
            List<StudentAttendace> results = new List<StudentAttendace>();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    for (int i = 0; i < tbl.Rows.Count; i++)
                    {
                        StudentAttendace studentAttendace = new StudentAttendace();
                        if (!Convert.IsDBNull(tbl.Rows[i]["StudentAttendanceId"]))
                        {
                            studentAttendace.ID = Convert.ToInt32(tbl.Rows[i]["StudentAttendanceId"]);
                        }
                        studentAttendace.Student = new BusinessEntities.Student.Student();
                        studentAttendace.Student.ID = Convert.ToInt32(tbl.Rows[i]["StudentId"]);
                        studentAttendace.Student.Name = Convert.ToString(tbl.Rows[i]["FirstName"]);
                        studentAttendace.Student.LastName = Convert.ToString(tbl.Rows[i]["LastName"]);
                        studentAttendace.Student.SmallPicture = Convert.ToString(tbl.Rows[i]["SmallPicture"]);
                        studentAttendace.Student.LargePicture = Convert.ToString(tbl.Rows[i]["LargePicture"]);
                        studentAttendace.Remarks = Convert.ToString(tbl.Rows[i]["Remarks"]);

                        studentAttendace.AttendanceStatus = new AttendanceStatus();
                        if (!Convert.IsDBNull(tbl.Rows[i]["AttendanceStatusId"]))
                        {
                            studentAttendace.AttendanceStatus.ID = Convert.ToInt32(tbl.Rows[i]["AttendanceStatusId"]);
                            studentAttendace.AttendanceStatus.Name = Convert.ToString(tbl.Rows[i]["S_Name"]);
                            studentAttendace.AttendanceStatus.AttendanceSymbol = Convert.ToString(tbl.Rows[i]["AttendanceSymbol"]);
                            studentAttendace.AttendanceStatus.CssClass = Convert.ToString(tbl.Rows[i]["CssClass"]);
                            studentAttendace.AttendanceStatus.StatusCssClass = "status " + Convert.ToString(tbl.Rows[i]["CssClass"]);
                        }
                        else
                        {
                            studentAttendace.AttendanceStatus.ID = AttendaceStatus.UnMarked.GetHashCode();
                            studentAttendace.AttendanceStatus.Name = AttendaceStatus.UnMarked.ToString();
                            studentAttendace.AttendanceStatus.AttendanceSymbol = string.Empty;
                            studentAttendace.AttendanceStatus.CssClass = "grey";
                            studentAttendace.AttendanceStatus.StatusCssClass = "status grey";
                        }
                        if (!Convert.IsDBNull(tbl.Rows[i]["RollTimeStatusId"]))
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = Convert.ToInt32(tbl.Rows[i]["RollTimeStatusId"]);
                        }
                        else
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = roleTimeStatusId;
                            
                        }
                        if (tbl.Columns.Contains("StartDate") && !Convert.IsDBNull(tbl.Rows[i]["StartDate"]))
                        {
                            studentAttendace.StartingDate = Convert.ToDateTime(tbl.Rows[i]["StartDate"]);
                        }
                        if (tbl.Columns.Contains("EndDate") && !Convert.IsDBNull(tbl.Rows[i]["EndDate"]))
                        {
                            studentAttendace.EndingDate = Convert.ToDateTime(tbl.Rows[i]["EndDate"]);
                        }
                        if (tbl.Columns.Contains("Reason") && !Convert.IsDBNull(tbl.Rows[i]["Reason"]))
                        {
                            studentAttendace.Reason = Convert.ToString(tbl.Rows[i]["Reason"]);
                        }
                        if (tbl.Columns.Contains("AttendanceDate") && !Convert.IsDBNull(tbl.Rows[i]["AttendanceDate"]))
                        {
                            studentAttendace.AttendanceDate = Convert.ToDateTime(tbl.Rows[i]["AttendanceDate"]);
                            string[] theTime = studentAttendace.AttendanceDate.ToString().Split(' ');

                            studentAttendace.AttendanceTime = theTime[1] +" "+ theTime[2];//studentAttendace.AttendanceDate.ToShortTimeString();
                        }
                        //if (tbl.Columns.Contains("ReasonTitle") && !Convert.IsDBNull(tbl.Rows[i]["ReasonTitle"]))
                        //{
                        //    studentAttendace.ReasonTitle  = "--"+Convert.ToString(tbl.Rows[i]["ReasonTitle"]);
                        //}
                        //else
                        //{
                        //    studentAttendace.AttendanceDate = DateTime.Now;
                        //}

                        results.Add(studentAttendace);
                    }
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }


        public int InsertStudentAttendace(StudentAttendace studentAttendace, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_Student_Id = cmd.CreateParameter();
            p_Student_Id.ParameterName = "p_Student_Id";
            p_Student_Id.DbType = DbType.Int32;
            p_Student_Id.Value = studentAttendace.Student.ID;
            p_Student_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Student_Id);

            DbParameter p_Attendance_Status_Id = cmd.CreateParameter();
            p_Attendance_Status_Id.ParameterName = "p_Attendance_Status_Id";
            p_Attendance_Status_Id.DbType = DbType.Int32;
            p_Attendance_Status_Id.Value = studentAttendace.AttendanceStatus.ID;
            p_Attendance_Status_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Attendance_Status_Id);

            DbParameter p_Remarks = cmd.CreateParameter();
            p_Remarks.ParameterName = "p_Remarks";
            p_Remarks.DbType = DbType.String ;
            if (string.IsNullOrEmpty(studentAttendace.Remarks))
            {
                p_Remarks.Value =DBNull.Value;
            }
            else
            {
                p_Remarks.Value = studentAttendace.Remarks;
            }
            p_Remarks.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Remarks);


            DbParameter p_RollTimeStatusId = cmd.CreateParameter();
            p_RollTimeStatusId.ParameterName = "p_RollTimeStatusId";
            p_RollTimeStatusId.DbType = DbType.Int32;
            p_RollTimeStatusId.Value = studentAttendace.RollTimeAttendaceStatus.ID;
            p_RollTimeStatusId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_RollTimeStatusId);

            DbParameter p_CREATED_BY = cmd.CreateParameter();
            p_CREATED_BY.ParameterName = "p_CREATED_BY";
            p_CREATED_BY.DbType = DbType.Int32;
            p_CREATED_BY.Value = createdBy;
            p_CREATED_BY.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_CREATED_BY);

            DbParameter p_StartDate = cmd.CreateParameter();
            p_StartDate.ParameterName = "p_StartDate";
            p_StartDate.DbType = DbType.DateTime;
            if (studentAttendace.StartingDate.Year ==1)
            {
                p_StartDate.Value = DBNull.Value;
            }
            else
            {
                p_StartDate.Value = studentAttendace.StartingDate;
            }
            p_StartDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StartDate);

            DbParameter p_EndDate = cmd.CreateParameter();
            p_EndDate.ParameterName = "p_EndDate";
            p_EndDate.DbType = DbType.DateTime;
            if (studentAttendace.EndingDate.Year == 1)
            {
                p_EndDate.Value = DBNull.Value;
            }
            else
            {
                p_EndDate.Value = studentAttendace.EndingDate;
            }
            p_EndDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_EndDate);

            DbParameter p_AttendanceDate = cmd.CreateParameter();
            p_AttendanceDate.ParameterName = "p_AttendanceDate";
            p_AttendanceDate.DbType = DbType.DateTime;
            if (studentAttendace.AttendanceDate.Year == 1)
            {
                p_AttendanceDate.Value = DateTime.Now; //DBNull.Value;
            }
            else
            {
                p_AttendanceDate.Value = studentAttendace.AttendanceDate;
            }
            //if (studentAttendace.AttendanceStatus.ID == AttendaceStatus.UnMarked.GetHashCode())
            //{
            //     p_AttendanceDate.Value = DBNull.Value;
            //}
            p_AttendanceDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_AttendanceDate);

            DbParameter p_Reason = cmd.CreateParameter();
            p_Reason.ParameterName = "p_Reason";
            p_Reason.DbType = DbType.String;
            if (string.IsNullOrEmpty(studentAttendace.Reason))
            {
                p_Reason.Value = DBNull.Value;
            }
            else
            {
                p_Reason.Value = studentAttendace.Reason;
            }
            p_Reason.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Reason);

            //DbParameter p_ReasonTitle = cmd.CreateParameter();
            //p_ReasonTitle.ParameterName = "p_ReasonTitle";
            //p_ReasonTitle.DbType = DbType.String;
            //if (string.IsNullOrEmpty(studentAttendace.ReasonTitle))
            //{
            //    p_ReasonTitle.Value = DBNull.Value;
            //}
            //else
            //{
            //    p_ReasonTitle.Value = studentAttendace.ReasonTitle;
            //}
            //p_ReasonTitle.Direction = ParameterDirection.Input;
            //cmd.Parameters.Add(p_ReasonTitle);

            try
            {
                cmd.CommandText = sp_Add;

                object returnValue = cmd.ExecuteScalar();//.ExecuteNonQuery();

                if (returnValue == null)
                    throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }


        public int UpdateStudentAttendace(StudentAttendace studentAttendace, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_StudentAttendanceId = cmd.CreateParameter();
            p_StudentAttendanceId.ParameterName = "p_StudentAttendanceId";
            p_StudentAttendanceId.DbType = DbType.Int32;
            p_StudentAttendanceId.Value = studentAttendace.ID ;
            p_StudentAttendanceId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StudentAttendanceId);

            DbParameter p_LAST_MODIFIED_BY = cmd.CreateParameter();
            p_LAST_MODIFIED_BY.ParameterName = "p_LAST_MODIFIED_BY";
            p_LAST_MODIFIED_BY.DbType = DbType.Int32;
            p_LAST_MODIFIED_BY.Value = createdBy;
            p_LAST_MODIFIED_BY.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_LAST_MODIFIED_BY);

            DbParameter p_Attendance_Status_Id = cmd.CreateParameter();
            p_Attendance_Status_Id.ParameterName = "p_Attendance_Status_Id";
            p_Attendance_Status_Id.DbType = DbType.Int32;
            p_Attendance_Status_Id.Value = studentAttendace.AttendanceStatus.ID;
            p_Attendance_Status_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Attendance_Status_Id);

            DbParameter p_Remarks = cmd.CreateParameter();
            p_Remarks.ParameterName = "p_Remarks";
            p_Remarks.DbType = DbType.String;
            if (string.IsNullOrEmpty(studentAttendace.Remarks))
            {
                p_Remarks.Value = DBNull.Value;
            }
            else
            {
                p_Remarks.Value = studentAttendace.Remarks;
            }
            p_Remarks.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Remarks);

            DbParameter p_StartDate = cmd.CreateParameter();
            p_StartDate.ParameterName = "p_StartDate";
            p_StartDate.DbType = DbType.DateTime;
            if (studentAttendace.StartingDate.Year == 1)
            {
                p_StartDate.Value = DBNull.Value;
            }
            else
            {
                p_StartDate.Value = studentAttendace.StartingDate;
            }
            p_StartDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StartDate);

            DbParameter p_EndDate = cmd.CreateParameter();
            p_EndDate.ParameterName = "p_EndDate";
            p_EndDate.DbType = DbType.DateTime;
            if (studentAttendace.EndingDate.Year == 1)
            {
                p_EndDate.Value = DBNull.Value;
            }
            else
            {
                p_EndDate.Value = studentAttendace.EndingDate;
            }
            p_EndDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_EndDate);

            DbParameter p_AttendanceDate = cmd.CreateParameter();
            p_AttendanceDate.ParameterName = "p_AttendanceDate";
            p_AttendanceDate.DbType = DbType.DateTime;
            if (studentAttendace.AttendanceDate.Year == 1)
            {
                p_AttendanceDate.Value = DateTime.Now;// DBNull.Value;
            }
            else
            {
                p_AttendanceDate.Value = studentAttendace.AttendanceDate;
            }
            p_AttendanceDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_AttendanceDate);

            DbParameter p_Reason = cmd.CreateParameter();
            p_Reason.ParameterName = "p_Reason";
            p_Reason.DbType = DbType.String;
            if (string.IsNullOrEmpty(studentAttendace.Reason))
            {
                p_Reason.Value = DBNull.Value;
            }
            else
            {
                p_Reason.Value = studentAttendace.Reason;
            }
            p_Reason.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Reason);

            //DbParameter p_ReasonTitle = cmd.CreateParameter();
            //p_ReasonTitle.ParameterName = "p_ReasonTitle";
            //p_ReasonTitle.DbType = DbType.String;
            //if (string.IsNullOrEmpty(studentAttendace.ReasonTitle))
            //{
            //    p_ReasonTitle.Value = DBNull.Value;
            //}
            //else
            //{
            //    p_ReasonTitle.Value = studentAttendace.ReasonTitle;
            //}
            //p_ReasonTitle.Direction = ParameterDirection.Input;
            //cmd.Parameters.Add(p_ReasonTitle);

            try
            {
                cmd.CommandText = sp_Update;

                object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                if (returnValue == null)
                    throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }


        public int UpdateStudentAttendaceWithOutReason(StudentAttendace studentAttendace, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_StudentAttendanceId = cmd.CreateParameter();
            p_StudentAttendanceId.ParameterName = "p_StudentAttendanceId";
            p_StudentAttendanceId.DbType = DbType.Int32;
            p_StudentAttendanceId.Value = studentAttendace.ID;
            p_StudentAttendanceId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StudentAttendanceId);

            DbParameter p_LAST_MODIFIED_BY = cmd.CreateParameter();
            p_LAST_MODIFIED_BY.ParameterName = "p_LAST_MODIFIED_BY";
            p_LAST_MODIFIED_BY.DbType = DbType.Int32;
            p_LAST_MODIFIED_BY.Value = createdBy;
            p_LAST_MODIFIED_BY.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_LAST_MODIFIED_BY);

            DbParameter p_Attendance_Status_Id = cmd.CreateParameter();
            p_Attendance_Status_Id.ParameterName = "p_Attendance_Status_Id";
            p_Attendance_Status_Id.DbType = DbType.Int32;
            p_Attendance_Status_Id.Value = studentAttendace.AttendanceStatus.ID;
            p_Attendance_Status_Id.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Attendance_Status_Id);

            DbParameter p_Remarks = cmd.CreateParameter();
            p_Remarks.ParameterName = "p_Remarks";
            p_Remarks.DbType = DbType.String;
            if (string.IsNullOrEmpty(studentAttendace.Remarks))
            {
                p_Remarks.Value = DBNull.Value;
            }
            else
            {
                p_Remarks.Value = studentAttendace.Remarks;
            }
            p_Remarks.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_Remarks);

            DbParameter p_AttendanceDate = cmd.CreateParameter();
            p_AttendanceDate.ParameterName = "p_AttendanceDate";
            p_AttendanceDate.DbType = DbType.DateTime;
            if (studentAttendace.AttendanceDate.Year == 1)
            {
                p_AttendanceDate.Value = DBNull.Value;
            }
            else
            {
                p_AttendanceDate.Value = studentAttendace.AttendanceDate;
            }
            p_AttendanceDate.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_AttendanceDate);

            try
            {
                cmd.CommandText = sp_UpdateWithOutReason;

                object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                if (returnValue == null)
                    throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }


        public List<StudentAttendace> GetStudentAttendaceById(int classId, int sectionId, int campusId, int roleTimeStatusId, DateTime selectedDate, int loginId)
        {
            StringBuilder query = new StringBuilder();

            #region old  Query
//            query.Append(@"SELECT  SR_Students.StudentId, SR_Students.FirstName, SR_Students.LastName, SR_Students.SmallPicture,SR_Students.LargePicture, ATT_Student_Attendance.RollTimeStatusId, 
//                      ATT_Student_Attendance.AttendanceStatusId,s.Name S_Name,s.AttendanceSymbol,s.CssClass, ATT_Student_Attendance.StudentAttendanceId,ATT_Student_Attendance.Remarks,ATT_Student_Attendance.ReasonTitle
//                      ,ATT_Student_Attendance.StartDate,ATT_Student_Attendance.EndDate,ATT_Student_Attendance.Reason,ATT_Student_Attendance.AttendanceDate
//                      FROM  SR_Student_Classes INNER JOIN
//                      SR_Students ON SR_Student_Classes.StudentId = SR_Students.StudentId
//                      INNER Join TR_ClassTeachers ct
//                      ON ct.ClassId =SR_Student_Classes.ClassId and ct.SectionId = SR_Student_Classes.SectionId 
//                      INNER JOIN  ATT_Student_Attendance
//                      ON SR_Students.StudentId = ATT_Student_Attendance.StudentId                     
//                      INNER Join SYS_Attendance_Status s 
//                      ON ATT_Student_Attendance.AttendanceStatusId = s.AttendanceStatusId 
//                      Where SR_Student_Classes.ClassId=1 and SR_Student_Classes.SectionId ="+ sectionId +" And CONVERT(VARCHAR, ATT_Student_Attendance.AttendanceDate, 111) = CONVERT(VARCHAR, "+ selectedDate +@", 111)
//                      AND ct.TeacherId = " + loginId + " AND ATT_Student_Attendance.RollTimeStatusId = " + roleTimeStatusId);
            #endregion
          
            #region  Query
            query.Append(@"SELECT     SR_Students.StudentId, SR_Students.FirstName, SR_Students.LastName, SR_Students.SmallPicture,SR_Students.LargePicture, ATT_Student_Attendance.RollTimeStatusId, 
                      ATT_Student_Attendance.AttendanceStatusId,s.Name S_Name,s.AttendanceSymbol,s.CssClass, ATT_Student_Attendance.StudentAttendanceId,ATT_Student_Attendance.Remarks
                      ,ATT_Student_Attendance.StartDate,ATT_Student_Attendance.EndDate,ATT_Student_Attendance.Reason,ATT_Student_Attendance.AttendanceDate
                      FROM         SR_Student_Classes INNER JOIN
                      SR_Students ON SR_Student_Classes.StudentId = SR_Students.StudentId
                      INNER JOIN  Config_Terms tm ON  SR_Student_Classes.TermId = tm.TermId 
                      INNER Join TR_ClassTeachers ct
                      ON ct.ClassId =SR_Student_Classes.ClassId and ct.SectionId = SR_Student_Classes.SectionId AND ct.TeacherId = " + loginId +
                      @"Left JOIN  ATT_Student_Attendance ON SR_Students.StudentId = ATT_Student_Attendance.StudentId
                      and CONVERT(VARCHAR, isnull(ATT_Student_Attendance.AttendanceDate,'" + (selectedDate.ToString("yyyy/MM/dd")) + "' ), 103) = '" + selectedDate.Date.ToString("dd/MM/yyyy") +
                      @"' and isnull(ATT_Student_Attendance.RollTimeStatusId," + roleTimeStatusId + ") = " + roleTimeStatusId + @" Left Join SYS_Attendance_Status s ON ATT_Student_Attendance.AttendanceStatusId = s.AttendanceStatusId 
                       Where isnull(SR_Students.IsActive,1) = 1  AND SR_Student_Classes.ClassId=" + classId + " and SR_Student_Classes.SectionId = " + sectionId + " and SR_Student_Classes.CampusId = " + campusId);
            query.Append(" AND isnull(SR_Student_Classes.IsActive,1) =  1 ");//new added check 26-05-2012
            query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
            query.Append(" Order by SR_Students.FirstName ;");
            #endregion
           
            List<StudentAttendace> results = new List<StudentAttendace>();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    for (int i = 0; i < tbl.Rows.Count; i++)
                    {
                        StudentAttendace studentAttendace = new StudentAttendace();
                        if (!Convert.IsDBNull(tbl.Rows[i]["StudentAttendanceId"]))
                        {
                            studentAttendace.ID = Convert.ToInt32(tbl.Rows[i]["StudentAttendanceId"]);
                        }
                        studentAttendace.Student = new BusinessEntities.Student.Student();
                        studentAttendace.Student.ID = Convert.ToInt32(tbl.Rows[i]["StudentId"]);
                        studentAttendace.Student.Name = Convert.ToString(tbl.Rows[i]["FirstName"]);
                        studentAttendace.Student.LastName = Convert.ToString(tbl.Rows[i]["LastName"]);
                        studentAttendace.Student.SmallPicture = Convert.ToString(tbl.Rows[i]["SmallPicture"]);
                        studentAttendace.Student.LargePicture = Convert.ToString(tbl.Rows[i]["LargePicture"]);
                        studentAttendace.Remarks = Convert.ToString(tbl.Rows[i]["Remarks"]);

                        studentAttendace.AttendanceStatus = new AttendanceStatus();
                        if (!Convert.IsDBNull(tbl.Rows[i]["AttendanceStatusId"]))
                        {
                            studentAttendace.AttendanceStatus.ID = Convert.ToInt32(tbl.Rows[i]["AttendanceStatusId"]);
                            studentAttendace.AttendanceStatus.Name = Convert.ToString(tbl.Rows[i]["S_Name"]);
                            studentAttendace.AttendanceStatus.AttendanceSymbol = Convert.ToString(tbl.Rows[i]["AttendanceSymbol"]);
                            studentAttendace.AttendanceStatus.CssClass = Convert.ToString(tbl.Rows[i]["CssClass"]);
                            studentAttendace.AttendanceStatus.StatusCssClass = "status " + Convert.ToString(tbl.Rows[i]["CssClass"]);
                        }
                        else
                        {
                            studentAttendace.AttendanceStatus.ID = AttendaceStatus.UnMarked.GetHashCode();
                            studentAttendace.AttendanceStatus.Name = AttendaceStatus.UnMarked.ToString();
                            studentAttendace.AttendanceStatus.AttendanceSymbol = string.Empty;
                            studentAttendace.AttendanceStatus.CssClass = "grey";
                            studentAttendace.AttendanceStatus.StatusCssClass = "status grey";
                        }
                        if (!Convert.IsDBNull(tbl.Rows[i]["RollTimeStatusId"]))
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = Convert.ToInt32(tbl.Rows[i]["RollTimeStatusId"]);
                        }
                        else
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = roleTimeStatusId;

                        }
                        if (tbl.Columns.Contains("StartDate") && !Convert.IsDBNull(tbl.Rows[i]["StartDate"]))
                        {
                            studentAttendace.StartingDate = Convert.ToDateTime(tbl.Rows[i]["StartDate"]);
                        }
                        if (tbl.Columns.Contains("EndDate") && !Convert.IsDBNull(tbl.Rows[i]["EndDate"]))
                        {
                            studentAttendace.EndingDate = Convert.ToDateTime(tbl.Rows[i]["EndDate"]);
                        }
                        if (tbl.Columns.Contains("Reason") && !Convert.IsDBNull(tbl.Rows[i]["Reason"]))
                        {
                            studentAttendace.Reason = Convert.ToString(tbl.Rows[i]["Reason"]);
                        }
                        if (tbl.Columns.Contains("AttendanceDate") && !Convert.IsDBNull(tbl.Rows[i]["AttendanceDate"]))
                        {
                            studentAttendace.AttendanceDate = Convert.ToDateTime(tbl.Rows[i]["AttendanceDate"]);
                            string[] theTime = studentAttendace.AttendanceDate.ToString().Split(' ');

                            studentAttendace.AttendanceTime = theTime[1] + " " + theTime[2];//studentAttendace.AttendanceDate.ToShortTimeString();
                        }
                        //if (tbl.Columns.Contains("ReasonTitle") && !Convert.IsDBNull(tbl.Rows[i]["ReasonTitle"]))
                        //{
                        //    studentAttendace.ReasonTitle = "--" + Convert.ToString(tbl.Rows[i]["ReasonTitle"]);
                        //}
                        //else
                        //{
                        //    studentAttendace.AttendanceDate = DateTime.Now;
                        //}

                        results.Add(studentAttendace);
                    }
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }
        public StudentAttendace GetStudnetAttendanceByStudent(StudentAttendace studentAttendace, int teacherId)
        {
            StringBuilder query = new StringBuilder();

//            #region Old Query
//            query.Append(@"SELECT     Att.StudentAttendanceId, Att.StudentId, Att.RollTimeStatusId, Att.AttendanceDate,Att.VERSION_NUMBER
//                            FROM         ATT_Student_Attendance Att
//                            INNER Join SR_Student_Classes SC
//                            ON  Att.StudentId= SC.StudentId
//                            INNER JOIN TR_ClassTeachers CT
//                            ON SC.ClassId = CT.ClassId AND SC.SectionId = CT.SectionId 
//                            WHERE   CT.TeacherId=" + teacherId + " AND (Att.StudentId = " + studentAttendace.Student.ID + ") AND (Att.RollTimeStatusId = " + studentAttendace.RollTimeAttendaceStatus.ID + ") AND (CONVERT(VARCHAR,Att.AttendanceDate , 111) = '" + studentAttendace.AttendanceDate.ToString("yyyy/MM/dd") + "')");
//            #endregion
            #region Old Query
            query.Append(@"SELECT     Att.StudentAttendanceId, Att.StudentId, Att.RollTimeStatusId, Att.AttendanceDate,Att.VERSION_NUMBER
                            FROM  ATT_Student_Attendance Att
                            INNER Join SR_Student_Classes SC
                            ON  Att.StudentId= SC.StudentId                            
                            WHERE   (Att.StudentId = " + studentAttendace.Student.ID + ") AND (Att.RollTimeStatusId = " + studentAttendace.RollTimeAttendaceStatus.ID + ") AND (CONVERT(VARCHAR,Att.AttendanceDate , 111) = '" + studentAttendace.AttendanceDate.ToString("yyyy/MM/dd") + "')");
           // query.Append("  AND SC.ClassId"+studentAttendace.c
            #endregion

            StudentAttendace studentAttendance = new StudentAttendace();

            try
            {
                System.Data.DataSet set = FindMetaDataWithTransaction(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {

                    studentAttendance = new StudentAttendace();
                    if (!Convert.IsDBNull(tbl.Rows[0]["StudentAttendanceId"]))
                    {
                        studentAttendance.ID = Convert.ToInt32(tbl.Rows[0]["StudentAttendanceId"]);
                    }
                    return studentAttendance;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return studentAttendance;
        }
        public StudentAttendace GetStudnetAttendanceByStudent(StudentAttendace studentAttendace, int classId, int sectionId, int campusId)
        {
            StringBuilder query = new StringBuilder();
            #region Old Query
            query.Append(@"SELECT     Att.StudentAttendanceId, Att.StudentId, Att.RollTimeStatusId, Att.AttendanceDate,Att.VERSION_NUMBER,u.RoleId,Att.AttendanceStatusId  
                            FROM         ATT_Student_Attendance Att
                            INNER Join SR_Student_Classes SC
                            ON  Att.StudentId= SC.StudentId 
                            Inner join UMS_Users u
                            on u.LoginUserId = isnull(Att.LAST_MODIFIED_BY,Att.CREATED_BY)                            
                            WHERE   (Att.StudentId = " + studentAttendace.Student.ID + ") AND (Att.RollTimeStatusId = " + studentAttendace.RollTimeAttendaceStatus.ID + ") AND (CONVERT(VARCHAR,Att.AttendanceDate , 111) = '" + studentAttendace.AttendanceDate.ToString("yyyy/MM/dd") + "')");
            query.Append("  AND SC.ClassId = " + classId);
            query.Append("  AND SC.SectionId = " + sectionId);
            query.Append("  AND SC.CampusId = " + campusId);
            query.Append("  AND isnull(SC.IsActive,1) =  1 ");
            #endregion

            StudentAttendace stdAttendance = null;

            try
            {
                System.Data.DataSet set = FindMetaDataWithTransaction(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {

                    stdAttendance = new StudentAttendace();
                    stdAttendance.UserRole = new BusinessEntities.UserManagement.Role();
                    if (!Convert.IsDBNull(tbl.Rows[0]["StudentAttendanceId"]))
                    {
                        stdAttendance.ID = Convert.ToInt32(tbl.Rows[0]["StudentAttendanceId"]);
                        stdAttendance.UserRole.ID = Convert.ToInt32(tbl.Rows[0]["RoleId"]);
                        stdAttendance.AttendanceStatus = new AttendanceStatus();
                        stdAttendance.AttendanceStatus.ID = Convert.ToInt32(tbl.Rows[0]["AttendanceStatusId"]);
                    }
                    return stdAttendance;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return stdAttendance;
        }
        public StudentAttendace GetStudnetAttendanceByStudent(StudentAttendace studentAttendace)
        {
            StringBuilder query = new StringBuilder();

            #region  Query
            query.Append(@"SELECT     Att.StudentAttendanceId, Att.StudentId, Att.RollTimeStatusId, Att.AttendanceDate,Att.VERSION_NUMBER
                            FROM         ATT_Student_Attendance Att                           
                            WHERE   (Att.StudentId = " + studentAttendace.Student.ID + ") AND (Att.RollTimeStatusId = " + studentAttendace.RollTimeAttendaceStatus.ID + ") AND (CONVERT(VARCHAR,Att.AttendanceDate , 111) = '" + studentAttendace.AttendanceDate.ToString("yyyy/MM/dd") + "')");
            #endregion

            StudentAttendace studentAttendance = new StudentAttendace();

            try
            {
                System.Data.DataSet set = FindMetaDataWithTransaction(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {

                    studentAttendance = new StudentAttendace();
                    if (!Convert.IsDBNull(tbl.Rows[0]["StudentAttendanceId"]))
                    {
                        studentAttendance.ID = Convert.ToInt32(tbl.Rows[0]["StudentAttendanceId"]);
                    }
                    return studentAttendance;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return studentAttendance;
        }


        public List<StudentAttendace> GetStudentAttendaceLateCount(int classId, int sectionId, int campusId, int roleTimeStatusId)
        {
            StringBuilder query = new StringBuilder();
            #region OldCode
            //            query.Append(@"SELECT     SR_Students.StudentId, SR_Students.FirstName, SR_Students.LastName, SR_Students.SmallPicture,SR_Students.LargePicture, ATT_Student_Attendance.RollTimeStatusId, 
            //                      ATT_Student_Attendance.AttendanceStatusId,s.Name S_Name,s.AttendanceSymbol,s.CssClass, ATT_Student_Attendance.StudentAttendanceId,ATT_Student_Attendance.Remarks
            //                      ,ATT_Student_Attendance.StartDate,ATT_Student_Attendance.EndDate,ATT_Student_Attendance.Reason,ATT_Student_Attendance.AttendanceDate
            //                      FROM         SR_Student_Classes INNER JOIN
            //                      SR_Students ON SR_Student_Classes.StudentId = SR_Students.StudentId Left JOIN
            //                      ATT_Student_Attendance ON SR_Students.StudentId = ATT_Student_Attendance.StudentId
            //                      and CONVERT(VARCHAR, isnull(ATT_Student_Attendance.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
            //                      and isnull(ATT_Student_Attendance.RollTimeStatusId," + roleTimeStatusId + ") =" + roleTimeStatusId +
            //                    @"Left Join SYS_Attendance_Status s ON ATT_Student_Attendance.AttendanceStatusId = s.AttendanceStatusId 
            //                       Where SR_Student_Classes.ClassId=" + classId + " and SR_Student_Classes.SectionId = " + sectionId);
            #endregion
            #region  Query
            query.Append(@"SELECT  SR_Student_Classes.CampusId,   SR_Students.StudentId, SR_Students.FirstName, SR_Students.LastName, SR_Students.SmallPicture,SR_Students.LargePicture, ATT_Student_Attendance.RollTimeStatusId, 
                      ATT_Student_Attendance.AttendanceStatusId,s.Name S_Name,s.AttendanceSymbol,s.CssClass, ATT_Student_Attendance.StudentAttendanceId,ATT_Student_Attendance.Remarks
                      ,ATT_Student_Attendance.StartDate,ATT_Student_Attendance.EndDate,ATT_Student_Attendance.Reason,ATT_Student_Attendance.AttendanceDate,tm.TermNo
                      ,(Select ISNULL(TotalLate,0)  from LateCount(4,SR_Students.StudentId,tm.TermId )) TLate 
                      ,(Select ISNULL(TotalLate,0)  from AbsentCount(SR_Students.StudentId,tm.TermId )) TAbsent
                      ,(Select ISNULL(TotalLate,0)  from YearlyLateCount(4,SR_Students.StudentId,{ fn NOW() } )) TYearlyLate 
                      ,(Select ISNULL(TotalAbsent,0)  from YearlyAbsentCount(SR_Students.StudentId,{ fn NOW() } )) TYearlyAbsent
                      FROM         SR_Student_Classes INNER JOIN
                      SR_Students ON SR_Student_Classes.StudentId = SR_Students.StudentId 
                      INNER JOIN  Config_Terms tm ON  SR_Student_Classes.TermId = tm.TermId 
                      Left JOIN  ATT_Student_Attendance ON SR_Students.StudentId = ATT_Student_Attendance.StudentId
                      and CONVERT(VARCHAR, isnull(ATT_Student_Attendance.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
                      and isnull(ATT_Student_Attendance.RollTimeStatusId," + roleTimeStatusId + ") =" + roleTimeStatusId +
                      @"Left Join SYS_Attendance_Status s ON ATT_Student_Attendance.AttendanceStatusId = s.AttendanceStatusId 
                       Where isnull(SR_Students.IsActive,1) = 1 And SR_Student_Classes.ClassId=" + classId + " and SR_Student_Classes.SectionId = " + sectionId + " and SR_Student_Classes.CampusId = " + campusId);
            query.Append(" AND isnull(SR_Student_Classes.IsActive,1) =  1 ");
            query.Append(" AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
            query.Append(" Order by SR_Students.FirstName ;");
            #endregion

            List<StudentAttendace> results = new List<StudentAttendace>();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    for (int i = 0; i < tbl.Rows.Count; i++)
                    {
                        StudentAttendace studentAttendace = new StudentAttendace();
                        if (!Convert.IsDBNull(tbl.Rows[i]["StudentAttendanceId"]))
                        {
                            studentAttendace.ID = Convert.ToInt32(tbl.Rows[i]["StudentAttendanceId"]);
                        }
                        studentAttendace.Student = new BusinessEntities.Student.Student();
                        studentAttendace.Student.ID = Convert.ToInt32(tbl.Rows[i]["StudentId"]);
                        studentAttendace.Student.Name = Convert.ToString(tbl.Rows[i]["FirstName"]);
                        studentAttendace.Student.LastName = Convert.ToString(tbl.Rows[i]["LastName"]);
                        studentAttendace.Student.SmallPicture = Convert.ToString(tbl.Rows[i]["SmallPicture"]);
                        studentAttendace.Student.LargePicture = Convert.ToString(tbl.Rows[i]["LargePicture"]);
                        studentAttendace.Remarks = Convert.ToString(tbl.Rows[i]["Remarks"]);

                        studentAttendace.AttendanceStatus = new AttendanceStatus();
                        if (!Convert.IsDBNull(tbl.Rows[i]["AttendanceStatusId"]))
                        {
                            studentAttendace.AttendanceStatus.ID = Convert.ToInt32(tbl.Rows[i]["AttendanceStatusId"]);
                            studentAttendace.AttendanceStatus.Name = Convert.ToString(tbl.Rows[i]["S_Name"]);
                            studentAttendace.AttendanceStatus.AttendanceSymbol = Convert.ToString(tbl.Rows[i]["AttendanceSymbol"]);
                            studentAttendace.AttendanceStatus.CssClass = Convert.ToString(tbl.Rows[i]["CssClass"]);
                            studentAttendace.AttendanceStatus.StatusCssClass = "status " + Convert.ToString(tbl.Rows[i]["CssClass"]);
                        }
                        else
                        {
                            studentAttendace.AttendanceStatus.ID = AttendaceStatus.UnMarked.GetHashCode();
                            studentAttendace.AttendanceStatus.Name = AttendaceStatus.UnMarked.ToString();
                            studentAttendace.AttendanceStatus.AttendanceSymbol = string.Empty;
                            studentAttendace.AttendanceStatus.CssClass = "grey";
                            studentAttendace.AttendanceStatus.StatusCssClass = "status grey";
                        }
                        if (!Convert.IsDBNull(tbl.Rows[i]["RollTimeStatusId"]))
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = Convert.ToInt32(tbl.Rows[i]["RollTimeStatusId"]);
                        }
                        else
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = roleTimeStatusId;

                        }
                        if (tbl.Columns.Contains("StartDate") && !Convert.IsDBNull(tbl.Rows[i]["StartDate"]))
                        {
                            studentAttendace.StartingDate = Convert.ToDateTime(tbl.Rows[i]["StartDate"]);
                        }
                        if (tbl.Columns.Contains("EndDate") && !Convert.IsDBNull(tbl.Rows[i]["EndDate"]))
                        {
                            studentAttendace.EndingDate = Convert.ToDateTime(tbl.Rows[i]["EndDate"]);
                        }
                        if (tbl.Columns.Contains("Reason") && !Convert.IsDBNull(tbl.Rows[i]["Reason"]))
                        {
                            studentAttendace.Reason = Convert.ToString(tbl.Rows[i]["Reason"]);
                        }
                        if (tbl.Columns.Contains("AttendanceDate") && !Convert.IsDBNull(tbl.Rows[i]["AttendanceDate"]))
                        {
                            studentAttendace.AttendanceDate = Convert.ToDateTime(tbl.Rows[i]["AttendanceDate"]);
                            string[] theTime = studentAttendace.AttendanceDate.ToString().Split(' ');

                            studentAttendace.AttendanceTime = theTime[1] + " " + theTime[2];//studentAttendace.AttendanceDate.ToShortTimeString();
                        }

                        if (tbl.Columns.Contains("TermNo") && !Convert.IsDBNull(tbl.Rows[i]["TermNo"]))
                        {
                            studentAttendace.Term = new BusinessEntities.Configuration.Term();
                            studentAttendace.Term.TermNo = Convert.ToString(tbl.Rows[i]["TermNo"]);
                        }
                        if (tbl.Columns.Contains("TLate") && !Convert.IsDBNull(tbl.Rows[i]["TLate"]))
                        {
                            studentAttendace.TotalLateInTerm  = Convert.ToInt32 (tbl.Rows[i]["TLate"]);
                        }
                        if (tbl.Columns.Contains("TAbsent") && !Convert.IsDBNull(tbl.Rows[i]["TAbsent"]))
                        {
                            studentAttendace.TotalAbsentsInTerm  = Convert.ToInt32(tbl.Rows[i]["TAbsent"]);
                        }
                        if (tbl.Columns.Contains("TYearlyLate") && !Convert.IsDBNull(tbl.Rows[i]["TYearlyLate"]))
                        {
                            studentAttendace.TotalYearlyLate  = Convert.ToInt32(tbl.Rows[i]["TYearlyLate"]);
                        }
                        if (tbl.Columns.Contains("TYearlyAbsent") && !Convert.IsDBNull(tbl.Rows[i]["TYearlyAbsent"]))
                        {
                            studentAttendace.TolatYearlyAbsent  = Convert.ToInt32(tbl.Rows[i]["TYearlyAbsent"]);
                        }
                        //if (tbl.Columns.Contains("ReasonTitle") && !Convert.IsDBNull(tbl.Rows[i]["ReasonTitle"]))
                        //{
                        //    studentAttendace.ReasonTitle  = "--"+Convert.ToString(tbl.Rows[i]["ReasonTitle"]);
                        //}
                        //else
                        //{
                        //    studentAttendace.AttendanceDate = DateTime.Now;
                        //}

                        results.Add(studentAttendace);
                    }
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }
        public List<StudentAttendace> GetStudentAttendaceLateCount(int classId, int sectionId, int roleTimeStatusId,DateTime selectedDate)
        {
            StringBuilder query = new StringBuilder();
           
            #region  Query
            query.Append(@"SELECT     SR_Students.StudentId, SR_Students.FirstName, SR_Students.LastName, SR_Students.SmallPicture,SR_Students.LargePicture, ATT_Student_Attendance.RollTimeStatusId, 
                      ATT_Student_Attendance.AttendanceStatusId,s.Name S_Name,s.AttendanceSymbol,s.CssClass, ATT_Student_Attendance.StudentAttendanceId,ATT_Student_Attendance.Remarks
                      ,ATT_Student_Attendance.StartDate,ATT_Student_Attendance.EndDate,ATT_Student_Attendance.Reason,ATT_Student_Attendance.AttendanceDate,tm.TermNo
                      ,(Select ISNULL(TotalLate,0)  from LateCount(4,SR_Students.StudentId,tm.TermId )) TLate 
                      ,(Select ISNULL(TotalLate,0)  from AbsentCount(SR_Students.StudentId,tm.TermId )) TAbsent
                      ,(Select ISNULL(TotalLate,0)  from YearlyLateCount(4,SR_Students.StudentId,"+ selectedDate + @" )) TYearlyLate 
                      ,(Select ISNULL(TotalAbsent,0)  from YearlyAbsentCount(SR_Students.StudentId," + selectedDate + @" )) TYearlyAbsent
                      FROM         SR_Student_Classes INNER JOIN
                      SR_Students ON SR_Student_Classes.StudentId = SR_Students.StudentId 
                      INNER JOIN  Config_Terms tm ON  SR_Student_Classes.TermId = tm.TermId 
                      Left JOIN  ATT_Student_Attendance ON SR_Students.StudentId = ATT_Student_Attendance.StudentId
                      and CONVERT(VARCHAR, isnull(ATT_Student_Attendance.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
                      and isnull(ATT_Student_Attendance.RollTimeStatusId," + roleTimeStatusId + ") =" + roleTimeStatusId +
                      @"Left Join SYS_Attendance_Status s ON ATT_Student_Attendance.AttendanceStatusId = s.AttendanceStatusId 
                       Where isnull(SR_Students.IsActive,1) = 1 And SR_Student_Classes.ClassId=" + classId + " and SR_Student_Classes.SectionId = " + sectionId);
            query.Append(" AND isnull(SR_Student_Classes.IsActive,1) =  1 ");
            query.Append(" AND ( tm.StartingDate <= " + selectedDate.ToString("yyyy/MM/dd") + " AND  " + selectedDate.ToString("yyyy/MM/dd") + " <= tm.EndingDate )");
            query.Append(" Order by SR_Students.FirstName ;");
            #endregion

            List<StudentAttendace> results = new List<StudentAttendace>();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    for (int i = 0; i < tbl.Rows.Count; i++)
                    {
                        StudentAttendace studentAttendace = new StudentAttendace();
                        if (!Convert.IsDBNull(tbl.Rows[i]["StudentAttendanceId"]))
                        {
                            studentAttendace.ID = Convert.ToInt32(tbl.Rows[i]["StudentAttendanceId"]);
                        }
                        studentAttendace.Student = new BusinessEntities.Student.Student();
                        studentAttendace.Student.ID = Convert.ToInt32(tbl.Rows[i]["StudentId"]);
                        studentAttendace.Student.Name = Convert.ToString(tbl.Rows[i]["FirstName"]);
                        studentAttendace.Student.LastName = Convert.ToString(tbl.Rows[i]["LastName"]);
                        studentAttendace.Student.SmallPicture = Convert.ToString(tbl.Rows[i]["SmallPicture"]);
                        studentAttendace.Student.LargePicture = Convert.ToString(tbl.Rows[i]["LargePicture"]);
                        studentAttendace.Remarks = Convert.ToString(tbl.Rows[i]["Remarks"]);

                        studentAttendace.AttendanceStatus = new AttendanceStatus();
                        if (!Convert.IsDBNull(tbl.Rows[i]["AttendanceStatusId"]))
                        {
                            studentAttendace.AttendanceStatus.ID = Convert.ToInt32(tbl.Rows[i]["AttendanceStatusId"]);
                            studentAttendace.AttendanceStatus.Name = Convert.ToString(tbl.Rows[i]["S_Name"]);
                            studentAttendace.AttendanceStatus.AttendanceSymbol = Convert.ToString(tbl.Rows[i]["AttendanceSymbol"]);
                            studentAttendace.AttendanceStatus.CssClass = Convert.ToString(tbl.Rows[i]["CssClass"]);
                            studentAttendace.AttendanceStatus.StatusCssClass = "status " + Convert.ToString(tbl.Rows[i]["CssClass"]);
                        }
                        else
                        {
                            studentAttendace.AttendanceStatus.ID = AttendaceStatus.UnMarked.GetHashCode();
                            studentAttendace.AttendanceStatus.Name = AttendaceStatus.UnMarked.ToString();
                            studentAttendace.AttendanceStatus.AttendanceSymbol = string.Empty;
                            studentAttendace.AttendanceStatus.CssClass = "grey";
                            studentAttendace.AttendanceStatus.StatusCssClass = "status grey";
                        }
                        if (!Convert.IsDBNull(tbl.Rows[i]["RollTimeStatusId"]))
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = Convert.ToInt32(tbl.Rows[i]["RollTimeStatusId"]);
                        }
                        else
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = roleTimeStatusId;

                        }
                        if (tbl.Columns.Contains("StartDate") && !Convert.IsDBNull(tbl.Rows[i]["StartDate"]))
                        {
                            studentAttendace.StartingDate = Convert.ToDateTime(tbl.Rows[i]["StartDate"]);
                        }
                        if (tbl.Columns.Contains("EndDate") && !Convert.IsDBNull(tbl.Rows[i]["EndDate"]))
                        {
                            studentAttendace.EndingDate = Convert.ToDateTime(tbl.Rows[i]["EndDate"]);
                        }
                        if (tbl.Columns.Contains("Reason") && !Convert.IsDBNull(tbl.Rows[i]["Reason"]))
                        {
                            studentAttendace.Reason = Convert.ToString(tbl.Rows[i]["Reason"]);
                        }
                        if (tbl.Columns.Contains("AttendanceDate") && !Convert.IsDBNull(tbl.Rows[i]["AttendanceDate"]))
                        {
                            studentAttendace.AttendanceDate = Convert.ToDateTime(tbl.Rows[i]["AttendanceDate"]);
                            string[] theTime = studentAttendace.AttendanceDate.ToString().Split(' ');

                            studentAttendace.AttendanceTime = theTime[1] + " " + theTime[2];//studentAttendace.AttendanceDate.ToShortTimeString();
                        }

                        if (tbl.Columns.Contains("TermNo") && !Convert.IsDBNull(tbl.Rows[i]["TermNo"]))
                        {
                            studentAttendace.Term = new BusinessEntities.Configuration.Term();
                            studentAttendace.Term.TermNo = Convert.ToString(tbl.Rows[i]["TermNo"]);
                        }
                        if (tbl.Columns.Contains("TLate") && !Convert.IsDBNull(tbl.Rows[i]["TLate"]))
                        {
                            studentAttendace.TotalLateInTerm = Convert.ToInt32(tbl.Rows[i]["TLate"]);
                        }
                        if (tbl.Columns.Contains("TAbsent") && !Convert.IsDBNull(tbl.Rows[i]["TAbsent"]))
                        {
                            studentAttendace.TotalAbsentsInTerm = Convert.ToInt32(tbl.Rows[i]["TAbsent"]);
                        }
                        if (tbl.Columns.Contains("TYearlyLate") && !Convert.IsDBNull(tbl.Rows[i]["TYearlyLate"]))
                        {
                            studentAttendace.TotalYearlyLate = Convert.ToInt32(tbl.Rows[i]["TYearlyLate"]);
                        }
                        if (tbl.Columns.Contains("TYearlyAbsent") && !Convert.IsDBNull(tbl.Rows[i]["TYearlyAbsent"]))
                        {
                            studentAttendace.TolatYearlyAbsent = Convert.ToInt32(tbl.Rows[i]["TYearlyAbsent"]);
                        }
                        //if (tbl.Columns.Contains("ReasonTitle") && !Convert.IsDBNull(tbl.Rows[i]["ReasonTitle"]))
                        //{
                        //    studentAttendace.ReasonTitle  = "--"+Convert.ToString(tbl.Rows[i]["ReasonTitle"]);
                        //}
                        //else
                        //{
                        //    studentAttendace.AttendanceDate = DateTime.Now;
                        //}

                        results.Add(studentAttendace);
                    }
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }


        public List<StudentAttendace> GetStudentAttendaceLateCountByDate(int classId, int sectionId, int campusId, int roleTimeStatusId, DateTime selectedDate, int loginId)
        {
            StringBuilder query = new StringBuilder();

            #region  Query
            query.Append(@"SELECT     SR_Students.StudentId, SR_Students.FirstName, SR_Students.LastName, SR_Students.SmallPicture,SR_Students.LargePicture, ATT_Student_Attendance.RollTimeStatusId, 
                                  ATT_Student_Attendance.AttendanceStatusId,s.Name S_Name,s.AttendanceSymbol,s.CssClass, ATT_Student_Attendance.StudentAttendanceId,ATT_Student_Attendance.Remarks
                                  ,ATT_Student_Attendance.StartDate,ATT_Student_Attendance.EndDate,ATT_Student_Attendance.Reason,ATT_Student_Attendance.AttendanceDate
                                  ,tm.TermNo
                                  ,(Select ISNULL(TotalLate,0)  from LateCount(4,SR_Students.StudentId,tm.TermId )) TLate 
                                  ,(Select ISNULL(TotalLate,0)  from AbsentCount(SR_Students.StudentId,tm.TermId )) TAbsent
                                  ,(Select ISNULL(TotalLate,0)  from YearlyLateCount(4,SR_Students.StudentId,ATT_Student_Attendance.AttendanceDate )) TYearlyLate 
                                  ,(Select ISNULL(TotalAbsent,0)  from YearlyAbsentCount(SR_Students.StudentId,ATT_Student_Attendance.AttendanceDate )) TYearlyAbsent
                                  FROM         SR_Student_Classes INNER JOIN
                                  SR_Students ON SR_Student_Classes.StudentId = SR_Students.StudentId
                                  INNER JOIN  Config_Terms tm ON  SR_Student_Classes.TermId = tm.TermNo 
                                  INNER Join TR_ClassTeachers ct
                                  ON ct.ClassId =SR_Student_Classes.ClassId and ct.SectionId = SR_Student_Classes.SectionId AND ct.TeacherId = " + loginId +
                      @"Left JOIN  ATT_Student_Attendance ON SR_Students.StudentId = ATT_Student_Attendance.StudentId
                                  and CONVERT(VARCHAR, isnull(ATT_Student_Attendance.AttendanceDate,'" + (selectedDate.ToString("yyyy/MM/dd")) + "' ), 103) = '" + selectedDate.Date.ToString("dd/MM/yyyy") +
                      @"' and isnull(ATT_Student_Attendance.RollTimeStatusId," + roleTimeStatusId + ") = " + roleTimeStatusId + @" Left Join SYS_Attendance_Status s ON ATT_Student_Attendance.AttendanceStatusId = s.AttendanceStatusId 
                                   Where  isnull(SR_Students.IsActive,1) = 1 And SR_Student_Classes.ClassId=" + classId + " and SR_Student_Classes.SectionId = " + sectionId + " and SR_Students.CampusId = " + campusId);
            query.Append(" AND isnull(SR_Student_Classes.IsActive,1) =  1 ");
            query.Append("AND ( tm.StartingDate <= '" + selectedDate.Date.ToString("yyyy/MM/dd") + "' AND '" + selectedDate.Date.ToString("yyyy/MM/dd") + "' <= tm.EndingDate )");
            query.Append(" Order by SR_Students.FirstName ;");

            #endregion

            List<StudentAttendace> results = new List<StudentAttendace>();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    for (int i = 0; i < tbl.Rows.Count; i++)
                    {
                        StudentAttendace studentAttendace = new StudentAttendace();
                        if (!Convert.IsDBNull(tbl.Rows[i]["StudentAttendanceId"]))
                        {
                            studentAttendace.ID = Convert.ToInt32(tbl.Rows[i]["StudentAttendanceId"]);
                        }
                        studentAttendace.Student = new BusinessEntities.Student.Student();
                        studentAttendace.Student.ID = Convert.ToInt32(tbl.Rows[i]["StudentId"]);
                        studentAttendace.Student.Name = Convert.ToString(tbl.Rows[i]["FirstName"]);
                        studentAttendace.Student.LastName = Convert.ToString(tbl.Rows[i]["LastName"]);
                        studentAttendace.Student.SmallPicture = Convert.ToString(tbl.Rows[i]["SmallPicture"]);
                        studentAttendace.Student.LargePicture = Convert.ToString(tbl.Rows[i]["LargePicture"]);
                        studentAttendace.Remarks = Convert.ToString(tbl.Rows[i]["Remarks"]);

                        studentAttendace.AttendanceStatus = new AttendanceStatus();
                        if (!Convert.IsDBNull(tbl.Rows[i]["AttendanceStatusId"]))
                        {
                            studentAttendace.AttendanceStatus.ID = Convert.ToInt32(tbl.Rows[i]["AttendanceStatusId"]);
                            studentAttendace.AttendanceStatus.Name = Convert.ToString(tbl.Rows[i]["S_Name"]);
                            studentAttendace.AttendanceStatus.AttendanceSymbol = Convert.ToString(tbl.Rows[i]["AttendanceSymbol"]);
                            studentAttendace.AttendanceStatus.CssClass = Convert.ToString(tbl.Rows[i]["CssClass"]);
                            studentAttendace.AttendanceStatus.StatusCssClass = "status " + Convert.ToString(tbl.Rows[i]["CssClass"]);
                        }
                        else
                        {
                            studentAttendace.AttendanceStatus.ID = AttendaceStatus.UnMarked.GetHashCode();
                            studentAttendace.AttendanceStatus.Name = AttendaceStatus.UnMarked.ToString();
                            studentAttendace.AttendanceStatus.AttendanceSymbol = string.Empty;
                            studentAttendace.AttendanceStatus.CssClass = "grey";
                            studentAttendace.AttendanceStatus.StatusCssClass = "status grey";
                        }
                        if (!Convert.IsDBNull(tbl.Rows[i]["RollTimeStatusId"]))
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = Convert.ToInt32(tbl.Rows[i]["RollTimeStatusId"]);
                        }
                        else
                        {
                            studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            studentAttendace.RollTimeAttendaceStatus.ID = roleTimeStatusId;

                        }
                        if (tbl.Columns.Contains("StartDate") && !Convert.IsDBNull(tbl.Rows[i]["StartDate"]))
                        {
                            studentAttendace.StartingDate = Convert.ToDateTime(tbl.Rows[i]["StartDate"]);
                        }
                        if (tbl.Columns.Contains("EndDate") && !Convert.IsDBNull(tbl.Rows[i]["EndDate"]))
                        {
                            studentAttendace.EndingDate = Convert.ToDateTime(tbl.Rows[i]["EndDate"]);
                        }
                        if (tbl.Columns.Contains("Reason") && !Convert.IsDBNull(tbl.Rows[i]["Reason"]))
                        {
                            studentAttendace.Reason = Convert.ToString(tbl.Rows[i]["Reason"]);
                        }
                        if (tbl.Columns.Contains("AttendanceDate") && !Convert.IsDBNull(tbl.Rows[i]["AttendanceDate"]))
                        {
                            studentAttendace.AttendanceDate = Convert.ToDateTime(tbl.Rows[i]["AttendanceDate"]);
                            string[] theTime = studentAttendace.AttendanceDate.ToString().Split(' ');

                            studentAttendace.AttendanceTime = theTime[1] + " " + theTime[2];//studentAttendace.AttendanceDate.ToShortTimeString();
                        }
                        if (tbl.Columns.Contains("TermNo") && !Convert.IsDBNull(tbl.Rows[i]["TermNo"]))
                        {
                            studentAttendace.Term = new BusinessEntities.Configuration.Term();
                            studentAttendace.Term.TermNo = Convert.ToString(tbl.Rows[i]["TermNo"]);
                        }
                        if (tbl.Columns.Contains("TLate") && !Convert.IsDBNull(tbl.Rows[i]["TLate"]))
                        {
                            studentAttendace.TotalLateInTerm = Convert.ToInt32(tbl.Rows[i]["TLate"]);
                        }
                        if (tbl.Columns.Contains("TAbsent") && !Convert.IsDBNull(tbl.Rows[i]["TAbsent"]))
                        {
                            studentAttendace.TotalAbsentsInTerm = Convert.ToInt32(tbl.Rows[i]["TAbsent"]);
                        }
                        if (tbl.Columns.Contains("TYearlyLate") && !Convert.IsDBNull(tbl.Rows[i]["TYearlyLate"]))
                        {
                            studentAttendace.TotalYearlyLate = Convert.ToInt32(tbl.Rows[i]["TYearlyLate"]);
                        }
                        if (tbl.Columns.Contains("TYearlyAbsent") && !Convert.IsDBNull(tbl.Rows[i]["TYearlyAbsent"]))
                        {
                            studentAttendace.TolatYearlyAbsent = Convert.ToInt32(tbl.Rows[i]["TYearlyAbsent"]);
                        }

                        results.Add(studentAttendace);
                    }
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }

//        public List<MessageResponse> GetAbsentStudents(int classId, int sectionId, int rollTimeStatusId)
//        {
//            StringBuilder query = new StringBuilder();

//            #region  Query
//            query.Append(@"SELECT SG.MobileNumber, ST.FirstName, ST.LastName
//                          FROM [AttendanceTest].[dbo].[ATT_Student_Attendance] SA
//                          INNER JOIN ST_StudentGaurdian SG ON SA.StudentId = SG.StudentId
//                          INNER JOIN SR_Student_Classes SC ON SA.StudentId = SC.StudentId
//                          INNER JOIN SR_Students ST ON SA.StudentId = ST.StudentId
//                          Where [AttendanceStatusId] IN (3,5,6,7,13,14,15,16,17,18,19,20) 
//                          AND CONVERT(VARCHAR, isnull(SA.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)
//                          AND (SC.ClassId = " + classId + " AND SC.SectionId = " + sectionId + ") AND RollTimeStatusId = " + rollTimeStatusId);
//            //query.Append(" Order by SR_Students.FirstName ;");

//            #endregion

//            List<MessageResponse> results = new List<MessageResponse>();

//            try
//            {
//                System.Data.DataSet set = FindMetaData(query.ToString());

//                System.Data.DataTable tbl = set.Tables[0];
//                if (tbl.Rows.Count > 0)
//                {
//                    for (int i = 0; i < tbl.Rows.Count; i++)
//                    {
//                        StudentAttendace studentAttendace = new StudentAttendace();
//                        {
//                            studentAttendace.ID = Convert.ToInt32(tbl.Rows[i]["StudentAttendanceId"]);
//                        }
//                        studentAttendace.Student = new BusinessEntities.Student.Student();
//                        studentAttendace.Student.ID = Convert.ToInt32(tbl.Rows[i]["StudentId"]);
//                        studentAttendace.Student.Name = Convert.ToString(tbl.Rows[i]["FirstName"]);
//                        studentAttendace.Student.LastName = Convert.ToString(tbl.Rows[i]["LastName"]);

//                        studentAttendace.AttendanceStatus = new AttendanceStatus();
//                        if (!Convert.IsDBNull(tbl.Rows[i]["AttendanceStatusId"]))
//                        {
//                            studentAttendace.AttendanceStatus.ID = Convert.ToInt32(tbl.Rows[i]["AttendanceStatusId"]);
//                        }
//                        studentAttendace
//                        results.Add(studentAttendace);
//                    }
//                    return results;
//                }
//                else
//                {
//                    return null;
//                }
//            }
//            catch (Exception ex)
//            {
//                HandleDBException(ex);

//            }
//            return results;
//        }
        public List<StudentAttendace> GetLateStudentByDate(DateTime fromDate, DateTime toDate)
        {
            StringBuilder query = new StringBuilder();

            #region  Query

            query.Append("Select L.*  From ( ");
            query.Append(@"SELECT ST.FirstName,ST.LastName,COUNT(SA.StudentId) LateCount,SA.StudentId,S.Name Section, C.Name St_Class,SC.ClassId,SC.SectionId
                            FROM ATT_Student_Attendance SA
                            INNER JOIN SR_Students ST
                            ON SA.StudentId =ST.StudentId                          
                            INNER JOIN SYS_Attendance_Status SU
                            ON SA.AttendanceStatusId =SU.AttendanceStatusId");  
            query.Append(@" INNER JOIN SR_Student_Classes SC
                            ON SA.StudentId =SC.StudentId 
                             INNER JOIN Config_Class C
                             ON SC.ClassId =C.ClassId
                            INNER JOIN Config_Section S
                            ON SC.SectionId=S.SectionId");
            query.Append(@" WHERE SA.AttendanceStatusId IN(4)  AND isnull(SC.IsActive,1) = 1 and datepart(dw,SA.AttendanceDate) <> 1
                            AND  (CONVERT(VARCHAR, SA.AttendanceDate, 103)>= '" + fromDate.ToString("dd/MM/yyyy")+   
                            "' AND CONVERT(VARCHAR, SA.AttendanceDate, 103) <= '"+toDate.ToString("dd/MM/yyyy")+"' )");
          query.Append("  group By  ST.FirstName,ST.LastName,SA.StudentId,S.Name,C.Name,SC.ClassId,SC.SectionId");
          query.Append(" ) L  Where L.LateCount= 6");
            #endregion

            List<StudentAttendace> results = new List<StudentAttendace>();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    for (int i = 0; i < tbl.Rows.Count; i++)
                    {
                        if (tbl.Columns.Contains("LateCount") && tbl.Rows[i]["LateCount"] != DBNull.Value && Convert.ToInt32(tbl.Rows[i]["LateCount"])==3)
                        {
                            StudentAttendace studentAttendace = new StudentAttendace();
                            studentAttendace.Student = new BusinessEntities.Student.Student();
                            studentAttendace.Student.ID = Convert.ToInt32(tbl.Rows[i]["StudentId"]);
                            studentAttendace.Student.Name = Convert.ToString(tbl.Rows[i]["FirstName"]);
                            studentAttendace.Student.LastName = Convert.ToString(tbl.Rows[i]["LastName"]);
                            studentAttendace.LateCount = Convert.ToInt32(tbl.Rows[i]["LateCount"]);
                            studentAttendace.Student.StudnetClass = new BusinessEntities.Configuration.Classes();
                            studentAttendace.Student.StudnetClass.Name = Convert.ToString(tbl.Rows[i]["St_Class"]);
                            studentAttendace.Student.StudnetClass.ID = Convert.ToInt32(tbl.Rows[i]["ClassId"]);
                            studentAttendace.Student.Section = new BusinessEntities.Configuration.Section();
                            studentAttendace.Student.Section.Name = Convert.ToString(tbl.Rows[i]["Section"]);
                            studentAttendace.Student.Section.ID = Convert.ToInt32(tbl.Rows[i]["SectionId"]);
                            results.Add(studentAttendace);
                        }
                    }
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }

        
        public List<StudentAttendace> GetUnMarkStudent(int rollTimeStatusId,int statusId)
        {
            StringBuilder query = new StringBuilder();

            #region  old Query
//            query.Append(@"SELECT DISTINCT ST.FirstName , ST.LastName ,
//                            ISNULL(SA.AttendanceStatusId,1)AttendanceStatusId,S.DisplayName ,ST.StudentId 
//                            ,C.ClassId ,C.Name C_NAME,SE.SectionId ,SE.Name SE_NAME
//                            ,T.TeacherId,T.FirstName T_FirstName ,T.LastName T_LastName 
//                            FROM SR_Students ST 
//                            LEFT JOIN  ATT_Student_Attendance SA
//                            ON ST.StudentId = SA.StudentId
//                            INNER JOIN SYS_Attendance_Status S
//                            ON S.AttendanceStatusId = ISNULL(SA.AttendanceStatusId,1)
//                            INNER JOIN SR_Student_Classes SC
//                            ON ST.StudentId = SC.StudentId 
//                            INNER JOIN  Config_Terms tm
//                            ON  SC.TermId = tm.TermNo 
//                            INNER JOIN Config_Class C
//                            ON SC.ClassId = C.ClassId
//                            INNER JOIN Config_Section SE
//                            ON SC.SectionId = SE.SectionId  
//                            LEFT JOIN TR_ClassTeachers TC
//                            ON SC.ClassId = TC.ClassId AND SC.SectionId = TC.SectionId 
//                            LEFT JOIN  TR_Teachers T
//                            ON TC.TeacherId = T.TeacherId AND TC.IsIncharge = 1
//                            LEFT JOIN UMS_Users US
//                            ON US.LoginUserId = T.TeacherId 
//                            INNER JOIN EMP_ClassCoordinatorAssociation CC
//                            ON SC.ClassId = CC.ClassId AND SC.SectionId = CC.SectionId  AND US.RoleId <> 1
//                            WHERE ISNULL(SA.AttendanceStatusId," + statusId + ") =" + statusId + @" 
//                            AND CONVERT(VARCHAR, isnull(SA.AttendanceDate,{ fn NOW()}), 111) = CONVERT(VARCHAR, { fn NOW() }, 111)");
//            query.Append(" AND ISNULL(SA.RollTimeStatusId," + rollTimeStatusId + ") = " + rollTimeStatusId);
//            query.Append(" AND CC.IsActive = 1 AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111) <= tm.EndingDate )");
//            query.Append(" Order by ST.FirstName ASC ;");
            #endregion
            #region OLD Query
//            query.Append(@"SELECT Distinct ST.FirstName , ST.LastName,ST.StudentId  
//                            , US.AttendanceStatusId ,US.DisplayName 
//                            ,C.ClassId ,C.Name C_NAME
//                            ,S.SectionId ,S.Name SE_NAME
//                            ,T.TeacherId,T.FirstName T_FirstName ,T.LastName T_LastName 
//                            FROM 
//                            SR_Students ST 
//                            INNER JOIN SR_Student_Classes SC
//                            ON SC.StudentId = ST.StudentId 
//                            INNER JOIN Config_Class C
//                            ON C.ClassId = SC.ClassId 
//                            INNER JOIN Config_Section S
//                            ON S.SectionId = SC.SectionId 
//                            INNER JOIN TR_ClassTeachers TC
//                            ON TC.ClassId = SC.ClassId AND TC.SectionId = SC.SectionId 
//                            INNER JOIN TR_Teachers T
//                            ON T.TeacherId = TC.TeacherId 
//                            INNER JOIN UMS_Users U
//                            ON U.LoginUserId = T.TeacherId AND U.RoleId <> 1
//                            INNER JOIN EMP_ClassCoordinatorAssociation CC
//                            ON CC.TeacherId = T.TeacherId  AND CC.IsActive = 1 AND CC.ClassId = SC.ClassId AND CC.SectionId = TC.SectionId
//                            INNER JOIN Config_Terms TM
//                            ON TM.TermNo = SC.TermId 
//                            LEFT JOIN ATT_Student_Attendance AT
//                            ON ST.StudentId =  ISNULL(AT.StudentId ,ST.StudentId) AND CONVERT(VARCHAR, isnull(AT.AttendanceDate,{ fn NOW()}), 103) = CONVERT(VARCHAR, { fn NOW() }, 103)
//                            AND ISNULL(AT.RollTimeStatusId," + rollTimeStatusId + ") = " + rollTimeStatusId + @"
//                            INNER JOIN SYS_Attendance_Status US
//                            ON US.AttendanceStatusId = ISNULL(AT.AttendanceStatusId ,1)
//                            WHERE  ( TM.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= TM.EndingDate )");

//            query.Append(" Order by ST.FirstName ASC ;");
            #endregion
            query.Append(@"SELECT A.* FROM (
                            SELECT DISTINCT  C.ClassId ,C.Name C_NAME
                             ,S.SectionId ,S.Name SE_NAME
                              ,T.TeacherId,T.FirstName T_FirstName ,T.LastName T_LastName 
 
                            FROM  SR_Student_Classes SC
                            INNER JOIN Config_Class C
                            ON SC.ClassId = C.ClassId 
                            INNER JOIN Config_Section S
                            ON SC.SectionId = S.SectionId 
                            INNER JOIN Config_Terms TM
                            ON TM.TermId = SC.TermId 
                            INNER JOIN TR_ClassTeachers TC
                            ON TC.ClassId = SC.ClassId AND TC.SectionId = SC.SectionId 
                            INNER JOIN TR_Teachers T
                            ON TC.TeacherId = T.TeacherId AND TC.IsIncharge = 1

                            LEFT JOIN ATT_Student_Attendance AT
                            ON SC.StudentId =  ISNULL(AT.StudentId ,SC.StudentId) AND CONVERT(VARCHAR, isnull(AT.AttendanceDate,{ fn NOW()}), 103) = CONVERT(VARCHAR, { fn NOW() }, 103)

                            WHERE isnull(SC.IsActive,1) =  1 AND  ( TM.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= TM.EndingDate )
                            AND TM.TermYear =  YEAR({ fn NOW() }) AND  isnull(at.AttendanceStatusId,1) = 1 AND ISNULL(AT.RollTimeStatusId," + rollTimeStatusId + ") = " + rollTimeStatusId + @"
                            )A
                            INNER JOIN (SELECT Distinct EA.[ClassId],EA.[SectionId]
                            FROM EMP_ClassCoordinatorAssociation EA
                            INNER JOIN TR_Teachers T
                            ON T.TeacherId = EA.TeacherId                     
                            Where EA.IsActive = 1)B
                            ON A.ClassId =B.ClassId AND A.SectionId = B.SectionId ");
            query.Append(@" INNER JOIN UMS_Users U
                            ON U.LoginUserId = A.TeacherId 
                            WHERE U.RoleId = 2 ");
            query.Append("ORDER BY A.T_FirstName  ASC ;");
            List<StudentAttendace> results = new List<StudentAttendace>();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    results = ConstructFactory(tbl);
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }
        public  List<StudentAttendace> ConstructFactory(DataTable dt)
        {
            List<StudentAttendace> studentsAttendace = new List<StudentAttendace>();

            for (int rowIndex = 0; rowIndex < dt.Rows.Count; rowIndex++)
            {
                StudentAttendace studentAttendace = new StudentAttendace();
                if (dt.Columns.Contains("StudentAttendanceId") && !Convert.IsDBNull(dt.Rows[rowIndex]["StudentAttendanceId"]))
                {
                    studentAttendace.ID = Convert.ToInt32(dt.Rows[rowIndex]["StudentAttendanceId"]);
                }
                studentAttendace.Student  = new BusinessEntities.Student.Student();
                if (dt.Columns.Contains("StudentId") && !Convert.IsDBNull(dt.Rows[rowIndex]["StudentId"]))
                {
                    studentAttendace.Student.ID = Convert.ToInt32(dt.Rows[rowIndex]["StudentId"]);
                }
                if (dt.Columns.Contains("FirstName") && !Convert.IsDBNull(dt.Rows[rowIndex]["FirstName"]))
                {
                    studentAttendace.Student.Name = Convert.ToString(dt.Rows[rowIndex]["FirstName"]);
                }
                if (dt.Columns.Contains("LastName") && !Convert.IsDBNull(dt.Rows[rowIndex]["LastName"]))
                {
                    studentAttendace.Student.LastName = Convert.ToString(dt.Rows[rowIndex]["LastName"]);
                }
                studentAttendace.AttendanceStatus = new BusinessEntities.Attendance.AttendanceStatus();
                if (dt.Columns.Contains("AttendanceStatusId") && !Convert.IsDBNull(dt.Rows[rowIndex]["AttendanceStatusId"]))
                {
                    studentAttendace.AttendanceStatus.ID = Convert.ToInt32(dt.Rows[rowIndex]["AttendanceStatusId"]);
                }
                if (dt.Columns.Contains("DisplayName") && !Convert.IsDBNull(dt.Rows[rowIndex]["DisplayName"]))
                {
                    studentAttendace.AttendanceStatus.Name = Convert.ToString(dt.Rows[rowIndex]["DisplayName"]);
                }

                if (dt.Columns.Contains("Remarks") && !Convert.IsDBNull(dt.Rows[rowIndex]["Remarks"]))
                {
                    studentAttendace.Remarks = Convert.ToString(dt.Rows[rowIndex]["Remarks"]);
                }

                if (dt.Columns.Contains("AttendanceDate") && !Convert.IsDBNull(dt.Rows[rowIndex]["AttendanceDate"]))
                {
                    studentAttendace.AttendanceDate = Convert.ToDateTime(dt.Rows[rowIndex]["AttendanceDate"]);
                }

                if (dt.Columns.Contains("StartDate") && !Convert.IsDBNull(dt.Rows[rowIndex]["StartDate"]))
                {
                    studentAttendace.StartingDate = Convert.ToDateTime(dt.Rows[rowIndex]["StartDate"]);
                }
                if (dt.Columns.Contains("EndDate") && !Convert.IsDBNull(dt.Rows[rowIndex]["EndDate"]))
                {
                    studentAttendace.EndingDate = Convert.ToDateTime(dt.Rows[rowIndex]["EndDate"]);
                }
                if (dt.Columns.Contains("Reason") && !Convert.IsDBNull(dt.Rows[rowIndex]["Reason"]))
                {
                    studentAttendace.Reason = Convert.ToString(dt.Rows[rowIndex]["Reason"]);
                }               
                studentAttendace.Student.StudnetClass = new BusinessEntities.Configuration.Classes();
                if (dt.Columns.Contains("ClassId") && !Convert.IsDBNull(dt.Rows[rowIndex]["ClassId"]))
                {
                    studentAttendace.Student.StudnetClass.ID  = Convert.ToInt32(dt.Rows[rowIndex]["ClassId"]);
                }
                if (dt.Columns.Contains("C_NAME") && !Convert.IsDBNull(dt.Rows[rowIndex]["C_NAME"]))
                {
                    studentAttendace.Student.StudnetClass.Name  = Convert.ToString(dt.Rows[rowIndex]["C_NAME"]);
                }
                studentAttendace.Student.Section = new BusinessEntities.Configuration.Section();
                if (dt.Columns.Contains("SectionId") && !Convert.IsDBNull(dt.Rows[rowIndex]["SectionId"]))
                {
                    studentAttendace.Student.Section.ID = Convert.ToInt32(dt.Rows[rowIndex]["SectionId"]);
                }
                if (dt.Columns.Contains("SE_NAME") && !Convert.IsDBNull(dt.Rows[rowIndex]["SE_NAME"]))
                {
                    studentAttendace.Student.Section.Name = Convert.ToString(dt.Rows[rowIndex]["SE_NAME"]);
                }
                studentAttendace.Employee = new Employee();
                if (dt.Columns.Contains("TeacherId") && !Convert.IsDBNull(dt.Rows[rowIndex]["TeacherId"]))
                {
                    studentAttendace.Employee.ID  = Convert.ToInt32 (dt.Rows[rowIndex]["TeacherId"]);
                }
                if (dt.Columns.Contains("T_FirstName") && !Convert.IsDBNull(dt.Rows[rowIndex]["T_FirstName"]))
                {
                    studentAttendace.Employee.Name = Convert.ToString(dt.Rows[rowIndex]["T_FirstName"]);
                }
                if (dt.Columns.Contains("T_LastName") && !Convert.IsDBNull(dt.Rows[rowIndex]["T_LastName"]))
                {
                    studentAttendace.Employee.LastName = Convert.ToString(dt.Rows[rowIndex]["T_LastName"]);
                }
                studentsAttendace.Add(studentAttendace);

            }
            return studentsAttendace;
        }
    }
}
