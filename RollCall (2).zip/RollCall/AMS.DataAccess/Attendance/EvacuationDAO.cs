﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Attendance;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using DataAccess.Generic;
using System.Data;
using DataAccess.Exceptions;

namespace AMS.DataAccess.Attendance
{
    public interface  IEvacuationDAO
    {
        List<Evacuation> GetAll(int? classId, int? sectionId, DateTime theDate, int rollTimeStatusId, int employeId);
        Evacuation IsExist(int studentId, int rollTimeId);
        int InsertEvacuation(Evacuation evacuation,int createdBy);
        int UpdatEvacuation(Evacuation evacuation, int createdBy);
    }
    public class EvacuationDAO : BaseDAO<Evacuation>, IEvacuationDAO
    {
        public string sp_InsertEvacuation = "ATT_Eva_Attendance_Add";
        public string sp_UpdateEvacuation = "ATT_Eva_Attendance_Update";
       public EvacuationDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }
       public EvacuationDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

       public List<Evacuation> GetAll(int? classId, int? sectionId, DateTime theDate, int rollTimeStatusId,int employeId)
       {
           StringBuilder query = new StringBuilder();

           #region  Query
          
           query.Append(@" SELECT LA.StudentId, LA.latestSatausId,LA.latestStatusName,LA.AttendanceStatusId,LA.DisplayName,LA.TeacherId ,LA.FirstName ,LA.LastName ,LA.SmallPicture,LA.AttendanceDate 
                        ,LA.SectionId,LA.ClassId,LA.TermId
       , EV.EvacuationAttendanceId ,ISNULL(EV.AttendanceStatusId,1)  EV_AttendanceStatusId,EV.AttendanceDate EV_AttendanceDate,EV.VERSION_NUMBER
                      ,LA.S_NAME ,LA.AttendanceSymbol ,LA.CssClass
       , ST.Name ES_NAME,ST.DisplayName E_DisplayName,ST.CssClass E_CssClass,ST.AttendanceSymbol E_AttendanceSymbol
         FROM
      (
      SELECT MA.StudentId,MA.AttendanceStatusId,MA.DisplayName,MA.FirstName ,MA.LastName ,MA.SmallPicture 
                        ,MA.S_NAME,MA.SectionId,MA.ClassId,MA.TermId
                        ,(SELECT AttendanceSymbol FROM dbo.LatestAttendanceStatus(EA.AttendanceStatusId,MA.AttendanceStatusId)) AttendanceSymbol                          
                        ,(SELECT CssClass DisplayName FROM dbo.LatestAttendanceStatus(EA.AttendanceStatusId,MA.AttendanceStatusId)) CssClass
      ,EA.TeacherId,ISNULL(EA.AttendanceDate,MA.AttendanceDate)AttendanceDate   
                        ,dbo.fn_LatestStatus(EA.AttendanceStatusId,MA.AttendanceStatusId) latestSatausId
                        ,(SELECT ISNULL(DisplayName,Name) DisplayName FROM dbo.LatestAttendanceStatus(EA.AttendanceStatusId,MA.AttendanceStatusId)) latestStatusName  
 
      FROM       
      (
      SELECT     
      ST.StudentId
                        ,ISNULL(AT.AttendanceStatusId,1)AttendanceStatusId,ISNULL(AT.RollTimeStatusId, 1)RollTimeStatusId
                        ,S.DisplayName ,S.Name S_NAME,S.AttendanceSymbol ,S.CssClass
                        ,ST.FirstName ,ST.LastName ,ST.SmallPicture
                        ,AT.AttendanceDate 
                        ,SC.SectionId,SC.ClassId,SC.TermId                        
                        FROM SR_Students ST
                        LEFT JOIN SR_Student_Classes SC 
                        ON SC.StudentId =ST.StudentId 
                        LEFT JOIN ATT_Student_Attendance AT
                        ON AT.StudentId = ST.StudentId AND ISNULL(AT.RollTimeStatusId,1) = 1 AND CONVERT(VARCHAR, isnull(AT.AttendanceDate,{fn now()}), 103) = '" + theDate.ToString("dd/MM/yyyy") + @"'
                        INNER JOIN SYS_Attendance_Status S
                        ON S.AttendanceStatusId = ISNULL(AT.AttendanceStatusId,1) 
                        INNER JOIN TR_ClassTeachers CT
                        ON CT.ClassId = SC.ClassId AND CT.SectionId = SC.SectionId
                        INNER JOIN Config_Terms TM
                        ON SC.TermId = TM.TermId  WHERE ISNULL(st.IsActive,1) =1 and isnull(SC.IsActive,1) =  1 AND CT.TeacherId= " + employeId + @" AND
                        ( '" + theDate.ToString("dd/MM/yyyy") + "' >= CONVERT(VARCHAR, TM.StartingDate, 103)  AND '" + theDate.ToString("dd/MM/yyyy") + @"' <= CONVERT(VARCHAR, TM.EndingDate, 103) )
                        )MA
                        LEFT JOIN 
                        (
                         SELECT ST.StudentId
                        ,ISNULL(AT.AttendanceStatusId,1)AttendanceStatusId,ISNULL(AT.RollTimeStatusId, 2)RollTimeStatusId,AT.AttendanceDate 
                        ,S.DisplayName 
                        ,CT.TeacherId 
                        FROM SR_Students ST
                        LEFT JOIN SR_Student_Classes SC 
                        ON SC.StudentId =ST.StudentId 
                        LEFT JOIN ATT_Student_Attendance AT
                        ON AT.StudentId = ST.StudentId AND ISNULL(AT.RollTimeStatusId,2) =  2 AND CONVERT(VARCHAR, isnull(AT.AttendanceDate,{fn now()}), 103) = '" + theDate.ToString("dd/MM/yyyy") + @"'
                        INNER JOIN SYS_Attendance_Status S
                        ON S.AttendanceStatusId = ISNULL(AT.AttendanceStatusId,1) 
                        INNER JOIN TR_ClassTeachers CT
                        ON CT.ClassId = SC.ClassId AND CT.SectionId = SC.SectionId
                        INNER JOIN Config_Terms TM
                        ON SC.TermId = TM.TermId  WHERE  ISNULL(st.IsActive,1) =1 and isnull(SC.IsActive,1) =  1  AND CT.TeacherId = " + employeId + @" AND  
                        ( '" + theDate.ToString("dd/MM/yyyy") + "' >= CONVERT(VARCHAR, TM.StartingDate, 103)  AND '" + theDate.ToString("dd/MM/yyyy") + @"'  <= CONVERT(VARCHAR, TM.EndingDate, 103) ) 
                        ) EA
                        ON MA.StudentId = EA.StudentId
                        Where  (ISNULL(MA.AttendanceStatusId,1) <> 1 OR EA.AttendanceStatusId <> 1 )
                      )LA
                     LEFT JOIN ATT_EvacuationAttendance EV
                     ON LA.StudentId = EV.StudentId
                     LEFT JOIN SYS_Attendance_Status ST
                     ON ST.AttendanceStatusId = ISNULL(EV.AttendanceStatusId,1) 
                    
           WHERE ");
           query.Append("  ISNULL(Ev.RollTimeStatusId," + rollTimeStatusId + ") = " + rollTimeStatusId);
           query.Append("  AND LA.latestSatausId <> ISNULL(EV.AttendanceStatusId,1) ");
           query.Append("  ORDER BY LA.FirstName ");
           #endregion

           List<Evacuation> results = new List<Evacuation>();

           try
           {
               System.Data.DataSet set = FindMetaData(query.ToString());

               System.Data.DataTable tbl = set.Tables[0];
               if (tbl.Rows.Count > 0)
               {
                   results = ConstructFactory(tbl);
                   return results;
               }
               else
               {
                   return null;
               }
           }
           catch (Exception ex)
           {
               HandleDBException(ex);

           }
           return results;
       }
       private List<Evacuation> ConstructFactory(DataTable dt)
       {
           List<Evacuation> lstEvacuation = new List<Evacuation>();

           for (int rowIndex = 0; rowIndex < dt.Rows.Count; rowIndex++)
           {
               Evacuation evacuation = new Evacuation();
              
               if (dt.Columns.Contains("EvacuationAttendanceId") && !Convert.IsDBNull(dt.Rows[rowIndex]["EvacuationAttendanceId"]))
               {
                   evacuation.ID = Convert.ToInt32(dt.Rows[rowIndex]["EvacuationAttendanceId"]);
               }
               evacuation.Student = new BusinessEntities.Student.Student();
               if (dt.Columns.Contains("StudentId") && !Convert.IsDBNull(dt.Rows[rowIndex]["StudentId"]))
               {                   
                   evacuation.Student.ID = Convert.ToInt32(dt.Rows[rowIndex]["StudentId"]);                 
                 
               }

               if (dt.Columns.Contains("FirstName") && !Convert.IsDBNull(dt.Rows[rowIndex]["FirstName"]))
               {
                   evacuation.Student.Name = Convert.ToString(dt.Rows[rowIndex]["FirstName"]);
               }

               if (dt.Columns.Contains("LastName") && !Convert.IsDBNull(dt.Rows[rowIndex]["LastName"]))
               {
                   evacuation.Student.LastName = Convert.ToString(dt.Rows[rowIndex]["LastName"]);
               }

               evacuation.AttendanceStatus = new BusinessEntities.Attendance.AttendanceStatus();
               if (dt.Columns.Contains("latestSatausId") && !Convert.IsDBNull(dt.Rows[rowIndex]["latestSatausId"]))
               {
                   evacuation.AttendanceStatus.ID = Convert.ToInt32(dt.Rows[rowIndex]["latestSatausId"]);                   
               }
               if (dt.Columns.Contains("latestStatusName") && !Convert.IsDBNull(dt.Rows[rowIndex]["latestStatusName"]))
               {
                   evacuation.AttendanceStatus.Name = Convert.ToString(dt.Rows[rowIndex]["latestStatusName"]);
               }
               if (dt.Columns.Contains("AttendanceSymbol") && !Convert.IsDBNull(dt.Rows[rowIndex]["AttendanceSymbol"]))
               {
                   evacuation.AttendanceStatus.AttendanceSymbol = Convert.ToString(dt.Rows[rowIndex]["AttendanceSymbol"]);
               }
               if (dt.Columns.Contains("CssClass") && !Convert.IsDBNull(dt.Rows[rowIndex]["CssClass"]))
               {
                   evacuation.AttendanceStatus.CssClass = Convert.ToString(dt.Rows[rowIndex]["CssClass"]);
               }
               if (dt.Columns.Contains("Name") && !Convert.IsDBNull(dt.Rows[rowIndex]["Name"]))
               {
                   evacuation.AttendanceStatus.Name = Convert.ToString(dt.Rows[rowIndex]["Name"]);
               }
               evacuation.EvationStatus  = new BusinessEntities.Attendance.AttendanceStatus();
               if (dt.Columns.Contains("EV_AttendanceStatusId") && !Convert.IsDBNull(dt.Rows[rowIndex]["EV_AttendanceStatusId"]))
               {
                   evacuation.EvationStatus.ID = Convert.ToInt32(dt.Rows[rowIndex]["EV_AttendanceStatusId"]);
               }
               if (dt.Columns.Contains("ES_NAME") && !Convert.IsDBNull(dt.Rows[rowIndex]["ES_NAME"]))
               {
                   evacuation.EvationStatus.Name = Convert.ToString(dt.Rows[rowIndex]["ES_NAME"]);
               }
               if (dt.Columns.Contains("E_DisplayName") && !Convert.IsDBNull(dt.Rows[rowIndex]["E_DisplayName"]))
               {
                   evacuation.EvationStatus.DisplayName = Convert.ToString(dt.Rows[rowIndex]["E_DisplayName"]);
               }
               if (dt.Columns.Contains("ES_NAME") && !Convert.IsDBNull(dt.Rows[rowIndex]["ES_NAME"]))
               {
                   evacuation.EvationStatus.Name = Convert.ToString(dt.Rows[rowIndex]["ES_NAME"]);
               }
               if (dt.Columns.Contains("E_AttendanceSymbol") && !Convert.IsDBNull(dt.Rows[rowIndex]["E_AttendanceSymbol"]))
               {
                   evacuation.EvationStatus.AttendanceSymbol = Convert.ToString(dt.Rows[rowIndex]["E_AttendanceSymbol"]);
               }
               if (dt.Columns.Contains("E_CssClass") && !Convert.IsDBNull(dt.Rows[rowIndex]["E_CssClass"]))
               {
                   evacuation.EvationStatus.CssClass = Convert.ToString(dt.Rows[rowIndex]["E_CssClass"]);
               }
               evacuation.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
               if (dt.Columns.Contains("RollTimeStatusId") && !Convert.IsDBNull(dt.Rows[rowIndex]["RollTimeStatusId"]))
               {
                   evacuation.RollTimeAttendaceStatus.ID = Convert.ToInt32(dt.Rows[rowIndex]["RollTimeStatusId"]);
               }
               if (dt.Columns.Contains("SmallPicture") && !Convert.IsDBNull(dt.Rows[rowIndex]["SmallPicture"]))
               {
                   evacuation.Student.SmallPicture = Convert.ToString(dt.Rows[rowIndex]["SmallPicture"]);
               }
               if (dt.Columns.Contains("EV_AttendanceDate") && !Convert.IsDBNull(dt.Rows[rowIndex]["EV_AttendanceDate"]))
               {
                   evacuation.AttendanceDate  = Convert.ToDateTime(dt.Rows[rowIndex]["EV_AttendanceDate"]);
               }
               if (dt.Columns.Contains("VERSION_NUMBER") && !Convert.IsDBNull(dt.Rows[rowIndex]["VERSION_NUMBER"]))
               {
                   evacuation.VersionNo  = Convert.ToInt32(dt.Rows[rowIndex]["VERSION_NUMBER"]);
               }
               evacuation.StudentClass =  new BusinessEntities.Configuration.Classes();
               if (dt.Columns.Contains("ClassId") && !Convert.IsDBNull(dt.Rows[rowIndex]["ClassId"]))
               {
                   evacuation.StudentClass.ID = Convert.ToInt32(dt.Rows[rowIndex]["ClassId"]);
               }
               evacuation.ClassSection = new BusinessEntities.Configuration.Section();
               if (dt.Columns.Contains("SectionId") && !Convert.IsDBNull(dt.Rows[rowIndex]["SectionId"]))
               {
                   evacuation.ClassSection.ID = Convert.ToInt32(dt.Rows[rowIndex]["SectionId"]);
               }
               evacuation.Term = new BusinessEntities.Configuration.Term();
                if (dt.Columns.Contains("TermId") && !Convert.IsDBNull(dt.Rows[rowIndex]["TermId"]))
               {
                   evacuation.Term.ID = Convert.ToInt32(dt.Rows[rowIndex]["TermId"]);
               }
               

               lstEvacuation.Add(evacuation);

           }
           return lstEvacuation;
       }

       public int InsertEvacuation(Evacuation evacuation,int createdBy)
       {
           int i = 0;
           DbCommand cmd = dbConnection.CreateCommand();
           cmd.Transaction = dbTransaction;
           cmd.CommandType = CommandType.StoredProcedure;

           DbParameter p_Student_Id = cmd.CreateParameter();
           p_Student_Id.ParameterName = "p_Student_Id";
           p_Student_Id.DbType = DbType.Int32;
           p_Student_Id.Value = evacuation.Student.ID;
           p_Student_Id.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_Student_Id);

           DbParameter p_Attendance_Status_Id = cmd.CreateParameter();
           p_Attendance_Status_Id.ParameterName = "p_Attendance_Status_Id";
           p_Attendance_Status_Id.DbType = DbType.Int32;
           p_Attendance_Status_Id.Value = evacuation.EvationStatus.ID;
           p_Attendance_Status_Id.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_Attendance_Status_Id);

           DbParameter p_RollTimeStatusId = cmd.CreateParameter();
           p_RollTimeStatusId.ParameterName = "p_RollTimeStatusId";
           p_RollTimeStatusId.DbType = DbType.Int32;
           p_RollTimeStatusId.Value = evacuation.RollTimeAttendaceStatus.ID;
           p_RollTimeStatusId.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_RollTimeStatusId);
          
           DbParameter p_CREATED_BY = cmd.CreateParameter();
           p_CREATED_BY.ParameterName = "p_CREATED_BY";
           p_CREATED_BY.DbType = DbType.Int32;
           p_CREATED_BY.Value = createdBy;
           p_CREATED_BY.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_CREATED_BY);

           DbParameter p_VERSION_NUMBER = cmd.CreateParameter();
           p_VERSION_NUMBER.ParameterName = "p_VERSION_NUMBER";
           p_VERSION_NUMBER.DbType = DbType.Int32;
           p_VERSION_NUMBER.Value = evacuation.VersionNo;
           p_VERSION_NUMBER.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_VERSION_NUMBER);


           DbParameter p_StudentClassId = cmd.CreateParameter();
           p_StudentClassId.ParameterName = "p_StudentClassId";
           p_StudentClassId.DbType = DbType.Int32;
           p_StudentClassId.Value = evacuation.StudentClass.ID ;
           p_StudentClassId.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_StudentClassId);

           DbParameter p_SectionId = cmd.CreateParameter();
           p_SectionId.ParameterName = "p_SectionId";
           p_SectionId.DbType = DbType.Int32;
           p_SectionId.Value = evacuation.ClassSection.ID;
           p_SectionId.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_SectionId);

           DbParameter p_TermId = cmd.CreateParameter();
           p_TermId.ParameterName = "p_TermId";
           p_TermId.DbType = DbType.Int32;
           p_TermId.Value = evacuation.Term.ID;
           p_TermId.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_TermId);
          
           DbParameter p_AttendanceDate = cmd.CreateParameter();
           p_AttendanceDate.ParameterName = "p_AttendanceDate";
           p_AttendanceDate.DbType = DbType.DateTime;
           if (evacuation.AttendanceDate.Year  == 1)
           {
               p_AttendanceDate.Value = DateTime.Now;
           }
           else
           {
               p_AttendanceDate.Value = evacuation.AttendanceDate;
           }
           p_AttendanceDate.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_AttendanceDate);

           try
           {
               cmd.CommandText = sp_InsertEvacuation;

               object returnValue = cmd.ExecuteNonQuery();

               if (returnValue == null)
                   throw new DAONoRecordFoundException();
               i = Convert.ToInt32(returnValue);

           }
           catch (Exception ex)
           {
               HandleDBException(ex);
           }
           return i;
          
       }


       public int UpdatEvacuation(Evacuation evacuation, int createdBy)
       {
           int i = 0;
           DbCommand cmd = dbConnection.CreateCommand();
           cmd.Transaction = dbTransaction;
           cmd.CommandType = CommandType.StoredProcedure;

           DbParameter p_EvacuationAttendanceId = cmd.CreateParameter();
           p_EvacuationAttendanceId.ParameterName = "p_EvacuationAttendanceId";
           p_EvacuationAttendanceId.DbType = DbType.Int32;
           p_EvacuationAttendanceId.Value = evacuation.ID;
           p_EvacuationAttendanceId.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_EvacuationAttendanceId);

           DbParameter p_Attendance_Status_Id = cmd.CreateParameter();
           p_Attendance_Status_Id.ParameterName = "p_Attendance_Status_Id";
           p_Attendance_Status_Id.DbType = DbType.Int32;
           p_Attendance_Status_Id.Value = evacuation.EvationStatus.ID;
           p_Attendance_Status_Id.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_Attendance_Status_Id);

           DbParameter p_LAST_MODIFIED_BY = cmd.CreateParameter();
           p_LAST_MODIFIED_BY.ParameterName = "p_LAST_MODIFIED_BY";
           p_LAST_MODIFIED_BY.DbType = DbType.Int32;
           p_LAST_MODIFIED_BY.Value = createdBy;
           p_LAST_MODIFIED_BY.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_LAST_MODIFIED_BY);

           DbParameter p_VERSION_NUMBER = cmd.CreateParameter();
           p_VERSION_NUMBER.ParameterName = "p_VERSION_NUMBER";
           p_VERSION_NUMBER.DbType = DbType.Int32;
           p_VERSION_NUMBER.Value = evacuation.VersionNo;
           p_VERSION_NUMBER.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_VERSION_NUMBER);

           DbParameter p_AttendanceDate = cmd.CreateParameter();
           p_AttendanceDate.ParameterName = "p_AttendanceDate";
           p_AttendanceDate.DbType = DbType.DateTime;
           p_AttendanceDate.Value = evacuation.AttendanceDate;
           p_AttendanceDate.Direction = ParameterDirection.Input;
           cmd.Parameters.Add(p_AttendanceDate);


           try
           {
               cmd.CommandText = sp_UpdateEvacuation;

               object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

               if (returnValue == null)
                   throw new DAONoRecordFoundException();
               i = Convert.ToInt32(returnValue);

           }
           catch (Exception ex)
           {
               HandleDBException(ex);
           }
           return i;
       }


       public Evacuation IsExist(int studentId, int rollTimeId)
       {
           StringBuilder query = new StringBuilder();

           #region  Query

           query.Append(@"	SELECT [EvacuationAttendanceId] ,[VERSION_NUMBER]
                            FROM [dbo].[ATT_EvacuationAttendance]
                            Where [StudentId] = " + studentId + " and [RollTimeStatusId] =" + rollTimeId);
           #endregion

           List<Evacuation> results = new List<Evacuation>();

           try
           {
               System.Data.DataSet set = FindMetaDataWithTransaction (query.ToString());

               System.Data.DataTable tbl = set.Tables[0];
               if (tbl.Rows.Count > 0)
               {
                   results = ConstructFactory(tbl);
                   return results[0];
               }
               else
               {
                   return null;
               }
           }
           catch (Exception ex)
           {
               HandleDBException(ex);

           }
           return null;
       }
    }
}
