﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;

using System.Data;
using DataAccess.Generic.Factory;
using System.Data.SqlClient;
using DataAccess.Exceptions;
using System.Reflection;
using AMS.Business;
using BuisnessEntities.Common;

namespace DataAccess.Generic
{
    /// <summary>
    /// A generic repository base class that uses various
    /// factory classes to get and retrieve specific domain
    /// objects.
    /// </summary> 
    public class BaseDAO<TDomainObject> : EntityDAO
    {
        protected DbConnection dbConnection;
        protected DbTransaction dbTransaction;
        protected Database database;
        protected static string VERSION_COL_NAME = "Version_Number";
        protected static string CREATEDBY_COL_NAME = "Created_By";
        protected static string CREATEDON_COL_NAME = "Created_On";
        protected static string MODIFIEDBY_COL_NAME = "Last_Modified_By";
        protected static string MODIFIEDON_COL_NAME = "Last_Modified_Date";

        public static string getUserDate(string field)
        {
            if (!String.IsNullOrEmpty(DAOFactory.Instance.LangPrefDB))
                return "to_char(" + field + " ,'MM/DD/YYYY HH24:MI:SS','nls_calendar=''" + DAOFactory.Instance.LangPrefDB + "''')";
            else
                return field;
        }
        public string getDefaultDate(string field)
        {
            if (!String.IsNullOrEmpty(DAOFactory.Instance.LangPrefDB))
                return "to_date('" + field + "' ,'MM/DD/YYYY HH:MI:SS AM','nls_calendar=''" + DAOFactory.Instance.LangPrefDB + "''')";
            else
                return "to_date('" + field + "','mm/dd/yyyy hh:mi:ss am')";
        }

        public BaseDAO(DAOInfo DAOInfo)
        {
            if (DAOInfo != null)
            {
                this.database = DAOInfo.Database;
                this.dbConnection = DAOInfo.DbConnection;
                this.dbTransaction = DAOInfo.Transaction;
            }
        }

        public BaseDAO(Database database, DbConnection dbConnection)
        {
            this.database = database;
            this.dbConnection = dbConnection;
        }

        public BaseDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
        {
            this.database = database;
            this.dbConnection = dbConnection;
            this.dbTransaction = dbTransaction;
        }

        protected virtual string GetSequenceName()
        {
            throw new NotImplementedException();
        }

        protected virtual string GetTableName()
        {
            throw new NotImplementedException();
        }

        protected virtual string GetSequenceColName()
        {
            throw new NotImplementedException();
        }
        protected virtual string GetDomainObjectName()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Find all objects that match the given criteria.
        /// </summary>
        /// <typeparam name="TIdentity">Type of object used to identify
        /// the objects to find.</typeparam>
        /// <param name="selectionFactory">Factory object that can turn the
        /// identity object into the appropriate DbCommand.</param>
        /// <param name="domainObjectFactory">Factory object that can turn the
        /// returned result set into a domain object.</param>
        /// <param name="identity">Object that identifies which items to get.</param>
        /// <returns></returns>
        public IList<TDomainObject> Find(IDomainObjectFactory<TDomainObject> domainObjectFactory,
            Dictionary<string, BaseEntity> domainObjects,
            List<string> parameters,
            string query)
        {
            IList<TDomainObject> results = null;

            using (DbCommand command = ConstructCommand(domainObjects, parameters, query))
            {
                using (DataSet set = database.ExecuteDataSet(command))
                {
                    results = domainObjectFactory.Construct(set);
                }
            }
            return results;
        }
        public IList<TDomainObject> FindWithTransaction(IDomainObjectFactory<TDomainObject> domainObjectFactory,
            Dictionary<string, BaseEntity> domainObjects,
            List<string> parameters,
            string query)
        {
            IList<TDomainObject> results = null;

            using (DbCommand command = ConstructCommand(domainObjects, parameters, query))
            {
                using (DataSet set = database.ExecuteDataSet(command, dbTransaction))
                {
                    results = domainObjectFactory.Construct(set);
                }
            }
            return results;
        }

        /// <summary>
        /// Find all objects that match the given criteria.
        /// </summary>
        /// <typeparam name="TIdentity">Type of object used to identify
        /// the objects to find.</typeparam>
        /// <param name="selectionFactory">Factory object that can turn the
        /// identity object into the appropriate DbCommand.</param>
        /// <param name="domainObjectFactory">Factory object that can turn the
        /// returned result set into a domain object.</param>
        /// <param name="identity">Object that identifies which items to get.</param>
        /// <returns></returns>
        public IList<TDomainObject> Find(IDomainObjectFactory<TDomainObject> domainObjectFactory,
            Dictionary<string, BaseEntity> domainObjects,
            List<string> parameters,
            string query, ref int totalRecords)
        {
            IList<TDomainObject> results = null;

            using (DbCommand command = ConstructCommand(domainObjects, parameters, query))
            {
                using (DataSet set = database.ExecuteDataSet(command))
                {
                    results = domainObjectFactory.Construct(set, ref totalRecords);
                }
            }
            return results;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="domainObjectFactory"></param>
        /// <param name="cmd"></param>
        /// <returns></returns>
        public IList<TDomainObject> FindAll(IDomainObjectFactory<TDomainObject> domainObjectFactory, DbCommand cmd)
        {
            IList<TDomainObject> results = null;

            using (DbCommand command = cmd)
            {
                using (DataSet set = database.ExecuteDataSet(command))
                {
                    results = domainObjectFactory.Construct(set);
                }
            }
            return results;
        }

        /// <summary>
        /// Find all objects of specified object type.
        /// </summary>                
        /// <param name="domainObjectFactory">Factory object that can turn the returned result set into a domain object.</param>
        /// <param name="query">Query String to execute</param>
        /// <returns></returns>
        public IList<TDomainObject> FindAll(IDomainObjectFactory<TDomainObject> domainObjectFactory, string query)
        {
            IList<TDomainObject> results = null;

            using (DbCommand command = dbConnection.CreateCommand())
            {
                command.CommandText = query;

                using (DataSet set = database.ExecuteDataSet(command))
                {
                    results = domainObjectFactory.Construct(set);
                }
            }
            return results;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="domainObjectFactory"></param>
        /// <param name="query"></param>
        /// <param name="iTotalRecords"></param>
        /// <returns></returns>
        public IList<TDomainObject> FindAll(IDomainObjectFactory<TDomainObject> domainObjectFactory, string query, ref int iTotalRecords)
        {
            IList<TDomainObject> results = null;

            using (DbCommand command = dbConnection.CreateCommand())
            {
                command.CommandText = query;

                using (DataSet set = database.ExecuteDataSet(command))
                {
                    results = domainObjectFactory.Construct(set, ref iTotalRecords);
                }
            }
            return results;
        }

        public IList<TDomainObject> FindAll(IDomainObjectFactory<TDomainObject> domainObjectFactory, DbCommand dbCmd, ref int iTotalRecords)
        {
            IList<TDomainObject> results = null;

            using (DbCommand command = dbCmd)
            {
                using (DataSet set = database.ExecuteDataSet(command))
                {
                    results = domainObjectFactory.Construct(set, ref iTotalRecords);
                }
            }
            return results;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="domainObjectFactory"></param>
        /// <param name="query"></param>
        /// <param name="iStartIndex"></param>
        /// <param name="iPageSize"></param>
        /// <param name="sSortExpression"></param>
        /// <param name="iTotalRecords"></param>
        /// <returns></returns>
        public IList<TDomainObject> FindByPage(IDomainObjectFactory<TDomainObject> domainObjectFactory, string query, int iStartIndex, int iPageSize, string sSortExpression, ref int iTotalRecords)
        {
            IList<TDomainObject> results = null;

            using (DbCommand command = dbConnection.CreateCommand())
            {
                command.CommandText = query;

                using (DataSet set = database.ExecuteDataSet(command))
                {
                    //iTotalRecords = set.Tables[0].Rows.Count;
                    results = domainObjectFactory.Construct(set, ref iTotalRecords);
                }

            }
            return results;
        }

        public DataSet FindMetaData(string query)
        {
            using (DbCommand command = dbConnection.CreateCommand())
            {
                command.CommandText = query;
                command.CommandTimeout = 0;
                using (DataSet set = database.ExecuteDataSet(command))
                {
                    return set;
                }
            }

        }

        public DataSet FindMetaDataWithTransaction(string query)
        {
            using (DbCommand command = dbConnection.CreateCommand())
            {
                command.CommandText = query;
                command.Transaction = dbTransaction;

                using (DataSet set = database.ExecuteDataSet(command, dbTransaction))
                {
                    return set;
                }
            }

        }

        /// <summary>
        /// Find the first / only object that matches the given criteria.
        /// </summary>
        /// <typeparam name="TIdentity">Type of object used to identity the domain object desired.</typeparam>
        /// <param name="selectionFactory">Factory object that can turn
        /// the identity object into the appropriate DbCommand.</param>
        /// <param name="domainObjectFactory">Factory object that can turn the
        /// returned result set into a domain object.</param>
        /// <param name="identity">Object that identifies which item to get.</param>
        /// <returns>The domain object requested, or null if not found.</returns>
        public TDomainObject FindOne(IDomainObjectFactory<TDomainObject> domainObjectFactory,
            Dictionary<string, BaseEntity> domainObjects,
            List<string> parameters,
            string query)
        {

            TDomainObject result = default(TDomainObject);
            using (DbCommand command = ConstructCommand(domainObjects, parameters, query))
            {

                using (DataSet set = database.ExecuteDataSet(command))
                {
                    if (set.Tables[0].Rows.Count > 0)
                        result = domainObjectFactory.Construct(set)[0];
                }
            }
            return result;
        }

        /// <summary>
        /// FindOne with parameterized query
        /// </summary>
        /// <param name="domainObjectFactory"></param>
        /// <param name="cmd"></param>
        /// <returns></returns>
        public TDomainObject FindOne(IDomainObjectFactory<TDomainObject> domainObjectFactory, DbCommand cmd)
        {
            TDomainObject result = default(TDomainObject);

            using (DbCommand command = cmd)
            {
                using (DataSet set = database.ExecuteDataSet(command))
                {
                    if (domainObjectFactory.Construct(set).Count != 0)
                    {
                        result = domainObjectFactory.Construct(set)[0];
                    }
                }
            }
            return result;
        }



        /// <summary>
        /// Insert the given object into the database.
        /// </summary>
        /// <param name="insertFactory">Factory used to create the command.</param>
        /// <param name="domainObj">Domain object to insert</param>
        /// 
        //public int Add(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy)
        //{
        //    using (DbCommand command = ConstructInsertCommand(domainObjects, iCreatedBy, null))
        //    {
        //        System.Data.Common.DbParameter objectIDParameter = new OracleParameter(":ObjectID", DbType.Int32);
        //        objectIDParameter.Direction = ParameterDirection.Output;
        //        command.Parameters.Add(objectIDParameter);
        //        command.ExecuteNonQuery();
        //        return (int)objectIDParameter.Value;
        //    }
        //}
        public int SqlAdd(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy)
        {
            using (DbCommand command = ConstructInsertCommand(domainObjects, iCreatedBy, null))
            {
                object returnValue = 0;
                  returnValue= command.ExecuteScalar();
                return Convert.ToInt32(returnValue);
            }
        }

        //public int Add(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy, string ForeignKeyField, int ForeignKeyValue)
        //{
        //    Dictionary<string, object> foreignKeys = new Dictionary<string, object>();
        //    foreignKeys.Add(ForeignKeyField, ForeignKeyValue);
        //    using (DbCommand command = ConstructInsertCommand(domainObjects, iCreatedBy, foreignKeys))
        //    {
        //        System.Data.Common.DbParameter objectIDParameter = new OracleParameter(":ObjectID", DbType.Int32);
        //        objectIDParameter.Direction = ParameterDirection.Output;
        //        command.Parameters.Add(objectIDParameter);
        //        command.ExecuteNonQuery();
        //        return (int)objectIDParameter.Value;
        //    }
        //}

        //public int Add(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy, Dictionary<string, object> foreignKeys)
        //{
        //    using (DbCommand command = ConstructInsertCommand(domainObjects, iCreatedBy, foreignKeys))
        //    {

        //        System.Data.Common.DbParameter objectIDParameter = new OracleParameter(":ObjectID", DbType.Int32);
        //        objectIDParameter.Direction = ParameterDirection.Output;
        //        command.Parameters.Add(objectIDParameter);
        //        command.ExecuteNonQuery();
        //        return (int)objectIDParameter.Value;
        //    }
        //}

        public void Remove(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy)
        {
            using (DbCommand command = ConstructDeleteCommand(domainObjects, iCreatedBy))
            {
                int i = command.ExecuteNonQuery();
                if (i == 0)
                    throw new DAONoRecordFoundException();
            }
        }

        public void Save(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy)
        {
            using (DbCommand command = ConstructUpdateCommand(domainObjects, iCreatedBy))
            {
                int i = command.ExecuteNonQuery();
                if (i == 0)
                    throw new DAOConcurrencyViolationException();
                else
                {
                    BaseEntity domainObject = domainObjects[this.GetDomainObjectName()];
                    domainObject.Version_Number++;
                }

            }
        }

        public void Save(string query, DbCommand cmd)
        {
            cmd.CommandText = query;
            cmd.Transaction = dbTransaction;

            int i = cmd.ExecuteNonQuery();
            if (i == 0)
                throw new DAOConcurrencyViolationException();

        }

        /// <summary>
        /// Constructing select query using reflection
        /// </summary>
        /// <param name="domainObjects"></param>
        /// <param name="parameters"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        private DbCommand ConstructCommand(Dictionary<string, BaseEntity> domainObjects, List<string> parameters, string query)
        {
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandText = query;

            cmd.Parameters.Clear();

            foreach (string param in parameters)
            {
                string[] parts = param.Split(new char[] { '^' });

                BaseEntity domainObject = domainObjects[parts[0]];
                Type objectType = domainObject.GetType();

                PropertyInfo propertyInfo = objectType.GetProperty(parts[1]);

                bool flag = true;
                if ((propertyInfo.Name.ToString() == "LangPrefDB") || (propertyInfo.Name.ToString() == "LangPrefAPP")) //|| (propertyInfo.Name.ToString() == "userID"))
                    flag = false;

                if (flag)
                    if (!propertyInfo.PropertyType.Name.Contains("IList"))
                    {
                        if (propertyInfo.PropertyType.Name.Equals("String") || propertyInfo.PropertyType.Name.Equals("string") ||
                            propertyInfo.PropertyType.Name.Equals("DateTime") ||
                            propertyInfo.PropertyType.Name.Equals("Char"))
                            cmd.CommandText = cmd.CommandText.Replace(param.ToString(), "'" + propertyInfo.GetValue(domainObject, null).ToString().Trim() + "'");
                        else if (propertyInfo.PropertyType == typeof(bool) || ((propertyInfo.PropertyType == typeof(Boolean?) || propertyInfo.PropertyType == typeof(bool?)) && propertyInfo.GetValue(domainObject, null) != null))
                            cmd.CommandText = cmd.CommandText.Replace(param.ToString(), "'" + Convert.ToInt32(propertyInfo.GetValue(domainObject, null)).ToString().Trim() + "'");
                        else
                            cmd.CommandText = cmd.CommandText.Replace(param.ToString(), propertyInfo.GetValue(domainObject, null).ToString().Trim());
                    }
            }
            return cmd;
        }
        /// <summary>
        /// Creating update query using reflecting and Mapping Attributes
        /// </summary>
        /// <param name="domainObjects"></param>
        /// <param name="iCreatedBy"></param>
        /// <returns></returns>
        private DbCommand ConstructUpdateCommand(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy)
        {
            String tmpquery;
            StringBuilder objValues = new StringBuilder();
            // Creating a Command Object From Connection to participate in the current Transaction
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            ///
            // Getting Entity out of the Domain Objects Dictionary
            BaseEntity domainObject = domainObjects[this.GetDomainObjectName()];
            Type objectType = domainObject.GetType();

            // Navigating the Entity inorder to prepare Columns and values Clause 
            foreach (PropertyInfo propertyInfo in objectType.GetProperties())
            {
                if ((propertyInfo.GetValue(domainObject, null) == null) && (propertyInfo.PropertyType == typeof(DateTime) || propertyInfo.PropertyType == typeof(DateTime?)))// || ((propertyInfo.PropertyType == typeof(DateTime))))
                {
                    /// /////////////////// Do nothing.
                }
                else
                {
                    if (propertyInfo.GetCustomAttributes(true).Length > 0)
                    {
                        bool isTransient = false;
                        foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                        {
                            MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                            if (mappingInfoAttribute != null && mappingInfoAttribute.Transient)
                            {
                                isTransient = true;
                                break;
                            }
                        }
                        if (isTransient)
                            continue;
                    }
                    if (!propertyInfo.PropertyType.Name.Contains("IList"))
                    {
                        if (propertyInfo.PropertyType.BaseType == typeof(BaseEntity))
                        {
                            BaseEntity childDomainObject = (BaseEntity)propertyInfo.GetValue(domainObject, null);
                            Type childObjectType = propertyInfo.PropertyType;

                            #region Child Object

                            string primaryKeyIdentifier = string.Empty;
                            string foreignKeyIdentifier = string.Empty;

                            foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                            {
                                if (obj.GetType() == typeof(MappingInfoAttribute) &&
                                    !string.IsNullOrEmpty(((MappingInfoAttribute)obj).ColumnName))
                                {
                                    foreignKeyIdentifier = ((MappingInfoAttribute)obj).ColumnName;
                                    break;
                                }
                            }

                            foreach (Object obj in childObjectType.GetCustomAttributes(true))
                            {
                                if (obj.GetType() == typeof(ClassMappingAttribute) &&
                                !string.IsNullOrEmpty(((ClassMappingAttribute)obj).Identifier))
                                {
                                    primaryKeyIdentifier = ((ClassMappingAttribute)obj).Identifier;
                                    break;
                                }
                            }

                            if (string.IsNullOrEmpty(foreignKeyIdentifier))
                                foreignKeyIdentifier = primaryKeyIdentifier;

                            if (childDomainObject == null)
                            {
                                objValues.Append(foreignKeyIdentifier + "= NULL,");
                            }
                            else if (!string.IsNullOrEmpty(primaryKeyIdentifier))
                            {
                                foreach (PropertyInfo pInfo in childObjectType.GetProperties())
                                {
                                    bool isPrimaryKeyPropertyFound = false;
                                    foreach (Object childObj in pInfo.GetCustomAttributes(true))
                                    {
                                        if (childObj.GetType() == typeof(MappingInfoAttribute) &&
                                            !string.IsNullOrEmpty(((MappingInfoAttribute)childObj).ColumnName) &&
                                            ((MappingInfoAttribute)childObj).ColumnName == primaryKeyIdentifier)
                                        {
                                            objValues.Append(foreignKeyIdentifier + "= " + pInfo.GetValue(childDomainObject, null).ToString().Trim() + ",");
                                            isPrimaryKeyPropertyFound = true;
                                            break;
                                        }
                                    }

                                    if (isPrimaryKeyPropertyFound)
                                        break;
                                    else if (!isPrimaryKeyPropertyFound && pInfo.Name.Equals(primaryKeyIdentifier))
                                    {
                                        if (pInfo.GetValue(childDomainObject, null) != null)
                                        {
                                            objValues.Append(foreignKeyIdentifier + "= " + pInfo.GetValue(childDomainObject, null).ToString().Trim() + ",");
                                            break;
                                        }
                                    }
                                }
                            }

                            #endregion
                        }
                        else
                        {
                            if (propertyInfo.GetCustomAttributes(true).Length > 0)
                            {
                                foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                                {
                                    MappingInfoAttribute MappingInfoAttribute = obj as MappingInfoAttribute;

                                    if (MappingInfoAttribute != null)
                                    {
                                        if (MappingInfoAttribute.Transient)
                                            continue;
                                        else if (MappingInfoAttribute.IdentitySpecification)
                                            continue;
                                        else if (MappingInfoAttribute.ColumnName != "")
                                        {
                                            #region//Attribute Mapping
                                            if (propertyInfo.PropertyType == typeof(string) || propertyInfo.PropertyType == typeof(String) || propertyInfo.PropertyType == typeof(char)
                                                || propertyInfo.PropertyType == typeof(char?) || propertyInfo.PropertyType == typeof(Char))
                                            {
                                                if (propertyInfo.GetValue(domainObject, null) != null)
                                                {
                                                    string val = Convert.ToString(propertyInfo.GetValue(domainObject, null)).Trim();
                                                    val = VerifyStringValue(val);
                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= '" + val + "',");
                                                }
                                                else
                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= NULL,");
                                            }
                                            else if (propertyInfo.PropertyType.Name.Equals("enum"))
                                            {
                                                objValues.Append("'" + propertyInfo.GetValue(domainObject, null).GetHashCode().ToString().Trim() + "',");
                                            }
                                            else if (propertyInfo.PropertyType == typeof(DateTime) || propertyInfo.PropertyType == typeof(DateTime?))
                                            {
                                                if (MappingInfoAttribute.ColumnName.Equals("CREATED_ON") || MappingInfoAttribute.ColumnName.Equals("LAST_MODIFIED_DATE"))
                                                {
                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= GETDATE ( ),");
                                                    //objValues.Append(MappingInfoAttribute.ColumnName + "= sysdate,");GETDATE ( )
                                                }
                                                else
                                                {
                                                    string str = propertyInfo.GetValue(domainObject, null) == null ? DateTime.MinValue.ToString() : propertyInfo.GetValue(domainObject, null).ToString().Trim();
                                                    //string str, str2="";
                                                    //if (propertyInfo.GetValue(domainObject, null) != null)
                                                    //{
                                                    //    str = propertyInfo.GetValue(domainObject, null).ToString();
                                                    string str2 = MappingInfoAttribute.ColumnName + "=" + getDefaultDate(str) + ",";
                                                    //}
                                                    //string str2 = MappingInfoAttribute.ColumnName + "= to_date('" + str + "','mm/dd/yyyy hh:mi:ss am'),";

                                                    objValues.Append(str2);

                                                    //objValues.Append(MappingInfoAttribute.ColumnName + "= to_date('" + propertyInfo.GetValue(domainObject, null).ToString() + "','mm/dd/yyyy hh:mi:ss am'),");
                                                    ////objValues.Append("to_date('" + propertyInfo.GetValue(domainObject, null).ToString() + "','mm/dd/yyyy hh:mi:ss am'),");
                                                }
                                            }
                                            else if (propertyInfo.PropertyType == typeof(Boolean) || (propertyInfo.PropertyType == typeof(Boolean?)) ||
                                            propertyInfo.PropertyType == typeof(bool) || (propertyInfo.PropertyType == typeof(bool?)))
                                            {
                                                if (Convert.ToBoolean(propertyInfo.GetValue(domainObject, null)))
                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= '1',");
                                                else
                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= '0',");

                                            }
                                            else if (propertyInfo.PropertyType == typeof(Int32) || (propertyInfo.PropertyType == typeof(Int32?)) ||
                                                    propertyInfo.PropertyType == typeof(int) || (propertyInfo.PropertyType == typeof(int?)) ||
                                                    propertyInfo.PropertyType == typeof(Decimal) || (propertyInfo.PropertyType == typeof(Decimal?)) ||
                                                    propertyInfo.PropertyType == typeof(decimal) || (propertyInfo.PropertyType == typeof(decimal?)) ||
                                                    propertyInfo.PropertyType == typeof(Double) || (propertyInfo.PropertyType == typeof(Double?)) ||
                                                    propertyInfo.PropertyType == typeof(double) || (propertyInfo.PropertyType == typeof(double?))
                                                )
                                            {
                                                if (MappingInfoAttribute.ColumnName == "VERSION_NUMBER")
                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= " + (Convert.ToInt32(propertyInfo.GetValue(domainObject, null)) + 1).ToString().Trim() + " ,");
                                                else if (MappingInfoAttribute.ColumnName.Equals("CREATED_BY"))
                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= " + iCreatedBy + " ,");
                                                else if (MappingInfoAttribute.ColumnName.Equals("LAST_MODIFIED_BY"))
                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= " + iCreatedBy + " ,");
                                                else
                                                {
                                                    foreach (Object objClass in objectType.GetCustomAttributes(true))
                                                    {
                                                        ClassMappingAttribute classMappingAttribute = objClass as ClassMappingAttribute;

                                                        if (classMappingAttribute != null)
                                                        {
                                                            if (MappingInfoAttribute.ColumnName.Equals(classMappingAttribute.Identifier))
                                                            {
                                                                objValues.Append(classMappingAttribute.Identifier + "= " + propertyInfo.GetValue(domainObject, null).ToString().Trim() + " ,");
                                                                break;
                                                            }
                                                            else
                                                            {
                                                                if (propertyInfo.GetValue(domainObject, null) == null)
                                                                {
                                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= null,");
                                                                    break;
                                                                }
                                                                else
                                                                {
                                                                    objValues.Append(MappingInfoAttribute.ColumnName + "= " + propertyInfo.GetValue(domainObject, null).ToString().Trim() + " ,");
                                                                    break;
                                                                }
                                                            }
                                                        }

                                                    }

                                                }
                                            }
                                            else if (propertyInfo.PropertyType.IsEnum)
                                            {
                                                objValues.Append(MappingInfoAttribute.ColumnName + "= " + propertyInfo.GetValue(domainObject, null).GetHashCode().ToString().Trim() + " ,");
                                            }
                                            #endregion
                                            break;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                #region//Property Mapping

                                if (propertyInfo.PropertyType == typeof(string) || propertyInfo.PropertyType == typeof(String) || propertyInfo.PropertyType == typeof(char)
                                                || propertyInfo.PropertyType == typeof(char?) || propertyInfo.PropertyType == typeof(Char))
                                {
                                    if (propertyInfo.GetValue(domainObject, null) != null)
                                    {
                                        string val = Convert.ToString(propertyInfo.GetValue(domainObject, null)).Trim();
                                        val = VerifyStringValue(val);
                                        objValues.Append(propertyInfo.Name + "= '" + val + "',");
                                    }
                                    else
                                        objValues.Append(propertyInfo.Name + "= NULL,");
                                }
                                else if (propertyInfo.PropertyType == typeof(DateTime) || propertyInfo.PropertyType == typeof(DateTime?))
                                {
                                    if (propertyInfo.Name.Equals("CREATED_ON") || propertyInfo.Name.Equals("LAST_MODIFIED_DATE"))
                                    {
                                        objValues.Append(propertyInfo.Name + "= sysdate,");
                                    }
                                    else
                                    {
                                        //objValues.Append(propertyInfo.Name + "= to_date('" + propertyInfo.GetValue(domainObject, null).ToString() + "','mm/dd/yyyy hh:mi:ss am'),");
                                        objValues.Append(propertyInfo.Name + "= " + getDefaultDate(propertyInfo.GetValue(domainObject, null).ToString().Trim()) + ",");
                                        //objValues.Append("to_date('" + propertyInfo.GetValue(domainObject, null).ToString() + "','mm/dd/yyyy hh:mi:ss am'),");
                                    }
                                }
                                else if (propertyInfo.PropertyType == typeof(Boolean) || (propertyInfo.PropertyType == typeof(Boolean?)) ||
                                        propertyInfo.PropertyType == typeof(bool) || (propertyInfo.PropertyType == typeof(bool?)))
                                {
                                    if (Convert.ToBoolean(propertyInfo.GetValue(domainObject, null)))
                                        objValues.Append(propertyInfo.Name + "= '1',");
                                    else
                                        objValues.Append(propertyInfo.Name + "= '0',");

                                }
                                else if (propertyInfo.PropertyType == typeof(Int32) || (propertyInfo.PropertyType == typeof(Int32?)) ||
                                        propertyInfo.PropertyType == typeof(int) || (propertyInfo.PropertyType == typeof(int?)) ||
                                        propertyInfo.PropertyType == typeof(Decimal) || (propertyInfo.PropertyType == typeof(Decimal?)) ||
                                        propertyInfo.PropertyType == typeof(decimal) || (propertyInfo.PropertyType == typeof(decimal?)) ||
                                        propertyInfo.PropertyType == typeof(Double) || (propertyInfo.PropertyType == typeof(Double?)) ||
                                        propertyInfo.PropertyType == typeof(double) || (propertyInfo.PropertyType == typeof(double?))
                                    )
                                {
                                    if (propertyInfo.Name == "VERSION_NUMBER")
                                        objValues.Append(propertyInfo.Name + "= " + (Convert.ToInt32(propertyInfo.GetValue(domainObject, null)) + 1).ToString().Trim() + " ,");
                                    else if (propertyInfo.Name.ToUpper().Equals(CREATEDBY_COL_NAME.ToUpper()))
                                        objValues.Append(propertyInfo.Name + "= " + iCreatedBy + " ,");
                                    else if (propertyInfo.Name.ToUpper().Equals(MODIFIEDBY_COL_NAME.ToUpper()))
                                        objValues.Append(propertyInfo.Name + "= " + iCreatedBy + " ,");
                                    else
                                    {
                                        foreach (Object objClass in objectType.GetCustomAttributes(true))
                                        {
                                            ClassMappingAttribute classMappingAttribute = objClass as ClassMappingAttribute;

                                            if (classMappingAttribute != null)
                                            {
                                                if (propertyInfo.Name.Equals(classMappingAttribute.Identifier))
                                                {
                                                    objValues.Append(classMappingAttribute.Identifier + "= " + propertyInfo.GetValue(domainObject, null).ToString().Trim() + " ,");
                                                    break;
                                                }
                                                else
                                                {
                                                    if (propertyInfo.GetValue(domainObject, null) == null)
                                                    {
                                                        objValues.Append(propertyInfo.Name + "= null,");
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        objValues.Append(propertyInfo.Name + "= " + propertyInfo.GetValue(domainObject, null).ToString().Trim() + " ,");
                                                        break;
                                                    }
                                                }
                                            }

                                        }

                                    }
                                }
                                else if (propertyInfo.PropertyType.IsEnum)
                                {
                                    objValues.Append(propertyInfo.Name + "= " + propertyInfo.GetValue(domainObject, null).GetHashCode().ToString().Trim() + " ,");
                                }
                                #endregion
                            }

                        }
                    }
                }
            }
            objValues.Remove(objValues.Length - 1, 1);

            string identifier = string.Empty;

            foreach (Object obj in objectType.GetCustomAttributes(true))
            {
                ClassMappingAttribute classMappingAttribute = obj as ClassMappingAttribute;
                if (classMappingAttribute != null)
                {
                    identifier = classMappingAttribute.Identifier;
                }
            }
            foreach (PropertyInfo propertyInfo in objectType.GetProperties())
            {
                foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                {
                    MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                    if (mappingInfoAttribute != null && mappingInfoAttribute.ColumnName.Equals(identifier))
                    {
                        identifier = propertyInfo.Name;
                        break;
                    }
                }
            }

            tmpquery = "UPDATE " + this.GetTableName() + " SET " + objValues.ToString() + " WHERE " +
                this.GetSequenceColName() + " = " + objectType.GetProperty(identifier).GetValue(domainObject, null).ToString().Trim() + " AND " +
                VERSION_COL_NAME + " = " +
                objectType.GetProperty(VERSION_COL_NAME).GetValue(domainObject, null).ToString().Trim();
            cmd.CommandText = tmpquery;
            return cmd;

        }

        private DbCommand ConstructDeleteCommand(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy)
        {
            String tmpquery;
            StringBuilder objValues = new StringBuilder();
            // Creating a Command Object From Connection to participate in the current Transaction
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            ///
            // Getting Entity out of the Domain Objects Dictionary
            BaseEntity domainObject = domainObjects[this.GetDomainObjectName()];
            Type objectType = domainObject.GetType();

            tmpquery = "DELETE FROM " + this.GetTableName() + " WHERE " + this.GetSequenceColName() + " = " +
                        objectType.GetProperty(this.GetSequenceColName()).GetValue(domainObject, null).ToString().Trim();
            cmd.CommandText = tmpquery;
            return cmd;
        }

        //private DbCommand ConstructInsertCommand(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy, string ForeignKeyField, int? ForeignKeyValue)
        private DbCommand ConstructInsertCommand(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy, Dictionary<string, object> foreignKeys)
        {
            String tmpquery;
            StringBuilder objCloumn = new StringBuilder();
            StringBuilder objValues = new StringBuilder();
            // Creating a Command Object From Connection to participate in the current Transaction
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;

            ConstructInsertQuery(domainObjects, iCreatedBy, objCloumn, objValues);

            objCloumn.Remove(objCloumn.Length - 1, 1);
            objValues.Remove(objValues.Length - 1, 1);

            //if (!string.IsNullOrEmpty(ForeignKeyField) && ForeignKeyValue != null)
            //{
            //    objCloumn.Append("," + ForeignKeyField);
            //    objValues.Append("," + ForeignKeyValue);
            //}

            if (foreignKeys != null && foreignKeys.Count > 0)
            {
                foreach (KeyValuePair<string, object> foreignKey in foreignKeys)
                {
                    if (!string.IsNullOrEmpty(foreignKey.Key))
                    {
                        objCloumn.Append("," + foreignKey.Key);
                        string value = string.Empty;
                        if (foreignKey.Value != null)
                        {
                            if (foreignKey.Value.GetType() == typeof(int) || foreignKey.Value.GetType() == typeof(Int32) ||
                                foreignKey.Value.GetType() == typeof(long) || foreignKey.Value.GetType() == typeof(Int64))
                            {
                                value = foreignKey.Value.ToString();
                            }
                        }
                        if (!string.IsNullOrEmpty(value))
                            objValues.Append("," + value);
                        else
                            objValues.Append(",NULL");
                    }
                }
            }

            //tmpquery = "INSERT INTO " + this.GetTableName() + " (" + objCloumn.ToString() + ") VALUES (" + objValues + ") RETURNING " + this.GetSequenceColName() + " INTO :ObjectID";
            tmpquery = "INSERT INTO " + this.GetTableName() + " (" + objCloumn.ToString() + ") VALUES (" + objValues + ") ;SELECT @@IDENTITY ";
          
            cmd.CommandText = tmpquery;
            return cmd;
        }

        private void ConstructInsertQuery(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy, StringBuilder objCloumn, StringBuilder objValues)
        {
            // Getting Entity out of the Domain Objects Dictionary
            BaseEntity domainObject = domainObjects[this.GetDomainObjectName()];
            Type objectType = domainObject.GetType();

            // Navigating the Entity inorder to prepare Columns and values Clause 
            foreach (PropertyInfo propertyInfo in objectType.GetProperties())
            {
                if ((propertyInfo.GetValue(domainObject, null) == null) && (propertyInfo.PropertyType == typeof(DateTime) || propertyInfo.PropertyType == typeof(DateTime?)))// || ((propertyInfo.PropertyType == typeof(DateTime))))
                {
                    /// /////////////////// Do nothing.
                }
                else
                {
                    if (propertyInfo.GetCustomAttributes(true).Length > 0)
                    {
                        bool isTransient = false;
                        foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                        {
                            MappingInfoAttribute mappingInfoAttribute = obj as MappingInfoAttribute;
                            if (mappingInfoAttribute != null && mappingInfoAttribute.Transient)
                            {
                                isTransient = true;
                                break;
                            }
                        }
                        if (isTransient)
                            continue;
                    }
                    if (!propertyInfo.PropertyType.Name.Contains("IList") && !propertyInfo.PropertyType.Name.Contains("List"))
                    {
                        if (propertyInfo.PropertyType.BaseType == typeof(BaseEntity) )//|| propertyInfo.PropertyType.BaseType == typeof(BaseTemplate))
                        {

                            BaseEntity childDomainObject = (BaseEntity)propertyInfo.GetValue(domainObject, null);
                            if (childDomainObject != null)
                            {
                                Type childObjectType = childDomainObject.GetType();

                                #region Child Object

                                string primaryKeyIdentifier = string.Empty;
                                string foreignKeyIdentifier = string.Empty;

                                foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                                {
                                    if (obj.GetType() == typeof(MappingInfoAttribute) &&
                                        !string.IsNullOrEmpty(((MappingInfoAttribute)obj).ColumnName))
                                    {
                                        foreignKeyIdentifier = ((MappingInfoAttribute)obj).ColumnName;
                                        break;
                                    }
                                }

                                foreach (Object obj in childObjectType.GetCustomAttributes(true))
                                {
                                    if (obj.GetType() == typeof(ClassMappingAttribute) &&
                                    !string.IsNullOrEmpty(((ClassMappingAttribute)obj).Identifier))
                                    {
                                        primaryKeyIdentifier = ((ClassMappingAttribute)obj).Identifier;
                                        break;
                                    }
                                }

                                if (string.IsNullOrEmpty(foreignKeyIdentifier))
                                    foreignKeyIdentifier = primaryKeyIdentifier;

                                if (!string.IsNullOrEmpty(primaryKeyIdentifier))
                                {
                                    foreach (PropertyInfo pInfo in childObjectType.GetProperties())
                                    {
                                        bool isPrimaryKeyPropertyFound = false;
                                        foreach (Object childObj in pInfo.GetCustomAttributes(true))
                                        {
                                            if (childObj.GetType() == typeof(MappingInfoAttribute) &&
                                                !string.IsNullOrEmpty(((MappingInfoAttribute)childObj).ColumnName) &&
                                                ((MappingInfoAttribute)childObj).ColumnName == primaryKeyIdentifier)
                                            {
                                                objCloumn.Append(foreignKeyIdentifier + ",");
                                                objValues.Append(pInfo.GetValue(childDomainObject, null).ToString().Trim() + ",");
                                                isPrimaryKeyPropertyFound = true;
                                                break;
                                            }
                                        }


                                        if (isPrimaryKeyPropertyFound)
                                            break;
                                        else if (!isPrimaryKeyPropertyFound && pInfo.Name.Equals(primaryKeyIdentifier))
                                        {
                                            if (pInfo.GetValue(childDomainObject, null) != null)
                                            {
                                                objCloumn.Append(foreignKeyIdentifier + ",");
                                                objValues.Append(pInfo.GetValue(childDomainObject, null).ToString().Trim() + ",");
                                                break;
                                            }
                                        }
                                    }
                                }

                                #endregion
                            }
                        }
                        else
                        {

                            if (propertyInfo.GetCustomAttributes(true).Length > 0)
                            {
                                foreach (Object obj in propertyInfo.GetCustomAttributes(true))
                                {
                                    MappingInfoAttribute MappingInfoAttribute = obj as MappingInfoAttribute;

                                    if (MappingInfoAttribute != null)
                                    {
                                        if (MappingInfoAttribute.Transient)
                                            continue;
                                        else if (MappingInfoAttribute.IdentitySpecification)
                                            continue;
                                        else if (MappingInfoAttribute.ColumnName != "")
                                        {
                                            #region //Attribute Mappings
                                            objCloumn.Append(MappingInfoAttribute.ColumnName + ",");
                                            if (propertyInfo.PropertyType == typeof(string) || propertyInfo.PropertyType == typeof(String) || propertyInfo.PropertyType == typeof(char)
                                                || propertyInfo.PropertyType == typeof(char?) || propertyInfo.PropertyType == typeof(Char))
                                            {
                                                if (propertyInfo.GetValue(domainObject, null) != null)
                                                {
                                                    string val = Convert.ToString(propertyInfo.GetValue(domainObject, null)).Trim();
                                                    val = VerifyStringValue(val);
                                                    objValues.Append("'" + val + "',");
                                                }
                                                else
                                                    objValues.Append("NULL,");
                                            }
                                            else if (propertyInfo.PropertyType.Name.Equals("enum"))
                                            {
                                                objValues.Append("'" + propertyInfo.GetValue(domainObject, null).GetHashCode().ToString().Trim() + "',");
                                            }
                                            else if (propertyInfo.PropertyType == typeof(DateTime) || propertyInfo.PropertyType == typeof(DateTime?))
                                            {
                                                if (MappingInfoAttribute.ColumnName.Equals("CREATED_ON") || MappingInfoAttribute.ColumnName.Equals("LAST_MODIFIED_DATE"))
                                                {
                                                   // objValues.Append("sysdate,");
                                                    objValues.Append("GETDATE ( ),");
                                                    
                                                }
                                                else
                                                {
                                                    string str = propertyInfo.GetValue(domainObject, null) == null ? DateTime.MinValue.ToString() : propertyInfo.GetValue(domainObject, null).ToString().Trim();
                                                    string str2 = getDefaultDate(str) + ",";
                                                    objValues.Append(str2);
                                                }
                                            }
                                            else if (propertyInfo.PropertyType == typeof(Boolean) || (propertyInfo.PropertyType == typeof(Boolean?)) ||
                                            propertyInfo.PropertyType == typeof(bool) || (propertyInfo.PropertyType == typeof(bool?)))
                                            {
                                                if (Convert.ToBoolean(propertyInfo.GetValue(domainObject, null)))
                                                {
                                                    objValues.Append("'1',");
                                                }
                                                else
                                                {
                                                    objValues.Append("'0',");
                                                }
                                            }
                                            else if (propertyInfo.PropertyType == typeof(Int32) || (propertyInfo.PropertyType == typeof(Int32?)) ||
                                                    propertyInfo.PropertyType == typeof(int) || (propertyInfo.PropertyType == typeof(int?)) ||
                                                    propertyInfo.PropertyType == typeof(Decimal) || (propertyInfo.PropertyType == typeof(Decimal?)) ||
                                                    propertyInfo.PropertyType == typeof(decimal) || (propertyInfo.PropertyType == typeof(decimal?)) ||
                                                    propertyInfo.PropertyType == typeof(Double) || (propertyInfo.PropertyType == typeof(Double?)) ||
                                                    propertyInfo.PropertyType == typeof(double) || (propertyInfo.PropertyType == typeof(double?))
                                                )
                                            {
                                                if (!string.IsNullOrEmpty(this.GetSequenceName()) && MappingInfoAttribute.ColumnName == this.GetSequenceColName())
                                                {
                                                    objValues.Append(this.GetSequenceName() + ".nextval,");
                                                }
                                                else
                                                {
                                                    if (MappingInfoAttribute.ColumnName.Equals("CREATED_BY"))
                                                        objValues.Append(iCreatedBy + ",");
                                                    else if (MappingInfoAttribute.ColumnName.Equals("LAST_MODIFIED_BY"))
                                                        objValues.Append(iCreatedBy + " ,");
                                                    else if (propertyInfo.GetValue(domainObject, null) == null)
                                                    {
                                                        objValues.Append("null,");
                                                    }
                                                    else
                                                    {
                                                        objValues.Append(propertyInfo.GetValue(domainObject, null).ToString().Trim() + ",");
                                                    }

                                                }
                                            }
                                            else if (propertyInfo.PropertyType.IsEnum)
                                            {
                                                objValues.Append(propertyInfo.GetValue(domainObject, null).GetHashCode().ToString().Trim() + ",");
                                            }
                                            #endregion
                                            break;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                #region//Property Mapping

                                objCloumn.Append(propertyInfo.Name + ",");
                                if (propertyInfo.PropertyType == typeof(string) || propertyInfo.PropertyType == typeof(String) || propertyInfo.PropertyType == typeof(char)
                                                || propertyInfo.PropertyType == typeof(char?) || propertyInfo.PropertyType == typeof(Char))
                                {
                                    if (propertyInfo.GetValue(domainObject, null) != null)
                                    {
                                        string val = Convert.ToString(propertyInfo.GetValue(domainObject, null)).Trim();
                                        val = VerifyStringValue(val);
                                        objValues.Append("'" + val + "',");
                                    }
                                    else
                                        objValues.Append("NULL,");
                                }
                                else if (propertyInfo.PropertyType == typeof(DateTime) || propertyInfo.PropertyType == typeof(DateTime?))
                                {
                                    if (propertyInfo.Name.Equals("Created_On") || propertyInfo.Name.Equals("Last_Modified_Date"))
                                    {
                                        objValues.Append("sysdate,");
                                    }
                                    else
                                    {
                                        objValues.Append("to_date('" + propertyInfo.GetValue(domainObject, null).ToString().Trim() + "','mm/dd/yyyy hh:mi:ss am'),");
                                    }
                                }
                                else if (propertyInfo.PropertyType == typeof(Boolean) || (propertyInfo.PropertyType == typeof(Boolean?)) ||
                                        propertyInfo.PropertyType == typeof(bool) || (propertyInfo.PropertyType == typeof(bool?)))
                                {
                                    if (Convert.ToBoolean(propertyInfo.GetValue(domainObject, null)))
                                    {
                                        objValues.Append("'1',");
                                    }
                                    else
                                    {
                                        objValues.Append("'0',");
                                    }
                                }
                                else if (propertyInfo.PropertyType == typeof(Int32) || (propertyInfo.PropertyType == typeof(Int32?)) ||
                                        propertyInfo.PropertyType == typeof(int) || (propertyInfo.PropertyType == typeof(int?)) ||
                                        propertyInfo.PropertyType == typeof(Decimal) || (propertyInfo.PropertyType == typeof(Decimal?)) ||
                                        propertyInfo.PropertyType == typeof(decimal) || (propertyInfo.PropertyType == typeof(decimal?)) ||
                                        propertyInfo.PropertyType == typeof(Double) || (propertyInfo.PropertyType == typeof(Double?)) ||
                                        propertyInfo.PropertyType == typeof(double) || (propertyInfo.PropertyType == typeof(double?))
                                    )
                                {
                                    if (!string.IsNullOrEmpty(this.GetSequenceName()) && propertyInfo.Name == this.GetSequenceColName())
                                    {
                                        objValues.Append(this.GetSequenceName() + ".nextval,");
                                    }
                                    else
                                    {
                                        if (propertyInfo.Name.ToUpper().Equals(CREATEDBY_COL_NAME.ToUpper()))
                                            objValues.Append(iCreatedBy + ",");
                                        else if (propertyInfo.Name.ToUpper().Equals(MODIFIEDBY_COL_NAME.ToUpper()))
                                            objValues.Append(iCreatedBy + ",");
                                        else if (propertyInfo.GetValue(domainObject, null) == null)
                                        {
                                            objValues.Append("null,");
                                        }
                                        else
                                        {
                                            objValues.Append(propertyInfo.GetValue(domainObject, null).ToString().Trim() + ",");
                                        }

                                    }
                                }
                                else if (propertyInfo.PropertyType.IsEnum)
                                {
                                    objValues.Append(propertyInfo.GetValue(domainObject, null).GetHashCode().ToString().Trim() + ",");
                                }

                                #endregion
                            }

                        }
                    }
                }
            }
        }

        private static string VerifyStringValue(string val)
        {
            if (val != null && val.Contains("'"))
                val = val.Replace("'", "''");
            return val;
        }

        #region Commented out ConstructChildInsertCommand
        //private DbCommand ConstructChildInsertCommand(Dictionary<string, BaseEntity> domainObjects, int iCreatedBy, string ForeignKeyField, int ForeignKeyValue)
        //{
        //    String tmpquery;
        //    StringBuilder objCloumn = new StringBuilder();
        //    StringBuilder objValues = new StringBuilder();
        //    // Creating a Command Object From Connection to participate in the current Transaction
        //    DbCommand cmd = dbConnection.CreateCommand();
        //    cmd.Transaction = dbTransaction;
        //    ///
        //    // Getting Entity out of the Domain Objects Dictionary
        //    BaseEntity domainObject = domainObjects[this.GetDomainObjectName()];
        //    Type objectType = domainObject.GetType();

        //    // Navigating the Entity inorder to prepare Columns and values Clause 
        //    foreach (PropertyInfo propertyInfo in objectType.GetProperties())
        //    {
        //        if (!propertyInfo.PropertyType.Name.Contains("IList") && !propertyInfo.PropertyType.Name.Contains("List"))
        //        {
        //            if (propertyInfo.PropertyType.BaseType == typeof(BaseEntity))
        //            {
        //                BaseEntity childDomainObject = (BaseEntity)propertyInfo.GetValue(domainObject, null);
        //                if (childDomainObject != null)
        //                {
        //                    Type childObjectType = childDomainObject.GetType();

        //                    if (childObjectType.Equals(objectType))
        //                    {
        //                        #region SelfJoin

        //                        Object []selfObj = propertyInfo.GetCustomAttributes(true);
        //                        MappingInfoAttribute mapInfoAttribute = selfObj[0] as MappingInfoAttribute;

        //                        if (!mapInfoAttribute.Transient)
        //                        {
        //                            foreach (Object obj in childObjectType.GetCustomAttributes(true))
        //                            {
        //                                ClassMappingAttribute classMappingAttribute = obj as ClassMappingAttribute;

        //                                if (classMappingAttribute != null && classMappingAttribute.Identifier != "")
        //                                {
        //                                    foreach (PropertyInfo pInfo in childObjectType.GetProperties())
        //                                    {
        //                                        Object[] childObj = pInfo.GetCustomAttributes(true);
        //                                        MappingInfoAttribute mappingInfoAttribute = childObj[0] as MappingInfoAttribute;
        //                                        if (mappingInfoAttribute != null && mappingInfoAttribute.ColumnName != "")
        //                                        {
        //                                            if (mappingInfoAttribute.ColumnName.Equals(classMappingAttribute.Identifier))
        //                                            {
        //                                                if (pInfo.GetValue(childDomainObject, null) != null)
        //                                                {
        //                                                    objCloumn.Append(mapInfoAttribute.ColumnName + ",");
        //                                                    objValues.Append(pInfo.GetValue(childDomainObject, null).ToString() + ",");
        //                                                    break;
        //                                                }
        //                                            }
        //                                        }
        //                                    }

        //                                }
        //                            }
        //                        }
        //                        #endregion
        //                    }
        //                    else
        //                    {
        //                        #region Different Object
        //                        Object[] selfObj = propertyInfo.GetCustomAttributes(true);
        //                        MappingInfoAttribute mapInfoAttribute = selfObj[0] as MappingInfoAttribute;

        //                        if (!mapInfoAttribute.Transient)
        //                        {
        //                            foreach (Object obj in childObjectType.GetCustomAttributes(true))
        //                            {
        //                                ClassMappingAttribute classMappingAttribute = obj as ClassMappingAttribute;

        //                                if (classMappingAttribute != null && classMappingAttribute.Identifier != "")
        //                                {
        //                                    foreach (PropertyInfo pInfo in childObjectType.GetProperties())
        //                                    {
        //                                        foreach (Object childObj in pInfo.GetCustomAttributes(true))
        //                                        {
        //                                            if (childObj != null)
        //                                            {
        //                                                MappingInfoAttribute mappingInfoAttribute = childObj as MappingInfoAttribute;

        //                                                if (mappingInfoAttribute != null && mappingInfoAttribute.ColumnName != "")
        //                                                {
        //                                                    if (mappingInfoAttribute.ColumnName.Equals(classMappingAttribute.Identifier))
        //                                                    {
        //                                                        if (pInfo.GetValue(childDomainObject, null) != null)
        //                                                        {
        //                                                            objCloumn.Append(mapInfoAttribute.ColumnName + ",");
        //                                                            objValues.Append(pInfo.GetValue(childDomainObject, null).ToString() + ",");
        //                                                            break;
        //                                                        }
        //                                                    }
        //                                                }
        //                                            }
        //                                        }
        //                                        if (pInfo.Name.Equals(classMappingAttribute.Identifier))
        //                                        {
        //                                            if (pInfo.GetValue(childDomainObject, null) != null)
        //                                            {
        //                                                objCloumn.Append(pInfo.Name + ",");
        //                                                objValues.Append(pInfo.GetValue(childDomainObject, null).ToString() + ",");
        //                                                break;
        //                                            }
        //                                        }

        //                                    }

        //                                }
        //                            }
        //                        }
        //                        #endregion
        //                    }
        //                }
        //            }
        //            else
        //            {

        //                if (propertyInfo.GetCustomAttributes(true).Length > 0)
        //                {
        //                    foreach (Object obj in propertyInfo.GetCustomAttributes(true))
        //                    {
        //                        MappingInfoAttribute MappingInfoAttribute = obj as MappingInfoAttribute;

        //                        if (MappingInfoAttribute != null)
        //                        {
        //                            if (MappingInfoAttribute.Transient)
        //                                continue;
        //                            else if (MappingInfoAttribute.ColumnName != "")
        //                            {
        //                                #region //Attribute Mappings
        //                                objCloumn.Append(MappingInfoAttribute.ColumnName + ",");
        //                                if (propertyInfo.PropertyType.Name.Equals("string") || propertyInfo.PropertyType.Name.Equals("String") || propertyInfo.PropertyType.Name.Equals("Char") || propertyInfo.PropertyType.Name.Equals("char?"))
        //                                {
        //                                    objValues.Append("'" + propertyInfo.GetValue(domainObject, null).ToString() + "',");
        //                                }
        //                                else if (propertyInfo.PropertyType.Name.Equals("enum"))
        //                                {
        //                                    objValues.Append("'" + propertyInfo.GetValue(domainObject, null).GetHashCode().ToString() + "',");
        //                                }
        //                                else if (propertyInfo.PropertyType.Name.Equals("DateTime"))
        //                                {
        //                                    if (MappingInfoAttribute.ColumnName.Equals("CREATED_ON") || MappingInfoAttribute.ColumnName.Equals("LAST_MODIFIED_DATE"))
        //                                    {
        //                                        objValues.Append("sysdate,");
        //                                    }
        //                                    else
        //                                    {
        //                                        objValues.Append("to_date('" + propertyInfo.GetValue(domainObject, null).ToString() + "','mm/dd/yyyy hh:mi:ss am'),");
        //                                    }

        //                                }
        //                                else if (propertyInfo.PropertyType == typeof(Boolean) || (propertyInfo.PropertyType == typeof(Boolean?)) ||
        //                                propertyInfo.PropertyType == typeof(bool) || (propertyInfo.PropertyType == typeof(bool?)))
        //                                {
        //                                    if (Convert.ToBoolean(propertyInfo.GetValue(domainObject, null)))
        //                                    {
        //                                        objValues.Append("'1',");
        //                                    }
        //                                    else
        //                                    {
        //                                        objValues.Append("'0',");
        //                                    }
        //                                }
        //                                else if (propertyInfo.PropertyType.Name.Equals("Int32") || propertyInfo.PropertyType.Name.Equals("Int32?") ||
        //                                        propertyInfo.PropertyType.Name.Equals("int") || propertyInfo.PropertyType.Name.Equals("int?"))
        //                                {
        //                                    if (MappingInfoAttribute.ColumnName == this.GetSequenceColName())
        //                                    {
        //                                        objValues.Append(this.GetSequenceName() + ".nextval,");
        //                                    }
        //                                    else
        //                                    {
        //                                        if (MappingInfoAttribute.ColumnName.Equals("CREATED_BY"))
        //                                            objValues.Append(iCreatedBy + ",");
        //                                        else if (MappingInfoAttribute.ColumnName.Equals("LAST_MODIFIED_BY"))
        //                                            objValues.Append(iCreatedBy + " ,");
        //                                        else if (propertyInfo.GetValue(domainObject, null) == null)
        //                                        {
        //                                            objValues.Append("null,");
        //                                        }
        //                                        else
        //                                        {
        //                                            objValues.Append(propertyInfo.GetValue(domainObject, null).ToString() + ",");
        //                                        }

        //                                    }
        //                                }
        //                                #endregion
        //                                break;
        //                            }
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    #region//Property Mapping

        //                    objCloumn.Append(propertyInfo.Name + ",");
        //                    if (propertyInfo.PropertyType.Name.Equals("String") || propertyInfo.PropertyType.Name.Equals("string") || propertyInfo.PropertyType.Name.Equals("Char"))
        //                    {
        //                        objValues.Append("'" + propertyInfo.GetValue(domainObject, null).ToString() + "',");
        //                    }
        //                    else if (propertyInfo.PropertyType.Name.Equals("DateTime"))
        //                    {
        //                        if (propertyInfo.Name.Equals("Created_On") || propertyInfo.Name.Equals("Last_Modified_Date"))
        //                        {
        //                            objValues.Append("sysdate,");
        //                        }
        //                        else
        //                        {
        //                            objValues.Append("to_date('" + propertyInfo.GetValue(domainObject, null).ToString() + "','mm/dd/yyyy hh:mi:ss am'),");
        //                        }
        //                    }
        //                    else if (propertyInfo.PropertyType == typeof(Boolean) || (propertyInfo.PropertyType == typeof(Boolean?)) ||
        //                            propertyInfo.PropertyType == typeof(bool) || (propertyInfo.PropertyType == typeof(bool?)))
        //                    {
        //                        if (Convert.ToBoolean(propertyInfo.GetValue(domainObject, null)))
        //                        {
        //                            objValues.Append("'1',");
        //                        }
        //                        else
        //                        {
        //                            objValues.Append("'0',");
        //                        }
        //                    }
        //                    else if (propertyInfo.PropertyType == typeof(Int32) || (propertyInfo.PropertyType == typeof(Int32?)) ||
        //                            propertyInfo.PropertyType == typeof(int) || (propertyInfo.PropertyType == typeof(int?)))
        //                    {
        //                        if (propertyInfo.Name == this.GetSequenceColName())
        //                        {
        //                            objValues.Append(this.GetSequenceName() + ".nextval,");
        //                        }
        //                        else
        //                        {
        //                            if (propertyInfo.Name.ToUpper().Equals(CREATEDBY_COL_NAME.ToUpper()))
        //                                objValues.Append(iCreatedBy + ",");
        //                            else if (propertyInfo.GetValue(domainObject, null) == null)
        //                            {
        //                                objValues.Append("null,");
        //                            }
        //                            else
        //                            {
        //                                objValues.Append(propertyInfo.GetValue(domainObject, null).ToString() + ",");
        //                            }

        //                        }
        //                    }
        //                    #endregion
        //                }
        //            }
        //        }
        //    }
        //    objCloumn.Remove(objCloumn.Length - 1, 1);
        //    objValues.Remove(objValues.Length - 1, 1);

        //    tmpquery = "INSERT INTO " + this.GetTableName() + " (" + objCloumn.ToString() + ", " + ForeignKeyField + " ) VALUES (" + objValues + ", " + ForeignKeyValue + ") RETURNING " + this.GetSequenceColName() + " INTO :ObjectID";
        //    cmd.CommandText = tmpquery;
        //    return cmd;
        //}
        #endregion

        protected void HandleDBException(Exception ex)
        {
            if (ex is DbException)
            {
                if (ex.Message.Contains("ORA-00001"))
                {
                    throw new DAOUniqueConstraintException(ex.Message, ex);
                }
                else if (ex.Message.Contains("ORA-01403"))
                {
                    //Data not found ORA-01403
                    throw new DAOException("01403", ex);
                }
                else if (ex.Message.Contains("ORA-02292"))
                {
                    throw new DAOIntegrityConstraintException(ex.Message);
                }
                else
                {
                    throw new DAOException("1500", ex);
                }
            }
            else if (ex is ValidationException ||
                     ex is DAOConcurrencyViolationException ||
                     ex is DAONoRecordFoundException ||
                     ex is DAOExecutionStartedException ||
                     ex is DAOReferentialConstraintException)
                throw ex;
            else if (ex is CustomDAOException)
            {
                throw new DAOException(((CustomDAOException)ex).ErrorCode, ex);
            }
            else
                throw new DAOException("", ex);

        }
    }
}
