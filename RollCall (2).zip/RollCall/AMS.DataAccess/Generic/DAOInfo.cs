﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace DataAccess.Generic
{
    public class DAOInfo
    {
        private Database database = null;
        private DbConnection dbConnection = null;
        private DbTransaction transaction = null;
        //private DAOName dAOname;

        public Database Database
        {
            get { return database; }
            set { database = value; }
        }

        public DbConnection DbConnection
        {
            get { return dbConnection; }
            set { dbConnection = value; }
        }

        public DbTransaction Transaction
        {
            get { return transaction; }
            set { transaction = value; }
        }

        //public DAOName DAOname
        //{
        //    get { return dAOname; }
        //    set { dAOname = value; }
        //}
    }
}
