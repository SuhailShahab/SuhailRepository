﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.Business;


namespace DataAccess.Generic
{
    public class EntityInfo
    {
        BaseEntity entity = null;
        int startIndex = 0;
        int pageSize = 0;
        string sortExpression = "";
        int totalRecords = 0;
        int createdBy = 0;
        string list = "";

        public BaseEntity Entity
        {
            get { return entity; }
            set { entity = value; }
        }

        public int StartIndex
        {
            get { return startIndex; }
            set { startIndex = value; }
        }

        public int PageSize
        {
            get { return pageSize; }
            set { pageSize = value; }
        }

        public string SortExpression
        {
            get { return sortExpression; }
            set { sortExpression = value; }
        }

        public int TotalRecords
        {
            get { return totalRecords; }
            set { totalRecords = value; }
        }

        public int CreatedBy
        {
            get { return createdBy; }
            set { createdBy = value; }
        }

        public string List
        {
            get { return list; }
            set { list = value; }
        }
    }
}
