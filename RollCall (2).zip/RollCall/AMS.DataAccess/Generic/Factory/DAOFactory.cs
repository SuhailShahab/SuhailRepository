﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using AMS.DataAccess.Security;
using AMS.DataAccess.Teacher;
using AMS.DataAccess.Attendance;
using AMS.DataAccess.UserManagement;
using AMS.DataAccess.Reports;
using AMS.DataAccess.Messaging;
using AMS.DataAccess.Students;
using AMS.DataAccess.Configuration;



namespace DataAccess.Generic.Factory
{
    public class DAOFactory
    {
        private const string databaseInstance ="SqlDB";// "OracleDB";
        private static DAOFactory daoFactory;
        private Database database;

        public int userId;
        public string LangPrefDB;
        public string LangPrefAPP;

        private DAOFactory()
        {
            database = DatabaseFactory.CreateDatabase(databaseInstance);
        }

        public static DAOFactory Instance
        {
            get
            {
                if (daoFactory == null)
                    daoFactory = new DAOFactory();

                return daoFactory;
            }
        }
        public DbConnection Connection
        {
            get
            {
                DbConnection connection = database.CreateConnection();

                //connection.ConnectionString = "Data Source=Orc;Persist Security Info=True;User ID=ANTOMS;Password=ANTOMS";

                connection.Open();
                return connection;
            }
        }
       
        //#region Factory Decleration of Section
        public IUserDAO GetIUserDAO(DbConnection dbConnection, DbTransaction trans)
        {
            return new UserDAO(database, dbConnection, trans);
        }
        public IUserDAO GetIUserDAO(DbConnection dbConnection)
        {
            return new UserDAO(database, dbConnection);
        }
        public IClassTeacherDAO GetIClassTeacherDAO(DbConnection dbConnection, DbTransaction trans)
        {
            return new ClassTeacherDAO(database, dbConnection, trans);
        }
        public IClassTeacherDAO GetIClassTeacherDAO(DbConnection dbConnection)
        {
            return new ClassTeacherDAO(database, dbConnection);
        }
        public IStudentAttendaceDAO GetIStudentAttendaceDAO(DbConnection dbConnection, DbTransaction trans)
        {
            return new StudentAttendaceDAO(database, dbConnection, trans);
        }
         public IStudentAttendaceDAO GetIStudentAttendaceDAO(DbConnection dbConnection)
        {
            return new StudentAttendaceDAO(database, dbConnection);
        }
         public IPermissionDAO GetIPermissionDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new PermissionDAO(database, dbConnection, trans);
         }
         public IPermissionDAO GetIPermissionDAO(DbConnection dbConnection)
         {
             return new PermissionDAO(database, dbConnection);
         }
         public ILatePassDAL GetILatePassDAL(DbConnection dbConnection, DbTransaction trans)
         {
             return new LatePassDAL(database, dbConnection, trans);
         }
         public ILatePassDAL GetILatePassDAL(DbConnection dbConnection)
         {
             return new LatePassDAL(database, dbConnection);
         }
         public IReportDAO GetIReportDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new ReportDAO(database, dbConnection, trans);
         }
         public IReportDAO GetIReportDAO(DbConnection dbConnection)
         {
             return new ReportDAO(database, dbConnection);
         }
         public IMessageResponseDAO GetIMessageResponseDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new MessageResponseDAO(database, dbConnection, trans);
         }
         public IMessageResponseDAO GetIMessageResponseDAO(DbConnection dbConnection)
         {
             return new MessageResponseDAO(database, dbConnection);
         }
         public IClassCoordinatorDAO GetICoordinatorDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new ClassCoordinatorDAO(database, dbConnection, trans);
         }
         public IClassCoordinatorDAO GetICoordinatorDAO(DbConnection dbConnection)
         {
             return new ClassCoordinatorDAO(database, dbConnection);
         }
         public IMessageStatusDAO GetIEmailStatusDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new MessageStatusDAO(database, dbConnection, trans);
         }
         public IMessageStatusDAO GetIEmailStatusDAO(DbConnection dbConnection)
         {
             return new MessageStatusDAO(database, dbConnection);
         }
         public IEvacuationDAO GetIEvacuationDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new EvacuationDAO(database, dbConnection, trans);
         }
         public IEvacuationDAO GetIEvacuationDAO(DbConnection dbConnection)
         {
             return new EvacuationDAO(database, dbConnection);
         }
         public IMessageResponseDAO IMessageResponseDAO(DbConnection dbConnection)
         {
             return new MessageResponseDAO(database, dbConnection);
         }
         public IStudentDAO GetIStudentDAO(DbConnection dbConnection)
         {
             return new StudentDAO(database, dbConnection);
         }
         public IStudentDAO GetIStudentDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new StudentDAO(database, dbConnection, trans);
         }
         public IStudentGaurdianDAO GetIStudentGaurdianDAO(DbConnection dbConnection)
         {
             return new StudentGaurdianDAO(database, dbConnection);
         }
         public IStudentGaurdianDAO GetIStudentGaurdianDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new StudentGaurdianDAO(database, dbConnection, trans);
         }
         public ICampusDAO GetICampusDAO(DbConnection dbConnection)
         {
             return new CampusDAO(database, dbConnection);
         }
         public ICampusDAO GetICampusDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new CampusDAO(database, dbConnection, trans);
         }
         public IClassesDAO GetIClassesDAO(DbConnection dbConnection)
         {
             return new ClassesDAO(database, dbConnection);
         }
         public IClassesDAO GetIClassesDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new ClassesDAO(database, dbConnection, trans);
         }
         public ISectionDAO GetISectionDAO(DbConnection dbConnection)
         {
             return new SectionDAO(database, dbConnection);
         }
         public ISectionDAO GetISectionDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new SectionDAO(database, dbConnection, trans);
         }
         public ITermDAO GetITermDAO(DbConnection dbConnection)
         {
             return new TermDAO(database, dbConnection);
         }
         public ITermDAO GetITermDAO(DbConnection dbConnection, DbTransaction trans)
         {
             return new TermDAO(database, dbConnection, trans);
         }
        //#endregion 
       

    }
}
