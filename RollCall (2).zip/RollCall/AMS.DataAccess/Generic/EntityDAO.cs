﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.Business;

namespace DataAccess.Generic
{
    /// <summary>
    /// This class is used to define the methods for DAO's.
    /// </summary>
    public abstract class EntityDAO
    {

        /// <summary>
        /// This method is used to fetch the Entity collection based on given criteria filled in entityInfo object.
        /// </summary>
        /// <param name="entityInfo">entityInfo object.</param>
        /// <returns>List of all related entities </returns>
        public virtual IList<BaseEntity> GetAll(EntityInfo entityInfo) { return null; }

        /// <summary>
        /// This method is used to fetch the Entity based on given criteria filled in entityInfo object.
        /// </summary>
        /// <param name="entityInfo">entityInfo object.</param>
        /// <returns>List of all related entities </returns>
        public virtual IList<BaseEntity> Get(EntityInfo entityInfo) { return null; }
        /// <summary>
        /// This method is used to save a new entity in the database.
        /// </summary>
        /// <param name="entityInfo">Contained all information about the Object to be saved</param>
        /// <returns>Number of records saved</returns>
        public virtual int Insert(EntityInfo entityInfo) { return -1; }
        /// <summary>
        /// This method is used to update existing entity in the database.
        /// </summary>
        /// <param name="entityInfo">Contained all information about the Object to be updated</param>
        /// <returns>Nothing, throws exception in case of error or exception</returns>
        public virtual void Update(EntityInfo entityInfo) { }
        /// <summary>
        /// This method is used to delete existing entity in the database.
        /// </summary>
        /// <param name="entityInfo">Contained relavent information about the Object to be deleted</param>
        /// <returns>Nothing, throws exception in case of error or exception</returns>
        public virtual void Delete(EntityInfo entityInfo) { }
    }
}
