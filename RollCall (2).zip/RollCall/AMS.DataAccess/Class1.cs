﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.DataAccess
{
    public class Class1
    {
    }
}
