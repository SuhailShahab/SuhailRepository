﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Student;
using DataAccess.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;
using DataAccess.Exceptions;

namespace AMS.DataAccess.Students
{
    public interface IStudentGaurdianDAO
    {
        int insertStudentGaurdian(StudentGaurdian studentGaurdian, int studentId, int createdBy);
        int UpdateStudentGaurdian(StudentGaurdian StudnetGaurdian, int createdBy);
        int IsExist(int studentId);
    }
    public class StudentGaurdianDAO : BaseDAO<StudentGaurdian>, IStudentGaurdianDAO
    {
        string sp_Add = "SR_StudentGaurdian_Add";
        string sp_Update = "SR_StudentGaurdian_Update";
        public StudentGaurdianDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

        public StudentGaurdianDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }
        public int insertStudentGaurdian(StudentGaurdian studentGaurdian, int studentId, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_StudentId = cmd.CreateParameter();
            p_StudentId.ParameterName = "p_StudentId";
            p_StudentId.DbType = DbType.Int32;
            p_StudentId.Value = studentId;
            p_StudentId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StudentId);

            DbParameter p_MobileNumber = cmd.CreateParameter();
            p_MobileNumber.ParameterName = "p_MobileNumber";
            p_MobileNumber.DbType = DbType.String;
            p_MobileNumber.Value = studentGaurdian.CellNo;
            p_MobileNumber.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_MobileNumber);


            try
            {
                cmd.CommandText = sp_Add;

                cmd.ExecuteNonQuery();//.ExecuteNonQuery();
                //if (returnValue == null)
                //     throw new DAONoRecordFoundException();
                // i = Convert.ToInt32(returnValue);
            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }

        public int UpdateStudentGaurdian(StudentGaurdian studnetGaurdian, int createdBy)
        {
            int i = 0;
            DbCommand cmd = dbConnection.CreateCommand();
            cmd.Transaction = dbTransaction;
            cmd.CommandType = CommandType.StoredProcedure;

            DbParameter p_StudentGaurdianId = cmd.CreateParameter();
            p_StudentGaurdianId.ParameterName = "p_StudentGaurdianId";
            p_StudentGaurdianId.DbType = DbType.Int32;
            p_StudentGaurdianId.Value = studnetGaurdian.ID;
            p_StudentGaurdianId.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_StudentGaurdianId);

            DbParameter p_MobileNumber = cmd.CreateParameter();
            p_MobileNumber.ParameterName = "p_MobileNumber";
            p_MobileNumber.DbType = DbType.String;
            p_MobileNumber.Value = studnetGaurdian.CellNo;
            p_MobileNumber.Direction = ParameterDirection.Input;
            cmd.Parameters.Add(p_MobileNumber);

            try
            {
                cmd.CommandText = sp_Update;

                object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                if (returnValue == null)
                    throw new DAONoRecordFoundException();
                i = Convert.ToInt32(returnValue);

            }
            catch (Exception ex)
            {
                HandleDBException(ex);
            }
            return i;
        }


        public int IsExist(int studentId)
        {
            StringBuilder query = new StringBuilder();
            int Id = 0;

            #region Old Query
            query.Append(@"SELECT [StudentGaurdianId]     
                              FROM [dbo].[ST_StudentGaurdian]
                              Where StudentId = " + studentId);

            #endregion


            try
            {
                System.Data.DataSet set = FindMetaDataWithTransaction(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    if (!Convert.IsDBNull(tbl.Rows[0]["StudentGaurdianId"]))
                    {
                        Id = Convert.ToInt32(tbl.Rows[0]["StudentGaurdianId"]);
                    }
                    return Id;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return 0;
        }
    }
}
