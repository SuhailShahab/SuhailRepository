﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.Generic;
using AMS.BusinessEntities.Student;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using System.Data;
using DataAccess.Exceptions;

namespace AMS.DataAccess.Students
{
    public interface  IStudentDAO
    {
        int insertStudnet(Student student, int createdBy);
        int UpdateStudnet(Student student, int createdBy);
        int insertStudentClass(int studentId, int campusId, int classId, int sectionId, int termId, int createdBy);
        int UpdateStudentClass(int studentClassId, int studentId, int versionNo, int createdBy);
        int IsExsitStudentClass(int studentId, int classId, int sectionId, int termId);
        List<Student> GetAllStudent(Student studnet);
    }
    public class StudentDAO : BaseDAO<Student>, IStudentDAO
    {
        string sp_Add = "SR_Student_Add";
        string sp_UpdateStudent = "SR_Student_Update";
        string sp_AddtudentClass = "SR_Student_Classes_Add";
        string sp_UpdatetudentClass = "SR_Student_Classes_Update";
          public StudentDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

          public StudentDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

          public int insertStudnet(Student student, int createdBy)
          {
              int i = 0;
              DbCommand cmd = dbConnection.CreateCommand();
              cmd.Transaction = dbTransaction;
              cmd.CommandType = CommandType.StoredProcedure;

              DbParameter p_RegistrationNo = cmd.CreateParameter();
              p_RegistrationNo.ParameterName = "p_RegistrationNo";
              p_RegistrationNo.DbType = DbType.String;
              p_RegistrationNo.Value = student.RegistrationNo;
              p_RegistrationNo.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_RegistrationNo);

              DbParameter p_FirstName = cmd.CreateParameter();
              p_FirstName.ParameterName = "p_FirstName";
              p_FirstName.DbType = DbType.String;
              p_FirstName.Value = student.Name ;
              p_FirstName.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_FirstName);

              DbParameter p_LastName = cmd.CreateParameter();
              p_LastName.ParameterName = "p_LastName";
              p_LastName.DbType = DbType.String;
              p_LastName.Value = student.LastName;
              p_LastName.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_LastName);

              DbParameter p_MobileNumber = cmd.CreateParameter();
              p_MobileNumber.ParameterName = "p_MobileNumber";
              p_MobileNumber.DbType = DbType.String;
              if (string.IsNullOrEmpty(student.CellphoneNo))
              {
                  p_MobileNumber.Value = DBNull.Value;
              }
              else
              {
                  p_MobileNumber.Value = student.CellphoneNo;
              }
              p_MobileNumber.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_MobileNumber);

              DbParameter p_Email = cmd.CreateParameter();
              p_Email.ParameterName = "p_Email";
              p_Email.DbType = DbType.String;
              if (string.IsNullOrEmpty(student.Email ))
              {
                  p_Email.Value = DBNull.Value;
              }
              else
              {
                  p_Email.Value = student.Email;
              }
              p_Email.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_Email);

              DbParameter p_SmallPicture = cmd.CreateParameter();
              p_SmallPicture.ParameterName = "p_SmallPicture";
              p_SmallPicture.DbType = DbType.String;
              if (string.IsNullOrEmpty(student.SmallPicture))
              {
                  p_SmallPicture.Value = DBNull.Value;
              }
              else
              {
                  p_SmallPicture.Value = student.SmallPicture;
              }
              p_SmallPicture.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_SmallPicture);


              DbParameter p_LargePicture = cmd.CreateParameter();
              p_LargePicture.ParameterName = "p_LargePicture";
              p_LargePicture.DbType = DbType.String;
              if (string.IsNullOrEmpty(student.LargePicture))
              {
                  p_LargePicture.Value = DBNull.Value;
              }
              else
              {
                  p_LargePicture.Value = student.LargePicture;
              }
              p_SmallPicture.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_LargePicture);

              DbParameter p_CREATED_BY = cmd.CreateParameter();
              p_CREATED_BY.ParameterName = "p_CREATED_BY";
              p_CREATED_BY.DbType = DbType.Int32;
              p_CREATED_BY.Value = createdBy;
              p_CREATED_BY.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_CREATED_BY);

              DbParameter p_CampusId = cmd.CreateParameter();
              p_CampusId.ParameterName = "p_CampusId";
              p_CampusId.DbType = DbType.Int32;
              p_CampusId.Value = student.Campus.ID;
              p_CampusId.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_CampusId);

              try
              {
                  cmd.CommandText = sp_Add;

                  object returnValue = cmd.ExecuteScalar();//.ExecuteNonQuery();

                  if (returnValue == null)
                      throw new DAONoRecordFoundException();
                  i = Convert.ToInt32(returnValue);
              }
              catch (Exception ex)
              {
                  HandleDBException(ex);
              }
              return i;
          }

          public int UpdateStudnet(Student student, int createdBy)
          {
              int i = 0;
              DbCommand cmd = dbConnection.CreateCommand();
              cmd.Transaction = dbTransaction;
              cmd.CommandType = CommandType.StoredProcedure;

              DbParameter p_RegistrationNo = cmd.CreateParameter();
              p_RegistrationNo.ParameterName = "p_RegistrationNo";
              p_RegistrationNo.DbType = DbType.String;
              p_RegistrationNo.Value = student.RegistrationNo;
              p_RegistrationNo.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_RegistrationNo);

              DbParameter p_FirstName = cmd.CreateParameter();
              p_FirstName.ParameterName = "p_FirstName";
              p_FirstName.DbType = DbType.String;
              p_FirstName.Value = student.Name;
              p_FirstName.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_FirstName);

              DbParameter p_LastName = cmd.CreateParameter();
              p_LastName.ParameterName = "p_LastName";
              p_LastName.DbType = DbType.String;
              p_LastName.Value = student.LastName;
              p_LastName.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_LastName);

              DbParameter p_MobileNumber = cmd.CreateParameter();
              p_MobileNumber.ParameterName = "p_MobileNumber";
              p_MobileNumber.DbType = DbType.String;
              if (string.IsNullOrEmpty(student.CellphoneNo))
              {
                  p_MobileNumber.Value = DBNull.Value;
              }
              else
              {
                  p_MobileNumber.Value = student.CellphoneNo;
              }
              p_MobileNumber.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_MobileNumber);

              DbParameter p_Email = cmd.CreateParameter();
              p_Email.ParameterName = "p_Email";
              p_Email.DbType = DbType.String;
              if (string.IsNullOrEmpty(student.Email))
              {
                  p_Email.Value = DBNull.Value;
              }
              else
              {
                  p_Email.Value = student.Email;
              }
              p_Email.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_Email);

              DbParameter p_SmallPicture = cmd.CreateParameter();
              p_SmallPicture.ParameterName = "p_SmallPicture";
              p_SmallPicture.DbType = DbType.String;
              if (string.IsNullOrEmpty(student.SmallPicture))
              {
                  p_SmallPicture.Value = DBNull.Value;
              }
              else
              {
                  p_SmallPicture.Value = student.SmallPicture;
              }
              p_SmallPicture.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_SmallPicture);


              DbParameter p_LargePicture = cmd.CreateParameter();
              p_LargePicture.ParameterName = "p_LargePicture";
              p_LargePicture.DbType = DbType.String;
              if (string.IsNullOrEmpty(student.LargePicture))
              {
                  p_LargePicture.Value = DBNull.Value;
              }
              else
              {
                  p_LargePicture.Value = student.LargePicture;
              }

              p_SmallPicture.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_LargePicture);

              DbParameter p_IsActive = cmd.CreateParameter();
              p_IsActive.ParameterName = "p_IsActive";
              p_IsActive.DbType = DbType.String;
              p_IsActive.Value = Convert.ToInt32(student.IsActive);              
              p_IsActive.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_IsActive);

              DbParameter p_LAST_MODIFIED_BY = cmd.CreateParameter();
              p_LAST_MODIFIED_BY.ParameterName = "p_LAST_MODIFIED_BY";
              p_LAST_MODIFIED_BY.DbType = DbType.Int32;
              p_LAST_MODIFIED_BY.Value = createdBy;
              p_LAST_MODIFIED_BY.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_LAST_MODIFIED_BY);

              DbParameter p_VERSION_NUMBER = cmd.CreateParameter();
              p_VERSION_NUMBER.ParameterName = "p_VERSION_NUMBER";
              p_VERSION_NUMBER.DbType = DbType.Int32;
              p_VERSION_NUMBER.Value = student.Version_Number;
              p_VERSION_NUMBER.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_VERSION_NUMBER);

              DbParameter p_STUDENT_ID = cmd.CreateParameter();
              p_STUDENT_ID.ParameterName = "p_STUDENT_ID";
              p_STUDENT_ID.DbType = DbType.Int32;
              p_STUDENT_ID.Value = student.ID ;
              p_STUDENT_ID.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_STUDENT_ID);

              DbParameter p_CampusId = cmd.CreateParameter();
              p_CampusId.ParameterName = "p_CampusId";
              p_CampusId.DbType = DbType.Int32;
              p_CampusId.Value = student.Campus.ID;
              p_CampusId.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_CampusId);

              try
              {
                  cmd.CommandText = sp_UpdateStudent;

                  object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                  if (returnValue == null)
                      throw new DAONoRecordFoundException();
                  i = Convert.ToInt32(returnValue);

              }
              catch (Exception ex)
              {
                  HandleDBException(ex);
              }
              return i;
          }


          public List<Student> GetAllStudent(Student studnet)
          {
              StringBuilder query = new StringBuilder();

            
              #region  Query
//              query.Append(@"SELECT S.[StudentId]
//                            ,S.[RegistrationNo],S.[FirstName],S.[LastName],S.[MobileNumber],S.[Email],S.[SmallPicture],S.[LargePicture],S.[IsActive] ,S.[VERSION_NUMBER]
//                            ,G.StudentGaurdianId,G.MobileNumber 
//                            ,sc.StudentClassId ,sc.ClassId,C.Name CLASS_NAME ,sc.SectionId,SE.Name SE_NAME ,sc.TermId,sc.VERSION_NUMBER SC_VERSION_NO 
//                             FROM [SR_Students]S");
//              query.Append(@"INNER JOIN SR_Student_Classes SC
//                              ON S.StudentId = SC.StudentId
//                              LEFT JOIN ST_StudentGaurdian G
//                              ON S.StudentId = G.StudentId
//                              INNER JOIN Config_Class C
//                              ON C.ClassId = SC.ClassId 
//                              INNER JOIN Config_Section SE
//                              ON SC.SectionId = SE.SectionId");
//              query.Append("Where 1= 1 ");
//              query.Append(" AND sc.ClassId =  "+ studnet.StudnetClass.ID);
//              query.Append("and sc.SectionId = " + studnet.Section.ID);
//              query.Append(" AND ISNULL(sc.IsActive,1) =  "+ Convert.ToInt32(studnet.IsActiveStudentClass));
//              query.Append(" AND ISNULL(s.IsActive,1) =   " + Convert.ToInt32(studnet.IsActive));
//              query.Append("  Order by s.FirstName  ASC ;");
              query.Append(@"SELECT S.[StudentId]
                            ,S.[RegistrationNo],S.[FirstName],S.[LastName],S.[MobileNumber],S.[Email],S.[SmallPicture],S.[LargePicture],ISNULL(s.IsActive,1)IsActive  ,S.[VERSION_NUMBER]
                            ,G.StudentGaurdianId,G.MobileNumber G_MobileNumber 
                           ,sc.StudentClassId ,s.CampusId, sc.ClassId,sc.SectionId,sc.TermId,sc.VERSION_NUMBER SC_VERSION_NO
                             FROM [SR_Students]S");
              query.Append(@" INNER JOIN SR_Student_Classes SC
                              ON S.StudentId = SC.StudentId
                              INNER JOIN  Config_Terms tm ON  SC.TermId = tm.TermId 
                              LEFT JOIN ST_StudentGaurdian G
                              ON S.StudentId = G.StudentId ");
              query.Append("Where 1= 1 ");
              query.Append(" AND sc.ClassId =  " + studnet.StudnetClass.ID);
              query.Append(" and sc.SectionId = " + studnet.Section.ID);
              query.Append(" AND ISNULL(sc.IsActive,1) = 1 ");
              query.Append(" AND ISNULL(s.IsActive,1) = 1 ");
              query.Append(" AND s.CampusId =  " + studnet.Campus.ID);
              query.Append("AND ( tm.StartingDate <= CONVERT(VARCHAR, { fn NOW() }, 111) AND  CONVERT(VARCHAR, { fn NOW() }, 111)<= tm.EndingDate )");
              //query.Append(" AND ISNULL(sc.IsActive,1) =  " + Convert.ToInt32(studnet.IsActiveStudentClass));
              
             // query.Append(" AND ISNULL(s.IsActive,1) =   " + Convert.ToInt32(studnet.IsActive));
              query.Append("  Order by s.FirstName  ASC ;");
              #endregion
              List<Student> results = new List<Student>();

              try
              {
                  System.Data.DataSet set = FindMetaData(query.ToString());

                  System.Data.DataTable tbl = set.Tables[0];
                  if (tbl.Rows.Count > 0)
                  {
                      results = ConstructFactory(tbl);
                      return results;
                  }
                  else
                  {
                      return null;
                  }
              }
              catch (Exception ex)
              {
                  HandleDBException(ex);

              }
              return results;
          }
          public List<Student> ConstructFactory(DataTable dt)
          {
              List<Student> students = new List<Student>();

              for (int rowIndex = 0; rowIndex < dt.Rows.Count; rowIndex++)
              {
                  Student student = new Student();
                  if (dt.Columns.Contains("RegistrationNo") && !Convert.IsDBNull(dt.Rows[rowIndex]["RegistrationNo"]))
                  {
                      student.RegistrationNo  = Convert.ToString(dt.Rows[rowIndex]["RegistrationNo"]);
                  }
                  if (dt.Columns.Contains("StudentId") && !Convert.IsDBNull(dt.Rows[rowIndex]["StudentId"]))
                  {
                      student.ID = Convert.ToInt32(dt.Rows[rowIndex]["StudentId"]);
                  }
                  if (dt.Columns.Contains("FirstName") && !Convert.IsDBNull(dt.Rows[rowIndex]["FirstName"]))
                  {
                      student.Name  = Convert.ToString(dt.Rows[rowIndex]["FirstName"]);
                  }
                  if (dt.Columns.Contains("LastName") && !Convert.IsDBNull(dt.Rows[rowIndex]["LastName"]))
                  {
                      student.LastName = Convert.ToString(dt.Rows[rowIndex]["LastName"]);
                  }

                  if (dt.Columns.Contains("MobileNumber") && !Convert.IsDBNull(dt.Rows[rowIndex]["MobileNumber"]))
                  {
                      student.CellphoneNo  = Convert.ToString (dt.Rows[rowIndex]["MobileNumber"]);
                  }
                  if (dt.Columns.Contains("Email") && !Convert.IsDBNull(dt.Rows[rowIndex]["Email"]))
                  {
                      student.Email = Convert.ToString(dt.Rows[rowIndex]["Email"]);
                  }

                  if (dt.Columns.Contains("SmallPicture") && !Convert.IsDBNull(dt.Rows[rowIndex]["SmallPicture"]))
                  {
                      student.SmallPicture  = Convert.ToString(dt.Rows[rowIndex]["SmallPicture"]);
                  }

                  if (dt.Columns.Contains("LargePicture") && !Convert.IsDBNull(dt.Rows[rowIndex]["LargePicture"]))
                  {
                      student.LargePicture  = Convert.ToString(dt.Rows[rowIndex]["LargePicture"]);
                  }

                  if (dt.Columns.Contains("IsActive") && !Convert.IsDBNull(dt.Rows[rowIndex]["IsActive"]))
                  {
                      student.IsActive  = Convert.ToBoolean (dt.Rows[rowIndex]["IsActive"]);
                  }
                  if (dt.Columns.Contains("VERSION_NUMBER") && !Convert.IsDBNull(dt.Rows[rowIndex]["VERSION_NUMBER"]))
                  {
                      student.Version_Number = Convert.ToInt32 (dt.Rows[rowIndex]["VERSION_NUMBER"]);
                  }
                  student.StudentGaurdain = new StudentGaurdian();
                  if (dt.Columns.Contains("StudentGaurdianId") && !Convert.IsDBNull(dt.Rows[rowIndex]["StudentGaurdianId"]))
                  {
                      student.StudentGaurdain.ID = Convert.ToInt32(dt.Rows[rowIndex]["StudentGaurdianId"]);
                  }
                  if (dt.Columns.Contains("G_MobileNumber") && !Convert.IsDBNull(dt.Rows[rowIndex]["G_MobileNumber"]))
                  {
                      student.StudentGaurdain.CellNo = Convert.ToString(dt.Rows[rowIndex]["G_MobileNumber"]);
                  }
                  student.Campus = new BusinessEntities.Configuration.Campus();
                  if (dt.Columns.Contains("CampusId") && !Convert.IsDBNull(dt.Rows[rowIndex]["CampusId"]))
                  {
                      student.Campus.ID = Convert.ToInt32(dt.Rows[rowIndex]["CampusId"]);
                  }
                  student.StudnetClass = new BusinessEntities.Configuration.Classes();
                  if (dt.Columns.Contains("ClassId") && !Convert.IsDBNull(dt.Rows[rowIndex]["ClassId"]))
                  {
                      student.StudnetClass.ID = Convert.ToInt32(dt.Rows[rowIndex]["ClassId"]);
                  }
                  if (dt.Columns.Contains("CLASS_NAME") && !Convert.IsDBNull(dt.Rows[rowIndex]["CLASS_NAME"]))
                  {
                      student.StudnetClass.Name  = Convert.ToString (dt.Rows[rowIndex]["CLASS_NAME"]);
                  }
                  student.Section  = new BusinessEntities.Configuration.Section ();
                  if (dt.Columns.Contains("SectionId") && !Convert.IsDBNull(dt.Rows[rowIndex]["SectionId"]))
                  {
                      student.Section.ID = Convert.ToInt32(dt.Rows[rowIndex]["SectionId"]);
                  }
                  if (dt.Columns.Contains("CLASS_NAME") && !Convert.IsDBNull(dt.Rows[rowIndex]["CLASS_NAME"]))
                  {
                      student.Section.Name = Convert.ToString(dt.Rows[rowIndex]["CLASS_NAME"]);
                  }
                  student.Term = new BusinessEntities.Configuration.Term();
                  if (dt.Columns.Contains("TermId") && !Convert.IsDBNull(dt.Rows[rowIndex]["TermId"]))
                  {
                      student.Term.ID  = Convert.ToInt32(dt.Rows[rowIndex]["TermId"]);
                  }
                  students.Add(student);

              }
              return students;
          }


          public int insertStudentClass(int studentId, int campusId, int classId, int sectionId, int termId, int createdBy)
          {
              int i = 0;
              DbCommand cmd = dbConnection.CreateCommand();
              cmd.Transaction = dbTransaction;
              cmd.CommandType = CommandType.StoredProcedure;

              DbParameter p_StudentId = cmd.CreateParameter();
              p_StudentId.ParameterName = "p_StudentId";
              p_StudentId.DbType = DbType.Int32;
              p_StudentId.Value = studentId;
              p_StudentId.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_StudentId);

              DbParameter p_CampusId = cmd.CreateParameter();
              p_CampusId.ParameterName = "p_CampusId";
              p_CampusId.DbType = DbType.Int32;
              p_CampusId.Value = campusId;
              p_CampusId.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_CampusId);

              DbParameter p_ClassId = cmd.CreateParameter();
              p_ClassId.ParameterName = "p_ClassId";
              p_ClassId.DbType = DbType.Int32;
              p_ClassId.Value = classId;
              p_ClassId.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_ClassId);

              DbParameter p_SectionId = cmd.CreateParameter();
              p_SectionId.ParameterName = "p_SectionId";
              p_SectionId.DbType = DbType.Int32;
              p_SectionId.Value = sectionId;
              p_SectionId.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_SectionId);

              DbParameter p_TermId = cmd.CreateParameter();
              p_TermId.ParameterName = "p_TermId";
              p_TermId.DbType = DbType.Int32;
              p_TermId.Value = termId;
              p_TermId.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_TermId);         

              DbParameter p_CREATED_BY = cmd.CreateParameter();
              p_CREATED_BY.ParameterName = "p_CREATED_BY";
              p_CREATED_BY.DbType = DbType.Int32;
              p_CREATED_BY.Value = createdBy;
              p_CREATED_BY.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_CREATED_BY);

              try
              {
                  cmd.CommandText = sp_AddtudentClass;

                  object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                 // if (returnValue == null)
                  //    throw new DAONoRecordFoundException();
                //  i = Convert.ToInt32(returnValue);
              }
              catch (Exception ex)
              {
                  HandleDBException(ex);
              }
              return i;
          }


          public int UpdateStudentClass(int studentClassId, int studentId, int versionNo, int createdBy)
          {
              int i = 0;
              DbCommand cmd = dbConnection.CreateCommand();
              cmd.Transaction = dbTransaction;
              cmd.CommandType = CommandType.StoredProcedure;

              DbParameter p_StudentClassId = cmd.CreateParameter();
              p_StudentClassId.ParameterName = "p_StudentClassId";
              p_StudentClassId.DbType = DbType.Int32;
              p_StudentClassId.Value = studentClassId;
              p_StudentClassId.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_StudentClassId);

              DbParameter p_StudentId = cmd.CreateParameter();
              p_StudentId.ParameterName = "p_StudentId";
              p_StudentId.DbType = DbType.Int32;
              p_StudentId.Value = studentId;
              p_StudentId.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_StudentId);

              DbParameter p_VERSION_NUMBER = cmd.CreateParameter();
              p_VERSION_NUMBER.ParameterName = "p_VERSION_NUMBER";
              p_VERSION_NUMBER.DbType = DbType.Int32;
              p_VERSION_NUMBER.Value = versionNo;
              p_VERSION_NUMBER.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_VERSION_NUMBER);

              DbParameter p_CREATED_BY = cmd.CreateParameter();
              p_CREATED_BY.ParameterName = "p_CREATED_BY";
              p_CREATED_BY.DbType = DbType.Int32;
              p_CREATED_BY.Value = createdBy;
              p_CREATED_BY.Direction = ParameterDirection.Input;
              cmd.Parameters.Add(p_CREATED_BY);



              try
              {
                  cmd.CommandText = sp_UpdatetudentClass;

                  object returnValue = cmd.ExecuteNonQuery();//.ExecuteNonQuery();

                 // if (returnValue == null)
                   //   throw new DAONoRecordFoundException();
                  i = Convert.ToInt32(returnValue);

              }
              catch (Exception ex)
              {
                  HandleDBException(ex);
              }
              return i;
          }


          public int IsExsitStudentClass(int studentId, int classId, int sectionId, int termId)
          {
              StringBuilder query = new StringBuilder();
              int Id = 0;
              
              #region Old Query
              query.Append(@"SELECT [StudentClassId]
                            FROM [SR_Student_Classes] WHERE  ");
              query.Append(" [SectionId]= " + sectionId);
              query.Append(" AND [ClassId]= " + classId);
              query.Append("  AND [TermId] =  " + termId);
              query.Append("  AND [StudentId] = " + studentId);
              #endregion

             
              try
              {
                  System.Data.DataSet set = FindMetaDataWithTransaction(query.ToString());

                  System.Data.DataTable tbl = set.Tables[0];
                  if (tbl.Rows.Count > 0)
                  {
                      if (!Convert.IsDBNull(tbl.Rows[0]["StudentClassId"]))
                      {
                          Id = Convert.ToInt32(tbl.Rows[0]["StudentClassId"]);
                      }
                      return Id;
                  }
                  else
                  {
                      return 0;
                  }
              }
              catch (Exception ex)
              {
                  HandleDBException(ex);

              }
              return 0;
          }
    }
}
