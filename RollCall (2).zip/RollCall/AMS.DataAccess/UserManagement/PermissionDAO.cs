﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.UserManagement;
using DataAccess.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace AMS.DataAccess.UserManagement
{
    public interface  IPermissionDAO
    {
        List<Permissions> GetPermissionsById(int roleId);
    }
    public class PermissionDAO : BaseDAO<Permissions>, IPermissionDAO
    {
        
             public PermissionDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

             public PermissionDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }
        public List<Permissions> GetPermissionsById(int roleId)
        {
            StringBuilder query = new StringBuilder();

            query.Append(@"SELECT     UMS_Objects.ObjectId, UMS_Objects.Name, UMS_Objects.DisplayName,UMS_Objects.DeviceId, UMS_Permissions.PermissionId, UMS_Permissions.AddRight, UMS_Permissions.EditRight, 
                      UMS_Permissions.DeleteRight, UMS_Permissions.ViewRight 
                      FROM         UMS_Permissions INNER JOIN
                      UMS_Objects ON UMS_Permissions.ObjectId = UMS_Objects.ObjectId
                      where UMS_Permissions.RoleId = "+ roleId );

            List<Permissions> results = new List<Permissions>();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    for (int i=0; i < tbl.Rows.Count; i++)
                    {
                        Permissions permissions = new Permissions();
                        permissions.ID = Convert.ToInt32(tbl.Rows[i]["PermissionId"]);
                        permissions.ObjectName = new ObjectNames();
                        permissions.ObjectName.ID = Convert.ToInt32(tbl.Rows[i]["ObjectId"]);
                        permissions.ObjectName.Name = Convert.ToString(tbl.Rows[i]["Name"]);
                        permissions.ObjectName.DisplayName = Convert.ToString(tbl.Rows[i]["DisplayName"]);
                        permissions.ObjectName.Device = new BusinessEntities.Configuration.Device();
                        permissions.ObjectName.Device.ID = Convert.ToInt32(tbl.Rows[i]["DeviceId"]); 
                       // permissions .ObjectName.Device.Name = Convert.ToString(tbl.Rows[0]["Name"]);
                        permissions.AddRight = Convert.ToBoolean(tbl.Rows[i]["AddRight"]);
                        permissions.EditRight = Convert.ToBoolean(tbl.Rows[i]["EditRight"]);
                        permissions.DeleteRight = Convert.ToBoolean(tbl.Rows[i]["DeleteRight"]);
                        permissions.ViewRight = Convert.ToBoolean(tbl.Rows[i]["ViewRight"]);
                        results.Add(permissions);
                    }
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }
    }
}
