﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess.Generic;
using AMS.BusinessEntities.UserManagement;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace AMS.DataAccess.Security
{
    public interface  IUserDAO
    {
        User 
            
            GetUserByPassword(string userName,string password);
    }
    public class UserDAO : BaseDAO<User>, IUserDAO
    {
             public UserDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

             public UserDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

        public User GetUserByPassword(string userName, string password)
        {
            StringBuilder query = new StringBuilder();

            //query.Append("SELECT CampusId, [UserId],[RoleId],LoginUserId FROM [dbo].[UMS_Users] Where UserName = '" + userName + "' and Password = '" + password +"'" );
            query.Append("SELECT CampusId, [UserId],[RoleId],LoginUserId FROM [dbo].[UMS_Users] Where UserName = '" + userName + "'");

            User results = new User();

            try
            {
                System.Data.DataSet set = FindMetaData(query.ToString());

                System.Data.DataTable tbl = set.Tables[0];
                if (tbl.Rows.Count > 0)
                {
                    results.ID = Convert.ToInt32(tbl.Rows[0]["UserId"]);
                    results.Role = new Role();
                    results.Role.ID = Convert.ToInt32(tbl.Rows[0]["RoleId"]);
                    results.LoginUserId  = Convert.ToInt32(tbl.Rows[0]["LoginUserId"]);
                    results.CampusId = Convert.ToInt32(tbl.Rows[0]["CampusId"]);
                    return results;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                HandleDBException(ex);

            }
            return results;
        }
    }
}

