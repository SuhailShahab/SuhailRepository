﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;
using DataAccess.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace AMS.DataAccess.Configuration
{
    public interface  ICampusDAO
    {
        List<Campus> GetAllCampusesName();
    }
    public class CampusDAO : BaseDAO<Campus>, ICampusDAO
    {
        public CampusDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

        public CampusDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

        public List<Campus> GetAllCampusesName()
         {
             StringBuilder query = new StringBuilder();

             query.Append(@"Select CampusId ,CampusName  from  Config_Campus ");


             List<Campus> results = new List<Campus>();

             try
             {
                 System.Data.DataSet set = FindMetaData(query.ToString());

                 System.Data.DataTable tbl = set.Tables[0];
                 Campus campus;

                 foreach (System.Data.DataRow row in tbl.Rows)
                 {
                     campus = new Campus();

                     campus.ID = Convert.ToInt32(row["CampusId"]);
                     campus.CampusName = Convert.ToString(row["CampusName"]);

                     results.Add(campus);
                 }
                 return results;
             }
             catch (Exception ex)
             {
                 HandleDBException(ex);

             }

             // LogUtility.LogInfo(LoggingEvent.Information, "FillDepartment", "Leaving");

             return results;
         }
    }
}
