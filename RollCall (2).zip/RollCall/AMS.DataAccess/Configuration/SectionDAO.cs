﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;
using DataAccess.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace AMS.DataAccess.Configuration
{
    public interface  ISectionDAO
    {
        List<Section> GetAllSectionName();
    }
    public class SectionDAO : BaseDAO<Section>, ISectionDAO
    {
        public SectionDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

        public SectionDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

        public List<Section> GetAllSectionName()
         {
             StringBuilder query = new StringBuilder();

             query.Append(@"Select SectionId ,Name  from  Config_Section ");


             List<Section> results = new List<Section>();

             try
             {
                 System.Data.DataSet set = FindMetaData(query.ToString());

                 System.Data.DataTable tbl = set.Tables[0];
                 Section section;

                 foreach (System.Data.DataRow row in tbl.Rows)
                 {
                     section = new Section();

                     section.ID = Convert.ToInt32(row["SectionId"]);
                     section.Name = Convert.ToString(row["Name"]);

                     results.Add(section);
                 }
                 return results;
             }
             catch (Exception ex)
             {
                 HandleDBException(ex);

             }

             // LogUtility.LogInfo(LoggingEvent.Information, "FillDepartment", "Leaving");

             return results;
         }
    }
}
