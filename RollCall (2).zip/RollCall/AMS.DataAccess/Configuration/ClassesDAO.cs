﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;
using DataAccess.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace AMS.DataAccess.Configuration
{
    public interface  IClassesDAO
    {
        List<Classes> GetAllClassesName();
    }
    public class ClassesDAO : BaseDAO<Classes>, IClassesDAO
    {
         public ClassesDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

         public ClassesDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

         public List<Classes> GetAllClassesName()
         {
             StringBuilder query = new StringBuilder();

             query.Append(@"Select Name,ClassId  from Config_Class ");


             List<Classes> results = new List<Classes>();

             try
             {
                 System.Data.DataSet set = FindMetaData(query.ToString());

                 System.Data.DataTable tbl = set.Tables[0];
                 Classes classes;

                 foreach (System.Data.DataRow row in tbl.Rows)
                 {
                     classes = new Classes();

                     classes.ID = Convert.ToInt32(row["ClassId"]);
                     classes.Name = Convert.ToString(row["Name"]);

                     results.Add(classes);
                 }
                 return results;
             }
             catch (Exception ex)
             {
                 HandleDBException(ex);

             }

             // LogUtility.LogInfo(LoggingEvent.Information, "FillDepartment", "Leaving");

             return results;
         }
    }
}
