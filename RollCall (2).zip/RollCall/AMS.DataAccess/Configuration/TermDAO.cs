﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;
using DataAccess.Generic;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;

namespace AMS.DataAccess.Configuration
{
    public interface  ITermDAO
    {
        List<Term> GetAllTermName();
    }
    public class TermDAO : BaseDAO<Term>, ITermDAO
    {
         public TermDAO(Database database, DbConnection dbConnection, DbTransaction dbTransaction)
            : base(database, dbConnection, dbTransaction)
        {
        }

         public TermDAO(Database database, DbConnection dbConnection)
            : base(database, dbConnection)
        {
        }

         public List<Term> GetAllTermName()
         {
             StringBuilder query = new StringBuilder();

             query.Append(@"Select TermNo ,TermId,TermDescription  from Config_Terms ");


             List<Term> results = new List<Term>();

             try
             {
                 System.Data.DataSet set = FindMetaData(query.ToString());

                 System.Data.DataTable tbl = set.Tables[0];
                 Term term;

                 foreach (System.Data.DataRow row in tbl.Rows)
                 {
                     term = new Term();

                     term.TermDescription  = Convert.ToString(row["TermDescription"]);
                     term.TermNo = Convert.ToString(row["TermNo"]);
                     term.ID = Convert.ToInt32(row["TermId"]);

                     results.Add(term);
                 }
                 return results;
             }
             catch (Exception ex)
             {
                 HandleDBException(ex);

             }

             // LogUtility.LogInfo(LoggingEvent.Information, "FillDepartment", "Leaving");

             return results;
         }
    }
}
