﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using AMS.BusinessEntities.UserManagement;
using AMS.BusinessEntities.Teacher;
using AMS.BusinessEntities.Attendance;
using AMS.BusinessEntities.Messaging;
using AMS.BusinessEntities.Configuration;
using AMS.BusinessEntities.Student;

namespace BuisnessEntity.FillEvent
{
   public  class FillResponse
    {
        private User user;
        private List<ClassTeacher> classesTeacher;
        private List<StudentAttendace> studentsAttendace;
        private List<RollTimeAttendaceStatus> rollTimeStatuses;
        private RollTimeAttendaceStatus rollTimeStatus;
        private List<MessageResponse> messageResponses;
        private List<Evacuation> lstEvacuation;
        private List<Classes> classes;
        private List<Section> sections;
        private List<Term> terms;
        private List<Student> studnets;
        private List<Campus> campuses;

        public List<Campus> Campuses
        {
            get { return campuses; }
            set { campuses = value; }
        }

        public List<Student> Studnets
        {
            get { return studnets; }
            set { studnets = value; }
        }


        public List<Term> Terms
        {
            get { return terms; }
            set { terms = value; }
        }
        public List<Section> Sections
        {
            get { return sections; }
            set { sections = value; }
        }
        public List<Classes> Classes
        {
            get { return classes; }
            set { classes = value; }
        }
        public List<Evacuation> LstEvacuation
        {
            get { return lstEvacuation; }
            set { lstEvacuation = value; }
        }

        public List<MessageResponse> MessageResponses
        {
            get { return messageResponses; }
            set { messageResponses = value; }
        }

        

        public RollTimeAttendaceStatus RollTimeStatus
        {
            get { return rollTimeStatus; }
            set { rollTimeStatus = value; }
        }

        public List<RollTimeAttendaceStatus> RollTimeStatuses
        {
            get { return rollTimeStatuses; }
            set { rollTimeStatuses = value; }
        }

        public List<StudentAttendace> StudentsAttendace
        {
            get { return studentsAttendace; }
            set { studentsAttendace = value; }
        }

        public List<ClassTeacher> ClassesTeacher
        {
            get { return classesTeacher; }
            set { classesTeacher = value; }
        }

        public User User
        {
            get { return user; }
            set { user = value; }
        }
        //private List<Department> fillDepartments;
        //private List<BanK> fillBanks;
        //private List<BankBranch> fillBankBranchs;
        //private List<Allowance> fillAllowances;
        //private List<Designation> fillDesignations;
        //private List<VoucherType> fillVoucherType;
        //private List<FinancialYear> fillFinancialYear;
        //private string voucherCode;
        //private string employeeCode;
        //private List<SalaryPaidType> fillSalaryPaidType;
        //private List<ExcelSheetColumn> fillExcelSheet;
        //private DataTable fillExcelFileData;
        //private List<ExcelSheetColumn> fillSexcelSheetSetting;
        //private int voucherMstID;

        //public int VoucherMstID
        //{
        //    get { return voucherMstID; }
        //    set { voucherMstID = value; }
        //}

        //public List<ExcelSheetColumn> FillSexcelSheetSetting
        //{
        //    get { return fillSexcelSheetSetting; }
        //    set { fillSexcelSheetSetting = value; }
        //}

        //public DataTable FillExcelFileData
        //{
        //    get { return fillExcelFileData; }
        //    set { fillExcelFileData = value; }
        //}

        //public List<ExcelSheetColumn> FillExcelSheet
        //{
        //    get { return fillExcelSheet; }
        //    set { fillExcelSheet = value; }
        //}

        //public List<SalaryPaidType> FillSalaryPaidType
        //{
        //    get { return fillSalaryPaidType; }
        //    set { fillSalaryPaidType = value; }
        //}

        //public string EmployeeCode
        //{
        //    get { return employeeCode; }
        //    set { employeeCode = value; }
        //}

        //public string VoucherCode
        //{
        //    get { return voucherCode; }
        //    set { voucherCode = value; }
        //}

        //public List<FinancialYear> FillFinancialYear
        //{
        //    get { return fillFinancialYear; }
        //    set { fillFinancialYear = value; }
        //}

        //public List<VoucherType> FillVoucherType
        //{
        //    get { return fillVoucherType; }
        //    set { fillVoucherType = value; }
        //}

        //public List<Department> FillDepartments
        //{
        //    get { return fillDepartments; }
        //    set { fillDepartments = value; }
        //}
        

        //public List<BanK> FillBanks
        //{
        //    get { return fillBanks; }
        //    set { fillBanks = value; }
        //}
       

        //public List<BankBranch> FillBankBranchs
        //{
        //    get { return fillBankBranchs; }
        //    set { fillBankBranchs = value; }
        //}
        

        //public List<Allowance> FillAllowances
        //{
        //    get { return fillAllowances; }
        //    set { fillAllowances = value; }
        //}
       

        //public List<Designation> FillDesignations
        //{
        //    get { return fillDesignations; }
        //    set { fillDesignations = value; }
        //}
    }
}
