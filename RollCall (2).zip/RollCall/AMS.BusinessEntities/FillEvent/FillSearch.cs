﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.UserManagement;

namespace BuisnessEntity.FillEvent
{
   public  class FillSearch
    {
        private bool isGetUserInfo;
        private bool isGetTeacherClasses;
        private bool isFillStudentAttendanceByid;
        private bool isFillRoleTimeStatus;
        private bool isFillStudentAttendanceLateCount;
        private bool isFillMessageResponce;
        private bool isFillEvacuationData;
        private bool? isIncharge;
        private bool isFillClasses;
        private bool isFillSections;
        private bool isFillTerm;
        private bool isFillTeachersAndStudents;
        private bool isFillStudents;
        private bool isFillCampuses;
        private bool isGetStudentByCriateria;

        public bool IsGetStudentByCriateria
        {
            get { return isGetStudentByCriateria; }
            set { isGetStudentByCriateria = value; }
        }

        public bool IsFillCampuses
        {
            get { return isFillCampuses; }
            set { isFillCampuses = value; }
        }

        public bool IsFillStudents
        {
            get { return isFillStudents; }
            set { isFillStudents = value; }
        }

        public bool IsFillTeachersAndStudents
        {
            get { return isFillTeachersAndStudents; }
            set { isFillTeachersAndStudents = value; }
        }

        public bool IsFillTerm
        {
            get { return isFillTerm; }
            set { isFillTerm = value; }
        }
        public bool IsFillSections
        {
            get { return isFillSections; }
            set { isFillSections = value; }
        }
        public bool IsFillClasses
        {
            get { return isFillClasses; }
            set { isFillClasses = value; }
        }
        public bool? IsIncharge
        {
            get { return isIncharge; }
            set { isIncharge = value; }
        }

        public bool IsFillEvacuationData
        {
            get { return isFillEvacuationData; }
            set { isFillEvacuationData = value; }
        }

        public bool IsFillMessageResponce
        {
            get { return isFillMessageResponce; }
            set { isFillMessageResponce = value; }
        }

        public bool IsFillStudentAttendanceLateCount
        {
            get { return isFillStudentAttendanceLateCount; }
            set { isFillStudentAttendanceLateCount = value; }
        }

        public bool IsFillRoleTimeStatus
        {
            get { return isFillRoleTimeStatus; }
            set { isFillRoleTimeStatus = value; }
        }

        public bool IsFillStudentAttendanceByid
        {
            get { return isFillStudentAttendanceByid; }
            set { isFillStudentAttendanceByid = value; }
        }

        public bool IsGetTeacherClasses
        {
            get { return isGetTeacherClasses; }
            set { isGetTeacherClasses = value; }
        }

        public bool IsGetUserInfo
        {
            get { return isGetUserInfo; }
            set { isGetUserInfo = value; }
        }
        private bool isRefreshData;

        public bool IsRefreshData
        {
            get { return isRefreshData; }
            set { isRefreshData = value; }
        }
        //private bool fillDepartment;
        //private bool fillBank;
        //private bool fillBankBranch;
        //private bool fillDesignation;
        //private bool fillAllowance;
        //private bool fillDesignationByDepartmentId;
        //private bool fillDepartmentWithDesignation;
        //private bool isFillBankWithBranch;
        //private bool isFillVoucherType;
        //private bool isFillFinancialYear;
        //private bool isGetVoucherCode;
        //private bool isGetEmpoyeeCode;
        //private bool isFillSalaryType;
        //private bool isImportFile;
        //private bool isFillSheetName;
        //private bool isBindExcelFile;
        //private bool isGetExcelSheetSetting;
        //private bool isGetVoucherMstIdByVoucherNo;

        //public bool IsGetVoucherMstIdByVoucherNo
        //{
        //    get { return isGetVoucherMstIdByVoucherNo; }
        //    set { isGetVoucherMstIdByVoucherNo = value; }
        //}

        //public bool IsGetExcelSheetSetting
        //{
        //    get { return isGetExcelSheetSetting; }
        //    set { isGetExcelSheetSetting = value; }
        //}

        //public bool IsBindExcelFile
        //{
        //    get { return isBindExcelFile; }
        //    set { isBindExcelFile = value; }
        //}

        //public bool IsFillSheetName
        //{
        //    get { return isFillSheetName; }
        //    set { isFillSheetName = value; }
        //}

        //public bool IsImportFile
        //{
        //    get { return isImportFile; }
        //    set { isImportFile = value; }
        //}

        //public bool IsFillSalaryType
        //{
        //    get { return isFillSalaryType; }
        //    set { isFillSalaryType = value; }
        //}

        //public bool IsGetEmpoyeeCode
        //{
        //    get { return isGetEmpoyeeCode; }
        //    set { isGetEmpoyeeCode = value; }
        //}

        //public bool IsGetVoucherCode
        //{
        //    get { return isGetVoucherCode; }
        //    set { isGetVoucherCode = value; }
        //}

        //public bool IsFillFinancialYear
        //{
        //    get { return isFillFinancialYear; }
        //    set { isFillFinancialYear = value; }
        //}

        //public bool IsFillVoucherType
        //{
        //    get { return isFillVoucherType; }
        //    set { isFillVoucherType = value; }
        //}
        

        //public bool IsFillBankWithBranch
        //{
        //    get { return isFillBankWithBranch; }
        //    set { isFillBankWithBranch = value; }
        //}

        //public bool FillDepartmentWithDesignation
        //{
        //    get { return fillDepartmentWithDesignation; }
        //    set { fillDepartmentWithDesignation = value; }
        //}
       

        //public bool FillDesignationByDepartmentId
        //{
        //    get { return fillDesignationByDepartmentId; }
        //    set { fillDesignationByDepartmentId = value; }
        //}

        //public bool FillDepartment
        //{
        //    get { return fillDepartment; }
        //    set { fillDepartment = value; }
        //}
       
        //public bool FillBank
        //{
        //    get { return fillBank; }
        //    set { fillBank = value; }
        //}
       
        //public bool FillBankBranch
        //{
        //    get { return fillBankBranch; }
        //    set { fillBankBranch = value; }
        //}
       
        //public bool FillDesignation
        //{
        //    get { return fillDesignation; }
        //    set { fillDesignation = value; }
        //}
        

        //public bool FillAllowance
        //{
        //    get { return fillAllowance; }
        //    set { fillAllowance = value; }
        //}

        #region Criateria
        private User user;
        private int sectionId;
        private int classId;
        private int teacherId;
        private int campusId;
        private int rollTimeStatusId;
        private DateTime currentDate;
        private DateTime reportFromDate;
        private DateTime reportToDate;

        public DateTime ReportToDate
        {
            get { return reportToDate; }
            set { reportToDate = value; }
        }

        public DateTime ReportFromDate
        {
            get { return reportFromDate; }
            set { reportFromDate = value; }
        }
       

        public DateTime CurrentDate
        {
            get { return currentDate; }
            set { currentDate = value; }
        }

        public int RollTimeStatusId
        {
            get { return rollTimeStatusId; }
            set { rollTimeStatusId = value; }
        }
        public int CampusId
        {
            get { return campusId; }
            set { campusId = value; }
        }
        public int TeacherId
        {
            get { return teacherId; }
            set { teacherId = value; }
        }

        public int SectionId
        {
            get { return sectionId; }
            set { sectionId = value; }
        }  

        public int ClassId
        {
            get { return classId; }
            set { classId = value; }
        }

        public User User
        {
            get { return user; }
            set { user = value; }
        }
        #endregion

    }
}
