﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Student
{
    public class StudentGaurdian
    {
        private int id;
        private string cellNo;
        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string CellNo
        {
            get { return cellNo; }
            set { cellNo = value; }
        }
    }
}
