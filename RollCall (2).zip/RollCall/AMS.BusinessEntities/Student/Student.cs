﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;
using AMS.Business;

namespace AMS.BusinessEntities.Student
{
    [Serializable ]
    public class Student : BaseEntity
    {
        private int id;
        private string name;
        private string lastName;
        private string largePicture;
        private string smallPicture;
        private string cellphoneNo;
        private string email;
        private string registrationNo;      
        private Classes studnetClass;
        private bool isActiveStudentClass;
        private Term term;
        private bool isActive;
        private Section section;
        private StudentGaurdian studentGaurdain;
        private Campus campus;

        public Campus Campus
        {
            get { return campus; }
            set { campus = value; }
        }
        public StudentGaurdian StudentGaurdain
        {
            get { return studentGaurdain; }
            set { studentGaurdain = value; }
        }

        public bool IsActiveStudentClass
        {
            get { return isActiveStudentClass; }
            set { isActiveStudentClass = value; }
        }
        

        public Term Term
        {
            get { return term; }
            set { term = value; }
        }
        

        public bool IsActive
        {
            get { return isActive; }
            set { isActive = value; }
        }

        public Classes StudnetClass
        {
            get { return studnetClass; }
            set { studnetClass = value; }
        }
        public string RegistrationNo
        {
            get { return registrationNo; }
            set { registrationNo = value; }
        }
        
        public Section Section
        {
            get { return section; }
            set { section = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
       

        public string Email
        {
            get { return email; }
            set { email = value; }
        }       

        public string CellphoneNo
        {
            get { return cellphoneNo; }
            set { cellphoneNo = value; }
        }      

        public string SmallPicture
        {
            get { return smallPicture; }
            set { smallPicture = value; }
        }       

        public string LargePicture
        {
            get { return largePicture; }
            set { largePicture = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }       

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}
