﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.Business
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property, AllowMultiple = true)]
    public class ClassMappingAttribute : System.Attribute
    {
        public ClassMappingAttribute()
        {
            
        }

        private string identifier;

        public string Identifier
        {
            get { return identifier; }
            set { identifier = value; }
        }

        private string tableName = String.Empty;
        public string TableName
        {
            get
            {
                return tableName;
            }
            set
            {
                tableName = value;
            }
        }
    }
}
