﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BuisnessEntities.Common
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property, AllowMultiple = true)]
    public class MappingInfoAttribute : System.Attribute
    {
        public MappingInfoAttribute()
        {

        }

        private bool transient = false;
        private string selfJoin = String.Empty;
        private string columnName = String.Empty;
        private string datatype = String.Empty;
        private bool identitySpecification = false;

        
        public bool Transient
        {
            get { return transient; }
            set { transient = value; }
        }

        public string SelfJoin
        {
            get { return selfJoin; }
            set { selfJoin = value; }
        }


        public string ColumnName
        {
            get
            {
                return columnName;
            }
            set
            {
                columnName = value;
            }
        }


        public string DataType
        {
            get { return datatype; }
            set { datatype = value; }
        }

        public bool IdentitySpecification
        {
            get { return identitySpecification; }
            set { identitySpecification = value; }
        }


    }
}
