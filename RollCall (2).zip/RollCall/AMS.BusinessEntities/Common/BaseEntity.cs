﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using BuisnessEntities.Common;

namespace AMS.Business
{
    [Serializable]
    public class BaseEntity
    {
        private int versionNumber;
        private int createdBy;
        private DateTime createdOn;
        private int lastModifiedBy;
        private DateTime lastModifiedDate;
       

        [MappingInfo(ColumnName = "LAST_MODIFIED_BY", DataType = "int")]
        public int Last_Modified_By
        {
            get { return lastModifiedBy; }
            set { lastModifiedBy = value; }
        }

        [MappingInfo(ColumnName = "LAST_MODIFIED_DATE", DataType = "DateTime")]
        public DateTime Last_Modified_Date
        {
            get { return lastModifiedDate; }
            set { lastModifiedDate = value; }
        }
        [MappingInfo(ColumnName = "CREATED_BY", DataType = "int")]
        public int Created_By
        {
            get { return createdBy; }
            set { createdBy = value; }
        }
        [MappingInfo(ColumnName = "CREATED_ON", DataType = "DateTime")]
        public DateTime Created_On
        {
            get { return createdOn; }
            set { createdOn = value; }
        }
        [MappingInfo(ColumnName = "VERSION_NUMBER", DataType = "int")]
        public int Version_Number
       {
           get { return versionNumber; }
           set { versionNumber = value; }
       }
       
       

        
    }
}