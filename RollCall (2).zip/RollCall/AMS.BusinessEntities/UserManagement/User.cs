﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;

namespace AMS.BusinessEntities.UserManagement
{
   public  class User
    {
        private int id;
        private string userName;
        private string password;
        private Role role;
        private int loginUserId;
        private int campusId;

        public int CampusId
        {
            get { return campusId; }
            set { campusId = value; }
        }
        public int LoginUserId
        {
            get { return loginUserId; }
            set { loginUserId = value; }
        }
        //private UserType userType;

        //public UserType UserType
        //{
        //    get { return userType; }
        //    set { userType = value; }
        //}

        public Role Role
        {
            get { return role; }
            set { role = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }
    }
}
