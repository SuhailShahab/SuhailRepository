﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;

namespace AMS.BusinessEntities.UserManagement
{
   public  class ObjectNames
    {
        private int id;
        private string name;
        private string displayName;
        private Device device;

        public Device Device
        {
            get { return device; }
            set { device = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }       

        public string Name
        {
            get { return name; }
            set { name = value; }
        }       

        public string DisplayName
        {
            get { return displayName; }
            set { displayName = value; }
        }
    }
}
