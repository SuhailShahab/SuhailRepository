﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.UserManagement;

namespace AMS.BusinessEntities.UserManagement
{
   public  class Permissions
    {
        private int id;
        private bool viewRight;
        private bool deleteRight;
        private bool editRight;
        private bool addRight;
        private ObjectNames objectName;
       

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
       
        public ObjectNames ObjectName
        {
            get { return objectName; }
            set { objectName = value; }
        }
        

        public bool AddRight
        {
            get { return addRight; }
            set { addRight = value; }
        }
        

        public bool EditRight
        {
            get { return editRight; }
            set { editRight = value; }
        }
       

        public bool DeleteRight
        {
            get { return deleteRight; }
            set { deleteRight = value; }
        }
       

        public bool ViewRight
        {
            get { return viewRight; }
            set { viewRight = value; }
        }
    }
}
