﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.UserManagement
{
   public  class Role
    {
        private int id;
        private string name;
        private List<Permissions> userPermissions;

        public List<Permissions> UserPermissions
        {
            get { return userPermissions; }
            set { userPermissions = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}
