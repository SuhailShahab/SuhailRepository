﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.CustomEnum;
using AMS.BusinessEntities.Attendance;

namespace AMS.BusinessEntities.Messaging
{
  public   class MessageStatus
    {
        private int id;
        private MessageType messageType;
        private DateTime messageDate;
        private RollTimeAttendaceStatus rollTimeAttendaceStatus;
        private int campusId;

        public int CampusId
        {
            get { return campusId; }
            set { campusId = value; }
        }

        public MessageType MessageType
        {
            get { return messageType; }
            set { messageType = value; }
        }
        public DateTime MessageDate
        {
            get { return messageDate; }
            set { messageDate = value; }
        }
        public RollTimeAttendaceStatus RollTimeAttendaceStatus
        {
            get { return rollTimeAttendaceStatus; }
            set { rollTimeAttendaceStatus = value; }
        }

      public int ID
        {
            get { return id; }
            set { id = value; }
        }
        
    }
}
