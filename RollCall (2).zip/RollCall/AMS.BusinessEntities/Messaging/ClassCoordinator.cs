﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;
using AMS.BusinessEntities.Attendance;

namespace AMS.BusinessEntities.Messaging
{
    [Serializable]
   public  class ClassCoordinator
    {
        private int Id;
        private Employee employee;
        private Classes studentClass;
        private Section section;
        private bool isActive;
        private List<StudentAttendace> studnetsAttendace;

        public List<StudentAttendace> StudnetsAttendace
        {
            get { return studnetsAttendace; }
            set { studnetsAttendace = value; }
        }
        
        public int ID
        {
            get { return Id; }
            set { Id = value; }
        }

        public Employee Employee
        {
            get { return employee; }
            set { employee = value; }
        }

        public Classes StudentClass
        {
            get { return studentClass; }
            set { studentClass = value; }
        }        

        public Section Section
        {
            get { return section; }
            set { section = value; }
        }        

        public bool IsActive
        {
            get { return isActive; }
            set { isActive = value; }
        }
    }
}
