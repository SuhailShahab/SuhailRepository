﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Messaging
{
    [Serializable]
    public class MessageResponse
    {
        private int id;
        private Student.Student studnet;
        private string replayId;
        private Attendance.AttendanceStatus attendacneStatus;

        private string messageReply;
        private DateTime replyDate;
        private DateTime smsSendingDateTime;       
        private string destinationMobileNumber;
        private string sourceMobileNumber;
        private string refrenceNumber;
        private string twoWayMessageId;
        private bool actionPerformed;

        public bool ActionPerformed
        {
            get { return actionPerformed; }
            set { actionPerformed = value; }
        }
        public DateTime SmsSendingDateTime
        {
            get { return smsSendingDateTime; }
            set { smsSendingDateTime = value; }
        }

        public string TwoWayMessageId
        {
            get { return twoWayMessageId; }
            set { twoWayMessageId = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }


        public Student.Student Studnet
        {
            get { return studnet; }
            set { studnet = value; }
        }


        public string ReplayId
        {
            get { return replayId; }
            set { replayId = value; }
        }

        public string MessageReply
        {
            get { return messageReply; }
            set { messageReply = value; }
        }

        public DateTime ReplyDate
        {
            get { return replyDate; }
            set { replyDate = value; }
        }

        public string SourceMobileNumber
        {
            get { return sourceMobileNumber; }
            set { sourceMobileNumber = value; }
        }

        public string DestinationMobileNumber
        {
            get { return destinationMobileNumber; }
            set { destinationMobileNumber = value; }
        }

        public string RefrenceNumber
        {
            get { return refrenceNumber; }
            set { refrenceNumber = value; }
        }


        public Attendance.AttendanceStatus AttendacneStatus
        {
            get { return attendacneStatus; }
            set { attendacneStatus = value; }
        }
    }
}
