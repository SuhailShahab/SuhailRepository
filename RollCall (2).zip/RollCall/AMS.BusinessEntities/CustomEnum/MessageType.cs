﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.CustomEnum
{
   public enum  MessageType
    {
       None=0,
       Late=1,
       UnMark=2,
       AbsetnSMS=3
    }
}
