﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.CustomEnum
{
   public enum ReportType
    {
       None,
       DailyAttendanceReport,
       DailyAbsenteesReport,
       SummaryAbsentReport,
       StudentTotalLateAbsetnCount,
       PrimaryReport,
       SecondaryReport,
       StatsDailyReport,
       StatsSummaryReport

    }
}
