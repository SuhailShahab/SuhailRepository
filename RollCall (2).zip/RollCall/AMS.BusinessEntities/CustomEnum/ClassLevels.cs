﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.CustomEnum
{
   public enum  ClassLevels:int 
    {
        PrimaryLevel=1,
       SecondaryLevel=2
    }
}
