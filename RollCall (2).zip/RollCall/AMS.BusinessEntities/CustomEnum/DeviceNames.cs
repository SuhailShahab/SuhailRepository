﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.CustomEnum
{
  public enum  DeviceNames:int
    {
      DeskTop=1,
      iPhone=2
    }
}
