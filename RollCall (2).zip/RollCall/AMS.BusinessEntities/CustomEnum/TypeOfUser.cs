﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.Business.CustomEnums
{
public  enum  TypeOfUser:int
    {
    Admin =1,
    Teacher=2,
    Parent=3
    }
}
