﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.CustomEnum
{
    public enum    AttendaceStatus:int
    {
        UnMarked =1,
        Present=2,
        Absent=3,
        PresntLate=4,
        AbsentMedical=5,
        AbsentUnauthorised=6,
        AbsentCamp=7,
        EarlyLeaveMedical=8,
        EarlyLeaveParentalConsent=9,
        EarlyLeaveExternalSuspension=10,
        EarlyLeaveEducational=11,
        EarlyLeaveHalfDay=12,
        AbsentFamilyHoliday=13,
        AbsentMedicalwithCertificate=14,
        AbsentReligious=15,
        AbsentWorkExperience=16,
        AbsentParentalConsent=17,
        AbsentTruancy=18,
        AbsentEducational=19,
        AbsentExternalSuspension=20,
        EarlyLeave=21

    }
}
