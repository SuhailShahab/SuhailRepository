﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.CustomEnum
{
    public static  class RollTimeStatusName
    {
        public const string MoringRollTime = "Moring Roll Time";
        public const int MoringRollTimeId = 1;
        public const string EveningRollTime = "Evening Roll Time";
        public const int EveningRollTimeId = 2;

    }
}
