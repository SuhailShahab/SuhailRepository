﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.CustomEnum
{
    public static  class CssClassStatusName
    {
       public  const string None = "";
       public  const string green = "status green";
       public  const string red = "status red";
       public const string orange = "status orange";
       public const string minFotoGreen = "min_foto green";
       public const string minFotoRed = "min_foto red";
       public const string minFotoOrange = "min_foto orange";
    }
}
