﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.CustomEnum
{
    public enum  AttendanceCssClassName
    {
        None,
        green,
        red,
        orange
    }
}
