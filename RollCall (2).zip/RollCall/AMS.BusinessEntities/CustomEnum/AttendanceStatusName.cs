﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.CustomEnum
{
    public static class AttendanceStatusName
    {
        public static string PresentLate = "Late"; //"Present--Late";
        public static string AbsentMedical = "Absent--Medical";
        public static string AbsentCamp = "Absent--Camp";
        public static string AbsentUnauthorised = "Absent--Unauthorised";
        public static string EarlyLeaveMedical = "Early Leave--Medical";
        public static string EarlyLeaveParentalConsent = "Early Leave--Parental Consent";
        public static string EarlyLeaveExternalSuspension = "Early Leave--External Suspension";
        public static string EarlyLeaveEducational = "Early Leave--Educational";
        public static string EarlyLeaveHalfDay = "Early Leave--Half Day";
        public static string AbsentFamilyHoliday = "Absent--Family Holiday";
        public static string AbsentMedicalwithCertificate = "Absent--Medical with Certificate";
        public static string AbsentReligious = "Absent--Religious";
        public static string AbsentWorkExperience = "Absent--Work Experience";
        public static string AbsentParentalConsent = "Absent--Parental Consent";
        public static string AbsentTruancy = "Absent--Truancy";
        public static string AbsentEducational = "Absent--Educational";
        public static string AbsentExternalSuspension = "Absent--External Suspension";
        public static string EarlyLeave = "Early Leave";
    }
}
