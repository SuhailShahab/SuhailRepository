﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;

namespace AMS.BusinessEntities.Attendance
{
    [Serializable ]
  public class Evacuation
    {
        private int id;
        private DateTime attendanceDate;
        private RollTimeAttendaceStatus rollTimeAttendaceStatus;
        private AttendanceStatus attendanceStatus;
        private Student.Student student;
        private string attendanceTime;
        private AttendanceStatus evationStatus;
        private int versionNo;
        private DateTime createdOn;
        private DateTime modifiedBy;
        private StudentClassAssociation studentClassAssociation;
        private Section classSection;
        private Term term;
        private Classes studentClass;

        public Classes StudentClass
        {
            get { return studentClass; }
            set { studentClass = value; }
        }

        public Term Term
        {
            get { return term; }
            set { term = value; }
        }

        public Section ClassSection
        {
            get { return classSection; }
            set { classSection = value; }
        }

        public StudentClassAssociation StudentClassAssociation
        {
            get { return studentClassAssociation; }
            set { studentClassAssociation = value; }
        }

        public DateTime CreatedOn
        {
            get { return createdOn; }
            set { createdOn = value; }
        }

        public int VersionNo
        {
            get { return versionNo; }
            set { versionNo = value; }
        }
        public AttendanceStatus EvationStatus
        {
            get { return evationStatus; }
            set { evationStatus = value; }
        }

        public string AttendanceTime
        {
            get { return attendanceTime; }
            set { attendanceTime = value; }
        }


        public Student.Student Student
        {
            get { return student; }
            set { student = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }


        public RollTimeAttendaceStatus RollTimeAttendaceStatus
        {
            get { return rollTimeAttendaceStatus; }
            set { rollTimeAttendaceStatus = value; }
        }

        public AttendanceStatus AttendanceStatus
        {
            get { return attendanceStatus; }
            set { attendanceStatus = value; }
        }

        public DateTime AttendanceDate
        {
            get { return attendanceDate; }
            set { attendanceDate = value; }
        }

        public DateTime ModifiedBy
        {
            get { return modifiedBy; }
            set { modifiedBy = value; }
        }    
    }
}
