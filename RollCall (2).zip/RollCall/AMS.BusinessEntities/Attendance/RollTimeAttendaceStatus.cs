﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Attendance
{
    [Serializable]
   public  class RollTimeAttendaceStatus
    {
        private int id;
        private string name;
        private int startingHour;
        private int endingHour;

        public int  StartingHour
        {
            get { return startingHour; }
            set { startingHour = value; }
        }
       

        public int EndingHour
        {
            get { return endingHour; }
            set { endingHour = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}
