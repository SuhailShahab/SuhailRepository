﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Attendance
{
  public  class Employee
    {
        private int id;
        private string name;
        private string lastName;
        private string emailAddress;
        private string phoneNo;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
       

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }
       

        public string EmailAddress
        {
            get { return emailAddress; }
            set { emailAddress = value; }
        }       

        public string PhoneNo
        {
            get { return phoneNo; }
            set { phoneNo = value; }
        }
    }
}
