﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Attendance
{
     [Serializable]
  public  class AttendanceStatus
    {
        private int id;
        private string name;
        private string displayName;
        private string attendanceSymbol;
        private string statusCssClass;

        public string StatusCssClass
        {
            get { return statusCssClass; }
            set { statusCssClass = value; }
        }
        public string AttendanceSymbol
        {
            get { return attendanceSymbol; }
            set { attendanceSymbol = value; }
        }
        private string cssClass;

        public string CssClass
        {
            get { return cssClass; }
            set { cssClass = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string DisplayName
        {
            get { return displayName; }
            set { displayName = value; }
        }
    }
}
