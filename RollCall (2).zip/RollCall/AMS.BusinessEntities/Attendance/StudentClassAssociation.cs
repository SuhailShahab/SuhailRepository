﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;
using AMS.BusinessEntities.Teacher;

namespace AMS.BusinessEntities.Attendance
{
   public  class StudentClassAssociation
    {
        private int id;
        private Student.Student student;
        private Classes studentClass;
        private Section section;
        private Term term;
        private DateTime startDate;
        private DateTime endDate;
        private Campus campus;
        private AMS.BusinessEntities.Teacher.Teacher teacher;
        private RollTimeAttendaceStatus rollTimeAttendanceStatus;

        public RollTimeAttendaceStatus RollTimeAttendanceStatus
        {
            get { return rollTimeAttendanceStatus; }
            set { rollTimeAttendanceStatus = value; }
        }

        public AMS.BusinessEntities.Teacher.Teacher Teacher
        {
            get { return teacher; }
            set { teacher = value; }
        }

        public Campus Campus
        {
            get { return campus; }
            set { campus = value; }
        }


        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public DateTime EndDate
        {
            get { return endDate; }
            set { endDate = value; }
        }

       public Student.Student Student
       {
           get { return student; }
           set { student = value; }
       }
       public Classes StudentClass
       {
           get { return studentClass; }
           set { studentClass = value; }
       }

       public Section Section
       {
           get { return section; }
           set { section = value; }
       }

       public Term Term
       {
           get { return term; }
           set { term = value; }
       }

       public DateTime StartDate
       {
           get { return startDate; }
           set { startDate = value; }
       }
    }
}
