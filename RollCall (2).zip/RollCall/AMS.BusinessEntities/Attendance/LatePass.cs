﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Attendance
{
     [Serializable]
   public  class LatePass
    {
        private int id;
        private Student.Student student;
        private AttendanceStatus attendanceStatus;
        private RollTimeAttendaceStatus rolltimeStatus;
        private DateTime latePassDate;
        private DateTime latePassTime;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
       

        public Student.Student Student
        {
            get { return student; }
            set { student = value; }
        }
       

        public AttendanceStatus AttendanceStatus
        {
            get { return attendanceStatus; }
            set { attendanceStatus = value; }
        }
       

        public RollTimeAttendaceStatus RolltimeStatus
        {
            get { return rolltimeStatus; }
            set { rolltimeStatus = value; }
        }
       

        public DateTime LatePassDate
        {
            get { return latePassDate; }
            set { latePassDate = value; }
        }
       

        public DateTime LatePassTime
        {
            get { return latePassTime; }
            set { latePassTime = value; }
        }

    }
}
