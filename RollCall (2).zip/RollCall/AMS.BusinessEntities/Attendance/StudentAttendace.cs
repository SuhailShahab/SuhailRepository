﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;
using AMS.BusinessEntities.UserManagement;

namespace AMS.BusinessEntities.Attendance
{
     [Serializable]
   public  class StudentAttendace
    {
        private int id;
        private DateTime attendanceDate;
        private RollTimeAttendaceStatus rollTimeAttendaceStatus;
        private AttendanceStatus attendanceStatus;
        private Student.Student student;
        private DateTime startingDate;
        private DateTime endingDate;
        private string reason;
        private string reasonTitle;
        private string attendanceTime;
        private int totalLateInTerm;
        private int totalAbsentsInTerm;
        private Term term;
        private int totalYearlyLate;
        private int tolatYearlyAbsent;
        private int lateCount;
        private Employee employee;
        private Role userRole;

        public Role UserRole
        {
            get { return userRole; }
            set { userRole = value; }
        }

        public Employee Employee
        {
            get { return employee; }
            set { employee = value; }
        }
        

        public int LateCount
        {
            get { return lateCount; }
            set { lateCount = value; }
        }

        public int TotalYearlyLate
        {
            get { return totalYearlyLate; }
            set { totalYearlyLate = value; }
        }
       

        public int TolatYearlyAbsent
        {
            get { return tolatYearlyAbsent; }
            set { tolatYearlyAbsent = value; }
        }

        public Term Term
        {
            get { return term; }
            set { term = value; }
        }

        public int TotalAbsentsInTerm
        {
            get { return totalAbsentsInTerm; }
            set { totalAbsentsInTerm = value; }
        }

        public int TotalLateInTerm
        {
            get { return totalLateInTerm; }
            set { totalLateInTerm = value; }
        }

        public string AttendanceTime
        {
            get { return attendanceTime; }
            set { attendanceTime = value; }
        }

        public string ReasonTitle
        {
            get { return reasonTitle; }
            set { reasonTitle = value; }
        }

        public string Reason
        {
            get { return reason; }
            set { reason = value; }
        }

        public DateTime StartingDate
        {
            get { return startingDate; }
            set { startingDate = value; }
        }
      

        public DateTime EndingDate
        {
            get { return endingDate; }
            set { endingDate = value; }
        }
       
        //private List<AbsentReason> absentResons;

        //public List<AbsentReason> AbsentResons
        //{
        //    get { return absentResons; }
        //    set { absentResons = value; }
        //}

        public Student.Student Student
        {
            get { return student; }
            set { student = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }


        public RollTimeAttendaceStatus RollTimeAttendaceStatus
        {
            get { return rollTimeAttendaceStatus; }
            set { rollTimeAttendaceStatus = value; }
        }

        public AttendanceStatus AttendanceStatus
        {
            get { return attendanceStatus; }
            set { attendanceStatus = value; }
        }
        private string remarks;

        public string Remarks
        {
            get { return remarks; }
            set { remarks = value; }
        }

        public DateTime AttendanceDate
        {
            get { return attendanceDate; }
            set { attendanceDate = value; }
        }
       
    }
}
