﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Attendance
{
     [Serializable]
   public  class AbsentReason
    {
        private int id;
        private DateTime startDate;
        private DateTime endingDate;
        private string resson;

        public string Reason
        {
            get { return resson; }
            set { resson = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
       

        public DateTime StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }
        

        public DateTime EndingDate
        {
            get { return endingDate; }
            set { endingDate = value; }
        }
    }
}
