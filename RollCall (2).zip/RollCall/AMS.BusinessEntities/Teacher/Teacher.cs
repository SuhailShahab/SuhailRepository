﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;

namespace AMS.BusinessEntities.Teacher
{
  public class Teacher
    {
        private int id;
        private string cellNo;
        private string lastName;
        private string firstName;
        
        
        public int ID
        {
            get { return id; }
            set { id = value; }
        }        

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
      
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }       

        public string CellNo
        {
            get { return cellNo; }
            set { cellNo = value; }
        }
    }
}
