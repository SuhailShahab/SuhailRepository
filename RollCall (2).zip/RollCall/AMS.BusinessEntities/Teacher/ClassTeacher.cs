﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Configuration;

namespace AMS.BusinessEntities.Teacher
{
  public  class ClassTeacher
    {
        private int id;
        private bool isIncharge;
        private string classSectionName;
        private Section section;
        private Classes classes;
        private Campus campus;

        public Campus Campus
        {
            get { return campus; }
            set { campus = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
       

        public Classes Classes
        {
            get { return classes; }
            set { classes = value; }
        }
       

        public Section Section
        {
            get { return section; }
            set { section = value; }
        }
       

        public string ClassSectionName
        {
            get { return classSectionName; }
            set { classSectionName = value; }
        }
      

        public bool IsIncharge
        {
            get { return isIncharge; }
            set { isIncharge = value; }
        }
    }
}
