﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Configuration
{
   public  class Term
    {
        private int id;
        private string termNo;
        private string termYear;
        private DateTime startingDate;
        private DateTime endingDate;
        private string termDescription;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
       

        public string TermNo
        {
            get { return termNo; }
            set { termNo = value; }
        }
       

        public string TermYear
        {
            get { return termYear; }
            set { termYear = value; }
        }
       

        public DateTime StartingDate
        {
            get { return startingDate; }
            set { startingDate = value; }
        }
        

        public DateTime EndingDate
        {
            get { return endingDate; }
            set { endingDate = value; }
        }
       

        public string TermDescription
        {
            get { return termDescription; }
            set { termDescription = value; }
        }
    }
}
