﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Configuration
{
     [Serializable]
   public  class Classes
    {
        private int id;
        private string name;
        private bool isActive;

        public bool IsActive
        {
            get { return isActive; }
            set { isActive = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }        

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}
