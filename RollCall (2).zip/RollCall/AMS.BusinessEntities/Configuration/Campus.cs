﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Configuration
{
    public class Campus
    {

        private int id;
        private string campusName;
        private string campusCode;
        
        public int ID
        {
            get { return id; }
            set { id = value; }
        }


        public string CampusName
        {
            get { return campusName; }
            set { campusName = value; }
        }

        public string CampusCode
        {
            get { return campusCode; }
            set { campusCode = value; }
        }


    }
}
