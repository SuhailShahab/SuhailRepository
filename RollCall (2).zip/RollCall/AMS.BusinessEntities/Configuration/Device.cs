﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMS.BusinessEntities.Configuration
{
  public   class Device
    {
        private int Id;
        private string name;

        public int ID
        {
            get { return Id; }
            set { Id = value; }
        }       

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
    }
}
