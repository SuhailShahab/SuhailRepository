﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Timers;
using System.Configuration;
using AMS.BusinessEntities.Attendance;
using AMS.BusinessEntities.CustomEnum;
using AMS.BusinessEntities.Messaging;
using AMS.Business.Messaging;
using System.Collections;
using MessageService.Common;


namespace MessageService
{
    partial class AMSEmailService : ServiceBase
    {
        private Timer scheduleTimer = null;
        private DateTime lastRunUnMark;
        private DateTime lastRunLateSudent;
        private DateTime lastRunEveningUnMark;
        private DateTime SecondLastRunUnMark;
        private DateTime SecondLastEveningUnMark;
        //private bool flag;
        public AMSEmailService()
        {
            InitializeComponent();

            if (!System.Diagnostics.EventLog.SourceExists("EmailSource"))
            {
                System.Diagnostics.EventLog.CreateEventSource("EmailSource", "EmailLog");
            }
            this.eventLogEmail.Source = "EmailSource";
            this.eventLogEmail.Log = "EmailLog";
            int timeInterval = Convert.ToInt32(ConfigurationManager.AppSettings["TimeInterval"]);
            scheduleTimer = new Timer();
            scheduleTimer.Interval = TimeSpan.FromMinutes(timeInterval).TotalMilliseconds;
            scheduleTimer.Enabled = true;
            scheduleTimer.Elapsed += new ElapsedEventHandler(scheduleTimer_Elapsed);
           // scheduleTimer_Elapsed("", null);
            eventLogEmail.WriteEntry("initailize service... ");
        }


       
        protected void scheduleTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            temp();

        }

        public  void temp()
        {
           // OnStart(null);
            /*if (!System.Diagnostics.EventLog.SourceExists("EmailSource"))
            {
                System.Diagnostics.EventLog.CreateEventSource("EmailSource", "EmailLog");
            }
            this.eventLogEmail.Source = "EmailSource";
            this.eventLogEmail.Log = "EmailLog";
            int timeInterval = Convert.ToInt32(ConfigurationManager.AppSettings["TimeInterval"]);
            scheduleTimer = new Timer();
            scheduleTimer.Interval = TimeSpan.FromMinutes(timeInterval).TotalMilliseconds;
            scheduleTimer.Enabled = true;
            scheduleTimer.Elapsed += new ElapsedEventHandler(scheduleTimer_Elapsed);
            //scheduleTimer_Elapsed("", null);
            eventLogEmail.WriteEntry("initailize service... ");*/


            eventLogEmail.WriteEntry("scheduleTimer Fire... ");
            string morningTime = Convert.ToString(ConfigurationManager.AppSettings["MorningTime"]);
            string eveningTime = Convert.ToString(ConfigurationManager.AppSettings["EveningTime"]);
            string[] targeMorningTime = morningTime.Split(':');
            string[] targeEventingTime = eveningTime.Split(':');

            AMS.Business.Attendance.StudentAttendanceManager studentAttendanceManager = null;
            AMS.Business.Messaging.MessageResponseManager messageResponseManager = null;

            try
            {


                if (scheduleTimer != null && this.IsValidDayToSendEamil())
                {
                    studentAttendanceManager = new AMS.Business.Attendance.StudentAttendanceManager();
                    messageResponseManager = new AMS.Business.Messaging.MessageResponseManager();
                    List<AMS.BusinessEntities.Messaging.ClassCoordinator> classCoordinator = messageResponseManager.GetAllCoordinators();
                    //
                    // Late Student
                    //
                    if (lastRunLateSudent.Date < DateTime.Now.Date && DateTime.Now.Hour == 10)
                    {
                        DateTime formDate = DateTime.Now.AddDays(-6);
                        int totalSunday = CountSunday(formDate, 6);
                        if (totalSunday > 0)
                        {
                            formDate = formDate.AddDays(-totalSunday);
                        }
                        List<StudentAttendace> studentAttendance = studentAttendanceManager.GetLateStudentByDate(formDate, DateTime.Now);

                        if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                        {
                            OnTimedEventForLateStudent(studentAttendance, classCoordinator, formDate, DateTime.Now);
                            eventLogEmail.WriteEntry("send email for Late student... ");
                        }
                        lastRunLateSudent = DateTime.Now;
                    }

                    //
                    //Morning Unmark Email
                    //
                    if (IsValidTime(targeMorningTime))
                    {
                        int targetMorningMin = Convert.ToInt32(targeMorningTime[1]);


                        if (lastRunUnMark.Date < DateTime.Now.Date && Convert.ToInt32(targeMorningTime[0]) == DateTime.Now.Hour && DateTime.Now.Minute >= targetMorningMin && DateTime.Now.Minute <= (targetMorningMin + 15))
                        {
                            // ServiceEmailMethod();
                            List<StudentAttendace> studentAttendance = studentAttendanceManager.GetUnMarkStudents(RollTimeStatusName.MoringRollTimeId, AttendaceStatus.UnMarked.GetHashCode());
                            if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                            {
                                OnTimedEventForUnMarkStudent(studentAttendance, classCoordinator, RollTimeStatusName.MoringRollTime);
                              //  AddEmailSataus(messageResponseManager, RollTimeStatusName.MoringRollTimeId, MessageType.UnMark);
                                lastRunUnMark = DateTime.Now;
                                eventLogEmail.WriteEntry("send email for unmark morning... ");
                            }
                           
                        }
                        else if (SecondLastRunUnMark.Date < DateTime.Now.Date && Convert.ToInt32(targeMorningTime[0]) == DateTime.Now.Hour && DateTime.Now.Minute >= (targetMorningMin + 15) && DateTime.Now.Minute <= ((targetMorningMin + 15) + 15))
                        {
                            // ServiceEmailMethod();
                            List<StudentAttendace> studentAttendance = studentAttendanceManager.GetUnMarkStudents(RollTimeStatusName.MoringRollTimeId, AttendaceStatus.UnMarked.GetHashCode());
                            if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                            {
                                OnTimedEventForUnMarkStudent(studentAttendance, classCoordinator, RollTimeStatusName.MoringRollTime);
                                //  AddEmailSataus(messageResponseManager, RollTimeStatusName.MoringRollTimeId, MessageType.UnMark);
                                SecondLastRunUnMark = DateTime.Now;
                                eventLogEmail.WriteEntry("send email for unmark morning... ");
                            }

                        }

                    }
                    else
                    {
                        eventLogEmail.WriteEntry("scheduleTimer_Elapsed:Invalid Morning Time ");
                    }
                    //
                    //Evening Unmark Email
                    //
                 
                    if (IsValidTime(targeEventingTime) && scheduleTimer != null)
                    {
                        int targetEveningMin = Convert.ToInt32(targeEventingTime[1]);
                        if (lastRunEveningUnMark.Date < DateTime.Now.Date && Convert.ToInt32(targeEventingTime[0]) == DateTime.Now.Hour && DateTime.Now.Minute >= targetEveningMin && DateTime.Now.Minute <= (targetEveningMin + 15))
                        {
                            // ServiceEmailMethod();
                            List<StudentAttendace> studentAttendance = studentAttendanceManager.GetUnMarkStudents(RollTimeStatusName.EveningRollTimeId, AttendaceStatus.UnMarked.GetHashCode());
                            if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                            {
                                OnTimedEventForUnMarkStudent(studentAttendance, classCoordinator, RollTimeStatusName.EveningRollTime);
                              //  AddEmailSataus(messageResponseManager, RollTimeStatusName.EveningRollTimeId, MessageType.UnMark);
                                eventLogEmail.WriteEntry("send email for unmark evening... ");
                                lastRunEveningUnMark = DateTime.Now;
                            }
                        }
                        else if (SecondLastEveningUnMark.Date < DateTime.Now.Date && (Convert.ToInt32(targeEventingTime[0]) + 1) == DateTime.Now.Hour && DateTime.Now.Minute >= (targetEveningMin + 10) && DateTime.Now.Minute <= (targetEveningMin + 30))
                        {
                            // ServiceEmailMethod();
                            List<StudentAttendace> studentAttendance = studentAttendanceManager.GetUnMarkStudents(RollTimeStatusName.EveningRollTimeId, AttendaceStatus.UnMarked.GetHashCode());
                            if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                            {
                                OnTimedEventForUnMarkStudent(studentAttendance, classCoordinator, RollTimeStatusName.EveningRollTime);
                               // AddEmailSataus(messageResponseManager, RollTimeStatusName.EveningRollTimeId, MessageType.UnMark);
                                eventLogEmail.WriteEntry("send email for unmark evening... ");
                                SecondLastEveningUnMark = DateTime.Now;
                            }
                        }
                    }
                    //else
                    //{
                    //    eventLogEmail.WriteEntry("scheduleTimer_Elapsed:Invalid Eventing Time ");
                    //}

                }


            }
            catch (Exception ex)
            {
                scheduleTimer.Stop();
                eventLogEmail.WriteEntry("Executing Studnet Attendance batch job has failed. Following error found: " + ex.Message,EventLogEntryType.Error);
            }
        }

        public bool IsValidTime(string[] theTime)
        {
            int targeMin = Convert.ToInt32(theTime[1]);
            if (targeMin > 60)
            {
                return false;
            }
            return true;
        }
        protected override void OnStart(string[] args)
        {
            // TODO: Add code here to start your service.
            //flag = true;
           // System.Threading.Thread t = new System.Threading.Thread(new System.Threading.ThreadStart(scheduleTimer_Elapsed));
            //t.Start();
            System.Threading.Thread.Sleep(4000);
            lastRunUnMark = DateTime.Now.Date.AddDays(-1);
            lastRunLateSudent = DateTime.Now.Date.AddDays(-1);
            lastRunEveningUnMark = DateTime.Now.Date.AddDays(-1);
            SecondLastRunUnMark = DateTime.Now.Date.AddDays(-1);
            SecondLastEveningUnMark = DateTime.Now.Date.AddDays(-1);
            if(scheduleTimer ==null)
                scheduleTimer = new Timer();
            scheduleTimer.Start();
            eventLogEmail.WriteEntry("Started");
        }

        protected override void OnStop()
        {
            // TODO: Add code here to perform any tear-down necessary to stop your service.
            scheduleTimer.Stop();
            eventLogEmail.WriteEntry("Stopped");
        }

        protected override void OnShutdown()
        {
            scheduleTimer.Stop();
            eventLogEmail.WriteEntry("ShutDowned");
        }

        protected override void OnContinue()
        {
            scheduleTimer.Start(); ;
            eventLogEmail.WriteEntry("Continuing");
        }

        protected override void OnPause()
        {
            scheduleTimer.Stop();
            eventLogEmail.WriteEntry("Paused");
        }

        #region cusotm Methods
        public static void OnTimedEventForUnMarkStudent(List<StudentAttendace> studnetsAttendance, List<ClassCoordinator> coordinators, string rollTimeStatusName)
        {
            // BusinessManager businessManager = new BusinessManager();
            StringBuilder sbEmailBody = new StringBuilder();
            // bool isSendEmail = false;
            try
            {
                // businessManager.ExecuteLicenseBatchJob();
                IList<string> tolist = new List<string>();
                #region Web config element getting recipient persons email
                Hashtable htblCoordinators = GetClassCoordinatorsWithClassSection(coordinators);
                Hashtable htblCoordinatorsWithStudnet = GetStudentWithClass(htblCoordinators, studnetsAttendance);

                #endregion
                foreach (DictionaryEntry entry in htblCoordinatorsWithStudnet)
                {
                    //tolist.Add("mir.imtiaz81@gmail.com");
                    ClassCoordinator classCoordinator = (ClassCoordinator)entry.Value;
                    sbEmailBody.AppendLine("Dear " + classCoordinator.Employee.Name + " " + classCoordinator.Employee.LastName + ", Following Classes have UnMarked Students in " + rollTimeStatusName + " on " + DateTime.Now.ToString() + ":");
                    sbEmailBody.Append("<br/>");
                    sbEmailBody.Append("<br/>");
                    tolist.Add(classCoordinator.Employee.EmailAddress);
                    // tolist.Add("shahabsohail@hotmail.com");
                    // tolist.Add("mir.imtiaz81@gmail.com");
                    //tolist.Add("sheed.alam@gmail.com");

                    if (classCoordinator.StudnetsAttendace != null && classCoordinator.StudnetsAttendace.Count > 0)
                    {
                        sbEmailBody.Append(GetEmailTableForUnMarkStudent(classCoordinator.StudnetsAttendace));
                        EmailHelper.SendEmail(tolist, "Un Mark Student Alert", sbEmailBody.ToString());
                    }

                    tolist.Clear();
                    if (sbEmailBody != null && sbEmailBody.Length > 0)
                    {
                        sbEmailBody.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                // timerExecuteMessageJob.Stop();
                throw new Exception("Executing Un Mark Student batch job has failed. Following error found: " + ex.Message);
            }

        }

        internal static int CountSunday(DateTime dtFrom, int dayRange)
        {
            int countSunday = 0;
            int countDay = 0;

            while (countDay < dayRange)
            {
                if (dtFrom.DayOfWeek == DayOfWeek.Sunday)
                {
                    countSunday = countSunday + 1;
                }
                else if (dtFrom.DayOfWeek == DayOfWeek.Saturday)
                {
                    countSunday = countSunday + 1;
                }
                countDay++;
                dtFrom = dtFrom.AddDays(1);

            }

            return countSunday;

        }

        public static void OnTimedEventForLateStudent(List<AMS.BusinessEntities.Attendance.StudentAttendace> lateStudnets, List<AMS.BusinessEntities.Messaging.ClassCoordinator> coordinators, DateTime fromDate, DateTime toDate)
        {
            // BusinessManager businessManager = new BusinessManager();
            StringBuilder sbEmailBody = new StringBuilder();
            // bool isSendEmail = false;
            try
            {
                // businessManager.ExecuteLicenseBatchJob();
                IList<string> tolist = new List<string>();
                #region Web config element getting recipient persons email
                Hashtable htblCoordinators = GetClassCoordinatorsWithClassSection(coordinators);
                Hashtable htblCoordinatorsWithStudnet = GetStudentWithClass(htblCoordinators, lateStudnets);

                #endregion
                foreach (DictionaryEntry entry in htblCoordinatorsWithStudnet)
                {
                    //tolist.Add("mir.imtiaz81@gmail.com");
                    AMS.BusinessEntities.Messaging.ClassCoordinator classCoordinator = (AMS.BusinessEntities.Messaging.ClassCoordinator)entry.Value;
                    sbEmailBody.AppendLine("Dear " + classCoordinator.Employee.Name + " " + classCoordinator.Employee.LastName + ", following students are coming late ");
                    sbEmailBody.AppendLine("from " + fromDate.ToString("dd-MM-yyyy") + " to " + toDate.ToString(("dd-MM-yyyy")) + ":");
                    sbEmailBody.Append("<br/>");
                    sbEmailBody.Append("<br/>");
                    tolist.Add(classCoordinator.Employee.EmailAddress);
                    // tolist.Add("shahabsohail@hotmail.com");
                    // tolist.Add("mir.imtiaz81@gmail.com");
                    //tolist.Add("sheed.alam@gmail.com");

                    if (classCoordinator.StudnetsAttendace != null && classCoordinator.StudnetsAttendace.Count > 0)
                    {

                        sbEmailBody.Append(GetEmailTableForLateStudent(classCoordinator.StudnetsAttendace));
                        EmailHelper.SendEmail(tolist, "Late student Alart", sbEmailBody.ToString());

                    }

                    tolist.Clear();
                }
            }
            catch (Exception ex)
            {
                // timerExecuteMessageJob.Stop();
                throw new Exception("Executing Late Student batch job has failed. Following error found: " + ex.Message);
            }

        }
        public static Hashtable GetClassCoordinatorsWithClassSection(List<AMS.BusinessEntities.Messaging.ClassCoordinator> classCoordinators)
        {
            Hashtable htblClassCoordinators = new Hashtable();
            List<string> tolst = new List<string>();
            List<AMS.BusinessEntities.Messaging.ClassCoordinator> lstClassCoordinator = null;
            for (int i = 0; i < classCoordinators.Count; i++)
            {
                lstClassCoordinator = new List<AMS.BusinessEntities.Messaging.ClassCoordinator>();
                for (int j = i; j < classCoordinators.Count; j++)
                {

                    if (classCoordinators[j].Employee.ID == classCoordinators[i].Employee.ID)
                    {
                        lstClassCoordinator.Add(classCoordinators[j]);
                    }
                }
                if (lstClassCoordinator.Count > 0)
                {
                    if (htblClassCoordinators != null && !htblClassCoordinators.ContainsKey(classCoordinators[i].Employee.ID))
                    {
                        htblClassCoordinators.Add(classCoordinators[i].Employee.ID, lstClassCoordinator);
                    }
                }
            }
            return htblClassCoordinators;
        }
        public static Hashtable GetStudentWithClass(Hashtable htblCoordinators, List<AMS.BusinessEntities.Attendance.StudentAttendace> lateStudnets)
        {
            Hashtable htblCoordinatorWithLateStudent = new Hashtable();
            foreach (DictionaryEntry entry in htblCoordinators)
            {
                List<AMS.BusinessEntities.Messaging.ClassCoordinator> classCoordinators = (List<AMS.BusinessEntities.Messaging.ClassCoordinator>)entry.Value;
                AMS.BusinessEntities.Messaging.ClassCoordinator c = new ClassCoordinator();
                foreach (AMS.BusinessEntities.Messaging.ClassCoordinator classCoordinator in classCoordinators)
                {
                    if (lateStudnets.Exists(ls => ls.Student.StudnetClass.ID == classCoordinator.StudentClass.ID && ls.Student.Section.ID == classCoordinator.Section.ID))
                    {
                        List<AMS.BusinessEntities.Attendance.StudentAttendace> lstStudentsAttendace = lateStudnets.FindAll(ls => ls.Student.StudnetClass.ID == classCoordinator.StudentClass.ID && ls.Student.Section.ID == classCoordinator.Section.ID).ToList();
                        if (c.StudnetsAttendace == null)
                        {
                            c = classCoordinator;
                            c.StudnetsAttendace = new List<AMS.BusinessEntities.Attendance.StudentAttendace>();
                            c.StudnetsAttendace.AddRange(lstStudentsAttendace);
                        }
                        else
                        {
                            c.StudnetsAttendace.AddRange(lstStudentsAttendace);
                        }
                        
                    }
                    //if (classCoordinator.StudnetsAttendace != null && classCoordinator.StudnetsAttendace.Count > 0)
                    //{
                    //    if (htblCoordinatorWithLateStudent != null && !htblCoordinatorWithLateStudent.ContainsKey(classCoordinator.ID))
                    //    {
                    //        htblCoordinatorWithLateStudent.Add(classCoordinator.ID, classCoordinator);
                    //    }
                    //}
                }
                if (c.StudnetsAttendace != null && c.StudnetsAttendace.Count > 0)
                {
                    if (htblCoordinatorWithLateStudent != null && !htblCoordinatorWithLateStudent.ContainsKey(c.Employee.ID ))
                    {
                        htblCoordinatorWithLateStudent.Add(c.Employee.ID, c);
                    }
                }
            }
            // htblCoordinators.Clear();
            return htblCoordinatorWithLateStudent;
        }

        public static string GetEmailTableForLateStudent(List<AMS.BusinessEntities.Attendance.StudentAttendace> lateStudnets)
        {
            bool alternateRows = true;
            StringBuilder stTemplate = new StringBuilder();
            string[] headerName = { "Student Name", "Class" };
            stTemplate.Append("<table border=\"2\" style=\"border:1px solid #C0C0C0\">");
            stTemplate.Append(GetNewRow(headerName));
            foreach (AMS.BusinessEntities.Attendance.StudentAttendace item in lateStudnets)
            {
                if (alternateRows)
                {
                    stTemplate.Append("<tr bgcolor=\"#ffffff\"  color=\"#333333>\">");
                    alternateRows = false;
                }
                else
                {
                    stTemplate.Append("<tr bgcolor=\"#A0A0A0\" style=\"color:#ffffff;\">");
                    alternateRows = true;
                }
                stTemplate.Append("<td>");
                stTemplate.Append(item.Student.Name + " " + item.Student.LastName);
                stTemplate.Append("</td>");
                stTemplate.Append("<td>");
                stTemplate.Append(item.Student.StudnetClass.Name + "" + item.Student.Section.Name);
                stTemplate.Append("</td>");
                stTemplate.Append("</tr>");


            }
            stTemplate.Append("</table>");

            return stTemplate.ToString();
           
        }
        public static string GetEmailTableForUnMarkStudent(List<AMS.BusinessEntities.Attendance.StudentAttendace> studentAttendace)
        {
           /* bool alternateRows = true;
            StringBuilder stTemplate = new StringBuilder();
            string[] headerName = { "Student Name", "Class", "Teacher Name" };
            stTemplate.Append("<table border=\"2\" style=\"border:1px solid #C0C0C0\">");
            stTemplate.Append(GetNewRow(headerName));
            foreach (AMS.BusinessEntities.Attendance.StudentAttendace item in studentAttendace)
            {
                if (alternateRows)
                {
                    stTemplate.Append("<tr bgcolor=\"#ffffff\"  color=\"#333333>\">");
                    alternateRows = false;
                }
                else
                {
                    stTemplate.Append("<tr bgcolor=\"#A0A0A0\" style=\"color:#ffffff;\">");
                    alternateRows = true;
                }
                stTemplate.Append("<td>");
                stTemplate.Append(item.Student.Name + " " + item.Student.LastName);
                stTemplate.Append("</td>");
                stTemplate.Append("<td>");
                stTemplate.Append(item.Student.StudnetClass.Name + "" + item.Student.Section.Name);
                stTemplate.Append("</td>");
                stTemplate.Append("<td>");
                stTemplate.Append(item.Employee.Name + "" + item.Employee.LastName);
                stTemplate.Append("</td>");
                stTemplate.Append("</tr>");


            }
            stTemplate.Append("</table>");

            return stTemplate.ToString();
            */
            bool alternateRows = true;
            StringBuilder stTemplate = new StringBuilder();
            string[] headerName = { "Un mark Student Classes" };
            stTemplate.Append("<table border=\"2\" style=\"border:1px solid #C0C0C0\">");
            stTemplate.Append(GetNewRow(headerName));
            foreach (AMS.BusinessEntities.Attendance.StudentAttendace item in studentAttendace)
            {
                if (alternateRows)
                {
                    stTemplate.Append("<tr bgcolor=\"#ffffff\"  color=\"#333333>\">");
                    alternateRows = false;
                }
                else
                {
                    stTemplate.Append("<tr bgcolor=\"#A0A0A0\" style=\"color:#ffffff;\">");
                    alternateRows = true;
                }
                stTemplate.Append("<td>");
                stTemplate.Append("Students have been unmarked in Class " + item.Student.StudnetClass.Name + " " + item.Student.Section.Name);
                stTemplate.Append(" and Class Teacher is " + item.Employee.Name + " " + item.Employee.LastName);
                stTemplate.Append("</td>");
                stTemplate.Append("</tr>");


            }
            stTemplate.Append("</table>");

            return stTemplate.ToString();
        }

        public static string GetNewRow(string[] headerName)
        {
            StringBuilder stTemplate = new StringBuilder();

            stTemplate.Append("<tr bgcolor=\"#5A4D40\" style=\"color:#ffffff;\" >");
            for (int i = 0; i < headerName.Length; i++)
            {
                stTemplate.Append("<td>");
                stTemplate.Append(headerName[i]);
                stTemplate.Append("</td>");
            }
            stTemplate.Append("</tr>");

            return stTemplate.ToString();
        }
        private static void AddEmailSataus(MessageResponseManager messageResponseManager, int rolltimeStatus, MessageType emailType)
        {
            MessageStatus emailStatus = new MessageStatus();
            emailStatus.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
            emailStatus.RollTimeAttendaceStatus.ID = rolltimeStatus;
            emailStatus.MessageType = emailType;
            messageResponseManager.AddMessageStatus(emailStatus);
        }
        private bool IsValidDayToSendEamil()
        {
            string InValidDays = Convert.ToString(ConfigurationManager.AppSettings["ExculdeDaysForEmail"]);
           // string[] aryInValidDays = InValidDays.Split('|');
           // for (int i = 0; i < headerName.Length; i++)
            if (InValidDays.Contains(DateTime.Now.DayOfWeek.ToString()))
            {
                return false;
            }

            return true;
        }
        #endregion
    }
}
