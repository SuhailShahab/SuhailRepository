﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BuisnessEntity.FillEvent;
using AMS.Web.Common;
using FrameWork.Common;
using AMS.BusinessEntities.CustomEnum;
using AMS.Business.Attendance;
using AMS.BusinessEntities.Attendance;
using AMS.BusinessEntities.Student;
using System.Web.Services;
using AMS.BusinessEntities.UserManagement;

namespace AMS.Web.iPhoneApp
{
    public partial class StudentAttendance : System.Web.UI.Page
    {
        #region Custom User Type
        public enum PageActions : byte
        {
            None,
            InitializedPage,
            FillStudent
        }
        private PageMode pageModes;
        #endregion 
        #region Custom Properties
        private int rollTimeStatusId;
        private int currentClassId;
        private int currentSectionId;
        private int currentCampusId;
        public int CurrentCampusId
        {
            get
            {
                if (ViewState["CurrentCampusId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentCampusId = Convert.ToInt32(ViewState["CurrentCampusId"]);
                }
            }
            set
            {
                ViewState["CurrentCampusId"] = value;

            }
        }
        public int RollTimeStatusId
        {
            get
            {
                if (ViewState["RollTimeStatusId"] == null)
                {
                    return 0;
                }
                else
                {
                    return rollTimeStatusId = Convert.ToInt32(ViewState["RollTimeStatusId"]);
                }
            }
            set
            {
                ViewState["RollTimeStatusId"] = value;
            }
        }
        public PageMode PageModes
        {
            get
            {

                return pageModes = (PageMode)ViewState["PageModes"];
            }
            set
            {
                ViewState["PageModes"] = value;
                this.hfPageMode.Value = Convert.ToString(ViewState["PageModes"]);
            }
        }
        public int CurrentSectionId
        {
            get
            {
                if (ViewState["CurrentSectionId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentSectionId = Convert.ToInt32(ViewState["CurrentSectionId"]);
                }
            }
            set
            {
                ViewState["CurrentSectionId"] = value;
            }
        }
        public int CurrentClassId
        {
            get
            {
                if (ViewState["CurrentClassId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentClassId = Convert.ToInt32(ViewState["CurrentClassId"]);
                }
            }
            set
            {
                ViewState["CurrentClassId"] = value;
            }
        }

        private User currentUser;

        public User CurrentUser
        {
            get { return currentUser = (User)Session["CurrentUser"]; }

        }
        #endregion 
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                
                string fileName = System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath);
               // if (!Request.Browser.IsMobileDevice && AMS.Web.Common.CurrentUser.IsAthurisedByName(fileName, DeviceNames.DeskTop.GetHashCode()))
                if (AMS.Web.Common.CurrentUser.IsAthurisedByName(fileName, DeviceNames.DeskTop.GetHashCode()))             
                {
                    this.SetVisibilityOfDate(false);
                    pageModes = PageMode.None;
                    this.SetContorlEnablity(pageModes);
                    InitializedData(PageActions.InitializedPage, new FillSearch());
                    lblCurrentDateTime.Text = DateTime.Now.ToString("dd-MMM-yyyy ");
                }
                else
                {
                    Response.Redirect(PageUrl.loginPageUrl);
                }

            }
        }

        #region Custom Methods
        private void SetContorlEnablity(int rollTimeId)
        {
            lnkbtnSave.Enabled = !(DateTime.Now.Date != Convert.ToDateTime(lblCurrentDateTime.Text) || rollTimeId != this.RollTimeStatusId);

        }
        private void InitializedData(PageActions pageActions, FillSearch fillSearch)
        {


            if (pageActions == PageActions.InitializedPage)
            {
                fillSearch.IsGetTeacherClasses = true;
                fillSearch.IsIncharge = true;
                fillSearch.IsFillStudentAttendanceLateCount = true;
                fillSearch.TeacherId = this.CurrentUser.LoginUserId;//CurrentUser.User.ID;
                fillSearch.CampusId = this.CurrentUser.CampusId;//CurrentUser.User.CampusId;
                FillResponse fillResponse = FillSearchManager.FillData(fillSearch);
                if (fillResponse.ClassesTeacher != null && fillResponse.ClassesTeacher.Count >0)
                {
                    this.CurrentClassId = fillResponse.ClassesTeacher[0].Classes.ID;
                    this.CurrentSectionId = fillResponse.ClassesTeacher[0].Section.ID;
                    this.CurrentCampusId = fillResponse.ClassesTeacher[0].Campus.ID;

                  //  this.rptTeacherClass.DataSource = fillResponse.ClassesTeacher;
                  //  this.rptTeacherClass.DataBind();
                }

                if (fillResponse.StudentsAttendace != null && fillResponse.StudentsAttendace.Count > 0)
                {
                    this.RollTimeStatusId = fillResponse.StudentsAttendace[0].RollTimeAttendaceStatus.ID;
                    rptRollList.DataSource = fillResponse.StudentsAttendace;
                    rptRollList.DataBind();
                }
                if (fillResponse.RollTimeStatus != null)
                {
                    this.lblRollCallName.Text = fillResponse.RollTimeStatus.Name;
                    this.RollTimeStatusId = fillResponse.RollTimeStatus.ID;
                }
            }
           
        }
        private void SetContorlEnablity(PageMode pageMode)
        {
            if (pageMode == PageMode.None)
            {
                this.lnkbtnCancel.Text = "Date";
                this.lnkbtnSave.Text = "Edit";
                this.PageModes = PageMode.Edit;
                this.lnkBtnLogOut.Visible = true;
                this.rollAction.Style.Add("display", "none");
            }
            else if (pageMode == PageMode.Edit)
            {
                this.lnkbtnCancel.Text = "Cancel";
                this.lnkbtnSave.Text = "Save";
                //this.rollAction.Text = "Roll Options";
                this.rollAction.Style.Add("display", "block");
                this.lnkBtnLogOut.Visible =false;
                this.PageModes = PageMode.Save;
            }
            else if (pageMode == PageMode.Save)
            {
                this.lnkbtnCancel.Text = "Date";
                this.lnkbtnSave.Text = "Edit";
                this.PageModes = PageMode.Edit;
            }
        }

       
        private List<BusinessEntities.Attendance.StudentAttendace> GetStudentAttendance()
        {
            HiddenField hfControl = null;
            List<BusinessEntities.Attendance.StudentAttendace> studentsAttendance = new List<BusinessEntities.Attendance.StudentAttendace>();
            for (int i = 0; i < this.rptRollList.Items.Count; i++)
            {
                BusinessEntities.Attendance.StudentAttendace studentAttendace = new BusinessEntities.Attendance.StudentAttendace();
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentAttendanceId");
                if (hfControl != null)
                {
                    studentAttendace.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceStatusId");
                if (hfControl != null)
                {
                    studentAttendace.AttendanceStatus = new BusinessEntities.Attendance.AttendanceStatus();
                    studentAttendace.AttendanceStatus.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentId");
                if (hfControl != null)
                {
                    studentAttendace.Student = new Student();
                    studentAttendace.Student.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfNote");
                if (hfControl != null)
                {
                    studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceDate");
                if (hfControl != null)
                {
                    if (!string.IsNullOrEmpty(hfControl.Value) && Convert.ToDateTime(hfControl.Value).Year != 1 && studentAttendace.AttendanceStatus.ID != AttendaceStatus.UnMarked.GetHashCode())
                    {
                        studentAttendace.AttendanceDate = Convert.ToDateTime(hfControl.Value);
                    }
                    else if (Convert.ToDateTime(hfControl.Value).Year == 1)
                    {//code for preventing duplication by zahmad
                        studentAttendace.AttendanceDate = DateTime.Now;//Convert.ToDateTime(DateTime.Now);
                    }
                    else if (studentAttendace.AttendanceStatus.ID == AttendaceStatus.UnMarked.GetHashCode())
                    {
                        studentAttendace.AttendanceDate = DateTime.Now;
                    }
                }

                studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                studentAttendace.RollTimeAttendaceStatus.ID = this.RollTimeStatusId;
                ///-------CURRENT CLASS AND SECTION
                studentAttendace.Student.StudnetClass = new BusinessEntities.Configuration.Classes();
                studentAttendace.Student.StudnetClass.ID = this.CurrentClassId;
                studentAttendace.Student.Section = new BusinessEntities.Configuration.Section();
                studentAttendace.Student.Section.ID = this.CurrentSectionId;
                studentAttendace.Student.Campus = new BusinessEntities.Configuration.Campus();
                studentAttendace.Student.Campus.ID = this.CurrentCampusId;

                studentsAttendance.Add(studentAttendace);
            }
            return studentsAttendance;


        }
        [WebMethod]
        public static string GetTime()
        {
            return DateTime.Now.ToString();
            //HttpContext.Current.Session["StudentId"] = studentId;
            //string fullPhoto = "../Images/SuhailShahab.jpg";
            //../Images/full_avatar.jpg;
            //return fullPhoto;


        }
        private void BindGridByDate(int rollRollTimeId , DateTime searchDate)
        {
            StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
            List<AMS.BusinessEntities.Attendance.StudentAttendace> studentsAttendace = null;
            studentsAttendace = studentAttendanceManager.SearchLateCountByDate(this.CurrentClassId, this.CurrentSectionId, this.CurrentCampusId, rollRollTimeId, this.CurrentUser.ID, searchDate); 
                //(this.CurrentClassId, this.CurrentSectionId, this.CurrentCampusId, rollRollTimeId, CurrentUser.User.ID, searchDate);
            if (studentsAttendace != null && studentsAttendace.Count > 0)
            {
                this.rptRollList.DataSource = studentsAttendace;
                this.rptRollList.DataBind();
                this.SetVisibilityOfDate(false);
            }
            else
            {

                // MessageAlert.Show("Record not found.");
                ShowMsg("Record not found.");
            }
        }
        #endregion
        #region Button Events
        protected void lnkbtnLogOut_Click(object sender, EventArgs e)
        {
            if (this.PageModes  == PageMode.Edit)
            {
                this.Session.Abandon();
                Response.Redirect(PageUrl.loginPageUrl);
                
            }
        }

        protected void lnkbtnCancel_OnClick(object sender, EventArgs e)
        {
            bool handalCalender = (this.history_arrow.Visible ? false : true);
            this.SetVisibilityOfDate(handalCalender);
            this.SetContorlEnablity(PageMode.None);
        }
        protected void lnkbtnSave_OnClick(object sender, EventArgs e)
        {
            try
            {

                if (this.PageModes == PageMode.Edit)
                {
                    this.SetContorlEnablity(this.PageModes);
                }
                else if (this.PageModes == PageMode.Save)
                {
                    StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
                    List<AMS.BusinessEntities.Attendance.StudentAttendace> studentsAttendace = studentAttendanceManager.AddWithOutReason(this.GetStudentAttendance(), this.CurrentUser.ID, this.CurrentUser.Role.ID);
                    //(this.GetStudentAttendance(),CurrentUser.User.ID,CurrentUser.User.Role.ID);

                    this.SetContorlEnablity(PageMode.None);
                    FillSearch fillSearch = new FillSearch();
                    fillSearch.ClassId = this.CurrentClassId;
                    fillSearch.SectionId = this.CurrentSectionId;
                    fillSearch.CampusId = this.CurrentCampusId;
                    fillSearch.RollTimeStatusId = this.RollTimeStatusId;
                    fillSearch.IsFillStudentAttendanceByid = true;
                    this.InitializedData(PageActions.InitializedPage, new FillSearch());
                   
                }
                this.SetVisibilityOfDate(false);
            }
            catch// (Exception ex)
            {
               // this.shw
            }
        }
        public void ShowMsg(string msg)
        {
            ScriptManager.RegisterStartupScript(this, typeof(Button), "Message", "alert('" + msg + "');", true);

        }
        #endregion 
        #region Calendar Event
        protected void cldrAttendance_SelectionChanged(object sender, EventArgs e)
        {
            lblCalenderDate.Text = this.cldrAttendance.SelectedDate.ToString("dd-MMM-yyyy");
        }
        private void SetVisibilityOfDate(bool handalCalender)
        {

            this.history_arrow.Visible = (lnkbtnCancel.Text.Equals("Date") && handalCalender);
            this.history.Visible = (lnkbtnCancel.Text.Equals("Date") && handalCalender);
            if ((lnkbtnCancel.Text.Equals("Date") && handalCalender))
            {
                // this.cldrAttendance.SelectedDate = DateTime.Now;

                // this.cldrAttendance.VisibleDate = DateTime.Now;*/

                DateTime dateToSet = DateTime.Parse(DateTime.Now.ToShortDateString());
                this.cldrAttendance.SelectedDate = dateToSet;
                this.cldrAttendance.VisibleDate = dateToSet;
                this.lblCalenderDate.Text = this.cldrAttendance.SelectedDate.ToString("dd-MMM-yyyy");
            }
        }
        protected void lnkbtnAM_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(lblCalenderDate.Text))
                {
                    this.BindGridByDate(RollTimeStatusName.MoringRollTimeId, Convert.ToDateTime(lblCalenderDate.Text));
                    lblCurrentDateTime.Text = lblCalenderDate.Text;
                    lblRollCallName.Text = RollTimeStatusName.MoringRollTime;
                    this.SetContorlEnablity(RollTimeStatusName.MoringRollTimeId);
                }
                else
                {
                    MessageAlert.Show("Please select date.");
                }
            }
            catch
            {
            }
        }
        protected void lnkbtnPM_OnClick(object sender, EventArgs e)
        {
           
            if (!string.IsNullOrEmpty(lblCalenderDate.Text))
            {
                this.BindGridByDate(RollTimeStatusName.EveningRollTimeId, Convert.ToDateTime(lblCalenderDate.Text));
                lblCurrentDateTime.Text = lblCalenderDate.Text;
                lblRollCallName.Text = RollTimeStatusName.EveningRollTime;
                this.SetContorlEnablity(RollTimeStatusName.EveningRollTimeId);
            }
            else
            {
                MessageAlert.Show("Please select date.");
            }
        }
        //protected void lnkbtnCloseCalendar_OnClick(object sender, EventArgs e)
        //{
        //    this.SetVisibilityOfDate(false);
        //}
        #endregion

        protected void rollAction_Click(object sender, EventArgs e)
        {
            this.Session.Abandon();
            Response.Redirect(PageUrl.loginPageUrl);
        
        
        
        }
    }
}