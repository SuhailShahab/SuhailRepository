﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AMS.Web.Common
{
    public static class PageUrl
    {
        public const string loginPageUrl = "~/Security/Default.aspx";
        public const string latePassReportUrl = "~/Reports/Templates/crptLatePass.rpt";
        public const string earlyLeavePassReportUrl = "~/Reports/Templates/crptEarlyLeavePass.rpt";
        public const string latePassViewUrl = "../Reports/LatePassView.aspx";
    }
}