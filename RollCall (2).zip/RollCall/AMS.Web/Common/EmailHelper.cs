﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Mail;

namespace AMS.Web.Common
{
    public class EmailHelper
    {
        public static bool SendEmail(IList<string> to_list, string subject, string body)
        {
            SmtpClient smtp = null;
            MailMessage mail = null;
            try
            {
                mail = new MailMessage();

                foreach (string to in to_list)
                    mail.To.Add(new MailAddress(to));

                mail.Subject = subject;

                mail.IsBodyHtml = true;
                mail.Body = body;

                smtp = new SmtpClient();
                smtp.Send(mail);

                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return false;
        }
    }
}