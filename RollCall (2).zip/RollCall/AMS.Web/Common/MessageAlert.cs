﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace AMS.Web.Common
{
    public static class MessageAlert
    {
        public static void Show(string message)
        {
            string cleanMessage = message.Replace("'", "\\");
            string script = "<script type= \"text/javascript\"> alert('" + cleanMessage + "');</script>";
            Page page = HttpContext.Current.CurrentHandler as Page;

            page.ClientScript.RegisterClientScriptBlock(typeof(MessageAlert), "alert", script);
            //ScriptManager.RegisterClientScriptBlock(typeof(MessageAlert), "alert", script);
        }
        //private static void ShowInformationMsg(string msg)
        //{
        //    ScriptManager.RegisterStartupScript(this, typeof(Button), "Message", "alert('" + msg + "');", true);
        //    //ClientScript.RegisterClientScriptBlock(typeof(Button),"myScript", "<script language=JavaScript>alert('Hello');</script>");
        //}
    }
}