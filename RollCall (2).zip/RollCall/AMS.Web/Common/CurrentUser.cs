﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AMS.BusinessEntities.UserManagement;

namespace AMS.Web.Common
{
    public class CurrentUser
    {
        private static User user;

        public static User User
        {
            get 
            {
                if (HttpContext.Current.Session["CurrentUser"] == null)
                {
                    return null;
                }
                else
                {
                    return CurrentUser.user = (User)HttpContext.Current.Session["CurrentUser"];
                }
               
            }
           
            //set 
            //{
            //    CurrentUser.user = value; 
            //}
        }

        public static  bool IsAthurised(int objectId,int deviceId)
        {
            if (User == null ||User.Role ==null)
            {
                return false;
            }
            else
            {
                if (User.Role.UserPermissions.Exists(p => p.ObjectName.ID == objectId && p.ObjectName.Device.ID == deviceId ))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public static bool IsAthurisedByName(string pageName ,int deviceId)
        {
            if (User == null || User.Role == null)
            {
                return false;
            }
            else
            {
                if (User.Role.UserPermissions.Exists(p => p.ObjectName.Name == pageName && p.ObjectName.Device.ID == deviceId))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}