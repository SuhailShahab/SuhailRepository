﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Timers;
using AMS.BusinessEntities.Attendance;
using System.Text;
using System.Collections;
using AMS.BusinessEntities.Messaging;
using AMS.Business.Attendance;
using AMS.Business.Messaging;
using AMS.BusinessEntities.CustomEnum;

namespace AMS.Web.Common
{
    public class MessageHelper
    {
        private static System.Timers.Timer timerExecuteMessageJob;
        public void InitilizeTimerExecuteMessageJob()
        {
            int timeInterval = Convert.ToInt32(System.Web.Configuration.WebConfigurationManager.AppSettings["TimeInterval"]);
           // timerExecuteMessageJob = new System.Timers.Timer(timeInterval);
            timerExecuteMessageJob = new System.Timers.Timer();
            timerExecuteMessageJob.Interval = TimeSpan.FromMinutes(timeInterval).TotalMilliseconds;
            timerExecuteMessageJob.Enabled = true;
            timerExecuteMessageJob.Elapsed += new ElapsedEventHandler(OnTimedEvent);
            OnTimedEvent("", null);
        }
        public static void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            StudentAttendanceManager studentAttendanceManager = null;
            MessageResponseManager messageResponseManager = null;
            try
            {
                 
                if (timerExecuteMessageJob != null)
                {
                    studentAttendanceManager = new StudentAttendanceManager();
                    messageResponseManager = new MessageResponseManager();
                    List<ClassCoordinator> classCoordinator = messageResponseManager.GetAllCoordinators();
                   int morningTime=Convert.ToInt32( System.Web.Configuration.WebConfigurationManager.AppSettings["MorningUnMarkTime"]);
                   int eveningTime = Convert.ToInt32(System.Web.Configuration.WebConfigurationManager.AppSettings["EveningUnMarkTime"]);
                    if (!messageResponseManager.IsSendEmail(RollTimeStatusName.MoringRollTimeId, MessageType.Late.GetHashCode()))
                    {

                        DateTime formDate = DateTime.Now.AddDays(-6);
                        int totalSunday = CountSunday(formDate, 6);
                        if (totalSunday > 0)
                        {
                            formDate = formDate.AddDays(-totalSunday);
                        }
                        List<StudentAttendace> studentAttendance = studentAttendanceManager.GetLateStudentByDate(formDate, DateTime.Now);
                       
                        if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                        {
                            OnTimedEventForLateStudent(studentAttendance, classCoordinator, formDate, DateTime.Now);
                        }
                    }

                    if (DateTime.Now.Hour >= morningTime && DateTime.Now.Hour <= morningTime+2 && !messageResponseManager.IsSendEmail(RollTimeStatusName.MoringRollTimeId, MessageType.UnMark.GetHashCode()))
                    {
                        List<StudentAttendace> studentAttendance = studentAttendanceManager.GetUnMarkStudents(RollTimeStatusName.MoringRollTimeId, AttendaceStatus.UnMarked.GetHashCode());
                        if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                        {
                            OnTimedEventForUnMarkStudent(studentAttendance, classCoordinator, RollTimeStatusName.MoringRollTime);
                            AddEmailSataus(messageResponseManager, RollTimeStatusName.MoringRollTimeId, MessageType.UnMark);
                        }
                       
                    }
                    if (DateTime.Now.Hour >= eveningTime && DateTime.Now.Hour <= eveningTime+2 && !messageResponseManager.IsSendEmail(RollTimeStatusName.EveningRollTimeId, MessageType.UnMark.GetHashCode()))
                    {
                        List<StudentAttendace> studentAttendance = studentAttendanceManager.GetUnMarkStudents(RollTimeStatusName.EveningRollTimeId, AttendaceStatus.UnMarked.GetHashCode());
                        if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                        {
                            OnTimedEventForUnMarkStudent(studentAttendance, classCoordinator, RollTimeStatusName.EveningRollTime);
                            AddEmailSataus(messageResponseManager, RollTimeStatusName.EveningRollTimeId, MessageType.UnMark);
                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                // timerExecuteMessageJob.Stop();
                throw new Exception("Executing Studnet Attendance batch job has failed. Following error found: " + ex.Message);
            }

        }
         internal  static  int CountSunday(DateTime dtFrom, int dayRange)
        {
            int countSunday = 0;
            int countDay = 0;

            while (countDay < dayRange)
            {
                if (dtFrom.DayOfWeek == DayOfWeek.Sunday)
                {
                    countSunday = countSunday + 1;
                }
                else if (dtFrom.DayOfWeek == DayOfWeek.Saturday)
                {
                    countSunday = countSunday + 1;
                }
                countDay++;
                dtFrom = dtFrom.AddDays(1);

            }

            return countSunday;

        }
        private static void AddEmailSataus(MessageResponseManager messageResponseManager,int rolltimeStatus, MessageType emailType)
        {
            MessageStatus emailStatus = new MessageStatus();
            emailStatus.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
            emailStatus.RollTimeAttendaceStatus.ID = rolltimeStatus;
            emailStatus.MessageType = emailType;
            messageResponseManager.AddMessageStatus(emailStatus);
        }
        //public  static void OnTimedEvent( List<StudentAttendace> lateStudnets ,DateTime fromDate,DateTime toDate)
        //{
        //    // BusinessManager businessManager = new BusinessManager();
        //    StringBuilder sbEmailBody = new StringBuilder();
        //    bool isSendEmail = false;
        //    try
        //    {
        //        // businessManager.ExecuteLicenseBatchJob();
        //        IList<string> tolist = new List<string>();
        //        #region Web config element getting recipient persons email
        //        // System.Configuration.AppSettingsSection customSetting = System.Web.Configuration.WebConfigurationManager.AppSettings["iPhone"];
        //        string firstPersonEmail = System.Web.Configuration.WebConfigurationManager.AppSettings["ToFirstPerson"];
        //        string secondPersonEmail = System.Web.Configuration.WebConfigurationManager.AppSettings["ToSecondPerson"];
        //        if (firstPersonEmail != null)
        //            tolist.Add(firstPersonEmail.ToString());
        //        if (secondPersonEmail != null)
        //            tolist.Add(secondPersonEmail.ToString());

        //        // }
        //        #endregion
                
        //        //tolist.Add("mir.imtiaz81@gmail.com");
        //        sbEmailBody.AppendLine("Dear Coordinator, following students are coming late ");
        //        sbEmailBody.Append("<br/>");
        //        sbEmailBody.AppendLine("from " + fromDate.ToString("dd-MM-yyyy") + " to " + toDate.ToString(("dd-MM-yyyy")));
        //        sbEmailBody.Append("<br/>");
        //        sbEmailBody.Append("<br/>");
        //        foreach (StudentAttendace studentAttendace in lateStudnets)
        //        {
        //            if (studentAttendace.LateCount >= 3)
        //            {
        //                isSendEmail = true;                       
        //                sbEmailBody.Append(studentAttendace.Student.Name + " " + studentAttendace.Student.LastName + "      " + studentAttendace.Student.StudnetClass.Name + "  " + studentAttendace.Student.Section.Name);
        //                sbEmailBody.Append("<br/>");
        //            }
        //        }
        //        if (isSendEmail)
        //        {
        //            EmailHelper.SendEmail(tolist, "Late student Alter", sbEmailBody.ToString());
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        // timerExecuteMessageJob.Stop();
        //        throw new Exception("Executing license batch job has failed. Following error found: " + ex.Message);
        //    }

        //}
        public static void OnTimedEventForLateStudent(List<StudentAttendace> lateStudnets,List<ClassCoordinator> coordinators, DateTime fromDate, DateTime toDate)
        {
            // BusinessManager businessManager = new BusinessManager();
            StringBuilder sbEmailBody = new StringBuilder();
           // bool isSendEmail = false;
            try
            {
                // businessManager.ExecuteLicenseBatchJob();
                IList<string> tolist = new List<string>();
                #region Web config element getting recipient persons email
                Hashtable htblCoordinators = GetClassCoordinatorsWithClassSection(coordinators);
                Hashtable htblCoordinatorsWithStudnet = GetStudentWithClass(htblCoordinators, lateStudnets);
               
                #endregion
                foreach (DictionaryEntry entry in htblCoordinatorsWithStudnet)
                {
                    //tolist.Add("mir.imtiaz81@gmail.com");
                    ClassCoordinator classCoordinator = (ClassCoordinator)entry.Value;
                    sbEmailBody.AppendLine("Dear "+classCoordinator.Employee.Name +" "+classCoordinator.Employee.LastName +", following students are coming late ");                   
                    sbEmailBody.AppendLine("from " + fromDate.ToString("dd-MM-yyyy") + " to " + toDate.ToString(("dd-MM-yyyy"))+":");
                    sbEmailBody.Append("<br/>");
                    sbEmailBody.Append("<br/>");                   
                    tolist.Add(classCoordinator.Employee.EmailAddress);
                   // tolist.Add("shahabsohail@hotmail.com");
                   // tolist.Add("mir.imtiaz81@gmail.com");
                    //tolist.Add("sheed.alam@gmail.com");
                 
                    if (classCoordinator.StudnetsAttendace != null && classCoordinator.StudnetsAttendace.Count > 0)
                    {
                        
                        sbEmailBody.Append(GetEmailTableForLateStudent(classCoordinator.StudnetsAttendace));
                        EmailHelper.SendEmail(tolist, "Late student Alart", sbEmailBody.ToString());

                    }

                    tolist.Clear();
                }
            }
            catch (Exception ex)
            {
                // timerExecuteMessageJob.Stop();
                throw new Exception("Executing Late Student batch job has failed. Following error found: " + ex.Message);
            }

        }
        public static void OnTimedEventForUnMarkStudent(List<StudentAttendace> studnetsAttendance, List<ClassCoordinator> coordinators, string rollTimeStatusName)
        {
            // BusinessManager businessManager = new BusinessManager();
            StringBuilder sbEmailBody = new StringBuilder();
            // bool isSendEmail = false;
            try
            {
                // businessManager.ExecuteLicenseBatchJob();
                IList<string> tolist = new List<string>();
                #region Web config element getting recipient persons email
                Hashtable htblCoordinators = GetClassCoordinatorsWithClassSection(coordinators);
                Hashtable htblCoordinatorsWithStudnet = GetStudentWithClass(htblCoordinators, studnetsAttendance);

                #endregion
                foreach (DictionaryEntry entry in htblCoordinatorsWithStudnet)
                {
                    //tolist.Add("mir.imtiaz81@gmail.com");
                    ClassCoordinator classCoordinator = (ClassCoordinator)entry.Value;
                    sbEmailBody.AppendLine("Dear " + classCoordinator.Employee.Name + " " + classCoordinator.Employee.LastName + ", Following students are UnMarked in " + rollTimeStatusName + " on " + DateTime.Now.ToString("dd/MMM/yyyy")+":");
                    sbEmailBody.Append("<br/>");
                    sbEmailBody.Append("<br/>");
                    tolist.Add(classCoordinator.Employee.EmailAddress);
                   // tolist.Add("shahabsohail@hotmail.com");
                   // tolist.Add("mir.imtiaz81@gmail.com");
                    //tolist.Add("sheed.alam@gmail.com");

                    if (classCoordinator.StudnetsAttendace != null && classCoordinator.StudnetsAttendace.Count > 0)
                    {
                        sbEmailBody.Append(GetEmailTableForUnMarkStudent(classCoordinator.StudnetsAttendace));
                        EmailHelper.SendEmail(tolist, "Un Mark Student Alert", sbEmailBody.ToString());
                    }

                    tolist.Clear();
                }
            }
            catch (Exception ex)
            {
                // timerExecuteMessageJob.Stop();
                throw new Exception("Executing Un Mark Student batch job has failed. Following error found: " + ex.Message);
            }

        }
     
        private string GetEmailBody(List<StudentAttendace> lateStudnets, DateTime fromDate, DateTime toDate)
        {
            StringBuilder sbEmailBody = new StringBuilder();
            sbEmailBody.AppendLine("Dear Coordinator, following students are coming late ");
            sbEmailBody.Append("<br/>");
            sbEmailBody.AppendLine("from " + fromDate.ToString("dd-MM-yyyy") + " to " + toDate.ToString(("dd-MM-yyyy")+":"));
            sbEmailBody.Append("<br/>");
            sbEmailBody.Append("<br/>");
            foreach (StudentAttendace studentAttendace in lateStudnets)
            {
                if (studentAttendace.LateCount >= 3)
                {
                   // isSendEmail = true;
                    sbEmailBody.Append(studentAttendace.Student.Name + " " + studentAttendace.Student.LastName + "      " + studentAttendace.Student.StudnetClass.Name + "  " + studentAttendace.Student.Section.Name);
                    sbEmailBody.Append("<br/>");
                }
            }
            return null;
        }
        public static Hashtable GetClassCoordinatorsWithClassSection(List<ClassCoordinator> classCoordinators)
        {
            Hashtable htblClassCoordinators = new Hashtable();
            List<string> tolst = new List<string>();
            List<ClassCoordinator> lstClassCoordinator = null;
            for (int i = 0; i < classCoordinators.Count; i++)
            {
                lstClassCoordinator = new List<ClassCoordinator>();
                for (int j = i; j < classCoordinators.Count; j++)
                {
                   
                   if (classCoordinators[j].Employee.ID == classCoordinators[i].Employee.ID)
                    {
                        lstClassCoordinator.Add(classCoordinators[j]);
                    }
                }
                if (lstClassCoordinator.Count > 0)
                {
                    if (htblClassCoordinators!=null && !htblClassCoordinators.ContainsKey(classCoordinators[i].Employee.ID))
                    {
                        htblClassCoordinators.Add(classCoordinators[i].Employee.ID, lstClassCoordinator);
                    }
                }
            }
            return htblClassCoordinators;
        }
        public static Hashtable GetStudentWithClass(Hashtable htblCoordinators, List<StudentAttendace> lateStudnets)
        {
            Hashtable htblCoordinatorWithLateStudent = new Hashtable();
            if (lateStudnets != null)
            {
                foreach (DictionaryEntry entry in htblCoordinators)
                {
                    List<ClassCoordinator> classCoordinators = (List<ClassCoordinator>)entry.Value;
                    foreach (ClassCoordinator classCoordinator in classCoordinators)
                    {
                        if (lateStudnets.Exists(ls => ls.Student.StudnetClass.ID == classCoordinator.StudentClass.ID && ls.Student.Section.ID == classCoordinator.Section.ID))
                        {
                            List<StudentAttendace> lstStudentsAttendace = lateStudnets.FindAll(ls => ls.Student.StudnetClass.ID == classCoordinator.StudentClass.ID && ls.Student.Section.ID == classCoordinator.Section.ID).ToList();
                            if (classCoordinator.StudnetsAttendace == null)
                            {
                                classCoordinator.StudnetsAttendace = new List<StudentAttendace>();
                                classCoordinator.StudnetsAttendace.AddRange(lstStudentsAttendace);
                            }
                            else
                            {
                                classCoordinator.StudnetsAttendace.AddRange(lstStudentsAttendace);
                            }
                        }
                        if (classCoordinator.StudnetsAttendace != null && classCoordinator.StudnetsAttendace.Count > 0)
                        {
                            if (htblCoordinatorWithLateStudent != null && !htblCoordinatorWithLateStudent.ContainsKey(classCoordinator.ID))
                            {
                                htblCoordinatorWithLateStudent.Add(classCoordinator.ID, classCoordinator);
                            }
                        }
                    }
                }
            }
           // htblCoordinators.Clear();
            return htblCoordinatorWithLateStudent;
        }

        public static string GetEmailTableForLateStudent(List<StudentAttendace> lateStudnets)
        {
            bool alternateRows = true;
            StringBuilder stTemplate = new StringBuilder();
            string[] headerName = { "Student Name", "Class" };
            stTemplate.Append("<table border=\"2\" style=\"border:1px solid #C0C0C0\">");
            stTemplate.Append(GetNewRow(headerName));
            foreach (StudentAttendace item in lateStudnets)
            {
                if (alternateRows)
                {
                    stTemplate.Append("<tr bgcolor=\"#ffffff\"  color=\"#333333>\">");
                    alternateRows = false;
                }
                else
                {
                    stTemplate.Append("<tr bgcolor=\"#A0A0A0\" style=\"color:#ffffff;\">");                    
                    alternateRows = true;
                }
                stTemplate.Append("<td>");
                stTemplate.Append(item.Student.Name +" "+item.Student.LastName);
                stTemplate.Append("</td>");
                stTemplate.Append("<td>");
                stTemplate.Append(item.Student.StudnetClass.Name +""+ item.Student.Section.Name);
                stTemplate.Append("</td>");
                stTemplate.Append("</tr>");


            }
            stTemplate.Append("</table>");

            return stTemplate.ToString();
        }        
        public static string GetEmailTableForUnMarkStudent(List<StudentAttendace> studentAttendace)
        {
            bool alternateRows = true;
            StringBuilder stTemplate = new StringBuilder();
            string[] headerName = { "Student Name", "Class","Teacher Name" };
            stTemplate.Append("<table border=\"2\" style=\"border:1px solid #C0C0C0\">");
            stTemplate.Append(GetNewRow(headerName));
            foreach (StudentAttendace item in studentAttendace)
            {
                if (alternateRows)
                {
                    stTemplate.Append("<tr bgcolor=\"#ffffff\"  color=\"#333333>\">");
                    alternateRows = false;
                }
                else
                {
                    stTemplate.Append("<tr bgcolor=\"#A0A0A0\" style=\"color:#ffffff;\">");
                    alternateRows = true;
                }
                stTemplate.Append("<td>");
                stTemplate.Append(item.Student.Name + " " + item.Student.LastName);
                stTemplate.Append("</td>");
                stTemplate.Append("<td>");
                stTemplate.Append(item.Student.StudnetClass.Name + "" + item.Student.Section.Name);
                stTemplate.Append("</td>");
                stTemplate.Append("<td>");
                stTemplate.Append(item.Employee.Name  + "" + item.Employee.LastName );
                stTemplate.Append("</td>");
                stTemplate.Append("</tr>");


            }
            stTemplate.Append("</table>");

            return stTemplate.ToString();
        }

        public static string GetNewRow(string[] headerName)
        {
            StringBuilder stTemplate = new StringBuilder();

            stTemplate.Append("<tr bgcolor=\"#5A4D40\" style=\"color:#ffffff;\" >");
            for (int i = 0; i < headerName.Length; i++)
            {
                stTemplate.Append("<td>");
                stTemplate.Append(headerName[i]);
                stTemplate.Append("</td>");
            }           
            stTemplate.Append("</tr>");

            return stTemplate.ToString();
        }
    }
}