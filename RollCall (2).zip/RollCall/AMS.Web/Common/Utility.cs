﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;


namespace AMS.Web.Common
{
    public static class Utility
    {

        public static void CheckSessionTimeout(Page page, Type type)
        {
            string msgSession = @"Warning: Within next 3 minute.Please save changed data.";
            //time to remind, 3 minutes before session ends
            int int_MilliSecondsTimeReminder = (HttpContext.Current.Session.Timeout * 60000) - 3 * 60000;
            //time to redirect, 5 milliseconds before session ends
            int int_MilliSecondsTimeOut = (HttpContext.Current.Session.Timeout * 60000) - 5;

            string str_Script = @"
            var myTimeReminder, myTimeOut; 
            clearTimeout(myTimeReminder); 
            clearTimeout(myTimeOut); " +
                    "var sessionTimeReminder = " +
                int_MilliSecondsTimeReminder.ToString() + "; " +
                    "var sessionTimeout = " + int_MilliSecondsTimeOut.ToString() + ";" +
                // "function doReminder(){ alert('" + msgSession + "'); }" +
                    "function doRedirect(){ window.location.href=\"../Security/Default.aspx\"; }" + @"
            myTimeReminder=setTimeout('doReminder()', sessionTimeReminder); 
            myTimeOut=setTimeout('doRedirect()', sessionTimeout); ";

            ScriptManager.RegisterClientScriptBlock(page, type,
                  "CheckSessionOut", str_Script, true);
        }
    }
}