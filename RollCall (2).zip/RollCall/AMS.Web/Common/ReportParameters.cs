﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AMS.BusinessEntities.CustomEnum;

namespace AMS.Web.Common
{
    public static  class ReportParameters
    {
        private static ReportType reportType;
        private static DateTime currentDate;

        public static DateTime CurrentDate
        {
            get
            {
                if (HttpContext.Current.Session["CurrentDate"] == null)
                {
                    return DateTime.Now;
                }
                else
                {
                    return currentDate = Convert.ToDateTime(HttpContext.Current.Session["CurrentDate"]);
                }

            }

            set
            {
                HttpContext.Current.Session["CurrentDate"] = value;
            }
        }

        public static ReportType ReportType
        {
            get
            {
                if (HttpContext.Current.Session["ReportType"] == null)
                {
                    return ReportType.None;
                }
                else
                {
                    return reportType = (ReportType)HttpContext.Current.Session["ReportType"];
                }

            }

            set
            {
                HttpContext.Current.Session["ReportType"] = value;
            }
        }
    }
}