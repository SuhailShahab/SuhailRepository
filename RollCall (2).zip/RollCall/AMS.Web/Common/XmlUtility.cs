﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace ANTOMS.VisoHelperClass
{
   public class XmlUtility
    {
       //public static string  XmlToSerialString(string targetFilenamePath, string fileName)
       //{
       //   // MSXML2.DOMDocument dom = new MSXML2.DOMDocument();
       //    dom.load(targetFilenamePath);
       //    string SerializedString = dom.xml;

       //    return SerializedString;
       //}
       //public static object GetSerializerDeSerializeObject(BaseEntity obj)
       //{
       //    XmlSerializer serializer = new XmlSerializer(obj.GetType());
       //    System.Text.StringBuilder sb = new System.Text.StringBuilder();
       //    System.IO.StringWriter writer = new System.IO.StringWriter(sb);
       //    serializer.Serialize(writer, obj);
       //    string xmlString = sb.ToString();

       //    StringReader  strReader=new StringReader(xmlString);
       //    XmlReader reader = new XmlTextReader(strReader);
       //    object deserialized = serializer.Deserialize(reader);
       //    return deserialized;
       //}
       public static T DeepClone<T>(T obj)
       {

           T objResult;

           using (MemoryStream ms = new MemoryStream())
           {

               BinaryFormatter bf = new BinaryFormatter();

               bf.Serialize(ms, obj);

               ms.Position = 0;

               objResult = (T)bf.Deserialize(ms);

           }

           return objResult;

       }
       public static object GetSerializerDeSerializeObject(object obj)
       {
           XmlSerializer serializer = new XmlSerializer(obj.GetType());
           System.Text.StringBuilder sb = new System.Text.StringBuilder();
           System.IO.StringWriter writer = new System.IO.StringWriter(sb);
           serializer.Serialize(writer, obj);
           string xmlString = sb.ToString();

           StringReader strReader = new StringReader(xmlString);
           XmlReader reader = new XmlTextReader(strReader);
           object deserialized = serializer.Deserialize(reader);
           return deserialized;
       }
       public static string  SerializerObjectToString(object obj)
       {
           XmlSerializer serializer = new XmlSerializer(obj.GetType());
           System.Text.StringBuilder sb = new System.Text.StringBuilder();
           System.IO.StringWriter writer = new System.IO.StringWriter(sb);
           serializer.Serialize(writer, obj);
           string xmlString = sb.ToString();

           if (xmlString.Length == 0)
               return string.Empty;
           else
               return xmlString;
           
       }
       //public static string SerializerObjectToString(BaseEntity objEitiy)
       //{
       //    try
       //    {
       //        XmlSerializer ser = new XmlSerializer(objEitiy.GetType());
       //        System.Text.StringBuilder sb = new System.Text.StringBuilder();
       //        System.IO.StringWriter sw = new System.IO.StringWriter(sb);
       //        ser.Serialize(sw, objEitiy);
       //        //XmlDocument xmlDoc = new XmlDocument();
       //        // xmlDoc.Load(sb.ToString());
       //        return sb.ToString();
       //    }
       //    catch (Exception loex)
       //    {
       //        return null;
       //    }
           
       //}
       public static object  SerializerStringToObject(string xmlString, object objEntity)
       {
           try
           {

               XmlDocument xmlDoc = new XmlDocument();
               xmlDoc.LoadXml(xmlString);
               XmlNodeReader xmlNodeReader = new XmlNodeReader(xmlDoc.DocumentElement);
               XmlSerializer ser = new XmlSerializer(objEntity.GetType());
               object obj = ser.Deserialize(xmlNodeReader);
               return obj;
           }
           catch// (Exception loEx)
           {
               return null;
           }
       }
      
    }
}
