﻿//In the name of Allah who is most beneficient and mercifull
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BuisnessEntity.FillEvent;
using FrameWork.Common;
using AMS.BusinessEntities.UserManagement;
using System.Web.Services;
using AMS.BusinessEntities.Student;
using AMS.Business.Attendance;
using AMS.BusinessEntities.CustomEnum;
using System.Web.UI.HtmlControls;
using AMS.Web.Common;
using System.Text;
using System.Globalization;
using System.Drawing.Printing;
using System.Drawing;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using AMS.BusinessEntities.Attendance;
using AMS.Business.Reports;
using AMS.BusinessEntities.Messaging;
using AMS.Business.Messaging;
using System.Net;
using System.IO;
using System.Data.SqlClient;

namespace AMS.Web.StudentAttendance
{
    public partial class LatePass : System.Web.UI.Page
    {
        public enum PageActions : byte
        {
            None,
            InitializedPage,
            FillStudent,
            RefreshData
        }

        #region Custom Property
        private int daysCounter = 0;
        private bool isLastRow = true;
        private int currentClassId;
        private int currentSectionId;
        private int currentCampusId;
        private int rollTimeStatusId;
        private PageMode pageModes;
        private BusinessEntities.Attendance.StudentAttendace passData;

        public BusinessEntities.Attendance.StudentAttendace PassData
        {
            get
            {
                if (Session["PassData"] == null)
                {
                    return null;
                }
                else
                {
                    return passData = (BusinessEntities.Attendance.StudentAttendace)Session["PassData"];
                }
            }
            set
            {
                Session["PassData"] = value;
            }
        }


        public int RollTimeStatusId
        {
            get
            {
                if (ViewState["RollTimeStatusId"] == null)
                {
                    return 0;
                }
                else
                {
                    return rollTimeStatusId = Convert.ToInt32(ViewState["RollTimeStatusId"]);
                }
            }
            set
            {
                ViewState["RollTimeStatusId"] = value;
            }
        }

        public int CurrentSectionId
        {
            get
            {
                if (ViewState["CurrentSectionId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentSectionId = Convert.ToInt32(ViewState["CurrentSectionId"]);
                }
            }
            set
            {
                ViewState["CurrentSectionId"] = value;

            }
        }
        public int CurrentCampusId
        {
            get
            {
                if (ViewState["CurrentCampusId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentCampusId = Convert.ToInt32(ViewState["CurrentCampusId"]);
                }
            }
            set
            {
                ViewState["CurrentCampusId"] = value;

            }
        }
        public int CurrentClassId
        {
            get
            {
                if (ViewState["CurrentClassId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentClassId = Convert.ToInt32(ViewState["CurrentClassId"]);
                }
            }
            set
            {
                ViewState["CurrentClassId"] = value;
            }
        }
        private User currentUser;

        public User CurrentUser
        {
            get { return currentUser = (User)Session["CurrentUser"]; }

        }
        public PageMode PageModes
        {
            get
            {

                return pageModes = (PageMode)ViewState["PageModes"];
            }
            set
            {
                ViewState["PageModes"] = value;
                this.hfPageMode.Value = Convert.ToString(ViewState["PageModes"]);
            }
        }
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {

            //this.CheckSessionTimeout();
            Utility.CheckSessionTimeout(this.Page, this.GetType());
           // Response.AppendHeader("Refresh", Convert.ToString(Session.Timeout * 60) + ";url=../Security/Default.aspx");
            if (!IsPostBack)
            {
                this.history_arrow.Visible = false;
                this.history.Visible = false;
                string fileName = System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath);
                if (!Request.Browser.IsMobileDevice && AMS.Web.Common.CurrentUser.IsAthurisedByName(fileName, DeviceNames.DeskTop.GetHashCode()))
                {
                    InitializedData(PageActions.InitializedPage, new FillSearch());
                    this.reasons.Visible = true;
                    PageModes = PageMode.None;
                    lblCurrentDateTime.Text = DateTime.Now.ToString("dd-MMM-yyyy ");
                    this.SetContorlEnablity(PageModes);
                    
                    
                }
                else
                {
                    Response.Redirect(PageUrl.loginPageUrl);
                }

            }
        }

        #region Cusotm Methods
        private void InitializedData(PageActions pageActions, FillSearch fillSearch)
        {

            // FillResponse fillResponse =new FillResponse();
            //FillSearch fillSearch =new FillSearch();

            if (pageActions == PageActions.InitializedPage)
            {

                fillSearch.IsGetTeacherClasses = true;
                fillSearch.TeacherId = this.CurrentUser.LoginUserId;
                fillSearch.CampusId = this.CurrentUser.CampusId;
                FillResponse fillResponse = FillSearchManager.FillData(fillSearch);
                if (fillResponse.ClassesTeacher != null && fillResponse.ClassesTeacher.Count > 0)
                {
                    this.CurrentClassId = fillResponse.ClassesTeacher[0].Classes.ID;
                    this.CurrentSectionId = fillResponse.ClassesTeacher[0].Section.ID;
                    this.CurrentCampusId = fillResponse.ClassesTeacher[0].Campus.ID;
            
                    this.rptTeacherClass.DataSource = fillResponse.ClassesTeacher;
                    this.rptTeacherClass.DataBind();
                    HiddenField hfCurrentClassSection = (HiddenField)this.form1.FindControl("hfCurrentClassSection");
                    hfCurrentClassSection.Value = fillResponse.ClassesTeacher[0].ClassSectionName;
                    HtmlContainerControl liClassSection = (HtmlContainerControl)rptTeacherClass.Items[0].FindControl("liClassSection");
                    if (liClassSection != null)
                    {
                        liClassSection.Attributes.Add("class", "grade");
                    }
                }


                if (fillResponse.StudentsAttendace != null)
                {
                    this.RollTimeStatusId = fillResponse.StudentsAttendace[0].RollTimeAttendaceStatus.ID;
                    rptRollList.DataSource = fillResponse.StudentsAttendace;
                    rptRollList.DataBind();
                }

                if (fillResponse.RollTimeStatus != null)
                {
                    this.lblRollCallName.Text = fillResponse.RollTimeStatus.Name;
                    this.RollTimeStatusId = fillResponse.RollTimeStatus.ID;

                }
            }
            else if (pageActions == PageActions.FillStudent)
            {
                fillSearch.RollTimeStatusId = this.RollTimeStatusId;
                fillSearch.IsFillStudentAttendanceByid = true;
                FillResponse fillResponse = FillSearchManager.FillData(fillSearch);
                if (fillResponse.StudentsAttendace != null)
                {
                    rptRollList.DataSource = fillResponse.StudentsAttendace;
                    rptRollList.DataBind();
                }
            }

        }
        private List<BusinessEntities.Attendance.StudentAttendace> GetStudentAttendance()
        {
            HiddenField hfControl = null;
            Label lblControl = null;
            List<BusinessEntities.Attendance.StudentAttendace> studentsAttendance = new List<BusinessEntities.Attendance.StudentAttendace>();
            HtmlContainerControl resonTitle = null;
            for (int i = 0; i < this.rptRollList.Items.Count; i++)
            {

                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfSelectedRecord");
                if (hfControl != null && hfControl.Value.Equals("selected"))
                {
                    BusinessEntities.Attendance.StudentAttendace studentAttendace = new BusinessEntities.Attendance.StudentAttendace();
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentAttendanceId");
                    if (hfControl != null)
                    {
                        studentAttendace.ID = Convert.ToInt32(hfControl.Value);
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceStatusId");
                    if (hfControl != null)
                    {
                        studentAttendace.AttendanceStatus = new BusinessEntities.Attendance.AttendanceStatus();
                        studentAttendace.AttendanceStatus.ID = AttendaceStatus.PresntLate.GetHashCode();
                        hfControl.Value = AttendaceStatus.PresntLate.GetHashCode().ToString();
                    }
                    // Label lbl = (Label)this.rptRollList.Items[i].FindControl("pStatusId");
                    HtmlContainerControl lbl = (HtmlContainerControl)this.rptRollList.Items[i].FindControl("symbolId");
                    if (lbl != null)
                    {
                        lbl.InnerText = AttendanceSymbol.L.ToString();
                        lbl.Attributes.Add("class", AttendanceStatusName.PresentLate);
                        studentAttendace.AttendanceStatus.Name = lbl.InnerText;
                    }
                    HtmlContainerControl pStatusId = (HtmlContainerControl)this.rptRollList.Items[i].FindControl("pStatusId");
                    if (pStatusId != null)
                    {
                        pStatusId.InnerText = AttendanceStatusName.PresentLate + "--" + this.GetSelectedTime(); //AttendaceStatus.Late.ToString();
                        pStatusId.Attributes.Add("class", CssClassStatusName.orange); //.green.ToString());
                        studentAttendace.AttendanceStatus.Name = pStatusId.InnerText;

                    }
                    HtmlContainerControl min_foto = (HtmlContainerControl)this.rptRollList.Items[i].FindControl("min_foto");
                    if (min_foto != null)
                    {
                        min_foto.Attributes.Add("class", CssClassStatusName.minFotoOrange);
                    }
                    //HtmlContainerControl min_fotoId = (HtmlContainerControl)this.rptRollList.Items[i].FindControl("min_foto");
                    //if (min_fotoId != null)
                    //{
                    //    min_fotoId.Attributes.Add("class", CssClassStatusName.green.ToString());
                    //}

                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentId");
                    if (hfControl != null)
                    {
                        studentAttendace.Student = new Student();
                        studentAttendace.Student.ID = Convert.ToInt32(hfControl.Value);
                        studentAttendace.Student.StudnetClass = new BusinessEntities.Configuration.Classes();
                        studentAttendace.Student.StudnetClass.ID = this.CurrentClassId;
                        studentAttendace.Student.Section = new BusinessEntities.Configuration.Section();
                        studentAttendace.Student.Section.ID = this.CurrentSectionId;
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfNote");
                    if (hfControl != null)
                    {
                        studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfResonTitle");
                    if (hfControl != null)
                    {
                        studentAttendace.ReasonTitle = Convert.ToString(hfControl.Value);
                        resonTitle = (HtmlContainerControl)this.rptRollList.Items[i].FindControl("spReasonTitle");
                        if (resonTitle != null)
                        {
                            resonTitle.InnerText = studentAttendace.ReasonTitle;
                        }
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfRollTimeStatusId");
                    if (hfControl != null)
                    {
                        studentAttendace.RollTimeAttendaceStatus = new BusinessEntities.Attendance.RollTimeAttendaceStatus();
                        if (string.IsNullOrEmpty(hfControl.Value))
                        {
                            studentAttendace.RollTimeAttendaceStatus.ID = Convert.ToInt32(hfControl.Value);
                        }
                        else
                        {
                            studentAttendace.RollTimeAttendaceStatus.ID = this.RollTimeStatusId;
                        }
                    }
                    lblControl = (Label)this.rptRollList.Items[i].FindControl("lblName");
                    if (hfControl != null)
                    {
                        if (studentAttendace.Student == null)
                        {
                            studentAttendace.Student = new Student();
                        }
                        studentAttendace.Student.Name = Convert.ToString(lblControl.Text);

                        lblControl = (Label)this.rptRollList.Items[i].FindControl("lblLastName");
                        if (lblControl != null)
                        {
                            studentAttendace.Student.LastName = Convert.ToString(lblControl.Text);
                        }
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendance");
                    if (hfControl != null)
                    {
                        studentAttendace.AttendanceDate = Convert.ToDateTime(hfControl.Value);
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfReasonStartDate");
                    if (hfControl != null)
                    {
                        hfControl.Value = this.txtStartingDate.Text;
                        // studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfReasonEndDate");
                    if (hfControl != null)
                    {
                        hfControl.Value = this.txtToDate.Text;
                        //studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                    }

                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceDate");
                    if (hfControl != null)
                    {
                        if (!string.IsNullOrEmpty(hfControl.Value) && Convert.ToDateTime(hfControl.Value).Year != 1)
                        {
                            studentAttendace.AttendanceDate = Convert.ToDateTime(hfControl.Value);
                        }
                        else
                        {
                            // string[] theTime = DateTime.Now.ToString().Split(' ');
                            studentAttendace.AttendanceDate = GetSelectedDateTime();
                        }
                    }

                    studentsAttendance.Add(studentAttendace);
                    break;
                }
            }
            return studentsAttendance;
        }
        private List<BusinessEntities.Attendance.StudentAttendace> GetStudentAttendance(AttendaceStatus attendaceStatus, string attendanceStatusName, string cssClassStatusName, AMS.BusinessEntities.CustomEnum.AttendanceSymbol attendanceSymbol)
        {
            HiddenField hfControl = null;
            List<BusinessEntities.Attendance.StudentAttendace> studentsAttendance = new List<BusinessEntities.Attendance.StudentAttendace>();
            HtmlContainerControl resonTitle = null;
            for (int i = 0; i < this.rptRollList.Items.Count; i++)
            {

                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfSelectedRecord");
                if (hfControl != null && hfControl.Value.Equals("selected"))
                {
                    BusinessEntities.Attendance.StudentAttendace studentAttendace = new BusinessEntities.Attendance.StudentAttendace();
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentAttendanceId");
                    if (hfControl != null)
                    {
                        studentAttendace.ID = Convert.ToInt32(hfControl.Value);
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceStatusId");
                    if (hfControl != null)
                    {
                        studentAttendace.AttendanceStatus = new BusinessEntities.Attendance.AttendanceStatus();
                        studentAttendace.AttendanceStatus.ID = attendaceStatus.GetHashCode();
                        hfControl.Value = attendanceStatusName;
                    }
                    // Label lbl = (Label)this.rptRollList.Items[i].FindControl("pStatusId");
                    HtmlContainerControl lbl = (HtmlContainerControl)this.rptRollList.Items[i].FindControl("symbolId");
                    if (lbl != null)
                    {
                        lbl.InnerText = attendanceSymbol.ToString();
                        lbl.Attributes.Add("class", attendanceStatusName);
                        studentAttendace.AttendanceStatus.Name = lbl.InnerText;
                        resonTitle = (HtmlContainerControl)this.rptRollList.Items[i].FindControl("spReasonTitle");
                        if (resonTitle != null)
                        {
                            resonTitle.InnerText = attendanceSymbol.ToString();
                        }
                    }
                    HtmlContainerControl pStatusId = (HtmlContainerControl)this.rptRollList.Items[i].FindControl("pStatusId");
                    if (pStatusId != null)
                    {
                        pStatusId.InnerText = attendanceStatusName;
                        pStatusId.Attributes.Add("class", cssClassStatusName);
                        studentAttendace.AttendanceStatus.Name = pStatusId.InnerText;

                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentId");
                    if (hfControl != null)
                    {
                        studentAttendace.Student = new Student();
                        studentAttendace.Student.ID = Convert.ToInt32(hfControl.Value);

                        Label lblControl = (Label)this.rptRollList.Items[i].FindControl("lblName");
                        if (hfControl != null)
                        {
                            if (studentAttendace.Student == null)
                            {
                                studentAttendace.Student = new Student();
                            }
                            studentAttendace.Student.Name = Convert.ToString(lblControl.Text);

                            lblControl = (Label)this.rptRollList.Items[i].FindControl("lblLastName");
                            if (lblControl != null)
                            {
                                studentAttendace.Student.LastName = Convert.ToString(lblControl.Text);
                            }
                        }
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfNote");
                    if (hfControl != null)
                    {
                        studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                    }
                    //hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfResonTitle");
                    //if (hfControl != null)
                    //{
                    //    studentAttendace.ReasonTitle = Convert.ToString(hfControl.Value);
                    //    resonTitle = (HtmlContainerControl)this.rptRollList.Items[i].FindControl("spReasonTitle");
                    //    if (resonTitle != null)
                    //    {
                    //        resonTitle.InnerText = studentAttendace.ReasonTitle;
                    //    }
                    //}
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfRollTimeStatusId");
                    if (hfControl != null)
                    {
                        studentAttendace.RollTimeAttendaceStatus = new BusinessEntities.Attendance.RollTimeAttendaceStatus();
                        if (string.IsNullOrEmpty(hfControl.Value))
                        {
                            studentAttendace.RollTimeAttendaceStatus.ID = Convert.ToInt32(hfControl.Value);
                        }
                        else
                        {
                            studentAttendace.RollTimeAttendaceStatus.ID = this.RollTimeStatusId;
                        }
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfReasonStartDate");
                    if (hfControl != null)
                    {
                        hfControl.Value = this.txtStartingDate.Text;
                        // studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfReasonEndDate");
                    if (hfControl != null)
                    {
                        hfControl.Value = this.txtToDate.Text;
                        //studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                    }
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfReason");
                    if (hfControl != null)
                    {

                        studentAttendace.Reason = Convert.ToString(hfControl.Value);
                    }

                    studentsAttendance.Add(studentAttendace);
                    break;
                }
            }
            return studentsAttendance;
        }
        private List<BusinessEntities.Attendance.StudentAttendace> GetAllStudentAttendance()
        {
            HiddenField hfControl = null;
            List<BusinessEntities.Attendance.StudentAttendace> studentsAttendance = new List<BusinessEntities.Attendance.StudentAttendace>();
            for (int i = 0; i < this.rptRollList.Items.Count; i++)
            {
                BusinessEntities.Attendance.StudentAttendace studentAttendace = new BusinessEntities.Attendance.StudentAttendace();
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentAttendanceId");
                if (hfControl != null)
                {
                    studentAttendace.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceStatusId");
                if (hfControl != null)
                {
                    studentAttendace.AttendanceStatus = new BusinessEntities.Attendance.AttendanceStatus();
                    studentAttendace.AttendanceStatus.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentId");
                if (hfControl != null)
                {
                    studentAttendace.Student = new Student();
                    studentAttendace.Student.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfNote");
                if (hfControl != null)
                {
                    studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceDate");
                if (hfControl != null)
                {
                    if (!string.IsNullOrEmpty(hfControl.Value) && Convert.ToDateTime(hfControl.Value).Year != 1)
                    {
                        studentAttendace.AttendanceDate = Convert.ToDateTime(hfControl.Value);
                    }
                    else
                    {
                        // string[] theTime = DateTime.Now.ToString().Split(' ');
                        studentAttendace.AttendanceDate = GetSelectedDateTime();//Convert.ToDateTime(this.lblCurrentDateTime.Text +" "+ theTime[1] +" "+ theTime[2]);
                    }
                }

                studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                studentAttendace.RollTimeAttendaceStatus.ID = this.RollTimeStatusId;

                studentAttendace.Student.StudnetClass = new BusinessEntities.Configuration.Classes();
                studentAttendace.Student.StudnetClass.ID = this.CurrentClassId;
                studentAttendace.Student.Section = new BusinessEntities.Configuration.Section();
                studentAttendace.Student.Section.ID = this.CurrentSectionId;
                studentAttendace.Student.Campus = new BusinessEntities.Configuration.Campus();
                studentAttendace.Student.Campus.ID = this.CurrentCampusId;

                studentsAttendance.Add(studentAttendace);
            }
            return studentsAttendance;


        }
        public DateTime GetSelectedDateTime()
        {
            string[] theTime = DateTime.Now.ToString().Split(' ');
            return Convert.ToDateTime(this.lblCurrentDateTime.Text + " " + theTime[1] + " " + theTime[2]);
        }
        private string GetSelectedTime()
        {
            string[] theTime = DateTime.Now.ToString().Split(' ');
            return Convert.ToString(theTime[1] + " " + theTime[2]);
        }

        private void UpdateSelectedRecorInRepeater(List<BusinessEntities.Attendance.StudentAttendace> updateStudentAttendance)
        {
            HiddenField hfControl = null;
            for (int i = 0; i < this.rptRollList.Items.Count; i++)
            {

                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfSelectedRecord");
                if (hfControl != null && hfControl.Value.Equals("selected"))
                {
                    hfControl.Value = string.Empty;
                    // BusinessEntities.Attendance.StudentAttendace studentAttendace = new BusinessEntities.Attendance.StudentAttendace();
                    hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentAttendanceId");
                    if (hfControl != null)
                    {
                        hfControl.Value = updateStudentAttendance[0].ID.ToString();
                    }
                    //hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceStatusId");
                    //if (hfControl != null)
                    //{
                    //    hfControl.Value = AttendaceStatusName.Late.GetHashCode().ToString(); //updateStudentAttendance[0].AttendanceStatus.ID.ToString();
                    //}
                    //Label lbl = (Label)this.rptRollList.Items[i].FindControl("lblStatus");
                    //if (lbl != null)
                    //{
                    //    lbl.Text = AttendaceStatusName.Late.ToString(); //updateStudentAttendance[0].AttendanceStatus.Name.ToString();
                    //}
                    break;
                }
            }


        }
        private bool SaveAbsent(string reason, DateTime fromDate, DateTime toDate)
        {
            //using (StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager())
            //{
            StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
            List<BusinessEntities.Attendance.StudentAttendace> studentAttendance = null;
            if (!string.IsNullOrEmpty(hfCurrentAttStatusId.Value))
            {
                if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentMedical.GetHashCode())
                {
                    //studentAttendance = this.GetStudentAttendance(AttendaceStatus.Absent, CssClassStatusName.red, AttendanceSymbol.A);
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentMedical, AttendanceStatusName.AbsentMedical, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentUnauthorised.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentUnauthorised, AttendanceStatusName.AbsentUnauthorised, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentCamp.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentCamp, AttendanceStatusName.AbsentCamp, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentFamilyHoliday.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentFamilyHoliday, AttendanceStatusName.AbsentFamilyHoliday, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentMedicalwithCertificate.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentMedicalwithCertificate, AttendanceStatusName.AbsentMedicalwithCertificate, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentReligious.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentReligious, AttendanceStatusName.AbsentReligious, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentWorkExperience.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentWorkExperience, AttendanceStatusName.AbsentWorkExperience, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentParentalConsent.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentParentalConsent, AttendanceStatusName.AbsentParentalConsent, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentTruancy.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentTruancy, AttendanceStatusName.AbsentTruancy, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentEducational.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentEducational, AttendanceStatusName.AbsentEducational, CssClassStatusName.red, AttendanceSymbol.A);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.AbsentExternalSuspension.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.AbsentExternalSuspension, AttendanceStatusName.AbsentExternalSuspension, CssClassStatusName.red, AttendanceSymbol.A);
                }
                if (studentAttendance != null && studentAttendance.Count > 0)
                {
                    studentAttendance[0].Reason = reason;
                    studentAttendance[0].StartingDate = fromDate.Year == 1 ? this.GetSelectedDateTime() : fromDate;
                    studentAttendance[0].EndingDate = toDate.Year == 1 ? this.GetSelectedDateTime() : toDate;
                    studentAttendance[0].AttendanceDate = this.GetSelectedDateTime();
                    // studentAttendance[0].AttendanceStatus.ID = AttendaceStatusName.Absent.GetHashCode();
                    // studentAttendance[0].AttendanceStatus.Name = AttendaceStatusName.Absent.ToString();
                    studentAttendance = studentAttendanceManager.AddAbsents(studentAttendance, this.CurrentClassId, this.CurrentSectionId,this.CurrentCampusId, this.CurrentUser.ID);
                    this.SetContorlEnablity(PageMode.None);
                    this.RefreshData();
                    //this.UpdateSelectedRecorInRepeater(studentAttendance);
                    //FillSearch fillSearch = new FillSearch();
                    //fillSearch.ClassId = this.CurrentClassId;
                    //fillSearch.SectionId = this.CurrentSectionId;
                    //this.InitializedData(PageActions.FillStudent, fillSearch);
                }
            }
            //}
            return true;
        }
        private bool SaveEarlyLeave(string reason)
        {
            //using (StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager())
            //{
            StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
            List<BusinessEntities.Attendance.StudentAttendace> studentAttendance = null;
            if (!string.IsNullOrEmpty(hfCurrentAttStatusId.Value))
            {
                if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.EarlyLeaveMedical.GetHashCode())
                {
                    //studentAttendance = this.GetStudentAttendance(AttendaceStatus.Absent, CssClassStatusName.red, AttendanceSymbol.A);
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.EarlyLeaveMedical, AttendanceStatusName.EarlyLeaveMedical, CssClassStatusName.green, AttendanceSymbol.P);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.EarlyLeaveParentalConsent.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.EarlyLeaveParentalConsent, AttendanceStatusName.EarlyLeaveParentalConsent, CssClassStatusName.green, AttendanceSymbol.P);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.EarlyLeaveExternalSuspension.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.EarlyLeaveExternalSuspension, AttendanceStatusName.EarlyLeaveExternalSuspension, CssClassStatusName.green, AttendanceSymbol.P);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.EarlyLeaveEducational.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.EarlyLeaveEducational, AttendanceStatusName.EarlyLeaveEducational, CssClassStatusName.green, AttendanceSymbol.P);
                }
                else if (Convert.ToInt32(hfCurrentAttStatusId.Value) == AttendaceStatus.EarlyLeaveHalfDay.GetHashCode())
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.EarlyLeaveHalfDay, AttendanceStatusName.EarlyLeaveHalfDay, CssClassStatusName.green, AttendanceSymbol.P);
                }
                else
                {
                    studentAttendance = this.GetStudentAttendance(AttendaceStatus.EarlyLeave, AttendanceStatusName.EarlyLeave, CssClassStatusName.green, AttendanceSymbol.P);
                }
                if (studentAttendance != null && studentAttendance.Count > 0)
                {
                    studentAttendance[0].AttendanceDate = GetSelectedDateTime();//DateTime.Now;
                    studentAttendance[0].RollTimeAttendaceStatus = new BusinessEntities.Attendance.RollTimeAttendaceStatus();
                    studentAttendance[0].RollTimeAttendaceStatus.ID = RollTimeStatusName.EveningRollTimeId;
                    studentAttendance[0].Remarks = reason;
                    this.PassData = studentAttendance[0];
                    this.SetEarlyPassStudenData(studentAttendance[0]);
                    studentAttendance = studentAttendanceManager.AddEarlyLeaves(studentAttendance, this.CurrentUser.ID);
                    this.SetContorlEnablity(PageMode.None);
                    this.RefreshData();

                    //FillSearch fillSearch = new FillSearch();
                    //fillSearch.ClassId = this.CurrentClassId;
                    //fillSearch.SectionId = this.CurrentSectionId;
                    //this.InitializedData(PageActions.FillStudent, fillSearch);
                }
            }
            //}
            return true;
        }
        private void SetVisibilityOfDate(bool handalCalender)
        {

            this.history_arrow.Visible = (lnkbtnCancel.Text.Equals("Date") && handalCalender);
            this.history.Visible = (lnkbtnCancel.Text.Equals("Date") && handalCalender);
            if ((lnkbtnCancel.Text.Equals("Date") && handalCalender))
            {
                // this.cldrAttendance.SelectedDate = DateTime.Now;

                // this.cldrAttendance.VisibleDate = DateTime.Now;*/

                DateTime dateToSet = DateTime.Parse(DateTime.Now.ToShortDateString());
                this.cldrAttendance.SelectedDate = dateToSet;
                this.cldrAttendance.VisibleDate = dateToSet;
                this.lblCalenderDate.Text = this.cldrAttendance.SelectedDate.ToString("dd-MMM-yyyy");
            }
        }
        private void BindGridByDate(int roltimeStatusId, DateTime searchDate)
        {
            StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
            List<AMS.BusinessEntities.Attendance.StudentAttendace> studentsAttendace = null;
            studentsAttendace = studentAttendanceManager.SearchByDate(this.CurrentClassId, this.CurrentSectionId, this.CurrentCampusId, roltimeStatusId, this.CurrentUser.LoginUserId, searchDate);
            if (studentsAttendace != null && studentsAttendace.Count > 0)
            {
                this.rptRollList.DataSource = studentsAttendace;
                this.rptRollList.DataBind();
                this.SetVisibilityOfDate(false);
            }
            else
            {

                // MessageAlert.Show("Record not found.");
                ShowMsg("Record not found.");
            }
        }
        public void ShowMsg(string msg)
        {
            ScriptManager.RegisterStartupScript(this, typeof(Button), "Message", "alert('" + msg + "');", true);

        }
        #endregion
        #region repeater teacher Events
       
        protected void rptTeacherClass_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            HiddenField hf = null;
            FillSearch fillSearch = new FillSearch();
            try
            {
                hf = (HiddenField)e.Item.FindControl("hfClassId");
                if (hf != null)
                {
                    fillSearch.ClassId = Convert.ToInt32(hf.Value);
                    this.CurrentClassId = fillSearch.ClassId;
                }
                hf = (HiddenField)e.Item.FindControl("hfSectionId");
                if (hf != null)
                {
                    fillSearch.SectionId = Convert.ToInt32(hf.Value);
                    this.CurrentSectionId = fillSearch.SectionId;
                }
                hf = (HiddenField)e.Item.FindControl("hfCampusId");
                if (hf != null)
                {
                    fillSearch.CampusId = Convert.ToInt32(hf.Value);
                    this.CurrentCampusId = fillSearch.CampusId;
                }

                if (lblCurrentDateTime.Text == DateTime.Now.ToString("dd-MMM-yyyy "))
                {
                    this.InitializedData(PageActions.FillStudent, fillSearch);
                }
                else
                {
                    this.BindGridByDate(this.RollTimeStatusId, Convert.ToDateTime(lblCalenderDate.Text));
                }
                this.SetContorlEnablity(PageMode.None);
                HtmlContainerControl liClassSection = null;
                foreach(RepeaterItem rptItem in this.rptTeacherClass.Items)
                {
                    liClassSection = (HtmlContainerControl)rptItem.FindControl("liClassSection");
                    if (liClassSection != null)
                    {
                        liClassSection.Attributes.Add("class", "");

                        //break;
                    }
                
                }
                liClassSection = (HtmlContainerControl)e.Item.FindControl("liClassSection");
                if (liClassSection != null)
                {
                    liClassSection.Attributes.Add("class", "grade");
                }
                //this.largeImage.Src = "../Images/full_avatar.jpg";
            }
            catch
            {
            }
        }
        protected void rptRollList_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            HiddenField hfControl = null;
            if (e.CommandName != null && e.CommandName.Equals("cmdCarat"))
            {
                hfControl = (HiddenField)e.Item.FindControl("hfLargePicture");
                this.largeImage.Src = hfControl.Value;
                hfControl = (HiddenField)e.Item.FindControl("hfSelectedRecord");
                hfControl.Value = "selected";
            }
        }
       
        #endregion
        #region Web Methods
        [WebMethod]
        public static string LoadStudentPicture(int studentId)
        {
            AMS.BusinessEntities.Attendance.StudentAttendace os = new BusinessEntities.Attendance.StudentAttendace();

            HttpContext.Current.Session["StudentId"] = studentId;
            string fullPhoto = "../Images/SuhailShahab.jpg";
            //../Images/full_avatar.jpg;
            return fullPhoto;


        }
        #endregion

        #region Button Event

        protected void lnkbtnLogOut_Click(object sender, EventArgs e)
        {
            this.Session.Abandon();
            Response.Redirect(PageUrl.loginPageUrl);
        }
        protected void btnOk_Click(object sender, EventArgs e)
        {
            try
            {

                if (!string.IsNullOrEmpty(this.txtStartingDate.Text.Trim()) && !string.IsNullOrEmpty(this.txtToDate.Text.Trim()))
                {
                    IFormatProvider au = new CultureInfo("en-AU", true);
                    DateTime fromDate = DateTime.ParseExact(txtStartingDate.Text, "dd/MM/yyyy", au);//Convert.ToDateTime(this.txtStartingDate.Text);
                    DateTime toDate = DateTime.ParseExact(txtToDate.Text, "dd/MM/yyyy", au);//Convert.ToDateTime(this.txtToDate.Text);
                    this.SaveAbsent(this.txtNote.Text.Trim(), fromDate, toDate);
                    //this.txtNote.Text = string.Empty;
                    // this.txtToDate.Text = string.Empty;
                    // this.txtStartingDate.Text = string.Empty;

                }
            }
            catch
            {
            }
        }
        protected void btnEarlyOk_Click(object sender, EventArgs e)
        {
            try
            {

                //if (!string.IsNullOrEmpty(this.txtStartingDate.Text.Trim()) && !string.IsNullOrEmpty(this.txtToDate.Text.Trim()) && !string.IsNullOrEmpty(this.txtNote.Text.Trim()))
                {
                    //DateTime fromDate = Convert.ToDateTime(this.txtStartingDate.Text);
                    //DateTime toDate = Convert.ToDateTime(this.txtToDate.Text);
                    //this.SaveEarlyLeave(this.txtEarlyNote.Text.Trim());
                    //this.txtNote.Text = string.Empty;
                    // this.txtToDate.Text = string.Empty;
                    // this.txtStartingDate.Text = string.Empty;

                }
            }
            catch
            {
            }
        }
        protected void lnkbtnCloseCalendar_OnClick(object sender, EventArgs e)
        {
            this.SetVisibilityOfDate(false);
        }
        protected void lnkbtnCancel_OnClick(object sender, EventArgs e)
        {
            bool handalCalender = (this.history_arrow.Visible ? false : true);
            this.SetVisibilityOfDate(handalCalender);
            this.SetContorlEnablity(PageMode.None);

        }
        private void SetContorlEnablity(PageMode pageMode)
        {
            if (pageMode == PageMode.None)
            {
                this.lnkbtnCancel.Text = "Date";
                this.lnkbtnSave.Text = "Edit";
                this.PageModes = PageMode.Edit;

            }
            else if (pageMode == PageMode.Edit)
            {
                this.lnkbtnCancel.Text = "Cancel";
                this.lnkbtnSave.Text = "Save";
                this.PageModes = PageMode.Save;

            }
            else if (pageMode == PageMode.Save)
            {
                this.lnkbtnCancel.Text = "Date";
                this.lnkbtnSave.Text = "Edit";
                this.PageModes = PageMode.Edit;
            }
            if (this.RollTimeStatusId == RollTimeStatusName.EveningRollTimeId && pageMode == PageMode.None)
            {
                //btnMarkPresent.Visible = false;
                btnMarkPresent.Attributes.Add("style", "display:none");
                btnMarkEarly.Attributes.Add("style", "display:block");
               

            }
            //  this.history_arrow.Visible = false;
            // this.history.Visible = false;
        }
        private void SetContorlEnablity()
        {
            lnkbtnSave.Enabled = !(Convert.ToDateTime(lblCurrentDateTime.Text) > DateTime.Now.Date);

        }
        protected void cldrAttendance_SelectionChanged(object sender, EventArgs e)
        {
            lblCalenderDate.Text = this.cldrAttendance.SelectedDate.ToString("dd-MMM-yyyy");
        }
        protected void cldrAttendance_DayRender(object sender, DayRenderEventArgs e)
        {
            daysCounter++;

            if (e.Day.Date.Day == 1 && !e.Day.IsOtherMonth) // 1st of current month. Turn visibility of row to ON.
            {
                isLastRow = false;
            }
            else if (daysCounter == 36 && e.Day.IsOtherMonth) // 5 rows already rendered. If its the next row is next month, hide it.
            {
                isLastRow = true;
            }
            else if (daysCounter == 1 && e.Day.IsOtherMonth && e.Day.Date.Month == e.Day.Date.AddDays(6).Month)
            {   // If first row completely is previous month, hide it. 
                // Actually the flag should be isFirstRow, but I dont want one more boolean just for the sake of it.
                isLastRow = true;
            }

            if (isLastRow)
                e.Cell.Visible = false;

        }
        protected void lnkbtnAM_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(lblCalenderDate.Text))
                {
                    this.BindGridByDate(RollTimeStatusName.MoringRollTimeId, Convert.ToDateTime(lblCalenderDate.Text));
                    lblCurrentDateTime.Text = lblCalenderDate.Text;
                    lblRollCallName.Text = RollTimeStatusName.MoringRollTime;
                    this.RollTimeStatusId = RollTimeStatusName.MoringRollTimeId;
                    // this.SetContorlEnablity();
                }
                else
                {
                    MessageAlert.Show("Please select date.");
                }
            }
            catch
            {
            }
        }
        protected void lnkbtnPM_OnClick(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(lblCalenderDate.Text))
            {
                this.BindGridByDate(RollTimeStatusName.EveningRollTimeId, Convert.ToDateTime(lblCalenderDate.Text));
                lblCurrentDateTime.Text = lblCalenderDate.Text;
                lblRollCallName.Text = RollTimeStatusName.EveningRollTime;
                this.RollTimeStatusId = RollTimeStatusName.EveningRollTimeId;
                // this.SetContorlEnablity();
                
            }
            else
            {
                MessageAlert.Show("Please select date.");
            }
        }
        protected void lnkbtnSave_OnClick(object sender, EventArgs e)
        {
            try
            {

                if (this.PageModes == PageMode.Edit)
                {
                    this.SetContorlEnablity(this.PageModes);
                }
                else if (this.PageModes == PageMode.Save)
                {
                    StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
                    List<AMS.BusinessEntities.Attendance.StudentAttendace> studentsAttendace = studentAttendanceManager.AddWithOutReason(this.GetAllStudentAttendance(), this.CurrentUser.ID,this.CurrentUser.Role.ID);
                    this.SetContorlEnablity(PageMode.None);
                    RefreshData();


                }
                SetVisibilityOfDate(false);
            }
            catch// (Exception ex)
            {
            }
        }
        private void RefreshData()
        {
            if (DateTime.Now.ToString("dd-MMM-yyyy").Equals(this.lblCurrentDateTime.Text.Trim()))
            {
                this.SetContorlEnablity(PageMode.None);
                FillSearch fillSearch = new FillSearch();
                fillSearch.ClassId = this.CurrentClassId;
                fillSearch.SectionId = this.CurrentSectionId;
                fillSearch.CampusId = this.CurrentCampusId;
                fillSearch.RollTimeStatusId = this.RollTimeStatusId;
                fillSearch.IsFillStudentAttendanceByid = true;
                this.InitializedData(PageActions.FillStudent, fillSearch);
            }
            else
            {
                this.BindGridByDate(this.RollTimeStatusId, Convert.ToDateTime(this.lblCurrentDateTime.Text));
            }
        }
        #endregion

        protected void btnMarkPresent_Click(object sender, EventArgs e)
        {
            try
            {
                
                StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
                List<AMS.BusinessEntities.Attendance.StudentAttendace> studentsAttendace = studentAttendanceManager.Add(this.GetStudentAttendance(), this.CurrentUser.ID);
                Session["StudentAttendanceId"] = studentsAttendace[0].ID;
                this.UpdateSelectedRecorInRepeater(studentsAttendace);
                this.reasons.Visible = false;
                this.receipt.Visible = true;
                this.PassData = studentsAttendace[0];
                SetLateStudenData(studentsAttendace[0]);
                this.RefreshData();
            }
            catch
            {
            }
        }
        protected void btnMarkEarly_Click(object sender, EventArgs e)
        {
            try
            {
                this.SaveEarlyLeave(this.txtEarlyNote.Text.Trim());

                // StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
                //List<AMS.BusinessEntities.Attendance.StudentAttendace> studentsAttendace = studentAttendanceManager.AddEarlyLeaves(this.GetStudentAttendance(AttendaceStatus.e), this.CurrentUser.ID);
                //Session["StudentAttendanceId"] = studentsAttendace[0].ID;
                // this.UpdateSelectedRecorInRepeater(studentsAttendace);
                // this.ea.reasons.Visible = false;
                this.Earlyreceipt.Visible = true;
                //this.PassData = studentsAttendace[0];
                //SetEarlyPassStudenData(studentsAttendace[0]);
            }
            catch
            {
            }
        }
        private void SetLateStudenData(AMS.BusinessEntities.Attendance.StudentAttendace studentAttendace)
        {
            StringBuilder stringBuilder = new StringBuilder();
            if (studentAttendace != null)
            {
                stringBuilder.Append(studentAttendace.Student.Name);
                stringBuilder.Append(" ");
                stringBuilder.Append(studentAttendace.Student.LastName);
                if (stringBuilder != null && stringBuilder.Length > 0)
                {
                    lblLateStudentName.Text = stringBuilder.ToString();
                }
                stringBuilder.Clear();
                String[] theDateTime = studentAttendace.AttendanceDate.ToString().Split(' ');
                if (studentAttendace.AttendanceDate.Year < 1998)
                {
                    theDateTime = DateTime.Now.ToString().Split(' ');
                    // lblLateDateTime.Text = //DateTime.Today.ToString("G", CultureInfo.CreateSpecificCulture("en-us"));// ToString("HH:mm-- dd-MMMM-yyyy");
                    stringBuilder.Append(theDateTime[1]);
                    stringBuilder.Append(" ");
                    stringBuilder.Append(theDateTime[2]);
                    stringBuilder.Append("-");
                    stringBuilder.Append("-");
                    stringBuilder.Append(DateTime.Now.ToString("dd-MMMM-yyyy"));
                    if (stringBuilder != null && stringBuilder.Length > 0)
                    {
                        lblLateDateTime.Text = stringBuilder.ToString();
                    }
                }
                else
                {
                    stringBuilder.Append(theDateTime[1]);
                    stringBuilder.Append(" ");
                    stringBuilder.Append(theDateTime[2]);
                    stringBuilder.Append("-");
                    stringBuilder.Append("-");
                    stringBuilder.Append(studentAttendace.AttendanceDate.ToString("dd-MMMM-yyyy"));
                    //stringBuilder.Append(studentAttendace.AttendanceDate.ToLocalTime());
                    if (stringBuilder != null && stringBuilder.Length > 0)
                    {
                        lblLateDateTime.Text = stringBuilder.ToString();
                    }
                }
            }
        }
        private void SetEarlyPassStudenData(AMS.BusinessEntities.Attendance.StudentAttendace studentAttendace)
        {
            StringBuilder stringBuilder = new StringBuilder();
            if (studentAttendace != null)
            {
                stringBuilder.Append(studentAttendace.Student.Name);
                stringBuilder.Append(" ");
                stringBuilder.Append(studentAttendace.Student.LastName);
                if (stringBuilder != null && stringBuilder.Length > 0)
                {
                    lblEarlyStudentName.Text = stringBuilder.ToString();
                }
                stringBuilder.AppendLine(" ");
                lblReason.Text = studentAttendace.Reason;
                stringBuilder.Clear();
                String[] theDateTime = studentAttendace.AttendanceDate.ToString().Split(' ');
                if (studentAttendace.AttendanceDate.Year < 1998)
                {
                    theDateTime = DateTime.Now.ToString().Split(' ');
                    // lblLateDateTime.Text = //DateTime.Today.ToString("G", CultureInfo.CreateSpecificCulture("en-us"));// ToString("HH:mm-- dd-MMMM-yyyy");
                    stringBuilder.Append(theDateTime[1]);
                    stringBuilder.Append(" ");
                    stringBuilder.Append(theDateTime[2]);
                    stringBuilder.Append("-");
                    stringBuilder.Append("-");
                    stringBuilder.Append(DateTime.Now.ToString("dd-MMMM-yyyy"));
                    if (stringBuilder != null && stringBuilder.Length > 0)
                    {
                        lblEarlyPassDateTime.Text = stringBuilder.ToString();
                    }
                }
                else
                {
                    stringBuilder.Append(theDateTime[1]);
                    stringBuilder.Append(" ");
                    stringBuilder.Append(theDateTime[2]);
                    stringBuilder.Append("-");
                    stringBuilder.Append("-");
                    stringBuilder.Append(studentAttendace.AttendanceDate.ToString("dd-MMMM-yyyy"));
                    //stringBuilder.Append(studentAttendace.AttendanceDate.ToLocalTime());
                    if (stringBuilder != null && stringBuilder.Length > 0)
                    {
                        lblEarlyPassDateTime.Text = stringBuilder.ToString();
                    }
                }
            }
        }
        private string GetLateStudenData(AMS.BusinessEntities.Attendance.StudentAttendace studentAttendace)
        {
            StringBuilder stringBuilder = new StringBuilder();
            if (studentAttendace != null)
            {
                stringBuilder.AppendLine("      Late Pass ");
                stringBuilder.AppendLine("");
                stringBuilder.Append(studentAttendace.Student.Name);
                stringBuilder.Append(" ");
                stringBuilder.AppendLine(studentAttendace.Student.LastName);
                //if (stringBuilder != null && stringBuilder.Length > 0)
                //{
                //    lblLateStudentName.Text = stringBuilder.ToString();
                //}
                // stringBuilder.Clear();
                String[] theDateTime = studentAttendace.AttendanceDate.ToString().Split(' ');
                if (studentAttendace.AttendanceDate.Year < 1998)
                {
                    theDateTime = DateTime.Now.ToString().Split(' ');
                    // lblLateDateTime.Text = //DateTime.Today.ToString("G", CultureInfo.CreateSpecificCulture("en-us"));// ToString("HH:mm-- dd-MMMM-yyyy");
                    stringBuilder.Append(theDateTime[1]);
                    stringBuilder.Append(" ");
                    stringBuilder.Append(theDateTime[2]);
                    stringBuilder.Append("-");
                    stringBuilder.Append("-");
                    stringBuilder.Append(DateTime.Now.ToString("dd-MMMM-yyyy"));
                    //if (stringBuilder != null && stringBuilder.Length > 0)
                    //{
                    //    lblLateDateTime.Text = stringBuilder.ToString();
                    //}
                }
                else
                {
                    stringBuilder.Append(theDateTime[1]);
                    stringBuilder.Append(" ");
                    stringBuilder.Append(theDateTime[2]);
                    stringBuilder.Append("-");
                    stringBuilder.Append("-");
                    stringBuilder.Append(studentAttendace.AttendanceDate.ToString("dd-MMMM-yyyy"));
                    //stringBuilder.Append(studentAttendace.AttendanceDate.ToLocalTime());
                    //if (stringBuilder != null && stringBuilder.Length > 0)
                    //{
                    //    lblLateDateTime.Text = stringBuilder.ToString();
                    //}
                }
            }

            if (stringBuilder != null && stringBuilder.Length > 0)
            {
                return stringBuilder.ToString();
            }
            else
            {
                return null;
            }
        }
        private DataSet GetPassData()
        {
            DataSet ds = new DataSet();
            DataColumn dcStatus = new DataColumn("Status", typeof(string));
            DataColumn dcFirstName = new DataColumn("FirstName", typeof(string));
            DataColumn dcLastName = new DataColumn("LastName", typeof(string));
            DataColumn dcAttendanceDate = new DataColumn("AttendanceDate", typeof(DateTime));
            DataColumn dcReason = new DataColumn("Reason", typeof(string));

            DataTable dtUMS_LatePass = new DataTable("UMS_LatePass");
            dtUMS_LatePass.Columns.Add(dcStatus);
            dtUMS_LatePass.Columns.Add(dcFirstName);
            dtUMS_LatePass.Columns.Add(dcLastName);
            dtUMS_LatePass.Columns.Add(dcAttendanceDate);
            dtUMS_LatePass.Columns.Add(dcReason);

            DataRow dr = dtUMS_LatePass.NewRow();
            dr["FirstName"] = this.PassData.Student.Name;
            dr["LastName"] = this.PassData.Student.LastName;
            if (this.PassData.AttendanceDate.Year == 1)
            {
                dr["AttendanceDate"] = DateTime.Now;
            }
            else
            {
                dr["AttendanceDate"] = this.PassData.AttendanceDate;
            }
            dr["Status"] = this.PassData.AttendanceStatus.Name;
            if (string.IsNullOrEmpty(this.PassData.Reason))
            {
                dr["Reason"] = "";
            }
            else
            {
                dr["Reason"] = this.PassData.Reason;
            }
            dtUMS_LatePass.Rows.Add(dr);
            ds.Tables.Add(dtUMS_LatePass);
            return ds;
        }
        protected void btnPrintRecept_Click(object sender, EventArgs e)
        {
            try
            {
                // Response.Redirect(PageUrl.latePassViewUrl, true);
                // String fullpath = PageUrl.latePassViewUrl;
                // String attributes = "scrollbars,menubar,resizable,status,width=600,height=400";
                // ltrJavscript.Text = "<script type= \"text/javascript\" >window.open('" + fullpath.ToString() + "','','" + attributes.ToString() + "'); </script>";
                /// ClientScript.RegisterClientScriptBlock(this, typeof(Button), "Message", ltrJavscript.Text, true);


                //PrintDocument p = new PrintDocument();
                //if (this.LatePassData != null)
                //{
                //    string s = this.GetLateStudenData(this.LatePassData);
                //    p.PrintPage += delegate(object sender1, PrintPageEventArgs e1)
                //    {
                //        e1.Graphics.DrawString(s, new Font("Times New Roman", 12), new SolidBrush(Color.Black), new RectangleF(50, 50, 250, 450));

                //    };
                //    try
                //    {
                //        p.Print();
                //    }
                //    catch (Exception ex)
                //    {
                //        throw new Exception("Exception Occured While Printing", ex);
                //    }
                //}
                //this.reasons.Visible = true;
                DataSet ds = this.GetPassData();
                if (ds != null && ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                {
                    ReportDocument rptDoc = new ReportDocument();
                    rptDoc.Load(Server.MapPath(PageUrl.latePassReportUrl));
                    rptDoc.SetDataSource(ds.Tables["UMS_LatePass"]);
                    rptDoc.PrintToPrinter(1, false, 0, 0);
                    // crvLatePass.ReportSource = rptDoc;
                }
            }
            catch
            {
            }
        }
        protected void btnEarlyPrentRecept_Click(object sender, EventArgs e)
        {
            try
            {
                //DataSet ds = new ReportManager().GetLatePassReportData(this.PassData.ID);
                DataSet ds = this.GetPassData();
                if (ds != null && ds.Tables != null && ds.Tables[0].Rows.Count > 0)
                {
                    ReportDocument rptDoc = new ReportDocument();
                    rptDoc.Load(Server.MapPath(PageUrl.earlyLeavePassReportUrl));
                    rptDoc.SetDataSource(ds.Tables["UMS_LatePass"]);
                    rptDoc.PrintToPrinter(1, false, 0, 0);
                    // crvLatePass.ReportSource = rptDoc;
                }
            }
            catch
            {
            }
        }

        protected void lnkBtnStudentReport_Click(object sender, EventArgs e)
        {
            try
            {
                ReportParameters.ReportType = ReportType.DailyAbsenteesReport;
                IFormatProvider au = new CultureInfo("en-AU", true);
                ReportParameters.CurrentDate = Convert.ToDateTime(this.lblCurrentDateTime.Text); //DateTime.ParseExact(this.lblCurrentDateTime.Text, "dd/MM/yyyy", au);
                CheckBox cbClasses = (CheckBox)rptTeacherClass.Controls.OfType<RepeaterItem>().Single(ri => ri.ItemType == ListItemType.Header).FindControl("chkAllClasses");
                //String fullpath = Server.MapPath("~/Reports/Templates/AttendanceReportView.aspx");
                //String attributes = "scrollbars,menubar,resizable,status,width=600,height=400";
                //ltrJavscript.Text = "<script type= \"text/javascript\" >window.open('" + fullpath + "','','" + attributes.ToString() + "'); </script>";
                //ClientScript.RegisterClientScriptBlock( typeof(Button), "Message", ltrJavscript.Text, true);
                Response.Redirect("~/Reports/Templates/AttendanceReportView.aspx?QryStrClassId=" + this.CurrentClassId + "&QryStrSectionId=" + this.CurrentSectionId + "&QryStrCampusId=" + this.CurrentCampusId + "&IsAllClasses=" + cbClasses.Checked, false);

            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }
        protected void lnkBtnSummaryAbsentReport_Click(object sender, EventArgs e)
        {
            try
            {
                ReportParameters.ReportType = ReportType.SummaryAbsentReport;
                IFormatProvider au = new CultureInfo("en-AU", true);
                ReportParameters.CurrentDate = Convert.ToDateTime(this.lblCurrentDateTime.Text); //DateTime.ParseExact(this.lblCurrentDateTime.Text, "dd/MM/yyyy", au);
                CheckBox cbClasses = (CheckBox)rptTeacherClass.Controls.OfType<RepeaterItem>().Single(ri => ri.ItemType == ListItemType.Header).FindControl("chkAllClasses");
                //String fullpath = Server.MapPath("~/Reports/Templates/AttendanceReportView.aspx");
                //String attributes = "scrollbars,menubar,resizable,status,width=600,height=400";
                //ltrJavscript.Text = "<script type= \"text/javascript\" >window.open('" + fullpath + "','','" + attributes.ToString() + "'); </script>";
                //ClientScript.RegisterClientScriptBlock( typeof(Button), "Message", ltrJavscript.Text, true);
                Response.Redirect("~/Reports/Templates/AttendanceReportView.aspx?QryStrClassId=" + this.CurrentClassId + "&QryStrSectionId=" + this.CurrentSectionId + "&QryStrCampusId=" + this.CurrentCampusId + "&IsAllClasses=" + cbClasses.Checked, false);

            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }

        protected void lnkBtnClassReport_Click(object sender, EventArgs e)
        {
            try
            {
                ReportParameters.ReportType = ReportType.DailyAttendanceReport;
                // IFormatProvider au = new CultureInfo("en-AU", true);               
                ReportParameters.CurrentDate = Convert.ToDateTime(this.lblCurrentDateTime.Text); //DateTime.ParseExact(this.lblCurrentDateTime.Text, "dd/MM/yyyy", au);
                CheckBox cbClasses = (CheckBox)rptTeacherClass.Controls.OfType<RepeaterItem>().Single(ri => ri.ItemType == ListItemType.Header).FindControl("chkAllClasses");
                //String fullpath = Server.MapPath("~/Reports/Templates/AttendanceReportView.aspx");
                //String attributes = "scrollbars,menubar,resizable,status,width=600,height=400";
                //ltrJavscript.Text = "<script type= \"text/javascript\" >window.open('" + fullpath + "','','" + attributes.ToString() + "'); </script>";
                //ClientScript.RegisterClientScriptBlock( typeof(Button), "Message", ltrJavscript.Text, true);                
                Response.Redirect("~/Reports/Templates/AttendanceReportView.aspx?QryStrClassId=" + this.CurrentClassId + "&QryStrSectionId=" + this.CurrentSectionId + "&QryStrCampusId=" + this.CurrentCampusId + "&IsAllClasses=" + cbClasses.Checked, false);

            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }
        protected void lnkBtnPriClassReport_Click(object sender, EventArgs e)
        {
            try
            {
                ReportParameters.ReportType = ReportType.PrimaryReport;
                ReportParameters.CurrentDate = Convert.ToDateTime(this.lblCurrentDateTime.Text); //DateTime.ParseExact(this.lblCurrentDateTime.Text, "dd/MM/yyyy", au);
                CheckBox cbClasses = (CheckBox)rptTeacherClass.Controls.OfType<RepeaterItem>().Single(ri => ri.ItemType == ListItemType.Header).FindControl("chkAllClasses");

                Response.Redirect("~/Reports/Templates/AttendanceReportView.aspx?QryStrClassId=" + this.CurrentClassId + "&QryStrSectionId=" + this.CurrentSectionId + "&QryStrCampusId=" + this.CurrentCampusId + "&IsAllClasses=" + cbClasses.Checked, false);

            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }
        protected void lnkBtnSecClassReport_Click(object sender, EventArgs e)
        {
            try
            {
                ReportParameters.ReportType = ReportType.SecondaryReport;
                ReportParameters.CurrentDate = Convert.ToDateTime(this.lblCurrentDateTime.Text); //DateTime.ParseExact(this.lblCurrentDateTime.Text, "dd/MM/yyyy", au);
                CheckBox cbClasses = (CheckBox)rptTeacherClass.Controls.OfType<RepeaterItem>().Single(ri => ri.ItemType == ListItemType.Header).FindControl("chkAllClasses");

                Response.Redirect("~/Reports/Templates/AttendanceReportView.aspx?QryStrClassId=" + this.CurrentClassId + "&QryStrSectionId=" + this.CurrentSectionId + "&QryStrCampusId=" + this.CurrentCampusId + "&IsAllClasses=" + cbClasses.Checked, false);

            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }
        protected void lnkbtnEmailSend_Click(object sender, EventArgs e)
        {
            try
            {
                //  StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
                //  MessageResponseManager messageResponseManager =new MessageResponseManager();
                /* DateTime formDate = DateTime.Now.AddDays(-6);
                 List<StudentAttendace> studentAttendance = studentAttendanceManager.GetLateStudentByDate(formDate, DateTime.Now);
                 List<ClassCoordinator> classCoordinator =  messageResponseManager.GetAllCoordinators();
                 if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                 {
                     MessageHelper.OnTimedEventForLateStudent(studentAttendance, classCoordinator, formDate, DateTime.Now);
                 }*/

                /* List<ClassCoordinator> classCoordinator = messageResponseManager.GetAllCoordinators();
                 List<StudentAttendace> studentAttendance =  studentAttendanceManager.GetUnMarkStudents(RollTimeStatusName.MoringRollTimeId, AttendaceStatus.UnMarked.GetHashCode());
                 if (studentAttendance != null && studentAttendance.Count > 0 && classCoordinator != null && classCoordinator.Count > 0)
                 {
                     MessageHelper.OnTimedEventForUnMarkStudent(studentAttendance, classCoordinator, RollTimeStatusName.MoringRollTime);
                 }*/

                //  MessageHelper.OnTimedEvent("", null);
                MessageHelper messageHelper = null;
                bool enableTimer = Convert.ToBoolean(System.Web.Configuration.WebConfigurationManager.AppSettings["EnableTime"]);
                if (enableTimer)
                {
                    messageHelper = new MessageHelper();
                    messageHelper.InitilizeTimerExecuteMessageJob();
                }
            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }
        protected void lnkBtnReporting_Click(object sender, EventArgs e)
        {
            try
            {
                FillDrowpDown();
                this.ModalPopupExtenderReporting.Show();

            }
            catch
            {
            }
        }
        protected void btnDailyStatsReport_Click(object sender, EventArgs e)
        {
            try
            {
                ReportParameters.ReportType = ReportType.StatsDailyReport;
                BusinessEntities.Attendance.StudentClassAssociation criteria = new BusinessEntities.Attendance.StudentClassAssociation();
                criteria.Campus = new BusinessEntities.Configuration.Campus();
                criteria.Campus.ID = Convert.ToInt32(ddlCampus.Text);
                criteria.StudentClass = new BusinessEntities.Configuration.Classes();
                criteria.StudentClass.ID = Convert.ToInt32(ddlClass.Text);
                //criteria.Section = new BusinessEntities.Configuration.Section();
                //criteria.Section.ID = Convert.ToInt32(ddlSection.Text);

                //criteria.Teacher = new BusinessEntities.Teacher.Teacher();
                //criteria.Teacher.ID = Convert.ToInt32(ddlTeacher.Text);
                //criteria.RollTimeAttendanceStatus = new BusinessEntities.Attendance.RollTimeAttendaceStatus();
                //criteria.RollTimeAttendanceStatus.ID = Convert.ToInt32(ddlRollCallStatus.Text);
                criteria.StartDate = Convert.ToDateTime(txtPopupFromDate.Text.ToString());
                criteria.EndDate = Convert.ToDateTime(txtPopupToDate.Text.ToString());
                Session["StatsReportCriteria"] = criteria;

                string statsReportingPageURL = "~/Reports/Templates/AttendanceReportView.aspx";
                Response.Redirect(statsReportingPageURL, false);

                
            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }

        protected void btnSummaryStatsReport_Click(object sender, EventArgs e)
        {
            try
            {

                ReportParameters.ReportType = ReportType.StatsSummaryReport;
                BusinessEntities.Attendance.StudentClassAssociation criteria = new BusinessEntities.Attendance.StudentClassAssociation();
                criteria.Campus = new BusinessEntities.Configuration.Campus();
                criteria.Campus.ID = Convert.ToInt32(ddlCampus.Text);
                criteria.StudentClass = new BusinessEntities.Configuration.Classes();
                criteria.StudentClass.ID = Convert.ToInt32(ddlClass.Text);
                //criteria.Section = new BusinessEntities.Configuration.Section();
                //criteria.Section.ID = Convert.ToInt32(ddlSection.Text);

                //criteria.Teacher = new BusinessEntities.Teacher.Teacher();
                //criteria.Teacher.ID = Convert.ToInt32(ddlTeacher.Text);
                //criteria.RollTimeAttendanceStatus = new BusinessEntities.Attendance.RollTimeAttendaceStatus();
                //criteria.RollTimeAttendanceStatus.ID = Convert.ToInt32(ddlRollCallStatus.Text);
                criteria.StartDate = Convert.ToDateTime(txtPopupFromDate.Text.ToString());
                criteria.EndDate = Convert.ToDateTime(txtPopupToDate.Text.ToString());
                Session["StatsReportCriteria"] = criteria;

                string statsReportingPageURL = "~/Reports/Templates/AttendanceReportView.aspx";
                Response.Redirect(statsReportingPageURL, false);


            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }
        //protected void btnCriteriaNext_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        BusinessEntities.Attendance.StudentClassAssociation criteria = new BusinessEntities.Attendance.StudentClassAssociation();
        //        criteria.Campus = new BusinessEntities.Configuration.Campus();
        //        criteria.Campus.ID = Convert.ToInt32(ddlCampus.Text);
        //        criteria.StudentClass = new BusinessEntities.Configuration.Classes();
        //        criteria.StudentClass.ID = Convert.ToInt32(ddlClass.Text);
        //        //criteria.Section  = new BusinessEntities.Configuration.Section();
        //        //criteria.Section.ID = Convert.ToInt32(ddlSection.Text);
        //        //criteria.Teacher = new BusinessEntities.Teacher.Teacher();
        //        //criteria.Teacher.ID = Convert.ToInt32(ddlTeacher.Text);
        //        //criteria.RollTimeAttendanceStatus = new BusinessEntities.Attendance.RollTimeAttendaceStatus();
        //        //criteria.RollTimeAttendanceStatus.ID = Convert.ToInt32(ddlRollCallStatus.Text);
        //        criteria.StartDate = Convert.ToDateTime(txtPopupFromDate.Text.ToString());
        //        criteria.EndDate = Convert.ToDateTime(txtPopupToDate.Text.ToString());
        //        Session["StatsReportCriteria"] = criteria;

        //        string statsReportingPageURL = "~/StudentAttendance/StatsReport.aspx";
        //        Response.Redirect(statsReportingPageURL, false);

        //    }
        //    catch(Exception loEx)
        //    {
        //        Response.Write("<Label>" + loEx.Message + "</Label>");
        //    }
        //}
        protected void lnkSMS_Click(object sender, EventArgs e)
        {
            try
            {
                string smsURL = "~/Messaging/StudentSMS.aspx?QryStrCampusId=" + this.CurrentCampusId;
                // MessageResponseManager messageResponseManager = new MessageResponseManager();
                // List<MessageResponse> messagesResponse = messageResponseManager.GetAbsentStudents(this.CurrentClassId ,this.CurrentSectionId ,this.RollTimeStatusId);
                // this.rptStudentSMS.DataSource = messagesResponse;
                // this.rptStudentSMS.DataBind();
                string destinationMobileNumber = string.Empty;
                string smsMessage = string.Empty;
                string smsMessageId = string.Empty;
                MessageStatus messageStatus = null;
                int result = 0;
                MessageResponseManager messageResponseManager = new MessageResponseManager();
                List<MessageResponse> messagesResponse = messageResponseManager.GetAbsentStudents(this.CurrentClassId, this.CurrentSectionId,this.CurrentCampusId, this.RollTimeStatusId);
                if (messagesResponse != null && messagesResponse.Count >= 1)
                {
                    if (!messageResponseManager.IsSendSMS(this.RollTimeStatusId, MessageType.AbsetnSMS.GetHashCode(),this.CurrentCampusId))
                    {
                        foreach (MessageResponse messageResponse in messagesResponse)
                        {

                            smsMessageId = getSMSMessageId(messageResponse.Studnet.ID);
                            smsMessage = getSMSMessageToSend(messageResponse.Studnet.Name, messageResponse.Studnet.LastName);
                            try
                            {

                                if (SendSMS(messageResponse.DestinationMobileNumber, smsMessageId, smsMessage))
                                {

                                    messageResponse.TwoWayMessageId = smsMessageId;
                                    result = messageResponseManager.AddAbsentStudentSMS(messageResponse);

                                }
                            }
                            catch { }

                        }

                        if (result > 0)
                        {
                            messageStatus = new MessageStatus();
                            messageStatus.MessageType = MessageType.AbsetnSMS;
                            messageStatus.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                            messageStatus.RollTimeAttendaceStatus.ID = this.RollTimeStatusId;
                            messageStatus.CampusId = this.CurrentCampusId;

                            messageResponseManager.AddMessageStatus(messageStatus);
                        }
                    }
                }
                Response.Redirect(smsURL, true);
            }
            catch (Exception loEx)
            {
                //Response.Write("<Label>" + loEx.Message + "</Label>");

            }
        }
        protected void lnkInbox_Click(object sender, EventArgs e)
        {
            try
            {
                string smsURL = "~/Messaging/StudentSMS.aspx?QryStrCampusId=" + this.CurrentCampusId;
                // MessageResponseManager messageResponseManager = new MessageResponseManager();
                // List<MessageResponse> messagesResponse = messageResponseManager.GetAbsentStudents(this.CurrentClassId ,this.CurrentSectionId ,this.RollTimeStatusId);
                // this.rptStudentSMS.DataSource = messagesResponse;
                // this.rptStudentSMS.DataBind();
                string destinationMobileNumber = string.Empty;
                string smsMessage = string.Empty;
                string smsMessageId = string.Empty;
                MessageStatus messageStatus = null;
                int result = 0;
                #region sms functionality
                //MessageResponseManager messageResponseManager = new MessageResponseManager();
                //List<MessageResponse> messagesResponse = messageResponseManager.GetAbsentStudents(this.CurrentClassId, this.CurrentSectionId, this.CurrentCampusId, this.RollTimeStatusId);
                //if (messagesResponse != null && messagesResponse.Count >= 1)
                //{
                //    if (!messageResponseManager.IsSendSMS(this.RollTimeStatusId, MessageType.AbsetnSMS.GetHashCode(), this.CurrentCampusId))
                //    {
                //        foreach (MessageResponse messageResponse in messagesResponse)
                //        {

                //            smsMessageId = getSMSMessageId(messageResponse.Studnet.ID);
                //            smsMessage = getSMSMessageToSend(messageResponse.Studnet.Name, messageResponse.Studnet.LastName);
                //            try
                //            {

                //                if (SendSMS(messageResponse.DestinationMobileNumber, smsMessageId, smsMessage))
                //                {

                //                    messageResponse.TwoWayMessageId = smsMessageId;
                //                    result = messageResponseManager.AddAbsentStudentSMS(messageResponse);

                //                }
                //            }
                //            catch { }

                //        }

                //        if (result > 0)
                //        {
                //            messageStatus = new MessageStatus();
                //            messageStatus.MessageType = MessageType.AbsetnSMS;
                //            messageStatus.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                //            messageStatus.RollTimeAttendaceStatus.ID = this.RollTimeStatusId;
                //            messageStatus.CampusId = this.CurrentCampusId;

                //            messageResponseManager.AddMessageStatus(messageStatus);
                //        }
                //    }
                //}
                #endregion
                Response.Redirect(smsURL, true);
            }
            catch (Exception loEx)
            {
                //Response.Write("<Label>" + loEx.Message + "</Label>");

            }
        }
        private string getSMSMessageToSend(string firstName, string lastName)
        {
            StringBuilder smsMessage = new StringBuilder();
            #region Web config element getting sms message send to gaurdain
            MessageResponseManager messageResponseManager = new MessageResponseManager();
            int campusId = this.CurrentUser.CampusId;
            string collegeName = messageResponseManager.GetLoginUserCampus(campusId);
            string message = System.Web.Configuration.WebConfigurationManager.AppSettings["SMSMessage"];
            
            string otherMessage = System.Web.Configuration.WebConfigurationManager.AppSettings["OtherMessage"];
            #endregion

            smsMessage.Append(collegeName);
            smsMessage.Append(" ");
            smsMessage.Append(message);
            smsMessage.Append(" ");
            smsMessage.Append(firstName);
            smsMessage.Append(" ");
            smsMessage.Append(lastName);
            smsMessage.Append(" ");
            smsMessage.Append("is Absent");
            smsMessage.Append(" today " + DateTime.Now.ToString());
            smsMessage.Append(". ");

            if (!String.IsNullOrEmpty(otherMessage))
            {
                smsMessage.Append(otherMessage);
            }
            return smsMessage.ToString();

        }

        private string getSMSMessageId(int studentId)
        {
            DateTime currentDateTime = DateTime.Now;
            StringBuilder smsMessageId = new StringBuilder();

            smsMessageId.Append(studentId.ToString());
            smsMessageId.Append(this.RollTimeStatusId);
            smsMessageId.Append(currentDateTime.Day.ToString());
            smsMessageId.Append(currentDateTime.Month.ToString());
            smsMessageId.Append(currentDateTime.Year.ToString());

            return smsMessageId.ToString();

        }
        private bool SendSMS(string destinationMobileNumber, string smsMessageid, string smsMessage)
        {
            bool smsSendStatus = false;
            try
            {

                WebClient wc = new WebClient();

                wc.QueryString.Add("username", "alam");
                wc.QueryString.Add("password", "133f19cf");
                wc.QueryString.Add("to", destinationMobileNumber);
                wc.QueryString.Add("message", smsMessage);
                wc.QueryString.Add("type", "2-way");
                wc.QueryString.Add("messageid", smsMessageid);


                string referalUrl = "http://api.directsms.com.au/s3/http/send_message";
                Stream responseStream = wc.OpenRead(referalUrl);
                StreamReader sr = new StreamReader(responseStream);
                string responseString = sr.ReadToEnd();
                if (responseString.Contains("id"))
                {
                    smsSendStatus = true;
                }
                sr.Close();
                responseStream.Close();

            }
            catch (Exception ex) { }

            return smsSendStatus;


        }

  private void CheckSessionTimeout()
{
   string msgSession = @"Warning: Within next 3 minutes, if you do not do anything, 
               ' our system will redirect to the login page. Please save changed data.";
    //time to remind, 3 minutes before session ends
    int int_MilliSecondsTimeReminder = (this.Session.Timeout * 60000) - 3 * 60000; 
    //time to redirect, 5 milliseconds before session ends
    int int_MilliSecondsTimeOut = (this.Session.Timeout * 60000) - 5; 

    string str_Script = @"
            var myTimeReminder, myTimeOut; 
            clearTimeout(myTimeReminder); 
            clearTimeout(myTimeOut); " +
            "var sessionTimeReminder = " + 
		int_MilliSecondsTimeReminder.ToString() + "; " +
            "var sessionTimeout = " + int_MilliSecondsTimeOut.ToString() + ";" +
            "function doReminder(){ alert('" + msgSession + "'); }" +
            "function doRedirect(){ window.location.href=\"/KB/session/login.aspx\"; }" + @"
            myTimeReminder=setTimeout('doReminder()', sessionTimeReminder); 
            myTimeOut=setTimeout('doRedirect()', sessionTimeout); ";

     ScriptManager.RegisterClientScriptBlock(this.Page, this.GetType(), 
           "CheckSessionOut", str_Script, true);
}
        #region Create Student
         protected void lnkBtnAddStudent_Click(object sender, EventArgs e)
        {
            Response.Redirect("../Students/CreateStudent.aspx");
        }
        #endregion 

         #region Cusotm Methods
         private void FillDrowpDown()
         {
             String query = string.Empty;
             DataTable dt = null;
             //Fill Campuses
             query = "Select CampusId, CampusName from [Config_Campus] order by CampusName";
             dt = this.GetdataTable(query, "Campuses");
             this.BindDrowpDown(this.ddlCampus, dt, "CampusName", "CampusId");

             //Fill Classess
             query = "Select ClassId, Name from [Config_Class] order by ClassOrder";
             dt = this.GetdataTable(query, "Classes");
             this.BindDrowpDown(this.ddlClass, dt, "Name", "ClassId");
             //Fill Sections
             //query = "SELECT [SectionId],[Name],[SectionOrder] FROM [Config_Section] order by SectionOrder ;";
             //dt = this.GetdataTable(query, "Sections");
             //this.BindDrowpDown(this.ddlSection, dt, "Name", "SectionId");

             ////Fill Teachers
             //query = "Select TeacherId, FirstName from [TR_Teachers] order by FirstName";
             //dt = this.GetdataTable(query, "Teachers");
             //this.BindDrowpDown(this.ddlTeacher, dt, "FirstName", "TeacherId");

             ////Fill Roll Call Status
             //query = "Select RollTimeStatusId, Name from [ATT_RollTime_Status] order by Name";
             //dt = this.GetdataTable(query, "RollCallStatus");
             //this.BindDrowpDown(this.ddlRollCallStatus, dt, "Name", "RollTimeStatusId");

         }
         private void BindDrowpDown(DropDownList ddl, DataTable dt, string dataTextField, string dataValueField)
         {
             if (dt.Rows.Count > 0)
             {

                 ddl.DataSource = dt;
                 ddl.DataTextField = dataTextField;
                 ddl.DataValueField = dataValueField;
                 ddl.DataBind();
             }
             else
             {
                 ddl.DataSource = null;
             }
             if (dt.Rows.Count > 1)
             {
                 ListItem litem = new ListItem();
                 litem.Text = "--All--";
                 litem.Value = "-1";
                 ddl.Items.Insert(0, litem);
             }
         }
         private DataTable GetdataTable(string query, string tableName)
         {
             SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["SqlDB"].ConnectionString);
             //String query = "Select ClassId, Name from [Config_Class] order by ClassOrder";

             SqlDataAdapter dataAdapter = new SqlDataAdapter();
             try
             {
                 SqlCommand cmd = new SqlCommand(query, con);
                 if (con.State == System.Data.ConnectionState.Closed)
                 {
                     con.Open();
                 }
                 dataAdapter.SelectCommand = cmd;
                 DataSet ds = new DataSet();
                 dataAdapter.Fill(ds, tableName);

                 if (ds.Tables[0].Rows.Count > 0)
                 {
                     return ds.Tables[0];
                 }
                 else
                 {
                     return null;
                 }
             }
             catch
             {
             }
             finally
             {
                 if (con.State == System.Data.ConnectionState.Open)
                 {
                     con.Close();
                 }
             }

             return null;

         }     
         #endregion

    }
}