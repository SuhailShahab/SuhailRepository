﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BuisnessEntity.FillEvent;
using AMS.Web.Common;
using AMS.BusinessEntities.Attendance;
using FrameWork.Common;
using AMS.Business.Attendance;
using AMS.BusinessEntities.UserManagement;
using AMS.BusinessEntities.CustomEnum;

namespace AMS.Web.StudentAttendance
{
    public partial class Evacuation : System.Web.UI.Page
    {
       /* public User CurrentUser
        {
            get { return currentUser = (User)Session["CurrentUser"]; }

        }*/
        public enum PageActions : byte
        {
            None,
            InitializedPage,
            RefreshData
            
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    string fileName = System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath);
                    if (!Request.Browser.IsMobileDevice && AMS.Web.Common.CurrentUser.IsAthurisedByName(fileName, DeviceNames.iPhone.GetHashCode()))
                    {
                        
                        InitializedData(PageActions.InitializedPage, new FillSearch());
                    }
                    else
                    {
                        this.ShowMsg("You are not authorised for this form.");
                        Response.Redirect(PageUrl.loginPageUrl,false);
                    }
                }
            }
            catch (Exception loEx)
            {
                this.ShowMsg(loEx.Message);
            }
        }
        #region Custom Properties
        private int rollTimeStatusId;
        public int RollTimeStatusId
        {
            get
            {
                if (ViewState["RollTimeStatusId"] == null)
                {
                    return 0;
                }
                else
                {
                    return rollTimeStatusId = Convert.ToInt32(ViewState["RollTimeStatusId"]);
                }
            }
            set
            {
                ViewState["RollTimeStatusId"] = value;
            }
        }
        #endregion 
        #region Common Methods
        private void InitializedData(PageActions pageActions, FillSearch fillSearch)
        {
            if (pageActions == PageActions.InitializedPage)
            {
                fillSearch.TeacherId = CurrentUser.User.LoginUserId;
                fillSearch.CurrentDate = DateTime.Now;
                fillSearch.IsFillEvacuationData = true;
                FillResponse fillResponse = FillSearchManager.FillData(fillSearch);
                if (fillResponse.LstEvacuation != null && fillResponse.LstEvacuation.Count > 0)
                {
                    rptEvacuation.DataSource = fillResponse.LstEvacuation;
                    rptEvacuation.DataBind();
                }
                else
                {
                    rptEvacuation.DataSource = null;
                    rptEvacuation.DataBind();
                }
                if (fillResponse.RollTimeStatus != null)
                {
                    this.RollTimeStatusId = fillResponse.RollTimeStatus.ID;
                }
                else
                {
                    this.RollTimeStatusId = 0;
                }
            }
           
           
        }
        #endregion 
        #region Custom Methods
        //private int rollTimeStatusId(List<RollTimeAttendaceStatus> lstrollTimeStatus)
        //{
        //    if (lstrollTimeStatus != null && lstrollTimeStatus.Count > 0)
        //    {
        //        if(lstrollTimeStatus.Exists(r=>r.StartingHour<= DateTime.Now.Hour  && DateTime.Now.Hour  <= r.EndingHour  ))
        //        {
        //            RollTimeAttendaceStatus rollTimeStatus = lstrollTimeStatus.FindLast(r => r.StartingHour <= DateTime.Now.Hour && DateTime.Now.Hour <= r.EndingHour);
        //            return rollTimeStatus.ID; 
        //        }              
               
        //    }
        //    return 0;
        //}
        private List<AMS.BusinessEntities.Attendance.Evacuation> GetEvacuationData()
        {
            HiddenField hfControl = null;
            List<AMS.BusinessEntities.Attendance.Evacuation> lstEvacuation = new List<AMS.BusinessEntities.Attendance.Evacuation>();
            for (int i = 0; i < this.rptEvacuation.Items.Count; i++)
            {
                AMS.BusinessEntities.Attendance.Evacuation evacuation = new AMS.BusinessEntities.Attendance.Evacuation();
                hfControl = (HiddenField)this.rptEvacuation.Items[i].FindControl("hdfEvacuationId");
                if (hfControl != null)
                {
                    evacuation.ID =string.IsNullOrEmpty(Convert.ToString(hfControl.Value))?0: Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptEvacuation.Items[i].FindControl("hdfEvaStatusId");
                if (hfControl != null)
                {
                    evacuation.EvationStatus  = new BusinessEntities.Attendance.AttendanceStatus();
                    evacuation.EvationStatus.ID  = Convert.ToInt32(hfControl.Value);
                }
               
                hfControl = (HiddenField)this.rptEvacuation.Items[i].FindControl("hdfVersionNo");
                if (hfControl != null)
                {
                    evacuation.VersionNo = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptEvacuation.Items[i].FindControl("hdfStudentId");
                if (hfControl != null)
                {
                    evacuation.Student = new BusinessEntities.Student.Student();
                    evacuation.Student.ID  = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptEvacuation.Items[i].FindControl("hdfClassId");
                if (hfControl != null)
                {
                    evacuation.StudentClass = new BusinessEntities.Configuration.Classes();
                    evacuation.StudentClass.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptEvacuation.Items[i].FindControl("hdfSectionId");
                if (hfControl != null)
                {
                    evacuation.ClassSection= new BusinessEntities.Configuration.Section();
                    evacuation.ClassSection.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptEvacuation.Items[i].FindControl("TermId");
                if (hfControl != null)
                {
                    evacuation.Term = new BusinessEntities.Configuration.Term();
                    evacuation.Term.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptEvacuation.Items[i].FindControl("hdfEvaDate");
                if (hfControl != null)
                {
                    if (!string.IsNullOrEmpty(hfControl.Value) && Convert.ToDateTime(hfControl.Value).Year != 1)
                    {
                        evacuation.AttendanceDate = Convert.ToDateTime(hfControl.Value);
                    }
                    else if (Convert.ToDateTime(hfControl.Value).Year == 1)
                    {

                        evacuation.AttendanceDate = DateTime.Now;
                    }
                }
                
                evacuation.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                evacuation.RollTimeAttendaceStatus.ID = this.RollTimeStatusId;
                lstEvacuation.Add(evacuation);
            }
            return lstEvacuation;
        }
        #endregion 
        #region Button Events
        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
               EvacuationManager evacuationManager = new EvacuationManager();
                evacuationManager.Save(this.GetEvacuationData(), AMS.Web.Common.CurrentUser.User.ID);
                InitializedData(PageActions.InitializedPage, new FillSearch());
                this.ShowMsg("Record saved successfully.");
                
            }
            catch (Exception loEx)
            {
                this.ShowMsg(loEx.Message);
            }
        }
        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            try
            {
                this.Session.Abandon();
                Response.Redirect(PageUrl.loginPageUrl);
            
            
            }
            catch (Exception loEx)
            {
                this.ShowMsg(loEx.Message);
            }
        }
        #endregion 
        #region Common Methods
        public void ShowMsg(string msg)
        {
            ScriptManager.RegisterStartupScript(this, typeof(Button), "Message", "alert('" + msg + "');", true);

        }
        #endregion 
    }
}