﻿//In the name of Allah who is most beneficient and mercifull.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMS.BusinessEntities.Student;
using FrameWork.Common;
using BuisnessEntity.FillEvent;
using AMS.BusinessEntities.UserManagement;
using System.Web.Services;
using AMS.Business.Attendance;
using AMS.BusinessEntities.CustomEnum;
using ANTOMS.VisoHelperClass;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using AMS.BusinessEntities.Attendance;
using AMS.Web.Common;
using System.Web.UI.HtmlControls;

namespace AMS.Web.StudentAttendance
{
    public partial class StudentAttendance : System.Web.UI.Page
    {
        public enum PageActions:byte 
        {
            None,
            InitializedPage,
            FillStudent
        }
       // static  PageMode pageMode;
        private PageMode pageModes;
        private int daysCounter=0;
        private bool isLastRow=true;
        private int currentClassId;
        private int currentSectionId;
        private int rollTimeStatusId;
        private bool handalCalender = false;
        private List<RollTimeAttendaceStatus> rollTimeStatues;
       // private bool handalCalender;
        private int currentCampusId;
        public int CurrentCampusId
        {
            get
            {
                if (ViewState["CurrentCampusId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentCampusId = Convert.ToInt32(ViewState["CurrentCampusId"]);
                }
            }
            set
            {
                ViewState["CurrentCampusId"] = value;

            }
        }
        public List<RollTimeAttendaceStatus> RollTimeStatues
        {
            get
            {
                if (ViewState["RollTimeAttendaceStatus"] == null)
                {
                    return null ;
                }
                else
                {
                    return rollTimeStatues = (List<RollTimeAttendaceStatus>)ViewState["RollTimeAttendaceStatus"];
                }
            }
            set
            {
                ViewState["RollTimeAttendaceStatus"] = value;
            }
        }

        public int RollTimeStatusId
        {
            get
            {
                if (ViewState["RollTimeStatusId"] == null)
                {
                    return 0;
                }
                else
                {
                    return rollTimeStatusId = Convert.ToInt32(ViewState["RollTimeStatusId"]);
                }
            }
            set
            {
                ViewState["RollTimeStatusId"] = value;
            }
        }

        public int CurrentSectionId
        {
            get
            {
                if (ViewState["CurrentSectionId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentSectionId = Convert.ToInt32(ViewState["CurrentSectionId"]);
                }
            }
            set
            {
                ViewState["CurrentSectionId"] = value;
            }
        }
        public int CurrentClassId
        {
            get
            {
                if (ViewState["CurrentClassId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentClassId = Convert.ToInt32(ViewState["CurrentClassId"]);
                }
            }
            set
            {
                ViewState["CurrentClassId"] = value;
            }
        }
       

        public PageMode PageModes
        {
            get
            {
                
                return pageModes = (PageMode)ViewState["PageModes"]; 
            }
            set
            {
                ViewState["PageModes"] = value;
                this.hfPageMode.Value = Convert.ToString(ViewState["PageModes"]);
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
           // Response.AppendHeader("Refresh", Convert.ToString(Session.Timeout * 60) + ";url=../Security/Default.aspx");
            if (!IsPostBack)
            {
               
                this.history_arrow.Visible = false;
                this.history.Visible = false;
               // string pageName=  this.Page.ToString().Split('_');
                string fileName = System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath);
                if (!Request.Browser.IsMobileDevice && AMS.Web.Common.CurrentUser.IsAthurisedByName(fileName, DeviceNames.DeskTop.GetHashCode()))
                {
                    PageModes = PageMode.None;
                   
                    InitializedData(PageActions.InitializedPage, new FillSearch());
                    lblCurrentDateTime.Text = DateTime.Now.ToString("dd-MMM-yyyy ");
                    this.SetContorlEnablity(PageModes);
                   // this.cldrAttendance.SelectedDate = DateTime.Now;
                   // this.lblCalenderDate.Text = this.cldrAttendance.SelectedDate.ToString("dd-MMM-yyyy");
                }
                else
                {
                    Response.Redirect(PageUrl.loginPageUrl);
                }
                
            }
        }
        private User currentUser;

        public User CurrentUser
        {
            get { return currentUser = (User)Session["CurrentUser"]; }
            
        }
        #region Custom Methods
        private RollTimeAttendaceStatus GetRollTimeStatus()
        {
            RollTimeAttendaceStatus rollTimeAttendaceStatus =null;
            if (this.RollTimeStatues != null)
            {
                if (this.RollTimeStatues.Exists(rt => rt.StartingHour <= DateTime.Now.Hour && DateTime.Now.Hour <= rt.EndingHour))
                {
                    rollTimeAttendaceStatus = this.RollTimeStatues.Find(rt => rt.StartingHour <= DateTime.Now.Hour && DateTime.Now.Hour <= rt.EndingHour);
                }
                else
                {
                    rollTimeAttendaceStatus = this.RollTimeStatues.Find(rt => rt.ID == RollTimeStatusName.EveningRollTimeId);
                }
            }
            return rollTimeAttendaceStatus;
        }
        private void SetContorlEnablity(PageMode pageMode)
        {
            if (pageMode == PageMode.None)
            {
                this.lnkbtnCancel.Text = "Date";
                this.lnkbtnSave.Text = "Edit";
                this.PageModes  = PageMode.Edit;
                
            }
            else if (pageMode == PageMode.Edit)
            {
                this.lnkbtnCancel.Text = "Cancel";
                this.lnkbtnSave.Text = "Save";
                this.PageModes = PageMode.Save;
               
            }
            else if (pageMode == PageMode.Save)
            {
                this.lnkbtnCancel.Text = "Date";
                this.lnkbtnSave.Text = "Edit";
                this.PageModes = PageMode.Edit;
            }

          //  this.history_arrow.Visible = false;
           // this.history.Visible = false;
        }
        private void SetContorlEnablity(int rollTimeId)
        {
            lnkbtnSave.Enabled = !(DateTime.Now.Date != Convert.ToDateTime(lblCurrentDateTime.Text)  ||  rollTimeId != this.RollTimeStatusId);
       
        }
        private void InitializedData(PageActions pageActions, FillSearch fillSearch)
        {


            if (pageActions == PageActions.InitializedPage)
            {
                fillSearch.IsGetTeacherClasses = true;
                fillSearch.IsIncharge = true;
                fillSearch.TeacherId = this.CurrentUser.LoginUserId;
                fillSearch.CampusId = this.CurrentUser.CampusId;
                FillResponse fillResponse = FillSearchManager.FillData(fillSearch);
                if (fillResponse.ClassesTeacher != null && fillResponse.ClassesTeacher.Count > 0)
                {
                    this.CurrentClassId = fillResponse.ClassesTeacher[0].Classes.ID;
                    this.CurrentSectionId = fillResponse.ClassesTeacher[0].Section.ID;
                    this.CurrentCampusId = fillResponse.ClassesTeacher[0].Campus.ID;
                    this.rptTeacherClass.DataSource = fillResponse.ClassesTeacher;
                    this.rptTeacherClass.DataBind();
                    //HtmlContainerControl liClassSection = (HtmlContainerControl)rptTeacherClass.Items[0].FindControl("liClassSection");
                    //if (liClassSection != null)
                    //{
                    //    liClassSection.Attributes.Add("class", "grade");
                    //}
                }
                if (fillResponse.RollTimeStatuses != null)
                {
                    this.RollTimeStatues = fillResponse.RollTimeStatuses;
                }

                if (fillResponse.StudentsAttendace != null && fillResponse.StudentsAttendace.Count > 0)
                {
                    this.RollTimeStatusId = fillResponse.StudentsAttendace[0].RollTimeAttendaceStatus.ID;
                    rptRollList.DataSource = fillResponse.StudentsAttendace;
                    rptRollList.DataBind();
                }
                if (fillResponse.RollTimeStatus != null)
                {
                    this.lblRollCallName.Text  = fillResponse.RollTimeStatus.Name;
                    this.RollTimeStatusId = fillResponse.RollTimeStatus.ID;

                }
            }
            else if (pageActions == PageActions.FillStudent)
            {
                fillSearch.RollTimeStatusId = this.RollTimeStatusId;
                fillSearch.IsFillStudentAttendanceByid = true;
                FillResponse fillResponse = FillSearchManager.FillData(fillSearch);
                //if (fillResponse.StudentsAttendace != null)
                //{
                    rptRollList.DataSource = fillResponse.StudentsAttendace;
                    rptRollList.DataBind();
                //}
            }
        }
        #region Web Methods
        private List<BusinessEntities.Attendance.StudentAttendace> GetStudentAttendance()
        {
            HiddenField hfControl = null;
            List<BusinessEntities.Attendance.StudentAttendace> studentsAttendance = new List<BusinessEntities.Attendance.StudentAttendace>();
            for (int i = 0; i< this.rptRollList.Items.Count; i++)
            {
                BusinessEntities.Attendance.StudentAttendace studentAttendace =new BusinessEntities.Attendance.StudentAttendace();
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentAttendanceId");
                if (hfControl != null)
                {
                    studentAttendace.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceStatusId");
                if (hfControl != null)
                {
                    studentAttendace.AttendanceStatus = new BusinessEntities.Attendance.AttendanceStatus();
                    studentAttendace.AttendanceStatus.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentId");
                if (hfControl != null)
                {
                    studentAttendace.Student  = new Student ();
                    studentAttendace.Student.ID  = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfNote");
                if (hfControl != null)
                {                   
                    studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceDate");
                if (hfControl != null)
                {
                    if (!string.IsNullOrEmpty(hfControl.Value) && Convert.ToDateTime(hfControl.Value).Year != 1 && studentAttendace.AttendanceStatus.ID != AttendaceStatus.UnMarked.GetHashCode())
                    {
                        studentAttendace.AttendanceDate  = Convert.ToDateTime(hfControl.Value);
                    }
                    else if (Convert.ToDateTime(hfControl.Value).Year == 1)
                    {//code for preventing duplication by zahmad
                        studentAttendace.AttendanceDate = DateTime.Now;//Convert.ToDateTime(DateTime.Now);
                    }
                    else if (studentAttendace.AttendanceStatus.ID == AttendaceStatus.UnMarked.GetHashCode())
                    {
                        studentAttendace.AttendanceDate = DateTime.Now;
                    }
                    
                    
                }
                
                studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                studentAttendace.RollTimeAttendaceStatus.ID = this.RollTimeStatusId;
                studentAttendace.Student.StudnetClass = new BusinessEntities.Configuration.Classes();
                studentAttendace.Student.StudnetClass.ID = this.CurrentClassId;
                studentAttendace.Student.Section = new BusinessEntities.Configuration.Section();
                studentAttendace.Student.Section.ID = this.CurrentSectionId;
                studentAttendace.Student.Campus = new BusinessEntities.Configuration.Campus();
                studentAttendace.Student.Campus.ID = this.CurrentCampusId;

                studentsAttendance.Add(studentAttendace);
            }
            return studentsAttendance;

            
        }
        [WebMethod]
        public static string LoadStudentPicture(int studentId)
        {

            HttpContext.Current.Session["StudentId"] = studentId;
            string fullPhoto = "../Images/SuhailShahab.jpg";
            //../Images/full_avatar.jpg;
            return fullPhoto;
        
        
        }
        [WebMethod]
        public static string GetTime()
        {
            return DateTime.Now.ToString();
            //HttpContext.Current.Session["StudentId"] = studentId;
            //string fullPhoto = "../Images/SuhailShahab.jpg";
            //../Images/full_avatar.jpg;
            //return fullPhoto;


        }
        #endregion
        protected void lnkbtnSave_OnClick(object sender, EventArgs e)
        {
            try
            {
               
                if (this.PageModes == PageMode.Edit)
                {                   
                    this.SetContorlEnablity( this.PageModes);
                }
                else if (this.PageModes == PageMode.Save)
                {
                    StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
                    //AddWithOutReason must have parameter "this.CurrentUser.LoginUserId" for teacher login.
                    List< AMS.BusinessEntities.Attendance.StudentAttendace> studentsAttendace = studentAttendanceManager.AddWithOutReason(this.GetStudentAttendance(), this.CurrentUser.LoginUserId,this.CurrentUser.Role.ID);
                  
                    this.SetContorlEnablity(PageMode.None);
                    FillSearch fillSearch = new FillSearch();
                    fillSearch.ClassId = this.CurrentClassId;
                    fillSearch.SectionId = this.CurrentSectionId;
                    fillSearch.CampusId = this.CurrentCampusId;
                    fillSearch.RollTimeStatusId = this.RollTimeStatusId;
                    fillSearch.IsFillStudentAttendanceByid = true;
                    this.InitializedData(PageActions.InitializedPage, new FillSearch());
                   // this.rptRollList.DataSource = studentsAttendace;
                   // this.DataBind();
                }
                SetVisibilityOfDate(false);
            }
            catch(Exception ex)
            {
            }
        }
      


        #endregion 

        protected void rptTeacherClass_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
           
            try
            {
                //if (this.PageModes != PageMode.Save)
                //{
                //    return;
                //}
                HiddenField hf = null;
                FillSearch fillSearch = new FillSearch();
                hf = (HiddenField)e.Item.FindControl("hfClassId");
                if (hf != null)
                {
                    fillSearch.ClassId = Convert.ToInt32(hf.Value);
                    this.CurrentClassId = fillSearch.ClassId;
                }
                hf = (HiddenField)e.Item.FindControl("hfSectionId");
                if (hf != null)
                {
                    fillSearch.SectionId = Convert.ToInt32(hf.Value);
                    this.CurrentSectionId = fillSearch.SectionId;
                }
                hf = (HiddenField)e.Item.FindControl("hfCampusId");
                if (hf != null)
                {
                    fillSearch.CampusId = Convert.ToInt32(hf.Value);
                    this.CurrentCampusId = fillSearch.CampusId;
                }

               
                this.InitializedData(PageActions.FillStudent, fillSearch);
                //HtmlContainerControl liClassSection = (HtmlContainerControl) e.Item.FindControl("liClassSection");
                
                //if (liClassSection != null)
                //{
                //    liClassSection.Attributes.Add("class", "grade");
                //}
            }
            catch
            {
            }
        }
        #region Button Events
        protected void lnkbtnLogOut_Click(object sender, EventArgs e)
        {
            this.Session.Abandon();
            Response.Redirect(PageUrl.loginPageUrl);
        }
        protected void lblLateAbsentReport_Click(object sender, EventArgs e)
        {
            try
            {
                ReportParameters.ReportType = ReportType.StudentTotalLateAbsetnCount;
                Response.Redirect("~/Reports/Templates/AttendanceReportView.aspx?QryStrClassId=" + this.CurrentClassId + "&QryStrSectionId=" + this.CurrentSectionId + "&QryStrCampusId=" + this.CurrentCampusId + "&qryRollTimeStatusId=" + this.RollTimeStatusId, false);

            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }
        
        protected void lnkbtnCancel_OnClick(object sender, EventArgs e)
        {
            this.handalCalender = (this.history_arrow.Visible ? false : true);
            this.SetVisibilityOfDate(this.handalCalender);
            this.SetContorlEnablity(PageMode.None);
            
        }
        protected void lnkbtnAM_OnClick(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(lblCalenderDate.Text))
                {
                    this.BindGridByDate(RollTimeStatusName.MoringRollTimeId , Convert.ToDateTime(lblCalenderDate.Text));
                    lblCurrentDateTime.Text = lblCalenderDate.Text;
                    lblRollCallName.Text =RollTimeStatusName.MoringRollTime;
                    this.SetContorlEnablity(RollTimeStatusName.MoringRollTimeId); 
                }
                else

                {
                    MessageAlert.Show("Please select date.");
                }
            }
            catch
            {
            }
        }
        protected void lnkbtnPM_OnClick(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(lblCalenderDate.Text))
            {
                this.BindGridByDate(RollTimeStatusName.EveningRollTimeId, Convert.ToDateTime(lblCalenderDate.Text));
                lblCurrentDateTime.Text = lblCalenderDate.Text;
                lblRollCallName.Text =RollTimeStatusName.EveningRollTime;
                this.SetContorlEnablity(RollTimeStatusName.EveningRollTimeId); 
            }
            else
            {
                MessageAlert.Show("Please select date.");
            }
        }
        protected void lnkbtnCloseCalendar_OnClick(object sender, EventArgs e)
        {
            this.SetVisibilityOfDate(false);
        }
        private void BindGridByDate(int roltimeStatusId,DateTime searchDate)
        {
            StudentAttendanceManager studentAttendanceManager = new StudentAttendanceManager();
            List<AMS.BusinessEntities.Attendance.StudentAttendace> studentsAttendace = null;           
            studentsAttendace = studentAttendanceManager.SearchByDate(this.CurrentClassId, this.CurrentSectionId, this.CurrentCampusId, roltimeStatusId, this.CurrentUser.ID, searchDate);
            if (studentsAttendace != null && studentsAttendace.Count > 0)
            {
                this.rptRollList.DataSource = studentsAttendace;
                this.rptRollList.DataBind();
                this.SetVisibilityOfDate(false);
            }
            else
            {

               // MessageAlert.Show("Record not found.");
                ShowMsg("Record not found.");
            }
        }
        public void ShowMsg(string msg)
        {
            ScriptManager.RegisterStartupScript(this, typeof(Button), "Message", "alert('" + msg + "');", true);

        }
        #endregion 
        private void SetVisibilityOfDate(bool handalCalender)
        {
            
            this.history_arrow.Visible = (lnkbtnCancel.Text.Equals("Date") && handalCalender) ;
            this.history.Visible = (lnkbtnCancel.Text.Equals("Date") && handalCalender);
            if ((lnkbtnCancel.Text.Equals("Date") && handalCalender))
            {
                // this.cldrAttendance.SelectedDate = DateTime.Now;
                 
                 // this.cldrAttendance.VisibleDate = DateTime.Now;*/
               
                DateTime dateToSet = DateTime.Parse(DateTime.Now.ToShortDateString());
                this.cldrAttendance.SelectedDate = dateToSet;
                this.cldrAttendance.VisibleDate = dateToSet;
                this.lblCalenderDate.Text = this.cldrAttendance.SelectedDate.ToString("dd-MMM-yyyy");
            }
        }
        //private void SetVisibilityOfDate(bool isVisible)
        //{
        //    this.history_arrow.Visible = isVisible;
        //    this.history.Visible = isVisible;
        //}
        protected void cldrAttendance_SelectionChanged(object sender, EventArgs e)
        {
            lblCalenderDate.Text = this.cldrAttendance.SelectedDate.ToString("dd-MMM-yyyy");
        }

        protected void cldrAttendance_DayRender(object sender, DayRenderEventArgs e)
        {
            //daysCounter++;

            //if (e.Day.Date.Day == 1 && !e.Day.IsOtherMonth) // 1st of current month. Turn visibility of row to ON.
            //{
            //    isLastRow = false;
            //}
            //else if (daysCounter == 36 && e.Day.IsOtherMonth) // 5 rows already rendered. If its the next row is next month, hide it.
            //{
            //    isLastRow = true;
            //}
            //else if (daysCounter == 1 && e.Day.IsOtherMonth && e.Day.Date.Month == e.Day.Date.AddDays(6).Month)
            //{   // If first row completely is previous month, hide it. 
            //    // Actually the flag should be isFirstRow, but I dont want one more boolean just for the sake of it.
            //    isLastRow = true;
            //}

            //if (isLastRow)
            //    e.Cell.Visible = false;

        }
    }
}