﻿//In the name of Allah who is most beneficient and mercifull.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMS.BusinessEntities.UserManagement;
using FrameWork.Common;
using BuisnessEntity.FillEvent;
using System.DirectoryServices;

namespace AMS.Web.Security
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //For testing
                Session["CurrentUser"] = null;
            }
            else
            { 
           
            
            }
           lblMessage.Text    = string.Empty;
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                bool iphoneDebug = false;
                string ua = string.Empty;
                bool loginUserDebug = false;
                
                #region Web config element checking
               // System.Configuration.AppSettingsSection customSetting = System.Web.Configuration.WebConfigurationManager.AppSettings["iPhone"];
                string iphoneValue = System.Web.Configuration.WebConfigurationManager.AppSettings["iPhone"];
                string allowLoginUser = System.Web.Configuration.WebConfigurationManager.AppSettings["AllowUserLogin"];

                if (iphoneValue != null)
                         iphoneDebug =  bool.Parse(iphoneValue.ToString());
                if (allowLoginUser != null)
                    loginUserDebug = bool.Parse(allowLoginUser.ToString());
  
               // }
                #endregion
                // this.ShowMsg("Login");
                FillSearchManager fillSearchManager = new FillSearchManager();
                Session["CurrentUser"] = null;
               //code for LDAP
               bool authenticUser = AuthenticateAD(this.txtUserName.Text,this.txtPassword.Text);
               if (authenticUser || loginUserDebug)
               {
                   //    Page.Response.Redirect("../StudentAttendance/StudentAttendance.aspx", false);

                   //}

                   //Response.Redirect("~/StudentAttendance/LatePass.aspx", false);
                   //End of LDAP

                   User user = fillSearchManager.GetUser(this.txtUserName.Text, this.txtPassword.Text);
                   //if (iphoneDebug)
                   //Response.Write(HttpContext.Current.Request.UserAgent.ToLower().ToString());
                   if (chkEvacuation.Checked && user != null && user.Role != null && user.Role.UserPermissions != null)
                   {
                       ua = HttpContext.Current.Request.UserAgent.ToLower();
                       if (iphoneDebug || (ua != null && (ua.Contains("iphone") || ua.Contains("ipad") || ua.Contains("ipod"))))
                       {
                           Session["CurrentUser"] = user;
                           Response.Redirect("~/StudentAttendance/Evacuation.aspx", false);
                       }
                       else
                       {
                           lblMessage.Text = "Evacuation operation is not supported in Desktop.";
                       }
                   }
                   else if (user != null && user.Role != null && user.Role.UserPermissions != null && user.Role.UserPermissions.Exists(p => p.ObjectName.Name.Equals("StudentAttendance")))
                   {
                       Session["CurrentUser"] = user;

                       ua = HttpContext.Current.Request.UserAgent.ToLower();

                       if (iphoneDebug || (ua != null && (ua.Contains("iphone") || ua.Contains("ipad") || ua.Contains("ipod"))))
                       {
                           Response.Redirect("~/iPhoneApp/StudentAttendance.aspx", false);
                       }
                       else
                       {

                           Page.Response.Redirect("../StudentAttendance/StudentAttendance.aspx", false);
                       }
                   }
                   else if (user != null && user.Role != null && user.Role.UserPermissions != null && user.Role.UserPermissions.Exists(p => p.ObjectName.Name.Equals("LatePass")))
                   {
                       Session["CurrentUser"] = user;
                       Response.Redirect("~/StudentAttendance/LatePass.aspx", false);
                   }

               }

            }
            catch(Exception ex)
            {
                this.ShowMsg(ex.Message);
                Response.Write("<Label>" + ex.Message + "</Label>");
            }
        }

        #region Form Buttom Events
       
        #endregion 

       
        #region Custom Methods
        private bool AuthenticateAD(string userName, string password)//, string domain, out string message)
        {
           string  message = "";
           string domainName = "";

           #region Web config element checking
           // System.Configuration.AppSettingsSection customSetting = System.Web.Configuration.WebConfigurationManager.AppSettings["iPhone"];
          domainName = System.Web.Configuration.WebConfigurationManager.AppSettings["DomainName"];

         // }
           #endregion
          // string domain = "ilim-server.ilimcollege.vic.edu.au";
           DirectoryEntry entry = new
                DirectoryEntry("LDAP://" + domainName, userName, password);
           
            try
            {
                object obj = entry.NativeObject;
                DirectorySearcher search = new DirectorySearcher(entry);
                search.Filter = "(SAMAccountName=" + userName + ")";
                search.PropertiesToLoad.Add("cn");
                SearchResult result = search.FindOne();
                
                if (null == result)
                {                    
                    return false;
                    
                }


            }
            catch (Exception ex)
            {
                message = ex.Message;
                Response.Write(message);
                return false;
                // throw ex;
                //throw new Exception("Error authenticating user. " + ex.Message);
            }


            return true;
        
        }

        #endregion 
        public void ShowMsg(string msg)
        {
            ScriptManager.RegisterStartupScript(this, typeof(Button), "Message", "alert('" + msg + "');", true);

        }
    }
}