﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMS.BusinessEntities.Student;
using FrameWork.Common;
using BuisnessEntity.FillEvent;
using AMS.BusinessEntities.UserManagement;
using System.Web.Services;
using AMS.Business.Attendance;
using AMS.BusinessEntities.CustomEnum;
using ANTOMS.VisoHelperClass;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using AMS.BusinessEntities.Attendance;
using AMS.Web.Common;
using System.Web.UI.HtmlControls;
using AMS.Business.Students;
namespace AMS.Web.Students
{
    public partial class CreateStudent : System.Web.UI.Page
    {
        public enum PageActions : byte
        {
            None,
            InitializedPage,
            FillStudent
        }
        private PageMode pageModes;
        private bool isLastRow = true;
        private int currentClassId;
        private int currentSectionId;
        private int currentCampusId;
        public int CurrentCampusId
        {
            get
            {
                if (ViewState["CurrentCampusId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentCampusId = Convert.ToInt32(ViewState["CurrentCampusId"]);
                }
            }
            set
            {
                ViewState["CurrentCampusId"] = value;

            }
        }
        public int CurrentSectionId
        {
            get
            {
                if (ViewState["CurrentSectionId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentSectionId = Convert.ToInt32(ViewState["CurrentSectionId"]);
                }
            }
            set
            {
                ViewState["CurrentSectionId"] = value;
            }
        }
        public int CurrentClassId
        {
            get
            {
                if (ViewState["CurrentClassId"] == null)
                {
                    return 0;
                }
                else
                {
                    return currentClassId = Convert.ToInt32(ViewState["CurrentClassId"]);
                }
            }
            set
            {
                ViewState["CurrentClassId"] = value;
            }
        }


        public PageMode PageModes
        {
            get
            {

                return pageModes = (PageMode)ViewState["PageModes"];
            }
            set
            {
                ViewState["PageModes"] = value;
                this.hfPageMode.Value = Convert.ToString(ViewState["PageModes"]);
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                string fileName = System.IO.Path.GetFileNameWithoutExtension(Request.PhysicalPath);
                if (!Request.Browser.IsMobileDevice && AMS.Web.Common.CurrentUser.IsAthurisedByName(fileName, DeviceNames.DeskTop.GetHashCode()))
                {
                    PageModes = PageMode.None;
                    this.btnTerminate.OnClientClick = String.Format("return confirm('Do you want to Terminate student?')");
                    InitializedData(PageActions.InitializedPage, new FillSearch());
                }
                else
                {
                    Response.Redirect(PageUrl.loginPageUrl);
                }

            }
        }

        protected void rptTeacherClass_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            try
            {
                HiddenField hf = null;
                FillSearch fillSearch = new FillSearch();
                hf = (HiddenField)e.Item.FindControl("hfClassId");
                if (hf != null)
                {
                    fillSearch.ClassId = Convert.ToInt32(hf.Value);
                    this.CurrentClassId = fillSearch.ClassId;
                }
                hf = (HiddenField)e.Item.FindControl("hfSectionId");
                if (hf != null)
                {
                    fillSearch.SectionId = Convert.ToInt32(hf.Value);
                    this.CurrentSectionId = fillSearch.SectionId;
                }
                hf = (HiddenField)e.Item.FindControl("hfCampusId");
                if (hf != null)
                {
                    fillSearch.CampusId = Convert.ToInt32(hf.Value);
                    this.CurrentCampusId = fillSearch.CampusId;
                }

                this.InitializedData(PageActions.FillStudent, fillSearch);
                ClearInputs(this.Page.Controls);
            }
            catch
            {
            }
        }
        private User currentUser;

        public User CurrentUser
        {
            get { return currentUser = (User)Session["CurrentUser"]; }

        }
        #region Custom Methods
       /* private RollTimeAttendaceStatus GetRollTimeStatus()
        {
            RollTimeAttendaceStatus rollTimeAttendaceStatus = null;
            if (this.RollTimeStatues != null)
            {
                if (this.RollTimeStatues.Exists(rt => rt.StartingHour <= DateTime.Now.Hour && DateTime.Now.Hour <= rt.EndingHour))
                {
                    rollTimeAttendaceStatus = this.RollTimeStatues.Find(rt => rt.StartingHour <= DateTime.Now.Hour && DateTime.Now.Hour <= rt.EndingHour);
                }
                else
                {
                    rollTimeAttendaceStatus = this.RollTimeStatues.Find(rt => rt.ID == RollTimeStatusName.EveningRollTimeId);
                }
            }
            return rollTimeAttendaceStatus;
        }*/
        /*
        private void SetContorlEnablity(PageMode pageMode)
        {
            if (pageMode == PageMode.None)
            {
                this.lnkbtnCancel.Text = "Date";
                this.lnkbtnSave.Text = "Edit";
                this.PageModes = PageMode.Edit;

            }
            else if (pageMode == PageMode.Edit)
            {
                this.lnkbtnCancel.Text = "Cancel";
                this.lnkbtnSave.Text = "Save";
                this.PageModes = PageMode.Save;

            }
            else if (pageMode == PageMode.Save)
            {
                this.lnkbtnCancel.Text = "Date";
                this.lnkbtnSave.Text = "Edit";
                this.PageModes = PageMode.Edit;
            }

            //  this.history_arrow.Visible = false;
            // this.history.Visible = false;
        }*/
        /*
        private void SetContorlEnablity(int rollTimeId)
        {
            lnkbtnSave.Enabled = !(DateTime.Now.Date != Convert.ToDateTime(lblCurrentDateTime.Text) || rollTimeId != this.RollTimeStatusId);

        }*/
        private void InitializedData(PageActions pageActions, FillSearch fillSearch)
        {


            if (pageActions == PageActions.InitializedPage)
            {
                fillSearch.IsFillTeachersAndStudents   = true;
               // fillSearch.IsIncharge = true;
                fillSearch.TeacherId = this.CurrentUser.LoginUserId;
                fillSearch.CampusId = this.CurrentUser.CampusId;
                fillSearch.IsFillCampuses = true;
                fillSearch.IsFillClasses = true;
                fillSearch.IsFillSections = true;
                fillSearch.IsFillTerm = true;
                FillResponse fillResponse = FillSearchManager.FillData(fillSearch);
                if (fillResponse.ClassesTeacher != null && fillResponse.ClassesTeacher.Count > 0)
                {
                    this.rptTeacherClass.DataSource = fillResponse.ClassesTeacher;
                    this.rptTeacherClass.DataBind();
                    this.CurrentClassId = fillResponse.ClassesTeacher[0].Classes.ID;
                    this.CurrentSectionId = fillResponse.ClassesTeacher[0].Section.ID;
                    this.CurrentCampusId = fillResponse.ClassesTeacher[0].Campus.ID;
                }

                if (fillResponse.Studnets != null && fillResponse.Studnets.Count > 0)
                {
                    this.rptStudnetList.DataSource = fillResponse.Studnets;
                    this.rptStudnetList.DataBind();
                }
                if (fillResponse.Campuses != null && fillResponse.Campuses.Count > 0)
                {
                    this.ddlCampus.DataSource = fillResponse.Campuses;
                    this.ddlCampus.DataTextField = "CampusName";
                    this.ddlCampus.DataValueField = "ID";
                    this.ddlCampus.DataBind();

                    ListItem item = new ListItem();
                    item.Text = "-Select-";
                    item.Value = "-1";
                    this.ddlCampus.Items.Insert(0, item);
                    this.ddlCampus.SelectedValue = "-1";

                }
                if (fillResponse.Classes != null && fillResponse.Classes.Count > 0)
                {
                    this.ddlClass.DataSource = fillResponse.Classes;
                    this.ddlClass.DataTextField ="Name";
                    this.ddlClass.DataValueField ="Id";
                    this.ddlClass.DataBind();

                    ListItem item = new ListItem();
                    item.Text = "-Select-";
                    item.Value = "-1";
                    this.ddlClass.Items.Insert(0,item);
                    this.ddlClass.SelectedValue = "-1";

                }

                if (fillResponse.Sections != null && fillResponse.Sections.Count > 0)
                {
                    this.ddlSection.DataSource = fillResponse.Sections;
                    this.ddlSection.DataTextField = "Name";
                    this.ddlSection.DataValueField = "Id";
                    this.ddlSection.DataBind();

                    ListItem item = new ListItem();
                    item.Text = "-Select-";
                    item.Value = "-1";
                    this.ddlSection.Items.Insert(0, item);
                    this.ddlSection.SelectedValue = "-1";
                }

                if (fillResponse.Terms != null && fillResponse.Terms.Count > 0)
                {
                    this.ddlTerm.DataSource = fillResponse.Terms;
                    this.ddlTerm.DataTextField = "TermDescription";
                    this.ddlTerm.DataValueField = "ID";//"TermNo";
                    this.ddlTerm.DataBind();

                    ListItem item = new ListItem();
                    item.Text = "-Select-";
                    item.Value = "-1";
                    this.ddlTerm.Items.Insert(0, item);
                    this.ddlTerm.SelectedValue = "-1";
                }

            }
            else if (pageActions == PageActions.FillStudent)
            {
                // fillSearch.RollTimeStatusId = this.RollTimeStatusId;
                fillSearch.IsFillStudents = true;
                fillSearch.SectionId = this.CurrentSectionId;
                fillSearch.ClassId = this.CurrentClassId;
                fillSearch.CampusId = this.CurrentCampusId;
                FillResponse fillResponse = FillSearchManager.FillData(fillSearch);
                this.rptStudnetList.DataSource = fillResponse.Studnets;
                this.rptStudnetList.DataBind();

            }
        }
        #region Web Methods
        /*
        private List<BusinessEntities.Attendance.StudentAttendace> GetStudentAttendance()
        {
            HiddenField hfControl = null;
            List<BusinessEntities.Attendance.StudentAttendace> studentsAttendance = new List<BusinessEntities.Attendance.StudentAttendace>();
            for (int i = 0; i < this.rptRollList.Items.Count; i++)
            {
                BusinessEntities.Attendance.StudentAttendace studentAttendace = new BusinessEntities.Attendance.StudentAttendace();
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentAttendanceId");
                if (hfControl != null)
                {
                    studentAttendace.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceStatusId");
                if (hfControl != null)
                {
                    studentAttendace.AttendanceStatus = new BusinessEntities.Attendance.AttendanceStatus();
                    studentAttendace.AttendanceStatus.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfStudentId");
                if (hfControl != null)
                {
                    studentAttendace.Student = new Student();
                    studentAttendace.Student.ID = Convert.ToInt32(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfNote");
                if (hfControl != null)
                {
                    studentAttendace.Remarks = Convert.ToString(hfControl.Value);
                }
                hfControl = (HiddenField)this.rptRollList.Items[i].FindControl("hfAttendanceDate");
                if (hfControl != null)
                {
                    if (!string.IsNullOrEmpty(hfControl.Value) && Convert.ToDateTime(hfControl.Value).Year != 1)
                    {
                        studentAttendace.AttendanceDate = Convert.ToDateTime(hfControl.Value);
                    }
                    else if (Convert.ToDateTime(hfControl.Value).Year == 1)
                    {//code for preventing duplication by zahmad

                        studentAttendace.AttendanceDate = DateTime.Now;//Convert.ToDateTime(DateTime.Now);
                    }
                }

                studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                studentAttendace.RollTimeAttendaceStatus.ID = this.RollTimeStatusId;
                studentAttendace.Student.StudnetClass = new BusinessEntities.Configuration.Classes();
                studentAttendace.Student.StudnetClass.ID = this.CurrentClassId;
                studentAttendace.Student.Section = new BusinessEntities.Configuration.Section();
                studentAttendace.Student.Section.ID = this.CurrentSectionId;
                studentsAttendance.Add(studentAttendace);
            }
            return studentsAttendance;


        }
        [WebMethod]
        public static string LoadStudentPicture(int studentId)
        {

            HttpContext.Current.Session["StudentId"] = studentId;
            string fullPhoto = "../Images/SuhailShahab.jpg";
            //../Images/full_avatar.jpg;
            return fullPhoto;


        }
        [WebMethod]
        public static string GetTime()
        {
            return DateTime.Now.ToString();
            //HttpContext.Current.Session["StudentId"] = studentId;
            //string fullPhoto = "../Images/SuhailShahab.jpg";
            //../Images/full_avatar.jpg;
            //return fullPhoto;


        }
         */
        #endregion
        /*
        protected void lnkbtnSave_OnClick(object sender, EventArgs e)
        {
            try
            {

                if (this.PageModes == PageMode.Edit)
                {
                }
                else if (this.PageModes == PageMode.Save)
                {

                    FillSearch fillSearch = new FillSearch();
                    fillSearch.ClassId = this.CurrentClassId;
                    fillSearch.SectionId = this.CurrentSectionId;
                    fillSearch.IsFillStudentAttendanceByid = true;
                    this.InitializedData(PageActions.InitializedPage, new FillSearch());
                   
                }
              
            }
            catch// (Exception ex)
            {
            }
        }*/



        #endregion

        
        #region Button Events
        protected void lnkbtnLogOut_Click(object sender, EventArgs e)
        {
            this.Session.Abandon();
            Response.Redirect(PageUrl.loginPageUrl);
        }
       /* protected void lblLateAbsentReport_Click(object sender, EventArgs e)
        {
            try
            {
                
                ReportParameters.ReportType = ReportType.StudentTotalLateAbsetnCount;
                Response.Redirect("~/Reports/Templates/AttendanceReportView.aspx?QryStrClassId=" + this.CurrentClassId + "&QryStrSectionId=" + this.CurrentSectionId + "&qryRollTimeStatusId=" + this.RollTimeStatusId, false);
                
            }
            catch (Exception loEx)
            {
                Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }*/

     
        public void ShowMsg(string msg)
        {
            ScriptManager.RegisterStartupScript(this, typeof(Button), "Message", "alert('" + msg + "');", true);

        }
        #endregion
       
        #region Create student 
        protected void btnCreateStudent_Click(object sender, EventArgs e)
        {

            try
            {
                string errorMsg = this.IsValidData();
                if (!string.IsNullOrEmpty(errorMsg))
                {
                    this.ShowMsg(errorMsg);
                    return;
                }
                Student student = getStudentData();
                StudentManager studentManager = new StudentManager();
                if (this.hfSelectedStudentId.Value != null && Convert.ToInt32(this.hfSelectedStudentId.Value) > 0)// && this.hfSelectedGuardianId.Value != null && Convert.ToInt32(this.hfSelectedGuardianId.Value) > 0)
                {
                    studentManager.Update(student, this.CurrentUser.ID);
                }
                else
                {
                    studentManager.Add(student, this.CurrentUser.ID);
                }
                ClearInputs(this.Page.Controls);
                RefreshData();
                this.ShowMsg("Record saved successfully.");
            }
            catch (Exception loEx)
            {
                this.ShowMsg(loEx.Message);
            }

        }
        protected void btnTerminate_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    string errorMsg = this.IsValidData();
                    if (!string.IsNullOrEmpty(errorMsg))
                    {
                        this.ShowMsg(errorMsg);
                        return;
                    }
                    StudentManager studentManager = new StudentManager();
                    if (this.hfSelectedStudentId.Value != null && Convert.ToInt32(this.hfSelectedStudentId.Value) > 0)// && this.hfSelectedGuardianId.Value != null && Convert.ToInt32(this.hfSelectedGuardianId.Value) > 0)
                    {
                        Student student = getStudentData();
                        studentManager.TerminateStudent(student, this.CurrentUser.ID);
                        ClearInputs(this.Page.Controls);
                        RefreshData();
                        this.ShowMsg("Student terminated.");
                    }
                    
                  
                }
                catch (Exception loEx)
                {
                    this.ShowMsg(loEx.Message);
                }
            }
            catch(Exception loex)
            {
            }
        }
       /* protected void btnNew_Click(object sender, EventArgs e)
        {

            try
            {                
                ClearInputs(this.Page.Controls);
                RefreshData();
            }
            catch (Exception loEx)
            {
                this.ShowMsg(loEx.Message);
            }

        }*/
        private string  IsValidData()
        {
            if (string.IsNullOrEmpty(this.txtFirstName.Text))
            {
                return "First Name is missing.";
            }
            else if (string.IsNullOrEmpty(this.txtSurName.Text))
            {
                return "Sur Name is missing.";
            }
            
            else if (string.IsNullOrEmpty(this.ddlClass.SelectedValue) || Convert.ToInt32(this.ddlClass.SelectedValue) == -1)
            {
                return "Please select class.";
            }
            else if (string.IsNullOrEmpty(this.ddlSection.SelectedValue) || Convert.ToInt32(this.ddlSection.SelectedValue) == -1)
            {
                return "Please select section.";
            }
            else if (string.IsNullOrEmpty(this.ddlTerm.SelectedValue) || Convert.ToInt32(this.ddlTerm.SelectedValue) == -1)
            {
                return "Please select term.";
            }
            else if (string.IsNullOrEmpty(this.txtMobile.Text))
            {
                return "Cell no is missing.";
            }
            else if (string.IsNullOrEmpty(this.txtEmail.Text))
            {
                return "Email is missing.";
            }
            else if (string.IsNullOrEmpty(this.txtRegistration.Text))
            {
                return "Registration no is missing.";
            }
            return string.Empty;
        }
        private void ClearInputs(ControlCollection ctrls)
        {
            this.hfSelectedGuardianId.Value = "0";
            this.hfSelectedStudentId.Value = "0";
            this.hfSelectSmallPictureUrl.Value = string.Empty;
            this.hfSelectLargePicUrl.Value = string.Empty;
            this.hfSelectIsActive.Value = string.Empty;
            foreach (Control ctrl in ctrls)
            {
                if (ctrl is TextBox)
                    ((TextBox)ctrl).Text = string.Empty;
                else if (ctrl is DropDownList)
                    ((DropDownList)ctrl).ClearSelection();

                ClearInputs(ctrl.Controls);
            }
        }
        private Student getStudentData()
        {
            Student student = new Student();
            student.ID = this.hfSelectedStudentId.Value != null && Convert.ToInt32(this.hfSelectedStudentId.Value) == 0 ? 0 : Convert.ToInt32(this.hfSelectedStudentId.Value);
            student.Name = String.IsNullOrEmpty(txtFirstName.Text) ? string.Empty : txtFirstName.Text;
            student.LastName = String.IsNullOrEmpty(txtSurName.Text) ? string.Empty : txtSurName.Text;
            student.Email = String.IsNullOrEmpty(txtEmail.Text) ? string.Empty : txtEmail.Text;
            student.RegistrationNo = String.IsNullOrEmpty(txtRegistration.Text) ? string.Empty : txtRegistration.Text;

            student.StudentGaurdain = new StudentGaurdian();
            student.Campus = new BusinessEntities.Configuration.Campus();
            student.StudnetClass = new BusinessEntities.Configuration.Classes();
            student.Section = new BusinessEntities.Configuration.Section();
            student.Term = new BusinessEntities.Configuration.Term();
            student.StudentGaurdain.CellNo  = String.IsNullOrEmpty(txtMobile.Text) ? string.Empty : txtMobile.Text;
            student.StudentGaurdain.ID = this.hfSelectedGuardianId.Value != null && Convert.ToInt32(this.hfSelectedGuardianId.Value) == 0 ? 0 : Convert.ToInt32(this.hfSelectedGuardianId.Value);

            if (!(ddlCampus.SelectedValue.Equals("-1")))
                student.Campus.ID = Convert.ToInt32(ddlCampus.SelectedValue);

            if (!(ddlClass.SelectedValue.Equals("-1")))
                student.StudnetClass.ID = Convert.ToInt32(ddlClass.SelectedValue);

            if (!(ddlSection.SelectedValue.Equals("-1")))
                student.Section.ID = Convert.ToInt32(ddlSection.SelectedValue);

            if (!(ddlTerm.SelectedValue.Equals("-1")))
                student.Term.ID = Convert.ToInt32(ddlTerm.SelectedValue);

            student.SmallPicture = this.hfSelectSmallPictureUrl.Value;
            student.LargePicture = this.hfSelectLargePicUrl.Value;
            student.IsActive = true; //Convert.ToBoolean(this.hfSelectIsActive.Value);

            return student;


        }
        private void SetStudentData(RepeaterItem repeaterItem)
        {
            HiddenField hfValue=null;
            Label lblValue = null;
            if (repeaterItem != null)
            {
                Student student = new Student();
                hfValue = (HiddenField)repeaterItem.FindControl("hfStudentId");
                if (hfValue != null)
                {
                    hfSelectedStudentId.Value = hfValue.Value;
                   
                }
                lblValue = (Label)repeaterItem.FindControl("lblName");
                if (hfValue != null)
                {
                    txtFirstName.Text = lblValue.Text;

                }
                lblValue = (Label)repeaterItem.FindControl("lblLastName");
                if (hfValue != null)
                {
                  this.txtSurName.Text = lblValue.Text;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfEmail");
                if (hfValue != null)
                {
                  txtEmail.Text  = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfRegistrationNo");
                if (hfValue != null)
                {
                  txtRegistration.Text  = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfStudentGaurdianId");
                if (hfValue != null)
                {
                    hfSelectedGuardianId.Value  = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfGaurdianCellNo");
                if (hfValue != null)
                {
                   this.txtMobile.Text  = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfCampusId");
                if (hfValue != null)
                {
                    this.ddlCampus.SelectedValue = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfClassId");
                if (hfValue != null)
                {
                   this.ddlClass.SelectedValue   = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfSectionId");
                if (hfValue != null)
                {
                    this.ddlSection.SelectedValue = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfTermId");
                if (hfValue != null)
                {
                    this.ddlTerm.SelectedValue = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfIsActive");
                if (hfValue != null)
                {
                    this.hfSelectIsActive.Value  = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfLargePicture");
                if (hfValue != null)
                {
                    this.hfSelectLargePicUrl.Value = hfValue.Value;

                }
                hfValue = (HiddenField)repeaterItem.FindControl("hfSmallPicture");
                if (hfValue != null)
                {
                    this.hfSelectSmallPictureUrl.Value = hfValue.Value;

                }
                
            }
        }
       /* protected void rptStudnetList_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

            try
            {
                if (e.Item != null)
                {
                    this.SetStudentData(e.Item);
                }
            }
            catch
            {
            }
        }*/

        private void RefreshData()
        {
            FillSearch fillSearch = new FillSearch();
            fillSearch.ClassId = this.CurrentClassId;
            fillSearch.SectionId = this.CurrentSectionId;
            fillSearch.CampusId = this.CurrentCampusId;
            fillSearch.IsFillStudentAttendanceByid = true;
            this.InitializedData(PageActions.InitializedPage, new FillSearch());
        }
        #endregion 
    }
}