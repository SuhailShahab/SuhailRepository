﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Globalization;

namespace AMS.Web.Reports
{
    public partial class StudentRpt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Create a new StringBuilder object
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(GetStudentRptSummaryHtml());
            sb.AppendLine("<div id=\"std\">");
            //DateTime now =   DateTime;
            var months = CultureInfo.CurrentCulture.DateTimeFormat.MonthNames;
            string monthName = string.Empty;
            int rowLimit = 3;
            //Iterating over 12 months in a year
            for (int i = 0; i < months.Length-1; i++)
            {

                if (i == rowLimit)
                {
                    rowLimit += 3;
                    sb.AppendLine("<h1></h1>");
                }
                monthName = months[i].ToString();//now.ToString("MMMM");
              // now = now.AddMonths(1);

               sb.AppendLine(GetStudentRptMonthlyAttendanceHtml(monthName));
            }

            sb.AppendLine("<p>&nbsp;</p>");
            sb.AppendLine("<p>&nbsp;</p>");
            sb.AppendLine("<p>&nbsp;</p>");
            sb.AppendLine("</div>");// end of std div

            Response.Write(sb.ToString());

        }
        /// <summary>
        /// <para>
        /// studentClass,section,student name, student total term wise attendance, yearly total attendance
        /// </para>
        /// </summary>
        string GetStudentRptSummaryHtml()
        {
            
            //Create a new StringBuilder object
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("<div id=\"summary\">");
            sb.AppendLine("<img src=\"min_avatar.jpg\" width=\"72\" height=\"72\">");
            sb.AppendLine("<p>5C<br />");
            sb.AppendLine("Mahmud<br />");
            sb.AppendLine("Dagestani</p>");

            sb.AppendLine("<span class=\"pie\">20,3,80</span>");
            sb.AppendLine("<ul>");
            sb.AppendLine("<li>Yearly</li>");
            sb.AppendLine("<li>12: Late</li>");
            sb.AppendLine("<li>7: Absent</li>");
            sb.AppendLine("</ul>");

            sb.AppendLine("<span class=\"pie\">1,3,90</span>");
            sb.AppendLine("<ul>");
            sb.AppendLine("<li>Term 1</li>");
            sb.AppendLine("<li>12: Late</li>");
            sb.AppendLine("<li>7: Absent</li>");
            sb.AppendLine("</ul>");

            sb.AppendLine("<span class=\"pie\">2,13,100</span>");
            sb.AppendLine("<ul>");
            sb.AppendLine("<li>Term 2</li>");
            sb.AppendLine("<li>12: Late</li>");
            sb.AppendLine("<li>7: Absent</li>");
            sb.AppendLine("</ul>");

            sb.AppendLine("<span class=\"pie\">2,2,100</span>");
            sb.AppendLine("<ul><li>Term 3</li>");
            sb.AppendLine("<li>12: Late</li>");
            sb.AppendLine("<li>7: Absent</li>");
            sb.AppendLine("</ul>");

            sb.AppendLine("<span class=\"pie\">40,13,30</span>");
            sb.AppendLine("<ul><li>Term 4</li>");
            sb.AppendLine("<li>12: Late</li>");
            sb.AppendLine("<li>7: Absent</li>");
            sb.AppendLine("</ul>");
            sb.AppendLine("</div>");

            return(sb.ToString());


        }

        string GetStudentRptMonthlyAttendanceHtml(string monthName )
        { 
            //Create a new StringBuilder object
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("<h2>"+monthName+"</h2>");
            sb.AppendLine("<table border=\"0\">");
            sb.AppendLine("  <tr>");
            sb.AppendLine("    <th scope=\"col\">Mon</th>");
            sb.AppendLine("    <th scope=\"col\">Tue</th>");
            sb.AppendLine("    <th scope=\"col\">Wed</th>");
            sb.AppendLine("    <th scope=\"col\">Thu</th>");
            sb.AppendLine("    <th scope=\"col\">Fri</th>");
            sb.AppendLine("    </tr>");
            sb.AppendLine("  <tr>");
            sb.AppendLine("    <td>2<span class=\"am orange\">l</span><span class=\"pm green\">p</span></td>");
            sb.AppendLine("    <td>3<span class=\"am red\">l</span><span class=\"pm red\">p</span></td>");
            sb.AppendLine("    <td>4<span class=\"am green\">l</span><span class=\"pm orange\">p</span></td>");
            sb.AppendLine("    <td>5<span class=\"am green\">l</span><span class=\"pm green\">p</span></td>");
            sb.AppendLine("    <td>6<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    </tr>");
            sb.AppendLine("  <tr>");
            sb.AppendLine("    <td>9<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>10<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>11<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>12<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>13<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    </tr>  <tr>");
            sb.AppendLine("    <td>16<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>17<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>18<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>19<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>20<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    </tr>  <tr>");
            sb.AppendLine("    <td>23<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>24<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>25<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>26<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>27<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    </tr>  <tr>");
            sb.AppendLine("    <td>30<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>31<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>1<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>2<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    <td>3<span class=\"am\">l</span><span class=\"pm\">p</span></td>");
            sb.AppendLine("    </tr>");
            sb.AppendLine("  </table>");

            return sb.ToString();
        
        }
        void GetStdTermsAttendanceHtml(int termId)
        { 


        
        
        }
    }
}