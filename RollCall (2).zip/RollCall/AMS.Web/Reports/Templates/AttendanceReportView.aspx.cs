﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMS.BusinessEntities.CustomEnum;
using System.Data;
using AMS.Business.Reports;
using CrystalDecisions.CrystalReports.Engine;
using AMS.Web.Common;

namespace AMS.Web.Reports.Templates
{
    public partial class AttendanceReportView : System.Web.UI.Page
    {
        private BusinessEntities.Attendance.StudentClassAssociation statsReportData;

        public BusinessEntities.Attendance.StudentClassAssociation StatsReportData
        {
            get
            {
                if (Session["StatsReportCriteria"] == null)
                {
                    return null;
                }
                else
                {
                    return statsReportData = (BusinessEntities.Attendance.StudentClassAssociation)Session["StatsReportCriteria"];
                }
                //  return statsReportData; 
            }
            set
            {
                statsReportData = value;
                
            }
        }

        
        protected void Page_Load(object sender, EventArgs e)
        {
            bool isAllClasses;
            int classId;
            int sectionId;
            int campusId;
            DataTable dt = null;
            if (Request.QueryString.HasKeys())
            {
                classId = Convert.ToInt32(Request.QueryString["QryStrClassId"]);
                sectionId = Convert.ToInt32(Request.QueryString["QryStrSectionId"]);
                campusId = Convert.ToInt32(Request.QueryString["QryStrCampusId"]);
                isAllClasses = Convert.ToBoolean(Request.QueryString["IsAllClasses"]);
                if (CurrentUser.User == null || CurrentUser.User.ID == 0)
                {
                    this.ShowMsg("Invalid user.");
                }
                else 
                if (ReportParameters.ReportType == ReportType.DailyAbsenteesReport)
                {
                    
                     dt = new ReportManager().GetAbsentLateByClassSectionId(classId, sectionId,campusId, isAllClasses,  ReportParameters.CurrentDate, CurrentUser.User.ID);
                    //this.ShowReport(ReportParameters.ReportType, dt);
                   /* if (dt.Rows.Count > 0)
                    {
                        this.ShowReport(ReportParameters.ReportType, dt);
                    }
                    else
                    {
                        this.ShowMsg("Record not found.");
                    }*/
                    
                }
                else if (ReportParameters.ReportType == ReportType.SummaryAbsentReport)
                {

                    dt = new ReportManager().GetGenderBasedAbsentClassSectionId(classId, sectionId, campusId, isAllClasses, ReportParameters.CurrentDate, CurrentUser.User.ID);
                        //this.ShowReport(ReportParameters.ReportType, dt);
                        /* if (dt.Rows.Count > 0)
                         {
                             this.ShowReport(ReportParameters.ReportType, dt);
                         }
                         else
                         {
                             this.ShowMsg("Record not found.");
                         }*/

                }
                else if (ReportParameters.ReportType == ReportType.PrimaryReport)
                {

                     dt = new ReportManager().GetStudentAttendanceByClassSectionId(classId, sectionId,campusId, isAllClasses, ReportParameters.CurrentDate, CurrentUser.User.ID, ClassLevels.PrimaryLevel.GetHashCode());
                   // this.ShowReport(ReportParameters.ReportType, dt);
                   /* if (dt.Rows.Count > 0)
                    {
                        this.ShowReport(ReportParameters.ReportType, dt);
                    }
                    else
                    {
                        this.ShowMsg("Record not found.");
                    }*/

                }
                else if (ReportParameters.ReportType == ReportType.SecondaryReport)
                {

                     dt = new ReportManager().GetStudentAttendanceByClassSectionId(classId, sectionId,campusId, isAllClasses, ReportParameters.CurrentDate, CurrentUser.User.ID, ClassLevels.SecondaryLevel.GetHashCode());
                   /* if (dt.Rows.Count > 0)
                    {
                        this.ShowReport(ReportParameters.ReportType, dt);
                    }
                    else
                    {
                        this.ShowMsg("Record not found.");
                    }*/

                }
                else if (ReportParameters.ReportType == ReportType.StudentTotalLateAbsetnCount)
                {
                    int rollTimeStatusId = Convert.ToInt32(Request.QueryString["qryRollTimeStatusId"]);
                     dt = new ReportManager().GetStudentAttendaceLateCountReport(classId, sectionId,campusId, rollTimeStatusId);
                    //this.ShowReport(ReportParameters.ReportType, dt);
                }
                                
            }

            else if (ReportParameters.ReportType == ReportType.StatsDailyReport)
            {
                //campusId = this.StatsReportData.Campus.ID;
                //classId = this.StatsReportData.StudentClass.ID;
                //sectionId = this.StatsReportData.Section.ID;
                //fillSearch.RollTimeStatusId = this.StatsReportData.RollTimeAttendanceStatus.ID;
                //fillSearch.ReportFromDate = this.StatsReportData.StartDate;
                //fillSearch.ReportToDate = this.StatsReportData.EndDate;

                dt = new ReportManager().GetDailyStatsReport(StatsReportData);

            }
            else if (ReportParameters.ReportType == ReportType.StatsSummaryReport)
            {
               // classId = 1; sectionId = 1; campusId = 1; isAllClasses = false;
                dt = new ReportManager().GetSummaryStatsReport(StatsReportData);

            }
            if (dt != null && dt.Rows.Count > 0)
            {
                this.ShowReport(ReportParameters.ReportType, dt);
            }
            else
            {
                lblMsg.Text = "Record not found.";
                this.ShowMsg("Record not found.");
            }
        }
      
        private void ShowReport(ReportType reportType,DataTable dt)
        {
            if (reportType == ReportType.DailyAbsenteesReport)
            {
                if (dt != null && dt.Rows.Count > 0)
                {

                    ReportDocument rptDoc = new ReportDocument();
                    rptDoc.Load(Server.MapPath("rptAbsentees.rpt"));                    
                    rptDoc.SetDataSource(dt);
                    rptDoc.SetParameterValue("currentDate", ReportParameters.CurrentDate);
                    this.crvAttendanceReport.ReportSource = rptDoc;

                }
            } 
            else if (reportType == ReportType.SummaryAbsentReport)
            {
                if (dt != null && dt.Rows.Count > 0)
                {

                    ReportDocument rptDoc = new ReportDocument();
                    rptDoc.Load(Server.MapPath("rptSummaryAbsentees.rpt"));
                    rptDoc.SetDataSource(dt);
                    //rptDoc.SetParameterValue("currentDate", ReportParameters.CurrentDate);
                    this.crvAttendanceReport.ReportSource = rptDoc;

                }
            }
            /*else if (reportType == ReportType.DailyAttendanceReport)
            {
                if (dt != null && dt.Rows.Count > 0)
                {

                    ReportDocument rptDoc = new ReportDocument();
                    rptDoc.Load(Server.MapPath("rpt_DailyAttendance.rpt"));                    
                    rptDoc.SetDataSource(dt);
                    rptDoc.SetParameterValue("currentDate", ReportParameters.CurrentDate);
                    this.crvAttendanceReport.ReportSource = rptDoc;

                }
            }*/
            else if (ReportParameters.ReportType == ReportType.SecondaryReport || ReportParameters.ReportType == ReportType.PrimaryReport)//)reportType == ReportType.DailyAttendanceReport)
            {
                if (dt != null && dt.Rows.Count > 0)
                {

                    ReportDocument rptDoc = new ReportDocument();
                    rptDoc.Load(Server.MapPath("rpt_DailyAttendance.rpt"));
                    rptDoc.SetDataSource(dt);
                    rptDoc.SetParameterValue("currentDate", ReportParameters.CurrentDate);
                    if (ReportParameters.ReportType == ReportType.PrimaryReport)
                    {
                        rptDoc.SummaryInfo.ReportTitle = "Daily Report - Primary";
                    }
                    else
                    {
                        rptDoc.SummaryInfo.ReportTitle = "Daily Report - Secondary";
                    }
                    this.crvAttendanceReport.ReportSource = rptDoc;

                }
            }
            else if (reportType == ReportType.StudentTotalLateAbsetnCount)
            {
                if (dt != null && dt.Rows.Count > 0)
                {

                    ReportDocument rptDoc = new ReportDocument();
                    rptDoc.Load(Server.MapPath("rptStudentAbsentLateCount.rpt"));
                    rptDoc.SetDataSource(dt);
                   // rptDoc.SetParameterValue("currentDate", ReportParameters.CurrentDate);
                    this.crvAttendanceReport.ReportSource = rptDoc;

                }
            }
            else if(reportType == ReportType.StatsDailyReport)
            {
                 if (dt != null && dt.Rows.Count > 0)
                {

                    ReportDocument rptDoc = new ReportDocument();
                    rptDoc.Load(Server.MapPath("rptDailyDataSheet.rpt"));
                    rptDoc.SetDataSource(dt);
                   // rptDoc.SetParameterValue("currentDate", ReportParameters.CurrentDate);
                    this.crvAttendanceReport.ReportSource = rptDoc;

                }
            
            
            }
            else if(reportType == ReportType.StatsSummaryReport)
            {
                 if (dt != null && dt.Rows.Count > 0)
                {

                    ReportDocument rptDoc = new ReportDocument();
                    rptDoc.Load(Server.MapPath("rptSummaryDataSheet.rpt"));
                    rptDoc.SetDataSource(dt);
                   // rptDoc.SetParameterValue("currentDate", ReportParameters.CurrentDate);
                    this.crvAttendanceReport.ReportSource = rptDoc;

                }
            
            
            }
           
        }
        #region  Custom Methods
        public void ShowMsg(string msg)
        {
            ScriptManager.RegisterStartupScript(this, typeof(Button), "Message", "alert('" + msg + "');", true);

        }
        #endregion
    }
}