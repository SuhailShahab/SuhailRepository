﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMS.Web.Reports.Templates;
using System.Data;
using AMS.Business.Reports;
using CrystalDecisions.CrystalReports.Engine;
using AMS.Web.Common;
using System.Drawing.Printing;
using System.Drawing;

namespace AMS.Web.Reports
{
    public partial class reportViewer : System.Web.UI.Page
    {
        #region Custom Properties
        private int studentAttendanceId;

        public int StudentAttendanceId
        {
            get
            {
                if (Session["StudentAttendanceId"] == null)
                {
                    return 0;
                }
                else
                {
                    return studentAttendanceId = Convert.ToInt32(Session["StudentAttendanceId"]);
                }
            }
            //set
            //{
            //    ViewState["RollTimeStatusId"] = value;
            //}
        }
        #endregion
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.StudentAttendanceId > 0)
            {
                DataSet ds = new ReportManager().GetLatePassReportData(this.StudentAttendanceId);
                ReportDocument rptDoc = new ReportDocument();
                rptDoc.Load(Server.MapPath(PageUrl.latePassReportUrl));
                rptDoc.SetDataSource(ds);
                crvLatePass.ReportSource = rptDoc;               
                
            }
        }
    }
}