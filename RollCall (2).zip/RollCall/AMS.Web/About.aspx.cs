﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AMS.Web.Common;

namespace AMS.Web
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String fullpath = PageUrl.latePassViewUrl;
            String attributes = "scrollbars,menubar,resizable,status,width=600,height=400";
            ltrJavscript.Text = "<script type= \"text/javascript\" >window.open('" + fullpath.ToString() + "','','" + attributes.ToString() + "'); </script>";
          //  ScriptManager.RegisterStartupScript(this, typeof(Button), "Message", ltrJavscript.Text, true);


           // "javascript:window.open('LowSpecDetail.aspx','mywindow','left=200,top=180,height=400,width=800,status=yes,toolbar=no,menubar=no,location=no, resizable=yes,scrollbars=1, directories=no');"
           // string script = "<script type= \"text/javascript\"> alert('" + cleanMessage + "');</script>";
           // Page page = HttpContext.Current.CurrentHandler as Page;

           // page.ClientScript.RegisterClientScriptBlock(typeof(MessageAlert), "alert", ltrJavscript.Text);
        }
    }
}
