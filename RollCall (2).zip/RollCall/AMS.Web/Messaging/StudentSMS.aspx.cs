﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BuisnessEntity.FillEvent;
using AMS.BusinessEntities.CustomEnum;
using FrameWork.Common;
using AMS.Business.Messaging;
using AMS.BusinessEntities.Messaging;
using System.Net;
using System.IO;
using AMS.Web.Common;
using System.Web.UI.HtmlControls;

namespace AMS.Web.Messaging
{
    public partial class StudentSMS : System.Web.UI.Page
    {
        #region Declearation
        public enum PageActions : byte
        {
            None,
            InitializedPage
            
        }
         private PageMode pageModes;
         private int currentCampusId;
        #endregion 
         public int CurrentCampusId
         {
             get
             {
                 if (ViewState["CurrentCampusId"] == null)
                 {
                     return 0;
                 }
                 else
                 {
                     return currentCampusId = Convert.ToInt32(ViewState["CurrentCampusId"]);
                 }
             }
             set
             {
                 ViewState["CurrentCampusId"] = value;

             }
         }
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Utility.CheckSessionTimeout(this.Page,this.GetType());
                if (!IsPostBack)
                {
                   CurrentCampusId = Convert.ToInt32(Request.QueryString["QryStrCampusId"]);
                    if (Request.QueryString.HasKeys() && Request.QueryString["messageid"] != null)
                    {
                        string messageid = Request.QueryString["messageid"].ToString();
                        string gaurdianMessage = Request.QueryString["message_text"].ToString();
                        MessageResponseManager messageResponseManager = new MessageResponseManager();
                        //update parent response to db
                        messageResponseManager.UpdateStudentMessage(messageid,gaurdianMessage);

                    }
                    FillGrid(CurrentCampusId);
                                        
                }

               
            }
            catch (Exception loEx)
            {
                //WriteExpceptionMessage(loEx.Message);
            }
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            HiddenField hfControl = null;
            DropDownList ddlReason = null;
            Label lblSMSSendingDate = null;
            //Get the reference of the clicked button.
            Button button = (sender as Button);
            //Get the Repeater Item reference
            RepeaterItem item = button.NamingContainer as RepeaterItem;
         
            //Get the repeater item index
            int index = item.ItemIndex;
            MessageResponseManager messageResponseManager =null;
            hfControl = (HiddenField)this.rptStudentSMS.Items[index].FindControl("hfStudentId");
            ddlReason = (DropDownList)this.rptStudentSMS.Items[index].FindControl("ddlReasons");
            lblSMSSendingDate = (Label)this.rptStudentSMS.Items[index].FindControl("lblReplyDate");

            if (hfControl != null && ddlReason != null)
            {
                int studentId = Convert.ToInt32(hfControl.Value);
                int attendanceStatusId = Convert.ToInt32(ddlReason.SelectedValue);
                DateTime smsSendingDate = Convert.ToDateTime(lblSMSSendingDate.Text);

                if (attendanceStatusId > 0)
                {
                    messageResponseManager = new MessageResponseManager();
                   
                    messageResponseManager.UpdateStudentSMSReason(studentId, attendanceStatusId, smsSendingDate);
                }
            }

            FillGrid(CurrentCampusId);
        
        }
        protected void lnkbtnLogOut_Click(object sender, EventArgs e)
        {
            this.Session.Abandon();
            Response.Redirect(PageUrl.loginPageUrl);
        }
        #region Custom Methods
        
        private void WriteExpceptionMessage(string exMessage)
        {
            Response.Write("<Label>"+exMessage+"</Label>");
        }
        private void InitializedData(PageActions pageActions, FillSearch fillSearch)
        {
            if (pageActions == PageActions.InitializedPage)
            {
                fillSearch.IsFillMessageResponce = true;
                FillResponse fillResponse =  FillSearchManager.FillData(fillSearch);
                if (fillResponse.MessageResponses != null && fillResponse.MessageResponses.Count > 0)
                {
                    this.rptStudentSMS.DataSource  = fillResponse.MessageResponses;
                    this.rptStudentSMS.DataBind();
                }
            }

        }
        private void FillGrid(int campusId)
        {
             try
            {
                MessageResponseManager messageResponseManager = new MessageResponseManager();
                List<MessageResponse> messagesResponse = messageResponseManager.GetAllMessageResponse(campusId);
            
                this.rptStudentSMS.DataSource = messagesResponse;
                this.rptStudentSMS.DataBind();
            }
            catch (Exception loEx)
            {
                //Response.Write("<Label>" + loEx.Message + "</Label>");
            }
        }
        #endregion 

        protected void rptStudentSMS_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HtmlTableRow smsRow = (HtmlTableRow)e.Item.FindControl("smsRow");

                HiddenField hfControl = (HiddenField)e.Item.FindControl("hfActionPerformed");
                if(hfControl.Value == "True")
                    smsRow.Attributes.Add("style", "background-color:#f0f0f0;");
                
            }

        }
    }
}