﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using System.Data;
using DataAccess.Generic.Factory;
using AMS.BusinessEntities.Attendance;

namespace AMS.Business.Reports
{
  public  class ReportManager
    {
      public DataTable GetDailyStatsReport(StudentClassAssociation statsReportData)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          DataTable dt = null;

          DbConnection dbConnection = DAOFactory.Instance.Connection;
          try
          {

              if (statsReportData != null)
              {
                  dt = DAOFactory.Instance.GetIReportDAO(connection).GetDailyStatsReport(statsReportData);
              }
              return dt;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          return null;
      
      }

      public DataTable GetSummaryStatsReport(StudentClassAssociation statsReportData)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          DataTable dt = null;

          DbConnection dbConnection = DAOFactory.Instance.Connection;
          try
          {

              if (statsReportData != null)
              {
                  dt = DAOFactory.Instance.GetIReportDAO(connection).GetSummaryStatsReport(statsReportData);
              }
              return dt;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          return null;
      
      }
      public DataSet GetLatePassReportData(int studentAttendanceId)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          DataSet ds = null;
         
              DbConnection dbConnection = DAOFactory.Instance.Connection;
              try
              {

                  if (studentAttendanceId > 0 )
                  {
                      ds = DAOFactory.Instance.GetILatePassDAL(connection).GetLatePassById(studentAttendanceId);
                  }
                  return ds;
              }
              catch
              {
                  throw new Exception();

              }
              finally
              {
                  if (dbConnection.State == System.Data.ConnectionState.Open)
                  {
                      dbConnection.Close();
                  }
              }            
        
          return null ;
      }

      public DataTable GetAbsentLateByClassSectionId(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          DataSet ds = null;

          DbConnection dbConnection = DAOFactory.Instance.Connection;
          try
          {

              if (classId > 0 && sectionId >0)
              {
                  ds = DAOFactory.Instance.GetIReportDAO(connection).GetAllAbsetLateStudents(classId, sectionId, campusId, isAllClasses, attendanceDate, teacherId);
              }
              return ds.Tables[0];
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          return null;
      }
      public DataTable GetGenderBasedAbsentClassSectionId(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          DataSet ds = null;

          DbConnection dbConnection = DAOFactory.Instance.Connection;
          try
          {

              if (classId > 0 && sectionId > 0)
              {
                  ds = DAOFactory.Instance.GetIReportDAO(connection).GetGenderBasedAbsentStudents(classId, sectionId, campusId, isAllClasses, attendanceDate, teacherId);
              }
              return ds.Tables[0];
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          return null;
      }
      public DataTable GetStudentAttendanceByClassSectionId(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          DataSet ds = null;

          DbConnection dbConnection = DAOFactory.Instance.Connection;
          try
          {

              if (classId > 0 && sectionId > 0)
              {
                  ds = DAOFactory.Instance.GetIReportDAO(connection).GetAllStudentsAttendance(classId, sectionId, campusId, isAllClasses, attendanceDate, teacherId);
              }
              return ds.Tables[0];
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          return null;
      }
      public DataTable GetStudentAttendanceByClassSectionId(int classId, int sectionId, int campusId, bool isAllClasses, DateTime attendanceDate, int teacherId, int classLevelId)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          DataSet ds = null;

          DbConnection dbConnection = DAOFactory.Instance.Connection;
          try
          {

              if (classId > 0 && sectionId > 0)
              {
                  ds = DAOFactory.Instance.GetIReportDAO(connection).GetAllStudentsAttendance(classId, sectionId, campusId, isAllClasses, attendanceDate, teacherId, classLevelId);
              }
              return ds.Tables[0];
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          return null;
      }
      public DataTable GetStudentAttendaceLateCountReport(int classId, int sectionId, int campusId, int rollTimeStatusId)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          DataTable  dt = null;

          DbConnection dbConnection = DAOFactory.Instance.Connection;
          try
          {

              if (classId > 0 && sectionId > 0)
              {
                  dt = DAOFactory.Instance.GetIReportDAO(connection).GetStudentAttendaceLateCountReport(classId, sectionId, campusId, rollTimeStatusId);
              }
              return dt;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          return null;
      }
    }
}
