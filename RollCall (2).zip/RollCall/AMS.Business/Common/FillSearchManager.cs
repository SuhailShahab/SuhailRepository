﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using BuisnessEntity.FillEvent;
using DataAccess.Generic.Factory;
using AMS.BusinessEntities.UserManagement;
using AMS.BusinessEntities.Attendance;
using AMS.BusinessEntities.CustomEnum;
using AMS.BusinessEntities.Student;

namespace FrameWork.Common
{
    public class FillSearchManager 
    {        
        public User GetUser(string userName,string password)
        {
            DbConnection dbConnection = DAOFactory.Instance.Connection;
            try
            {

                User user = DAOFactory.Instance.GetIUserDAO(dbConnection).GetUserByPassword(userName, password);
                if (user != null)
                {
                    user.Role.UserPermissions = DAOFactory.Instance.GetIPermissionDAO(dbConnection).GetPermissionsById(user.Role.ID);
                }
                return user;
            }
            catch
            {
                throw new Exception();

            }
            finally
            {
                if (dbConnection.State == System.Data.ConnectionState.Open)
                {
                    dbConnection.Close();
                }
            }
        }

        public static FillResponse FillData(FillSearch fillSearch)
        {
            DbConnection dbConnection = DAOFactory.Instance.Connection;
            FillResponse resp = new FillResponse();
            try
            {
                //if (fillSearch.IsGetUserInfo)
                //{
                //    resp.User  = DAOFactory.Instance.GetIUserDAO(dbConnection).GetUserByPassword(fillSearch.User.UserName ,fillSearch.User.Password);
                //}

                if (fillSearch.IsGetTeacherClasses && fillSearch.TeacherId > 0)
                {
                    RollTimeAttendaceStatus rollTimeAttendaceStatus = null;
                    resp.ClassesTeacher = DAOFactory.Instance.GetIClassTeacherDAO(dbConnection).GetClassTeacherById(fillSearch.TeacherId, fillSearch.IsIncharge);
                    if (resp.ClassesTeacher != null && resp.ClassesTeacher.Count > 0)
                    {
                        // int roltimeStatusId= DAOFactory.Instance.GetIClassTeacherDAO(dbConnection).GetRollTimeStatusByCurrentTime(DateTime.Now);
                        resp.RollTimeStatuses = DAOFactory.Instance.GetIClassTeacherDAO(dbConnection).GetRollTimeStatus();
                        if (resp.RollTimeStatuses != null && resp.RollTimeStatuses.Count > 0)
                        {
                            int hour = DateTime.Now.Hour; //GetStandardTime(DateTime.Now);
                            if (resp.RollTimeStatuses.Exists(rt => rt.StartingHour <= hour && hour <= rt.EndingHour))
                            {
                                rollTimeAttendaceStatus = resp.RollTimeStatuses.Find(rt => rt.StartingHour <= hour && hour <= rt.EndingHour);
                            }
                            else
                            {
                                rollTimeAttendaceStatus = resp.RollTimeStatuses.Find(rt => rt.ID == RollTimeStatusName.EveningRollTimeId );
                            }
                        }
                        if (rollTimeAttendaceStatus != null && rollTimeAttendaceStatus.ID > 0)
                        {
                            resp.RollTimeStatus = rollTimeAttendaceStatus;
                            if (fillSearch.IsFillStudentAttendanceLateCount)
                            {
                                resp.StudentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetStudentAttendaceLateCount(resp.ClassesTeacher[0].Classes.ID, resp.ClassesTeacher[0].Section.ID, resp.ClassesTeacher[0].Campus.ID, rollTimeAttendaceStatus.ID);
                            }
                            else
                            {
                                resp.StudentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetStudentAttendaceById(resp.ClassesTeacher[0].Classes.ID, resp.ClassesTeacher[0].Section.ID, resp.ClassesTeacher[0].Campus.ID, rollTimeAttendaceStatus.ID);
                            }
                        }
                    }

                }
                if (fillSearch.IsFillTeachersAndStudents)
                {
                    resp.ClassesTeacher = DAOFactory.Instance.GetIClassTeacherDAO(dbConnection).GetClassTeacherById(fillSearch.TeacherId, fillSearch.IsIncharge);
                    if (resp.ClassesTeacher != null && resp.ClassesTeacher.Count > 0)
                    {
                        Student student = new Student();
                        student.StudnetClass = new AMS.BusinessEntities.Configuration.Classes();
                        student.StudnetClass.ID = resp.ClassesTeacher[0].Classes.ID;                       
                        student.Section = new AMS.BusinessEntities.Configuration.Section();
                        student.Section.ID = resp.ClassesTeacher[0].Section.ID;
                        student.Campus = new AMS.BusinessEntities.Configuration.Campus();
                        student.Campus.ID = resp.ClassesTeacher[0].Campus.ID;
                        student.IsActive = true;
                        resp.Studnets = DAOFactory.Instance.GetIStudentDAO(dbConnection).GetAllStudent(student);
                    }
                }
                if (fillSearch.IsFillStudents && fillSearch.ClassId > 0 && fillSearch.SectionId > 0 )
                {
                   
                        Student student = new Student();
                        student.StudnetClass = new AMS.BusinessEntities.Configuration.Classes();
                        student.StudnetClass.ID = fillSearch.ClassId;
                        student.Section = new AMS.BusinessEntities.Configuration.Section();
                        student.Section.ID = fillSearch.SectionId;
                        student.Campus = new AMS.BusinessEntities.Configuration.Campus();
                        student.Campus.ID = fillSearch.CampusId;
                        student.IsActive = true;
                        resp.Studnets = DAOFactory.Instance.GetIStudentDAO(dbConnection).GetAllStudent(student);
                   
                }
                if (fillSearch.IsFillStudentAttendanceByid && fillSearch.SectionId > 0 && fillSearch.ClassId > 0)
                {
                   // int roltimeStatusId = DAOFactory.Instance.GetIClassTeacherDAO(dbConnection).GetRollTimeStatusByCurrentTime(DateTime.Now);
                    resp.StudentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetStudentAttendaceById(fillSearch.ClassId, fillSearch.SectionId, fillSearch.CampusId, fillSearch.RollTimeStatusId);

                }
                if (fillSearch.IsFillRoleTimeStatus)
                {
                    resp.RollTimeStatuses = DAOFactory.Instance.GetIClassTeacherDAO(dbConnection).GetRollTimeStatus();
                }
                if (fillSearch.IsFillMessageResponce)
                {
                    resp.MessageResponses = DAOFactory.Instance.GetIMessageResponseDAO(dbConnection).GetAllMessageResponse(fillSearch.CampusId);
                }
                if (fillSearch.IsFillEvacuationData)
                {
                    if (fillSearch.RollTimeStatusId == 0)
                    {
                      List<RollTimeAttendaceStatus> lstRolltimeStatus   = DAOFactory.Instance.GetIClassTeacherDAO(dbConnection).GetRollTimeStatus();
                      if (lstRolltimeStatus != null && lstRolltimeStatus.Count > 0)
                        {

                            int hour = DateTime.Now.Hour; //GetStandardTime(DateTime.Now);
                            if (lstRolltimeStatus.Exists(r => r.StartingHour <= hour && hour <= r.EndingHour))
                            {
                                RollTimeAttendaceStatus rollTimeStatus = lstRolltimeStatus.FindLast(r => r.StartingHour <= hour && hour <= r.EndingHour);
                                fillSearch.RollTimeStatusId = rollTimeStatus.ID;
                                resp.RollTimeStatus = rollTimeStatus;
                            }

                        }
                    }

                    resp.LstEvacuation = DAOFactory.Instance.GetIEvacuationDAO(dbConnection).GetAll(null, null, fillSearch.CurrentDate, fillSearch.RollTimeStatusId, fillSearch.TeacherId);
                }
                if (fillSearch.IsFillCampuses)
                {
                    resp.Campuses = DAOFactory.Instance.GetICampusDAO(dbConnection).GetAllCampusesName();
                }
                if (fillSearch.IsFillClasses)
                {
                    resp.Classes = DAOFactory.Instance.GetIClassesDAO(dbConnection).GetAllClassesName();
                }
                if (fillSearch.IsFillSections)
                {
                    resp.Sections  = DAOFactory.Instance.GetISectionDAO(dbConnection).GetAllSectionName ();
                }
                if (fillSearch.IsFillTerm)
                {
                    resp.Terms  = DAOFactory.Instance.GetITermDAO(dbConnection).GetAllTermName();
                }

                if (fillSearch.IsGetStudentByCriateria)
                {
                    resp.ClassesTeacher = DAOFactory.Instance.GetIClassTeacherDAO(dbConnection).GetClassTeacherById(fillSearch.TeacherId, null,fillSearch.CampusId,fillSearch.ClassId,fillSearch.SectionId);
                    if (resp.ClassesTeacher != null && resp.ClassesTeacher.Count > 0)
                    {

                        if (fillSearch.RollTimeStatusId > 0)
                        {

                            resp.StudentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetStudentAttendaceById(resp.ClassesTeacher[0].Classes.ID, resp.ClassesTeacher[0].Section.ID, resp.ClassesTeacher[0].Campus.ID, fillSearch.RollTimeStatusId);

                        }
                    }

                }

                //if (fillSearch.IsRefreshData && fillSearch.ClassId > 0 && fillSearch.SectionId >0 && fillSearch.RollTimeStatusId >0)
                //{

                //        if (fillSearch.IsFillStudentAttendanceLateCount)
                //        {
                //            resp.StudentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetStudentAttendaceLateCount(resp.ClassesTeacher[0].Classes.ID, resp.ClassesTeacher[0].Section.ID, rollTimeAttendaceStatus.ID);
                //        }
                //        else
                //        {
                //            resp.StudentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetStudentAttendaceById(resp.ClassesTeacher[0].Classes.ID, resp.ClassesTeacher[0].Section.ID, rollTimeAttendaceStatus.ID);
                //        }             

                //}
                //if (fillSearch.FillAllowance)
                //{
                //    resp.FillAllowances = DAOFactory.Instance.GetAllowanceDAO(dbConnection).FillAllowance(fillSearch.IsActive);
                //}

                //if (fillSearch.FillBankBranch)
                //{
                //    resp.FillBankBranchs = DAOFactory.Instance.GetBankBranchDAO(dbConnection).FillBankBranch();
                //}

                //if (fillSearch.FillDesignation)
                //{
                //    resp.FillDesignations = DAOFactory.Instance.GetDesignationDAO(dbConnection).FillDesignation();
                //}

                //if (fillSearch.FillDesignationByDepartmentId)
                //{
                //    if (fillSearch.DesignationId > 0)
                //    {
                //        Designation designation = new Designation();
                //        //designation
                //    }
                //}

                //if (fillSearch.FillDepartmentWithDesignation)
                //{
                //    resp.FillDepartments = DAOFactory.Instance.GetDepartmentDAO(dbConnection).FillDepartment(fillSearch.IsActive);
                //    for (int rowIndex = 0; rowIndex < resp.FillDepartments.Count; rowIndex++)
                //    {
                //        resp.FillDepartments[rowIndex].Designations = DAOFactory.Instance.GetDesignationDAO(dbConnection).FillDesignationByDepartmentId(resp.FillDepartments[rowIndex].ID);
                //    }
                //}

                //if (fillSearch.IsFillBankWithBranch)
                //{
                //    resp.FillBanks = DAOFactory.Instance.GetBankDAO(dbConnection).FillBanK(fillSearch.IsActive);
                //    for (int rowIndex = 0; rowIndex < resp.FillBanks.Count; rowIndex++)
                //    {
                //        resp.FillBanks[rowIndex].BankBranches = DAOFactory.Instance.GetBankBranchDAO(dbConnection).FillBankBranchByBankId(resp.FillBanks[rowIndex].ID);
                //    }
                //}

                //if (fillSearch.IsFillVoucherType)
                //{
                //    resp.FillVoucherType = DAOFactory.Instance.GetVoucherTypeDAO(dbConnection).FillVoucherType(fillSearch.IsActive);
                //}
                //if (fillSearch.IsFillFinancialYear)
                //{
                //    resp.FillFinancialYear = DAOFactory.Instance.GetFinancialYearDAO(dbConnection).FillFinancialYear(fillSearch.IsActive);
                //}

                //if (fillSearch.IsGetVoucherCode)
                //{
                //    StringBuilder sbVoucherCode = new StringBuilder();
                //    resp.VoucherCode = DAOFactory.Instance.GetVoucherDAO(dbConnection).GetVoucherNo(fillSearch.VoucherDate);
                //    if (fillSearch.VoucherType.ID == PaymentVoucherTye.SalaryVoucher.GetHashCode())
                //    {
                //        sbVoucherCode.Append("SAL-");
                //    }
                //    else
                //    {
                //        sbVoucherCode.Append("PAY-");
                //    }
                //    sbVoucherCode.Append(fillSearch.VoucherDate.Year.ToString());
                //    sbVoucherCode.Append("-");
                //    sbVoucherCode.Append(fillSearch.VoucherDate.ToString("MM"));
                //    sbVoucherCode.Append("-");
                //    sbVoucherCode.Append(fillSearch.VoucherDate.Day.ToString());
                //    sbVoucherCode.Append("-");
                //    sbVoucherCode.Append(resp.VoucherCode);
                //    resp.VoucherCode = sbVoucherCode.ToString();
                //}

                //if (fillSearch.IsGetEmpoyeeCode)
                //{
                //    resp.EmployeeCode = DAOFactory.Instance.GetEmployeeDAO(dbConnection).GetEmployeeCode();
                //}

                //if (fillSearch.IsFillSalaryType)
                //{
                //    resp.FillSalaryPaidType = DAOFactory.Instance.GetSalaryPaidTypeDAO(dbConnection).FillSalaryPaidType(fillSearch.IsActive);
                //}

                //if (fillSearch.IsImportFile)
                //{
                //    ImportExcelpSheet impExcelFile = new ImportExcelpSheet();
                //    System.Collections.ArrayList columnNames = new System.Collections.ArrayList();
                //    columnNames.Add("F3");
                //    impExcelFile.GetExcelSheetData(fillSearch.ImportFileName, columnNames);
                //}
                //if (fillSearch.IsFillSheetName)
                //{
                //    resp.FillExcelSheet = DAOFactory.Instance.GetExcelSheetHelperDAO(dbConnection).FillSheeName(fillSearch.ImportFileName);

                //}
                //if (fillSearch.IsBindExcelFile)
                //{
                //    resp.FillExcelFileData = DAOFactory.Instance.GetExcelSheetHelperDAO().BindExcelSheet(fillSearch.ImportFileName, fillSearch.SheetName);

                //}
                //if (fillSearch.IsGetExcelSheetSetting)
                //{
                //    resp.FillSexcelSheetSetting = DAOFactory.Instance.GetExcelSheetHelperDAO(dbConnection).FillSheetColumn();

                //}
                //if (fillSearch.IsGetVoucherMstIdByVoucherNo)
                //{
                //    resp.VoucherMstID = DAOFactory.Instance.GetVoucherDAO(dbConnection).GetVoucherByVoucherNo(fillSearch.VoucherNo);
                //}
                return resp;
            }
            catch
            {
                throw new Exception();

            }
            finally
            {
                if (dbConnection.State == System.Data.ConnectionState.Open)
                {
                    dbConnection.Close();
                }
            }
        }

        public static int GetStandardTime(DateTime theDateTime)
        {
            if(theDateTime.IsDaylightSavingTime())
            {
                return theDateTime.Hour ;
            }
            else 
            {
                return theDateTime.Hour+12;
            }

        }
    }
}
