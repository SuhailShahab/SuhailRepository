﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Attendance;
using System.Data.Common;
using DataAccess.Generic.Factory;

namespace AMS.Business.Attendance
{
   public  class EvacuationManager
    {
       public List<Evacuation> GetLateStudentByDate(int classId,int sectionId,DateTime theDate,int rollTimeStatusId,int employeId)
       {
           DbConnection dbConnection = DAOFactory.Instance.Connection;
           List<Evacuation> lstEvacuation = null;
           try
           {
               lstEvacuation = DAOFactory.Instance.GetIEvacuationDAO(dbConnection).GetAll(classId, sectionId, theDate, rollTimeStatusId, employeId);
               return lstEvacuation;
           }
           catch
           {
               throw new Exception();

           }
           finally
           {
               if (dbConnection.State == System.Data.ConnectionState.Open)
               {
                   dbConnection.Close();
               }
           }

           //return null;
       }
       public List<Evacuation> Save(List<Evacuation> Evacuations, int createdBy)
       {
           DbConnection connection = DAOFactory.Instance.Connection;
           using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
           {
               try
               {

                   for (int i = 0; i < Evacuations.Count; i++)
                   {
                       if (Evacuations[i].ID > 0)
                       {
                           DAOFactory.Instance.GetIEvacuationDAO(connection, transaction).UpdatEvacuation(Evacuations[i], createdBy);
                       }
                       else
                       {
                           Evacuation evacuation = DAOFactory.Instance.GetIEvacuationDAO(connection, transaction).IsExist(Evacuations[i].Student.ID, Evacuations[i].RollTimeAttendaceStatus.ID);
                           if (evacuation != null && evacuation.ID > 0)
                           {
                               Evacuations[i].ID = evacuation.ID;
                               evacuation.VersionNo = evacuation.VersionNo;
                               Evacuations[i].ID = DAOFactory.Instance.GetIEvacuationDAO(connection, transaction).UpdatEvacuation(Evacuations[i], createdBy);
                           }
                           else
                           {
                               Evacuations[i].ID = DAOFactory.Instance.GetIEvacuationDAO(connection, transaction).InsertEvacuation(Evacuations[i], createdBy);
                           }
                       }
                   }

                   transaction.Commit();
               }
               catch// (Exception ex)
               {
                   transaction.Rollback();
                  
               }
               finally
               {
                   connection.Close();
                   connection.Dispose();
               }
           }

           return Evacuations;
       }
     
    
    }
}
