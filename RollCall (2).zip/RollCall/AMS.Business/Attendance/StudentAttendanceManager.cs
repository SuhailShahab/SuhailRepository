﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using AMS.BusinessEntities.Attendance;
using DataAccess.Generic.Factory;
using AMS.BusinessEntities.CustomEnum;

namespace AMS.Business.Attendance
{
  public   class StudentAttendanceManager 
    {

      public List< StudentAttendace> Add(List< StudentAttendace> studentAttendaces, int createdBy)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
          {
              try
              {

                  for (int i=0; i < studentAttendaces.Count; i++)
                  {
                      //if (studentAttendaces[i].ID > 0)
                      //{
                      //   DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).UpdateStudentAttendace (studentAttendaces[i], createdBy);
                      //}
                      //else
                      //{
                          StudentAttendace studentAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).GetStudnetAttendanceByStudent(studentAttendaces[i]);//, studentAttendaces[i].Student.StudnetClass.ID, studentAttendaces[i].Student.Section.ID);
                          if (studentAttendace!=null && studentAttendace.ID > 0)
                          {
                              studentAttendaces[i].ID = studentAttendace.ID;
                              DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).UpdateStudentAttendace(studentAttendaces[i], createdBy);
                          }
                          else
                          {
                              if (studentAttendaces[i].AttendanceStatus.ID != AttendaceStatus.UnMarked.GetHashCode())
                              {
                                  studentAttendaces[i].ID = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).InsertStudentAttendace(studentAttendaces[i], createdBy);
                              }
                          }
                     // }
                  }

                  transaction.Commit();
              }
              catch// (Exception ex)
              {
                  transaction.Rollback();
                 // HandleBLException(ex);


              }
              finally
              {
                  connection.Close();
                  connection.Dispose();
              }
          }
         // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
          return studentAttendaces;
      }
      //public List<StudentAttendace> AddAbsents(List<StudentAttendace> studentAttendaces,int classId,int sectionId, int createdBy)
      //{
      //    DbConnection connection = DAOFactory.Instance.Connection;
      //    using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
      //    {
      //        try
      //        {

      //            DateTime absentDate = studentAttendaces[0].StartingDate;
      //            for (int i = 0; i < studentAttendaces.Count; i++)
      //            {

      //                while (absentDate.Date <= studentAttendaces[i].EndingDate.Date)
      //                {
      //                   // StudentAttendace studnetAttendace = new StudentAttendace();
      //                   // studnetAttendace = studentAttendaces[i];
      //                  //  studnetAttendace.AttendanceDate = absentDate;
      //                    studentAttendaces[i].AttendanceDate = absentDate;
      //                    studentAttendaces[i].RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
      //                    studentAttendaces[i].RollTimeAttendaceStatus.ID = RollTimeStatusName.MoringRollTimeId;
      //                    StudentAttendace MorningStudentAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).GetStudnetAttendanceByStudent(studentAttendaces[i],classId ,sectionId);
      //                    if (MorningStudentAttendace != null && MorningStudentAttendace.ID > 0)
      //                    {
      //                        studentAttendaces[i].ID = MorningStudentAttendace.ID;
      //                        DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).UpdateStudentAttendace(studentAttendaces[i], createdBy);
      //                    }
      //                    else
      //                    {
      //                        studentAttendaces[i].ID = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).InsertStudentAttendace(studentAttendaces[i], createdBy);
      //                    }

      //                    studentAttendaces[i].RollTimeAttendaceStatus.ID = RollTimeStatusName.EveningRollTimeId;                          
      //                    StudentAttendace EveningStudentAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).GetStudnetAttendanceByStudent(studentAttendaces[i], classId, sectionId);
      //                    if (EveningStudentAttendace != null && EveningStudentAttendace.ID > 0)
      //                    {
      //                        studentAttendaces[i].ID = EveningStudentAttendace.ID;
      //                        DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).UpdateStudentAttendace(studentAttendaces[i], createdBy);
      //                    }
      //                    else
      //                    {
      //                        studentAttendaces[i].ID = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).InsertStudentAttendace(studentAttendaces[i], createdBy);
      //                    }

      //                    // studentAttendaces.Add(studnetAttendace);
      //                    absentDate = absentDate.AddDays(1);
      //                }
      //            }

      //            transaction.Commit();
      //        }
      //        catch// (Exception ex)
      //        {
      //            transaction.Rollback();

      //        }
      //        finally
      //        {
      //            connection.Close();
      //            connection.Dispose();
      //        }
      //    }
      //    // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
      //    return studentAttendaces;
      //}
      public List<StudentAttendace> AddAbsents(List<StudentAttendace> studentAttendaces, int classId, int sectionId, int campusId ,int createdBy)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
          {
              try
              {

                  DateTime absentDate = studentAttendaces[0].StartingDate;
                  for (int i = 0; i < studentAttendaces.Count; i++)
                  {

                      while (absentDate.Date <= studentAttendaces[i].EndingDate.Date)
                      {
                          // StudentAttendace studnetAttendace = new StudentAttendace();
                          // studnetAttendace = studentAttendaces[i];
                          //  studnetAttendace.AttendanceDate = absentDate;
                          studentAttendaces[i].AttendanceDate = absentDate;
                          studentAttendaces[i].RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                          studentAttendaces[i].RollTimeAttendaceStatus.ID = RollTimeStatusName.MoringRollTimeId;
                          //==Exclude the Satureday and Sunday form extended leave===
                          if (studentAttendaces[i].AttendanceDate.DayOfWeek != DayOfWeek.Saturday && studentAttendaces[i].AttendanceDate.DayOfWeek != DayOfWeek.Sunday)
                          {
                              StudentAttendace MorningStudentAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).GetStudnetAttendanceByStudent(studentAttendaces[i], classId, sectionId,campusId);
                              if (MorningStudentAttendace != null && MorningStudentAttendace.ID > 0)
                              {
                                  studentAttendaces[i].ID = MorningStudentAttendace.ID;
                                  DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).UpdateStudentAttendace(studentAttendaces[i], createdBy);
                              }
                              else
                              {
                                  studentAttendaces[i].ID = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).InsertStudentAttendace(studentAttendaces[i], createdBy);
                              }

                              studentAttendaces[i].RollTimeAttendaceStatus.ID = RollTimeStatusName.EveningRollTimeId;
                              StudentAttendace EveningStudentAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).GetStudnetAttendanceByStudent(studentAttendaces[i], classId, sectionId,campusId);
                              if (EveningStudentAttendace != null && EveningStudentAttendace.ID > 0)
                              {
                                  studentAttendaces[i].ID = EveningStudentAttendace.ID;
                                  DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).UpdateStudentAttendace(studentAttendaces[i], createdBy);
                              }
                              else
                              {
                                  studentAttendaces[i].ID = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).InsertStudentAttendace(studentAttendaces[i], createdBy);
                              }
                          }
                          // studentAttendaces.Add(studnetAttendace);
                          absentDate = absentDate.AddDays(1);
                      }
                  }

                  transaction.Commit();
              }
              catch// (Exception ex)
              {
                  transaction.Rollback();

              }
              finally
              {
                  connection.Close();
                  connection.Dispose();
              }
          }
          // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
          return studentAttendaces;
      }
      public List<StudentAttendace> AddEarlyLeaves(List<StudentAttendace> studentAttendaces, int createdBy)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
          {
              try
              {

                  for (int i = 0; i < studentAttendaces.Count; i++)
                  {
                     
                      StudentAttendace studentAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).GetStudnetAttendanceByStudent(studentAttendaces[i]);

                      if (studentAttendace!= null && studentAttendace.ID > 0)
                      {
                          studentAttendaces[i].ID = studentAttendace.ID;
                          DAOFactory.Instance.GetILatePassDAL(connection, transaction).UpdateEarlyLeave(studentAttendaces[i], createdBy);
                      }
                      else
                      {
                          studentAttendaces[i].ID = DAOFactory.Instance.GetILatePassDAL(connection, transaction).AddEarlyLeave(studentAttendaces[i], createdBy);
                      }
                  }

                  transaction.Commit();
              }
              catch// (Exception ex)
              {
                  transaction.Rollback();

              }
              finally
              {
                  connection.Close();
                  connection.Dispose();
              }
          }
          // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
          return studentAttendaces;
      }
      public List<StudentAttendace> AddWithOutReason(List<StudentAttendace> studentAttendaces, int createdBy,int rollId)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
          {
              try
              {

                  for (int i = 0; i < studentAttendaces.Count; i++)
                  {
                      StudentAttendace studentAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).GetStudnetAttendanceByStudent(studentAttendaces[i], studentAttendaces[i].Student.StudnetClass.ID, studentAttendaces[i].Student.Section.ID, studentAttendaces[i].Student.Campus.ID);
                         
                     if (studentAttendace != null && studentAttendace.ID > 0)
                          {
                              if (studentAttendace.UserRole != null && studentAttendace.AttendanceStatus != null)
                              {
                                  if (studentAttendace.UserRole.ID == rollId || rollId == 1 || studentAttendace.AttendanceStatus.ID == AttendaceStatus.UnMarked.GetHashCode())
                                  {
                                      studentAttendaces[i].ID = studentAttendace.ID;
                                      DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).UpdateStudentAttendace(studentAttendaces[i], createdBy);
                                  }
                              }
                          }
                          else
                          {
                              if (studentAttendaces[i].AttendanceStatus.ID != AttendaceStatus.UnMarked.GetHashCode())
                              {
                                  studentAttendaces[i].ID = DAOFactory.Instance.GetIStudentAttendaceDAO(connection, transaction).InsertStudentAttendace(studentAttendaces[i], createdBy);
                              }
                          }
                  }

                  transaction.Commit();
              }
              catch// (Exception ex)
              {
                  transaction.Rollback();
                  // HandleBLException(ex);


              }
              finally
              {
                  connection.Close();
                  connection.Dispose();
              }
          }
          // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
          return studentAttendaces;
      }
      private List<StudentAttendace> GetCopyOfData(List<StudentAttendace> st)
      {
          List<StudentAttendace> newstudentAttendaces = new List<StudentAttendace>();
          if (st != null)
          {
              for (int i = 0; i < st.Count; i++)
              {
                  StudentAttendace studentAttendace = new StudentAttendace();
                  studentAttendace.ID  = st[i].ID;
                  studentAttendace.AttendanceStatus = new AttendanceStatus();
                  studentAttendace.AttendanceStatus.ID = st[i].AttendanceStatus.ID;
                  studentAttendace.AttendanceStatus.Name = st[i].AttendanceStatus.Name;
                  studentAttendace.AttendanceStatus.CssClass = st[i].AttendanceStatus.CssClass;
                  studentAttendace.AttendanceStatus.AttendanceSymbol = st[i].AttendanceStatus.AttendanceSymbol;
                  studentAttendace.RollTimeAttendaceStatus = new RollTimeAttendaceStatus();
                  studentAttendace.RollTimeAttendaceStatus.ID = st[i].RollTimeAttendaceStatus.ID;
                  studentAttendace.RollTimeAttendaceStatus.Name = st[i].RollTimeAttendaceStatus.Name;
                  studentAttendace.Remarks = st[i].Remarks;
                  studentAttendace.Student = new BusinessEntities.Student.Student();
                  studentAttendace.Student.Name = st[i].Student.Name;
                  studentAttendace.Student.LastName = st[i].Student.LastName;
                  studentAttendace.Student.SmallPicture = st[i].Student.SmallPicture;
                  studentAttendace.Student.LargePicture = st[i].Student.LargePicture;
                
                  newstudentAttendaces.Add(studentAttendace);
              }
          }

          return newstudentAttendaces;
      }
      public  List<StudentAttendace> SearchByDate(int classId, int sectionId, int campusId, int rollTimeStatusId, int loginId, DateTime selectedDate)
      {
           DbConnection dbConnection = DAOFactory.Instance.Connection;
           List<StudentAttendace> StudentsAttendace = null;
            try
            {

                StudentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetStudentAttendaceById(classId, sectionId, campusId, rollTimeStatusId, selectedDate.Date, loginId);
                return StudentsAttendace;
            }
            catch
            {
                throw new Exception();

            }
            finally
            {
                if (dbConnection.State == System.Data.ConnectionState.Open)
                {
                    dbConnection.Close();
                }
            }

           // return null;
      }
      public List<StudentAttendace> SearchLateCountByDate(int classId, int sectionId, int campusId, int rollTimeStatusId, int loginId, DateTime selectedDate)
      {
          DbConnection dbConnection = DAOFactory.Instance.Connection;
          List<StudentAttendace> StudentsAttendace = null;
          try
          {

              StudentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetStudentAttendaceLateCountByDate (classId, sectionId, campusId, rollTimeStatusId, selectedDate.Date, loginId);
              return StudentsAttendace;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

           //return null;
      }
      public List<StudentAttendace> GetLateStudentByDate(DateTime fromDate,DateTime toDate)
      {
          DbConnection dbConnection = DAOFactory.Instance.Connection;
          List<StudentAttendace> StudentsAttendace = null;
          try
          {
              StudentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetLateStudentByDate(fromDate,toDate);
              return StudentsAttendace;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          //return null;
      }
      public List<StudentAttendace> GetUnMarkStudents(int rollTimeStatusId,int attendanceStatusId )
      {
          DbConnection dbConnection = DAOFactory.Instance.Connection;
          List<StudentAttendace> studentsAttendace = null;
          try
          {
              studentsAttendace = DAOFactory.Instance.GetIStudentAttendaceDAO(dbConnection).GetUnMarkStudent(rollTimeStatusId, attendanceStatusId);
              return studentsAttendace;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          //return null;
      }
      public void UpdateAttendanceStatus(List<StudentAttendace> studentAttendaces, int createdBy)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
          {
              try
              {

                  for (int i = 0; i < studentAttendaces.Count; i++)
                  {
                      DAOFactory.Instance.GetILatePassDAL(connection, transaction).UpdateAttendanceStatus(studentAttendaces[i].ID, studentAttendaces[i].AttendanceStatus.ID, createdBy);

                  }

                  transaction.Commit();
              }
              catch// (Exception ex)
              {
                  transaction.Rollback();

              }
              finally
              {
                  connection.Close();
                  connection.Dispose();
              }
          }
          // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
          // return studentAttendaces;
      }
      private bool disposed; 
      //public void Dispose()
      //{
      //    Dispose(true); GC.SuppressFinalize(this); 
      //}
      //protected virtual void Dispose(bool disposing)
      //{
      //    // Check to see if Dispose has already been called.
      //    if (!this.disposed)
      //    {
      //        // If disposing equals true, dispose all managed
      //        // and unmanaged resources.
      //        if (disposing)
      //        {
      //            // Dispose managed resources.
      //            component.Dispose();
      //        }

      //        // Call the appropriate methods to clean up
      //        // unmanaged resources here.
      //        // If disposing is false,
      //        // only the following code is executed.
      //        CloseHandle(handle);
      //        handle = IntPtr.Zero;

      //        // Note disposing has been done.
      //        disposed = true;

      //    }
      //}


    }
}
