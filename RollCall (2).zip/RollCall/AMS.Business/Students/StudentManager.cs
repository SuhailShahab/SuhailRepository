﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Student;
using System.Data.Common;
using DataAccess.Generic.Factory;

namespace AMS.Business.Students
{
    public class StudentManager
    {
        public int Add(Student student, int createdBy)
        {
            DbConnection connection = DAOFactory.Instance.Connection;
            int id = 0;
            using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
            {
                try
                {

                    if (student != null)
                    {
                        student.ID = DAOFactory.Instance.GetIStudentDAO(connection, transaction).insertStudnet(student, createdBy);
                        DAOFactory.Instance.GetIStudentDAO(connection, transaction).insertStudentClass(student.ID,student.Campus.ID, student.StudnetClass.ID, student.Section.ID, student.Term.ID, createdBy);
                        int i = DAOFactory.Instance.GetIStudentGaurdianDAO(connection, transaction).insertStudentGaurdian(student.StudentGaurdain, student.ID, createdBy);
                        id = student.ID;
                    }


                    transaction.Commit();
                    return id;
                }
                catch// (Exception ex)
                {
                    transaction.Rollback();
                    // HandleBLException(ex);


                }
                finally
                {
                    connection.Close();
                    connection.Dispose();
                }
            }
            // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
            return 0;
        }
        public int Update(Student student, int createdBy)
        {
            DbConnection connection = DAOFactory.Instance.Connection;
            using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
            {
                try
                {

                    if (student != null && student.ID > 0)
                    {
                        DAOFactory.Instance.GetIStudentDAO(connection, transaction).UpdateStudnet(student, createdBy);
                        int studentClassId = DAOFactory.Instance.GetIStudentDAO(connection, transaction).IsExsitStudentClass(student.ID, student.StudnetClass.ID, student.Section.ID, student.Term.ID);
                        if (studentClassId > 0)
                        {
                            DAOFactory.Instance.GetIStudentDAO(connection, transaction).UpdateStudentClass(studentClassId, student.ID, 1, createdBy);
                        }
                        else
                        {
                            DAOFactory.Instance.GetIStudentDAO(connection, transaction).insertStudentClass(student.ID, student.Campus.ID, student.StudnetClass.ID, student.Section.ID, student.Term.ID, createdBy);
                        }

                        if (student.StudentGaurdain != null && student.StudentGaurdain.ID > 0)
                        {
                            int i = DAOFactory.Instance.GetIStudentGaurdianDAO(connection, transaction).UpdateStudentGaurdian(student.StudentGaurdain, createdBy);
                        }
                        else
                        {
                            int GaurdianId = DAOFactory.Instance.GetIStudentGaurdianDAO(connection, transaction).IsExist(student.ID);
                            if (GaurdianId > 0)
                            {
                                DAOFactory.Instance.GetIStudentGaurdianDAO(connection, transaction).UpdateStudentGaurdian(student.StudentGaurdain, createdBy);
                            }
                            else
                            {
                                int i = DAOFactory.Instance.GetIStudentGaurdianDAO(connection, transaction).insertStudentGaurdian(student.StudentGaurdain, student.ID, createdBy);

                            }
                        }

                    }


                    transaction.Commit();
                    return student.ID;
                }
                catch// (Exception ex)
                {
                    transaction.Rollback();
                    // HandleBLException(ex);


                }
                finally
                {
                    connection.Close();
                    connection.Dispose();
                }
            }
            // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
            return 0;
        }
        public int TerminateStudent(Student student, int createdBy)
        {
            DbConnection connection = DAOFactory.Instance.Connection;
            using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
            {
                try
                {

                    if (student != null && student.ID > 0)
                    {
                        student.IsActive = false;
                        DAOFactory.Instance.GetIStudentDAO(connection, transaction).UpdateStudnet(student, createdBy);

                    }


                    transaction.Commit();
                    return student.ID;
                }
                catch// (Exception ex)
                {
                    transaction.Rollback();
                    // HandleBLException(ex);


                }
                finally
                {
                    connection.Close();
                    connection.Dispose();
                }
            }
            // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
            return 0;
        }
    }
}
