﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FrameWork.Exceptions
{
    public class CustomException : Exception
    {
        public string AppErrorCode;
        public bool IsCommittedTransaction;

        public CustomException()
        {
            IsCommittedTransaction = false;
        }

        public CustomException(string message, Exception exception, bool isCommittedTransaction)
            : base(message, exception)
        {
            IsCommittedTransaction = isCommittedTransaction;
            AppErrorCode = message;
        }

    }//end CustomExceptions
}
