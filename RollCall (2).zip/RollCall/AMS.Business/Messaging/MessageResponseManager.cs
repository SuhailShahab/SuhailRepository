﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AMS.BusinessEntities.Messaging;
using System.Data.Common;
using DataAccess.Generic.Factory;
using AMS.BusinessEntities.CustomEnum;

namespace AMS.Business.Messaging
{
  public   class MessageResponseManager
    {
      //public List<MessageResponse> GetAbsentStudents(int classId, int sectionId, int rollTimeStatusId)
      //{
      //    DbConnection dbConnection = DAOFactory.Instance.Connection;
      //    List<MessageResponse> MessagesResponse = null;
      //    try
      //    {

      //        MessagesResponse = DAOFactory.Instance.GetIMessageResponseDAO (dbConnection).GetAbsentStudents (classId, sectionId, rollTimeStatusId);
      //        return MessagesResponse;
      //    }
      //    catch
      //    {
      //        throw new Exception();

      //    }
      //    finally
      //    {
      //        if (dbConnection.State == System.Data.ConnectionState.Open)
      //        {
      //            dbConnection.Close();
      //        }
      //    }

      //    // return null;
      //}
      public List<ClassCoordinator> GetAllCoordinators()
      {
          DbConnection dbConnection = DAOFactory.Instance.Connection;
          List<ClassCoordinator> classCoordinators = null;
          try
          {

              classCoordinators = DAOFactory.Instance.GetICoordinatorDAO(dbConnection).GetAllCoordinators();
              return classCoordinators;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          // return null;
      }
      public string GetLoginUserCampus(int campusId)
      {
          DbConnection dbConnection = DAOFactory.Instance.Connection;
          try
          {
              string campusName = DAOFactory.Instance.GetIMessageResponseDAO(dbConnection).GetLoginUserCampus(campusId);
              return campusName;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }


      }
      public bool  IsSendEmail(int rollTimeStatusId,int emailTypeId)
      {
          DbConnection dbConnection = DAOFactory.Instance.Connection;
          bool isEmail=false ;
          try
          {

              isEmail = DAOFactory.Instance.GetIEmailStatusDAO(dbConnection).IsEmailSend(rollTimeStatusId, emailTypeId);
              return isEmail;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }
          
      }
      public bool IsSendSMS(int rollTimeStatusId, int smsTypeId,int campusId)
      {
          DbConnection dbConnection = DAOFactory.Instance.Connection;
          bool smsSendStatus = false;
          try
          {

              smsSendStatus = DAOFactory.Instance.GetIEmailStatusDAO(dbConnection).IsSMSSend(rollTimeStatusId, smsTypeId, campusId);
              return smsSendStatus;
          }
          catch 
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

      }
      public int AddMessageStatus(MessageStatus messageStatus)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          int i = 0;
          using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
          {
              try
              {                 
                  i = DAOFactory.Instance.GetIEmailStatusDAO(connection, transaction).InsertMessageStatus(messageStatus,RollTimeStatusName.MoringRollTimeId);

                  transaction.Commit();
              }
              catch// (Exception ex)
              {
                  transaction.Rollback();

              }
              finally
              {
                  connection.Close();
                  connection.Dispose();
              }
          }
          // newstudentAttendaces = this.GetCopyOfData(studentAttendaces);
          return i;
      }
      public void UpdateStudentSMSReason(int studentId, int attendanceStatusId,DateTime smsSendingDate)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
          {
              try
              {
                  DAOFactory.Instance.GetIMessageResponseDAO(connection, transaction).UpdateStudentSMSReason(studentId, attendanceStatusId,smsSendingDate);

                  transaction.Commit();
              }
              catch// (Exception ex)
              {
                  transaction.Rollback();

              }
              finally
              {
                  connection.Close();
                  connection.Dispose();
              }
          }

      }
      public void UpdateStudentMessage(string messageId, string messageText)
      {
          DbConnection connection = DAOFactory.Instance.Connection;
          using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
          {
              try
              {
                  DAOFactory.Instance.GetIMessageResponseDAO(connection, transaction).UpdateStudentMessage(messageId, messageText);

                  transaction.Commit();
              }
              catch// (Exception ex)
              {
                  transaction.Rollback();

              }
              finally
              {
                  connection.Close();
                  connection.Dispose();
              }
          }


      }
      public int AddAbsentStudentSMS(MessageResponse messageResponse)
      {
          //DbConnection dbConnection = DAOFactory.Instance.Connection;
          //int smsStatus = DAOFactory.Instance.IMessageResponseDAO(dbConnection).AddMessageResponse(messageResponse);

          //return smsStatus;
          int result = 0;
          DbConnection connection = DAOFactory.Instance.Connection;
          using (DbTransaction transaction = connection.BeginTransaction(System.Data.IsolationLevel.ReadCommitted))
          {
              try
              {
                 result= DAOFactory.Instance.GetIMessageResponseDAO(connection, transaction).AddMessageResponse(messageResponse);

                  transaction.Commit();
              }
              catch// (Exception ex)
              {
                  transaction.Rollback();

              }
              finally
              {
                  connection.Close();
                  connection.Dispose();
              }
             
          }

          return result;

      }
      public List<MessageResponse> GetAllMessageResponse(int campusId)
      {
          DbConnection dbConnection = DAOFactory.Instance.Connection;
          List<MessageResponse> MessagesResponse = null;
          try
          {

              MessagesResponse = DAOFactory.Instance.GetIMessageResponseDAO(dbConnection).GetAllMessageResponse(campusId);
              return MessagesResponse;

          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

      }
      public List<MessageResponse> GetAbsentStudents(int classId, int sectionId,int campusId, int rollTimeStatusId)
      {
          DbConnection dbConnection = DAOFactory.Instance.Connection;
          List<MessageResponse> messagesResponse = null;
          try
          {
              messagesResponse = DAOFactory.Instance.GetIMessageResponseDAO(dbConnection).GetAbsentStudents(classId, sectionId,campusId, rollTimeStatusId);
              return messagesResponse;
          }
          catch
          {
              throw new Exception();

          }
          finally
          {
              if (dbConnection.State == System.Data.ConnectionState.Open)
              {
                  dbConnection.Close();
              }
          }

          // return null;
      }
     
    }
}
